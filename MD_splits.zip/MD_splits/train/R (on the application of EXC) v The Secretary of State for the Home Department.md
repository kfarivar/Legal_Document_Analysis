# R (on the application of EXC) v The Secretary of State for the Home
 Department [2024] EWHC 935 (Admin)

King's Bench Division, Administrative Court (London)

Mr David Lock Kc, Sitting As A Deputy Judge Of The High Court

30 April 2024Judgment

**Ms Catherine Meredith (instructed the Anti Trafficking and**

Labour Exploitation Unit) for the Claimant

**Mr Gavin Dingley (instructed by the Government Legal Department) for the Defendant.**

No appearance by the Interested Party

Hearing date: 16 April 2024

- - - - - - - - - - - - - - - - - - - - 
**APPROVED JUDGMENT**

_This judgment was handed down remotely by circulation to the parties' representatives by email, release to_
_the National Archives. The date and time for hand-down is deemed to be 12.00 on 30 April 2024._

_I direct that pursuant to CPR PD 39A para 6.1 no official shorthand note shall be taken of this Judgment_
_and that copies of this version as handed down may be treated as authentic._

1. The Claimant seeks permission to challenge a decision of the Single Competent Authority (“the SCA”),
who take decisions on behalf of the Secretary of State for the Home Department, to refuse to allow the
Claimant to re-enter the **_Modern Slavery Victim Care Contract (“MSVCC”) support service following the_**
withdrawal of support at a time when the Claimant was in immigration detention. In order to explain the
decisions I have made it is necessary to set out something about the MSVCC scheme and provide an
outline of the history of this case. However, in summary, I have found that the Claimant has a good
arguable case that he was unlawfully denied the benefit of support under the MSVCC scheme and that the
balance of convenience favours making an order that the Claimant be reinstated to the scheme, and
receive its attendant benefits, pending the resolution of this case.

**The facts.**

2. I take the facts from the Claimant's evidence. Although these facts have not been tested under cross
examination, at this stage the Secretary of State does not appear to take issue with the general factual
picture presented by the Claimant. The Claimant is now aged 23 and is an Albanian national. He entered
the UK as an unaccompanied asylum-seeking child in 2015. He was accommodated by a local authority
and his asylum claim was considered and rejected by the First Tier Tribunal. He was refused permission
to appeal that decision and thus he exhausted his appeal rights by September 2017.

3. At that point he feared that he would be removed back to Albania and so left his foster placement and
sought assistance from friends. He fell in with an Albanian man who I shall refer to as “S”. S exploited the
Claimant by forcing him to work on building sites in the Midlands The precise details as to what happened


-----

to the Claimant are not wholly clear but he was effectively imprisoned by S, financially exploited and
exposed to circumstances which led to him developing Post Traumatic Stress Disorder and a number of
other mental health conditions. In about February 2020, he was unable to work due to his mental health
problems and thus it appears that he was considered to be no use to his traffickers, and was abandoned
by them at Coventry railway station.

4. He explains that he then slept in a park for a few nights, but then met up with someone he had known
from his days of attending Lambeth College when he was in foster care, who allowed him to sleep in his
car. He says that he stayed in the car for 5 nights but then, along with another friend, he decided to take
the car for a drive. He had no driving licence or insurance and accepts that this was a stupid thing to do.
Soon after commencing this escapade, the Claimant encountered the police and, instead of accepting he
was driving illegally, he attempted to drive away from them. The police gave chase and he was arrested.
He was subsequently convicted of dangerous driving at Wolverhampton Crown Court in February 2020.
The Claimant was sentenced to 12 months imprisonment in a Young Offenders Centre. At this point he
was aged 20.

5. The background to the Claimant's offending emerged after he was transferred to Immigration Detention
and an application was made to the SCA for him to be acknowledged as a victim of modern slavery. On
24 August 2020, whilst the Claimant was still detained, he received a positive Reasonable Grounds
decision from SCA.

6. That meant that he became entitled to support as a potential victim of modern slavery. The nature of
that support is set out in guidance published by the Secretary of State under s49 of Modern Slavery Act
2015. S49 provides that the Secretary of State must issue guidance about:

_“(a) the sorts of things which indicate that a person may be a victim of slavery or human trafficking;_

_(b) arrangements for providing assistance and support to persons who there are reasonable grounds to_
_believe are victims of slavery or human trafficking or who are such victims;_

_(c) arrangements for determining whether there are reasonable grounds to believe that a person may be a_
_victim of slavery or human trafficking”_

This case is concerned with what is referred to in the authorities as the Protection Duty, namely
“arrangements for providing assistance and support to persons who there are reasonable grounds to
_believe are victims of slavery or human trafficking or who are such victims”._

7. Although there was initially a delay in issuing this statutory guidance, it has now been issued and is
[called “Modern Slavery: statutory guidance for England and Wales (under s49 of the Modern Slavery Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C273-00000-00&context=1519360)
_2015) and non-statutory guidance for Scotland and Northern Ireland” (“the Guidance”). The Secretary of_
State accepts (at least for present purposes) that this is statutory guidance and accordingly the Secretary
of State has a public law duty to properly understand the meaning of his own guidance and, absent a
carefully formulated case based on reasonable grounds, to give effect to the terms of his Guidance.

8. Part 8 of the Guidance deals with Support for Adult Victims of modern slavery. Para 8.5 provides:

_“Support services may be delivered by a range of organisations, including central government and the_
_support on offer through the_ **_Modern Slavery Victim Care Contract (MSVCC) managed by the Home_**
_Office, which supports adult victims in England and Wales in the community. Potential and confirmed_
_victims may also access support outside of specialist modern slavery support provision, for example, they_
_may receive accommodation through the asylum support system or from a local authority. Where a victim_
_is in immigration detention or prison, support is provided by the immigration removal centre or HM Prison._
_Support may also be provided by third parties not contracted by the state”_

9. Thus, part of the support for victims of modern slavery is provided through the Modern Slavery Victim
Care Contract – the MSVCC. This contract is operated on the Secretary of State's behalf by The Salvation
Army (“TSA”). However, where a victim of modern slavery finds himself in immigration detention, support
for him as a victim is supposed to be provided by the immigration removal centre instead of being provided
by TSA


-----

10. The Guidance explains that the purpose of the support schemes, including the MSVCC, is to provide a
bridge for victims of modern slavery in order to help them to rebuild their lives outside the conditions in
which they were held and to cope with the physical and psychological consequences of being held in
**_modern slavery. The support to victims should include a full risk assessment and a “Needs-Based_**
Assessment” which is:

_“an assessment for all potential victims in the Recovery Period which will identify the support required to_
_address the needs of the potential victim at the Reasonable Grounds stage. Need should continue to be_
_reviewed throughout the victim's time in support as appropriate”_

11. Although there is an initial period of 30 days of support referred to in the guidance, it is recognised that
victims may need support over an extended period. This is set out at para 8.23 which provides:

_“It is important to note that a full recovery should not be expected during this minimum 30-day period; for_
_some victims this may take considerably longer or may not be possible at all. It is therefore expected that_
_victims will leave the Modern Slavery Victim Care Contract with ongoing recovery needs when they have_
_alternate sources of support to help them meet these needs”_

12. This paragraph confirms that the MSVCC is not intended to continue indefinitely but it does suggest
that the support framework is intended to continue until those providing it have assured themselves that
services to support the modern slavery victim in the next stage of his recovery process will be available
for the victim. As part of that process, the Guidance explains that the support workers should develop a
“journey plan” for the victim. Para 8.24 provides:

_“A journey plan is a plan tailored to an individual's needs and circumstances, that keeps track of the_
_potential victim or victim's recovery progress and details how they will move towards independence outside_
_of Modern Slavery Victim Care Contract support”_

13. There are provisions in paragraph 7 of the Guidance to explain the steps that should to be taken
before anyone exits the scheme. Paragraph 7.12 provides:

_“The point at which a victim will be exited from MSVCC support will be determined through a Recovery_
_Needs Assessment conducted in accordance with Recovery Needs Assessment (RNA) process guidance;_
_this guidance is for SCA staff, who make all decisions related to support provided through the RNA_
_process”_

14. The Guidance appears to me to create a structure which starts with a Recovery Needs Assessment,
and then supports a victim through his journey of recovery. When progress has been made, those
providing the services can conduct a further assessment and, at that point, they can decide whether the
person's needs have been sufficiently met and that services outside the MSVCC have been identified to
support the person on his continuing path of recovery. At that point the person will be exited from the
MSVCC because his “journey” (to use the language of the Guidance) has finished.

15. After “exiting” MSVCC support, a victim is entitled to Reach-in support. Para 8.30 explains that
“Reach-in support is a post-NRM service that offers transitional support to confirmed victims, once they
_have exited the main Modern Slavery Victim Care Contract support service”.  However, Reach-in support_
consists of information and signposting but does not include regular financial support.

16. Paras 8.34 to 8.36 of the Guidance refer to a case where a victim has completed their journey and has
exited the main MSVCC support service, and then subsequently receives a conclusive grounds decision. It
provides:

_“8.34. Victims with a positive Conclusive Grounds decision, who have exited the main MSVCC support_
_service, are eligible to be considered for re-entry to MSVCC support, through self-referral. The confirmed_
_victim should contact the SCA to self-refer (nrm@modernslavery.gov.uk, or NRM Duty Line: 0300 0727_
_543)._

_8.35. If the individual is eligible to be considered for re-entry, the SCA will send a Support Referral to The_
_Salvation Army, who will complete a re-entry request form. The SCA will then assess the information_


-----

_provided on the re-entry request form as to whether the need for support outlined should be met by the_
_MSVCC. If the support requested is determined to be provided by the MSVCC, and is linked to their_
**_modern slavery experience, then the SCA will approve the victim to be re-entered into support. If the_**
_support requested does not need to be met by the MSVCC, for example, if it is being met by other_
_services, or the support cannot be provided by the MSVCC, or if Reach-in Support is appropriate, the_
_victim will not re-enter MSVCC support._

_8.36. After being approved for re-entry, but before the individual enters support, risk and initial needs_
_assessments will be conducted by The Salvation Army”_

17. These paragraphs appear to give the SCA a wide discretion to decide whether to permit a person to
re-enter the scheme after he has been formally exited from the MSVCC. That wide discretion appears
entirely sensible because, in the assumed case, by this stage the person will have completed all the steps
that are agreed between the person and the support worker as part of the Recovery Needs Assessment.
However, I consider that it is arguable that the words in these paragraphs about a person who has “exited
_the main MSVCC support service” should primarily mean those who have “exited the main MSVCC support_
_service in accordance with the terms of the Guidance”. Thus, it seems to me that this paragraph applies in_
circumstances where a person has been subject to a paragraph 7 exit assessment, has been exited the
scheme and directed to other areas of support and then seeks to rejoin the scheme. It seems to me to be
arguable that the wide discretion given to the SCA to decide if a person should be allowed to rejoin the
scheme are not applicable to a case where a person has exited the MSVCC scheme otherwise than in
accordance with the terms of the Guidance, namely has exited without having reached the end of his
journey and without an exit assessment.

18. I now return to the facts of this case.  The Claimant was released from detention on 30 September
2020 and moved to live in a house in Sheffield which was provided for him under the MSVCC. The
Claimant moved from the safe house in Sheffield to a friend's house but continued to get financial support
under the MSVCC and assistance from support workers, as well as being in receipt of psychological
support to deal with his mental health problems.

19. On 13 October 2022 the Claimant received a positive conclusive grounds decision by the SCA. His
support appeared to continue under the MSVCC in accordance with his journey plan albeit he appears to
have moved from Sheffield to London at some point. The Claimant has developed a relationship with a girl
in London to which he attaches considerable importance and who provides him with a great deal of
psychological support. He explains that ideally he would like to reside with her but she lives in a shared
house and her landlord will not permit him to reside there. Thus, when the landlord visits, the Claimant
either hides in a cupboard or goes to stay overnight with friends so that he is away from the house. This is
not always possible and at times the Claimant sleeps in a local park to avoid his girlfriend's landlord. He
has explained that he does not want to seek accommodation either as an asylum seeker or under the
MSVCC scheme. It seems to me, reading his evidence, that he is refusing to seek state funded
accommodation because he fears that the accommodation will be provided to him outside London or will
be subject to restrictions which will limit the time he can spend with his girlfriend. I note however that he is
a vulnerable young man with serious mental health difficulties, and that his present accommodation
arrangements are precarious and wholly unsatisfactory. Once he has been restored to the MSVCC
scheme it will be a matter for his support workers to discuss the present arrangements with him in order to
see whether better accommodation arrangements can be found which give him the stability he needs in
order to continue to recover from the long term effects of having been a victim of modern slavery.

20. On 6 March 2023, the Claimant was refused permission to remain in UK as a victim of trafficking.
There does not appear to have been any legal challenge to that decision and accordingly, from that date, it
appears that the Claimant had no legal right to remain in the UK.

21. As he had no continuing right to be in the UK, on 13 June 2023 he was detained in immigration
detention pending deportation.

22. The notes held by TSA show that, on 5 July 2023, the Claimant emailed TSA saying:


-----

_“I've been detained for 22 days and Im loosing my mind the only thing thats comes on my mind Is ending_
_my life because I dont have much choice i already writed a letter to salvation army”_

23. The notes on the TSA system then suggest that TSA staff decided that they were required to take the
decision to exit the Claimant from the MSVCC as he was now in immigration detention.  This is captured in
the following note on the system:

_“The SU [Support Worker] sent an email to mst support advising he has been detained In IRC. Please_
_contact the SU to confirm and proceed with exit”_

24. A variety of reasons were given in the TSA notes namely:

- Exit Reason - Client disengaged from service prior to completion of Recovery and Reflection Period

- Placement End Reason: Client in Custody

- Placement End Reason: Unable to contact client

25. It seems clear from these notes that the TSA staff were struggling to understand which box to
complete and opted for “Client in Custody”. Thus, at that point, the Claimant was noted by TSA staff as
having been exited from the MSVCC. That is consistent with the terms of paragraph 8.5 of the Guidance
which I set out above, which suggests that support for victims of Modern Slavery should be provided by
those running the immigration detention centre.

26. On 10 July 2023 the Claimant was granted immigration bail and promptly made efforts to have his
support reinstated. He then sought, with the help of a support worker from a refugee agency, to re-enter
the MSVCC largely on the basis that he was, in effect, in exactly the same position as he had occupied
prior to his month in immigration detention. However, whatever he did in the period following 10 July 2023,
he did not seem able to extract a reasoned decision from the SCA as to whether he could rejoin the
MSVCC or, if not, why that decision had been taken.

27. In October 2023 the Claimant made a fresh claim for asylum, which has yet to be processed. The fact
that the Claimant has made this application potentially opened up the possibility of the Claimant making an
application for support as a person who has an unresolved application for asylum under section 4 of the
Immigration Act 1999. However, the support provided to people who have an unresolved claim for asylum
is limited, general support. It is wholly different to the specialist, tailored support available to those who
have been victims of modern slavery and are supported to recover from those experiences.

28. The application he made on release to re-enter the MSVCC was eventually refused. A letter from the
Home Office dated 6 December 2023 states that the reason for this refusal was:

_“The team have confirmed that they received a re-entry request for your client on 16 November 2023. This_
_was refused, given that there was no direct causality, in terms of needs, pertaining to your client's Modern_
**_Slavery experience. Additionally, given that a fresh Asylum claim has been submitted, there was potential_**
_scope for Asylum Support provision for your client”_

29. I have seen no material from any decision maker which carries out an assessment of the Claimant's
needs at that point and reaches the conclusion that there was no causal relationship between his needs in
the autumn of 2023 and his experiences of modern slavery. Further, as those supporting the Claimant
had pointed out to the Home Office, by this stage the Claimant had received threatening a message which
he was concerned may have come from his trafficker. This was referred to by his solicitors and the Home
Office suggested that the Claimant make a further application for re-entry to the MSVCC. He duly did so.
His application said:

_“[ECX] is currently destitute due to uncertain immigration status and poverty. He is not allowed to work and_
_has no access to recourse to public funds. He is currently staying with his girlfriend in North London,_
_pending his EUSS claim/ asylum claim being determined. [EXC] requires subsistence payments to avoid a_
_further decline in his mental health and possible re-exploitation._


-----

_Current Risks: EXC has previously experienced suicidal ideations (attempted to end his life in 2020) and_
_self-harmed whilst in immigration detention._

_Diagnosed health conditions: Depression, Anxiety and difficulties sleeping and symptoms of Post-_
_Traumatic Stress Disorder. He is currently prescribed Mirtazapine 45mg and Promethazine Hydrochloride_
_25mg…_

_[EXC] has no means access accommodation or finances. He is at increased risk of exploitation / re-_
_trafficking due destitution. He previously was exploited in 2017 during a period of destitution.”_

30. That application was supported by a psychiatric report which confirmed the Claimant had been
diagnosed with PTSD and which said:

_“In my opinion the most likely causes for [EXC]'s PTSD symptoms described above are the specific_
_traumatic events in his history related to the threat to his life from the blood feud and the persistent abusive_
_and de-humanising exploitation during his period of forced labour. There is nothing else known from his_
_history that would have caused these symptoms. The type and level of the trauma he described would be_
_sufficient to induce such symptoms and consistent with the level required for identification of symptoms._
_The traumas described would meet the specific criterion required for diagnosis in PTSD, i.e., life-_
_threatening and horrific. I would not expect to see the range of specific symptoms of PTSD, which I elicited_
_from [EXC] in someone who had not endured traumas of this level. Migration to the UK and immigration_
_uncertainty on their own or together would not be sufficient. Therefore, his psychiatric symptoms are_
_consistent with his biographical account”_

31. Given this evidence, any decision maker would have to have solid evidence pointing in the other
direction before it could be concluded safely that the Claimant's continuing mental health challenges were
unrelated to his experiences when he was living under conditions of modern slavery. Nonetheless, on 16
January 2024 the SCA, acting on behalf of the Secretary of State, made a further decision to refuse him
entry into the MSVCC.  There is no witness statement from the decision maker and the only evidence of
the reasons for this decision comes from notes on the TSA system which record:

_“After reviewing the request in full the HO is refusing the request for re-entry for this individual._

_The individual has confirmed and stated clearly that they do not consider themselves at risk of re-_
_exploitation despite an incident of a suspected exploiter contacting them as this has since been mitigated_
_through them changing phone number. Regarding support, according to the information provided [EXC]_
_should be entitled to S4 asylum support which includes subsistence and as the request form has not_
_provided any narrative for a MSVCC specific need (recovery/support need) this option should be utilised”_

32. It is not clear precisely who took the decision and there are no disclosed primary documents from the
decision maker. However, I note that the reasons given for refusing the Claimant re-entry into the MSVCC
scheme given here were wholly different to the reasons set out in the letter dated 6 December 2023.

33. It is the Secretary of State's case that this decision was properly taken under paragraph 8.35 of the
Guidance which gives a wide discretion to the SCA to decide whether to readmit a person to the MSVCC
scheme and that the SCA have taken a rational and proper decision not to do so under these paragraphs.

34. However, as became clear in oral argument, simply saying that the Claimant was properly exited from
the scheme when he went into detention and that the Guidance which gives a wide discretion to the SCA
to decide whether to readmit a person to the MSVCC scheme may involve a misunderstanding of the
overall purpose and effect of the Guidance.

35. The Claimant's right to support from TSA was terminated by TSA staff at the point that he was taken
into immigration detention. That decision was taken by TSA staff in accordance with the Guidance
because the package of support for the Claimant was supposed to have been taken over by those running
the immigration detention centre. For these purposes, it does not seem to me likely to matter whether the
staff running the immigration detention centre were, as a matter of fact, providing appropriate support to
the Claimant as a recognised victim of modern slavery for the 1 month period when he was in immigration


-----

detention. Under the guidance, responsibility for providing him with support had moved from TSA to those
running the immigration detention centre.

36. However, the scheme for exiting support under the Guidance provides for a person to be exited after
they have had a full assessment and for the decision to be taken by the SCA, not by TSA staff. I thus put it
to counsel for the Secretary of State during the hearing that it appeared that the Claimant had not been
exited from the scheme in a way that complied with the terms of the Guidance because (a) the decision
was taken by TSA staff and not the SCA and (b) in any event, as far as I can tell on the material presently
before me, the decision was not taken in accordance with the exiting provisions under the Guidance
because the SCA had not assessed that the Claimant had come to an end of his journey, it did not assess
that he had had his needs to support his recovery sufficiently met and there was no assessment that he
would be supported by other services to meet any residual needs.

37. I thus concluded that it was at least arguable that no effective decision had ever been taken by the
SCA to exit the Claimant from the MSVCC scheme. To be fair to counsel for the Secretary of State, he
fully accepted that the Claimant had not been exited in circumstances where there was any assessment of
his needs and where he would get future support as required by paragraph 7 of the Guidance. However,
he could not take the concessions any further at this stage.

38. There is nothing in the Guidance which suggests that MSVCC support can be terminated by the SCA
solely because a person finds themselves in immigration detention. The identity of the body providing
appropriate support may change from TSA to those running the immigration detention centre but that
appears to be is a change in the identity of the body providing services to the person formerly held in
**_modern slavery, not a termination of those services. Hence, whilst the Guidance provides that the identity_**
of the person providing support changes from TSA to the Immigration Detention Centre at the point that a
person is detained, it seems to me arguable that thus solely signifies a change of provider of support
services to the person, not a removal of the right to support.

39. As far as I can determine, the TSA never produced a formal “Journey Plan” for the Claimant as
required by the Guidance. However, as far as I can tell on the material before me at this early stage, on 13
June 2023 neither the TSA nor the SCA had reached any decision that the Claimant had reached the end
of his “journey”.  The Secretary of State has confirmed that no Recovery Needs Assessment was
undertaken, it seems to me to be strongly arguable that no decision (and certainly no lawful decision) was
ever taken by the SCA to exit the Claimant from support as a victim of Modern Slavery.

40. However, having assumed that the Claimant had been exited from the MSVCC, the Secretary of State
advanced 2 reasons why the Claimant was refused re-entry namely:

a. The Claimant said he did not consider that he was at risk of re-exploitation by traffickers; and

b. He could obtain support via s4 now following his renewed asylum application.

41. That decision is challenged by the Claimant. The first alleged problem with that decision is, as it
seems to me, that it is arguable that the decision not to allow the Claimant to re-enter the scheme could not
have been taken lawfully under paragraph 8.35 because either (a) the Claimant had never been lawfully
exited from the scheme in the first place and should have been readmitted as a matter of right in July 2023
and/or (b) if the Claimant had exited the scheme, that paragraph is predicated on the basis that the
Claimant's exit from the MSVCC would have been in accordance with the Guidance and it was not and
accordingly the SCA were looking at the wrong part of the Guidance when they made their decision. It is
arguable, in my judgment, that the Claimant was wrongly treated as having been removed from the
scheme in circumstances when in fact he ought to have been treated as still being part of the scheme and
entitled to support from TSA when he left immigration detention in July 2023 or, that if he did leave the
scheme, his re-entry should have been based on a proper assessment of his needs and it was not.

42. It is arguable that he never lawfully left the scheme because no one had assessed his case and
concluded that he had reached the stage where he had completed the tasks set out in the Recovery Needs
Assessment. There was no assessment as required by para 7.12 as to whether he had moved on
sufficiently to justify an exit from the scheme


-----

43. As I read the Statutory Guidance, there is nothing which permits a supported person to be wholly
removed from the MSVCC on the sole grounds that the person is in detention. I recognise that the effects
of having been a victim of modern slavery are profound and may very well lead to a person getting into
trouble with the law or being in immigration detention. I can see that the benefits of the scheme may need
to be suspended during a period when the person is in detention for practical reasons but if the person is
released, it is difficult to see wording in the Guidance which can be relied upon to suggest it is permissible
for a person to be treated as if they had completed their journey to recovery by having accomplished the
tasks set out in the Recovery Needs Assessment simply because the person finds themselves in
immigration detention.

44. I accept that this Claimant was detained after a relatively long period of support under the MSVCC but,
as the medical report has shown, the problems caused by his period of slavery were profound and long
lasting. I can thus understand why it may have taken longer in his case than in others to complete his
journey. I thus consider that it is fully arguable that the Claimant was wrongly refused “re-admission” to the
scheme because it was not recognised that the Home Office had no proper grounds for exiting him from
the scheme ever existed and he could not be exited solely on the grounds of his being in immigration
detention.

45. I should deal with a further argument that was tentatively advanced by counsel for the Secretary of
State. He argued that it was justifiable for the Claimant to be excluded from support under the MSVCC
because he was a person who the Secretary of State had decided to deport and that put the Claimant
outside the scheme. I do not accept that submission because almost by definition, victims of **_modern_**
**_slavery may have an irregular immigration status and thus could be the subject of a deportation decision._**
There does not appear to be anything in the Guidance which makes support for victims of modern slavery
contingent on them having regularised their immigration status or justifying the Secretary of State
withdrawing support from someone because an intention had been formed to deport the person. I accept
that it is arguably unlawful for the Secretary of State to have made the,decision to withdraw MSVCC
support on the grounds that he had taken a decision that he was minded to deport a person. It seems ot
me that this would be an arguable unlawful departure from the decision framework in the Guidance.

46. A further potential problem is that the evidence base to support a decision based on the Claimant's
own perception of risk of being re-trafficked appears problematic to say the least. First, the Claimant
denies ever having said this and, at least at this stage, the evidence he said this appears thin at best.
Secondly, TSA disagreed because they thought he was a very high risk: see the risk assessment at p106
of the permission bundle undertaken by the TSA. Thirdly, a self-assessment by a victim of trafficking about
his risk of being re-trafficked seems unlikely to be a proper basis, on its own, to suggest that a person is
not at any significant risk of being re-trafficked. Victims of trafficking, especially those with mental health
problems, may well not appreciate the risks they face. Thus, it is at least arguable that any _Tameside_
complaint analysis would take account of the victim's views.

47. In _R (TDT (Vietnam)) v Secretary of State for the Home Department (Equality and Human Rights_
_Commission intervening) [2018] 1 WLR 4922Underhill LJ said at para 40:_

_“A victim of trafficking who is encountered in the back of a lorry or found working at a cannabis farm or a_
_nail bar will not only have been trafficked in the preceding period but will also be at real and immediate risk_
_of the trafficking continuing; even if a victim has escaped, or been removed, from the immediate control of_
_their traffickers, he or she will very commonly still be sufficiently under their influence to be at real and_
_immediate risk of re-trafficking if not afforded proper support and protection…_

_In order to decide whether a past victim is indeed no longer at real and immediate risk of being (re-_
_)trafficked the authorities will in any event have to conduct a careful assessment of the kind for which they_
_contended”_

48. It seems to me that reaching a decision solely on what is reported to have been said by a person
about their own perceptions as to whether they were at risk of being trafficked is a very long way away
from the careful assessment contemplated by the Judge. Thus, on this additional ground, I consider this
claim is arguable


-----

49. In those circumstances I grant permission. I accept that the oral argument extended somewhat
beyond the strict limits of the pleaded grounds, but all the points emerged out of the pleaded grounds as
opposed to being entirely separate grounds. Nonetheless I agree that it is only fair to the Secretary of
State if the Claimant is given an opportunity to amend its grounds.

50. In contrast to the issues around arguability, the question as to whether the Claimant should have
interim relief seem to me to be relatively straightforward. The balance of convenience plainly favours
granting the Claimant continuing support as, without that support, he may become destitute or, if he is
forced to accept s4 support, he is highly likely to lose his support worker, will be moved out of London to
dispersal accommodation elsewhere in the UK, lose his contact with his girlfriend and his existing support
system and his mental health will be threatened. I accept that, if this claim fails, the Secretary of State will
have paid out money that may be irrecoverable and provided support that may not be due. However,
balancing the interests of the parties, the benefits of reinstating support appear to me to vastly outweigh
the risks and I thus order that, until trial or further order, the Claimant be treated as if he remained entitled
to support under the MSVCC scheme from TSA until the hearing of this matter.

**End of Document**


-----

