# R v Ahmed [2022] EWCA Crim 1789

Court of Appeal, Criminal Division

Holroyde LJ, Dove J, Kerr J

6 October 2022Judgment

**Mr F Fitzgibbon KC appeared on behalf of the Applicant**

**Mr P Glenser KC appeared on behalf of the Crown**

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

Thursday 6th October 2022

**LORD JUSTICE HOLROYDE: I shall ask Mr Justice Dove to give the judgment of the court.**

**MR JUSTICE DOVE:**

1. There is an application by the applicant for an anonymity order. We have considered the principles set out in R
_v L; R v N [2017] EWCA Crim 2012, and also the submissions made on behalf of the applicant on the basis that_
she is a vulnerable person who has been found to be a victim of trafficking and is at risk of being further trafficked.
Notwithstanding that material, in striking the balance which we have to between the public interest in open justice
and the particular interests of the applicant, we are not satisfied that it would be appropriate in her case for the
anonymity order to be extended.

2. The facts of this matter are as follows. On 8th September 2017, in the Crown Court at Blackfriars, the applicant
pleaded guilty to conspiracy to commit fraud by false representation. The particulars of that offence were that
between 1st March 2013 and 30th March 2016, along with her co-accused, the applicant conspired to commit fraud
by false representation by presenting false or duplicate sales documents to John Lewis Partnership ("JLP") in order
to obtain refunds of gift vouchers and cash to which she and her co-conspirators were not entitled. Following the
entry of her guilty plea, the applicant instructed her legal representatives that they were not to advance any
mitigation "that may impact on my co-defendants", that is to say the other conspirators with whom she was charged.
The applicant was sentenced to 16 months' imprisonment on 8th November 2017.


-----

3. The applicant's applications for an extension of time in which to apply for leave to appeal against conviction, and
an application to rely upon fresh evidence, pursuant to section 23 of the Criminal appeal Act 1968, have been
referred to the full court by the Registrar.

4. In essence, the case is brought on the basis that, subsequent to these criminal proceedings, the applicant has
been found to be a victim of trafficking by both the Home Office in a conclusive grounds decision, dated 21st
November 2019, and a judge of the First Tier Tribunal Immigration and Asylum Chamber on 7th June 2021. It is
contended, in effect, that the applicant had a statutory defence, or ought not to have been prosecuted, and
therefore her applications should be granted and her appeal against conviction should be allowed.

5. Whilst not the first part of the factual framework in time, it is helpful at the outset to set out in detail the
circumstances of the offence which led to the applicant's conviction, as they were known to the court below.

6. The applicant became friendly with, and then the carer for, Rifhat Azim ("RA") and her children. She was
recruited to take part in the fraud which was being run by RA and her associates, who included her partner. The
nature of the fraud exploited an anomaly in the procedure for refunding goods purchased online by returning them
to a store and reclaiming their price, whether or not they had in fact been purchased online. The conspiracy was
large scale and the applicant played her part by being one of the people who returned items in store at JLP and
obtained refunds to which she was not entitled. It is estimated that £300,000 to £400,000 was obtained from JLP
over the life of the conspiracy. Although during the course of her trial, RA sought to claim that the applicant was a
leader of the conspiracy, in his sentencing remarks the judge did not accept this. Nonetheless, he noted that the
applicant was a prolific offender in relation to offences of this type. He also observed that "the subtext of what was
put before me is that that is where you lived and worked, and you were put to work, and you were the sacrifice, and
you definitely were".

7. The earlier history of this matter is as follows. The applicant is a national of Ethiopia. She arrived in the UK on
8th January 1999 after the outbreak of war in that country. She claimed asylum on arrival in the UK and, in an
appeal against the Home Office's refusal of her siblings' claim, upon which hers was dependent, it was accepted by
the immigration adjudicator that their account of the circumstances which led to them leaving Ethiopia was proved
to the standard required in that tribunal. The immigration adjudicator did not allow the appeal as the situation in
Ethiopia had improved, and they could no longer establish that they would be at risk on return. The applicant
remained in the UK and was ultimately granted indefinite leave to remain as a result of a legacy exercise in 2010.

8. Prior to her conviction for the current offences, and following a conviction at South London Magistrates' Court on
26th May 2016 for an offence of making false representations for which she was sentenced to 24 weeks'
imprisonment, the applicant was served with a notice of the decision to deport her on 27th June 2016. She claimed
asylum following the receipt of this decision on the basis of her fear of ill-treatment by the authorities on return to
Ethiopia. Her asylum claim was refused and a decision to deport re-affirmed.

9. The asylum and deportation decisions were both appealed, which led to the decision of the First Tier Tribunal,
referred to above. However, prior to those proceedings being concluded, and after the Crown Court proceedings
with which this application is concerned were completed, on 1st October 2018 the applicant's case was referred to
the National Referral Mechanism as she was suspected to be a victim of trafficking, leading to the conclusive
grounds decision set out above.

10. The essence of the basis for the conclusive grounds decision was as follows. The applicant had become
friends with RA's mother, and then RA, in Newcastle. RA married Asadullah Ahmadi ("AA"), who was ultimately
one of the co-conspirators, and they moved to London. The applicant became aware that RA and her sister were
shoplifting. When they were convicted and imprisoned as a result of that, the applicant went to support AA and in
due course moved in with them in London.  The applicant cared for their children, without reward. She worked in a
fish and chip shop and was made to hand over her wages to AA and RA. Over the course of several years, the
applicant was coerced and controlled by AA and RA who forced her to take part in shoplifting and the fraudulent
return and refunding of goods, including at JLP. The applicant stated that her vulnerability was exploited by AA and
RA and that she was forced to support their criminal activities. She was isolated from her family and felt unable to
l h h d h l t Th d i i l d d f ll


-----

"Looking at the evidence in the round, it is considered that your account of forced criminality and domestic
servitude within the United Kingdom has met the required threshold, namely 'on the balance of
probabilities' it is more likely than not to have occurred. In summary, you were recruited and transported in
the United Kingdom between March 2007 and October 2016 and therefore meet Part A of the definition of
human trafficking. You were threatened, coerced, deceived and your position of vulnerability was abused,
and thus you also meet Part B. Lastly, you were forced to carry out domestic chores and crimes, for which
you did not receive any payment and therefore you meet Part C."

11. The NRM process and this application are supported by expert evidence from a number of witnesses. Firstly,
the application relies on a psychological report from Dr Bradley Mann, dated 23rd June 2018, which concluded that
the applicant had evidence of a learning disability and impaired cognitive functioning. She was likely to meet the
diagnostic criteria for depression and traumatic stress. As a result of low intellectual functioning and self-esteem,
as well as her compliant personality, she was a vulnerable individual. When Dr Mann examined her again on 14th
October 2019, his findings essentially remained the same.

12. The applicant also relies upon a psychiatric report from Dr Syed Ali who, following an examination on 18th
October 2019, concluded that the applicant had moderate to severe depression, with complex PTSD. Dr Ali stated
that the applicant is a very vulnerable woman with a very fragile state of mind, consistent with her being subjugated
and a psychological slave – a diagnosis consistent with the applicant having been trafficked.

13. The applicant further relies upon the expert evidence of Natalia Dawkins, who has extensive experience of
working with the victims of trafficking and who concludes in her report that the evidence which the applicant
provides establishes that she is a victim of trafficking.

14. Finally, in the context of the appeal, Dr Ian Cumming has produced a joint psychiatric report, dated 6th June
2022. From his own examination, he concluded that the applicant was a vulnerable individual and he found
evidence of depression and complex PTSD. He also found that the applicant exhibited evidence of learning or
intellectual disability – a condition which affects her ability to think adaptably, quickly or flexibly, and which would
have impacted upon her ability to challenge those who were exploiting her. He concluded that she was fit to plead
and to stand trial. Subsequently, in a further report, Dr Cumming has explained that the stress of attending court
would be likely to be traumatic and harmful to the applicant.

15. In the light of Dr Cumming's opinion, it has been agreed that the applicant need not give evidence. It is also
agreed that the applicant's expert reports and her witness statements can be received into evidence, without the
need for any of the witnesses to be called.

16. In support of the application, as indicated above, it was firstly submitted that the court should accept, on the
evidence, that the applicant can now demonstrate that she was a victim of trafficking. Thus, it is contended that
there is potential for her to have been entitled to plead the defence provided by section 45 of the Modern Slavery
Act 2015. For present purposes it suffices to set out section 45(1) which provides as follows:

"Defence for slavery or trafficking victims who commit an offence

(1) A person is not guilty of an offence if —

(a) the person is aged 18 or over when the person does the act which constitutes the offence,

(b) the person does that act because the person is compelled to do it,

(c) the compulsion is attributable to slavery or to relevant exploitation, and

(d) a reasonable person in the same situation as the person and having the person's relevant
characteristics would have no realistic alternative to doing that act."

17. In fairness to the submissions which were advanced this morning on behalf of the applicant, Mr Fitzgibbons KC
did not pursue the contention that section 45 of the 2015 Act entitled the applicant to a defence. Nevertheless, as
the point has been raised certainly in the Respondent's Notice, and appears on the face of the evidence before the
court as well as being essential to the disposal of this appeal it is appropriate to address the issue of whether or


-----

not in the circumstances of this particular case the section 45 defence may be applicable. The position of the
respondent, set out in the Respondent's Notice, is that it is accepted that the court can receive evidence of the
conclusive grounds decision and the decision of the First Tier Tribunal, along with the expert evidence, and
although it is submitted that little help can be derived from Ms Dawkins' expert report on trafficking, there is,
nonetheless, other elements of the evidential material from which it could be concluded that there is a credible case
that the applicant is a victim of trafficking and **_modern slavery. Indeed, Mr Glenser KC, in his submissions on_**
behalf of the respondent this morning, accepted that it was appropriate for the court to record that the respondent's
position is that the applicant has established that she is a victim of trafficking and modern slavery.

18.  The point in relation to section 45 of the 2015 Act arises because of the period of the conspiracy and the fact
that, as a result of the **_[Modern Slavery Act 2015 (Commencement No 1, Saving and Transitional Provisions)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
Regulations 2015, section 45 did not come into force until 31st July 2015. Thus, the section came into force during
the currency of the period of the conspiracy set out in the charge on the indictment.

19. The question of whether the section 45 defence was available in relation to offences committed before it was in
force, and thus whether it was of retrospective effect, was considered, in our view definitively, in _R v CS and Le_

_[[2021] EWCA Crim 134 at [54] to [72] in particular. The court concluded that the general presumption against](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:61XV-50W3-GXFD-823X-00000-00&context=1519360)_
retrospectivity of legislation applied to section 45, in particular in the absence of any evidence in the statutory
material, that it should be displaced. All of the arguments presented by the appellants to support the retrospective
application of the legislation in that case were reviewed and dismissed.

20. Does the fact that the period of the conspiracy specified in the indictment spans the commencement date of
section 45 make any difference? In our judgment, it does not. An offence of conspiracy under section 1 of the
Criminal Law Act 1977 is committed when the agreement to embark upon the course of criminal conduct is forged.
In this case, it was made long before the commencement of section 45 and the availability of the statutory defence.
The entering into the agreement was the act constituting the offence, and it was not entered into at a time when the
section 45 defence was available. The tenor and nature of the applicant's case was that the conspiracy and the
behaviour associated with it occurred consistently across the period over which the conspiracy was charged. The
fact that the precise timescales over which the agreement was to operate were not determined at the time that it
was entered into, and subsequently spanned the commencement of section 45, does not alter this conclusion. If
anything, it reinforces it. Thus, the section 45 defence could not have applied when the offence alleged was
committed, and the fact that the conspiracy agreed upon extended beyond the commencement period does not
entitle reliance upon it in the circumstances of this offence.

21. That is, of course, not the end of the consideration of the issues in this case.  This court has, in earlier
decisions in a number of cases, considered the question of the correct approach to cases in which there had been
convictions of victims of trafficking. These decisions considered the extent to which domestic law could give effect
to the UN Convention against transnational organised crime, including within it Annex 2, a protocol "the Palermo
Protocol", the purpose of which was to prevent in combat trafficking persons and to protect and assist victims of
trafficking. Central to the Palermo Protocol was the creation of the definitions which were to be applied to
determine when a person was a victim of trafficking. The Palermo Protocol was followed by the Council of Europe
Convention on Action against Trafficking in Human Beings, agreed in Warsaw in May 2005, and subsequently
ratified in the UK and brought into force here on 1st April 2009. Article 26 of this Council of Europe instrument
made provision for each party to the Convention to "provide for the possibility of not imposing penalties on victims
for their involvement in unlawful activities to the extent that they have been compelled to do so". In these earlier
cases the courts also considered the policy of the CPS in relation to the exercise of the decision to prosecute.

22. In R v VSJ [2017] EWCA Crim 36; [2017] 1 Cr App R 33, the threads from the earlier case law were drawn
together in [20] and [21]. The court set out the general principles as follows:

"20. The judgments in these cases established the legal regime in domestic law to give effect to the
international obligations we have set out:

i) The obligation under Article 26 of the Council of Europe Convention is given effect in England and
Wales through (1) the common law defences of duress and necessity or (2) guidance for prosecutors on


-----

the exercise of the discretion to prosecute (which has been revised from time to time) or (3) the power of
the court to stay a prosecution for abuse of process (see R v M(L), B(M) and G(D), 2010 at paragraphs 712)

ii) In a case where (a) there was reason to believe the defendant who had committed an offence had been
trafficked for the purpose of exploitation, (b) there was no credible common law defence of duress or
necessity but (c) there was evidence the offence was committed as a result of compulsion arising from
trafficking, the prosecutor has to consider whether it is in the public interest to prosecute (see: R v M(L),
_B(M) and G(D), … at paragraph 10)._

iii) The court's power to stay is a power to ensure that the State complied with its international obligations
and properly applied its mind to the possibility of not imposing penalties on victims. If proper consideration
had not been given, then a stay should be granted, but where proper consideration had been given, the
court should not substitute its own judgment for that of the prosecutor (see R v M(L), B(M) and G(D), … at
paragraph 19).

iv) Where this court concludes that the trial court would have stayed the indictment had an application
been made, the proper course is to quash the conviction (see R v M(L), B(M) and G(D) … at paragraph
17).

v) The obligation under Article 26 does not require a blanket immunity from prosecution for victims of
trafficking. Various factors should be taken into account in deciding whether to prosecute; if there is no
reasonable nexus of connection between the offence and the trafficking, generally a prosecution should
proceed. If some nexus remained, then prosecution would depend on various factors including the gravity
of the offence, the degree of continuing compulsion and the alternatives reasonably available to the
defendant. Each case was fact specific (see R v M(L), B(M) and G(D) … at paragraph 13-14).

vi) The distinct question for decision in the case of a trafficked defendant is the extent to which the
offences with which he is charged (or of which he has been found guilty) are integral to or consequent on
the exploitation of which the person was a victim (see R v L(C), N, N & T, 2013, at paragraph 33). The
court made clear such a decision is a fact sensitive one:

'We cannot be prescriptive. In some cases the facts will indeed show that he was under levels of
compulsion which mean that, in reality, culpability was extinguished. If so, when such cases are
prosecuted, an abuse of process submission is likely to succeed. That is the test we have applied in these
appeals. In other cases, more likely in the case of a defendant who is no longer a child, culpability may be
diminished but nevertheless be significant. For these individuals prosecution may well be appropriate, with
due allowance to be made in the sentencing decision for their diminished culpability. In yet other cases,
the fact that the defendant was a victim of trafficking will provide no more than a colourable excuse for
criminality which is unconnected to and does not arise from their victimisation. In such cases an abuse of
process submission would fail.'

vii) The reason why the criminality or culpability of a trafficked person is diminished or extinguished does
not result merely from age but in circumstances where there has been no realistic alternative available to
the person but to comply with the dominant force of another individual or group of individuals (see R v L(C),
_N, N & T … at paragraph 13)._

viii) The decision of the competent authority as to whether a person had been trafficked for the purposes
of exploitation is not binding on the court but, unless there was evidence to contradict it or significant
evidence that had not been considered, it is likely that the criminal courts will abide by the decision (see R
_v L(C), N, N & T … at paragraph 28)._

21. As a consequence of experience and the decisions of the courts and the successive changes to CPS
guidance, the present policy of the CPS, as expressed in 2015, in respect of those not within the scope of
the 2015 Act is to require the prosecutor to consider three broad questions on a fact specific basis in each
case where the defence of duress does not arise on the evidence:


-----

i) Is there credible evidence that the defendant falls within the definition of trafficking in the Palermo
Protocol and the Directive?

ii) Is there a nexus between the crime committed by the defendant and the trafficking? In the case of
adults it is necessary to assess whether the defendant had been compelled to commit the crime by
considering whether the offence

'was a direct consequence of, or in the course of trafficking/slavery and whether the criminality is
significantly diminished or effectively extinguished because no realistic alternative was available but to
comply with the dominant force of another'.

iii) Is it in the public interest to prosecute? There will be some crimes that it will be in the public interest to
prosecute."

23. This distillation of the principles was reiterated in indistinguishable terms by Gross LJ in R v GS _[2018] EWCA_
_Crim 1824. There is, in the circumstances, no need for further citation._

24. A number of contentions arise for determination in respect of this proposed appeal, which must, in the light of
our earlier conclusion, be determined by applying the law before the section 45 defence commenced. The first of
these is whether to grant the application for fresh evidence, applying the well-known principles taken from section
23 of the Criminal Appeal Act 1968 and the authorities such as _R v GS_ and _R v ADD_ _[[2022] EWCA Crim 106;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_

[2022] 1 Cr App R 19, in which similar questions arose. As set out above, there is no dispute but that the
conclusive grounds decision and the determination of the First Tier Tribunal should be admitted into evidence. We
note, of course, that this is not to say that this documentation would necessarily be admissible in the context of a
trial in the Crown Court. It is also agreed that the medical expert report should be admitted. Different issues arise
with respect to Ms Dawkins' report in relation to whether or not the applicant was a victim of trafficking. The
authorities demonstrate that, without in any way calling into question the knowledge and expertise of this witness,
little assistance can be obtained in relation to the issues that the court has for itself to decide.

25. Having considered this material, a number of points emerge. Firstly, it is reasonably clear that many of the
applicant's cognitive and mental health problems are of long-standing, and it appears to us that the medical
evidence describes matters which are not new and which could reasonably have been researched and put before
the court at the time of the proceedings in the Crown Court. It appears implicit in the way in which the prosecution
is framed that the applicant was experiencing these issues at the time of the offence, and therefore equally at the
time of the Crown Court proceedings.

26. Secondly, there were clearly indications in the material before the Crown Court that the applicant participated in
the offence at the direction and to some extent under the control of others. This is evidenced in the judge's
sentencing remarks, set out above, and also in the sentencing note prepared by the applicant's counsel, describing
her as a "foot soldier" controlled by others. Clearly, her counsel could not go behind her instructions not to mitigate
as to affect the interests of her co-accused; but in that instruction there is the further clue that the applicant was at
times under the heavy influence of RA and AA in particular. In these circumstances, as the respondent points out,
the reality is that this is a case of fresh instructions from the applicant, arising out of the circumstances which were
known to her at the time of the Crown Court proceedings. The principles in relation to such cases on appeal are
clear. A defendant has one chance to present their case to the Crown Court, and it is necessary for them to provide
their full instructions to their legal advisers at that time. Only in the most exceptional of cases will this court permit a
defendant to advance what in effect would be fresh instructions about the facts in relation to a conviction. It is clear
that this principle has been applied to cases involving trafficking. In our view this is a significant impediment to the
applicant's case.

27. Nevertheless, even were these fresh instructions to be considered, on the basis of the material before the
court, it is accepted, and beyond dispute, that the applicant is a victim of trafficking, as set out above. In his
submissions this morning on behalf of the respondent, Mr Glenser accepted as much.

28. There are, however, it will be clear from the citation of authority set out above, further points which have to be
considered when applying the legal principles in respect of pre-section 45 cases to the case of this applicant The


-----

first of these is the question of whether there is a nexus between the crime which the applicant committed and the
offence which was a direct consequence of the trafficking, such that the applicant's criminality is significantly
diminished or effectively extinguished, because no realistic alternative was available but to comply with the
dominant force of another: see, for instance, VSJ at [21] – a requirement reiterated in the other authorities.

29. Having considered the material which is before the court in relation to the applicant's case, we are not satisfied
that it is properly arguable that her criminality is significantly diminished or extinguished as a result of having no
realistic alternative but to comply with the instructions of RA and AA. It is clear from all of the evidence that, firstly,
the record of her previous convictions shows that, prior to and during the time period of the conspiracy, the
applicant was convicted on numerous occasions for offences which appear to be of a similar character to the
purpose of this conspiracy. Those offences gave rise to appearances before the court and disposals which
included both community sentences and terms of imprisonment. In reality, the applicant was provided with at least
several opportunities to obtain help and support, and to break away from the influences that led her to offend, but
she failed to avail herself of any of those opportunities when there was such a chance to break away.

30. The evidence also demonstrates, and the prosecution submit, that the applicant was able to move about the
country, in particular between London and Newcastle, in order to visit her relatives, in particular her siblings in
Newcastle. It is further submitted on behalf of the respondent that she had support from her siblings, and therefore
the nexus which is necessary in the present case has not been accepted. These submissions are well-founded.

31. In the light of this material, and stepping back, we are unable to accept that it is arguable, even taking account
of the medical evidence presented in this appeal and relied upon by her, that the applicant had, or may have had,
no reasonable alternative during the course of this lengthy conspiracy, other than to continue to participate in it.

32. Further, it is necessary to offer observations in relation to the third aspect of paragraph 21 of VSJ, namely the
question of whether or not it would be in the public interest for the applicant to have been prosecuted. The
respondent submits that there is considerable force behind the suggestion that it would have been in the public
interest to prosecute her and that is a submission which we accept. As the judge at the time of sentencing the
applicant observed, and as is obvious from her record of previous convictions, she was a very persistent offender in
relation to offences of dishonesty. She had had, as has already been noted, several opportunities for rehabilitation
as a consequence of her earlier appearances before the courts, none of which had been taken. The offence with
which she was charged involved the dishonest acquisition of a very substantial amount of money in circumstances
where an immediate term of custody was almost inevitable. In all of those circumstances we are not satisfied that it
is properly arguable, other than that the public interest required that the applicant be prosecuted.

33. During the course of his submissions this morning, it has been contended by Mr Fitzgibbon, based in particular
[on paragraph 156 in R v Tredget [2022] EWCA Crim 108; [2022] 2 Cr App R 1, that the guilty plea entered by the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R9-80J3-CGX8-00NM-00000-00&context=1519360)
applicant was equivocal and can properly be regarded to have been vitiated by improper pressure. Paragraph 156
cites two cases, but in particular R v Inns (1974) 60 Cr App R 231, as authority for the proposition that a plea of
guilty entered under pressure and threats is not one upon which proper reliance can be placed. Thus, it is
submitted on the applicant's behalf by Mr Fitzgibbon that the guilty plea in this case was equivocal on the basis that
it is accepted that she was a victim of trafficking, and that it was involuntary as a consequence of the coercion and
control which she was under by consequence of her relationship with RA and AA.

34. We are not satisfied that this submission is properly arguable for a number of reasons. Firstly, the evidence is
frail, in our judgment, in relation to the question of whether or not this case properly falls within this category of
cases. The reality is that Mr Fitzgibbon relies upon the medical evidence coupled with two short observations in the
applicant's witness statement. In our judgment, that is insufficient to establish that the plea, which was plainly
unequivocal from the court's perspective, was one which could not be relied upon in the context of these
proceedings.

35. Secondly, and in any event, the applicant is afforded protection by the application of the pre-2015 domestic law
principles. In particular, the second criterion, namely, whether there is a nexus between her offending and the
conclusion that she was a victim of trafficking, provides protection in relation to ensuring that only in proper cases
ld i ti f t ffi ki b th bj t f ti


-----

36. For the reasons which we have set out above, we are not satisfied that it is properly arguable that those
principles lead to the conclusion that the applicant ought not to have been prosecuted before the Crown Court.

37. This point also addresses other authorities where, for instance, those who were convicted were unaware of a
defence for various reasons. In this instance, the applicant has had the opportunity for this court to consider
whether the domestic law in operation at the time afforded a proper reason for her not to be brought before the
court.

38. For all of these reasons, we are not satisfied that it is properly arguable that leave to appeal should be granted
in this case. In the circumstances, therefore, we are not satisfied that any purpose would be served by granting the
extension of time which has been sought, and we decline to do so.

39. For all of these reasons, this application must be refused.

__________________________________

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground, 18-22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

______________________________

**End of Document**


-----

