# R v Mason and Others [2023] EWCA Crim 1540

Court of Appeal, Criminal Division

Popplewell LJ, Baker J, HHJ De Bertodano

9 November 2023Judgment

Transcript prepared from digital audio by

Opus 2 International Ltd.

Official Court Reporters and Audio Transcribers

5 New Street Square, London, EC4A 3BFTel: 020 7831 5627   Fax: 020 7831 7737

CACD.ACO@opus2.digital

_________

MISS J MAXWELL appeared on behalf of the First Appellant.

MR S NIKOLICH appeared on behalf of the Second Appellant.

MR J NUTTER appeared on behalf of the Third Appellant.

MR P JARVIS appeared on behalf of the Crown.

_________

If this Transcript is to be reported or published, there is a requirement to ensure that no reporting restriction will be
breached. This is particularly important in relation to any case involving a sexual offence, where the victim is
[guaranteed lifetime anonymity (Sexual Offences (Amendment) Act 1992), or where an order has been made in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)
relation to a young person.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

LORD JUSTICE POPPLEWELL:

1 James Mason, now aged 34, his brother Josh Mason, now 25, and Adam McArdle, now 28, were
involved with others in operating a county lines drugs operation supplying heroin and cocaine from
Liverpool to Oswestry, Shropshire, using vulnerable children and young people aged between 14 and 18
as runners.  They were sentenced by His Honour Judge Barrie in the Crown Court at Shrewsbury for
offences of being concerned in the supply of heroin and crack cocaine and conspiracy to commit offences
[contrary to the Modern Slavery Act 2015. They each pleaded guilty to those offences at various different](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
stages of the proceedings against them. McArdle was sentenced to 14 years' imprisonment, James Mason
to 7 years' imprisonment, and Josh Mason to 6 years' imprisonment. McArdle and Josh Mason seek leave


-----

to appeal against their sentences. The Solicitor-General applies for leave to refer the sentences of Josh
Mason and James Mason as unduly lenient.

2 Count 1 comprised conspiracy to commit an offence contrary to section 1(1)(b) of the Modern Slavery
Act of requiring a person to perform forced or compulsory labour. Count 2 comprised conspiracy to commit
an offence contrary to section 2 of the Modern Slavery Act of arranging or facilitating the travel of a person
with a view to the victim being exploited. We will refer to those **_Modern Slavery Act offences as "the_**
slavery offence" and "the trafficking offence" respectively.  McArdle and James Mason pleaded guilty to
both offences, whereas Josh Mason pleaded guilty only to the slavery offence, with the trafficking offence
being ordered to lie on the file.

3 Counts 3 and 4 (in the case of James Mason offences 1 and 2 to which he pleaded guilty at the
magistrates court and was committed for sentence) charged being concerned in the supply of heroin and
crack cocaine, respectively, contrary to section 4(3)(b) of the Misuse of Drugs Act 1971.

4 The individual sentences were as follows:

Count 1 (the slavery offence): McArdle 7 years, James Mason 5½ years, Josh Mason 4½ years.

Count 2 (the trafficking offence): McArdle 7 years, James Mason 5½ years.

Count 3/offence 1 (supply of heroin): McArdle 14 years, James Mason 7 years, Josh Mason 6 years.

Count 4/offence 2 (supply of crack cocaine) McArdle 14 years, James Mason 7 years, Josh Mason 6
years.

5 All sentences were made to run concurrently.

_The facts_

6 The drugs line, known as the Boris Line, was operated for about 18 months between July 2018 and
February 2020, from two locations in Liverpool, one being the home of James Mason and the other a
location close to where McArdle lived. The operation was run by an organised crime group which was
described as 'extremely violent'.

7 The person in overall control of the line was McArdle, but between March and July 2019 James Mason
was entrusted with the mobile telephone through which the line operated, after which McArdle resumed
that role using a new number.  Those in charge of the line sent out regular bulk messages advertising
drugs for sale. When orders were placed by users on the line, instructions were sent to the local dealers in
Oswestry, who would then arrange for the drugs to be delivered to the purchasers. There were a series of
drugs supplies made to users on an almost daily basis throughout the indictment period.

8 Periodically the drugs were supplied from Liverpool to the associates in Oswestry to enable the dealing
operation to take place, and the cash to be collected. Josh Mason bagged the drugs and made some 30
trips between Liverpool and Oswestry during the indictment period to deliver the drugs and collect the
cash.  His involvement continued after his brother, James Mason, had ceased to be operating the line
himself.

9 The runners who delivered the drugs to users in Oswestry were provided with mobile telephones and
were responsible for handing over the drugs, collecting the cash and giving it to the dealers in Oswestry.
The operation used nine children, amongst others, to deliver the drugs in Oswestry. At the beginning of
the indictment period one was aged 14, one aged 15, four were aged 16 and three were aged 17. Many
of them were threatened with violence and encouraged into drug use in order to make them indebted to
those running the operation. Many of them were known to children's services in the Oswestry area. A
number of them had very poor attendance at school. Some had mental health problems and others came
from homes where the adults were drug users or where domestic abuse was prevalent.

10 The children were all from the Oswestry area, and the trafficking offence appears to have been put on
the basis that it involved facilitating rather than arranging travel, the travel involved being simply the
inevitable concomitant of their being the runners that were being exploited in the commission of the section


-----

1 offence. Accordingly, it does not seem to us that the trafficking offence adds anything of any significance
to the slavery offence so far as affects the length of sentence.

11 On 11 July 2019, the police raided the home address of James Mason. They found large quantities of
heroin and crack cocaine as well as drug paraphernalia and £10,000 in cash. The police also found a
black Samsung mobile telephone which, upon being interrogated, turned out to be the Boris Line
telephone. Thereafter McArdle resumed operating the line with a new number.  The police estimated the
total quantities of drugs involved in the operation at a little over 1 kilogramme, and that those in charge of
the line probably received about £100,000.

12 On 7 January 2019, during the indictment period, there was an attack on Lizzie West. She was a 30
year old heroin and cocaine addict who was supplied by one of those in Oswestry involved in the Boris
Line operation, a man called Stewart. She had been given some £500 worth of drugs to sell by Stewart
and had either used them or lost them and so was in debt to Stewart and McArdle. McArdle travelled from
Liverpool and went to meet Lizzie West in a local park together with Stewart and another, who had
arranged the meeting.  McArdle slashed her face, neck and wrists a number of times with a blade, causing
deep lacerations, going down to the bone of her jaw and leaving significant scarring and life-changing
injuries.  McArdle was sentenced for this offence in the Crown Court at Stafford on 3 September 2020 to
life imprisonment with a minimum term of 8 years and 12 days, being 9 years less 353 days spent on
remand, pursuant to section 225 of the Criminal Justice Act 2003. In reaching such sentence the Judge on
that occasion took account of the drugs context as aggravation, determined that McArdle was dangerous
and concluded that a determinate sentence (which would have been one of 18 years imprisonment) would
not adequately protect the public. His appeal against that sentence was dismissed by this court.

13 When His Honour Judge Barrie was sentencing for the instant offences on 9 August 2023 there was
just over five years of the minimum term of that sentence left to serve.

_Bases of plea_

14 James Mason and Josh Mason entered bases of plea to the Modern Slavery Act offences which the
prosecution did not challenge.

15 James Mason's basis of plea stated that he did not know the individuals were victims of **_modern_**
**_slavery until 19 March 2019 (i.e. for, roughly speaking, the first 7 months of the 11 month indictment period_**
up to the time of his arrest). The basis of plea also said that he received communications via the drug line
and made arrangements for the street dealers to supply the drugs, but he was not the principal, whom he
declined to name.

16 Josh Mason's basis of plea stated that when he was first involved he was unaware that minors were
involved. It said that he became aware of that at some point after his initial involvement but it did not
identify when. It stated that he was not involved in the initial recruitment of minors, was not in direct
contact with them and was not responsible for directing them through others.

17 McArdle pleaded guilty without a basis of plea.

_Antecedents_

18 McArdle had 15 convictions from 8 prior appearances. Apart from the Lizzie West conviction, the most
significant were for offences of conspiring to supply heroin and cocaine, committed when he was aged 19,
for which he was sentenced in 2015 to three years' detention in a Young Offenders Institution.

19 James Mason had nine convictions, the last being in 2012. They did not involve offences of supply of
drugs and none had attracted a custodial sentence.

20 Josh Mason had convictions for 22 offences, including 12 for fraud or theft or kindred offences, five for
possession of drugs and, most significantly, one for possession with intent to supply heroin and crack
cocaine for which he was sentenced in 2017 to two years' detention in a Young Offenders Institution. He
was aged 19 at the time of the commission of those offences.


-----

_Pre-Sentence Reports_

21 In interview with the author of the Pre-Sentence Report, James Mason said that he became involved in
the operation of the Boris Line because his brother Josh was in debt and one of his co-defendants
threatened him that if he did not work to pay off that debt then someone would burn down his mother's
house. He told the author of the report that he was provided with a mobile telephone and given
instructions as to what to say to those who called it. He said he felt a sense of relief when he was arrested
because it meant he would no longer be subject to threats and intimidation to carry on. He went on to say
that he was unaware at the beginning that the group were using vulnerable young people as runners.
When he learned of this he felt that there was nothing he could do to prevent it such was the fear that he
was in.

22 In the author's assessment, it was likely that James Mason could have distanced himself from the
operation of the Boris line if he had wanted to, and also likely that as well as taking orders he was handing
them out. The author was also sceptical of James Mason's assertion that he made no gain from his
involvement other than the opportunity to clear his brother's debt.

23 There was also evidence available to the Probation Service, recorded in the report, to show that James
Mason experienced daily asthma attacks and often struggled to breathe.

24 The author assessed James Mason's risk of re-offending as medium, and she recognised that he was
likely to receive a lengthy custodial sentence.

25 In Josh Mason's case, he told the author of his Pre-Sentence Report that he had become involved in
the operation of the Boris Line in order to make ends meet and not to fund a lavish lifestyle. He said he
had been raised by his elder siblings because his mother was always working and his father was never
around. He first became involved in drug dealing aged 15, when he was approached by a drug dealer and
was offered the opportunity to deliver some drugs for payment. He took that offer, and that was when his
involvement in drug dealing first started. That involvement escalated, resulting in his first conviction of
possession with intent to supply in 2017. Upon his release from that sentence he said he tried to find a
responsible job but without success. It was not long before he descended back into a life of dealing drugs,
and that was how he became involved with the Boris Line. He told the author he regretted the choices he
had made in his life, although he realised that plenty of people in difficult situations would have made
different decisions from those which he made.

26 The author assessed Josh Mason as presenting a low risk of re-offending in the future. Under different
circumstances she would have recommended the imposition of a community order, but she acknowledged
that the offences were too serious for that.

27 There was no Pre-Sentence Report prepared for McArdle for this particular sentencing, but the Judge
had before him the Pre-Sentence Report which had been prepared when McArdle had been sentenced for
the Lizzie West wounding in 2020.

_Sentencing_

28 The Judge sentenced the Mason brothers together with a number of co-defendants on 7 August 2023.
McArdle was not produced in time to be table to take part in that hearing, with the result that he was
sentenced separately two days later on 9 August.

_Sentencing the Mason brothers_

29 The Judge resolved to impose concurrent sentences on all offences, treating the drugs offences as the
lead offences on which the sentences would reflect the total appropriate for all the offending.

30 The Judge agreed with the prosecution that the harm in respect of the drugs offences fell within
Category 2 by reason of the quantity involved and the extent of the dealing over the indictment period.  He
also agreed that James Mason occupied a leading role and Josh Mason occupied a significant role. The
Sentencing Council Guideline provides that for a Category 2 leading role the starting point is 11 years, with
a range of 9 to 13; and for a significant role the starting point is 8 years with a range of 6 to 10 years.


-----

31 The Judge said that for James Mason, the sentence after a trial for the drugs offences taken alone
would have been one of 10 years' custody. For Josh Mason it would have been 7½ years. The Judge
afforded credit of one-third to both for their guilty pleas, reducing them to 6 years 8 months and 5 years
respectively.

32 Turning to the **_modern slavery offences, the Judge agreed with the prosecution that in the case of_**
James Mason the harm was Category 2 and his culpability was medium. In accordance with the relevant
guideline, that gave a starting point of 8 years' custody. The Judge adjusted that sentence downwards to
one of six years by reason of the matters set out in the basis of plea, and then reduced it further to 5½
years to reflect the credit due for his late plea of guilty.

33 For Josh Mason the Judge concluded that in the light of his basis of plea the harm fell into Category 3
but that his culpability was also medium. That meant the starting point on count 1 for him was 6 years'
custody. The Judge determined that a sentence after a trial for that offence alone would have been 5
years, which the Judge reduced to 4½ years for his late plea.

34 In the course of his sentencing remarks, the learned Judge remarked that the defendants had exploited
young people by compelling them to become involved in drug dealing: "in a way that goes far beyond
forced labour and amounts, in law, to slavery." He went on:

". . . there is obviously a substantial overlap of the drug dealing and the slavery offences. But the slavery
offences emphasise the significance of this kind of exploitation which, in a less serious case, might be
regarded as an aggravating feature."

35 The Judge went on to say that having decided to impose concurrent sentences for the two sets of
offences, it was incumbent on him to make some upward adjustment to the drugs sentences to account for
the principle of totality. In the final analysis the Judge decided to increase the sentences for the drug
offences by 12 months in the case of each of the Mason brothers. With respect to James Mason that
would have increased his overall sentence to 7 years and 8 months' imprisonment. From that figure, the
Judge then made a further deduction of 8 months to take account of personal mitigation, most notably his
health problems. That was the wrong stage at which to make a further deduction, having previously
identified the appropriate sentence after a trial, but that does not form part of the grounds for the AttorneyGeneral's reference, and we will treat James Mason as entitled to that reduction. That meant that his final
overall sentence was 7 years' imprisonment, which was the sentence imposed on offences 1 and 2.  With
respect to Josh Mason the uplift of 12 months for the slavery offence increased his overall sentence to 6
years' imprisonment on counts 3 and 4, with the lesser concurrent sentence on count 1.

_McArdle sentencing on 9 August_

36 The Judge recognised that there was an overlap between the Lizzie West incident, which was part of
McArdle's role in operating the Boris Line, and counts 3 and 4 which concerned that role more generally.
The Judge identified that McArdle had had a particular role in spreading fear of violence to get those lower
down the chain to toe the line, and he was a key part of the compulsion and exploitation of the young
people which comprised the Modern Slavery Act offences. He fell to be sentenced for his involvement in
the county line operation beyond the specific instance of the attack on Lizzie West.

37 The Judge said that although he treated the quantity of drugs involved as Category 2, in McArdle's
case he would elevate it to Category 1 because of his leading role in an organised crime group operation
over a busy and sustained period of 18 months. A Category 1 leading role has a guideline starting point of
14 years, and a range of 12 to 16 years. The Judge moved up in the range from the starting point to 15
years by reason of McArdle's role and his previous convictions, before giving credit of one-third for the
guilty pleas so as to reduce it to 10 years.  He put the Modern Slavery Act offences in Category 2A with a
starting point of 10 years. He increased that slightly for aggravating factors and reduced it by one-third for
the guilty plea to come down to 7 years.

38 He then turned to the practical effect of the 2020 sentence. He said that he could impose a sentence
which was consecutive to the minimum term imposed in 2020, which would then require a very substantial


-----

reduction for totality; but that he preferred to impose a sentence which commenced immediately and ran
concurrently with the minimum term "rather than an artificially reduced sentence that runs consecutively."
He resolved to add four years to the drugs offence sentence (10 years) to reflect the Modern Slavery Act
offending, resulting in a 14 year sentence on counts 3 and 4 to reflect all the offending.  The Judge said
that the practical effect would be to add two years to the minimum term because McArdle would be eligible
for release at the half way point of the 14 year sentence after 7 years, and there were about 5 years left of
the minimum term of the 2020 sentence.

_McArdle's application for leave to appeal._

39 Two grounds of appeal were advanced. The first was that the Judge made a mistake in thinking that
McArdle would be eligible for release halfway through the 14 year sentence, and that he would, rather, only
be eligible for release after two-thirds of that sentence had been served by reason of section 130 of the
Police Crime and Sentencing Courts Act 2022, which inserted a new section 244ZA into the _[Criminal](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DV-00000-00&context=1519360)_
_[Justice Act 2003.  That ground is misconceived, and the Judge made no such mistake, as Mr Nikolich,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DV-00000-00&context=1519360)_
who appeared before us on behalf of James Mason, frankly accepted. In order for section 244ZA to apply,
amongst other things the offences must be specified offences in Part 1 or 2 of Schedule 15 to the 2003 Act
(see subsection 4(d) of section 244ZA). Counts 3 and 4 do not fulfil that requirement.

40 That requirement and the other requirements of section 244ZA are fulfilled for the Modern Slavery Act
offences for which a 7 year sentence was imposed. Accordingly, McArdle could not be released under
those sentences until two-thirds of them had been served, that is to say 4 years and 8 months. But since
that is less than both the remaining period of the minimum term of 5 years and the period of 7 years, which
is half the 14 year term imposed for the drugs offences, that has no bearing on how long he will remain in
custody.

41 The second ground advanced is that the sentence overall was manifestly excessive. We cannot
accept that submission. The structured way in which the Judge reached the overall sentence cannot be
faulted. The practical effect of the total sentence, which was to impose an additional period of custody, at
least of about two years, was commensurate with the totality of offending over and above that imposed for
the Lizzie West wounding. That was not excessive, let alone manifestly so, and indeed might well be
regarded as lenient. We do not concern ourselves with whether the Judge was right to achieve that
outcome by treating the drugs offending as falling within Category 1A. He could just as easily have done
so by treating them as Category 2A but giving a greater uplift for the Modern Slavery Act offences.  We
say some more about the seriousness of the **_Modern Slavery Act offences when addressing the_**
application for a reference in the case of the Mason brothers. Or he might have imposed sentences
consecutive to the minimum term imposed in 2020. Or he might have imposed sentences for the drugs
offences and the Modern Slavery Act offences which took immediate effect but were consecutive to each
other. It is the overall sentence which matters, not how it was structured, and we commend the Judge for
taking the least complicated route of imposing a sentence to take immediate effect which took proper
account of the existing minimum term.

42 Accordingly we dismiss McArdle's application for leave to appeal.

_Josh Mason leave to appeal_

43 On behalf of Josh Mason it is contended that the sentences for the drugs offences were manifestly
excessive for the following reasons:

a. The assessment of his culpability was too high. He was playing a limited role under direction and he
should not have been put into the category of playing a significant role; or if put in that bracket he should
have been treated at the bottom end of the range which is 6½ years.

b. Insufficient credit was given for his rehabilitation, remorse and personal mitigation.

c. His previous conviction for supply should not have been taken as a serious aggravating factor because
he was 15 when first involved in drug dealing and would have been treated as a victim of modern slavery
had the legislation then been in place


-----

d. In relation to the slavery offence for which he was being sentenced, the Judge ought to have
categorised his involvement as culpability Category C not B. The Judge did not draw any distinction
between him and James Mason when applying the uplift for the **_Modern Slavery Act offences which he_**
should have done given that James Mason had pleaded to both offences and Josh Mason had only
pleaded to the slavery offence.

e. Finally, it was submitted, there was an unfair disparity between the sentence imposed on Josh Mason
and that imposed on a co-accused, Gary Kelly.

44 We find no merit in any of these grounds. The Judge was well placed to assess Josh Mason's
culpability, having prepared for three trials, and conducted one trial in respect of three of the individuals
who were involved in the operation. Josh Mason acted as a courier, travelling with his wife to lend an
appearance of lawfulness, on 30 occasions over the whole indictment period, involving the transfer of a
large quantity of drugs and the transfer of a large quantity of cash. It is clear to us that he played a
significant operational role with an awareness of the scale of the operation. The starting point of 8 years
was entirely appropriate.  Reducing it to 7½ years to reflect the balance between aggravating and
mitigating features involved no error. Initially, the submission was made that the previous conviction
should not have been taken into account because he was only 15 when it was committed. It is clear from
the material that that was not so. The antecedents showed that it was committed in 2017 when he was 19,
and the contents of the pre-sentence report confirmed that although he was 15 when he first became in
drugs he was not saying that that was when the conviction took place. It was submitted that when he was
first involved, he was a minor who was trafficked into offending and that he was a victim of **_modern_**
**_slavery. Again, there is no basis for that submission. It is clear from what was said to the author of the_**
pre-sentence report that his initial involvement when he was 15 simply involved the opportunity to become
involved in return for payment, which he voluntarily and willingly accepted. That offence was, therefore, a
significant aggravating factor.

45 The Judge was also fully entitled to treat Josh Mason's culpability for the slavery offence as Category B
and involving a significant role. This was a conspiracy offence in which he bore responsibility for the
treatment of the victims by others, quite apart from the extent of his own involvement. He was a knowing
member of an organised crime group which he was aware forced minors into the operation through fear of
violence. His basis of plea that he only became aware of it at some unidentified point after it started means
that he fell to be sentenced on the basis that he was aware of the position for the greater part, if not the
entirety, of the 18 months during which it operated. He was aware of the exploitation and the forced labour
involved, and he did nothing to discourage or distance himself from it. That was part and parcel of the
criminal operation in which he chose to play a significant role.

46 As to the disparity argument, Gary Kelly played a quite different role and there is no unfair disparity with
his sentence, which was one of two years' imprisonment suspended for two years. The Judge said that
Kelly was on the edge of the county line operation, acting as a driver on 12 occasions in quite a short
period to carry others from Liverpool to Oswestry; and that Kelly had no contact with the drugs, no contact
with the dealers, and no contact with the users. There was no suggestion that Kelly was aware of the
scale of the operation, even for the short period when driving, let alone for the substantial indictment period
during which Josh Mason played an important operational part. Kelly had no previous convictions for
drugs offences, and was not convicted of any offending in relation to a Modern Slavery Act offence. He
also had strong personal mitigation. His position was quite different from that of Josh Mason.

_The Attorney-General's Reference_

47 Mr Jarvis, who appeared before us for the Solicitor-General, but not for the prosecution below, does not
criticise the Judge for the sentences he reached for the drugs offences had they been committed alone.
Nor does he make any criticism of the Judge's approach to the sentencing exercise seeking to apply the
totality guideline by assessing what sentences would be appropriate separately for the drugs offences on
the one hand, and the Modern Slavery Act offences on the other, and then seeking to give effect to them
by imposing a sentence on the drugs offences to which the **_Modern Slavery Act sentences would run_**
concurrently His submission was simply that the uplift of 12 months for the Modern Slavery Act


-----

offences should have been much longer, and failed to take sufficient account of the gravity of that
offending.

48 His submissions recognise that the Definitive Guideline for drugs offences lists as a statutory
aggravating factor that the defendant: "used or permitted a person under 18 to deliver a controlled drug to
a third person", and so, to an extent, the Definitive Guideline already takes into account the possibility of a
defendant using children as runners. However, he submits, the offences in the **_Modern Slavery Act_**
(including when in their inchoate forms as in this case) involve more than just the use of children to commit
crime. What matters, Mr Jarvis submitted, is not just the fact that children and young people have been
used to supply drugs, but the circumstances in which that happened. Some children and young people
may be paid for their services as runners, and paid well, but others – like the runners in this case – fall into
a different category. Their labour was not provided willingly, and for profit, but under compulsion. That, he
submitted, is a serious form of criminality distinct from their simple involvement in drug dealing, and had to
be met with a significant upward adjustment to the overall sentence.

49 On behalf of James and Josh Mason it was submitted that the Judge took into account all the relevant
features, and that an uplift of 12 months was appropriate, and did not involve reaching a sentence which
was lenient; alternatively, that if it was lenient, it was not unduly so.

_Analysis and conclusions_

[50 R v Mohammed (Zakaria) [2019] EWCA Crim 1881 concerned offences of conspiracy to supply drugs,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5XMW-H6Y3-CGXG-02KG-00000-00&context=1519360)
for which the appellant was sentenced to a total of six years' imprisonment, and offences of conspiracy to
commit offences of trafficking under section 2 of the Modern Slavery Act, for which he was sentenced to a
consecutive period of eight years.  His appeal against the individual sentences failed, and his appeal
against the 14 year total, on the grounds of totality, was allowed only to the extent of a reduction of two
years to reflect the appellant's youth, good record and personal background.  In that case three children
were used, aged 14 and 15, having been taken from Birmingham and transported to accommodation of
poor quality in Lincoln as the base from which they supplied the drugs pursuant to a county lines operation.

51 William Davis J (as he then was), giving the judgment of the court, referred to three previous decisions
of this court, namely: Attorney-General's Reference No.2 of 2013 [2013] Cr App Rep (S) 71; R v Connors

_[[2013] EWCA Crim 1165; and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:58X2-N631-F0JY-C3J3-00000-00&context=1519360)_ _R v Zielinski [2017] EWCA Crim 758. All involved vulnerable adults. He_
emphasised that offending which involved exposing 14 and 15 year old children to the trade in Class A
drugs put them in danger. At [37] he said this:

"First, where the other person whose travel is arranged with a view to exploitation is a child, then the
offence inevitably will be more serious than a case where the person is an adult. Second, where the
exploitation of itself involves the commission of serious criminal offences, the exploitation offence will be
especially grave. Third, the number of children whose travel is facilitated or arranged will be of importance.
Fourth, the offence will be aggravated if the same child is the subject of travel with a view to exploitation
more than once. We note that all of those features are present on the facts of this case."

That was said in the context of offences under section 2 of the Modern Slavery Act, but in our view they
apply equally to offences of compulsion and slavery under section 1 of the Act. We note that the first three
of those factors are present in the operation of the Boris Line.

52 In R v Nixon & Ismail _[[2021] EWCA Crim 575, this court increased the sentence imposed on Nixon on a](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62M0-V7S3-CGXG-03NS-00000-00&context=1519360)_
reference by the Attorney-General. Nixon was involved in a county line drugs operation from London to
Devon supplying heroin and crack cocaine. That involved arranging for four boys to be transported from
London to the south west to act as runners, the youngest being 15. The sentencing Judge treated the drug
dealing on its own as attracting a sentence of 5 years, reduced by one-third to 3 years 4 months for guilty
pleas, and the trafficking offences on their own as warranting 5 years after a trial, reduced by 10 per cent
for a late plea to 4 ½ years. The Judge took account of totality in imposing a total sentence of 7 years.
This court took the view that the individual sentences were too short and that individually the drugs
offences warranted 4 years (after discount for plea) and the trafficking offences 7 years (after discount for


-----

plea). That would have made a total of 11 years. The court determined that the total sentences for the
offences should be increased to a total of 10 years.

53 In this case we have little hesitation in saying that the seriousness of the Modern Slavery Act offences
required a significantly greater uplift than 12 months. Many of the children were particularly vulnerable for
the reasons we have described. They were controlled by fear of serious violence and forced unwillingly to
work in this trade. They were not merely encouraged or enticed to do so, but forcibly exploited by
compulsion. That had particularly serious consequences in a number of ways. It enabled the operators of
the line to run the county lines business remotely.  County lines drug dealing is a scourge of modern
society, with all the misery it inflicts, and any criminality which facilitates it is for that reason alone serious.
But, more importantly, the effect on the young victims of the Modern Slavery Act offences themselves was
also very serious.  They were encouraged to become drug users so as to become embroiled in a way
which made it difficult to remove themselves from the trade. They were put in fear of violence from the
county line operation itself, violence whose seriousness is can be gauged from the Lizzie West assault of
which they were no doubt all aware. They were put in danger, moreover, of violence from others in the
drugs and gang world in which they were forced to work. They were isolated from the efforts of social
services and other services to promote their welfare. They were put at serious risk of becoming
entrenched in that world, even after this operation ceased, in a way from which they might find it difficult to
escape.  This is all serious enough if it happens to adults, but it is particularly so when it involves
vulnerable children and young people, as young as 14 and 15. The number of children involved in this
case is also a seriously aggravating feature. The sentences of 5½ years and 4½ years respectively, which
were imposed for those offences taken alone, were certainly no less than was merited for the seriousness
of this offending and were if anything lenient. To uplift the drugs sentences by only 12 months did not
adequately reflect the seriousness of this aspect of the offending.

54 In the case of James Mason we consider that an uplift of at least four years was required, taking
account of totality. In the case of Josh Mason an uplift of at least three years was required. When added
to the sentences which the drugs offences alone would have attracted, 6 years for James Mason and 5
years for Josh Mason, this would have resulted in a total sentence for James Mason of 10 years, and for
Josh Mason one of 8 years. The sentences of 7 years and 6 years respectively were not merely lenient
but unduly so.

55 Accordingly we grant leave to the Solicitor-General. We quash the sentences on the drugs offences on
each of Counts 3 and 4 for Josh Mason and Offences 1 and 2 for James Mason.  In James Mason's case
we increase the sentence on each of those counts to one of 10 years' imprisonment. In Josh Mason's
case we increase the sentence on each of those counts to one of 8 years' imprisonment. The other
sentences are undisturbed, and the sentences will remain running concurrently to each other.

______________

**CERTIFICATE        Opus 2 International Limited hereby certifies that the above is an**
accurate and complete record of the Judgment or part thereof.Transcribed by Opus 2 International LimitedOfficial
_Court Reporters and Audio Transcribers5 New Street Square, London, EC4A 3BFTel: 020 7831 5627   Fax:_
**_020 7831 7737CACD.ACO@opus2.digitalThis transcript has been approved by the Judge._**

**CERTIFICATE**

Opus 2 International Limited hereby certifies that the above is an accurate and complete record of the
Judgment or part thereof.

_Transcribed by Opus 2 International Limited_

_Official Court Reporters and Audio Transcribers_

**_5 New Street Square, London, EC4A 3BF_** **_Tel: 020 7831 5627_**
**_Fax: 020 7831 7737_**


-----

**_CACD.ACO@opus2.digital_**

This transcript has been approved by the Judge.

**End of Document**


-----

