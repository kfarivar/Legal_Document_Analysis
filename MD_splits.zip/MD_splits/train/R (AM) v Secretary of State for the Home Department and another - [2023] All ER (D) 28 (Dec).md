# R (AM) v Secretary of State for the Home Department and another [2023] All
 ER (D) 28 (Dec)

[2023] EWHC 3034 (Admin)

King's Bench Division, Administrative Court (London)

Mr Justice Lane

1 December 2023

**IMMIGRATION – ASYLUM SEEKERS – ASYLUM**
Abstract

_The Administrative Court, determining a challenge in respect of the claimant's claim for back payments of trafficking_
_support under the Modern Slavery Victim Care Contract, held that the difference of treatment between child victims_
_of trafficking and adult victims of trafficking in the relevant statutory provisions had not been unlawful, however the_
_first defendant Secretary of State and second defendant local authority were liable to the claimant for the specific_
_manner in which they dealt with the claimant who had entered the country as a child victim of human trafficking and_
_was subsequently dealt with as an adult victim of human trafficking as he attained majority._
Digest

The judgment is available at: [2023] EWHC 3034 (Admin)

**Background**

The claimant arrived in the United Kingdom when he was 16 and claimed asylum. He was screened by the first
defendant Secretary of State and identified as a victim of child trafficking. He was referred to the National Referral
Mechanism and placed in the care of the second defendant local authority. The Secretary of State agreed to make
back payments of trafficking support under the Modern Slavery Victim Care Contract (“MSVCC”) between certain
dates, but refused to do so for an earlier period on the basis that the claimant was a child and did not accordingly
fall within the MSVCC, but that his needs as a child victim of trafficking for that earlier period fell to be met by the
local authority. The local authority's case however was that it had not known that the claimant was a child victim of
trafficking until shortly before his eightieth birthday and, in any event, there was nothing to show that its care for the
claimant would have been any different then he actually received. As against the Secretary of State, the claimant
submitted that there was an unlawful difference in the way in which the Secretary of State's responsibilities under
the **_[Modern Slavery Act 2015 (MSA 2015) were discharged in relation to adult victims of trafficking and child](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
victims of trafficking in breach of Arts 12 and/or 13 of the Council of Europe Convention on Action Against
Trafficking in Human Beings (“the Trafficking Convention”) and/or Art 4 of the European Convention on Human
Rights (“ECHR”). The claimant further challenged the Secretary of State's view that a person in the National
Referral Mechanism had to consent to continue in it after they became an adult. In regard to the local authority, the
claimant contended that it was aware that he was a child victim of trafficking and entitled to trafficking-related
support, but did not conduct any assessment of those needs in breach of Arts 12 and /or 13 of the Trafficking
Convention and Art 4 of the ECHR. Further, it was alleged that the local authority breached its duties under the
_[Children Act 1989 (ChA 1989).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)_

**Issues and decisions**


-----

(1) Whether the Secretary of State had breach their duties towards the claimant.

It was plain from the opening words of Art 12 of the Trafficking Convention that States were being given a broad
discretion regarding the adoption of such legislation or other measures as were necessary to assist victims. It was
up to the State concerned to determine what measures were to be adopted. Likewise, it was open to that State to
decide, if a measure was to be adopted, how it was to be done in practice. That included what emanation of the
State was to be chosen for the task. Furthermore, it was plain that, even where the State decided that a measure
needed to be undertaken by one of its organs, that organ did not have to be the same, as regards all categories of
victims. The claimant's case failed because of his impermissible attempt to infer from Art 12 of the Trafficking
Convention an obligation of consistency as between different categories of persons. The general system of asylum
support payments to adults calculated at a level to avoid destitution was in no way analogous to the specific
individualised obligations owed to a looked after child such as the claimant. Further, the claimant had been unable
to show that any needs which a child victim of trafficking had as a result of trafficking were not needs that a local
[authority did not have a legal obligation to address pursuant to ChA 1989 and related legislation. However, whilst](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y1GT-00000-00&context=1519360)
the Secretary of State was entitled to take the view that a person who had entered the National Referral Mechanism
as a child had to consent to continue in it as an adult, and the Secretary of State was entitled to address the issue
of consent in respect of children in the National Referral Mechanism as they approach majority, the Secretary of
State chose to do so by means of a system that the claimant decided to opt out and communicated that to the
Secretary of State. Therefore, the claim succeeded to that extent (see [173], [174], [176], [183], [188], [207], [216],

[217] of the judgment).

_EOG v Secretary of State for the Home Department (AIRE Centre intervening); KTT v Secretary of State for the_
_Home Department [2022] 3 WLR 353 considered_

_Wilson v First County Trust Ltd [2004] 1 AC 816 considered_

_R (on the application of O and the child's mother and litigation friend Ms PO) v Lambeth London Borough Council_

_[2016] EWHC 937 (Admin) considered_

_MD and another v Secretary of State for the Home Department [2022] PTSR 1182 considered_

_R (on the application of EM) v Secretary of State for the Home Department [2018] 1 WLR 4386 considered_

_R (on the application of A) v Secretary of State for the Home Department_ _[2021] UKSC 37 considered_

_R (on the application of O and the child's mother and litigation friend Ms PO) v Lambeth London Borough Council_

_[2016] EWHC 937 (Admin) considered_

(2) Whether the local authority had breached its duties to the claimant.

There was speculation in the instant case and the local authority's case was speculative in nature. It was not
appropriate to require the court to engage in such an exercise. Therefore, the local authority had not shown that it
was highly likely that the outcome for the claimant would not have been substantially different if the conduct
complained of had not occurred. Accordingly, the claim against the local authority succeeded (see [235], [236] of
the judgment

Shu Shin Luh and Ms Grace Capel (instructed by Leigh Day Solicitors) for the claimant.

Jack Anderson (instructed by The Government Legal Department) for the first defendant.

Hilton Harrop-Griffiths (instructed by LB Barnet) for the second defendant.

**E d** **f D** **t**


-----

