# Re JR96 and another [2019] NIQB 97

QUEEN'S BENCH DIVISION

KEEGAN J

27 NOVEMBER 201927 NOVEMBER 2019

**Immigration — Leave to remain — Settlement Scheme — Greek national challenging failure of Secretary of**
**State (“SSHD”) to issue BRP card or other physical photographic identity card certifying right to indefinite**
**leave to remain — Applicant being vulnerable adult deemed medically unfit to take up employment for**
**several years — Actions of Secretary of State based on Settlement Scheme transitioning to policy of digital**
**only information — Whether Secretary of State erring in exercise of discretion — Whether actions of Home**
**Secretary unlawful — Whether actions of Home Secretary unreasonable or irrational**

**KEEGAN J:**

**_Introduction_**

**[1] The Applicant in this case is a Greek national aged 33 years who challenges the failure of the Secretary of**
State for the Home Department (“SSHD”) to provide him with hard copy evidence of his settled status within the
United Kingdom (Indefinite leave to Remain) under the SSHD's recently introduced EU Settlement Scheme.
Anonymity has been granted to the Applicant on the basis of established mental health difficulties.

**[2] The Amended Ord 53 Statement now seeks the following relief at para 4(1):**

a An Order of Certiorari to quash the impugned decisions made on 10 May 2019 and on 22 May 2019 by which the
Home Secretary refused to issue a BRP card or some other form of physical photographic identification to the
Applicant to show proof of his immigration status as a person conferred with indefinite leave to remain in the United
Kingdom (settled status under the EU Settlement Scheme).

b A declaration that the decisions of the Home Secretary are unlawful, unreasonable and irrational.

c A declaration that the EU Settlement Scheme provisions at Appendix EU of the Immigration Rules are
incompatible with arts 8 and 16 of the European Convention on Human Rights as they fail to require the United
Kingdom Home Secretary to issue a photographic BRP card or some form of physical identity document for EU
citizens with a right to indefinite leave to remain in the United Kingdom.

d An order of mandamus requiring the SSHD to remake her decisions in accordance with law.

e Costs.

**[3] At para 5 of the Ord 53 Statement the Applicant's grounds of challenge are expressed as follows:**

**_(i) Illegality_**

The Applicant contends that the impugned decisions are unlawful.


-----

**_(ii) Inconsistency_**

The Applicant contends that in refusing to issue a BRP card or some other physical photographic identity card
certifying the Applicant's right to indefinite leave to remain in the United Kingdom the proposed respondent acted in

a manner which is inconsistent with the approach adopted for non‑EU nationals who are conferred with some form

of immigration status or indefinite leave to remain in the United Kingdom (and who are issued with a BRP card).

**_(iii) Material_** **_Considerations_**

The Applicant further contends that the impugned decisions are vitiated by the proposed respondent having failed
to take into account certain material fact considerations - in particular, that the Applicant suffers from significant
mental health challenges, namely schizophrenic disorder, his condition may impact on his personal capacity to
effectively show proof of his right to reside in the United Kingdom. In the event of failure of the online Home Office
Digital System due to the absence of hard copy proof of identity, the Applicant will be significantly disadvantaged as
he has not been able to show proof of his lawful status to any public authority or body/agency in the United
Kingdom.

**[4] The impugned decision in this case is contained in a letter of 10 May 2019. This is a positive letter for the**
Applicant in that he is informed by it that his application to the EU Settlement Scheme has been successful and that
he has been granted indefinite leave in the United Kingdom under Appendix EU to the Immigration Rules. The letter
explains that this is also referred to as “settled status.”

**[5] By way of explanation this letter also reads:**

“As you now have settled status there is no time limit on how long you can stay in the United Kingdom. Your
settled status gives you the right to stay in the UK under UK Immigration Law. At the same time, you can also
apply to rely on any rights you have as an EEA or Swiss citizen or family member of an EEA or Swiss citizen
under EU law for as long as it remains in force in the United Kingdom.”

The next part of the letter is entitled “On-line evidence of your status” and reads:

“This letter is not proof of your status in the UK. Your status is linked to the passport or national identity card
that was used to apply for the scheme. You can view your on-line status at any time with this service. In line
with existing requirements, you may be required to prove your status in order to demonstrate your right to work,
or to access benefits and services, for example to prospective employers and landlords, the National Health
Service (“NHS”) other government departments and local authorities. As well as being able to use valid
residence documentation or a passport or national identity card to evidence your rights for as long as EU law
remains in force in the UK, you can also use the Home Office on-line checking service to prove your rights in

the UK under the UK's Immigration Rules. You will be able to use the on‑line checking service to show your

right to work to an employer by letting them view your status on-line. In due course, you will also be able to use
it to show a landlord your right to rent. Employers and landlords must already check your right to work or rent in
the UK, but this service will let them check your rights on-line. To maintain access to your on-line status and
keep your status up to date, you will need to tell us if you change your email address or mobile phone number.
If you renew or replace the identity document you used in your application, or you changed your name after
making your application, you will need to tell us so that your immigration status is up to date. To access your
on-line status, you will need the document number you used to make your application – therefore please make
a note of your document number for future reference. The letter provides various links to the relevant
websites.”

**[6] The Applicant had previously applied for a document certifying permanent residence to confirm that he is a**
European Economic Area (“EEA”) or Swiss national who has exercised treaty rights in the UK for a continuous
period of five years. By letter of 30 December 2018 that application was refused. The reason for that refusal is
based upon the Applicant's inability to work since 17 July 2013 as a result of an illness or accident and so it was
deemed as follows –


-----

“you have not provided evidence that immediately prior to your incapacity you were a worker or a selfemployed person;

you have not demonstrated that you have resided in the United Kingdom continuously for more than two years
prior to your incapacity;

you have not provided evidence that the incapacity is the result of an accident at work or an occupational
disease that entitles you to a pension payable in full or in part by an institution in the United Kingdom.”

**[7] During the course of the hearing it was confirmed that no appeal has been pursued from this decision given that**
the Applicant cannot satisfy the requirements as he has been unavailable for work due to mental health difficulties.

**[8] Ms Fionnuala Connolly BL appeared on behalf of the Applicant in this hearing and Mr Philip Henry BL appeared**
on behalf of the proposed respondent. I am grateful to both Counsel for their oral submissions which have assisted
me greatly in deciding this matter.

**_Evidence_** **_of_** **_the Applicant_**

**[9] The first affidavit is provided by Mr James Strawbridge who is the Applicant's solicitor. It is dated 9 August**
2019. This affidavit was filed by solicitors as at the time the Applicant had left the jurisdiction for a family holiday in
Greece. The affidavit sets out some background facts as follows.

**[10] The Applicant is a Greek national. He has resided in Northern Ireland for over nine years and currently lives**
with his mother and brother who are also Greek nationals. He holds a Greek passport. The Applicant is a vulnerable
adult who has been medically unfit to take up employment for a number of years. He has longstanding mental
health difficulties and is under the care of mental health services in Northern Ireland as he suffers from
schizoaffective disorder. In this regard Mr Strawbridge refers to two medical reports which are exhibited to the
affidavit from the Applicant's general practitioner and treating consultant.

**[11] Mr Strawbridge avers that on 30 April 2019 the Applicant instructed him to make an on-line application for**
settled status as an EEA National under the UK's new EU Settlement Scheme. This scheme went live on 30 March
2019. On 10 May 2019 confirmation was received that the Applicant was successful. The Applicant's passport was
returned to him as a result of this. The affidavit then refers to the decision making letter.

**[12] Paragraph 15 of the affidavit summarises the Applicant's concerns about the impugned decisions, namely**
that:

i The Applicant would have difficulty proving status to public authorities in the United Kingdom.

ii The Applicant is deeply concerned about travel into the UK following the UK's departure from the EU.

iii The Applicant is concerned about proving status due to his mental health difficulties and management of the online service.

**[13] The Applicant filed his own affidavit of 25 October 2019 in which he confirms the contents of Mr Strawbridge's**
affidavit. He also says at para 5 of his affidavit that:

“The essence of my case is that I do not feel it is appropriate, fair or practical to rely solely upon accessing an
on-line portal to verify my immigration status for entry to the UK or engagement with other UK service
providers.”

**[14] The Applicant further states that he is aware that under the UK Immigration Rules, non-EU nationals who have**
leave to remain in the United Kingdom or indefinite leave to remain or settled status are conferred with photographic
identity documents issued by the proposed respondent and known Biometric Residence Permits (“BRP”). He also
refers to EU nationals who acquired indefinite leave to remain under the 2016 EEA Regulations and he avers that in
those cases:


-----

“It is my understanding that in fact the proposed respondent issued small blue dockets containing photographic
evidence of the person and their status.”

**[15] In support of this proposition the Applicant refers to an affidavit of Ms Inga Bulatovaite, who is a Lithuanian**
national, who acquired settled status under the 2016 EEA Regulations and who exhibits a copy of her small blue
document to an affidavit she has filed dated 25 October 2019.

**[16] In his affidavit the Applicant also describes the on-line portal. He states that he has accessed the portal and it**
produces one page containing his photograph. This is exhibited. This document confirms that the Applicant has
settled status. In his affidavit the Applicant confirms that access to the portal is dependent upon an account and
password. He also states that he would have concerns about his ability to recall details particularly when he feels
under pressure and stressed. The affidavit then goes on to reference some difficulties the Applicant had with an
application for Universal Credit. However, that matter appears to have been resolved by virtue of the
correspondence of 25 October 2019 that was provided during the hearing.

**[17] In addition, Mr Strawbridge filed a further affidavit of evidence of 31 October 2019.**

**_Documentation_** **_provided_** **_by_** **_the_** **_proposed_** **_respondent_**

**[18] The proposed respondent has filed a helpful bundle of documents in this case in response to the Case**
Management Direction order of 3 September 2019. This includes the Immigration Rules Appendix EU which sets
out the scheme for settled status. Also, within the bundle is also a Policy Equality Statement (“PES”) which sets out
an analysis of the equality issues in relation to the policy proposals for providing evidence of status in a digital form
to EU citizens currently resident in the UK under the EU Exit Settlement Scheme until the end of the implementation
period. This document includes consideration of disability.

**[19] Also included in this bundle of documentation are two letters from Baroness Kennedy of the Shaws who is**
Chairman of the EU Justice Sub-Committee of the House of Lords. She wrote to the Home Secretary, the Right
Honourable Sajid Javid MP on 22 January 2019 and 27 February 2019. Within that correspondence reference is
made to the position of vulnerable people. Two responses have been provided in the documentation from the Home
Secretary dated 20 March 2019 and 17 April 2019. Of particular significance is the Home Secretary's response
regarding digitalisation which I paraphrase as follows:

“The digital status given to successful applicants will be a secure and permanent record held by the Home
Office that is accessible to the holder at any time and which cannot be lost or stolen. Users will also be able to
allow third parties such as employers or landlords to have time limited access to relevant information. With this
on-line service we can ensure that employers, landlords and others who are required to check a person's
immigration status see only the information that is relevant to their need. A physical document or endorsement
provides none of these benefits and causes problems when it is lost, stolen, damaged, expired or in the
process of being renewed.

A digital status provides space for a more comprehensive explanation of the individual's rights and status, as
compared to the limited characters that can fit on to a small card. It is also much easier for visually impaired
and dyslexic users who may have difficulty reading a physical document. As I have said previously, I
understand that this represents a cultural change, but this new digital capability forms part of moving the UK's
immigration system to digital by default and is a simpler, safer and more convenient system. We will of course
be keeping this under review to see how it works in practice.”

**[20] The House of Commons Home Affairs Committee EU Settlement Scheme 15th Report of Session 2017 –**
2019 is also contained within the documentation along with the House of Commons Home Affairs Committee EU
Settlement Scheme government's response to the Committee's 15th Report of Session 2017-2019. Both of these
documents refer to digitalisation of the system.


-----

**[21] Of particular moment for this case is para 15 of the Government Response report to the Home Affairs**
Committee entitled “digital status” which reads as follows (the first paragraph is a recommendation, the remainder
the government response):

“15. We also recommend that the Government provide all citizens who successfully apply to the Settlement
Scheme with hard copy confirmation of their status. This need not replace the digital system but would
complement it. The Government cannot suddenly impose a 'digital first'—indeed, 'digital only'—system upon
people without giving them, employers and landlords time to adapt. People can have the best of both worlds: a
more secure and forward-thinking digital system in parallel with the more familiar and reassuring hard copy. We
would hope to see new applicants being routinely provided with physical certification of their Settlement
Scheme status by the end of the year, with documents provided retrospectively to those who have already
completed the process. (Paragraph 72)

We welcome the Committee's recognition that the digital status system the Government is introducing is more
secure and forward-looking. We agree that it would be wrong for the Government to suddenly impose a digital
first or digital only system without giving people, including employers, landlords and other service providers,
time to adapt. That is why we have been clear that EEA and Swiss citizens can continue to use their passport
or national identity card to evidence their status in the UK until the new border and immigration system is
introduced in 2021, and that there is no requirement for EEA and Swiss citizens to start using their digital status
under the EU Settlement Scheme to evidence their entitlements until then either.

This provides a significant period of transition during which EEA and Swiss citizens can choose to use their
digital status if they wish. We know from usage of the online right to work service that many of those who have
been granted status under the EU Settlement Scheme are already using their digital status to prove their right
to work. And our research with users indicates that many wish to use other online services to prove their rights
across a range of circumstances as these services are developed.

Feedback so far on the digital status service has been positive. Users find it simple and easy to use. The
service has been designed to be widely accessible and the great majority of users will not require any
assistance accessing or using their status. 95 per cent of adults aged 16–74 years in the UK in 2018 were
recent internet users, the third highest in the EU. However, we recognise there will be a small minority who do
not find it as easy to use. That is why we have a call centre that can assist digital status holders to use the
service.

The Government can assure the Committee that successful applicants will continue to receive written notice of
their immigration status, by email or letter, which is an official document intended for individuals to keep.
However, due to the possibility of fraud and abuse, this document cannot be used to evidence an individual's
immigration status to external organisations. Instead, starting from 2021, they will increasingly be required to
use the digital status service to do this, or have this information made available on their behalf through system
to system checks.

Immigration decisions and the rights and conditions that flow from those decisions have been recorded digitally
by the Home Office since the turn of the century, but physical documents, whether a stamp in a passport, a
letter or more recently a biometric residence card or permit, have historically been issued to enable individuals
to evidence their status and entitlements to others when required. These physical documents have evolved
over time to address security weaknesses, but the risk of forgery and counterfeiting still exists, and any
physical document may be lost or stolen or become out of date very quickly.

In addition, there are circumstances in which an individual's status document can be controlled by another
person – for example, in cases of domestic violence, **_modern slavery and human trafficking. Moving to a_**
digital status is a step forward in tackling those who seek to control others. A digital status is also easier to use
for visually impaired users, who may have difficulty reading a physical document.

Since 2018, it has been increasingly possible for individuals to view the digital record of their immigration status
held by the Home Office This online status service which is being used for the EU Settlement Scheme


-----

enables individuals to keep their information up-to-date and share it in real time, helping to minimise any delay
in accessing services. It also promotes the principles of data minimisation by sharing only the information
required for the check, rather than all the information held on a physical document.

Non-EEA citizens granted status under other immigration routes can already prove their right to work digitally
via the Employee Checking Service, and since this service went live in April 2018 there have been over 40,000
employer profile views. A similar service to enable right to rent checks is in private test phase and will be
launched later this year.

We are introducing all these services well in advance of moving to a fully digital environment, allowing us to
develop and improve the digital status service based on feedback, and to embed the concept of digital status
amongst users.

The Government fully appreciates the cultural change this represents for many EEA citizens. Many Member
States not only require an identity document to be held at all times, but some also enforce compulsory
identification checks, for example by police officers. The UK does not have these requirements, nor are they
part of our culture. The Government believes that the UK's methods of proving identity and rights do not have
to mirror what other Member States may choose to do, but should reflect the wider direction of travel in the use
of digital services and the advantages for users these bring over paper documents and cards.

We are committed to learning from what works to continue improving our offer. In response to feedback on the
EU Settlement Scheme and the digital status service, we are working on enhanced communications for users.
We are also monitoring all the different real world uses of digital status and will use this to inform future design
and communications. It is important to stress that immigration status is not something that has to be used
frequently, and we are committed to delivering an approach that enables users to demonstrate their status and
access the services they are eligible for in the simplest and most secure way possible. Where those services
are provided by government, for example health and benefits, it is right that individuals should only need to
present their identity, for government to confirm their eligibility.”

**_Conclusion_**

**[22] The EU Settlement Scheme was promulgated in line with the draft withdrawal agreement to safeguard rights**
of EU citizens and family members in the United Kingdom and ensure reciprocal arrangements for when the UK
leaves the EU. The Applicant has of course benefitted from this scheme by achieving settled status. The issue in
this case is a practical one. The Applicant effectively asserts that reliance on a digital system is not advantageous
to him. Ms Connolly has presented a very structured argument on the Applicant's behalf. She points out that this is
an important issue affecting many persons. She stresses that the Applicant is a vulnerable person who is anxious
about his status being recognised and that he may have difficulties in managing the digital system. She therefore
says that the policy of digital only information is unlawful and in breach of the art 8 rights of the Applicant.

**[23] As against these arguments Mr Henry asserts that there is no real evidence of detriment in this case. He**
points out that the Applicant has travelled without difficulty. He has also accessed health benefits without difficulty.
Mr Henry states that the one area in relation to Universal Credit has worked in the Applicant's favour and that the
evidence shows that the Applicant was able to access on-line that system of adjudication. Mr Henry points to the
fact that this challenge relates to an administrative policy which is itself under review. He also contends that art 8 is
not engaged and if engaged any interference is justified. Finally, Mr Henry suggested that an alternative remedy
was open to the Applicant by way of applying for an EEA card.

**[24] During the course of submissions I was told that the scheme was going well and that there had been 2.4**
million applicants to date with 1.9 million applications granted and that it was estimated there would be 3.7 million
applications in total. I have now received the EU Settlement Scheme Statistics dated 14 November 2019 which
refers to the fact that more than half a million applications were received in the month of October 2019 (590,300)
and overall the total number of applications received up to 31 October 2019 was more than 2.4 million (2,450,500). I
was also told that feedback from the NHS has been positive to date.


-----

**[25] This is an application for leave to apply for judicial review. It is clear that all of the material upon which the**
parties wish to rely was before this court. In those circumstances I must decide whether there is “the demonstration
of an arguable case with a reasonable prospect of success” see paras [5] and [43] of Omagh District Council v The
_Minister with Responsibility for Health, Social Services and Public Safety [2004] NICA._

**[26] The context of the case is important. The EU Settlement Scheme has come about in the wake of the Brexit for**
the benefit of EU citizens in the UK. The scheme itself is not under challenge in this case which is unsurprising
given the benefit it has conferred upon this applicant and many others. Rather, this challenge relates to how the
scheme is being administered by the government. This is in the realm of policy with which the court should be slow
to interfere. It is also clear that this is a scheme in transition and as the government response states “we are
introducing all these services well in advance of moving to a fully digital environment, allowing us to develop and
improve the digital status service based on feedback, and to embed the concept of digital status amongst users.”

**[27] I agree with Ms Connolly that the Applicant does not have an alternative remedy to apply for an EEA card due**
to his work history but that is not determinative in this case. I appreciate that the Applicant has some vulnerabilities
however he has been able to manage an on-line application for Universal Credit. He has also been able to print off
his settled status documentation. The Applicant has not encountered any difficulties with travelling. On these facts I
cannot see that art 8 of the European Convention on Human Rights is engaged at all and if it were any interference
is justified to allow for the system to function. There was no argument of any substance made in relation to other
Convention provisions.

**[28] In any event, the issue of how vulnerable people engage with the system has been highlighted both by**
Baroness Kennedy and the Home Affairs Committee in the House of Commons. There is therefore no question of a
material consideration being left out of account. I note that various supports and services have been put in place for
those with difficulties in accessing the digital system. It is also clear that this issue is on the agenda going forward
and that this is an evolving process.

**[28] Mr Henry correctly makes the point that the non EEA nationals who have the benefit of a BRP are subject to a**
different process. At present an EEA passport gives an automatic right of entry into the United Kingdom. The real
issue here may be an anxiety that travel may become more difficult for those with settled status in the future. This is
a matter which will be subject to ongoing review and as such any challenge is premature.

**[29] Having considered all of the evidence and the comprehensive arguments made to me I do not consider that**
the Applicant has established an arguable case with a reasonable prospect of success on the facts of this case at
this time. The digitalisation policy is new, in transition, and subject to review. This is all well within the discretion of
the Home Secretary and as such his actions cannot be characterised as unlawful, unreasonable or irrational.

**[30] I conclude by saying that if there are difficulties going forward they can be highlighted in the political arena to**
make sure that all persons who can benefit from the scheme are advantaged in the same way. The issues may
change but as of now the application for judicial review will be dismissed.

Judgment accordingly.

**End of Document**


-----

