# R (on the application of MS) v Secretary of State for the Home Department

 [2017] EWHC 2797 (Admin)

Queen's Bench Division, Administrative Court (London)

Martin Griffiths QC sitting as a deputy judge of the High Court

10 November 2017Judgment

**Ms Leonie Hirst (instructed by Deighton Pierce Glynn) for the Claimant**

**Ms Hafsah Masood (instructed by the Government Legal Department) for the Defendant**

Hearing dates: 31 October, 1 November 2017

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

By order dated 10 November 2017 no report of this case shall directly or indirectly identify the Claimant. The
judgment has been prepared so that it may be published without contravention of that order. There is liberty to
apply to the Court for the anonymity order to be recalled (upon notice in writing to the parties and to the Court) at an
inter partes hearing (to be convened following receipt of any such notice).

**Martin Griffiths QC:**

1. This is an application for judicial review brought with permission of Nicola Davies J. The three decisions
which are challenged are:
(1)  The Defendant's decision on 26 January 2017, with supplementary reasons given on 6 July 2017, to
certify under Regulation 24AA of the Immigration (European Economic Area) Regulations 2006 that the
Claimant's deportation to Poland would not be in breach of the European Convention on Human Rights.
There is no challenge before me to the decision to deport itself, which was made on the same day, but an
appeal against that was lodged on 14 June 2017 and has not yet been heard by the First Tier Tribunal. The
effect of the certification was that the Claimant could be deported before resolution of any appeal.

(2)  The Claimant's detention from 15 February 2017 to date.

(3)  The Defendant's refusal and failure on and after 27 March 2017 to provide the Defendant with a bail
address under section 4 of the Immigration Act 1999. The Defendant refused to provide such
accommodation in a decision on 27 March 2017. Since 9 August 2017, it has agreed in principle to provide
such accommodation, on a “purely pragmatic” basis, but at the time of the hearing before me last week, it
had not so far succeeded in doing so.

**Background facts**

2.  The Claimant was born in Poland on 3 December 1977 (now 39 years old) and is a Polish national.

3.  Between July 2002 (when he was 23) and December 2014 he was convicted of various criminal
offences in Poland. These included burglary convictions in 2005, 2007, and 2008; theft convictions in 2012
and 2013; convictions for reporting false danger on two occasions in 2014 (resulting in a sentence of 10


-----

months imprisonment for the first offence and a suspended sentence of 1 year 6 months for the second)
and further burglary convictions on 13 February 2014 (for which he was sentenced to 1 year in prison,
suspended for 5 years) and 17 March 2014 (for which he was sentenced to 1 year in prison suspended for
3 years and a supervision order). According to his witness statement, he had a drink problem in Poland,
which continues.

4.  On or about 23 November 2015 the Claimant accepted an offer of work and accommodation in the UK
and was taken across Europe and placed in a house in Birmingham with other men and put to work at a
recycling plant and, subsequently, on night shifts at a car parts manufacturer. He was controlled by men
who took most of his wages and threatened him when he complained. In May 2016, the Claimant escaped,
and found a squat to live in. Through his attendance at a soup kitchen, the Claimant found his way to the
Hope for Justice charity on 2 June 2016.

5.  On 20 July 2016 a positive conclusive grounds decision was made recognising him as a victim of
human trafficking. Earlier, in March or April 2016, the police told him that his traffickers had been caught
and charged and there was expected to be a trial in 2018.

6.  On 2 August 2016, a Court in Poland activated a previously suspended sentence of 1 year. The
Claimant had not kept in touch with the friend whose address he had given the probation service and it
seems that it was the Claimant's loss of contact with his probation service which led to the activation of his
suspended prison sentence. It is not disputed that, upon his deportation to Poland, he will be incarcerated
for, presumably, the one year term of his activated prison sentence.

7.  Between June 2016 and February 2017, when he was detained by the Home Office, the Claimant lived
in safe house accommodation provided to him because of his status as a trafficked person. This was
funded by the Home Office.

8.  Because the challenged decisions of the Home Secretary were based partly on concerns about the
Claimant's behaviour, as well as his criminal convictions in Poland, I will say something about his
behaviour in the safe house accommodation.

9.  The Claimant entered safe house accommodation (funded by the Home Office but provided by City
Hearts and run by the Salvation Army) in June 2016. He was transferred to accommodation elsewhere
provided by a registered not for profit Community Interest Company (which I will call the Safe House
Society) in October 2016. Concerns about his drinking surface in the Salvation Army records on 1 July
2016 and the Claimant was warned. On 8 September 2016 he was thought to have been drinking again
(which he denied) and three neighbours complained about the noise he was making in the early morning.
He was given a written warning. On 15 September there was another alcohol related difficulty, and he had
a disagreement with a new arrival at the house over communal facilities. In October, he was moved
following a violent incident which it is not suggested he was responsible for. On 13 October he was drunk
and missed a support session. On 17 October it was noted that he had been drinking heavily all weekend
and missed a GP appointment. His support worker spoke to him and he admitted an alcohol problem,
which was addressed with him in the following weeks. On 4 November he was noted as “very intoxicated”
but on other occasions he appeared well. He tended to turn off his phone, or not to answer it, which
created difficulties for his support worker. On 8 December 2016 there was a complaint that he was
collecting cigarette ends from the street and drying them out in the communal microwave. On 12
December, he was “slightly intoxicated”. He missed three appointments with his Salvation Army worker to
open a bank account, the last one on 21 December, but he was sober when seen on 22 December. On 3
January and 4 January he was intoxicated again, and “heavily intoxicated” on 6 January; he had also
smoked some drugs. On 16 January he was intoxicated and admitted being under the influence of another
substance. The drugs mentioned elsewhere in the papers are marijuana and spice. The Salvation Army
worker told him he could not come into the office in that condition. There are other notes of intoxication on
23 and 24 January 2017.

10.  On 10 January 2017, the Home Office spoke to a woman at the Safe House Society, and was told
that the Claimant's behaviour “has become worse he is drinking very heavily and becoming very
aggressive ” On 23 January 2017 the same Home Office worker was told by the same person at the Safe


-----

House Society that the Claimant “is an alcoholic and is making threats to members of staff and other
people residing in the safe house which has resulted in her calling the police.” On 25 January 2017, the
Home Office referred to having been told by the Safe House Society “he is alcoholic and violent and never
sober”. On 31 January 2017, an internal Home Office email said “I understand and appreciate that he
would pose a risk to the public if he became street homeless, but we are also concerned for the safety of
staff at the Safe House who have to deal with him and other residents.”

11.  On 27 January, Salvation Army records show the Claimant asked to see a doctor about his drink
problem; meanwhile, notes of his intoxication continue into February and there was a complaint about him
playing music during the night. There are notes of him ringing the police and ambulances and then
disappearing; and, on 6, 7 and 8 February, notes of him smoking drugs, “excessive drinking and substance
misuse”.

12.  On 8 February, the Safe House Society emailed the Home Office saying:

“He is drinking alcohol excessively now, he attends the office in a loud, drunken state, he is continually
stating that he is ill and needs an ambulance, then when he calls for an ambulance he is taken to hospital
but then walks out without seeing a doctor. He is also regularly smoking drugs and yesterday whilst out on
an appointment with his support worker at a GP surgery he openly lit up a cigarette containing cannabis
therefore the appointment had to be cancelled.”

13.  A Salvation Army note on 13 February 2017 includes the following note from the Home Office
(possibly from within their Modern Slavery Unit): “We are very concerned about his behaviour and for the
safety of staff and other residents in the safe house so have advised our immigration colleagues that they
need to take urgent steps to detain him elsewhere; we have been clear to them that this will be the final
extension as there is no other basis for allowing him to remain in the safe house.”

14.  An email from the Safe House Society to the Home Office on 6 July 2017, well after the Claimant's
stay at their accommodation had ended on 15 February, said “During his time at our accommodation the
client was dependent on alcohol and this would sometimes impact on his engagement of appointments,
seeking employment etc.” It said that, after he had been served with his Notice of Liability to Deportation
(on 30 December 2016), his “consumption of alcohol increased and it became difficult to engage with him.”

**The first challenged decision: certification under Regulation 24AA**

15.  The first challenged decision is dated 26 January 2017. This was the date of the Defendant's decision
to deport the Claimant (which is now before the First Tier Tribunal) and of the decision which accompanied
it to certify under Regulation 24AA of the Immigration (European Economic Area) Regulations 2006 (“the
Regulations”) that the Claimant's deportation to Poland would not be in breach of the European Convention
on Human Rights, so that he could be deported without waiting for the outcome of any challenge to the
deportation.

16.  Before the decision itself, a formal deportation warning was drawn up dated 29 December 2016 and
the Claimant was served with it and signed for it on 30 December. The reason given justifying deportation
was “As a result of your criminality your deportation is considered to be justified on grounds of public policy
and/or public security”. The burglary conviction on 17 March 2014 and activation of his suspended
sentence on 2 August 2016 were cited.

17.  The Claimant was asked to respond, but there is no document on the Home Office files in which he
did so. There is, however, a Home Office email dated 10 January 2017, which notes “He responded to the
Stage 1 letter by providing only evidence of the Modern slavery no evidence of him working, his residence
or family life in the UK.” A later email of 23 January 2017 refers to a letter sent to the Home Office through
the Safe House Society “from the NCA dated 6 June 2016 but nothing has been recorded since.” 6 June
2016 was the date of a letter from the National Crimes Agency to the Claimant stating that it had concluded
that “there are reasonable grounds to believe that you have been a victim of **_modern slavery (human_**
trafficking)”.


-----

18.  The challenged decision followed, in a decision letter dated 26 January 2017. The letter first stated
that the Claimant would be deported to Poland, on the basis that the Secretary of State was “satisfied that
you would pose a genuine, present and sufficiently serious threat to the interests of public policy if you
were to be allowed to remain in the United Kingdom and that your deportation is justified under Regulation
21 [of the Immigration (European Economic Area) Regulations 2006]. You have raised no grounds as to
why you should not be deported.” It cited his Polish criminal convictions, and the activation of his one year
suspended sentence. The deportation, as I have mentioned, is subject to a pending appeal now awaiting a
hearing in the First Tier Tribunal.

19.  The same letter then notified the Claimant of the challenged decision to certify that Claimant's
removal would not be unlawful under section 6 of the Human Rights Act 1998, pursuant to Regulation
24AA of the Regulations. This decision was briefly expressed, in the following terms:
“The Secretary of State has considered whether there would be a real risk of serious irreversible harm if
you were to be removed pending the outcome of any appeal you may bring. The Secretary of State does
not consider that such a risk exists because you have provided no grounds for believing that such a risk
exists. Therefore it has been decided to certify your case under regulation 24AA.”

20.  This decision, in applying only a serious irreversible harm test, failed to address the question posed
by Regulation 24AA itself, which was whether, quoting Regulation 24AA(2):

“...despite the appeals process not having been begun or not having been finally determined, removal of

[the Claimant] to the country or territory to which [the Claimant] is proposed to be removed, pending the
outcome of [the Claimant's] appeal, would not be unlawful under section 6 of the Human Rights Act 1998
(public authority not to act contrary to Human Rights Convention).”

21.  The “serious irreversible harm” wording comes from Regulation 24AA(3) which states:
“The grounds upon which the Secretary of State may certify a removal under paragraph (2) include (in
particular) that P would not, before the appeal is finally determined, face a real risk of serious irreversible
harm if removed to the country or territory to which P is proposed to be removed.”

However, that does not replace the primary question, which is the Human Rights Act question. The
Secretary of State did not address that question.

22.  The Defendant submits that this failure was not material, because no Human Rights Act claim had
been made and it is not obvious what Human Rights Act claim might have been anticipated at that stage.
The Claimant in argument before me has raised Article 4 of the European Convention on Human Rights
(which Counsel paraphrases as “positive obligations towards a victim of trafficking”) and Article 8 (which
Counsel paraphrases as “private life and the proportionality of removal”). However, the Defendant's
obligations towards the Claimant as a victim of trafficking had, on the face of it, been discharged by his
extensive accommodation and support in the safe house, and no complaint had been made about that.
There was no evidence that the Claimant had any formed family or other ties in the United Kingdom,
having been trafficked, and then accommodated in the safe house.

23.  Nevertheless, I accept that whether Human Rights Acts claims might be made, and whether any such
rights had been breached, should have been considered as an essential part of the Regulation 24AA
decision, and the letter did not do that.

24.  Supplemental reasons for the decision to deport were provided on 6 July 2017. These do consider
possible Human Rights Act claims, in an extensive passage between paragraphs 48-96 of the letter of 6
July 2017.

25.  Moreover, in making her decision, the Secretary of State was bound to follow her own policy: _R_
_(Lumba) v Secretary of State for the Home Department_ _[2011] UKSC 12 [2012] 1 AC 245at paragraph 35._
Her published policy guidance on _Regulation 24AA of the Immigration (European Economic Area)_
_Regulations 2006 was at the material time dated 9 May 2016 (“the Regulation 24AA Guidance”). This_
stated:

-----

“The fact that it has been decided in an individual case that removal would not breach the ECHR does not
mean that the case owner can be satisfied that removal for a limited period pending the outcome of any
appeal would not breach that person's human rights. They are separate considerations. When considering
whether removal pending the outcome of any appeal would breach the ECHR, case owners should assess
the question on the basis that the person's appeal will succeed and consider whether serious irreversible
harm or a breach of ECHR rights would be caused by that temporary removal from the UK.”

26.  The critical fact here is that the Secretary of State already knew that the Claimant's prison sentence
had been activated and that, therefore, he would be incarcerated for a year if he was deported to Poland,
even on an interim basis. The position was analogous to extradition cases in respect of which the
Regulation 24AA Guidance said:

“Extradition cases are not normally suitable for certification on the grounds that the person will be unable to
return for their hearing and may be unable to conduct their case from abroad while in custody.”

27.  Although not an extradition case, the Claimant's Regulation 24AA removal as an EEA citizen was
subject to Article 31(4) of the Citizens Directive (Directive 2004/38/EC) which, subject to exceptions which
do not apply to the Claimant's case, gave him an absolute right to submit his deportation appeal in person.
It seems to me fanciful to suggest that the Claimant could conduct his appeal effectively from abroad, in
prison. On the policy assumption that he would pursue an appeal, the Claimant should not have been
certified for removal in circumstances where he would be incarcerated in Poland before he could submit his
appeal and have it heard. To deport him before then would be to cause him serious irreversible harm. To
do so was a breach of the policy, Wednesbury unreasonable, and unlawful.

28.  An email disclosed by the Home Office very late (after the oral hearing before me had concluded),
dated 7 August 2017, supports the conclusion I have reached in this respect. It says:
“Although his decision was certified, it soon came to light that [Mr S] was wanted in Poland to serve an
outstanding prison sentence there. As such, to enforce the certification would breach his Article 6 rights as
he would not be able to return to the UK to be present at his appeal. He will therefore need to remain in the
UK until his appeal rights are exhausted.”

The activation of the Claimant's prison sentence did not come to light after the decision to certify. It was
referred to in the letter containing the decision to certify.

29.  A removal date was set for 21 April 2017 but this was deferred on 20 April, after the Claimant had
given notice of his proposed judicial review claim. Another removal date of 25 June was set, but this was
also cancelled, on 20 June 2017, by which time the Claimant had lodged his appeal against the deportation
decision.

30.  On 21 June 2017, the Defendant confirmed that no further action would be taken to deport the
Claimant pending his deportation appeal.

31.  The letter of 6 July 2017, providing more extensive reasons for the deportation decision, referred to
the original decision to certify under Regulation 24AA and did not formally withdraw it. However, it
maintained the concession that he would not be deported on an interim basis, as follows:

“It is noted that you have lodged an out of time appeal which has been accepted by the Asylum and
Immigration Tribunal. Although we certified the decision to deport you under Regulation 24AA, we informed
your representative in our letter dated 21 June 2017 that we will not enforce the certificate. You will be
permitted to remain in the UK pending the outcome of the appeal.”

32.  The hearing before the First Tier Tribunal was listed for 18 September and again on 13 October but,
unfortunately, the transport to take the Claimant from detention to the hearings did not materialise on either
occasion, for which the Home Office is responsible through its contractors, and no new date for the hearing
has yet been set.


-----

33.  The certificate has not been withdrawn, but it is not being implemented until the appeal has been
determined. It has not had any practical effect because the Claimant has not been removed and will not
now be removed until his appeal against deportation has been determined.

34.  In view of my finding that the decision under Regulation 24AA on 26 January 2017 was unlawful in
the particular circumstances of the Claimant's case, it is not necessary for me to address other arguments
in support of that conclusion.

**The second challenge: the Claimant's detention**

35.  On 15 February 2017 the Claimant was arrested at his Safe House Society safe house. He has been
in detention since then. The decision to keep him in detention from that date is the subject of the second
challenge before me.

_History of the Claimant's detention_

36.  The history of the Claimant's detention since his arrest on 15 February 2017 to date is as follows.

37.  On 18 May 2017, solicitors for the Claimant sent a pre-action protocol letter challenging the failure to
grant discretionary leave to remain and the decision to detain the Claimant, and alleging interference with
his EU right to remain in the UK.

38.  A Home Office note on 19 May 2017 referred to the letter. The note said the removal directions set
for 25 May 2017 should be deferred, discussed possible discretionary leave to remain, and noted “Urgent
consideration needs to be given to releasing Mr S in the meantime which is going to be looked at by the
detention case owner and operational managers.”

39.  On 25 May 2017, the Home Office notified the Claimant's solicitors by email that they were in the
process of submitting a release referral but sought from the solicitors a proposed release address. From
this point, the question of the Claimant's detention and the question of his accommodation on release,
were discussed together.

40.  In a letter dated 30 May 2017 the Home Office said it was “happy to put up a release referral for your
client” but that “The onus is on your client to obtain a suitable release address; this would also apply if your
client was applying for immigration bail. Please supply us with a suitable release address for your client.”

41.  The Claimant's solicitors replied on 12 June 2017 saying: “We expect the Home Office to arrange
appropriate and suitable accommodation and support for our client in accordance with Article 12 ECAT and
Article 11 EU Anti-Trafficking Directive...”

42.  The Claimant's appeal against deportation was launched, out of time, on 14 June 2017 and admitted
by the First Tier Tribunal on 20 June 2017. On the same day, 20 June 2017, the Home Office notified the
Claimant's solicitors by email that the removal direction for 25 June 2017 had been cancelled.

43.  On 21 June 2017 the Home Office wrote to the Claimant's solicitors, principally on the matter of
discretionary leave to remain. It rejected the allegation that he had been given inadequate accommodation
and support as a victim of trafficking, saying that he had been given support in safe house accommodation
during his 45 day reflection period (which began in June 2016) and he had been given extended support
after that, until 15 February 2017, “so he received significantly more extra support than most other victims
of trafficking.” After affirming the decision to deport, it concluded:

“It is noted that an out of time appeal lodged by your client has been accepted by the Asylum and
Immigration Tribunal. Although we certified the decision to deport your client under regulation 24AA, we will
not enforce the certificate. He will be permitted to remain in the UK pending the outcome of the appeal.

**Accommodation**

You have requested we release your client and return him to the safe house provider. We have made
enquiries with the Modern Slavery Unit who are responsible for the victim care contract with the Salvation
Army. As your client has had his recovery and reflection period and has left the NRM [i.e. the trafficking


-----

and modern slavery National Referral Mechanism], he is not eligible for government funded support and
accommodation.”

44.  The present judicial review proceedings were launched with an out of time Claim Form on 19 July
2017; Andrews J allowed an extension of time on 21 July 2017; and permission was granted by Nicola
Davies J on 24 August 2017. The hearing before me has been expedited.

45.  On 9 August 2017 the Home Office approved a release referral, and decided that section 4
accommodation should be provided. The Home Office says that this decision was “purely pragmatic”, the
section 4 accommodation to be provided “exceptionally” (quoting evidence from Mr Daniel Dyer), since the
Claimant is an EEA national whom the Home Office does not recognise as having Convention rights or EU
Treaties rights which would in the ordinary case be required for the exercise of its section 4 powers.

46.  However, the efforts to source such accommodation described in Mr Dyer's witness statement did not
for some time succeed in placing the Claimant and he remained in detention at the time of the hearing
before me last week. Within a few days of the hearing, however, a section 4 address was found for him
and he was released on Tuesday 7 November into that accommodation.

_Justification for detention_

47.  The reasons for detention in the Notice to Detainee dated 27 January 2017 are likelihood of
absconding and release not being conducive to the public good, based on the Claimant's “unacceptable
character, conduct or associations”. These are, however, just ticked boxes. A fuller explanation was
provided on the same date in a Minute of a Decision to Detain a Person Under Immigration Powers. This
assesses risk of absconding, risks of re-offending, and risks of harm, all as medium; and cites his criminal
history and sentences in Poland. At a couple of points, Romania rather than Poland is referred to, but I do
not regard that as significant because the offences and sentences are otherwise all correctly described.
There is reference to him being alcohol dependent and “potentially addicted to other illegal substances”,
said to be spice. “He has refused any support from Healthcare. He is being funded for his addiction from
the money he receives from the Salvation Army.” Under the heading “assessment of re-offending”, specific
reference is made to his previous convictions again, and then this passage:
“The offences are mainly theft related. [Mr S] is alcohol dependant and is relying on funds provided by the
Salvation Army to fund his addition [sc. addiction]. There is no evidence to show that he has ever had
stable employment in the UK therefore, it is likely that the potential exists for him to commit further offences
of this nature in the future in order to support himself financially and to continue to fund his [addiction].”

Under the heading “Assessment of risk of harm to the public” there is further reference to the previous
convictions, followed by this:
“The circumstances surrounding these offences are unknown however his convictions indicates an antisocial attitude towards the public and community... There is no evidence to show that he has addressed
his offending behaviour. [Mr S] is alcohol dependant and has refused any support from Healthcare. He
therefore remains a risk of harm to the public. It is likely that the potential exists for him to commit further
offences of this nature in the future in order to support himself financially and fund his [addiction].”

The final “Recommendation” section concludes as follows:
“Alcohol is the main concern, he is alcohol dependent and has refused any support from Healthcare. In the
light of all known circumstances, it is considered that release carries a risk of harm to the public and risk of
re-offending. The risk is considered to outweigh the presumption in favour of release.

I propose that [Mr S] should be detained as a short-term measure pending the deportation decision being
served on him and removal directions being set.”

48.  I agree that there was a risk of offending given the circumstances identified in the Minute, and this
material was not limited to the previous convictions but included the Claimant's behaviour in the safe
house, his alcohol problem, his consumption of illegal drugs and the lack of support available to him after
he left the safe house. He had to leave the safe house even if he was not detained, because the period of


-----

prescribed support (45 days) had long since expired, and the Safe House Society were not prepared to
keep him any longer.

49.  The risk of absconding is not so clear. I bear in mind the observations of Dyson LJ in _R (on the_
_application of I) v Secretary of State for the Home Department_ _[2002] EWCA Civ 888 at paragraphs 53-56._
The Claimant being of no fixed abode, with no family or other ties or other ongoing connections, meant that
it would be difficult to find him in order to deport him. At the point when he was served with the deportation
order, the Secretary of State was under no obligation to provide him with bail accommodation and suitable
accommodation has, in any event, proved difficult to find over the last few months (an aspect that I
consider in more detail below, in relation to the third challenge). The Claimant had a history of missed
appointments and not responding to mobile telephone calls. The real risk that he would vanish, so that
removal directions could not be executed, together with the also (in my judgment) moderate risk of
offending, could justify detention for a period of time, but not an excessively long period. The risk was not a
risk of absconding properly so-called, because that suggests a deliberate evasion, and there was no
evidence that the Claimant would deliberately run away from deportation. However, it is the outcome and
not the motive of a deportee who cannot be found which can be a relevant circumstance when considering
short-term detention before deportation. I note that Simon Brown LJ in _R (on the application of I) v_
_Secretary of State for the Home Department_ _[2002] EWCA Civ 888 at paragraphs 27-29 talks about the_
deportee “going to ground”. There is no magic in the word 'abscond'. It is not in a statutory test. The risk
that a person will vanish so that removal directions cannot be executed, even if not in a deliberate attempt
to evade deportation, is a factor that may be present in some cases to a degree that could justify detention
for a limited period.

50.  I am not saying that every homeless person is liable to detention pending deportation. It must depend
on the facts of the particular case, and detention is always the exception and not the rule. Nor does the risk
that the person cannot be located justify detention for an indefinite period, any more than the risk of
absconding properly so-called does (see _R (on the application of I) v Secretary of State for the Home_
_Department_ _[2002] EWCA Civ 888 per Dyson LJ at paragraphs 53 and 56)._

51.  The Claimant, as a trafficked person, was an adult at risk within the meaning of the Defendant's
policy, but there was no evidence that he would be (or has been) particularly vulnerable to detention. That
is borne out by the Detention Review of 15 February 2017 (the day of detention).

52.  The first basis of challenge to the detention is that the decision to deport was unlawful and the
Regulation 24AA certification was unlawful, and hence the power to detain cannot have been lawfully
exercised. I reject those submissions. Whether the deportation was unlawful is not for me to decide; it is a
matter for the First Tier Tribunal and I will leave it to them. I have found that the Regulation 24AA
certification was unlawful, but the decision to detain was based on the substantive decision to deport,
rather than the certificate under Regulation 24AA (the Minute of Decision to Detain dated 27 January 2017
refers to “A signed deportation order” on p 1 and states “[Mr S] is the subject of a signed deportation order”
on p 2).

53.  The second basis of challenge is that “there was no prospect of his removal” (Grounds, paragraph
63). The Secretary of State's discretionary power to detain an EEA national pending deportation is
conferred by Regulation 24(3) of the Regulations, which imports into such cases the procedures in
Schedule 3 of the Immigration Act 1971. These include paragraph 2(3) of Schedule 3, which provides:
“Where a deportation order is in force against any person, he may be detained under the authority of the
Secretary of State pending his removal or departure from the United Kingdom...”

54.  This power is subject to the well-established principles in Hardial Singh (see R v Governor of Durham
_Prison ex parte Hardial Singh [1984] 1 WLR 704, 706) summarised in_ _R (on the application of I) v_
_Secretary of State for the Home Department_ _[2002] EWCA Civ 888 [2003] INLR 196 per Dyson LJ at_
paragraph 46 as follows:
“(i) The Secretary of State must intend to deport the person and can only use the power to detain for that
purpose.


-----

(ii)  The deportee may only be detained for a period that is reasonable in all the circumstances.

(iii)  If, before the expiry of the reasonable period, it becomes apparent that the Secretary of State will not
be able to effect deportation within that reasonable period, he should not seek to exercise the power of
detention.

(iv)  The Secretary of State should act with the reasonable diligence and expedition to effect removal.”

55.  In my judgment, there was at first a reasonable prospect of removal before the period of detention
became unreasonable in all the circumstances. The Claimant had not responded to the deportation
warning letter served on him on 30 December 2016 with any reasons why he should not be deported. The
time limit for his appeal was 14 days after service of the deportation notice which seems to have taken
place on 15 February 2017; no appeal was lodged in that 14 day period. There was no challenge to the
decision to deport until an out of time appeal on 14 June 2017 which was admitted by the First Tier
Tribunal on 20 June 2017. The Claimant sent an unsealed judicial review application to the Home Office on
19 April 2017 which, as well as never being issued, seemed to lack substance, for reasons set out in a
Home Office response dated 19 April 2017. (The grounds of the present judicial review applications, issued
out of time on 19 July 2017, are quite different to those in the unsealed application.)

56.  The first indication of a substantial challenge to the deportation order was the pre-action protocol
letter dated 18 May 2017 and within a week the Home Office was agreeing to release, subject to resolution
of the question of accommodation. Thereafter, no application to the First Tier Tribunal was made until it
was out of time, on 14 June 2017, although it was admitted by the First Tier Tribunal on 20 June 2017.

57.  By then, the Claimant had been detained for over 4 months. It might have been hoped to expedite the
hearing, and so bring the matter to a conclusion within what might still have been a reasonable period in all
the circumstances. But on 27 June it was recognised that the First Tier Tribunal's Case Management
Review hearing could not be expedited, and the first available date for a hearing would probably be 6 - 8
weeks after that. From that point, I consider that it was apparent that the Secretary of State would not be
able to effect deportation within a reasonable period from the start of the detention in February.

58.  This did not mean that it was unreasonable not to release the Defendant immediately on 27 June.
The Home Office was entitled and perhaps even bound to take stock of the Claimant's particular
circumstances, including his lack of accommodation or support outside detention, and consider how best to
manage any release. But only a relatively short time could be justified for that purpose. In my judgment, it
became unreasonable to detain him on Hardial Singh principles by Friday 14 July 2017 at the latest.

59.  It has been suggested that the Claimant also had an in-country appeal under section 82(1)(b) of the
Nationality, Immigration and Asylum Act 2002. I do not agree. Section 82(1)(b) applies when the Secretary
of State “has decided to refuse a human rights claim made by [a person]”. In this case, the Secretary of
State's decision to detain was made when the Claimant had made no human rights claim, and there had
been no decision to refuse any human rights claim he had made.

60.  A further basis of challenge is that decision to detain was contrary to the Defendant's published
policies. These included the Defendant's _Chapter 55 Enforcement Instructions and Guidance (“Chapter_
55”) and her Adults at risk in immigration detention policy, dated 6 December 2016 (“the AAR Policy”).

61.  I do not think there was any failure to follow Chapter 55, although I have been referred, particularly, to
paragraphs 55.1.3; 55.3.1; and 55.8. So far at the AAR Policy is concerned, it is clear that the Claimant
was an adult at risk within the meaning of that policy, because he had been trafficked, but the evidence
does not suggest that, by the time he was detained in February 2017, which was 8 months after an
extended period of support in safe houses, he had vulnerabilities other than his alcohol and drug use, both
of which were considered and factored in to his detention reviews, and could be managed in detention.
Although there is a presumption against detention of a trafficked adult at risk, the AAR Policy allows for
detention if the immigration factors outweighed the risk factors such as to displace the presumption that
individuals at risk should not be detained. In my judgment, this balancing exercise did, on the facts of the
Claimant's case, permit his detention for a short time with a view to deportation. It did not make his
detention unlawful prior to the date of Friday 14 July 2017 which I have arrived at above


-----

**The third challenge: failure to provide bail accommodation**

62.  On 22 February 2017 the Claimant applied for bail accommodation under section 4(1)(b) of the
Immigration and Asylum Act 1999 (“the 1999 Act”). This was refused on 27 March 2017. That refusal, and
the continuing failure to provide such accommodation, was the subject of the third and final challenge
before me.

63.  Section 4(1) of the 1999 Act provides:
“The Secretary of State may provide, or arrange for the provision of, facilities for the accommodation of
persons - ... (b) released from detention...”

64.  It is to be noted that use of the word “may” means that this confers a discretionary power, and does
not impose an absolute duty.

65.  The Claimant, as an EEA national, was not eligible for section 4 accommodation unless he was
within paragraph 3 of Schedule 3 to the 1999 Act, which provides that the exclusion:
“...does not prevent the exercise of a power or the performance of a duty if, and to the extent that, its
exercise or performance is necessary for the purpose of avoiding a breach of 
(a) a person's Convention rights;

(b) a person's rights under the Community Treaties.”

66.  The application for section 4 accommodation was made on 22 February 2017 on a form provided by
the Home Office. It did not identify any Convention or Community rights that were engaged, but the form
did not specifically prompt for this. The application was rejected on 27 March 2017 on that basis that “you
have not demonstrated that there would be any breach of ECHR if support were to be withheld by the
Secretary of State”. The Home Office response went on, however, to consider and reject a possible Article
3 claim (the right not to be subjected to torture or to inhumane or degrading treatment or punishment). It
did so by reference to the Claimant's right to work in the UK (which was wrong, because his deportation
decision dated 26 January 2017 had specifically warned him that he was “not allowed to work in the UK”
and “not entitled to claim benefits”); the possibility of a return to Poland (he faced incarceration there, which
would deprive him of his right to submit his deportation appeal in person, as discussed above, but by this
date the time for lodging an appeal against the deportation decision had expired, and the Claimant had not
yet lodged an out of time appeal); and the possibility of moving elsewhere in the EU to work (although
there is no evidence that he would be better able to fend for himself there than in the UK).

67.  I do not consider the faults in the reasoning of that decision to be material at the time it was made
because no bail accommodation was available, it proved difficult to find when efforts to seek it were, later,
made; and the Claimant was being lawfully detained at this point, as I have found to be the case until 14
July 2017.

68.  On 4 May 2017, the Claimant completed an application to be released on bail, which was never
submitted to the Home Office and therefore could not be considered by them. This did not include an
application for bail accommodation. On the contrary, it said “I have a job waiting as well as friends and
accommodation in the UK”. However, this is not relevant, both because the Home Office did not see it, and
because it does not appear to have been true.

69.  The pre-action protocol letter dated 18 May 2017 did not apply for bail accommodation or refer to
section 4, although it did suggest “release... back to a suitable safe house”. It appears from the Home
Office response dated 30 May 2017 that, in a subsequent telephone conversation, the Claimant's
representatives suggested the Claimant “could return to the safe house where he was residing prior to
being detained”. This turned out not to be possible. The Home Office letter concluded “The onus is on your
client to obtain a suitable release address; this would also apply if your client was applying for immigration
bail.” It agreed to release if such an address were to be provided.

70.  On 12 June 2017, the Claimant's solicitors wrote the letter quoted above, saying “We expect the
Home Office to arrange appropriate and suitable accommodation and support for our client in accordance


-----

with Article 12 ECAT and Article 11 EU Anti-Trafficking Directive so that he can properly recover from his
exploitation...” On 21 June 2017, the Home Office confirmed, having made enquiries with the **_Modern_**
**_Slavery Unit, and in response to the request for accommodation pursuant to the anti-trafficking Treaty and_**
Directive, “As your client has had his recovery and reflection period and has left the NRM, he is not eligible
for further government funded support and accommodation”. I reject the challenge to the decision to refuse
accommodation made before me on the basis that it is a breach of the anti-trafficking measures. The
Claimant had been given sufficient support to satisfy the obligations in those measures before he was
detained in February 2017, beginning in June 2016. He had support over a longer period than most
trafficked individuals are provided with in the UK.

71.  The next reference to a claim for section 4 accommodation is in the judicial review application dated
19 July 2017. This points to the refusal of 27 March, and the “second application of May 2017” which was
never, as I have found, presented.

72.   On 9 August, as I have mentioned, the Home Office agreed to provide section 4 bail
accommodation, but without conceding that it was under any obligation to do so. A witness statement from
Mr Dyer of the Home Office explained what steps had been taken to identify and provide this
accommodation, none of which had by the time of the hearing before me last week been successful.
Lincolnshire County Council assessed the Claimant at an interview on 14 August 2017, but refused to
[provide accommodation, having concluded that he was not eligible for services under the Care Act 2014.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-W431-DYCN-C3MY-00000-00&context=1519360)
The National Offender Management Service was asked to identify suitable accommodation on 4 August;
but the places they found fell through, due to errors in paperwork or contractual disputes for which the
Claimant was not responsible. G4S required information which the Defendant did not feel able, for data
protection reasons, to provide, although that has now been resolved.

73.  On 13 September 2017, the Defendant agreed to release the Claimant on to the street. This was
successfully objected to by his representative, who threatened an injunction and asserted the Defendant's
“responsibility to find accommodation for my client”.

74.   Efforts to source section 4 accommodation continued, but it was only during the weekend after the
hearing concluded before me on 1 November that suitable accommodation was identified, and the
Claimant was released into it on Tuesday 7 November 2018. That does not, of course, remove the
Claimant's challenge to the Defendant's refusal and, upon a change of mind, failure to provide it sooner.

75.  Since any rights the Claimant may have under section 4 require identification of a Convention or
Treaty claim, reliance has been placed before me on Articles 3, 5 and 8 of the European Convention on
Human Rights. Article 8 is the right to respect for private and family life. No infringement of this has been
shown; since the Claimant has no family or other relationships or private life in the UK which have been
threatened by the Defendant. Article 5 is the right to liberty and security of person, and I have decided that
the Claimant was not entitled to be released from detention before 14 July.

76.  Article 3 is the right not to be subject to inhuman or degrading treatment. There is no evidence that
the Claimant's treatment in detention has in any way been inhuman or degrading, or that it amounts to
torture or punishment. But there is a question about whether his Article 3 rights would be breached if he
were to be released on to the streets as a homeless person with no means of support and no
accommodation.

77.  In R (Limbuela) v Secretary of State for the Home Department [2006] 1 AC 396, late asylum seekers
refused support under section 55 of the Nationality, Immigration and Asylum Act 2002 succeeded in their
claim for judicial review by reference to Article 3 of the Convention. Lord Bingham's judgment, at
paragraphs 6-9, included the following:
“6. Article 3 of the European Convention prohibits member states from subjecting persons within their
jurisdiction to torture or inhuman or degrading treatment or punishment. Since these appeals do not
concern torture or punishment, the focus is on inhuman and degrading treatment. Does the regime
imposed on late applicants amount to “treatment” within the meaning of article 3? I think it plain that it does.
Section 55(1) prohibits the Secretary of State from providing or arranging for the provision of


-----

accommodation and even the barest necessities of life for such an applicant. But the applicant may not
work to earn the wherewithal to support himself, since section 8 of the Asylum and Immigration Act 1996,
[the Immigration (Restrictions on Employment) Order 1996 (SI 1996/3225) and standard conditions](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW8-2S80-TX08-C1FG-00000-00&context=1519360)
included in the applicant's notice of temporary admission (breach of which may lead to his detention or
prosecution) combine to prevent his undertaking any work, paid or unpaid, without permission, which is not
given unless his application has been the subject of consideration for 12 months or more...

“7. May such treatment be inhuman or degrading? Section 55(5)(a) assumes that it may, and that
assumption is plainly correct. In _Pretty v United Kingdom (2002) 35 EHRR 1, the European court was_
addressing a case far removed on its facts from the present, but it took the opportunity in para 52 of its
judgment... to describe the general nature of treatment falling, otherwise than as torture or punishment,
within article 3. That description is in close accord with the meaning one would naturally ascribe to the
expression. Treatment is inhuman or degrading if, to a seriously detrimental extent, it denies the most
basic needs of any human being. As in all article 3 cases, the treatment, to be proscribed, must achieve a
minimum standard of severity, and I would accept that in a context such as this, not involving the deliberate
infliction of pain or suffering, the threshold is a high one. A general public duty to house the homeless or
provide for the destitute cannot be spelled out of article 3. But I have no doubt that the threshold may be
crossed if a late applicant with no means and no alternative sources of support, unable to support himself,
is, by the deliberate action of the state, denied shelter, food or the most basic necessities of life. It is not
necessary that treatment, to engage article 3, should merit the description used, in an immigration context,
by Shakespeare and others in Sir Thomas More when they referred to “your mountainish inhumanity”.

8. When does the Secretary of State's duty under section 55(5)(a) arise? The answer must in my opinion
be: when it appears on a fair and objective assessment of all relevant facts and circumstances that an
individual applicant faces an imminent prospect of serious suffering caused or materially aggravated by
denial of shelter, food or the most basic necessities of life. Many factors may affect that judgment, including
age, gender, mental and physical health and condition, any facilities or sources of support available to the
applicant, the weather and time of year and the period for which the applicant has already suffered or is
likely to continue to suffer privation.

9. It is not in my opinion possible to formulate any simple test applicable in all cases. But if there were
persuasive evidence that a late applicant was obliged to sleep in the street, save perhaps for a short and
foreseeably finite period, or was seriously hungry, or unable to satisfy the most basic requirements of
hygiene, the threshold would, in the ordinary way, be crossed.”

78.  In _Razai and Others v Secretary of State for the Home Department_ _[2010] EWHC 3151 (Admin),_
Nicol J observed at paragraph 24 that section 4(1) “confers a _power on the SSHD to provide_
accommodation, not a duty” (emphasis in the original). He noted (at paragraph 26) a concession by
Counsel for the Secretary of State “that there was a duty on the SSHD to use reasonable endeavours to
provide a bail address if the person concerned would otherwise be likely to remain in detention.” That
concession was not made before me, and Counsel for the Secretary of State before me argued against it.

79.  I do not think that detention could be justified simply on the basis that release would place the
Claimant on the streets. If it is unacceptable to place the Claimant on the streets, he should be provided
with bail accommodation. Detention is not a proper substitute for such accommodation once detention
cannot otherwise be justified. Detention could not be justified either, of course, if it is acceptable to place
the Claimant on the streets.

80.  Nicol J also said this (at paragraph 25 of Razai):
“...Mr Armstrong on the Claimants' behalf submitted that the SSHD was under a duty to use reasonable
endeavours to provide accommodation when application for such accommodation is made. He relies on a
trilogy of cases concerning s.117 of the Mental Health Act 1983. This gives health authorities a duty to
provide aftercare services for those patients who have been discharged from compulsory detention under
s.3 of the 1983 Act. The first of these cases, R v Camden and Islington Health Authority ex parte K _[2001]_
_EWCA Civ 240, concerned the position prior to discharge. The health authority conceded that it had a_
power to take preparatory steps; it should normally use this discretionary power to use reasonable


-----

endeavours to fulfil conditions dependent on which the Mental Health Review Tribunal had indicated it was
prepared to order release; and failure to use such endeavours in the absence of strong reasons would be
likely to be an unlawful exercise of discretion - see [20]. Lord Phillips MR endorsed these concessions see [29]. Although, as Stanley Burnton J observed in _R (B) v Camden London Borough Council_ _[2005]_
_EWHC 1366 (Admin) at [60], the point was not the subject of competing argument, a similar conclusion_
was expressed by the House of Lords in R (H) v Secretary of State for the Home Department _[2003] UKHL_
_59 when Lord Bingham said at [29], 'the duty of the health authority, whether under s.117 of the 1983 Act_
or in response to the tribunal's order of 3 February 2000, was to use its best endeavours to procure
compliance with the condition laid down by the Tribunal.' ”

81.  I think there is also assistance to be gained on this point, albeit in a different context, from _R_
_(Limbuela) v Secretary of State for the Home Department [2006] 1 AC 396per Lord Bingham at paragraph_
5, where he said, in relation to section 55 of the Nationality, Immigration and Asylum Act 2002:

“Where (and to the extent) that exercise of the power is necessary, the Secretary of State is subject to a
duty, and has no choice, since it is unlawful for him under section 6 of the 1998 Act to act incompatibly with
a Convention right. Where (and to the extent) that exercise of the power is not necessary, the Secretary of
State is subject to a statutory prohibition, and again has no choice. Thus the Secretary of State (in practice,
of course, officials acting on his behalf) must make a judgment on the situation of the individual applicant
matched against what the Convention requires or proscribes, but he has, in the strict sense, no discretion.”

82.  Would it be a breach of his Convention rights for the Secretary of State to release the Claimant on or
after 14 July 2017 without providing him with section 4 accommodation? In my judgment, it would. He had
no means and no sources of support and he had no means of supporting himself. He was not entitled to
work and he was not entitled to benefits. His release from detention by the Secretary of State without
section 4 accommodation to go to would therefore leave him without “shelter, food or the most basic
necessities of life”, to quote Lord Bingham in Limbuela. The Claimant is a man in the prime of life, but his
mental and physical health, particularly given his alcohol problem, and the absence of any remaining
facilities or sources of support for him (whether from the Safe House Society, Lincolnshire County Council,
or anyone else) mean that releasing him on to the streets, even in the middle of the summer, would on any
“fair and objective assessment of all relevant facts and circumstances” (to quote Lord Bingham again)
cause him to face “an imminent prospect of serious suffering caused or materially aggravated by denial of
shelter, food or the most basic necessities of life.” He would be obliged to sleep in the street for an
indefinite period, with all the privations that follow, including difficulties in eating, sleeping, and keeping
clean. This was in my judgment sufficient to entitle him to section 4 bail accommodation from the Secretary
of State, upon release pending his deportation. The position is different on the facts from that considered
by Kerr J in Machnikowski v Secretary of State for the Home Department [2016] 1 WLR 1655at paragraphs
77-78.

83.  That does not mean the Claimant would be entitled to remain in the accommodation if, by his own
actions, he were to deprive himself of it; for example, by misconduct leading to expulsion. That would not
be an act of the Secretary of State, and she would not have an obligation to find other accommodation
under section 4 in that case.

84.  It is clear from Mr Dyer's witness statement that this accommodation is not easy to find. However,
some of the difficulties, such as failures to process paperwork, or to resolve data protection issues, or to
solve contractual disputes, are not of a nature to absolve the Secretary of State from her obligation
indefinitely. The date of 14 July 2017 (which I have found marked the end of the period when the Claimant
could lawfully be detained) already builds in a period to make suitable arrangements. In my judgment,
section 4 accommodation could and should with reasonable endeavours have been provided from that
date.

**Summary**

85.  In summary, my conclusion on the three challenges before me is that:

-----

(1)  The Defendant's decision to certify under Regulation 24AA of the Immigration (European Economic
Area) Regulations 2006 was unlawful, but immaterial, because the Claimant was not removed and the
threat of removal under Regulation 24AA has now been withdrawn.

(2)  The Claimant's detention was lawful from 15 February to 14 July 2017, but has been unlawful since
then.

(3)  The Defendant should have provided the Claimant with a bail address from 14 July 2017.

86.  Counsel have agreed to try and agree an order and directions to follow on my judgment. In the
absence of agreement, I will hear submissions.

**End of Document**


-----

