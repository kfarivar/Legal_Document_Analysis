# R (on the application of ARM) v London Borough Of Brent [2022] EWHC 1454
 (Admin)

Queen's Bench Division (Administrative Court)

Deputy Judge Douglas-Jones

13 May 2022Judgment

MISS I. PROUD (instructed by Osbournes Law) appeared on behalf of the Claimant/Applicant.

MR D. CARTER (instructed by the London Borough of Brent) appeared on behalf of
Defendant/Respondent.

_________

If this Transcript is to be reported or published, there is a requirement to ensure that no reporting restriction will be
breached. This is particularly important in relation to any case involving a sexual offence, where the victim is
[guaranteed lifetime anonymity (Sexual Offences (Amendment) Act 1992), or where an order has been made in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)
relation to a young person.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

(Transcript prepared without the aid of documentation)

THE DEPUTY JUDGE:

**Introduction.**

1 This is a renewed application for permission to seek judicial review. It concerns a local authority short
form age assessment. The claimant also seeks an order for interim relief requiring the defendant to treat
him as a child until the decision on the judicial review.

2 By an order dated 7 March 2022, Jay J refused permission on the papers. By an order dated 24
February 2022, preceding that, Ritchie J refused interim relief on the papers.

**The Claim.**

3 The claimant challenges the decision on four bases. The first three are traditional judicial review grounds:

Ground 1 –  the use of the short form age assessment was unlawful, and contrary to the law concerning
age disputes and/or guidance and/or amounted to a breach of the Tameside duty, and/or was irrational.

Ground 2 –  the decision was irrational as it involved "demonstrable flaws".

Ground 3 –  the short form age assessment was unlawful as it involved "serious procedural unfairness"
contrary to age dispute case law and guidance.

The fourth ground is that the defendant's conclusion in the short form age assessment was wrong as a
matter of precedent fact


-----

4 In written submissions the claimant's stance was that if permission were to be granted in relation to
ground 4 alone the claimant would invite the court to transfer the claim to the Upper Tribunal Immigration
and Asylum Chamber for a full factual hearing to determine his age. In the course of discussion I
suggested to Miss Proud, who appears on behalf of the claimant, that if permission were granted on any of
grounds 1 to 3, as well as ground 4, as there were no issues of policy or principle at stake in the challenge
before me, then a transfer to the Upper Tribunal prima facie appeared to be the more appropriate
procedure which would ultimately be more beneficial and expeditious from the claimant's point of view.
Miss Proud's stance, in light of that, was that such a course would not be inappropriate but the claimant
would prefer to have an initial local authority assessment and, therefore, traditional judicial review would be
the preferred course in those circumstances.

**Context of the Claim.**

5 The claimant is an unaccompanied Sudanese asylum seeker. He arrived in the United Kingdom in
October 2021. His claimed age is [an age]. The defendant is a local authority with social services
functions. The claimant is accommodated in the defendant's area. The claimant claims he was born in a
small village in Sudan on [a date]. He uses the Gregorian calendar, and gives his date of birth as [a date].
The claimant asserts that his mother told him his date of birth near to his [an age] birthday; that was in the
context of their discussing his securing an identity card. He would use that to register at school. He
asserts that he has a birth certificate in Sudan and he is trying to arrange for that to be posted to him.

6 The claimant asserts that he grew up with his parents and four brothers aged about [an age], [an age],

[an age] and [an age]. He was not formally educated. He asserts that he left Sudan when he was [an age].
He recalls leaving on 23 July 2020. He left because his father was then critically ill with cancer. The
claimant's father paid an agent to take the claimant out of Sudan for his protection in circumstances where
the father's illness prevented the father from providing protection to the claimant. The claimant was then
trafficked, in the context of debt bondage and labour exploitation, before arriving in the UK by small boat on
about 16 October 2021.

**The KIU Assessment.**

7 On 17 October 2021 the claimant was interviewed by the Kent Intake Unit ("the KIU") on behalf of the
Home Office. They assessed his age to be 24. As a result of the KIU assessment the claimant was put in
Home Office accommodation for adult asylum seekers in the form of a room at the Holiday Inn in Wembley.

**The Challenged Assessment.**

8 On 10 November 2021 the defendant first met with the claimant ("the 10 November 2021 meeting").
Two social workers visited him at the Holiday Inn in Wembley. In pre-action correspondence (an email of
14 December 2021) this was described as a "welfare meeting". In contrast, in the short form age
assessment document, the 10 November 2021 meeting was described as the "initial interview" in the
context of the age assessment process. The claimant was not told at the 10 November 2021 meeting that
it was part of an age assessment process.

9 On 16 November 2021 the charity 'Young Roots' began assisting the claimant. On that day Young
Roots sent the defendant an email to the effect that the claimant was 16 but he had been assessed as
being 24 and this was causing him ". . . a lot of distress." The defendant sent a letter to the claimant
inviting him to attend Brent Civic Centre for a short form age assessment on 24 November 2021. The
letter set out that there would be an interpreter who speaks Sudanese Arabic and an appropriate adult
present. In that letter the defendant did not describe the 10 November 2021 meeting as being part of the
age assessment process. On 24 November 2021 the defendant undertook the short form age assessment
of the claimant. Two social workers and an appropriate adult were present. An interpreter who spoke
Egyptian Arabic, rather than Sudanese Arabic, was used.

10 The claimant claimed his date of birth was [a date], according to the appropriate adult. He said he was
“[an age]” old. Social workers recorded the claimant's claimed date of birth as [a date]. This may have
derived from the KIU's record of the claimant's date of birth which was inaccurate.


-----

11 The conclusion of the short form age assessment was that the claimant was between [an age] and [an
age]. This was reached "on conclusion of assessment", i.e. it was reached after the short form age
assessment, not simply on the basis of demeanour and appearance but after questioning. The short form
age assessment, included questioning under some 14 heads including physical appearance and
demeanour, interaction of person during the assessment and matters relevant to the claimant's
background. In the conclusion the social workers drew adverse inferences from the claimant's accounts of
events, in particular an apparent inconsistency concerning how many siblings he had in the context of
apparently referring to two of his brothers as "my children". The short form age assessment recorded that
"the assessors reserved the right to revise the assessment should other evidence come to light".

12 On 24 January 2022 the claimant instructed solicitors. His solicitors provided further evidence
supporting the claimant's claimed age, including a letter from Shona Warne, Youth Welfare Officer of
Young Roots Charity. By an "addendum … continuation of the age assessment process by considering
additional evidence in relation to age report" dated 31 January 2022, which drew support from the
inconsistencies said to have been revealed in the interview of 24 November 2021, the short form age
assessment decision was upheld.

**Jurisdiction.**

13 One basis on which a local authority age assessment may be challenged on judicial review is that the
assessment was "wrong as a question of fact". The test for the permission judge in such cases was set out
in R(on the application of FZ) v London Borough of Croydon _[2011] EWCA Civ 59. The court has to ask:_

". . . whether the material before the court raises a factual case which, taken at its highest, could not
properly succeed in a contested factual hearing."

As Fordham J emphasised in the permission decision of R(on the application of GB) v Leeds City Council

_[[2022] EWHC 465 (Admin) at 7:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6516-5TK3-CGX8-046N-00000-00&context=1519360)_

" 'This test for refusing permission for judicial review arises in the context of a hard-edged question of fact
for the judicial review court to decide R (A) v Croydon LBC _[2009] UKSC 8 [2009] 1 WLR 2557), and where_
there is the practice of transfer to the Upper Tribunal for the substantive hearing, where fresh evidence and
oral evidence can properly be considered' . . ."

The court made clear in that case that this court clearly has to have in mind the prospect of success at a
future factual hearing of that nature and with evidence of that kind. The FZ test nevertheless focuses on
"the material before the court" at the permission stage in order to evaluate whether "taken at its highest"
the "factual case" being advanced can "not properly succeed". So far as the permission stage judge is
concerned, the context includes appreciating the significance of the age assessment decision for a child.
This is the jurisdiction which applies insofar as ground 4 is concerned. Fordham J went on, at paragraph 8,
to explain the jurisdiction of the Administrative Court in age assessment challenges other than those
involving hard-edged factual considerations:

_“There is another basis on which a local authority age assessment can be challenged on judicial review,_
_that is as to its lawfulness judged by reference to applicable legal standards as a matter of conventional_
_judicial review challenge, those include legal standards of fairness and due process, sufficiency of inquiry_
_and legally adequate reasons.”_

14 Grounds 1 to 3 are based on that conventional route to challenging an age assessment.

**Law.**

15 The importance of age assessments is set out by Thornton J at paragraph 18 of R(on the application
_of AB) v Kent County Council [2020] EWHC 109 (Admin) (“AB”)._

16 In _B v Mayor and Burgesses of the London Borough of Merton_ _[2003] EWHC 1689 (Admin), which_
concerned a 25 to 45 minute interview and a finding by local authority social worker that the claimant was
at least 18 to 20, Stanley Burnton J considered "obvious cases" at paragraphs 27, 36 to 38 and 50. Most
pertinently at paragraph 27 it was set out that there may be cases where it is very obvious that a person is


-----

under or over 18. In such cases there is normally no need for prolonged inquiry, if any. There is a difficulty
where the person concerned is approaching 18 or is only a few years over 18. It is not possible to
prescribe the level or manner of inquiry so as sensibly to cover all cases. At paragraph 37, except in clear
cases, it was set out the decision maker cannot determine age solely on the basis of the appearance of the
applicant. Generally, background should be elicited and if there is reason to doubt the applicant's
statement as to his age an assessment of his credibility will be necessary through questions. At paragraph
50 it was set out that there should not be judicialization of what are relatively straightforward decisions.
Cases will vary.

17 In AB, Thornton J reviewed at paragraphs 18 to 24 the legal framework concerning age assessments.
At paragraph 21 the court grouped the guidelines into headings. They are important.

18 In BF (Eritrea) v Secretary of State for the Home Department [2019] EWCA Civ 872, cited by Thornton
J at paragraph 22 of _AB, the Court of Appeal considered Home Office policy that claims by asylum_
seekers to be under 18 should be accepted unless:

". . . 'their physical appearance/demeanour very strongly suggests they are significantly over 18 years of
age and no other credible evidence appears to the contrary' . . ." (emphasis in the original policy).

19 At paragraph 55, Underhill LJ set out:

“there would be cases where it is so obvious, even on an initial assessment of appearance and demeanour
that a person was over 18, and to treat them as a child would be unjustified. That is, of course, also in line
with the observations of Stanley Burnton J in Merton.”

20 Then, at paragraph 57 Underhill LJ said:

"That, however, is only half the story. If it is legitimate for the Secretary of State to make an initial decision
based on appearance and demeanour only, it is incumbent on him to ensure so far as possible that such
decisions take fully into account the wide margin of error which such decisions will necessarily involve, so
that only those young people whose claims to be under 18 are obviously false are detained: in other words,
anyone claiming to be a child must be given the benefit of the doubt. . ."

21 Underhill LJ set out in BF the margin of error in age assessments.

22 Returning to AB at paragraphs 31 to 46, Thornton J analysed the law, having considered Merton and
_BF (see 33 and 34). At 35 it was set out:_

". . . there may come a point when an experienced social worker considers they have conducted sufficient
inquiries to be confident that the person in front of them is either an adult or a child . . . it would be pointless
to . . . require the continuation of the inquiry process to achieve full Merton compliance simply for the sake
of form . . ."

23 At 36, core principles were distilled from _Merton. At 37 Thornton J recognised "limitations" of_
assessments based on appearance and demeanour. At 44 Thornton J set out that it was incumbent on the
authority to ensure it takes into account the margin for error in abbreviated assessments.

24 In MA and HT v Coventry City Council _[[2022] EWHC 98 (Admin) Henshaw J conducted a structured](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64K1-H4Y3-CGX8-02WJ-00000-00&context=1519360)_
review of the authorities concerning age assessments; see paragraphs 38 to 85. The court began with an
overview of the area by reference to Thornton J's judgment in _AB (see paragraph 38) and proceeded to_
examine the topics of "obvious cases", the need for an appropriate adult and "preliminary decisions" (see
paragraph 39). Henshaw J dealt with obvious and very clear cases at paragraph 41. Then, at 105 he set
out that:

"The unreliability of appearance/demeanour as a means to making fine judgments as to age (well
recognised in the case law) would make it questionable whether a person regarded, even by an
experienced social worker, as appearing to be slightly over 18 could be regarded as an obvious or clear
case: especially when newly arrived after a long journey."

25 Paragraph 106 is in these terms:


-----

" Moreover, such a case is unlikely to transform itself into a 'clear' or 'obvious' case - in that sense - during
the course of the assessment. In the circumstances with which we are currently concerned, both the KIU
officer and the social worker must have formed the view prior to the assessment that the individual's
physical appearance and demeanour do not very strongly suggest that they are 25 or older. Their
perceived appearance and demeanour are unlikely to change significantly as a result of the interview.
Further, the 'Decision on age' section of the report form itself does not ask the social worker to revisit the
question of whether the individual's physical appearance and demeanour indicate that he/she is very
clearly significantly over 18, nor even that his/her physical appearance and demeanour indicate that he/she
is clearly over 18. Instead, the question is whether he/she has been '[a]ssessed to be clearly an adult'."

26 See also paragraph 110. At paragraph 44, the court addressed the importance of the "minded to"
process, and at 49 to 50 the court addressed the need for an appropriate adult. At paragraph 109 the court
described the 'minded to' (or 'provisional decision') opportunity and the safeguard of an appropriate adult,
as "necessary elements of a fair and appropriate process."

27 In R(on the application of SB) v Royal Borough of Kensington & Chelsea _[[2022] EWHC 308 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64T6-VFG3-CGX8-04D4-00000-00&context=1519360)_
Bennathan J observed at paragraph 31 that in terms of local authority process, and the approach of this
court to challenges of age assessments:

". . . local authorities should not be hobbled by the Courts taking a highly technical approach to appeals . .
."

28 At paragraph 32 Bennathan J said:

_". . . the depth of enquiry required of a local authority in an age assessment process is not binary."_

A short form assessment may be appropriate but it must be fair.

**Discussion.**

Ground 1.

29 Through ground 1 the claimant alleges that the short form age assessment procedure was unlawful,
contrary to case law and guidance and/or in breach of the Tameside duty and/or irrational. It was
submitted by Miss Proud, on behalf of the claimant that the short form procedure should be reserved for
"rare circumstances" where it is "very clear that the individual is an adult well over the age of 18". In
support of that proposition she relied on the ADCS (Association of Directors of Children's Services Ltd)
Guidance at page 6.

30 The claimant submits this is not a very clear case because the age assessed was within the applicable
margin for error. Miss Proud relied on AB in support of this submission. Pertinently, the finding that the
claimant was 23 to 25 was reached "on conclusion of the assessment", i.e. taking into consideration the
material rehearsed in the report other than merely appearance and demeanour, including adverse
inferences drawn from the claimant from ostensible inconsistencies and apparent lack of credibility which
had not been the subject of any 'minded to' safeguard.

31 In relation to ground 1 the defendant submits that it is the claimant's assertion - that the question
whether the defendant was entitled to decide whether to carry out a short form assessment is a matter for
the court - is wrong. It is accepted that the test to be applied to determine whether the conduct of such an
assessment was procedurally unfair is not whether it was irrational for the decision maker to act as he/she
did, rather whether the court considers it unfair of him not to do so. The defendant submits the decision to
carry out a short form age assessment did not relate to the conduct of the assessment, it related to the
scope and scale of the assessment. There was no “bright line”, Mr Carter submitted on behalf of the
defendant, between those cases where a short form age assessment and those where a full _Merton_
assessment were appropriate. The defendant submits that the margin for error had been applied correctly,
as with a five year margin for error the claimant would still be 18.

Ground 2.


-----

32 Insofar as ground 2 is concerned, the claimant sets out in the statement of facts and grounds at
paragraph 70, why each of the eight reasons given by the defendant for its conclusion is "demonstrably
flawed". For the purpose of this renewal application Miss Proud, on behalf of the claimant, confined her
submissions to two examples including an adverse inference finding against the claimant deriving from his
apparently referring to two children as his children at one point in the interview process, and as his younger
brothers in another. She pointed to the fact that the interpreter spoke a different dialect of the same
language as the claimant as a possible source of confusion.

33 The defendant submits that I should adopt a "benevolent attitude" to the decision and look at it
holistically, relying on the speech of Lord Neuberger in Holmes-Moorhouse v Richmond on Thames
_London Borough Council_ _[2009] UKHL 7; [2009] 1 W.L.R. 413 at paragraphs 46 to 52, and the judgment of_
Auld LJ at paragraph 38(9) of _Osmani v Camden London Borough Council [2004 ] EWCA Civ 1706. In_
support of the defendant's position in the context of such a benevolent approach the defendant pointed to a
number of "rational factors" which the defendant submitted tended to point towards the claimant being an
adult. Significantly, however, in the context of the claimant's submissions about process, those factors
included the adverse findings of the defendant against the claimant in respect of consistency and
credibility.

Ground 3.

34 Insofar as ground 3 is concerned "serious procedural unfairness" is alleged. This focuses on an
absence of the minded-to process. The argument was developed by reference to specific examples of
adverse inference drawn against the claimant by the social workers in the context of the interpreter
speaking a different dialect. The defendant submitted that it was not necessary for the assessors in the
instant case to adopt a particular procedure in putting their concerns to the claimant: although the
assessors did not convene a minded to meeting, the claimant was given the opportunity to answer
discrepancies throughout the interview. At the end of their interview he was afforded the opportunity to
clarify any of the information he had provided. The claimant submits in that regard that such a mere
statement as to an authority's continuing public law duty is no substitute for a structured minded to process.

Ground 4.

35 The claimant relies on two principal matters to show that a claim is made out on the basis of evidence
that could be believed: (i) the claimant's account of how he came to know his age and date of birth, and
(ii) Miss Warne's evidence. Miss Warne had only worked for Young Roots for a short period of time. She
has no formal training in age assessment. On the other hand, at paragraph 8 of her statement, of 2
February 2022, submitted in support of the claim, she sets out:

"Prior to working for Young Roots I previously worked as the outreach co-ordinator of a youth charity in
Calais and Northern France from 1 February 2020 to 17 September 2021. The charity supported
unaccompanied 'minors on the move'. This was a role in which I became very familiar with the
experiences of asylum seeking children en route to and in the UK. The children I work with in this role are
primarily between the ages of 14 and 17, and their nationalities reflected the demographics of migrant
communities in the area as such. By far the highest proportion of children I worked with were Sudanese."

36 She had seen the claimant on a weekly basis between November 2021 and the end of January 2022.
He was receiving support and ESOL teaching from her. At paragraph 11 she set out:

"I have had eight one to one case work sessions with the claimant lasting an average of 30 minutes each,
so approximately four hours of in-person one to one time in total, with brief check-ins by
telephone/message approximately twice a week in addition. Also, since November the claimant has
attended 10 youth activity sessions that I have been running/supporting (eight Ahlan Youth Club and two
Youth Hub). Each session is two to three hours long and I would have interacted with the claimant in
group settings throughout the sessions."

At paragraph 12 she set out that she is strongly inclined to believe that the claimant is his claimed age.


-----

37 The defendant's submissions on ground 4 focused on the inconsistencies in the claimant's account and
that Miss Warne "neither has the expertise nor experience to opine on age."

**Conclusion**

38 As to ground 4 in my judgment when the case is considered as a whole, applying the test in FZ, when I
ask myself: "whether the material before the court raises a factual case which, taken at its highest, could
not properly succeed in a contested factual hearing" the answer is 'no'. On that basis I propose to grant
leave on ground 4, and transfer the case to the Upper Tribunal.

39 Insofar as grounds 1 to 3 are concerned, in my judgment, they are arguable and have merit but the
matters raised will, insofar as they are relevant, all be addressed through the procedure in the Upper
Tribunal.

**Interim relief**

40 I turn now to the issue of interim relief. The claimant seeks an order that, following my ruling on
permission, pending determination of the proceedings in the Upper Tribunal or further order, that the
defendant shall treat the claimant as a child of his claimed age with a date of birth of [a date], and maintain
the provision of suitable accommodation and support for a looked after child of that age.

41 As a preliminary issue I have to decide what has been described by Miss Proud as "the height of the
bar". Miss Proud submits that the correct approach is that taken by the House of Lords in _American_
_Cyanamid Company v Ethicon Ltd [1975] AC 386"with modifications appropriate to the public law context"._
In that respect, she relies on _R(Medical Justice) v Secretary of State for the Home Department_ _[[2010]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7YRB-WKD0-YBF6-755D-00000-00&context=1519360)_
_[EWHC 1425 (Admin). In particular, she stresses that the court must consider whether the claimant has a](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7YRB-WKD0-YBF6-755D-00000-00&context=1519360)_
real prospect of success at trial, and whether the balance of convenience favours the award of the relief
sought. Miss Proud stresses that the test is not whether the claimant has an "strong prima facie case".
She submits that the defendant is wrong to draw support in the way it does from the provision of housing in
homelessness cases.

42 In support of her application Miss Proud relies on the Statutory Guidance for Local Authorities issued
by the Department for Education in respect of care of unaccompanied migrant children and child victims of
**_modern slavery. Pursuant to this guidance where the age of a person is uncertain, and there are reasons_**
to believe that they are a child, that person is to be presumed a child in order to receive immediate access
to assist and support, and protection. Miss Proud drew support from R(on the application of S) v Croydon
_LBC [2017] EWHC 265, in which Lavender J held that a putative child, awaiting an age assessment in that_
case was to be treated as a child unless there were cogent reasons for departing from the DFE Guidance.
She invites my attention beyond that to the ADCS Guidance which states that putative children will be
looked after under section 20 of the Children Act 1989 "other than in exceptional circumstances". In BG v
_Oxfordshire County Council_ _[[2014] EWHC 3187 (Admin), Michael Fordham QC, sitting as a Deputy Judge](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5D9K-PWT1-F0JY-C01F-00000-00&context=1519360)_
of the High Court, held, in granting interim relief in an age assessment case:

"32. The court, on interim relief, will always have close regard of course to the implications of what it would
be ordering. On the other hand, even in areas where the courts have a more indirect supervisory
jurisdiction on review, that is to say the more conventional standards of reasonableness review, it is
inevitably always the case that a court considering interim relief is being invited to dictate to the public
authority concerned a step which the public authority itself has decided is not necessary or appropriate.
The homelessness context would be a classic example where interim relief will have that consequence.
That of itself, in my judgment, cannot suffice to deter the court in granting interim relief if satisfied by
reference to arguability and the 'balance of convenience', modified to apply in the public law context, that
interim relief is appropriate.

33. In my judgment, there is, though, a further consideration that arises in the present context. Parliament,
as explained by the Supreme Court, has imposed in the present area a heightened duty on the reviewing
court to evaluate objective facts for itself. As it seems to me, once the court has reached the position at the
permission stage filter that there is a properly arguable case which ought to proceed to a hearing, the court
is squarely seized of a matter which falls within what can properly be described as a primary judgment of


-----

the court. In my judgment, in that context there are limits on the weight that can be given to the submission
that the Local Authority has reached its own conscientious view and would, were there interim relief, be
making provision which it is satisfied is unnecessary and inappropriate."

Miss Proud further relies on _R(on the application of MG & Ors) v London Borough of Hillingdon_ [2020]
EWHC 2847 (Admin) and _R(on the application of M) v Waltham Forest_ to show the importance of
identifying and respecting legal requirements of local authorities towards children.

43 Mr Carter relied on _De Falco v Crawley Borough Council_ and _Sylvester v Crawley Borough Council_

[1980] QB Reports 460 at 478 where Lord Denning MR said the granting of an interlocutory injunction in
the context of the Council's finding of intentional homelessness:

". . .should not be granted unless it is a case on which an application for judicial review certiorari would be
granted to quash their decision and a mandamus issued to command them to consider afresh."

44 Mr Carter also relied on the decision of Hickinbottom LJ in _R(on the application of Vincent Nolson v_
_Stevenage Borough Council [2021] 2 HLR 31 at 8. However, Hickinbottom LJ rehearsed the decision in_
_De Falco, but at paragraphs 20 and 21 set out the court was unpersuaded it should consider the issue in_
that case. Mr Carter further relied on the Westlaw abstract of an unreported case: R(on the application of
_Vokow) v London Borough of Southwark [2022] 4 WLUK 354 which applied the strong prima facie case_
test in a homelessness case. He also relied on the immigration detention decision of Mr Hugh Southey
QC, sitting as a Deputy Judge of the High Court in R(on the application of Kabay v Secretary of State for
_the Home Department_ _[[2021] EWHC 3101 (Admin) to suggest that a strong prima facie case is needed](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:647M-T673-CGX8-027F-00000-00&context=1519360)_
before relief should be granted.

45 The cases relied on by Mr Carter do not support the proposition that in the context of interim relief in an
age assessment case a strong prima facie case is necessary in my judgment.

[46 I adopt the approach in BG v Oxfordshire County Council [2014] EWHC 3187 (Admin). I decide this](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5D9K-PWT1-F0JY-C01F-00000-00&context=1519360)
interim relief application on the basis of the balance of justice and the balance of injustice. I agree with
Ritchie J, in his decision in this case of 24 February 2022, that the appropriate test in this context is that set
out for mandatory injunctions in _Shepherd Homes Limited v Sandam_ [1971] ChD 340 and _Nottingham_
_Building Society v Eurodynamics Systems Plc [1993] FSR 468. Where one is dealing with the interests of_
a prima facie asylum seeking child who gives a credible account of being a victim of trafficking that has to
weigh in his favour in terms of the balance of convenience, bearing in mind the statutory and ADCS
guidance. However, I do not consider, on the balance of convenience that the order of Ritchie J should be
varied. As Ritchie J set out in his reasons:

"The evidence of the claimant's suffering in the Holiday Inn is: (i) his assertion that he is struggling, lonely
and depressed and life is not worth living; and (ii) his youth charity worker's assertion that he is isolated
and uncomfortable there but he interacts well in all the youth activities she provides for him save for
education.

There is no medical evidence in support for any psychiatric or psychological suffering. He is housed and
fed. He has the support of a charity. If he is sent under a mandatory interim order to a children's hostel he
may, depending on his age, be a man surrounded by children. The defendant will incur additional expense
in such a move and the injunction will substantially determine the claim until the JR or age assessment
hearings which may not be determined for [and I vary the wording here because of the context of this
renewed application, for several] months. On his own case he turns 18 in [now seven] months.

In those circumstances I decline to vary the order of Ritchie J.

_______________

**CERTIFICATE**

Opus 2 International Limited hereby certifies that the above is an accurate and complete record of the Judgment or
part thereof.


-----

_Transcribed by Opus 2 International Limited_

_Official Court Reporters and Audio Transcribers_

**_5 New Street Square, London, EC4A 3BF_** **_Tel: 020 7831 5627_**
**_Fax: 020 7831 7737_**

**_CACD.ACO@opus2.digital_**

This transcript has been approved by the Judge.

**End of Document**


-----

