# Esslemont v The Information Commissioner [2024] UKFTT 333 (GRC)

UK First-tier Tribunal (General Regulatory)

Tribunal Judge Sophie Buckley; Tribunal Member Dave Sivers and Tribunal Member Naomi Matthews

25 April 2024Judgment

For the Appellant: In person

For the Respondent: Did not appear

**Decision: The appeal is allowed.**

**Substituted Decision Notice:**

Organisation: The Home Office

Complainant: Mx Maya Esslemont

**The Substitute Decision – IC-251137-R5S8**

1. For the reasons set out below the Home Office was not entitled to rely on section 22 of the Freedom of
Information Act 2000 to withhold the information requested by the complainant on 21 June 2023.

2. The Home Office is not required to take any steps.

**REASONS**

**Introduction**

1. This is an appeal against the Commissioner's decision notice IC-251137-R5S8 of 21 September 2023 which
held that the Home Office was entitled to rely on section 22(1) of the Freedom of Information Act 2000.

2. The Commissioner did not require the Home Office to take any steps.

**Factual background to the appeal**

3. The tribunal adopts the following factual background from the Commissioner's response:

“10. Public authorities in England and Wales have a duty under section 52 of the **_Modern Slavery Act 2015 to_**
notify the Home Office when they come across potential victims of modern slavery including any form of human
trafficking, slavery, servitude or forced labour. This duty can be fulfilled by referring a potential victim into the
National Referral Mechanism ('NRM'). Individuals referred to the NRM receive decisions from the Home Office on (i)
reasonable grounds (there are reasonable grounds to believe that a person is a victim of modern slavery) or (ii)
conclusive grounds (on the balance of probabilities, there is sufficient information to consider the individual is a
victim of modern slavery). Following a positive reasonable grounds decision, a conclusive grounds decision will be
made determining whether the individual will be entitled to further support. The Home Office publishes quarterly
statistics about referrals to the NRM.


-----

11. The Appellant is the Director of After Exploitation, a small organisation established to support survivors of
**_modern slavery.”_**

4. Decisions can be reconsidered after being issued. This could be if additional evidence becomes available that
would be material to the outcome of a case, or there are specific concerns that a decision has not been made in line
with published guidance.

5. The request is for NRM statistics. The requested information forms part of statistics later published by the Home
Office in November 2023.

**Request and response**

6. This appeal concerns a request made by the appellant on 21 June 2023 for the following information:

“Please provide the number of National Referral Mechanism (NRM) reconsiderations between 1 January 2022 and
present, broken down by:

- NRM stage (eg. 'reasonable' or 'conclusive grounds')

- Reconsideration outcome

- Year of reconsideration”

7. The Home Office replied on 4 July 2023. The Home Office refused to provide the information relying on section
22 FOIA on the basis that the requested information was intended for future publication and the public interest
favoured maintaining the exemption.

8. The appellant applied for an internal review. On 10 August 2023 the Home Office upheld its decision.

**Decision Notice**

9. In a decision notice dated 21 September 2023 the Commissioner decided that the exemption was engaged and
that the public interest favoured maintaining the exemption.

10. The Commissioner accepted that it was reasonable for the Home Office to apply section 22 of FOIA to the
information.

11. In relation to the public interest the Commissioner recognised the public interest in the Home Office publishing
the information, as it would promote transparency, and in limiting any delays to publication. He welcomed the Home
Office's evidence that the information will be published as soon as it is practical.

12. The Commissioner considered that there was a stronger public interest in the Home Office being able to
publish the requested information in a controlled manner following the required quality checks. He stated that
premature disclosure of the information would be likely to impact on its quality and raise issues which the Home
Office would have to divert resources into countering.

13. The Commissioner was satisfied that the information (the number of NRM reconsiderations) was intended to be
published at the next quarterly publication on 2 November 2023. He was also satisfied that when the request was
made to the Home Office, there was an intention to publish the information requested.

14. The Commissioner concluded that the balance of public interests favoured maintaining the exemption.

**The grounds of appeal**

15. The appellant appealed the decision, in essence on the ground that the Commissioner was wrong to conclude:

15.1. that section 22 was engaged and


-----

15.2. that the public interest favoured maintaining the exemption

16. The appellant raises the following points:

16.1. The Home Office provided similar information to another requestor on 29 August 2023.

16.2. The Home Office approached the other requestor's request in a way that was not 'applicant blind'

16.3. The Home Office's objection to disclosure on the basis that 'ad hoc' disclosures would be disruptive is
undermined by this disclosure in August 2023.

**The Commissioner's response**

17. The Commissioner noted that the Home Office's response on 29 August 2023 to a separate information
request made by a different requester postdated the relevant time (the date of the Home Office's response on 4
July 2023). Further the Commissioner noted that part one of the separate request covered a shorter time frame
(about six months, instead of almost 18 months cited in the Request) and the Home Office responded to it just over
nine weeks before the intended publication date of 2 November 2023.

18. The Commissioner submitted that the issue of whether or not the Home Office was 'applicant blind' in its
response to the other requestor is not a matter for the tribunal in this appeal.

**Legal framework**

19. Section 22 FOIA states:

“1) Information is exempt information if—

(a) the information is held by the public authority with a view to its publication, by the authority or any other person,
at some future date (whether determined or not),

(b) the information was already held with a view to such publication at the time when the request for information
was made, and

(c) it is reasonable in all the circumstances that the information should be withheld from disclosure until the date
referred to in paragraph (a).”

20. Section 22(1) FOIA is a qualified exemption and thus subject to the public interest balancing test in section 2
FOIA.

**Evidence**

21. We read an open bundle of documents.

**Issues**

22. The issues under section 22 are:

22.1. Was the information held, at the relevant dates, with a view to publication at some future date?

22.2. Was it reasonable in all the circumstances that the information should be withheld from disclosure until that
future date?

22.3. Where does the public interest balance lie?

_The role of the tribunal_


-----

23. The tribunal's remit is governed by s.58 FOIA. This requires the tribunal to consider whether the decision made
by the Commissioner is in accordance with the law or, where the Commissioner's decision involved exercising
discretion, whether he should have exercised it differently. The Tribunal may receive evidence that was not before
the Commissioner and may make different findings of fact from the Commissioner.

**Oral submissions by the appellant**

24. We heard and took account of oral submissions by the appellant.

**Discussion and conclusions**

_Was the information held, at the relevant dates, with a view to publication at some future date?_

25. In **Montague v Information Commissioner** _[[2022] UKUT 104 (AAC) (Montague)[1] the Upper Tribunal held](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:68Y7-2BH3-S7C0-22TF-00000-00&context=1519360)_
that the public interest under FOIA should be assessed at the date of the refusal of the request:

“86. ... The public authority is not to be judged on the balance of competing public interests on how matters stand
other than at the time of the decision on the request which it has been obliged by Part I of FOIA to make.”

26. The Upper Tribunal decision was appealed to the Court of Appeal (and upheld) on other grounds (reported at

_[2023] EWCA Civ 1378)._

27. We agree with the Commissioner that the principle in **Montague** applies equally to whether or not an
exemption is engaged. Thus the relevant date for the purposes of section 22(1)(a) is the date of the response to the
request (4 July 2023).

28. Section 22(1)(b) specifies that that the information must also already be held for the relevant purpose 'at the
time when the request for information was made'. The request was made on 21 June 2023.

29. Accordingly under section 22 the information must already have been held with a view to publication at some
future date when the request was made on 21 June 2023) and must have been held for that purpose at the date of
the response on 4 July 2023.

30. As part of the Commissioner's investigation, the Commissioner asked the Home Office to provide evidence that
there was a settled intention to publish the requested information prior to the request being received. The
Commissioner stated in a letter to the Home Office:

“In order correctly rely on section 22 there must have been a settled intention to publish the requested information
prior to the request being received.

Therefore, please provide evidence which demonstrates that the information was going to be published at the time
of the initial request.”

31. We have been provided with three emails which were produced by the Home Office to in response:

31.1. An email of 11 May 2023 which includes a proposal to include additional data about reconsiderations.

31.2. An email of 22 June 2023 which states that 'I have just spoken to [redacted] who has confirmed that there is
an intention to publish recon[sideration] data inclusive of the the time period asked by the requestor'.

31.3. An email of 12 July 2023 providing the specification for data on reconsideration decisions.

32. The email of 11 May 2023 demonstrates that there was a proposal to include reconsideration data in future
publications. It is clear from that email that there was not yet a settled intention to publish that data. The email sets
out the proposal and then states:


-----

“Before we go to [redacted] to clarify whether they have reservations as data owners, would you support the
proposal of adding these in the publications? Please can responses be sent by Wed 17[th] so we can begin work for
this if agreed.'

33. There is no evidence as to what, if anything, happened with that proposal between 11 May 2023 and 22 June
2023.

34. The email of 22 June 2023, sent at 15.33 the day after the request has been received on 21 June 2023, reads
as follows:

**“Subject: RE: FOI 76963 - (M Esslemont) - 2023-06-21 - (PSG)**

@SCA FOI – I've just spoken to who has confirmed that there is an intention to publish recon data inclusive of the
time period asked by the requester.”

35. On the basis of that email, it is clear that by 15.33 on 22 June 2023 there was a settled intention to publish the
requested data. The email was generated as a result of the request by the appellant. We can infer that the
discussion with [redacted] referred to in the email also took place as a result of the request by the appellant.

36. What cannot be deduced or inferred from that email is that the settled intention to publish, that was
communicated to the sender by [redacted], had already been reached by the time the request was made.

37. The Commissioner made very clear to the Home Office that it needed to provide evidence that there was a
settled intention to publish the requested information prior to the request being received. This could have been in
the form of emails, or other documents, or even a short statement from one of the relevant individuals. The
evidence produced by the Home Office does not, in our view, demonstrate that the intention to publish existed
before the request was made on 21 June.

38. On the evidence before us we are not satisfied that the intention to publish already existed by the time the
request was made. We find that the requirement in section 22(1)(b) is not satisfied, and the Home Office was not
entitled to rely on the exemption. The appeal is allowed.

39. Given that the requested information was published in November 2023, we have determined that we should
exercise our discretion not to order the Home Office to take any steps.

Signed Sophie Buckley       Date: 22 April 2024

Judge of the First-tier Tribunal

Promulgated        Date: 25 April 2024

**End of Document**


-----

# Esslemont v The Information Commissioner

_[[2024] UKFTT 333 (GRC)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6BXD-T983-RTBD-B0CB-00000-00&context=1519360)_

**Court: UK First-tier Tribunal**
**Judgment Date: 25/04/2024**

# Catchwords & Digest

**INFORMATION - REQUEST FOR INFORMATION – WHETHER INTENTION TO PUBLISH EXISTING**

The First-tier Tribunal (General Regulatory Chamber) (the FTT) allowed the appellant’s (E’s) appeal
against the respondent Commissioner’s decision notice (DN) which held that the Home Office had been entitled to
[rely on s 22(1) of the Freedom of Information Act 2000. E was the Director of After Exploitation, a small organisation](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61F0-TWPY-Y1DK-00000-00&context=1519360)
established to support survivors of modern slavery. The request was for National Referral Mechanism statistics.
The requested information had formed part of statistics later published by the Home Office. The Home Office
refused to provide the information relying on s 22 of the Act on the basis that the requested information had been
intended for future publication and the public interest favoured maintaining the exemption. The issue was whether
the information held, at the relevant dates, was with a view to publication at some future date. The FTT held that
based on the evidence it had not been satisfied that the intention to publish had already existed by the time the
request had been made. There was an email which demonstrated that there had been a proposal to include
reconsideration data in future publications. It was clear from that email that there had not yet been a settled
intention to publish that data. Therefore, the requirement in s 22(1)(b) was not satisfied, and the Home Office had
not been entitled to rely on the exemption.

# Cases considered by this case

Montague v Information Commissioner and another; Department for International
Trade v Information Commissioner and another

_[[2022] UKUT 104 (AAC), [2023] 1 WLR 1565](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:68Y7-2BH3-S7C0-22TF-00000-00&context=1519360)_
Approved

**End of Document**


13/04/2022

UKUT


-----

