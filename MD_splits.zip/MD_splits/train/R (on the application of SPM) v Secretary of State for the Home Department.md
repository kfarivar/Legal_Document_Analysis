# R (on the application of SPM) v Secretary of State for the Home Department

 [2023] EWCA Civ 764

Court of Appeal, Civil Division

Lord Justice Stuart-Smith, Lord Justice Snowden and Lady Justice Whipple

4 July 2023Judgment

**Alex Goodman KC and Miranda Butler (instructed by Duncan Lewis Solicitors) for the Appellant**

**Thomas Roe KC and Rowan Pennington-Benton** (instructed by the Treasury Solicitor) for the
**Respondent**

Hearing dates : 16-17 May 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

LADY JUSTICE WHIPPLE:

Introduction

[1. This is an appeal against the judgment of Lang J ([2022] EWHC 2007 (Admin)) dismissing claims for](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:661J-FTX3-GXF6-8561-00000-00&context=1519360)
judicial review brought by SPM, the appellant, against the Secretary of State for the Home Department
(“SSHD”).  There was originally a second claimant, Women for Refugee Women (“WRW”), a charity which
supports refugee women, but WRW has played no part in this appeal.

2. The appellant's claim centres on complaints that there was a real risk that her common law rights of
access to justice were infringed by what she says were inadequate arrangements for in-person legal visits
for detainees at Derwentside Immigration Removal Centre (“Derwentside”) from its opening in December
2021 to 30 June 2022, after which the arrangements changed. She says that her detention at Derwentside
was rendered unlawful because of the existence of a real risk of breach of her rights.  She advances her
claim on her own behalf and on the basis that a judgment in her favour would necessarily apply to other
women held at Derwentside in the relevant period, although she does not in any formal sense represent
the other women. By way of relief, she seeks declarations that her right to effective access to justice was
unlawfully compromised and that in consequence she was unlawfully detained. She also seeks
declarations to similar effect in relation to all the other women who were detained at Derwentside during
the relevant period. She seeks damages for false imprisonment.

3. Permission to appeal was granted by Andrews LJ on the papers on the single ground that Lang J had
failed to apply anxious scrutiny or give reasons for certain of her conclusions. Andrews LJ refused
permission for SPM's other grounds of appeal. The case had originally involved claims of direct and
indirect discrimination but those were rejected by the judge and have now fallen away.

The Facts

SPM's immigration history


-----

4. SPM was born on 28 December 1974. She is South African. She came to the UK on 5 December 2018
on a visitor's visa which was valid until 6 May 2019. Her native language is Zulu. She has limited
knowledge of English. She claimed asylum on 22 February 2019. Her claim was refused by the SSHD on
29 February 2020. Her appeal to the FTT was dismissed on 9 November 2021. Her appeal rights were
exhausted on 24 November 2021.

5. Lang J recorded the following background in relation to the appellant's immigration and detention
history, with some small amendments:

“14. According to SPM, she was the victim of physical and mental abuse at the hands of her stepmother,
and forced to work from the age of 12 years. She was raped by her uncle. At the age of 14 or 16 she
entered into an arranged marriage with a man called Joshua, who forced her to work as a prostitute, and
act as a servant to his other wives. She escaped from this forced marriage and met a man called Samuel
who was the leader of a criminal gang. He and members of his gang subjected her to physical, mental and
sexual abuse. In 2014, SPM was stabbed by Samuel in the abdomen and has scarring as a result. In 2015
SPM was shot in the head by Samuel, which caused her to suffer from epilepsy and hearing impairment.
She now requires hearing aids and struggles to hear on the telephone. After the shooting, she went into
hiding, but she was followed and threatened by Samuel and his men.

15. In the FTT appeal, SPM was represented by [solicitors and counsel]. FTT Judge Lebasci concluded
that SPM was not a credible witness and the evidence did not support a finding that SPM had been a
victim of forced labour, forced marriage and violence. He dismissed her asylum and human rights appeal.
In the course of his decision the FTT Judge said:

“47.9 It is the Appellant's evidence Samuel stabbed her with a knife in 2014 and she was admitted to
hospital for two months. She claims to have provided medical evidence and says she is unable to provide
anything else. At the hearing, the Appellant produced a photograph of the scar which she says she has
been left with as a result of this injury. The medical evidence provided…appears to relate to a gunshot
injury in 2015 and therefore does not assist me in relation to the alleged incident in 2014. No evidence from
a health care professional in the UK has been provided regarding the existence of any scar which the
Appellant has or its likely cause.”

16. On 24 January 2022, SPM was detained when reporting in accordance with her reporting conditions,
and she was served with liability to removal papers (form RED.0001). According to SPM, her solicitors had
not informed her of the outcome of her appeal, despite her frequent attempts to contact them. Removal
directions were set for 7 February 2022.

17. On 27 January 2022, SPM was transferred to Derwentside. She claims she called [her solicitors] but
she could not reach them. After her arrival SPM was given a pamphlet which explained that she could ask
for legal advice. She claims she rang the legal advice telephone number in the pamphlet but did not
receive any response. She claims she asked the officers at Derwentside to assist her in finding a solicitor
but they did not do so. On 29 January 2022, SPM asked her partner to bring her medication and batteries
for her hearing aids. When he arrived at the detention centre he was refused entry. This led to SPM feeling
suicidal and being placed on an open Assessment Care in Detention and Teamwork (“ACDT”) plan (for
detained individuals at risk of suicide or self harm).

18. On 31 January 2022, still without any legal assistance, [SPM] wrote to the [SSHD] asking her to
reconsider her case. She explained that she was having difficulty finding a solicitor.

19. On 2 February 2022 a report under Rule 35 of the Detention Centre Rules 2001 (“a Rule 35 report”)
was drawn up by a member of the Derwentside healthcare team. It reported her concern that SPM was a
victim of domestic abuse and torture. On examination, SPM had a number of significant scars which were
consistent with her account. The report summarised her mental and physical health issues.

20. On 4 February 2022, the [SSHD] maintained SPM's detention in response to the Rule 35 report. Also,
on 4 February 2022 the Defendant wrote to SPM maintaining her decision to remove [SPM] to South
Africa. SPM was served with the IS151D Removal Papers and Immigration Factual Summary.


-----

21. On 4 February 2022, SPM was referred to Duncan Lewis Solicitors by a member of WRW who had
spoken to her on the phone. Ms Lily Parrott, a solicitor at Duncan Lewis, immediately contacted SPM by
telephone. However, SPM and Ms Parrott had difficulty communicating because of SPM's hearing
impairment and limited English (no Zulu interpreter was available). As a result, Ms Parrott was unable to
obtain full instructions. At Ms Parrott's request, a member of IRC staff printed out the authority and legal
help forms and helped SPM scan and send the signed documents to Ms Parrott, along with the notice of
liability to removal, and the Rule 35 report. Once Ms Parrott realised that SPM had a hearing impairment,
she was able to take further instructions from SPM on the telephone more effectively on several occasions
by speaking loudly directly into the telephone microphone which increased SPM's comprehension. Ms
Parrott also requested and received further relevant documents from the Home Office.

22. On 6 February 2022, Ms Parrott sent an urgent pre-action letter to the [SSHD] which (among other
matters) identified clear trafficking indicators which they submitted required investigation and referral into
the National Referral Mechanism (“NRM”).

23. On 6 February 2022 the [SSHD] maintained the removal directions and moved SPM to Colnbrook IRC
(near Heathrow airport), in preparation for her departure on 7 February 2022. On 7 February 2022, in
response to the pre-action correspondence from Ms Parrott, the [SSHD] cancelled the removal directions
for that day.

24. Ms Parrott made an appointment to see SPM in person on 11 February 2022 at Colnbrook. However,
the appointment was cancelled as SPM was moved back to Derwentside by the [SSHD] on 10 February
2022 without prior notice. A medico-legal visit by an expert to document her scarring also had to be
cancelled because there was no expert available who could travel to Derwentside.

25. On 10 February 2022, SPM was referred into the NRM for identification as a victim of trafficking. On 16
February 2022 the [SSHD] made a positive Reasonable Grounds decision in relation to SPM, identifying
her as a potential victim of modern slavery. Her Conclusive Grounds decision is still awaited.

26. On 25 February 2022, SPM was released on immigration bail.”

Derwentside

6. Lang J recorded the background facts relating to Derwentside at [27]-[41] and the following paragraphs
summarise her findings, with some small additions.

7. Derwentside is a women-only immigration removal centre (“IRC”) situated in County Durham, around 15
minutes' drive from Newcastle. The SSHD announced her intention to open Derwentside as an IRC on 1
March 2021. It had previously been a secure training centre which could relatively easily be converted for
use as an IRC. Female detainees had previously been held at Yarl's Wood in Bedfordshire, but that was
now to be used for male detainees following the closure of Morton Hall IRC.

8. An equality impact assessment (“EIA”) on Derwentside was published on 23 November 2021. It was
noted in that EIA that:

“For individuals who do not have a fluent command of English and are seeking advice regarding their
detention and/or removal from UK, the potential loss of access to organisations offering advocacy services
who are working with women detained in other IRCs could place such detained persons at a disadvantage,
potentially resulting in indirect discrimination. For some people detained it may be easier to receive such
advice face-to-face from a speaker of their first language, rather than over the telephone or internet. The
Legal Aid Agency (LAA) will set up a Detained Duty Advice scheme on the same basis as in other IRCs,
and the LAA is tendering for a service comparable with that currently available at Yarl's Wood. Residents
and legal providers will have access to purposed designed interview suites and high speed wifi.”

9. A note of a meeting of the Detention Sub-Group held on 29 June 2021, involving representatives of the
SSHD and various stakeholders, records discussion about the Detained Duty Advice Scheme (“DDAS”)
that would be put in place at Derwentside by the LAA. A representative of the SSHD (Frances Hardy) said
this:


-----

“FH explained that videoconferencing was a contingency and agreed that face to face was a priority”.

10. On 22 July 2021, the LAA published an invitation to tender for the DDAS at Derwentside, including the
following requirement:

“1.32 Applicants must be able to deliver advice through DDAS face to face in person at Derwentside IRC.”

11. On 16 November 2021, the LAA announced that the procurement process for DDAS at Derwentside
had been cancelled because insufficient compliant tenders had been received. On the same date, the LAA
announced that from 1 January 2022 the LAA would continue its existing contingency arrangements until
June 2022. Those contingency arrangements involved existing providers from Yarl's Wood IRC providing
an additional six months' provision at Derwentside. The contingency arrangements involved provision of
two DDAS surgeries a week. The default arrangement was to conduct the surgery by telephone, but
video-conferencing arrangements were also available; in-person appointments could be requested by
detainees but there was no requirement for providers to meet that request. The judge found that in practice
providers did not do so ([33]).

12. The first detainees were moved to Derwentside on 28 December 2021.

13. By 23 June 2022 there had been 44 DDAS surgeries provided at Derwentside under the contingency
arrangements. 109 appointments had taken place within those surgeries, 63 of which took place by videoconference, the rest by telephone. Although there were no in-person visits under DDAS while the
contingency arrangements were in place, there were 5 or 6 in-person visits outside the DDAS scheme
within that period. By way of comparison with other IRCs at the same time: in the period 1 January 2022 to
13 June 2022, which is the period for which data exists, there were no in-person DDAS visits at three other
IRCs (Colnbrook, Harmondsworth and Tinsley House) but there were in- person DDAS visits at Yarl's
Wood and Brook House IRCs; there is no recorded data for Dungavel IRC because the DDAS does not
operate in Scotland.

14. The LAA re-tendered for DDAS providers for Derwentside in March 2022. That tender process was
successful in identifying three firms who were awarded contracts to commence from 1 July 2022. Those
firms were located in Bradford, Coventry and Hounslow. The appellant does not suggest that the
arrangements in place after 1 July 2022 were unlawful. The appeal is concerned only with the period
before then (the “relevant period”), from 28 December 2021 to 30 June 2022.

The Power to Detain

15. The SSHD detained the appellant under powers contained in paragraph 16 of Schedule 2 to the
Immigration Act 1971. Paragraph 18(1) of the same schedule provides that:

“Persons may be detained under paragraph 16 above in such places as the Secretary of State may direct
(when not detained in accordance with paragraph 16 on board a ship or aircraft)”.

[16. The Detention Centre Rules (SI 2001/238) preserve a detainee's right to establish and maintain](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW7-S3R0-TX08-H0XH-00000-00&context=1519360)
relations with persons and agencies outside the detention centre (paragraph 26) and provide as follows so
far as meetings with legal advisers and representatives are concerned:

“30. The legal adviser or any representative of any detained person in legal proceedings shall be afforded
reasonable facilities for interviewing him in confidence, save that any such interview may be in sight of an
officer”.

Legal Aid Provision

17. The legislative scheme for legal aid is set out in the _[Legal Aid, Sentencing and Punishment of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C45S-00000-00&context=1519360)_
_[Offenders Act 2012 (“LASPO”). Section 1 provides that the Lord Chancellor must secure that legal aid is](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:55JM-GYP1-DYCN-C45S-00000-00&context=1519360)_
made available in accordance with that part of the Act. Section 2 provides that the Lord Chancellor may
make such arrangements as he considers appropriate for the purposes of carrying out his functions.
Under section 4, the LAA carries out functions on behalf of the Lord Chancellor and the Director of Legal
Aid Casework. Civil legal services which come within the ambit of legal aid are described in sections 9 and


-----

10 which in turn cross-reference to Part 1 of Schedule 1 of LASPO. Even where civil legal services do not
fall within Part 1 of Schedule 1, there may be exceptional case funding available. Provision of legal aid is
usually subject to a means and a merits test: sections 11 and 21.

18. Section 27 of LASPO provides as follows:

“27 Choice of provider of services etc.

(1) The Lord Chancellor's duty under section 1(1) does not include a duty to secure that, where services
are made available to an individual under this Part, they are made available by the means selected by the
individual.

(2) The Lord Chancellor may discharge that duty, in particular, by arranging for services to be provided by
telephone or by other electronic means.

…”

19. The LAA's 2018 Standard Civil Contract divides civil legal aid into two main categories of work:
controlled work and licensed work. Providers are given delegated authority to start controlled work without
having to apply to the LAA. The providers can decide whether the means and merits tests are satisfied
and grant funding accordingly. Where a provider opens a controlled work case, it is described as a “matter
start”. Licensed work requires authorisation from the LAA, by an application for a legal aid certificate.

20. DDAS services form part of the Immigration and Asylum Specification of that 2018 Standard Civil
Contract. Paragraphs 8.117 to 8.122 of that Specification provide for advice of up to 30 minutes provided
as part of a DDAS surgery without regard to the client's financial eligibility. The purpose of that preliminary
advice session is to ascertain the basic facts of the matter and to make a decision as to whether the matter
requires further investigation or action. The provider must decide at the end of that 30-minute session
whether the client is entitled to legal aid as part of a controlled work case; if so, the provider can log a
matter start for that client and offer further legal services covered by legal aid.

The Judgment

21. There is no challenge to the accuracy or fairness of the judge's summary of the claimants' evidence at

[43]-[50]. The claimants relied on the following evidence, which I summarise from the judgment:

a. Dr Jo Wilding, a researcher on immigration and asylum, said that there were 12 legal aid offices in the
area around Derwentside and that demand in that area, once Derwentside opened, would outstrip
capacity. Dr Wilding had interviewed solicitors providing services remotely who had reported that it was
more difficult to obtain a client's paperwork when working remotely and that it was important to meet in
person at the outset, in order to build a relationship of trust with the client ([45]).

b. Dr Juliet Cohen, an independent forensic physician, said that in-person legal visits were essential for
the detainees at Derwentside, many of whom were vulnerable women who were likely to be survivors of
trafficking, sexual exploitation, domestic violence and gender-based violence. She said that many of these
women would have difficulty in disclosing past experiences, and that in-person visits would facilitate better
trust, rapport, communication and disclosure, as well as providing support to manage distress, flashbacks
and potential crises. Dr Cohen's view was that a sensitive interviewer who could offer empathy and support
in response to non-verbal cues would obtain more disclosure ([46]) and that a person with a disability may
be further disadvantaged if she was unable to have an in-person assessment ([47]).

c. Ms Shalini Patel, the supervising solicitor at Duncan Lewis, agreed with these observations, based on
her own experience ([48]).

d. Dr Gemma Lousley, policy and research coordinator at WRW, had spoken to a number of detainees at
Derwentside about their experiences in trying to access legal services ([49]).

e. Ms Theresa Schleicher, a casework manager for Medical Justice, identified some systemic flaws in the
assessment and safeguarding of detainees at IRCs including Derwentside relating to the Rule 35 and
Adults at Risk Policy ([50]).


-----

22. The judge referred to the statutory framework for legal aid contained in LASPO and the regulations
made under that Act ([51]-[67]). She described the DDAS scheme in outline, noting that £360 is the
standard fee for advising 5 or more clients and £180 is the standard fee for advising fewer than 5 clients.
Providers are not paid for travel or waiting time when attending a DDAS surgery, but disbursements,
including travel expenses and interpreter expenses, are recoverable. Around 20-25% of detainees seen at
a DDAS clinic result in a controlled work matter start. Where that happens, travel time and travel expenses
are paid as long as they are reasonable, and guidance from the LAA indicates that round trips of more than
5 hours will not be considered reasonable unless clearly justified ([67]-[69]).

23. The judge also referred to the evidence of Mr Toufique Hossain, director of public law and immigration
at Duncan Lewis, solicitors for the appellant, who described the financial pressures on legal aid solicitors
and the concerns about remuneration for travel time and expenses when visiting Derwentside [70].

24. The judge turned to Ground 1 by which the claimants argued that their right of effective access to
justice encompassed an unimpeded right to in person legal advice, arguing that in practice that is
unavailable at Derwentside because it is located too far away from the small pool of solicitors who provide
legal aid advice and representation in immigration and asylum cases ([71]). She noted the SSHD's
arguments: that she was entitled to use Derwentside as an IRC, that there was no fundamental common
law right to be provided with legal aid, that the provision of legal services by remote means was lawful
under section 27 LASPO, that the Lord Chancellor had not been joined as a defendant to these
proceedings, and that there was no real risk of denial of access to justice ([73]-[76]).

25. She recorded the claimants' confirmation that they did not allege any breach of duty by the Lord
Chancellor ([82]). She set out key passages of the various cases to which she had been referred [85]-[94].
She rejected the SSHD's submission that there was no fundamental common law right to be provided with
legal aid, saying that “the law has evolved since Witham” (a reference to R v Lord Chancellor ex p Witham

[1998] QB 575) and that “a lack of legal aid provision can, in certain circumstances, (for example, where a
person is held in detention), constitute an obstacle to the fundamental common law right of access to
justice” ([95]).

26. The judge held that the SSHD's decision to transfer women detainees from Yarl's Wood to
Derwentside was a lawful exercise of her discretion ([99]).

27. She addressed the claimants' challenge to the contingency arrangements. She noted that at all times,
detainees were permitted to receive legal advice from privately paid or legal aid solicitors, in person, via
telephone or via video-conference. She noted that the SSHD facilitated DDAS surgeries and the LAA
provided such surgeries, with legal aid available for controlled or licensed work on behalf of detainees on
standard LAA terms ([105]-106]).  She stated her conclusion on the adequacy of the arrangements for
meetings during the relevant period in the following terms:

“106. In my judgment, the provision of legal advice via telephone or video-conference instead of in-person,
for a limited 6 month period, delivered by existing experienced providers from Yarl's Wood, did not amount
to a denial of effective access to justice in “real world conditions”. Whilst I accept that some users have a
strong preference for in-person meetings, which should be accommodated where possible, the quality and
convenience of modern video-conference facilities is very good, and comparable to an in-person meeting.
The video conference facilities, with high speed wi-fi, were newly installed at Derwentside. Alternatively,
the telephone is an adequate means of communication for most people, though I accept it may be less
effective for those with disabilities and mental health issues, and where a detainee has limited knowledge
of English. I take into account the criticism made in the Claimant's evidence of unhelpful members of IRC
staff and solicitor providers, but I consider that these are management issues for the Defendant and the
LAA to address, rather than this Court.”

28. The judge rejected the claimants' submission that there was a hindrance or impediment to the right of
access to a lawyer which interfered with the common law rights of the women detained at Derwentside
when the contingency arrangements were in place ([107]). She noted that the SSHD had planned to
provide the same legal services as had been on offer at Yarl's Wood, including in person visits ([108]) but
that tender was unexpectedly unsuccessful ([109]) During the Covid 19 pandemic in person DDAS


-----

surgeries at IRCs had been largely replaced by remote appointments, as a way of protecting detainees and
complying with government advice and legal restrictions ([109]). The SSHD made the decision to move the
detainees to Derwentside in the knowledge that the Lord Chancellor, acting through the LAA, could and
would implement contingency arrangements for six months until a second tender process was concluded
([110]). She held that those contingency arrangements were a lawful discharge of the Lord Chancellor's
duties and powers to deliver legal services under LASPO using electronic means where necessary ([110]).

29. By way of disposal, the judge dismissed the claimants' claim on those grounds that she had addressed
substantively. She adjourned other parts of the case, which had not been addressed and were specific to
the appellant's own circumstances, for further argument (those parts are not relevant to this appeal and
remain adjourned pending the outcome of this appeal). She refused permission to appeal.

Submissions

30. I am grateful to all counsel and their legal teams for all the assistance that was given to the court in
writing and by oral submissions. The following summarises their submissions.

Appellant

31. Mr Goodman KC and Ms Butler represent the appellant. They submit that the fundamental right of
access to justice incorporates a right to access in-person (face-to- face) legal advice where that is required
for the effective exercise of the right. The detention of women at Derwentside creates a real risk of
abrogating the detainees' right to effective legal advice and representation. The risk consisted in the
barriers to disclosure of sexual violence and other trauma when not face to face with a lawyer, the difficulty
in building rapport over remote communication links, the greater difficulty for lawyers in identifying
vulnerability and assisting vulnerable clients when advising remotely and the additional impediments
experienced by those who are disabled and unable to communicate by telephone. These are all
foreseeable problems when offering legal advice to the particularly vulnerable cohort of women detained at
Derwentside. The vulnerability of this group of women finds recognition in the SSHD's own policy on
**_Modern Slavery (Modern Slavery: Statutory Guidance for England and Wales) v 2.9, para 13.18, and to_**
similar effect the Equal Treatment Bench Book (February 2021 edition) notes at para 22 the difficulties for
some litigants who lack English as a first language in being involved in remote hearings. The lack of
availability of in-person legal services during the relevant period at Derwentside was the “tipping point”
because, in combination with the distant location of Derwentside, the extreme vulnerability of the women
moved there and the fact that legal services in the field of immigration and asylum are already stretched, it
created a real risk that women in this cohort would be prevented from having effective access to justice.

32. Given that this is a challenge concerning fundamental rights (including common law rights) the court
must apply anxious scrutiny to the material before it following _R (MN) v SSHD (AIRE Centre_
_intervening)[2020] EWC Civ 1746, [2021] 1 WLR 1956: “every factor which tells in favour of the putative_
victim's case must be taken into account” (per Underhill LJ at [244]). Lang J failed to do that, or to explain
why she did not accept the evidence which was put before her from the claimants' witnesses about the
additional difficulty of providing legal services remotely to this group of vulnerable women.

33. Section 27 is a general power only. The principle of legality explained in R v Secretary of State for the
_Home Department, ex p Simms [2000] 2 AC 115prohibits any impediment to the right of access to a lawyer_
without clear authorisation by Parliament, which section 27 does not constitute. Therefore, section 27 does
not stand in the way of the appellant's arguments.

34. The existence of an impediment to the right of access to a lawyer rendered the detention of the women
at Derwentside during the relevant period unlawful. The power to detain is subject to observance of
detainees' fundamental rights, and in this case the breach of those rights invalidated the detention. The
appellant relied on the following passage from R (Lumba) v SSHD [2011] UKSC 12; [2012] 1 AC 245per
Lord Dyson JSC at [65]:

“65. … All that a claimant has to prove in order to establish false imprisonment is that he was directly and
intentionally imprisoned by the defendant, whereupon the burden shifts to the defendant to show that there


-----

was lawful justification for doing so. As Lord Bridge said in R v Deputy Governor of Parkhurst Prison, Ex p
_Hague_ [1992] 1 AC 58, 162C-D: “The tort of false imprisonment has two ingredients: the fact of
imprisonment and the absence of lawful authority to justify it.”

Respondent

35. Mr Roe KC and Mr Pennington-Benton act for the SSHD. They invite this court to uphold the judge's
factual conclusion at [106] of the judgment, arguing that the judge was entitled to reach that conclusion, on
the basis of the evidence before her, and this court should not interfere. But they take a series of more
fundamental and logically prior points against the appellant, which were not addressed by the judge. They
argue that this claim is misconceived because there is no fundamental right to in-person legal services.
Further, they argue that the provision of legal advice by remote means is consistent with section 27(2)
LASPO and that the appellant's case amounts to a collateral attack on that provision; in any event, the
principle of legality applies in the SSHD's favour because section 27(1) and (2) confront squarely the issue
of how legal aid services are to be provided taking economic and political considerations into account, and
it is not open to the appellant to argue that the provisions should be interpreted so as to carve out the rights
for which she argues in this appeal. Further or alternatively, even if there was a breach of the appellant's
[common law rights, the appellant's detention under the Immigration Act 1971 remained lawful at all times.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)

36. By a Respondent's Notice, the SSHD advanced a challenge to the judge's conclusion at [95] that a
lack of legal aid provision can, in certain circumstances, constitute an obstacle to the fundamental common
law right of access to justice. Mr Roe did not press that challenge at the hearing. I need say nothing further
about that notice.

Discussion

Issues

37. The parties' various arguments can, in my judgment, be gathered into the following headings to be
addressed in the following sequence:

(1) **Collateral attack on LASPO: whether the appellant is, in substance, mounting an impermissible**
collateral attack on LASPO.

(2)  Real risk of breach: whether the judge erred at [106] and if so, whether that error was material to her
conclusion.

(3)  Unlawful detention: whether, if the appellant makes out her case on breach of common law rights,
she is entitled to the remedies sought.

Law

38. Mr Goodman took the court to a number of authorities to explain the approach he invited this court to
take to the central issue, on his case, of whether the appellant's common law rights had been breached.
The judge reviewed many of these authorities in her judgment. In this court, there was no real dispute on
the approach to be taken. I shall therefore summarise Mr Goodman's submissions into the following
propositions which I understand to be agreed, at least for the purposes of this appeal:

a. The relevant test is whether the actions of the SSHD created a real risk that persons will effectively be
prevented from having access to justice (R (UNISON) v Lord Chancellor (EHRC intervening) Nos 1 and 2

_[2017] UKSC 51, [2020] AC 869per Lord Reed JSC at [87])._

b. To the extent that the right of unimpeded access to a court encompasses a prisoner's right of access to
a solicitor, the right will be breached by any rule which creates an impediment to the free flow of
communications between a solicitor and a client (based on _R v Secretary of State for the Home_
_Department, ex p Leech (No 2) [1994] Q.B. 198 at 210per Steyn LJ at p 1134G-p1135E)._


-----

c. The right of access to justice means not merely theoretical but effective access in the real world
(UNISON, ibid, at [85] and [93]; and _R (FB (Afghanistan) v SSHD [2020] EWCA Civ 1338; [2021] Q.B._
185per Hickinbottom LJ at [92]).

d. The court has to make an overall evaluative assessment whether this legal standard is met _(R (A) v_
_Secretary of State for the Home Department [2021] UKSC 37, [2021] Q.B. 185per Lord Sales JSC and_
Lord Burnett CJ at [80]).

e. The principle of anxious scrutiny as it was explained in _R (MN) v Secretary of State for the Home_
_Department applies when reaching that evaluative assessment._

Issue (1): Collateral Attack on LASPO

39. Mr Goodman disavowed any challenge to LASPO. He accepted that the Lord Chancellor had
discharged his obligations under LASPO by means of contingency arrangements put in place for the period
in question. Mr Goodman said this case was a challenge to the SSHD's decision to place women at
Derwentside at a time when the provision of legal services at that IRC, whether privately paying or publicly
funded, did not in reality extend to face-to-face meetings.

40. Mr Goodman's case requires a bit of unpacking. First of all, it is necessary to have in mind what
provision for legal advice and representation was in fact available to these women during the relevant
period, in order to frame the appellant's case that that provision was inadequate. During this period, there
were regular DDAS surgeries for detainees. Those surgeries delivered legal advice free of charge or
inquiry as to means. Solicitors could take on controlled or licensed work if they thought there was merit in
the case following a DDAS appointment and subject to the ordinary legal aid rules. There was funding
available for legal visits, to include travel, if the DDAS contact developed into a controlled matter. Legal
visits were not prohibited and some legal visits did in fact take place. The appellant's case focusses on the
30-minute triage appointments undertaken as part of DDAS, which were in practice remote-only because
funding was not available within the DDAS funding model for travel or waiting time and because
Derwentside was situated a long way from the offices of solicitors who participated in the contingency
arrangements. The appellant's case boils down to a proposition that in order to avoid the real risk of
breach of her fundamental rights (in turn rendering their detention unlawful), there needed to be an option
for face-to-face legal visits as part of or in addition to DDAS and that in the absence of such an option,
there was a real risk of breach of her fundamental right of access to justice (and consequent unlawful
detention). It is the soundness of that proposition which lies at the heart of this appeal.

41. Secondly, although Mr Goodman talked about privately paid legal advice, there is no evidence to
suggest that the women at Derwentside routinely instructed solicitors privately. From all I have seen in this
case, and judged by the tenor of Mr Goodman's submissions, I infer that most of those women lacked the
means to pay for private representation. Certainly, throughout the period in question, the appellant lacked
funds to pay her lawyers privately. It follows, in my view, that Mr Goodman's challenge does not concern
the availability of privately funded legal visits. It is about the provision of legal services to a cohort of
vulnerable women who are not in a position to pay for those services.

42. Thirdly, and following on from the last point, the way in which the state provides legal aid and
assistance to those who lack funds is by means of legal aid. Although Mr Goodman argued that there
were other ways which did not involve legal aid services to arrive at a satisfactory outcome for the women
at Derwentside in the relevant period, I am not persuaded that those suggestions are realistic. It was, for
example, said that the SSHD could have procured on-site pro bono legal advice, or the services of a local
legal charity such as Citizens Advice, to give legal advice face to face where that was requested. But the
women detainees at Derwentside, by Mr Goodman's own submission, needed expert immigration and
asylum advice from lawyers who were in a position to take their cases forward if they had merit. I doubt
that legal assistance from these other sources would in practice have been capable of plugging the gap in
provision which Mr Goodman identified.  It was suggested, alternatively, that the SSHD could have
screened the women being placed at Derwentside to ensure that those who were acutely vulnerable were


-----

not moved there. But on the appellant's own evidence, women detainees as a group are often reluctant to
disclose their past experiences, which means that screening could not be an answer.

43. I conclude that the appellant's proposition (as I have characterised it at para 40 above) necessarily
involves an assertion that the contingency arrangements _for legal aid were insufficient to meet these_
detainees' common law rights. The solution would have been a “top up” in funding to make the provision of
face-to-face DDAS appointments at Derwentside economically viable for the specialist practitioners who
had contracted with the Legal Aid Agency to provide those contingency services remotely.

44.  Fourthly, though, LASPO governs the provision of legal aid. Section 1 provides that the Lord
Chancellor is required to secure legal aid “in accordance with this Part” and section 2 gives the Lord
Chancellor discretion to make such arrangements as he considers appropriate for the purposes of carrying
out his functions under this Part. Within that Part, section 27(1) provides in terms that the individual cannot
specify the means by which legal services are to be provided, and section 27(2) provides in terms that
legal services can be provided by telephone or other electronic means.  These provisions govern the way
in which the state, by the Lord Chancellor, who in turn acts through the Director of Casework and his staff
at the LAA, provides legal aid.

45. Fifthly, and building on these points, it is clear that the appellant's complaint, properly understood, is
indeed a challenge to the provision of legal aid services in the relevant period to the women at
Derwentside. It is a failure in the sufficiency _of legal aid that underpins the claim for unlawful detention._
That presents the appellant with a number of obstacles. First, at a practical level, the appellant has not
named the Lord Chancellor as a respondent to the claim, even though it is the Lord Chancellor who has
been made responsible, by statute, for the provision of legal aid, and it is he who must answer for alleged
deficiencies in the provision for any individual or group. Secondly, there are contradictions in the
appellant's case: she disavows any attack on LASPO while at the same time suggesting that in person
appointments are required, which runs contrary to section 27(2); she says that she should be able to have
legal services delivered in a particular way, which runs contrary to section 27(1) and the discretion vested
in the Lord Chancellor by section 2. Put shortly, her arguments cannot be adjudicated without considering
the terms of the statute. Thirdly, however, in the absence of some EU or human right being engaged to
support her position (which is not suggested here), the default position is that the court will not review the
terms of primary legislation, see eg R (Countryside Alliance) v Attorney-General [2007] UKHL 52, [2008] 1
AC 719per Lord Brown at [134]-[135].  Thus, the appellant's claim would seem to be destined for failure.

46. Mr Goodman sought to skirt this last difficulty by arguing that the principle of legality required LASPO
to be interpreted as being subject to the appellant's fundamental common law rights as she asserted them
to be, placing particular reliance on Lord Hoffmann's statement that “Fundamental rights cannot be
overridden by general or ambiguous words” in _ex p Simms at p 131 E-G. I doubt that the provisions of_
section 27 could sensibly be viewed as being “general or ambiguous”, but there is anyway an
insurmountable obstacle to the resolution of that debate: without the provisions of LASPO being put in
issue in this case, and without the Lord Chancellor who is responsible for LASPO being before the court,
the court is simply not in a position to consider the appellant's arguments.

47. I agree with Mr Roe that this challenge is misconceived. The right parties are not before the court and
a challenge to the legislation has not been made even though such a challenge predicates the appellant's
claim. This appeal must fail.

48. I will deal with the remaining points shortly. They were fully argued before us and warrant some
response, even if the outcome of the appeal is already determined.

Issue (2): Real Risk of Breach

49. The judge concluded at [106] that the quality and convenience of video-conferencing facilities was very
good and “comparable” to an in-person meeting, and that telephone was an adequate means of contact for
most people (see para 28 above). The appellant challenges those findings, on the basis that they lack
reasons and they expose a failure to apply anxious scrutiny. This is the ground on which the appellant has
permission to appeal.


-----

50. The appellant's case was based on the assertion that video-conferencing and telephone are inferior
means of contact, by comparison with in person meetings. At [106], the judge seems to have rejected that
assertion. With respect to this very experienced judge, I am hampered in my understanding of her
conclusions by her lack of reasons for rejecting the appellant's evidence – as it appears she did.

51. In those circumstances, I have reviewed the evidence which was before the judge to reach my own
conclusions. In addition to the evidence outlined above (paras 21 and 23), I have also read the evidence
of Eleanor Druker, senior development manager at the LAA, filed on behalf of the SSHD, who explains the
background to the contingency arrangements being put in place.

52. I would be willing to accept, based on the claimants' evidence taken as a whole, which evidence the
SSHD does not challenge, that it is more satisfactory for women in immigration detention, some of whom
are likely to be vulnerable, to have available a facility or option for in-person meetings with their solicitors
as well as remote options; for some of these women, video-conferencing or telephone as a means of
communication is not as effective as meeting in person, at least for some meetings with their solicitors
some of the time. My view should come as no surprise, because it coincides with the view expressed by
an official at the meeting on 29 June 2021 and with the LAA's original tender which included face-to-face
visits as part of the requirements (see paras 9 and 10 above). I do not, however, accept that such inperson visits are essential in order for a solicitor to provide effective legal advice to their client, and if Dr
Cohen (a medical doctor) was suggesting that, I respectfully disagree (noting that Dr Cohen is not qualified
to speak about how a solicitor should interact with their client, a point she acknowledges at [19] of her
statement).

53. The view reached on the evidence does not however determine the question in this appeal, which is
whether there was a real risk that these women, some or all, were prevented from having effective access
to legal advice during the relevant period. That is a question which turns on the meaning of effectiveness
in the context of the right of access to justice. To determine that question, it is necessary to consider the
scope of the common law right which the appellant asserts, and, specifically, whether it extends to
receiving legal advice in a particular way.

54. We were shown no case which came close to establishing that the lack of facilities to meet lawyers
face to face was in breach of, or created a real risk of breach of, that right of access. The main cases
relied on by the appellant which involved issues of access to a lawyer as part of the right of access to
justice were: R v Secretary of State for the Home Department, ex p Anderson [1984] Q.B. 778, where the
court held that the 'simultaneous ventilation' rule requiring the prison to be told of any complaint by a
prisoner before the prisoner sought legal advice was an impediment to that prisoner's right to unimpeded
access to the courts; _ex p Leech, where the court held that the Secretary of State's statutory powers to_
make rules for the regulation and management of prisons did not extend to a rule permitting the prison
governor to read privileged legal correspondence between a prisoner and his lawyer because that would
impede the free flow of information between them; and _R (Howard League for Penal Reform) v Lord_
_Chancellor (EHRC intervening) [2017] EWCA Civ 244, [2017] 4 WLR 92, where the court held that the_
removal of legal aid from prisoners for certain areas of legal work was unlawful. These cases involve the
removal of an impediment standing in the way of access to or communication with lawyers. _Howard_
_League comes closest to the present case on its facts, but there the issue was the removal of legal aid for_
certain types of work which is different from this case where there is no suggestion of removing legal aid
from any given category of work. None of these cases go so far as to suggest that the means by which
legal aid is delivered is part of the right of access to justice.

55. Further, we were shown no case where the court had directed the state to take the positive step of
“topping up” what was already on offer. To the contrary, where the court was willing to step in, it did so
only to remove the impediment. As examples: in UNISON, the Supreme Court held that the Fees Order
was unlawful because it gave rise to a real risk that it would effectively prevent persons from having access
to justice; in FB, the court declared the Secretary of State's removals policy to be unlawful and quashed it;
in the prison cases, the courts restrained the governors of various prisons from implementing certain
policies or practices which interfered with the prisoner's right of access to the courts (in addition to the


-----

cases mentioned in the preceding paragraph, we were also shown Raymond v Honey [1983] AC 1and R
_(Daly) v Secretary of State for the Home Department [2001] UKHL 26, [2001] 2 AC 532)._

56. In my judgment, the case law offers little support for the appellant's proposition that the right of access
to justice encompasses the medium through which legal services are delivered.

57. The appellant's case is not supported by the legislation either. LASPO confers on the Lord Chancellor
the duty and the power to devise the way in which legal aid services are to be delivered (section 2). It
provides expressly that legal aid services may be provided by remote means (section 27(2)) and that the
individual's preference or choice of means is irrelevant (section 27(1)). These provisions undermine the
appellant's case that she has a fundamental right at common law to legal services delivered in person.

58. I come then to the facts. As already discussed, the detainees did have access to legal advice (through
the DDAS) at all times, and if the matter progressed to a controlled matter, there was funding for in-person
visits (including travel time). During the relevant period, legal visits were not prohibited at Derwentside and
some did take place. I am not persuaded that the lack of an option, in practice, for face-to-face meetings as
part of DDAS constituted an impediment to justice or created a real risk of such an impediment. At the
most, it was a less than ideal way of carrying out initial legal visits for some of the women at Derwentside
for some of the time. The context is relevant: the whole point of DDAS was for the solicitor to form a view
about whether further work was required, and if it was, then the matter proceeded under a different part of
the legal aid funding scheme (as a controlled matter) which included funding for legal visits. While
accepting that the contingency arrangements were not ideal, because they lacked the possibility of face-toface contact, I am not persuaded that this single facet created a real risk of breach of the detainees' rights
of access to justice.

59. In reaching that conclusion, I have not taken account of the temporary nature of the contingency
arrangements or the fact that they reflected the way legal services were provided to detainees in IRCs
during Covid-19 when face-to-face visits were not possible. That is, however, very much part of the
background. It explains the LAA's resort to remote only legal services in early 2022 when many
businesses and institutions were still emerging from pandemic conditions. Ms Druker explains that the
LAA has since the period in question returned to a system which provides for in-person DDAS
appointments in all IRCs, including Derwentside, if requested; that is to the advantage of the detainees in
the IRCs and is, as I understand it, a return to the norm. The judge did take these factors into account
when arriving at her overall view that there was no hindrance or impediment to the right of access to a
lawyer at [107]. Contrary to Mr Goodman's submissions, I think she was entitled to do so as part of her
evaluation of all the evidence before her.

60. It follows that to the extent that the judge made an error in not giving reasons for her conclusion at

[106] or in failing to apply anxious scrutiny to that question, that error was not material to the outcome of
this case. Alternatively, if it was material, I would reach the same conclusion on the totality of the evidence
anyway.

Issue (3): Unlawful detention

61. The appellant seeks declarations that she was unlawfully detained because the power to detain under
the 1971 Act was vitiated by the breach of or risk of breach of her common law rights. Even if I had been
with her on the breach/risk of breach, I would not have granted the relief she sought. It was recognised in
_Lumba_ that not every breach of public law is sufficient to give rise to a cause of action in false
imprisonment. Instead, to render the imprisonment unlawful, the breach in question has to bear on and be
relevant to the decision to detain (see Lady Hale at [207]). Here, the decision to detain is conceptually and
factually separate from the assumed error in the provision of legal services at Derwentside. This is not a
case like Lumba where the public law error goes to the detention itself (in that case, the error consisted of
maintaining a secret policy on the detention of foreign national offenders after their sentences had expired,
a policy which was closely related to the decision to detain in that case). The remedy in this case, if there
was to be one, would surely be limited to declaring a deficiency in the legal provision required to satisfy the
appellant's fundamental rights.


-----

Disposal

62. I would dismiss this appeal.

**LORD JUSTICE SNOWDEN:**

63. I agree.

**LORD JUSTICE STUART-SMITH:**

64. I also agree.

**End of Document**


-----

