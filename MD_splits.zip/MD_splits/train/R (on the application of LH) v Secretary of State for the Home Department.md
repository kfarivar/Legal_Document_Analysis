# R (on the application of LH) v Secretary of State for the Home Department

 [2019] EWHC 3457 (Admin)

Queen's Bench Division, Administrative Court (London)

Peter Marquand (sitting as a deputy judge of the High Court)

13 December 2019Judgment

**Chris McWatters (instructed by Duncan Lewis) for the Claimant**

**William Irwin (instructed by Government Legal Department) for the Defendant**

Hearing date: 30 October 2019

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Peter Marquand:**

**Introduction**

1. The Claimant is from Vietnam and challenges by way of Judicial Review the lawfulness of the
Defendant's decision recorded in a letter dated 9 October 2018 that, notwithstanding new information, the
Claimant was not a victim of trafficking. This decision was a reconsideration of the Defendant's conclusive
grounds decision of 31 May 2016 ('the 31 May 2016 Decision').

2. At the hearing an application was made by the Claimant for anonymity. I made such an order for the
following reasons. If identified, the Claimant may be at risk of serious harm if, first, the Claimant is returned
to Vietnam or secondly, he remains in the UK and some, or all, of what the Claimant says about his
treatment is true. Furthermore, a significant amount of the subject matter concerns the Claimant's medical
condition. Additionally, this Judgment refers to 2 decisions of the First-Tier Tribunal, both of which had
made Directions providing for the anonymity of the Claimant, which would be ineffective if there was no
anonymity in this case. Considering the Claimant's article 8 rights and the right to freedom of expression,
article 10, I was, and am, satisfied that non-disclosure is necessary to secure the proper administration of
justice and in order to protect the interests of the Claimant. The order I made on 30 October 2019 contains
a provision for any non-party to apply to vary it or to have it set aside. The order has been published in
accordance with CPR 39.2(5).

3. The Claimant says that he is a victim of trafficking. The Defendant is the relevant public authority
('competent authority') which determines, within the legal framework, whether or not individuals are victims
of trafficking. In summary, after a decision is made that there are reasonable grounds to suspect a person
is a victim of trafficking the competent authority goes on to make a conclusive grounds decision, on the
balance of probabilities, whether that person is a victim of trafficking. The relevant policy provides for a
reconsideration by the competent authority of a previous conclusive grounds decision.

4. In a claim form filed on 11 January 2019 the Claimant challenged first, the Defendant's decision of 9
October 2018 not to recognise the Claimant as a victim of trafficking and secondly, the Defendant's failure
to apply anxious scrutiny in considering the Claimant's credibility and evidence in support of his claim to be


-----

a victim of trafficking. In summary, the Claimant's case is that a psychiatric report diagnosing the Claimant
as suffering from PTSD and a report from an expert on Vietnam, were not sufficiently taken into account by
the Defendant. In oral submissions the Claimant's emphasis was in particular on the psychiatric evidence.

5. On 29 March 2019 Alison Foster QC, sitting as a Deputy High Court Judge, granted permission.

**The legal framework**

6. Human trafficking falls within the scope of article 4 of the European Convention on Human Rights
(Rantsev v Cyprus and Russia (2010) 51 EHRR 1 paragraph 282). The article provides:

“Article 4 of the Convention – Prohibition of slavery and forced labour

1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.”

7. There are no permissible exceptions or derogations. In Rantsev at paragraph 283 the court stated that
this article 'enshrines one of the basic values of the democratic societies making up the Council of Europe.'

8. The UK is a signatory of the Council of Europe Convention on Action against Trafficking in Human
Beings ('the ECAT'), which was ratified by UK and came into force on 1 April 2009. The UK is also subject
to the European Directive 2011/36/EU ('the Directive'), which is directed at preventing trafficking of human
beings and protecting its victims. The mechanism of compliance with the ECAT and Directive is through
the national referral mechanism ('the NRM').

9. The NRM process relies on first responders identifying potential victims and referring them to a
competent authority. The competent authority assesses the evidence to reach a reasonable grounds
decision on the standard of proof of 'I suspect but cannot prove.' A positive reasonable grounds decision
puts in place a timeline for the competent authority to make a conclusive grounds decision. The standard of
proof for that decision is 'on the balance of probabilities,' although that is currently subject to an appeal, but
nothing turns on that in this case.

10. The Defendant has published guidance for Home Office staff entitled 'Victims of **_Modern Slavery –_**
Competent Authority Guidance.' There have been a number of versions but the parts relevant to this case
have not changed. In particular, the section entitled 'How to Assess Credibility When Making a Reasonable
Grounds or Conclusive Grounds Decision' ('the Credibility Guidance') and 'Appeals against a Reasonable
Grounds or Conclusive Grounds Decision' ('the Reconsideration Guidance').

11. The Credibility Guidance points out the potential victim's account needs to be assessed to determine
whether it is credible. The material facts of past and present events are assessed for their coherence and
consistency, including the level of detail of the information provided, but the Guidance notes:

“Due to the trauma of human trafficking or **_modern slavery, there may be valid reasons why a potential_**
victim's account is inconsistent or lacks sufficient detail.”

12.  The Credibility Guidance goes on to deal with assessing mitigating circumstances:

“… which can affect whether a potential victim's account of modern slavery is credible.

When the CA [competent authority] assesses the credibility of a claim there may be mitigating reasons why
a potential victim of modern slavery is incoherent, inconsistent or delays giving details of material facts.
The CA must take these reasons into account when considering the credibility of the claim. Such factors
may include, but are not limited to, the following:

     - trauma (mental, psychological, or emotional)

     - inability to express themselves clearly

     - mistrust of authorities

     - feelings of shame


-----

- painful memories (including those of a sexual nature)”

13. I was referred to authorities that dealt with assessments of credibility. In KB & AH (credibility-structured
_approach)_ _[[2017] UKUT 491 (IAC) Lord Burns, sitting as a Judge of the Upper Tribunal, and Judge Storey](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RTP-R1N1-F0JY-C0CS-00000-00&context=1519360)_
considered this issue in the context of an asylum claim. The guidance is different but the principles are
relevant at paragraphs 26 to 41. In essence, the factors in the guidance referred to as indicators of
credibility are not to be treated as a set of conditions or requirements and must not be applied as such.
They are not to be taken as an exhaustive list and it must not be forgotten that a credibility assessment is
highly fact sensitive. The evidence must be considered as a whole and consideration given to every factor
that might tell in favour of or against a person. In _MA (Somalia) Secretary of State for the Home_
_Department_ _[2010] UKSC 49 at paragraph 33 Lord Dyson stated 'the significance of lies will vary from case_
to case'. I was also referred to _R (FK) v Secretary of State for the Home Department_ _[2016] EWHC 56_
_(Admin) at paragraph 27 where Dove J in a case concerning the application of the Credibility Guidance in_
the NRM decision-making process stated that:

“Given the nature of the Guidance, and the level of detail that it provides in relation to the consideration of
credibility in trafficking claims, a high standard of reasoning is required from the competent authority in
order to demonstrate a careful and conscientious analysis of the relevant factors which have to be taken
into account when assessing credibility.”

14. The Reconsideration Guidance points out that an individual has a right to challenge either a
reasonable grounds decision or a conclusive grounds decision by way of judicial review. However, it goes
on to state that it may be appropriate for the competent authority to reconsider a decision but:

“This is not a formal right of appeal and the decision should only be reconsidered where there are grounds
to do so.

This informal arrangement does not extend to other parties such as legal advisors and non-governmental
organisations outside the NRM.”

15. It is common ground that in assessing this challenge I must apply 'anxious scrutiny' or referred to as
'rigorous scrutiny' by Sir Stephen Silber in _R (SF (Saint Lucia)) v Secretary of State for the Home_
_Department [2016] 1 WLR 1439. This was analysed by Philip Mott QC, sitting as a Deputy High Court_
Judge, in R (IXU) v Secretary of State for the Home Department [2019] EWHC 12 (Admin) at paragraph
50. The judge identified 7 propositions which are as follows:

“i. …The Defendant bears the burden of justifying the decision.

ii.  The review is one for error of law, not merits…

iii.  The test is one of rationality, not some higher or lower standard…

iv.  In some cases, it may be enough simply to say that a possible basis of a claim has been considered
and rejected… In others, very much more detailed justification and explanation will be expected, especially
where the effect of the decision is great. The concept of anxious scrutiny reflects this requirement for more
detailed reasons in certain cases.

v.  The Supreme Court has endorsed a flexible approach to judicial review, especially where important
rights are at stake (see Kennedy v Charity Commissioner (Secretary of State for Justice intervening) [2015]
AC 455).… and 'in the context of fundamental rights, it is a truism that the scrutiny is likely to be more
intense than where other interests are involved' (see paragraph 54) …

vi.  The practical effect of the anxious scrutiny test is 'the need for decisions to show by their reasoning
that every factor which might tell in favour of an applicant has been properly taken into account' (R (YH) v
_Secretary of State for the Home Department_ _[[2010] 4 All ER 448 at paragraph 24). But it is not incumbent](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5196-W261-DYBP-M484-00000-00&context=1519360)_
on decision-makers to refer specifically to all the available evidence.

vii.  Anxious scrutiny 'does not mean that the court should strive by tortuous mental gymnastics to find
error in the decision when in truth there has been none. The concern of the court ought to be substance
[not semantics' (R (Sarkisian) v IAT [2001] EWHC Admin 486 at paragraph 18). Decision letters should be](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VGC1-DYBP-P0CC-00000-00&context=1519360)


-----

read in a broad and common-sense way, without being subjected to excessive or over punctilious textual
analysis.”

**The Facts**

16. The Claimant entered the United Kingdom clandestinely at some time in May 2008. On 25 December
2015 the Claimant was arrested by Cleveland police for driving whilst under the influence of alcohol and
without insurance. The Claimant said that he had been trafficked to the United Kingdom and forced to work
on a cannabis farm. He had been badly beaten by the traffickers when he tried to escape and, in the past,
had boiling water poured on him and a cigarette stubbed out on his left hand. At the time of his arrest he
had damaged the trafficker's car. The Claimant claimed that the traffickers said he owed them £20,000 for
damaging their business ('the £20,000 Debt').

17. Under the NRM he was referred to the Defendant, as the competent authority. A reasonable grounds
decision was made in the Claimant's favour, but in the 31 May 2016 Decision a negative conclusive
grounds decision was made. In other words, it was decided the Claimant on the balance of probabilities,
was not a victim of trafficking.

18. In the 31 May 2016 Decision, the Defendant set out the definitions of human trafficking, slavery,
servitude and forced or compulsory labour. The Defendant went on to consider the Claimant's evidence as
follows:

i) As a child in Vietnam, shining shoes and selling lottery tickets led to the Claimant being paid below the
minimum wage, but his employers paid for food, lodgings and transport. The claim that his employers
would have stopped him leaving was considered inconsistent with being paid a wage and giving him
freedom of movement initially.

ii) The Claimant's claim that he chose to go abroad to work for a person that he did not know and for an
unknown amount of money was inconsistent, as without that information the Claimant would be unable to
judge if he was in a better financial position and whether it was worth the risk of travelling abroad.

iii) That despite his denials, the Claimant knew at an early point after his arrival in United Kingdom that
cultivation of cannabis was illegal.

iv) That the Claimant had access to the Internet through a smart phone at an earlier point than he claimed.

v) The freedom provided to the Claimant in terms of being given access to a car, being left the keys to the
house, being paid monthly and access to the Internet was inconsistent with claims of not being given any
money for 6 years and threatened with death if he tried to leave. The sums of money that the Claimant was
paid were inconsistent with his claim to be subject to forced work.

19. The Defendant's conclusion was that the Claimant's credibility had been damaged to the extent that
his claim to have been exploited 'cannot be believed' and that his evidence was internally inconsistent and
limited weight was attached to it. It was considered that the Claimant had not met the required evidentiary
standard and it was not accepted that he had been mistreated as claimed.

20. The decision was made to deport the Claimant and he was detained under immigration powers on 25
June 2016. The Claimant applied for asylum which was refused and the Claimant appealed to the First-Tier
Tribunal. Whilst in detention a medical practitioner prepared a report under rule 35 of the Immigration
Rules ('the Rule 35 Report') and it concluded that the Claimant had scars which 'may be due to' having had
boiling water poured on him and a cigarette stubbed out in his left hand.

21. The first hearing at the First-Tier Tribunal took place on 29 August 2017 before FTTJ Woolf. The
Claimant represented himself. The decision and reasons were promulgated on 12 September 2017. His
claim for asylum was rejected on refugee convention grounds, humanitarian protection grounds and human
rights grounds. The judge's findings of fact included the following:

i) The judge did not find the Claimant to be a credible witness in relation to some very pertinent issues;


-----

ii) The claim to have restricted movements was not supported by the circumstances in which he was alone
in a car when arrested;

iii) It was not credible that the Claimant's traffickers/employers fixed the sum of £20,000 in the event that
he should cause damage their business;

iv) The judge was not satisfied that his traffickers/employers would have any cause or wish to harm the
Claimant should he return to Vietnam. The possibility of being identified on re-entry to Vietnam by anyone
in league with the people who arranged for him to come to the UK was extremely remote;

v) The debt the Claimant incurred in relation to his original journey to the United Kingdom had been
cleared; and

vi) There was no credible evidence as to how his traffickers/employers would even be aware of his return
to Vietnam.

22. The Claimant underwent a psychiatric assessment by Dr Bose, consultant psychiatrist, and he
produced a report dated 26 March 2018. The history Dr Bose records is the one that he obtained from the
Claimant, although he had other material available to him including the First-Tier Tribunal decision dated
12 September 2017, the Rule 35 Report and the immigration removal centre medical records. At paragraph
28 Dr Bose records his diagnosis of PTSD and a major depressive episode. At paragraph 119 and 129 Dr
Bose states that he considers the Claimant 'psychiatrically credible' and at paragraph 120 that it would be
most unusual for someone attempting to fabricate psychiatric disorder for the purposes of gaining entry to
present a balanced and considered view of his symptoms. At paragraph 137 Dr Bose states: 'I consider his
mental health condition, matched with his objectively viewed demeanour to be totally consistent with his
reported experiences as a victim of torture and abuse.' Dr Bose considers the First-Tier Tribunal conclusion
that I have summarised at paragraph 21(ii) and states:

“Psychiatrically speaking, I am of the view that [the Claimant] was so significantly traumatised from the
abuse he suffered on trying to escape, and so susceptible to this trauma due to his childhood experiences,
in conjunction to the distorted perception of his own agency described above, that he would not have dared
to escape and seek assistance even if he had wanted to.”

23. The Claimant also obtained a report dated 28 March 2018 from Joshua Kurlantzick, who is an expert
on Vietnam. Mr Kurlantzick was provided with Dr Bose's report, the First-Tier Tribunal decision dated 12
September 2017 and the Home Office decision refusing his asylum claim. He reviewed the situation in
Vietnam generally and addressed the risks of the Claimant's return to Vietnam. At paragraph 39 he
concluded that the Claimant's account was 'plausible'. He made the distinction between plausibility and
credibility and stated that it was not his role as an expert to determine the question of credibility. At
paragraph 53, having reviewed a number of factors, Mr Kurlantzick stated that there was a likelihood that
the Claimant would be harmed if he returned to Vietnam '…potentially attacked by former traffickers for not
having paid his debt [this is a reference to the £20,000 Debt] or being recaptured as a vulnerable member
of society.'

24. Based on the two expert reports, the Claimant made further submissions for an asylum claim and this
was dealt with under paragraph 353 of the Immigration Rules by the Defendant. The decision was made
on 20 April 2018 again rejecting the asylum claim. This letter repeats the history and in particular refers to
the First-Tier Tribunal judgment pointing out that the Defendant was bound by the findings of the
immigration judge, in particular relying upon the judge's rejection of the credibility of the £20,000 Debt. The
report of Dr Bose is considered noting that the Claimant had been diagnosed with PTSD and Dr Bose's
opinion that the Claimant presented as a person with increased vulnerability. The letter, with some
apparent scepticism states that the Claimant has been able to pass through a criminal trial, prison
sentence and an immigration appeal without alerting anyone to the extent of his mental condition. The
availability of treatment in Vietnam for those with mental health issues is considered and the conclusion
reached that the Claimant did not qualify for asylum. However, it was accepted that the material produced
amounted to a fresh claim and therefore the Claimant had a right to appeal the Defendant's decision. The
Claimant accordingly applied to appeal, and this is dealt with below.


-----

25. On 25 May 2018 the Claimant requested the Defendant to reconsider the 31 May 2016 Decision (i.e.
the conclusive grounds). The Defendant's decision was communicated to the Claimant in a letter dated 9
October 2018. The letter records that consideration was given to the expert report of Dr Bose, the expert
report of Mr Kurlantzick, the Rule 35 Report and the patient records from the immigration removal centre.

26. The letter includes a recital of the history of the asylum claims including the First-Tier Tribunal
judgment dated 12 September 2017 especially the rejection of the claim that the £20,000 Debt was owed
to his traffickers. There is a quotation from the judgment concerning that issue. The focus is also on the
fresh asylum claim and the rejection of it in the letter dated 20th April 20181. The key part of the letter is as
follows:

“Consideration has been given to the representations of 25 May 2018. These representations, when
considered with the information received and decisions made since the conclusive grounds decision of 31
May 2016, do not explain the inconsistencies identified in your accounts. The evidence submitted does not
alter the findings in the conclusive grounds decision of 31 May 2016 that little weight could be given to your
accounts as they lack credibility due to the internal inconsistencies identified.

Consequently, the conclusive grounds decision dated 31 May 2016 is maintained as subsequent material
does not, on the balance of probabilities, lead to the belief that you have been a victim of modern slavery
(human trafficking or slavery, servitude or forced/compulsory labour).”

27. The judgment of the Claimant's second appeal to the First-Tier Tribunal was promulgated on 11 June
2019. The appeal was rejected on asylum grounds, humanitarian protection grounds and human rights
grounds. The judge at paragraph 31 rejected the Claimant as a credible witness. The judge did not accept
the evidence in relation to the £20,000 Debt, accepted the evidence of his injuries but was not satisfied that
the assaults were at the hands of his 'captor.' In relation to Dr Bose's evidence the judge does not accept
that the Claimant's PTSD was caused by the assault at the hands of his 'captor.' The judge does not
accept, bearing in mind Dr Bose's evidence, that the Claimant has established substantial grounds for
believing that if returned to Vietnam he would face a real risk of suffering serious harm. The Claimant has
applied to the Upper Tribunal for permission to appeal this judgment.

**The Grounds**

28. In Ground 1, the Claimant alleges that the Defendant's decision of 9 October 2018 was unlawful as the
evidence of the 2 expert reports and the Rule 35 Report had not been considered, especially the impact on
FTTJ Woolf, if they had been available. An irrelevant fact was relied on, namely the £20,000 Debt. In
Ground 2 the Claimant says the Defendant failed to apply anxious scrutiny to the decision. Essentially,
Ground 1 is encompassed with in Ground 2.

**The Submissions**

29. Mr McWatters submitted that the evidence of the 2 expert reports and the Rule 35 Report had not
been considered by the Defendant when relying upon the determination of FTTJ Woolf and their likely
impact upon him if they were available. The £20,000 Debt is an irrelevant fact for the purposes of
reconsideration of the issue of whether the Claimant is a victim of trafficking as it is relevant to the risk to
the Claimant in the future (i.e. for the asylum claim), but not evidence of whether he had been trafficked in
the past. The Defendant had ignored the findings of Dr Bose, which I have quoted at paragraph 22 above
and other aspects of the report. Mr McWatters further submitted that Defendant failed to apply anxious
scrutiny in considering the Claimant's credibility and the evidence in support of his claim to be a victim of
trafficking. There is no evidence that the Defendant has applied the Competent Authority Guidance and
failed to consider meaningfully the expert evidence, in particular the evidence of Dr Bose.

30. Mr Irwin's submissions on behalf of the Defendant were that the decision of 9 October 2018
incorporated the 31 May 2016 Decision, the asylum appeal, the First-Tier Tribunal's judgement dated 12
September 2017 and the Defendant's decision on 20 April 2018. The 31 May 2016 Decision concluded the
Claimant was not credible, the First-Tier Tribunal appeal was in substance the same account and was
rejected by the judge. The 2 expert reports and the Rule 35 Report were considered in the decision of 20


-----

April 2018 and applied a lower standard of proof, but still rejected the claim, including a detailed analysis of
the report of Dr Bose and concluding that Mr Kurlantzick's report could not assist the Claimant as it was
predicated upon the £20,000 Debt. The second First-Tier Tribunal decision was an unsuccessful appeal of
the decision of 20 April 2018. It is plainly rational for the Defendant to conclude that the 2 expert reports
and the Rule 35 Report did not overcome the previous rejections of the Claimant's account. The
requirement of anxious scrutiny did not oblige the Defendant carry out repetitive analysis of the same
material in different decisions. It was unarguably rational for the Defendant to incorporate by reference the
analysis carried out in the earlier decisions. The reconsideration was an informal process and judicial
review was flexible in the context of the decision. He also submitted that if there was a defect in the
decision-making process it would make no difference to the outcome. That was raised for the 1st time
during the hearing and did not appear in the written argument.

**Discussion**

31. In order to determine whether or not an asylum claim is made out it is necessary for the decisionmaker to evaluate the available evidence to determine whether or not there is a future risk for a person in
the event that they are returned to their country of origin. However, in order to determine whether or not an
individual has been a victim of trafficking, it is necessary for the decision-maker to evaluate the available
evidence to determine whether or not that has been established, on the balance of probabilities, as a past
fact. The former process looks forwards and the latter process backwards.

32. I have no difficulty in accepting the Defendant's submission that, as a matter of principle, it is possible
to incorporate previous reasoning and decisions by reference to them into a subsequent decision. This is
provided that is it is clear that incorporation is to substantiate the new decision. Mr Irwin submitted that the
reference in the Reconsideration Guidance to the 'informal arrangement' applied to the review of the
decision. This is not correct, in that the reference to “informality” is to the process leading up to the
reconsideration. It does not mean that the reconsideration itself should in some way be a lesser application
of the Competent Authority Guidance or a less rigorous or anxious scrutiny. This would be irrational, given
the fundamental nature of the rights involved (Rantsev) and the propositions set out in IXU.

33. The requirement on the Defendant is to consider, applying the relevant parts of the Competent
Authority Guidance and anxious scrutiny, what difference the new material makes to the decision that is
under reconsideration. It does not mean in every case it is necessary for the Defendant to repeat the entire
process that she has previously gone through. It will depend upon the facts and the nature of the new
material.

34. Turning to the facts of this case, the Defendant was entitled to reach the conclusions that she did in
relation to the Claimant's credibility in the 31 May 2016 Decision. The £20,000 Debt is not referred to in
that letter and it is not known whether that is something that the Claimant put forward at that time. The
First-Tier Tribunal decision dated 12 September 2017 also did not find the Claimant's account credible and
particular focus was placed upon the £20,000 Debt. This is because if a debt of that magnitude was 'owed'
by the Claimant to his traffickers it is plausible, based on the evidence of Mr Kurlantzick that the traffickers
would take steps to recover that sum of money. The First-Tier Tribunal on this occasion, and subsequently,
rejected the evidence about the £20,000 Debt and both judges relied on this as a key reason for the
conclusion that the Claimant was not at future risk.

35. The focus of 20 April 2018 decision was also on the asylum claim. It again relied heavily on the
rejection of the £20,000 Debt by the First-Tier Tribunal judge and the finding of the Claimant's lack of
credibility. The report of Mr Kurlantzick was said to fail, in so far as it is predicated on the acceptance of the
£20,000 Debt. There was an acceptance of the diagnosis of PTSD by Dr Bose, but an emphasis on the
lack of manifestation of that mental condition. The writer appears to express scepticism about Dr Bose's
diagnosis as, in addition to the comments on lack of manifestation of the mental condition, it is recorded
that the Claimant's solicitors “claim” the Claimant to have been diagnosed with PTSD. It is not claimed: it
has been diagnosed and been said to be credible by the expert. The consideration given to Dr Bose's
report in this decision letter relates to future risk to the Claimant from his mental health condition, as it is a
decision on an asylum claim


-----

36. The Claimant's account has on a number of occasions been found to be lacking in credibility.
However, applying KB & AH, MA (Somalia) and IXU the Defendant, in reaching her decision of 9 October
2018, is required to apply the Credibility Guidance and in particular show by her reasoning that every factor
which might tell in favour of the Claimant has been properly taken into account.

37. The majority of the letter dated 9 October 2018 deals with the previous decisions that had been made
concerning asylum, in other words looking at future risks. The only part of the letter that focuses on a
reconsideration is the one that I have quoted at paragraph 26 above. Within those 2 paragraphs the only
relevant phrase is that the information received does not 'explain the inconsistencies identified in [the
Claimant's] accounts.' There is no reference to a consideration of the Credibility Guidance, which is now
particularly relevant as it identifies that mental trauma may be a mitigating circumstance why a potential
victim of **_modern slavery give an incoherent or inconsistent report and this must be taken into account_**
when considering the credibility of the Claimant's account. Dr Bose has diagnosed a mental disorder,
identified the Claimant as psychiatrically credible and that his psychiatric condition may explain his
evidence that has otherwise been found to be inconsistent and lacking in credibility.

38. The effect of the Defendant's letter is to reject the evidence of Dr Bose as Dr Bose's report does
provide an explanation for what the Defendant had considered to be inconsistencies in the Claimant's
account. However, there are no reasons given for rejecting that evidence in the letter or in the letter of 20
April, because as I have already said, that letter deals with future risks. What has not been considered is a
reconciliation of Dr Bose's evidence with the inconsistencies in the Claimant's account and why Dr Bose's
evidence should be rejected.

39. In his submissions Mr Irwin said that the Claimant's account had already been found to be lacking in
credibility and therefore Dr Bose's opinion was undermined as it was based upon that account. This does
not help the Defendant for 2 reasons. First, Dr Bose's opinion is not solely based upon the Claimant's
account, but is also based upon his clinical assessment of the Claimant during the interview, of particular
note are his conclusions on psychiatric credibility. Secondly, Dr Bose's diagnosis, when considered with
the Credibility Guidance, may be an explanation for some or all of the apparent inconsistencies. The thinly
veiled scepticism expressed in the letter dated 20th April 2018 is not appropriate or enough.

40. The issue over the £20,000 Debt is relevant to the extent that the Claimant's account has been found
not to be credible and as such it may cast doubt on his credibility in other areas. If it were true then it would
tend to support his claim to have been a victim of trafficking. As it has been found to be lacking credibility,
it does not support his claim to have been a victim of trafficking in relation to the circumstances at the time
the alleged debt was incurred. However, it does not automatically follow that everything else he has said
about his past is lacking in credibility. All the circumstances of the case need to be considered.

41. The Defendant's decision of 9 October 2018 does not set out detailed reasons and given the
fundamental rights involved it should do so. It does not show by its reasoning that every factor which might
tell in the Claimant's favour has been properly taken into account. This is the case even reading the
Defendant's letter in a broad and common-sense way. There is no analysis in the letter, other than a
wholesale rejection of the Claimant's case based on a blanket rejection of the Claimant's credibility. The
incorporation of the earlier decisions do not provide the necessary reasoning as they are directed at a
different assessment, namely, the future risks to the Claimant and consideration of his asylum claim. This
betrays a failure to consider Dr Bose's evidence and how it may impact on the decision on the Claimant's
credibility when applying the Credibility Guidance. Failing to do such analysis is irrational, does not follow
the Defendant's own policy and does not meet the requirement of rigorous or anxious scrutiny.

42. In oral submissions, the Defendant invited me to conclude that even if there was a defect in the
decision-making process the outcome would not have been any different. Section 31(2A) Senior Courts Act
1981 provides that:

“The High Court—

(a)must refuse to grant relief on an application for judicial review, and

(b)may not make an award under subsection (4) on such an application


-----

if it appears to the court to be highly likely that the outcome for the applicant would not have been
substantially different if the conduct complained of had not occurred.”

43.  The application was not developed by Mr Irwin and I was not referred to section 31(2A) or to any
authorities. There is no evidence before me on which I could reach the conclusion as required by section
31(2A). There is no evidence of what the decision maker could have concluded in the alternative. On the
basis of the material before me I would be substituting my own decision for that of the proper decision
maker. There is more than one possible outcome for the decision. It might be concluded that Dr Bose's
evidence is an explanation for some or all of the inconsistencies, leading to a decision in the Claimant's
favour. I would be speculating on the outcome. In those circumstances, I am not satisfied that it is highly
likely that the outcome for the Claimant would not be substantially different.

44.  Accordingly, the Claimant succeeds in his claim and I quash the Defendant's decision dated 9th
October 2018.

**Postscript**

45. Having circulated the draft of this Judgment, the parties referred me to R (DS) v Secretary of State for
_the Home Department_ _[2019] EWHC 3046 (Admin), which was handed down after the hearing of this case._
The Defendant's Reconsideration Guidance was considered in detail by Kerr J. The parties agree that
there is nothing inconsistent between my findings at 31 -33 and the court's judgment in DS and I agree. In
_DS what was in issue was the 'gateway' to obtain reconsideration. As Kerr J found, the obligation on the_
Defendant is to identify victims of trafficking (paragraph 67). This decision is consistent with what I have
concluded at paragraphs 31 and 33 of this Judgment.

**End of Document**


-----

