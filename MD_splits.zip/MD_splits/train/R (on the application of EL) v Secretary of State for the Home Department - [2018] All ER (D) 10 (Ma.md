# R (on the application of EL) v Secretary of State for the Home Department

 [2018] All ER (D) 10 (May)

[2018] EWHC 968 (Admin)

Queen's Bench Division, Administrative Court (London)

Judge Evans-Gordon (sitting as a Judge of the High Court)

26 April 2018

**Immigration – Trafficking – Credibility**
Abstract

_Immigration – Trafficking. The defendant Secretary of State had not erred in making a negative conclusive grounds_
_decision on the basis that that the claimant Albanian national's account was incredible and she was not a victim of_
_trafficking. Accordingly, the Administrative Court dismissed the claimant's application for judicial review of that_
_decision._
Digest

The judgment is available at: [2018] EWHC 968 (Admin)

**Background**

In 2004, the claimant Albanian national met a man, Marko, when she was 14. She stated that, after two or three
months, he raped her and continued to rape her over the next three years, threatening her and physically harming
her to prevent disclosure. In 2015, Marko invited the claimant to live with him in Italy and said he would look after
her son. The claimant refused, but later agreed when Marko said he would also take her brother E with them.

In July, the claimant, her son and E left Albania for Italy, and travelled to France. In October, the claimant, her son
and E tried to enter the United Kingdom using forged documents, but were stopped by the authorities. Following
their release, they were collected by friends of Marko's and met a woman named Selima. Selima told the claimant
that she would have to work as a prostitute to pay them for the forged documents. When the claimant spoke to
Marko on the telephone he said that E's life was in her hands; if she worked as a prostitute, E would be free to do
as he pleased. The claimant began work as a prostitute.

In December 2015 the claimant entered the UK and the competent authority made a positive reasonable grounds
decision. However, in October 2016, the competent authority made a negative conclusive grounds decision on the
basis that that the claimant's account was incredible and she was not a victim of trafficking. The claimant sought
judicial review.

Application dismissed.

**Issues and decisions**

(1) Whether defendant Secretary of State's assessment of the claimant's credibility was unlawful, given the
approach to assessing credibility as set out in the Victims of **_Modern Slavery – Competent Authority Guidance_**
(v.3.0, 21 March 2016) and given the information provided by the claimant.


-----

There was no evidence to support a contention that the claimant had been groomed by Marko for the purposes of
sexual exploitation beyond his own personal gratification. In any event, the claimant did not appear to have been
under Marko's control after his first departure as, following a brief affair, it had been the claimant who had ended the
relationship. Further, the reasons given by the claimant for refusing to go with Marko initially and then later
agreeing to go negated such a suggestion, as the decision-maker had found. It had been open to her to make that
finding on the evidence (see [24] of the judgment).

The decision-maker had not incorrectly approached the question of the credibility of the alleged sexual exploitation
of the claimant as a child. The tailored parts of the Guidance went to the issues of the components of child
trafficking and the assessment of the credibility of children. The claimant was attempting to conflate these two
separate elements of the Guidance. She had not been trafficked as a child and had not been interviewed as a child.
The claimant's credibility had properly been assessed as an adult. The decision-maker had recognised that, if
trafficking had started when the claimant had been a child, the 'means' element would have been irrelevant.
However, the decision-maker had disbelieved the whole of the claimant's account, therefore, the 'means' element
had been irrelevant in any event. Neither was the case complex, as envisaged by the Guidance, where a child was
sexually exploited and forced into prostitution as a child, and then continued that occupation, apparently of her own
volition, as an adult (see [25] of the judgment).

The decision-maker had correctly identified the task and set out the relevant principles in the decision letter. She
had also correctly set out the Guidance in relation to credibility at the outset of her decision. The decision-maker
had plainly had in mind the fact that some of the events allegedly had occurred during the claimant's childhood, as
she had recognised that the 'means' by which the claimant had been said to be a victim of trafficking was irrelevant
or inapplicable. The reality was that the decision-maker simply had not believed anything the claimant had said to
her (see [27] of the judgment).

(2) Whether the Secretary of State's decision was irrational, as it concluded that the information from an
organisation providing support to the claimant did not provide any mitigating reasons in terms of the claimant's
credibility.

The claimant's unwillingness to talk and her distress with her counsellor had not gone to the credibility of what she
had, in fact, said to the interviewers. Therefore, it had been open to the decision-maker to decide that the
organisation's letter had not addressed or mitigated the claimant's lack of credibility. In accordance with the
Guidance, the decision-maker had given clear, robust reasons why the conclusive grounds test had not been met.
The decision-maker's conclusion had clearly been open to her on the material before her and she had considered
all relevant matters (see [30] of the judgment).

(3) Whether the decision-maker had erred in failing to put the information received from the Albanian authorities to
the claimant before reaching her decision.

The decision-maker had not placed any reliance on the different dates of departure from Albania that had been
given. A small inconsistency such as that was highly unlikely to have made any difference to the decision which had
been based on more substantial matters. While the decision-maker had relied on the difference between the
claimant's account of her living arrangements in Albania and those provided by the authorities, that inconsistency
was not determinative and had not had a significant impact on the outcome. If those items were removed from the
list of inconsistencies and implausibility, there would still be ample material on which the decision-maker could have
reached her conclusion (see [32] of the judgment).

Catherine Robinson (instructed by Duncan Lewis Solicitors Ltd) for the claimant.

Christopher Staker (instructed by the Government Legal Department) for the Secretary of State.
Karina Weller - Solicitor (NSW) (non-practising).


-----

**End of Document**


-----

