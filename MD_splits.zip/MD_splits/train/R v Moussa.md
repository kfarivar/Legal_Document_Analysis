# R v Moussa [2024] EWCA Crim 214

Court of Appeal, Criminal Division

William Davis LJ, Yip J, HHJ Robinson

27 February 2024Judgment

**Dr A O'Shea appeared on behalf of the Applicant**

**Mr A Johnson appeared on behalf of the Crown**

**____________________**

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making are that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

Tuesday 27[th] February 2024

**LORD JUSTICE WILLIAM DAVIS: I shall ask Mrs Justice Yip to give the judgment of the court.**

**MRS JUSTICE YIP:**

1. This is an application for leave to appeal against conviction which the single judge has referred to the full court.

2. On 24[th] March 2023, following a trial in the Crown Court at Warwick, the applicant was convicted of two counts
of conspiracy to supply a Class A drug. Count 1 related to the supply of cocaine and count 2 to the supply of
heroin. In each case the conspiracy was alleged to have occurred between 1[st] May 2021 and 30[th] September 2021.

3. The applicant was born on 14[th] November 2002 and so was aged 18 during the period covered by the
indictment.

4. The applicant admitted that he had conspired with a named minor and others to supply the drugs. His defence
was that he had been compelled to take part in the conspiracy, having been recruited at the age of 16 when he was
tricked into believing he owed a debt that he was required to repay. He relied upon section 45 of the **_Modern_**
**_Slavery Act 2015. Where a defence under section 45 is raised, it is for the prosecution to prove that it does not_**
apply.


-----

5. Section 45 draws a distinction between a person who is aged 18 or over and one who is under the age of 18.
For these purposes the relevant time is "when the person does the act which constitutes the offence". Section
45(1) provides:

"(1) A person is not guilty of an offence if —

(a) the person is aged 18 or over when the person does the act which constitutes the offence,

(b) the person does that act because the person is compelled to do it,

(c) the compulsion is attributable to slavery or to relevant exploitation, and

(d) a reasonable person in the same situation as the person and having the person's relevant
characteristics would have no realistic alternative to doing that act.

6. Section 45(4) provides:

(4) A person is not guilty of an offence if —

(a) the person is under the age of 18 when the person does the act which constitutes the offence,

(b) the person does that act as a direct consequence of the person being, or having been, a victim of
slavery or a victim of relevant exploitation, and

(c) a reasonable person in the same situation as the person and having the person's relevant
characteristics would do that act."

7. It follows that a lower bar is set for the defence when considering acts done by children than when by
considering the position for adults. In the case of a child, the defence is available if the act was done "as a direct
consequence" of the defendant being a victim of slavery or relevant exploitation, and where a reasonable person in
the same position and with the same characteristics would do that act. For adults, the defence applies only if the
defendant was "compelled" to do the act as a result of **_modern slavery or relevant exploitation and where a_**
reasonable person in the same position and with the same characteristics would "have no realistic alternative to
doing that act".

8. The prosecution of the applicant arose out of an investigation into the modern slavery of children engaged in
the trafficking of drugs through a "county lines" network. One of the children, Jack, was stopped on 15[th] May 2021
and again on 5[th] August 2021. On each occasion he was found to be in possession of Class A drugs, two phones
and a knife. He was found to be in regular contact with a telephone number which was associated with a county
line known as the "D Line". The credit for that line was topped up on 8[th] August 2021. CCTV evidence from the
shop where the voucher was purchased showed Jack entering with the applicant. Mobile phone evidence
demonstrated that two different numbers were associated with the same handset which was used as the "D Line"
during the period of the conspiracy. The first connected on 4[th] March 2021 and was used between 15[th] June 2021
and 28[th] September 2021. The second was first connected on 9[th] April 2021 and was used between 24[th]
September 2021 and 28[th] September 2021.

9. Evidence of mobile data and cell site analysis showed that phones attributed to the applicant were frequently in
the same area as the "D Line" phone and moving together. The applicant admitted that he was the person who
was usually in control of the "D Line", although it was sometimes held by Jack. He admitted that it was his job to
send out bulk messages from the "D Line".

10. Jack pleaded guilty to the conspiracies represented by counts 1 and 2. The applicant admitted that he was
involved in the supply of drugs with Jack and others, such that he had committed the acts said to amount to his part
in the conspiracies. The sole issue, therefore, was whether he could rely on the section 45 defence.

11. The applicant's evidence was that he became involved in a gang led by people he called "Max" and "K". He
met them through a friend called Ajay shortly after he left school at the age of 16. He had initially viewed them as
friends, but they then told him that he had been smoking their premium cannabis and now owed a debt. He was
taken to Scotland where he was kept in a flat for four days before being taken to another property where he was


-----

required to sell drugs. He thought he would "get stabbed up" if he left. When the property came under attack by
men in masks, he escaped and said that he was allowed to return home. After that, he avoided contact with Max
and K for about six months, but he then discovered from Ajay that they were looking for him. He went with Ajay to
meet them, and he felt that he had to go back to Scotland to protect Ajay and his family. He was placed in a house
with other teenagers and was not allowed out. Eventually, he was allowed to return home, and it was around that
time that the idea to sell drugs in Stratford Upon Avon came to him. He said that although he had talked to others
about selling drugs, he had not been able to talk about the fear or threats that had made him do so, or to complain
about Max and K.

12. After the conclusion of the evidence, and following the circulation and discussion of draft legal directions, Dr
O'Shea, counsel for the applicant, submitted that the jury should be directed as to the defence under section 45(4)
available to those under 18. That was said to be necessary on the applicant's account. It was submitted that if
there was a continuing agreement which began before the applicant's 18[th] birthday, the jury should consider
whether the defence available to children applied. The Recorder ruled that the jury should be directed to consider
the adult defence under section 45(1) only. The prosecution case was that there was a continuing conspiracy from
May to September 2021. The acts alleged to constitute the offence were all committed after the applicant had
attained the age of 18. Therefore, the only appropriate defence was that under section 45(1) and the directions to
the jury should not be complicated by reference to the defence under section 45(4).  The Recorder noted that this
did not preclude the applicant from relying on what had happened over the previous months and years. His
experiences, if to be believed, could form part of the relevant characteristics for the jury to take into account when
considering whether a reasonable person in the same situation and sharing the same characteristics would have
had a realistic alternative. However, in conclusion the Recorder said:

"The defence must be framed by the allegation which the [applicant] has to meet."

13. On behalf of the applicant it is contended that the Recorder was wrong to refuse to direct the jury on the
defence available to children. It is submitted that the words "when the person did the act which constitutes the
offence" are capable of two meanings in relation to a continuing criminal act. The first is that it relates only to
conduct falling within the period covered by the indictment. The second possible interpretation contended for is (to
quote the grounds of appeal): "whatever it is on the evidence in the case without any artificial restriction on its time
frame". It is argued that if the jury considered that the act was a continuing one which began before the applicant's
18[th] birthday, both provisions potentially applied.  Dr O'Shea submitted that in those circumstances the jury should
have been left to evaluate whether this was a continuing conspiracy which began before the applicant was 18. In
making his submissions, Dr O'Shea urges a purposive approach to interpretation. He began his oral submissions
to us by focusing on the international context. He highlighted that Article 26 of the Council of Europe Convention of
2005 provides for the non-punishment of victims compelled to commit offences. Dr O'Shea submitted that it is
important to avoid re-victimisation of those who have become involved in things as children. As put in the grounds
of appeal, it is contended that "it would be contrary to the spirit of the provisions on human trafficking to interpret the
statute in a manner which would allow the prosecution to deprive a victim who was a child at the time of entering
into a conspiracy of the defence for a child under section 45 simply by restricting the period of the indictment to part
of a continuing course of conduct".

14. We make it clear that in this case there is no suggestion whatsoever of any impropriety on the part of the
prosecution, such as artificially restricting the period of the indictment to a period commencing after the applicant's
18[th] birthday, to deprive him of the defence under section 45(4). The acts upon which the prosecution relied to
establish the conspiracies all occurred after the applicant reached his majority. That was the case the applicant had
to meet. In that context it was the defence under section 45(1) which fell to be considered by the jury and upon
which they were properly directed.

15. The fact that the applicant said in his evidence that he had been involved in selling drugs before his 18[th]
birthday does not affect the position. The applicant was vague about when it was that he had persuaded Max and
the others to let him return to Stratford from Scotland, and about when the idea of selling drugs in the Stratford area
came to him. Dr O'Shea accepts that the point about reliance on the defence under section 45(4) only came to him
later on in the trial. It was not something that was actively pursued throughout the trial. In part, this may explain


-----

why there appears to have been very little focus on the dates or on the specifics of any prior acts. What is clear is
that on the applicant's own evidence there had been gaps in his involvement in selling drugs, including a gap of
about six months when he was not in contact with Max and K.

16. The reality is that on the facts of this case, the acts which the jury had to consider were those on which the
prosecution relied, including the applicant's use of the "D Line" and his contact with Jack. It was admitted by the
applicant that those acts were sufficient to prove the conspiracy which was alleged, subject to the section 45
defence. All such acts were committed when the applicant was an adult. The applicant's evidence of his earlier
contact with Max and K, and the reasons he first involved himself in dealing drugs, formed part of the background
for the jury to weigh up when considering the defence under section 45(1). It did not though, on the facts of this
case, mean that the defence for children under section 45(4) applied.

17. In the circumstances we consider that the Recorder was plainly right to direct the jury in the way that she did.
Accordingly, we refuse the application for leave to appeal against conviction.

__________________________________

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground Floor, 46 Chancery Lane, London WC2A 1JE

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

______________________________

**End of Document**


-----

# R v Moussa

_[[2024] EWCA Crim 214](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6BS5-T4S3-S40N-D1V5-00000-00&context=1519360)_

**Court: Court of Appeal, Criminal Division**
**Judgment Date: 27/02/2024**

# Catchwords & Digest

**CRIMINAL LAW - CONSPIRACY TO SUPPLY CLASS A DRUGS – APPEAL AGAINST CONVICTION**

The Court of Appeal, Criminal Division, dismissed the defendant’s appeal against his conviction for two
counts of conspiracy to supply a Class A drug. The defendant was aged 18 during the period covered by the
indictment and had argued that when he was recruited at the age of 16, he was tricked into believing he owed a
[debt that he was required to repay, and he relied upon s 45 of the Modern Slavery Act 2015 (the Act). However,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)
the Recorder had ruled that the jury should have been directed to consider the adult defence under s 45(1) of the
Act only. The defendant contended, among other things, that the Recorder was wrong to refuse to direct the jury on
the s 45 of the Act as a defence available to children, since it should have been up to the jury to evaluate whether it
had been a continuing conspiracy which began before the applicant was 18. The court held, among other things,
that the Recorder had been correct to direct the jury in the way that she did since the defendant's evidence of his
earlier contact with the drug dealers, and the reasons he first involved himself in dealing drugs, formed part of the
background for the jury to weigh up when considering the defence under s 45(1) of the Act and it therefore did not
mean that the defence for children under s 45(4) of the Act had applied. Accordingly, the court refused the
application for leave to appeal against conviction.

**End of Document**


-----

