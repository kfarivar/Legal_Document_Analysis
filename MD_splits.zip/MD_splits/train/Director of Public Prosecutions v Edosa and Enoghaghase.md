# Director of Public Prosecutions v Edosa and Enoghaghase [2023] IECA 38

Irish Court of Appeal

Birmingham P, Edwards and McCarthy JJ

20 February 2023Judgment

**[188/21]**

**[193/21]**

**[191CJA/21]**

**[192CJA/21]**

**The President Edwards J.**

**McCarthy J.**

**BETWEEN**

**THE PEOPLE AT THE SUIT OF THE DIRECTOR OF PUBLIC PROSECUTIONS**

**RESPONDENT/APPLICANT AND**

**ALICIA EDOSA**

**APPELLANT/RESPONDENT**

**BETWEEN**

**THE PEOPLE AT THE SUIT OF THE DIRECTOR OF PUBLIC PROSECUTIONS**

**APPLICANT AND**

**EDITH ENOGHAGHASE**

**RESPONDENT**

JUDGMENT of the Court delivered on the 20[th] day of February 2023 by Birmingham P.

**1.** Following a trial at Mullingar Circuit Criminal Court which lasted 25 days, Ms. Alicia Edosa and Ms.
Edith Enoghaghase were convicted of various offences. They were each convicted of two counts of trafficking of
persons other than children contrary to s. 4(1) and (7) of the Criminal Law (Human Trafficking) Act 2008, (“the 2008
Act”) as well as one count of organisation of prostitution contrary to s. 9 of the Criminal Law (Sexual Offences) Act
1993. Ms. Edosa was convicted of 34 counts of money laundering contrary to s. 7 of the Criminal Justice (Money
Laundering and Terrorist Financing) Act 2010, while Ms. Enoghaghase was convicted of four counts thereof. Ms.
Edosa has appealed against conviction, Ms. Enoghaghase has appealed against severity of sentence, having
withdrawn an appeal against conviction, while the Director has sought to review the sentences imposed in each


-----

case on grounds of undue leniency. In that regard, Ms. Edosa received an effective sentence of five years and eight
months imprisonment, while Ms. Enoghaghase received one of five years and one month. Although there are, in
effect, cross-appeals – the Director's applications to review, on the one hand, and on the other, the appeal against
conviction from Ms. Edosa, and against severity of sentence from Ms. Enoghaghase – it is convenient to refer to
Ms. Edosa and Ms. Enoghaghase as “the respondents”.

Background

2. Before turning to consider the specifics of the grounds of appeal and application, it may be helpful to provide
some background to the trial. The respondents were convicted of trafficking four victims within the State, organising
prostitution, and laundering the money to which those activities gave rise. Each of the victims was a native of
Nigeria, and each had been targeted there as a potential victim for trafficking. Each was required to undergo a
Voodoo ritual; the evidence was that the impact of these rituals was that, in accordance with the beliefs and
customs of their society, those subject to them were convinced that they were obliged to obey all commands issued
to them, and were to be under the control of certain individuals. Those trafficked were led to believe that if they
disobeyed any command, they would suffer dire consequences.

3. To elaborate somewhat of the facts of the case, the investigation was triggered on 16[th] May 2018, when
complainants JE (born March 1996) and SI (born December 1995) presented themselves at Store Street Garda
station and informed Gardaí that they had complaints to make in relation to being forced into prostitution. They
indicated that they were originally from Benin City in Nigeria, but that they had only met when they came to Ireland.
Subsequently, Gardaí became aware, through Interpol, that another complainant, PS (born December 1992), was
also alleging that she had been induced into coming to Ireland and then forced into prostitution.

4. There was a further development on 14[th] December 2018, when complainant PO (born September 1994) arrived
at Dundalk Garda station. She reported that she had been offered a job as a nursing assistant in Ireland. She
explained that her circumstances were difficult, that she had come from a poor background, had two children, and
wanted to take the job in order to send money back to her children and her parents. She gave details of being in
contact with a Nigerian woman called Alicia who knew a friend of her mother's. She explained that she had
undergone a Voodoo-type ritual before leaving Nigeria, and when she came to Ireland, she, too, like the other
complainants, had been forced into working as a prostitute. She was able to leave the situation with the help of an
Irish male with whom she became friendly.

5. In the case of JE, she had travelled from Nigeria to Ireland in the belief that she was going to get work in an Afro
shop in Dublin. In 2015, she had been working as a water seller on the streets of her home city of Benin and she
was put in touch with a woman called Alicia Edosa Amoseoden. She reported that Ms. Edosa was originally from
Benin City, but at that point was living in Ireland. In the course of a telephone conversation, the complainant was
told that there was a job available in Ireland working as a manager in an Afro shop and that she would be paid
€2,000 per month. JE agreed to take the job and arrangements were put in place by the person she knew as Alicia
for her to travel to Ireland. Prior to departing for Ireland, JE was required to take a trip to a Voodoo shrine or a Juju
in Benin City where she was required to undertake an oath of loyalty to Ms. Edosa. The ritual involved the shaving
of her body and the oath required her to commit not to seek to escape from Alicia or to speak to police about the
matter.

6. JE arrived in Dublin Airport in September 2016. She was met at the airport by a Nigerian man who brought her to
a fast-food restaurant in the airport where she was first introduced to Ms. Edosa, and also to another woman, Ms.
Enoghaghase, who was also known as Cynthia. JE was driven by Ms. Edosa and Ms. Enoghaghase to Mullingar
where she was first taken to the home of Ms. Edosa. Over the following days, it became apparent that she was not
going to be working in an Afro shop. She was told by Ms. Edosa that she was going to be required to work as a
prostitute under the direction and control of Ms. Edosa.

7. At trial, JE's evidence was that she never wanted to work as a prostitute but was forced to do so by Ms. Edosa
under threats, fear of those threats, a Voodoo death curse and a warning of harm to her family in Nigeria. In
addition, she was told that she would be required to pay Ms. Edosa the sum of €35,000 for the cost of bringing her


-----

to Ireland. In evidence, JE outlined in some detail her work over a two-year period in forced prostitution working
under the direction and control of Ms. Edosa. The sex work initially began in Ms. Edosa's home apartment and then
at another apartment controlled by Ms. Edosa at another location in Mullingar. In time, her work expanded, and she
was forced to work in cities and towns across Ireland. She was directed by Ms. Edosa as to the locations to which
she was to travel, and all money generated from her work had to be lodged into a bank account provided to her by
Ms. Edosa. On 14[th] May 2018, she was directed to travel to Carrick-on-Shannon for the purpose of providing sexual
services to clients. On that occasion, there was contact between herself and SI. Thereafter, both travelled to Dublin
and made their way to Store Street Garda station. 8. So far as complainant SI is concerned, in September 2017,
she was working selling top-up credit from a kiosk in Benin City, and was approached by a woman who told her she
was very beautiful, and she was asked whether she would like to go to Ireland and work in sales in an Afro clothes
shop. SI accepted the offer. A few days later, the woman instructed SI to go to an immigration office in Benin City.
She was provided with a false name and would later receive a false Nigerian passport. A few days after the initial
contact, a woman called Cynthia phoned and told her that when she came to Ireland, she would be working for her
and would be paid €2,000 a month. She, too, was instructed to attend a Voodoo shrine or Juju, and there take an
oath that she would not steal from Cynthia and that she would not tell the police anything about Cynthia, and she
was told that if she broke that oath, “her mother would go to hell and she would roam mad”. She travelled to Ireland
through Istanbul, Greece, France and Italy. On 4[th] November 2017, she arrived in Dublin Airport, was met by
“Cynthia” and her husband, and driven to an address at Meeting House Lane in Mullingar.

9. At trial, the evidence was that the woman known to the complainant as Cynthia was Ms. Enoghaghase. Over the
following days, it became apparent to SI that she was not going to be working in an Afro shop, and she was told
that she was going to work as a prostitute under the direction and control of Ms. Enoghaghase. Again, SI made
clear that she never wanted to work as a prostitute but was forced to do so by Ms. Enoghaghase through fear, by
reason of threats, by reason of the Voodoo curse and the warning and threat of harm to her family back in Nigeria.
She was told that she would be required to pay €60,000 in respect of the costs of bringing her to Ireland. SI
explained that her work as a prostitute under the control of Ms. Enoghaghase began from an apartment in Cork, but
over time, SI was forced to work in various towns and cities across Ireland. During the period December 2017 to
January 2018, Ms. Enoghaghase was in Africa, so SI was, she said, required to work under Ms. Edosa's direction.
All the monies generated by her as a sex worker had to be lodged into an account provided by Ms. Enoghaghase.
SI was aware of another Nigerian woman, JE, who was in a similar situation. It appears they were in contact with
each other from early May, and then they decided to go to Dublin together.

10. In relation to PS, she was also from Benin City, and she left Nigeria in July 2017, arriving in Dublin on 27[th]
August 2017. Her background was particularly difficult. She had lived in Benin City with a woman she called her
aunt. In the course of the sentence hearing, her upbringing was described as horrendous, she was brought up
without any schooling and was forced into prostitution by her aunt from the age of 14 years. In Nigeria, she was
provided with false documentation. She, too, was brought to a Voodoo ceremony presided over by a “Chief Priest”.
The ceremony involved her taking an oath and having her hair shaved. A chicken was sacrificed, at which point the
complainant was required to pull its heart out and to undertake various tasks during the ritual. In Dublin, PS was
told by Ms. Enoghaghase that the oath she had taken in Nigeria meant that she had to pay back the sum of
€50,000 in respect of the costs of bringing her to Ireland, and that if she failed, either she or her son would die. PS'
first assignment as a prostitute was in Killarney, and before commencing, she was reminded of the Juju oath and
was warned that she would die if she did not pay the money that was owed. PS travelled to many towns across
Ireland. The money generated by her work was lodged into various bank accounts on Ms. Enoghaghase's
instructions. In addition, she would keep cash and hand it to Ms. Enoghaghase when she returned to Mullingar. In
January 2018, with the assistance of a regular client, she made her way to England by ferry.

11. Finally, in the case of complainant PO, she explained initially to Gardaí at Dundalk Garda station that, while
living at home in Nigeria, she had been offered a job as a nursing assistant in Ireland. She left Nigeria on 15[th]
December 2017. Prior to leaving, she, too, underwent a Juju or Voodoo ritual. The Voodoo priest made small cuts
on her body, and she was required to swear that she would not run away or would not report Ms. Edosa to the
police. At the ritual ceremony, she was told that she would die, and her children would be killed if she ran away or


-----

was not loyal. She travelled to Ireland via Greece and Italy. She was in Italy between 15[th] and 27[th] December where
she was provided with a false Irish passport.

**12.  Upon arrival in Ireland, PO was required to work as a prostitute from the end of January 2018 until**
the end of July 2018. She would travel to different towns around Ireland, spending a week at a time in different
apartments. Her evidence was that Ms. Edosa would take the bookings and would contact PO on a mobile phone
with the details of when the clients would be arriving. Her evidence was that most weeks, she deposited sums of
the order of €1,500 to €3,000 into various bank accounts the details of which were given to her by Ms. Edosa. She
had made a note of these lodgements and recorded the dates and the amounts deposited. Her last assignment was
in Letterkenny in late June, and she then contacted a male friend from Dundalk who provided her with assistance.

**13.** Following the report to Gardaí, the homes of both respondents were searched on foot of search
warrants obtained by the Gardaí. In addition, each respondent was arrested and detained for questioning. Both
were interviewed on multiple occasions but made no admissions.

Grounds of Appeal and Application

14. As to the appeal against conviction brought by Ms. Edosa, four grounds were raised.

They are as follows:

(i) The trial judge erred in fact and in law in refusing to direct verdicts of not guilty in respect of the human trafficking
charges in circumstances where a complainant admitted to having destroyed evidence. Further, the trial judge erred
in fact and in law by refusing to direct verdicts of not guilty by reason of the Garda failure to carry out further
investigations into phone records.

(ii) The trial judge erred in law and in fact in refusing to direct verdicts of not guilty in respect of the human trafficking
charges in circumstances where there was no evidence to infer the complainants were “vulnerable”.

(iii) The trial judge erred in law and in fact in admitting the bank records of Ms. Edosa in circumstances where they
were obtained in breach of the constitutional right to privacy.

(iv) The trial judge erred in law and in fact in refusing to direct not guilty verdicts in respect of the money laundering
charges, in circumstances where same were duplicitous, vague and there was insufficient evidence from which a
jury could find that the appellant knew the sums were the proceeds of crime.

However, at the hearing of the appeal, only one ground of appeal was pursued: ground (i) as to the missing
evidence.

15. The grounds of application for both undue leniency reviews are the same. The Director contends inter alia that
the sentencing judge did not have due regard to the nature and gravity of the offending and did not impose a
proportionate sentence in that regard. It is said the sentencing judge did not have appropriate regard to the
aggravating factors and did not calibrate the sentences to the seriousness of the offending. The Director takes issue
with the pre-mitigation sentences, in that they did not calibrate with the seriousness of the offending and considers
that the judge attached excessive weight to the mitigating factors in the case. It is said also that the sentencing
judge failed to place appropriate weight on deterrence.

The Conviction Appeal by Alicia Edosa

**16.  It will be recalled that Ms. Edosa was convicted of two counts of human trafficking in respect of PO**
and JE, one count of organisation of prostitution, and 34 counts of money laundering. For completeness, it should
be noted at this stage that she was acquitted of one count of committing an offence on behalf of a criminal
organisation, two counts of human trafficking against two other named individuals, and also in respect of two counts
of money laundering.

Missing Evidence


-----

**17.  This issue featured prominently in the application for a direction that was advanced on 31[st] May 2021**
and 1[st] June 2021, Days 18 and 19 of the trial. In essence, the complainants JE and PO stated in evidence that
they had been given phones which they used for contact with Ms. Edosa. Both stated that the phone number for
Ms. Edosa was 089-5997966. Both complainants made their mobile phones available to Gardaí. The phone
provided by complainant JE contained a number of outgoing messages to 089-5997966. The phone contained a
number of deleted messages. A similar situation prevailed in the case of another complainant, SI; Ms. Edosa was
acquitted in respect of the charges relating to the latter.

**18.  In the case of the phone provided by JE and also by complainant SI, the phones contained a number**
of deleted messages. The phone provided by complainant PO was essentially blank with no information on it.
Complainants JE and PO rejected suggestions put to them that they had colluded in relation to how they were going
to approach the Gardaí and in relation to what evidence they would provide.

19. At trial, Garda Paul O'Leary gave evidence of carrying out an XRY analysis of the phones of JE and SI, which
indicated that 29 out of 101 messages had been deleted on one phone and 27 out of 117 messages deleted on the
other. The phones in question were not smartphones. They were variously described as throwaway phones or
burner phones. It appears the phones had very limited memory and an element of over-writing would be expected.
Garda O'Leary made clear that the exercise that he undertook in relation to the phones of SI and JE did not reveal
whether deletions were deliberate or accidental.

20. No subscriber information or similar information from telecommunications companies was provided in respect of
the phones, either those of the complainants, or the 089 phone. Ms. Edosa has denied at all stages that the 089
phone was her phone.

21. The issue raised in relation to the telephones was advanced in the context of a contention that the fact that the
complainants had contacted Gardaí in similar circumstances, bringing with them similar material, should have put
Gardaí on notice of the need to carry out a detailed investigation to see whether there was any supporting
documentation for their allegations. It was said that while there was cause for general concern, the concern in
relation to phones was heightened. Both JE and SI had travelled on the train and provided phones on the same
day. In each instance, there was substantial deletion of phone records. In the case of PO, the phone that she had
provided was essentially completely blank. None of the phones recorded incoming calls. The contention was
advanced that while there was a basis for criticism of the complainant, there was also a basis for significant criticism
of the Gardaí, who, it was contended, had been guilty of significant failure.

22. The judge's ruling on the issue focused in particular on the fact that JE had discarded the SIM card from her
phone. The judge was prepared to accept that this had the potential to have contained evidence which could be
relevant to the proceedings and from which the jury might well have derived assistance. The judge indicated that he
accepted there was a jurisdiction to stop a trial if a Court was satisfied that the conduct of someone relevant to the
investigation was so pronounced and egregious that it deprived the jury of information which was necessary to
determine a trial. However, he was satisfied that, in the case before him, the threshold for stopping a trial by reason
of the discarding of the SIM card just did not arise.

23. In this Court's view, the approach of the trial judge was a perfectly reasonable one, and indeed, a correct one.
The suggestion that what was deleted or destroyed – however the deletions came to occur, or the SIM card
destroyed – contained material that was exculpatory of Ms. Edosa is pure speculation. There is further no evidence
to the effect that Gardaí should have been put on notice of a need to carry out a further investigation as a result of
the telephones.

The Undue Leniency Reviews

24. Having rejected the appeal against conviction of Ms. Edosa, we turn to the applications brought by the Director
pursuant to s. 2 of the Criminal Justice Act 1993, seeking to review the sentences imposed on grounds of undue
leniency. The trial judge dealt with this matter by imposing substantive sentences in respect of the human trafficking
offences, with lesser concurrent sentences in respect of the organisation of prostitution and money laundering
offences In the case of Ms Edosa the human trafficking offences were dealt with by way of a sentence of 68


-----

months imprisonment on each count, the sentences to run concurrently, and they were backdated to 14[th] April
2019. Thus, the effective sentence in Ms. Edosa's case was one of five years and eight months imprisonment. In
the case of Ms. Enoghaghase, the sentence identified was one of 62 months imprisonment in respect of each of the
two human trafficking offences, sentences that were reduced to 61 months in recognition of time already spent in
custody. Thus, her effective sentence was one of five years and one month imprisonment.

25. In a situation where the trial judge dealt with matters by imposing the substantive sentence on the human
trafficking counts, and where broadly comparable sentences were imposed in respect of the counts involving the
organisation of prostitution, the focus of the submissions on appeal has been on these counts.

26. This is believed to be the first case of an offence involving human trafficking contrary to the 2008 Act coming
before the Irish courts. It is therefore appropriate to set out the terms of s. 4 of the Act so far as relevant:

“4.— (1) A person (in this section referred to as the 'trafficker') who trafficks another person (in this section referred
to as the 'trafficked person'), other than a child or a person to whom subsection (3) applies, for the purposes of the
exploitation of the trafficked person shall be guilty of an offence if, in or for the purpose of trafficking the trafficked
person, the trafficker—

(a) coerced, threatened, abducted or otherwise used force against the trafficked person,

(b) deceived or committed a fraud against the trafficked person,

(c) abused his or her authority or took advantage of the vulnerability of the trafficked person to such extent as to
cause the trafficked person to have had no real and acceptable alternative but to submit to being trafficked,

(d) coerced, threatened or otherwise used force against any person in whose care or charge, or under whose
control, the trafficked person was for the time being, in order to compel that person to permit the trafficker to traffick
the trafficked person, or

(e) made any payment to, or conferred any right, interest or other benefit on, any person in whose care or charge,
or under whose control, the trafficked person was for the time being, in exchange for that person permitting the
trafficker to traffick the trafficked person.

(2) In proceedings for an offence under this section it shall not be a defence for the defendant to show that the
person in respect of whom the offence was committed consented to the commission of any of the acts of which the
offence consists.

(3) A person who trafficks a person who is mentally impaired for the purposes of the exploitation of the person shall
be guilty of an offence.

(4) A person who—

(a) sells another person, offers or exposes another person for sale or invites the making of an offer to purchase
another person, or

(b) purchases or makes an offer to purchase another person, shall be guilty of an offence.

(5) A person who causes an offence under subsection (1), (3) or (4) to be committed shall be guilty of an offence.

(6) A person who attempts to commit an offence under subsection (1), (3), (4) or (5) shall be guilty of an offence.

(7) A person guilty of an offence under this section shall be liable upon conviction on indictment—

(a) to imprisonment for life or a lesser term, and

(b) at the discretion of the court, to a fine.”


-----

The definition of exploitation is to be found in the “Interpretation” section of the Act, s. 1. It is there provided that
exploitation means:

“(a) labour exploitation,

(b) sexual exploitation, or

(c) exploitation consisting of the removal of one or more organs of a person”.

Sexual exploitation in relation to a person is then defined as meaning:

“(a) the production of pornography depicting the person either alone or with others, (b) causing the person to
engage in sexual activity for the purposes of the production of pornography,

(c) the prostitution of the person,

(d) the commission of an offence specified in the Schedule to the Act of 2001 against the person; causing another
person to commit such offence against the person or causing the person to commit such an offence against another
person, or

(e) otherwise causing the person to engage or participate in any sexual, indecent or obscene act”.

27. As this is believed to be the first case of human trafficking to come before the Irish courts, the sentencing judge
was required to undertake the task of imposing sentence without the guidance that would often be provided by
sentences in comparable cases; here, there were no comparators. In those circumstances, the Director has
suggested to this Court that useful assistance could be obtained from guidelines adopted by the English Sentencing
Council in October 2021, a sentencing guideline for “[s]lavery, servitude and forced or compulsory labour/ Human
[trafficking”. The Director says that while human trafficking is defined in more general terms in the English Modern](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
**_[Slavery Act 2015,the conduct with which it is concerned is essentially the same as that in issue in the 2008 Act in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
Ireland. The English guidelines identify three levels of culpability described as follows:

A. High Culpability

- “Leading role in the offending

- Expectation of substantial financial or other material advantage

- High degree of planning/premeditation

- Use or threat of a substantial degree of physical violence towards victim(s) or their families

- Use or threat of a substantial degree of sexual violence or abuse towards victims or their families”

B. Medium culpability

- “Significant role in the offending

- Involves others in the offending whether by coercion, intimidation, exploitation or reward

- Expectation of significant financial or other material advantage

- Use or threat of some physical violence towards victim(s) or their families

- Use or threat of some sexual violence or abuse towards victim(s) or their families

- Other threats towards victim(s) or their families


-----

- Other cases falling between [higher and lower culpability] because o Factors in both the higher and lower category
are present which balance each other out and/or o The offender's culpability falls between the factors as described

[under higher and lower culpability]”

C. Lower culpability

- “Engaged by pressure, coercion or intimation or has been a victim of slavery or trafficking related to this offence

- Performs limited functions under direction

- Limited understanding or knowledge of the offending

- Expectation of limited or no financial or other material advantage

- Little or no planning/premeditation”

The English guidelines also identify four harm categories, paraphrased as:

1. Exposure of victims to high risk of death. A category 2 offence may also be elevated to category 1 by: (a) the
extreme nature of one or more factors; or (b) the extreme impact caused by a combination of factors.

2. Serious psychological harm which has a substantial and/or long-term effect; substantial and long-term adverse
impact on the victim's daily life after the

offending has ceased; victim(s) deceived or coerced into sexual activity.

3. Some physical harm; some psychological harm; significant financial loss/disadvantage to the victim(s); exposure
of victim(s) to additional risk of serious physical or psychological harm; other cases falling between categories 2 and
4 because: (a) factors in both categories 2 and 4 are present which balance each other out; and/or (b) the level of
harm falls between the factors as described in categories 2 and 4.

4. Limited physical harm; limited psychological harm; limited financial loss/disadvantage to the victim(s).

28. The Director has drawn attention to a number of English cases from which it is suggested assistance can be
derived. In the case of R v. Zielinski [2017] EWCA Crim. 758, the facts were that the defendant had conspired with
family members to trick desperate Poles, who spoke no English, to travel to England on the promise of well-paid
work. The offender and his family housed victims in appalling conditions, threatened and beat them, forced them to
work in regular jobs and took their wages. Following conviction on two counts of trafficking for exploitation contrary
to s. 2 of the Modern Slavery Act 2015, the matter came before the UK Court of Appeal where sentences were
increased to seven years imprisonment. Of note are the observations of the Court about factors relevant when
assessing gravity, these being:

(i) the level of organisation and planning behind the scheme;

(ii) the deception involved from the outset in persuading the victim to travel to the UK;

(iii) the relatively large number of victims involved;

(iv) the duration and persistence of the conspiracy;

(v) the poor standard of accommodation provided;

(vi) the methods used to control the victims;

(vii) the level of vulnerability of the victims;

(viii) the level of harm caused by the offending and the lasting effect on those victims; and,


-----

(ix) whether the offending was for financial gain.

29. Of particular interest is the case of _R v. Iyamu_ _[2018] EWCA Crim 2166. Here, the facts had significant_
similarities to the present case. The defendant, a native of Liberia based in London, organised for five or possibly
six young women from the Benin City region of Nigeria to be trafficked to Germany to work as prostitutes with the
proceeds of their activity going to her. Particularly noteworthy is the fact that, before leaving Nigeria, the victims all
had to undergo a pre-trafficking Juju ritual. At this juncture, it should be observed there are some distinctions that
go in both directions. In Iyamu, five out of six of the complainants were aware that they would become prostitutes
upon arriving in England, contrasting with the present facts. On the other side of the coin, the complainants in
_Iyamu were forced to undergo a perilous sea journey from Italy to England. In Iyamu, the defendant was sentenced_
to 13 years imprisonment for the trafficking offence with a concurrent one-year sentence for perverting the course of
justice. The UK Court of Appeal increased the sentence for trafficking to 17 years imprisonment.

30. In the course of her submissions, the Director has drawn attention to the cases DPP v. Byrne _[[2018] IECA 120,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6833-XSP3-RSJG-B52J-00000-00&context=1519360)_
and DPP v. JMcD _[[2021] IECA 31. In each case – Byrne was dealing with inter alia robbery and JMcD with inter alia](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6833-XX03-RSRP-M4R0-00000-00&context=1519360)_
defilement – the Court operated on the basis that the effective maximum was likely to be 15 years and then
proceeded to divide the effective available range into three segments: 0-5, 6-10 and 11-15. The Director
acknowledged that the Court might wish to adopt a similar approach in the present case, but suggested that a
higher effective maximum, of the order of 18 to 20 years, could be considered. The Director submits that the harm
element involved in human trafficking can be multi-dimensional in nature, and that accordingly, sentences of up to
20 years imprisonment should be possible for particularly egregious cases. The Director submits that cases in the
highest range would be cases where headline sentences of 12 to 15/18 or 20 years would be appropriate. The
factors that would bring a trafficking offence into the higher range, according to the Director, would include:

(i) the victim having been exposed to a high risk of death;

(ii) the victim having been exposed to and/or suffered serious physical or psychological harm;

(iii) the victim having been coerced or deceived into engaging in sexual activity;

(iv) the offender having played a leading role in the offending;

(v) a significant level of planning or meditation;

(vi) the use of threats of violence against the victim;

(vii) there being more than one victim;

(viii) the deprivation of the victim's liberty including their freedom of movement within the State and their ability to
decide where and with whom they should live;

(ix) the expectation on the part of the offender of significant financial reward;

(x) advantage having been taken of victim's vulnerability, including lack of familiarity with the county or environment
in which they found themselves, linguistic difficulties, impoverished circumstances, and any belief on the part of
victims, perhaps driving from traditional rituals, that they were obliged to obey all orders directed to them;

(xi) victims having been prevented from seeking assistance, including an opportunity to reveal their circumstances
and experience to police, social services or health providers.

31. For our part, we regard this checklist created by the Director as very helpful in identifying factors that would tend
to put a trafficking offence into the highest category. We also agree with the Director that it is not to be expected
that all factors will be present in any particular case, but that the presence of several of them would justify placing
an offence in the highest sentencing range.


-----

32. The Director has submitted that, in this case, the sentencing judge should have placed the trafficking offences in
the highest range, or if not that, then at the very least at the very upper end of the middle range. The Director draws
attention to the fact that there were a number of factors present which would tend to see the offence put in the
highest range, including the fact that there were four victims involved, that all victims were highly vulnerable, that
the victims were effectively coerced into engaging in prostitution, that the trafficking operation was the product of a
high degree of planning, that the offending was motivated by the expectation of significant financial profit (which
materialised for those involved), the high level of psychological harm inflicted on the victims, and the severe
restrictions imposed on the victims' personal liberty, as well as the level of control to which they were subjected.

The Trial Judge's Approach to Sentencing

33. To firstly summarise the factual background, the judge made it clear that he took the view that he was
sentencing in respect of the operation of an enterprise of trafficking within Ireland and was not sentencing for any
involvement in the activity of bringing each of the four victims from Nigeria to Ireland. What had occurred in Nigeria
and outside the State in terms of the arranging of false documentation and the orchestration of the administration of
oaths represented background circumstances that went to the extent of the premeditation involved. In that context,
he observed that the crimes could in no way be characterised as opportunistic or something into which the
offenders had drifted. There was a calculated decision to exploit the individuals. The judge referred in considerable
detail to the evidence that had been put before the Court about the extent of the impact these offences had on each
of the victims.

34. The judge identified multiple factors which he saw as aggravating while also being careful to point to the fact
that there were other factors absent which, had they been present, would have further aggravated the offences,
such as, for example, would have been the case had those trafficked been underage. The judge referred to the fact
that a practice had developed of dealing with offences where the maximum sentence available was life
imprisonment, identifying an effective maximum of 15 years and then dividing the available 15 years into three
segments. He indicated that he saw a headline sentence as falling beyond the halfway point of midrange, but not
into the highest segment, that being between 10 and 15 years. The judge then proceeded to nominate a headline
sentence for each of the four counts of trafficking as being 96 months or eight years.

35. Having identified a headline sentence, the judge then referred to the need for deterrence and the desirability of
addressing the need for rehabilitation. So far as the personal circumstances of the offenders were concerned, he
felt that there were factors present in the case of the two offenders which would have made them less conscious of
the evil that they were doing because they themselves, to some extent or other, had gone through something
similar. He felt that this might provide a psychological explanation for an inability to empathise with the people they
were harming. In that regard, he referred to a psychological report that had been made available in the case of Ms.
Edosa and made particular reference to the extent of the trauma that had been inflicted in the past upon Ms.
Enoghaghase.

36. In terms of the background and circumstances of the two respondents, the judge noted that neither had any
previous convictions. There were aspects of their previous lives which showed them behaving as persons of good
character, in that regard he referred to the fact that Ms. Edosa had worked for a time as a care worker, and that Ms.
Enoghaghase was the mother of three small children. He referred to the fact that both respondents had suffered
trauma in the past; this was particularly so in the case of Ms. Enoghaghase who had been rescued as a child from
prostitution and who had then been abused while in care.

37. Having reviewed the personal circumstances of both respondents, the judge indicated that, having taken 96
months as the headline sentence, because of the previous good character of each of them, he was going to take as
a starting point, before considering other personal mitigating factors, a sentence of 82 months. He then indicated
that, in the case of Ms. Edosa, having reduced his starting point substantially because of her previous good
character, the harshness of the life she had led, and the isolation that existed in her life, he was going to move to a
figure of 72 months. However, he did not stop there, noting that, because the steps Ms. Edosa had taken in prison
were signs of hope and engagement, he was going to impose a sentence of 68 months imprisonment. The judge
then engaged in a similar exercise in the case of Ms. Enoghaghase, observing that in her case, he referred once


-----

more to the extent of the trauma in her background, describing it as “quite pronounced”, and proceeded to impose a
sentence of 62 months, reducing this by one month to take account of a period that appeared to have been spent in
custody before obtaining bail.

Discussion and Decision

38. For our part, we can see considerable merit in the view that the effective maximum headline should be set in the
range of 18 to 20 years. We find it easy to imagine cases where such sentences would be fully justified. However,
in a situation where this is the first case of trafficking to come before the courts, we are slow to depart from what is
now the wellestablished practice of taking 15 years as an effective maximum, while recognising, as has always
been done, that there may be particularly egregious offences justifying or requiring a higher figure up to and
including life imprisonment. Therefore, it seems to us that the headline or pre-mitigation sentence in each case
cannot properly be less than ten years imprisonment, and that to fix a headline or pre-mitigation sentence less than
that would amount to an error. However, the mere finding of an error in approach is not per se sufficient to justify
interference by this Court on the grounds of undue leniency. The jurisprudence in this area is well settled, see in
particular: _DPP v. Byrne [1995] 1 ILRM 279;_ _DPP v. McCormack_ _[[2000] 4 IR 356; and,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4RHY-V0T0-TXX6-9117-00000-00&context=1519360)_ _DPP v. Stronge_ _[[2011]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6833-XKF3-RSC8-21X4-00000-00&context=1519360)_
_[IECCA 79. These authorities establish that it must be proved that the sentence imposed constituted a substantial or](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6833-XKF3-RSC8-21X4-00000-00&context=1519360)_
gross departure from what would be the appropriate sentence in the circumstances. There must be a clear
divergence and discernible difference between the latter and the former, and this will usually have been caused by
an error of principle.

39. As aforementioned, the offence being dealt with here is a new one, of which there are no comparators in this
jurisdiction. As such, determining whether the sentences imposed constitute a substantial or gross departure from
the norm could be problematic. However, the Court has addressed this issue in the case of DPP v. Mahoney _[[2016]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6833-XPT3-RSJG-B24C-00000-00&context=1519360)_
_[IECA 27, with Edwards J. at para. 40 proffering that a wide interpretation of the word norm should be adopted:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6833-XPT3-RSJG-B24C-00000-00&context=1519360)_

“Rather, we believe the norm spoken of refers to what might be predicted to be the result, within a reasonable
margin of appreciation, of a faithful application to the facts of the individual case of appropriate sentencing
principles, whether or not there are any useful comparators.”

40. We are satisfied that the sentences actually imposed in this case did represent a substantial departure from
what we consider would have been the appropriate sentences in the circumstances. Accordingly, we are satisfied
that those sentences were unduly lenient. In fairness to the sentencing judge in this case, he was faced with having
to sentence for a new type of offence in the absence of any comparators, guidelines or appellate court guidance.
Accordingly, while we have expressed disagreement with his calibration of the gravity of the respondents' offending
conduct, we think it important to say that our recording of such disagreement does not amount to criticism of him.

41. In circumstances where we have found the sentences imposed by the court below to have been unduly lenient,
we must therefore quash those sentences and proceed to resentence. It also clearly follows from the finding of
undue leniency that Ms. Enoghaghase's cross-appeal against the severity of her sentence is being dismissed.

42. As the sentencing judge correctly pointed out, there were some factors present that allowed for mitigation from
the headline sentence, these being, principally, the absence of previous convictions and the difficult backgrounds
that applied in both cases. The approach of the sentencing judge was to address these by reducing the headline or
pre-mitigation sentence, in the first place by 25%. We do not think the judge was in error in that regard, so we will
reduce both headline sentences to ones of seven and a half years. The sentencing judge, who was particularly well
placed to make an assessment of this, having presided over a six-week trial, felt it appropriate to differentiate
between the two appellants to a limited extent and we will follow his lead in that regard. So, we will further reduce
the sentence of Ms. Enoghaghase by an additional five months.

43. Accordingly, the sentences on the trafficking offences will be ones of seven and half years in the case of Alicia
Edosa and seven years and one month imprisonment in the case of Edith Enoghaghase.

44. This was a case where the various offences charged, trafficking, organising prostitution offences, and money
laundering though in the particular circumstances of the case the focus is on the trafficking and prostitution


-----

were all inextricably linked. We agree that this was a case for concurrent sentences, though it followed that as the
activity involved offences as serious as human trafficking and organising prostitution, the headline sentence had to
recognise this fact. In relation to the human trafficking offences, we have identified a headline or pre-mitigation
sentence of ten years imprisonment and proceeded to mitigate this, for the reasons explained, to seven and a half
years in the case of Ms. Edosa and to seven years and one month imprisonment in the case of Ms. Enoghaghase.
We will impose similar sentences in respect of the organising prostitution offences, and we will leave the money
laundering sentences unaltered. All sentences are concurrent, and the sentences will date from the dates indicated
in the Circuit Court.

**End of Document**


-----

