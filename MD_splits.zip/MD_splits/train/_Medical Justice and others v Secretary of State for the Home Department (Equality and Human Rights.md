Commission intervening) [2017] EWHC 2461 (Admin)

# *Medical Justice and others v Secretary of State for the Home Department
 (Equality and Human Rights Commission intervening) [2017] EWHC 2461
 (Admin)

Queen's Bench Division, Administrative Court (London)

Ouseley J

10 October 2017Judgment

**Ms Stephanie Harrison QC and Ms Shu Shin Luh** (instructed by Bhatt Murphy) for the **1st – 3rd**
**Claimants**

**Mr Christopher Buttler and Ms Ayesha Christie** (instructed by **Duncan Lewis) for the** **4th – 8th**
**Claimants**

**Ms Nathalie Lieven QC and Ms Sarah Hannett** (instructed by the **solicitor to the EHRC)** for the
**Intervener**

**Mr James Strachan QC and Mr Rory Dunlop (instructed by the Treasury Solicitor) for the Defendant**

Hearing dates: 7-10 March 2017

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Mr Justice Ouseley:**

**Introduction**

1. At the heart of these judicial review claims is the contention that the Secretary of State, SSHD, has
issued unlawful statutory Guidance, and policies, albeit for the lawful purpose of preventing those who are
more vulnerable to harm in immigration detention from entering immigration detention, or for removing
them from it, unless there are sufficiently strong countervailing reasons. Being a victim of torture is an
indicator of such vulnerability. The unlawfulness is said to arise from the way in which victims of torture are
defined, through the adoption, with a variation, of the definition of “torture” to be found in the United Nations
Convention against Torture, UNCAT. This had the effect, it was said, of excluding those who are victims of
torture by non-state actors, from those whose circumstances indicate vulnerability to harm in detention.
The SSHD's response is essentially that the statutory Guidance and policies have been misunderstood.
But there are many other issues to be considered along the way.

2. The statutory Guidance at issue is the “Adults at Risk in Immigration Detention”, AARSG, issued under
s59 of the Immigration Act 2016, after it had been laid before Parliament on 22 August 2016, and approved
under the negative resolution procedure. This Guidance came into force from 12 September 2016, in
accordance with the Immigration (Guidance on Detention of Vulnerable Persons) Regulations 2016 SI No.
847.


-----

Commission intervening) [2017] EWHC 2461 (Admin)

3. The two policies at issue are (1) the Detention Services Order, DSO 9/2016, in effect from 12
September 2016, dealing with the Detention Centre Rules 2001 SI No. 238, DCR, made under s153 of the
Immigration and Asylum Act 1999 for the regulation and management of removal centres; R35 of the DCR
relates to medical reports on those who are in detention; and (2) Chapter 55b of the Enforcement
Instructions and Guidance, EIG 55b, which provides, for Home Office staff including case workers,
Guidance entitled “Adults at risk in immigration detention”. As the title suggest, it relates to the new
AARSG. It was published on 9 September 2016, for implementation from 12 September 2016.

4. Three broad issues were raised by the Claimants: (1) the definition of “torture” used in the AARSG was
unlawfully restrictive, was contrary to the definition of “torture” in the Detention Centre Rules and R35 in
particular, and had no rational justification in relation to the identification of those particularly vulnerable to
harm in immigration detention; (2) the EIG 55b caseworker guidance was inconsistent with the AARSG
which took precedence over it; and (3) the public sector equality duty in s149 of the Equality Act 2010 had
not been complied with (I permitted the Equality and Human Rights Commission, EHRC, to intervene on
this issue).

5. The claims of the individual lead Claimants for damages for unlawful detention were considered
because of what they illustrated for the general issue. I am also asked to decide whether their detention
was in pursuit of an unlawful policy or alternatively was inconsistent with the SSHD's published policy. But
in the light of the concessions by the SSHD that the decisions in relation to their detention had all been
unlawful for one reason or another, issues as to whether they would have been detained anyway pursuant
to a lawful decision, and thus whether they were entitled to substantial or nominal damages, were
adjourned by prior agreement to another hearing. That hearing will also be able to decide whether the
basis on which the SSHD conceded that the detention decision was unlawful was correct or whether the
Claimants were correct, in so far as that issue still arises.

**The background to the AARSG and policy**

6. It is necessary, to set the scene for the subsequent submissions, to put the Guidance and policy on
immigration detention in their proper context. A person may be placed in immigration detention while a
claim for asylum or protection, or some other basis for remaining in the UK, is being considered and
appealed; and it may arise pending removal of those whose claims have been dismissed. This case is not
primarily concerned with the question of the impact which detention may have on the fairness of the
resolution of claims while detained, nor with the length of detention while removal is attempted or effected.
There may be an interrelationship with those issues, but the focus is on identifying those who should be
regarded as particularly vulnerable to harm in immigration detention, and whose detention therefore
requires commensurately greater justification.

7. Schedules 2 and 3 to the Immigration Act 1971 provide the general statutory basis for immigration
detention, whether pending examination by an immigration officer, or pending a decision on whether
someone should receive leave to enter, or pending a decision to give directions to remove them, or
pending removal pursuant to those directions. Other detention powers exist in s62 of the Nationality,
Immigration and Asylum Act 2002 and s36 of the Borders Act 2007. In _R (WL (Congo))_ v _SSHD_ _[2011]_
_UKSC 12, [2012] 1 AC 245, also known as Lumba, Lord Dyson JSC said at [34-36]:_

“34. The rule of law calls for a transparent statement by the executive of the circumstances in which the
broad statutory criteria will be exercised. Just as arrest and surveillance powers need to be transparently
identified through codes of practice and immigration powers need to be transparently identified through the
immigration rules, so too the immigration detention powers need to be transparently identified through
formulated policy statements.

35. The individual has a basic public law right to have his or her case considered under whatever policy the
executive sees fit to adopt provided that the adopted policy is a lawful exercise of the discretion conferred
by the statute: see _In re Findlay [1985] AC 318, 338E. There is a correlative right to know what that_
currently existing policy is, so that the individual can make relevant representations in relation to it.


-----

Commission intervening) [2017] EWHC 2461 (Admin)

…

36. Precisely the same is true of a detention policy. Notice is required so that the individual knows the
criteria that are being applied and is able to challenge an adverse decision.”

8. The Court of Appeal in R (Detention Action) v SSHD _[2014] EWCA Civ 1634 said at [14] that the latter_
passage, though formulated in the context of an unpublished policy, emphasised the importance of clarity
in a policy governing personal liberty; such policy statements needed to be formulated in a sufficiently
defined manner to enable individuals to know the criteria being applied to detain them.

9. I need to outline the previous policy for determining those who should not normally be placed
immigration detention, the role of R35(3) and the definition of “torture”. The Enforcement Instructions and
Guidance Chapter 55.10, which was to be replaced by EIG 55b, stated that “Certain persons are normally
considered suitable for detention in only very exceptional circumstances….” Eight categories were listed.
One was “Those where there is independent evidence that they have been tortured.” This was the
consistent approach over a number of years, expressed in a number of policy documents including
previous Detention Service Orders and the earlier Operating Enforcement Manual. The elderly or those
with serious medical or mental health conditions or disabilities “which cannot be satisfactorily managed
within detention,” were another category. That language was to be changed along with the provisions for
women in the earlier stages of pregnancy, as the policy for those normally unsuitable for immigration
detention evolved.

10. The Detention Centre Rules 2001, the DCR, were made pursuant to s153 Immigration and Asylum Act
1999, and were approved by Parliament under the negative resolution procedure. They remain in force.
R34 requires every detained person to have a physical and mental examination within 24 hours of
admission to the detention centre. R35 provides an important safeguard for those in immigration detention:

“35. – Special illnesses and conditions (including torture claims)

(1). The medical practitioner shall report to the manager on the case of any detained person whose health
is likely to be injuriously affected by continued detention or any conditions of detention.

…

(3). The medical practitioner shall report to the manager on the case of any detained person who he is
concerned may have been the victim of torture.

(4). The manager shall send a copy of any report under paragraphs (1), (2) or (3) to the Secretary of State
without delay.”

11. The operation of R35(3) was considered in _R (D and K)_ v _SSHD [2006] EWCA 980 (Admin), which_
concerned the lawfulness of the detention in the detained fast track of those who claimed to be the victims
of torture. The relationship of R35(3) to the need for “independent evidence of torture”, in order for
detention to require very exceptional circumstances as a matter of Government policy, was at the heart of
the case. At [50] and [53], Davis J concluded that both R34 and R35 (3), were important safeguards in
relation to the application of Government policy on detention. That was because they could provide
independent evidence of torture. The R35(3) report was distinct from reports under R35(1), and indeed
R35(2) on suicide risk.

12. There was and is no definition of “torture” in the DCR. The DSOs of 2008 and of 2012 provided none.
However, a crucial change was made in January 2013 when the Detention Rules Process Guidance was
updated. This made it clear to case workers that “torture” in EIG 55.10 was to be understood in the way in
which “torture” was defined in Article 1 of UNCAT, a definition which has been termed “UNCAT torture”.

13. Proceedings were brought by a number of individual litigants in EO and Others v SSHD _[2013] EWHC_
_1236 (Admin), supported by Medical Justice. One issue before Burnett J was what “torture” meant in the_
Rules and policy: did it mean “UNCAT torture” as the SSHD contended was now clear and in line with the
ECHR and domestic statute, or did it have a non-technical, colloquial meaning?


-----

Commission intervening) [2017] EWHC 2461 (Admin)

14. Burnett J's analysis, which I have had to consider closely in view of the arguments before me, lies
between [75]-[82]. He concluded that “torture” in the DCR and policy documents had a broader meaning
than the UNCAT definition. It was not confined to acts by state agents or in which they were complicit or
acquiesced. At [82] he said it was:

“any act by which severe pain or suffering, whether physical or mental, is intentionally inflicted on a person
for such purposes as obtaining from him or a third person information or a confession, punishing him for an
act he or a third person has committed, or intimidating or coercing him or a third person, or for any reason
based upon discrimination of any kind.”

15. That is the UNCAT definition (set out later at [32]) minus the words “when such pain or suffering is
inflicted by a public official ….” It is conveniently known as “EO torture”. Burnett J was dealing with the
issue before him, namely whether state actor involvement was required for the purpose of the definition of
“torture” in the documents he was construing. But “EO torture” is not merely a simple colloquial or nontechnical definition of “torture” either, since in addition to the intentional infliction of severe pain or suffering,
the purpose for which it was inflicted remains part of the definition. So for example, pain inflicted for
pleasure is not covered, and pain inflicted in “medical experiments” may or may not be covered depending
on whether it is based on discrimination. Severe pain inflicted to obtain information in the course of robbery
may or may not be covered. I do not suppose that it was meant to exclude the exception from the definition
of “torture” of the deliberate infliction of pain inherent in lawful sanctions.

16. Burnett J said, [79], that there had been no evidence from the SSHD that, “over the many years that
her officials were dealing with the Medical Foundation for the Victims of Torture, the Helen Bamber
Foundation or other charities in the field that they understood or applied the policy in the sense now
contended for.” The UKBA Policy Instruction had not drawn the distinction between state and non-state
perpetrators of severe pain, and had instead adopted a broad view that it covered the deliberate infliction of
severe pain, rather than a legal view. He continued in [80], saying that, important though the
understandings of the authors of the policy were, and those with whom the authors had dealings, it was for
the court to interpret the policy. “…[w]hen one considers the purpose of the policy, namely to protect those
who are particularly vulnerable to the effects of detention, I can detect no reason of sufficient weight to
depart from what I consider to have been the common understanding of the meaning of the word 'torture'
for these purposes.”

17. The SSHD contended that one factor which made detention so damaging was that victims of torture
were likely to have been detained by their torturers. Burnett J accepted, [81], that there was some support
for that view in the evidence of Professor Katona of the Helen Bamber Foundation; but he judged that the
Professor had not been suggesting that features such as being locked in a prison-like environment, with
uniformed officers, and the sound of doors being locked and unlocked repeatedly, “were necessary indicia
for torture or for serious adverse consequences if an individual were to be detained.” The evidence from
the Helen Bamber Foundation explained why the identity of the perpetrator was of little consequence: she
concluded “that there was no significant difference between the therapeutic needs of victims of torture in
the UNCAT sense or in the wider sense.” That then led to his conclusion in [82] above.

**The development of Home Office policy**

18. Ms Rouse, Head of the Illegal Immigration and Identity Security and Enforcement Unit of the
Immigration and Border Policy Unit within the Home Office, explained how the Home Office saw the
background to EO. It had always understood that the definition of “torture” to be applied for the purposes
of the EIG was the UNCAT definition.

19. Mr Rhys Jones, a legal officer with the Helen Bamber Foundation, gave contrasting evidence in his
witness statement: in his evidence in EO, he had referred to discussions about a definition of “torture” for
the Asylum Policy Instructions of 2011, not, he thought, involving Ms Rouse. He said that a definition had
been developed between Home Office officials and the Medical and Helen Bamber Foundations, which


-----

Commission intervening) [2017] EWHC 2461 (Admin)

expressly moved away from legal definitions in human rights law, to include “rape or other serious forms of
psychological, physical or sexual violence.”

20. Ms Rouse said that the SSHD had changed the DSO in 2012 and made the UNCAT definition explicit
in the Asylum Policy Instruction published in January 2014, as EO was underway. After the judgment, the
SSHD had suspended its policy of using the UNCAT definition in response to further threatened litigation,
while reserving its position for the future. It was in the context of the evolving AARSG that the Home Office
had decided that it would be appropriate to adopt the UNCAT definition, which it made public in May 2016.

21. The genesis of the new approach was the report by Stephen Shaw CBE, commissioned by the Home
Office in February 2015. It wished to review the appropriateness of its policies and practices concerning
the welfare of those in immigration detention. His report, submitted in September 2015 and published in
January 2016, ranged far more widely than the issues arising in this case. Several bodies including
Medical Justice made extensive submissions to him. He developed the concept of “particular vulnerability”
to harm in detention; it was susceptibility to physical or emotional harm, damage or injury which mattered,
the potential or likelihood of such effects rather than actual, present suffering from them. He accepted that
there were difficulties with checklists of vulnerability but recommended that the existing categories of those
presumed unsuitable for detention should be expanded, and some of the qualifications to that unsuitability
should be removed. There should be recognition of the “dynamic nature of vulnerability” in detention. There
would be persons who fell outside the scope of the categories, who should nonetheless be identified as
sufficiently vulnerable for their continued detention to be injurious to their welfare.

22. Mr Shaw also wanted an authoritative literature review of the impact of immigration detention on
mental health. Professor Bosworth provided it. She concluded that it had a negative effect; in addition to
the length of detention, the causes of mental deterioration resulting from detention included pre-existing
trauma, such as torture and sexual violence.

23. The Ministerial Statement responding to the Shaw report came with its publication in January 2016.
So far as material it said:

“First, the Government accepts Mr Shaw's recommendations to adopt a wider definition of those at risk,
including victims of sexual violence, individuals with mental health issues, pregnant women, those with
learning difficulties, post-traumatic stress disorder and elderly people, and to recognise the dynamic nature
of vulnerabilities. It will introduce a new “adult at risk” concept into decision-making on immigration
detention with a clear presumption that people who are at risk should not be detained, building on the
existing legal framework. This will strengthen the approach to those whose care and support needs make it
particularly likely that they would suffer disproportionate detriment from being detained, and will therefore
be considered generally unsuitable for immigration detention unless there is compelling evidence that other
factors which relate to immigration abuse and the integrity of the immigration system, such as matters of
criminality, compliance history and the imminence of removal, are of such significance as to outweigh the
vulnerability factors. Each case will be considered on its individual facts, supported by a new vulnerable
persons team. We will also strengthen our processes for dealing with those cases of torture, health issues
and self-harm threats that are first notified after the point of detention, including bespoke training to GPs on
reporting concerns about the welfare of individuals in detention and how to identify potential victims of
torture.”

**The new Guidance and policy**

24. S59 of the Immigration Act 2016 introduced, as a statutory concept, those “particularly vulnerable to
harm,” and required Parliamentary approval by negative resolution of the guidance issued about it by the
SSHD. S59 provides in subsections (1) and (3):

“(1) The Secretary of State must issue guidance specifying matters to be taken into account by a person to
whom the guidance is addressed in determining –

(a) whether a person (“P”) would be particularly vulnerable to harm if P were to be detained or to remain in
detention and


-----

Commission intervening) [2017] EWHC 2461 (Admin)

(b) if P is identified as being particularly vulnerable to harm in those circumstances, whether P should be
detained or remain in detention.

…

(3) A person to whom guidance under this section is addressed must take the guidance into account.”

25. Subsection (4) was relied on in relation to whether Equality Act duties were to be undertaken
personally by the Minister. It provides: “Before issuing guidance under this section the Secretary of State
must lay a draft of the guidance before Parliament.” I also note that by subsection (5) the guidance comes
into force in accordance with regulations made by the Secretary of State. The regulations state that they
were laid before Parliament by the Secretary of State, and are signed by the Minister of State.

26. The AARSG needs to be set out at some length. It states under the heading “Purpose and
background”, that its approach “emerges from the Government's response to the report of Stephen Shaw
of his review, commissioned by the SSHD, of the welfare of vulnerable people in detention.”

“1. … The intention is that the guidance will, in conjunction with other reforms referred to in the
Government's response, lead to a reduction in the number of vulnerable people detained and a reduction in
the duration of detention before removal. It aims to introduce a more holistic approach to the consideration
of individual circumstances, ensuring that genuine cases of vulnerability are consistently identified, in order
to ensure that vulnerable people are not detained inappropriately. The guidance aims to strike the right
balance between protecting the vulnerable and ensuring the maintenance of legitimate immigration
control.”

27. A case by case evidence-based assessment is envisaged. It continues:

“3. The clear presumption is that detention will not be appropriate if a person is considered to be “at risk”.
However, it will not mean that no one at risk will ever be detained. Instead, detention will only become
appropriate at the point at which immigration control considerations outweigh this presumption. Within this
context it will remain appropriate to detain individuals at risk if it is necessary in order to remove them. This
builds on the existing guidance and sits alongside the general presumption of liberty.”

28.  Ten principles underlie the guidance. I note three:

“  assessment of risk is based on the evidence available, ranging from a self-declaration of risk to
authoritative professional opinion. The level of evidence available dictates the level of evidence-based risk
into which any given individual will fall

- where professional evidence is not immediately available, but where observations from Home Office
officials lead to a belief that the individual is at a higher level of risk than a simple self-declaration would
suggest, an individual can be allocated to a higher risk category in the terms of this guidance on the basis
of that observational evidence

- in each case, the evidence of risk to the individual will be considered against any immigration factors to
establish whether these factors outweigh the risk.”

29. Paragraphs 7-9 are important and need to be set out in their entirety:

“Who is an adult at risk?

7. For the purposes of this guidance, an individual will be regarded as being an adult at risk if:

- they declare that they are suffering from a condition, or have experienced a traumatic event (such as
trafficking, torture or sexual violence), that would be likely to render them particularly vulnerable to harm if
they are placed in detention or remain in detention

- those considering or reviewing detention are aware of medical or other professional evidence, or
observational evidence, which indicates that an individual is suffering from a condition, or has experienced
a traumatic event (such as trafficking, torture or sexual violence), that would be likely to render them


-----

Commission intervening) [2017] EWHC 2461 (Admin)

particularly vulnerable to harm if they are placed in detention or remain in detention – whether or not the
individual has highlighted this themselves.

8. On the basis of the available evidence, the Home Office will reach a view on whether a particular
individual should be regarded as being “at risk” in the terms of this guidance. If, on this basis, the individual
is considered to be an adult at risk, the presumption will be that the individual will not be detained.

**Assessment of whether an individual identified as being at risk should be detained**

9. Once an individual has been identified as being at risk, consideration should be given to the level of
evidence available in support and the weight that should be afforded to the evidence in order to assess the
likely risk of harm to the individual if detained for the period identified as necessary to effect their removal:

- a self-declaration of being an adult at risk – should be afforded limited weight, even if the issues raised
cannot be readily confirmed. Individuals in these circumstances will be regarded as being at evidence level
1

- professional evidence (e.g. from a social worker, medical practitioner or NGO), or official documentary
evidence, which indicates that the individual is an adult at risk – should be afforded greater weight.
Individuals in these circumstances will be regarded as being at evidence level 2

- professional evidence (e.g. from a social worker, medical practitioner or NGO) stating that the individual
is at risk and that a period of detention would be likely to cause harm – for example, increase the severity
of the symptoms or condition that have led to the individual being regarded as an adult at risk – should be
afforded significant weight. Individuals in these circumstances will be regarded as being at evidence level
3.”

30. Paragraph 10 makes the point that court or tribunal findings on credibility may be taken into account.

31. Paragraph 11 sets out the “Indicators of risk” and with [12] is also important:

“Indicators of risk

11.  The following is a list of conditions or experiences  which will indicate that a person may be
particularly vulnerable to harm in detention.

- suffering from a mental health condition or impairment (this may include more serious learning difficulties,
psychiatric illness or clinical depression, depending on the nature and seriousness of the condition)

- having been a victim of torture* (individuals with a completed Medico Legal Report from reputable
providers will be regarded as meeting level 3 evidence, provided the report meets the required standards)

- having been a victim of sexual or gender-based violence, including female genital mutilation

- having been a victim of human trafficking or modern slavery (see paragraph 20 below)

- suffering from post-traumatic stress disorder (which may or may not be related to one of the above
experiences)

- being pregnant (pregnant women will automatically be regarded as meeting level 3 evidence)

- suffering from a serious physical disability

- suffering from other serious physical health conditions or illnesses

- being aged 70 or over

- being a transsexual or intersex person

- As defined in Article 1 of the United Nations Convention Against Torture and Other Cruel, Inhuman or
Degrading Treatment or Punishment (UNCAT)

12. It cannot be ruled out that there may be other, unforeseen, conditions that may render an individual
particularly vulnerable to harm if they are placed in detention or remain in detention In addition the nature


-----

Commission intervening) [2017] EWHC 2461 (Admin)

and severity of a condition, as well as the available evidence of a condition or traumatic event, can change
over time.”

32. The definition of torture for the AARSG and EIG 55b is spelt out in Detention Services Order, DSO
09/2016. It also purported to define “torture” for the purposes of DCR R35, which I set out here for
convenience:

**“Torture is 'any act by which severe pain or suffering, whether physical or mental, is intentionally inflicted**
on a person for such purposes as obtaining from him or a third person information or a confession,
punishing him for an act he or a third person has committed or is suspected of having committed, or
intimidating or coercing him or a third person, or for any reason based on discrimination of any kind, when
such pain or suffering is inflicted by or at the instigation of or with the consent or acquiescence of a public
official or other person acting in an official capacity. It does not include pain or suffering arising only from,
inherent in or incidental to lawful sanctions.' (Article 1 of the UN Convention Against Torture and Other
Cruel, Inhuman or Degrading Treatment or Punishment (UNCAT).) It includes such acts carried out by
terrorist groups exploiting instability or civil war to hold territory.”

33.  The reference to acts carried out by terrorist groups is not part of the UNCAT definition, but was
added following discussions between the SSHD and an NGO, Freedom from Torture; it was suggested by
Sir Keir Starmer MP.

34. The AARSG then sets out the immigration factors which may mean that a person at risk is detained.
These cases do not require consideration by me of those paragraphs, though obviously they affect
prospects of release, even if any given decision to detain is unlawful.

35. I turn next to EIG 55b, which is both the published statement of Government policy about how its
powers of detention are to be used, and its principal guidance to Home Office staff on the use of those
powers. EIG 55b deals with the new AARSG. It starts by saying that it applies to all cases in which
detention is being considered in relation to removing someone, and to those already in detention. The
underpinning presumption in immigration policy that a person will not be detained, may be outweighed by
immigration control considerations. The general principles involve asking whether someone needs to be
detained to effect removal and, if so, for how long. If an individual was identified as a person “at risk”, the
decision-maker should ask what the likely level of harm would be if they were detained for the period
necessary to effect removal. If detention for that period was likely to have a “deleterious effect”, they
should not be detained unless there were public interest concerns which outweighed that risk. The public
interest in the deportation of foreign national offenders “will generally outweigh a risk of harm to the
detainee.”

“An individual will be regarded as being at risk if:

- they declare that they are suffering from a condition, or have experienced a traumatic event (such as
trafficking, torture or sexual violence), that would be likely to render them particularly vulnerable to harm if
they are placed in detention or remain in detention

- those considering or reviewing detention are aware of medical or other professional evidence which
indicates that an individual is suffering from a condition, or has experienced a traumatic event (such as
trafficking, torture or sexual violence), that would be likely to render them particularly vulnerable to harm if
they are placed in detention or remain in detention – whether or not the individual has highlighted this
themselves

- observations from members of staff lead to a belief that the individual is at risk, in the absence of a selfdeclaration or other evidence

The nature and severity of a condition, as well as the available evidence of a condition or traumatic event,
can change over time. Therefore decision-makers should use the most up-to-date information each time a
decision is made about continuing detention.”


-----

Commission intervening) [2017] EWHC 2461 (Admin)

36. The indicators of risk are explained under a paragraph which states that “Indicators of whether an
individual may be particularly vulnerable to harm and therefore at risk include the conditions or
experiences…set out below.” Mr Strachan QC for the SSHD emphasised the word “include”. Of relevance
was what it said about “specific experiences” including torture:

“There may also be specific experiences to which the individual has (or claims to have) been subject, or
which indicate that they may suffer particular harm or detriment if detained, because those experiences
may have affected the individual's mental state. Indicators can include:

- having been a victim of torture (as defined in Article 1 of the United Nations Convention Against Torture
and Other Cruel, Inhuman or Degrading Treatment or Punishment (UNCAT)): this includes acts of torture
or ill-treatment carried out by public officials or other persons acting in an official capacity and terrorist
groups exploiting instability and civil war to hold territory – this may emerge from a Rule 35 report or from a
medico-legal report supplied by Freedom from Torture or The Helen Bamber Foundation

- having been a victim of sexual or gender-based violence; including female genital mutilation

- having been a victim of human trafficking or modern slavery.”

37. No complaint was made of what the EIG said about the evidence levels, under the heading “Assessing
risk: weighing the evidence”. It conforms to the AARSG. This is followed by the section on balancing risk
against immigration control factors. It is what is said in that section about the three evidence Levels which
drew some fire on behalf of the Claimants, because of differences in the language used there and in the
AARSG. It says of Levels 2 and 3:

**“Level 2**

Where there is professional and/or official documentary evidence indicating that an individual is an adult at
risk but no indication that detention is likely to lead to a significant risk of harm to the individual if detained
for the period identified as necessary to effect removal, they should be considered for detention only if one
of the following applies:

- the date of removal is fixed, or can be fixed quickly, and is within a reasonable timescale and the
individual has failed to comply with reasonable voluntary return opportunities, or if the individual is being
detained at the border pending removal having been refused entry to the UK

- they present a level of public protection concerns that would justify detention – for example, if they meet
[the criteria of foreign criminal as defined in the Immigration Act 2014 or there is a relevant national security](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)
or other public protection concern

- there are negative indicators of non-compliance which suggest that the individual is highly likely not to be
removable unless detained

Less compelling evidence of non-compliance should be taken into account if there are also public
protection issues. The combination of such non-compliance and public protection issues may justify
detention in these cases.

**Level 3**

Where on the basis of professional and/or official documentary evidence, detention is likely to lead to a risk
of significant harm to the individual if detained for the period identified as necessary to effect removal, they
should be considered for detention only if one of the following applies:

- removal has been set for a date in the immediate future, there are no barriers to removal, and escorts
and any other appropriate arrangements are (or will be) in place to ensure the safe management of the
individual's return and the individual has not complied with voluntary or ensured return.”

The “following” which “applies” refers to the likely length of delay before actual removal and the risk to the
public if they were released.

38 The DSO said this of the role of medical practitioners in relation to R35(3):


-----

Commission intervening) [2017] EWHC 2461 (Admin)

“Medical practitioners are not required to make a report under Rule 35(3) if they do not have concerns that
the detainee may have been a victim of torture. This includes instances where the detainee's experience of
harm or mistreatment does not meet the definition of torture given above, where there are no clinical
concerns that the detainee may have been a victim of torture, or where there is no basis for concern other
than an unsupported claim by the detainee to have been a victim of torture. As an optional aid when
seeking to explain this position to a detainee, medical practitioners might find it helpful to use the Annex D:
Rule 35(3) letter template, if they wish.”

39. It said this of R35(1) reports:

“Where the Rule 35 report is completed in accordance with Rule 35(1), which can relate to physical or
mental health issues, medical practitioners should note when they consider that an individual's health is
likely to be injuriously affected by continued detention or any conditions of detention by stating the basis,
with evidence, for that concern and giving an estimate of the timescale for remedial action, if relevant.”

40. Annexed to the DSO are template letters for medical practitioners to send to detainees after the R35
appointment. Annex A relates to R35(1). Annex C is a template R35(3) report, which includes the
definition of torture, as used in the DSO, and contains sections for the detainee's account, clinical
observations and for the medical assessment as to why the practitioner had concerns that the detainee
may have been a victim of torture, and as to the impact which detention “is having and why, including the
likely impact of ongoing detention.”

41. There is also a template letter for the detainee for use where no report is made. The last paragraph
says this:

“On the basis of what you have been able to tell me and/or the examination I have carried out, my
independent view is that a report under Rule 35 is not the appropriate process for these concerns to be
raised. The events or issues you raised may be relevant to your immigration or asylum case and you
should therefore raise them in writing with your Home Office caseworker directly. However, it is my opinion
that the completion of a Rule 35 report in these circumstances will not be appropriate for you. Accordingly,
I have not issued a Rule 35 report.”

42. DSO 09/2016 was amended on 11 November 2016, the better to express the relationship between a
R35 (3) report and a R35(1) report, where the medical practitioner was concerned that the trauma related
by the detainee did not constitute torture as defined by the DSO but still left the detainee particularly
vulnerable to harm in detention. Concern had been expressed by doctors that the letter would undermine
the trust which detainees ought to have in their doctor, and could inhibit them seeking medical care; and a
“pre-assessment appointment process” appears to have been in operation with a possible aim of screening
out those who did not fit the new definition of torture.

43. The material passage in the amendment said:

“Where IRC medical practitioners consider that a detainee's claim to have been tortured does not meet the
UNCAT definition of torture and does not therefore trigger the requirement to make a report under Rule
35(3) they may nevertheless have concerns arising from the alleged incident(s) or its consequences (e.g.)
physical or mental health problems) that the detainee may be particularly vulnerable to harm in detention.
In such circumstances, medical practitioners must report their concerns. This may be by completion of a
Rule 35(1) report, if appropriate, by completion of an IS91 RA Part C (risk assessment), or by passing the
information direct to the Home Office Immigration Enforcement team at the centre.

Where IRC medical practitioners are unsure as to whether a detainee's claimed harm or ill-treatment fits
within the UNCAT definition of torture because of the identity of the perpetrator they should err on the side
of caution and make a Rule 35(3) report, which will allow the Home Office to make an assessment of the
claim.”

44. Ms Rouse described the difference between what Mr Shaw had recommended and the AARSG as
being that, instead of an “exempt categories approach [as in EIG 55.10,] the adults at risk policy sets out a


-----

Commission intervening) [2017] EWHC 2461 (Admin)

case by case assessment as to whether an individual needs to be detained in order to effect removal,
based on the evidence of vulnerability available in their particular case.” The identification of the
vulnerable was not limited to the application of the indicators.

45. Ms Rouse set out the position this way in her evidence:

“30. The Home Office has therefore sought to define what exactly constitutes torture when establishing a
policy for protecting people most vulnerable to immigration detention. The policy's method for assessing
potential risk in immigration detention is to consider the effect of harm rather than type of harm suffered. In
this context, the Home Office considers it reasonable to use the UNCAT (plus terrorist groups exploiting
instability) definition for the express definition of torture in the policy. Where there has been involvement of
a 'public official' or other person acting in an official capacity in torture, this is more likely to have occurred
in association with detention by such officials. Immigration detention for such individuals can therefore give
rise to particular potential vulnerability. Evidence suggests that immigration detention is more likely to be
redolent of previous detention by a state, in the course of which torture may have occurred. A paper
produced by the Office of the United Nations High Commissioner for Human Rights' (OHCHR) Voluntary
Fund for Victims of Torture (2008) cited the work of Manfred Nowak, then UN Special Rapporteur on
Torture, and Elizabeth McArthur, of the Boltzmann Institute of Human Rights in 'The United Nations
Convention Against Torture: A Commentary' (2008, Oxford University Press) covering the fact that illtreatment occurring in a situation of powerlessness for the victim, such as detention, is more likely to be
considered torture.”

46. Ms Rouse explained this further:

“31. It is important to note, however, that the adoption of this express definition of torture is only intended to
act as an additional safeguard. All victims of harm are protected by the policy, regardless of who committed
the act of harm. This is because the effect and impact of harm, rather than the type of harm, is the relevant
factor for the purposes of assessing vulnerability in the detention context. A person who has been harmed
by a private individual, for instance, will be considered an adult at risk by virtue of any impact of that harm
on their physical or mental wellbeing. The UNCAT definition of torture, however, provides an additional
safeguard for asymptomatic victims of torture who may not display any evidence of physical or mental
harm, but who may nonetheless still be at risk in immigration detention. This is congruent with both the
intention of Mr Shaw's recommendations and the adults at risk policy as a whole.”

47. She described what she saw as an important link between the definition of torture and the R35(3)
process:

“32. …For example the EO and Others definition of torture caused situations involving violence in the wake
of neighbourhood disputes, which are arguably qualitatively different from torture, nonetheless to be
classed as torture. Coupled with the category-based approach to harm in Chapter 55.10, people only had
to show evidence that harm could theoretically have been suffered as a result of 'torture' in the EO sense, if
corroborated by a doctor. This incentivised detainees to use medical services solely in order to access the
Rule 35(3) process. As a result, some perverse situations arose in which injuries to individuals, although
undoubtedly unpleasant to them, were treated as torture.”

48. Three examples of unpleasant violence which had led to a R35 (3) report, exemplified what she
described as the perverse situation which could arise under the “EO” definition. These were accounts of
family or business assaults; the person could still be in good mental and physical health, but with
independent evidence of torture. There had been a 3-6 fold increase in the number of R35(3) reports, after
_EO, including those going for an appointment because lawyers had told them that it would help their case._
Waiting times had increased, and more resources were necessary to cope. Some detainees, through
R35(3) reports, could secure release though they were in good health, and unlikely to be traumatised by
detention. There was some evidence that 44% of those released in October 2015, with a R35 (3) report,
had absconded.


-----

Commission intervening) [2017] EWHC 2461 (Admin)

49. The concerns expressed by Ms Rouse, adumbrated above, had led the Home Office to reinstate the
UNCAT definition of torture in its policies. Ms Rouse explained:

“36. In reinstating the UNCAT definition of torture, the Home Office has therefore sought to address how
Rule 35(3) is used in practice in consequence of the policy. It was important to strike the right balance
between identifying potentially vulnerable individuals and reducing the incentive to claim to have been a
victim of torture merely in order to secure release from detention and to frustrate removal. This could also
block individuals with genuine claims from being able to access the Rule 35(3) mechanism in a timely
manner. Since Stephen Shaw expressed concerns about the Rule 35 mechanism (recommendation
number 21), this was something that was taken into account from the inception of the adults at risk policy.
By using the UNCAT definition to address people who are most vulnerable to the effects of immigration
detention as a result of torture, the most vulnerable are now more likely to have timely access to the
medical services they need and to reconsideration of their case by the Home Office. This does not,
however, serve to exclude people who may have other causes of vulnerability.”

50. She addressed the problem of those who might fall outside UNCAT torture when previously they had
been within it in this way:

“37. In line with our broadening of the policy more generally, the Home Office has concurrently also
reinforced the mechanisms available for providing evidence or reporting concerns on adults potentially at
risk who may not fall within the definition of torture set out in UNCAT. The Home Office accepts that they
may display other indicators of vulnerability in any event and must therefore be notified by other reporting
mechanisms. Therefore as per Mr Shaw's recommendations, and as I have stated above, the Home Office
introduced additional indicators of risk, including transsexual people, victims of sexual or gender-based
violence, people with learning difficulties, and people suffering from post-traumatic stress disorder (PTSD).
In addition to an IRC doctor making a Rule 35 report, individuals may now self-declare or provide medical
or professional evidence. IRC doctors are able to file an IS91 Risk Assessment Part C report to flag adults
at risk who fit neither within the UNCAT definition of torture nor Rule 35 as a whole. They can also report
concerns through more informal channels, such as emails.”

51. The intention was to strike the right balance. The purpose of the policy was to protect adults at risk in
detention:

“38. …That is achieved by assessing vulnerability to immigration detention with reference to the impact of
any harm previously suffered. To this end, the use of the definition in UNCAT picks up an event in which an
individual suffers harm that is more likely to constitute torture i.e. harm suffered in a condition of
powerlessness imposed by a state authority. The impact of such harm is therefore more likely to leave a
person at risk in immigration detention due to potential redolence of past experience in state detention. A
failure to differentiate between such situations risks undermining the chances of those who are most at risk
of receiving appropriate attention via the Rule 35(3) mechanism, provide an opportunity to frustrate the fair
and effective running of the immigration detention system, and put undue strain on the Rule 35(3)
process.”

52. Medical Justice made much the same points as it did in these proceedings during the consultation on
the AARSG, published in draft in May 2016: the new definition of torture did not come from any evidencebased distinction between the effects of state and non-state infliction of severe pain, and there was no
justification for the exclusion, as they saw it, of certain forms of non-state violence from the safeguards of
the policy. Mr Cheeseman, a policy official within the Home Office Unit headed by Miss Rouse, replied,
agreeing to a large extent that the identity of the perpetrator of the act was not necessarily related to the
impact of detention on its victim; but the adoption of the UNCAT definition of torture did not mean that the
SSHD was necessarily denying protection under the policy to individuals who had suffered broader forms
of ill-treatment. He believed that the UNCAT definition “most accurately reflects the need to protect those
who are most likely to be deleteriously affected by detention- that is, those who have been harmed by the
state and for whom detention is most likely to be redolent of the harm they have suffered.” This did not


-----

Commission intervening) [2017] EWHC 2461 (Admin)

include what he called individuals harmed in “neighbourhood disputes”, but they could be covered by one
of the other indicators of risk.

53. Another aspect of the definition of torture occasioned some argument: the role of General Comment 2
from the UN Committee Against Torture, which has oversight of UNCAT. Its General Comments combine
exhortation and the development of the understanding of UNCAT as the Committee gains experience of
the problems in its application. The interpretative and authoritative status of such Comments was disputed.
General Comment 2 in paragraph 18 deals with what acts and omissions are to be seen as consenting to
or acquiescing in torture or ill-treatment. It says:

“18. The Committee has made clear that where State authorities or others acting in official capacity or
under colour of law, know or have reasonable grounds to believe that acts of torture or ill-treatment are
being committed by non-State officials or private actors and they fail to exercise due diligence to prevent,
investigate, prosecute and punish such non-State officials or private actors consistently with the
Convention, the State bears responsibility and its officials should be considered as authors, complicit or
otherwise responsible under the Convention for consenting to or acquiescing in such impermissible acts.
Since the failure of the State to exercise due diligence to intervene to stop, sanction and provide remedies
to victims of torture facilitates and enables non-State actors to commit acts impermissible under the
Convention with impunity, the State's indifference or inaction provides a form of encouragement and/or de
facto permission. The Committee has applied this principle to States parties' failure to prevent and protect
victims from gender-based violence, such as rape, domestic violence, female genital mutilation, and
trafficking.”

54. The recital to the Order of Andrew Baker J of 15 February 2017 records that the SSHD “had not
formed a view as to whether she agreed or disagreed with the interpretation of UNCAT” in  General
Comment 2 “before 12 September 2016 but had adopted a definition of torture based on Article 1 UNCAT
which did not expressly include that interpretation.” It also recited that further consideration had been put
on hold as a result of this litigation. The Claimants contend that this showed that she did not know what
definition she was using or what Article 1 meant. Mr Strachan said that her concern related to the status of
the Committee's General Comments, as authoritative explanations of the true interpretation of UNCAT,
with the international obligations which that could entail.

**The operation of the policy**

55. The operation of the new policy did not go to plan, which the Claimants said demonstrated its failings.
On 26 November 2016, at a case management and directions hearing, I ordered interim relief to the effect
that the EO definition of torture should be substituted for the UNCAT definition in the DCR, AARSG, EIG
and DSO 9/2016 as amended, with effect from 7 December. The SSHD had conceded that the decisions
to detain the Claimants had been unlawful, though maintaining that they would still have been detained
pursuant to lawful decisions made under the new policies. It had become clear, as these claims stimulated
inquiry, that there were what Mr Moore, a Home Office Grade 7 within Immigration Enforcement, described
in his witness statement as errors and misunderstanding about the policies. An initial review of a random
sample of 37 cases showed that there had been case worker errors in around 50%. A more detailed
review of 340 cases showed about the same percentage of error, though not, he judged, affecting the
decision to maintain in almost all cases. By 7 December, the reviews were showing almost no errors.

56. The position in the seven individual cases is instructive. In each case, the SSHD accepted that there
had been an error in the decision; the case worker should have found that there was Level 2 evidence
which should have been the basis upon which the particular vulnerability of the Claimant to detention
should have been assessed. The Claimants do not accept that that is the limit of the error, contending that
the evidence should have been seen as Level 3, but I do not need to resolve that issue.

**The two Bhatt Murphy Claimants**

57. **JXL:** She is a Tanzanian national aged 44. Her claim was that she had met a Tanzanian while
studying in Poland. She had a child with him out of wedlock. Her family in Tanzania, angered by this, tried


-----

Commission intervening) [2017] EWHC 2461 (Admin)

to inflict FGM on her; she escaped to Poland where her partner subjected her to sexual and physical
abuse, and forced her into prostitution. She came to the UK on a student visa in 2003, where she met
another Tanzanian, who also abused and raped her. Her extensions of leave expired in 2010, and an
appeal against the refusal of a further extension was dismissed. She overstayed however, and was
arrested and detained on 17 August 2016. She claimed asylum on 20 August 2016. She was referred to
the National Referral Mechanism, NRM, for victims of trafficking, but it found that there were no reasonable
grounds to conclude that she was a victim of trafficking. Her asylum claim was refused on 22 September
2016, and certified.

58. On 9 October, a R35(3) report was completed; JXL recounted the history above. The doctor
concluded that the physical and mental evidence was consistent with what she said, and ticked the box on
the form to the effect that she was concerned that JXL may have been a victim of torture. The case worker
response set out the UNCAT/EIG55b definition of torture in the usual way. As none of the individuals were
public officials, JXL was not a victim of torture and did not “engage” the adults at risk policy in EIG 55b.
Therefore, detention was maintained. It was thereafter maintained on the basis that, although there was
evidence at Level 1 that she was at risk because of what she said about gender violence and sickle cell
anaemia, removal was expected soon, and her immigration history made detention appropriate for the
purposes of removal. She was released on 19 October 2016. There is evidence that her mental health
declined in detention.

59. The SSHD accepted that the R35 report provided Level 2 evidence of sexual or gender based
violence, making her vulnerable to harm in detention, and her continued detention should have been
considered on that basis.

60.  SN: She is a Ugandan national aged 19. She was brought to the UK in 2009/10 with her brother by
the man who, with his wife, had brought her up after she had been orphaned. There, he had abused her
sexually and brought other men to the house to do likewise. She was taken into care in 2011, and helped
to claim asylum. The claim was rejected but discretionary leave was granted until 2013. An application for
an extension was refused, and the appeal failed, with SN's appeal rights being exhausted in April 2016.
SN was arrested, reporting on 27 July 2016. She remained in detention until about 11 November 2016,
after Collins J had ordered her release within 3 days. Her proceedings had been issued on 7 November.

61. Further representations were rejected as amounting to a fresh asylum claim on 10 August 2016.
Shortly after 6 September, when removal directions were set for 18 October, Medical Justice expressed
concerns about how SN was coping in detention. On 22 September 2016, a R35(3) report was completed,
based on SN's account as summarised above. The doctor concluded that SN had a scar consistent with a
particular assault that she described, and had sleep problems symptomatic of PTSD. She had concerns
that SN may have been the victim of torture. The case worker response on 23 September 2016 rejected
this as evidence of torture because there was no public official involvement. Detention was maintained to
facilitate removal. There was evidence of a decline in her mental health in detention.

62. The SSHD accepted that the R35 report should have been accepted as Level 2 evidence of sexual or
gender based violence, and SN's continued detention should have been assessed on that basis.

**The five Duncan Lewis Claimants**

63. HT: She is a Vietnamese national born in 1997 who was first encountered in 2013. She was referred to
the NRM, but the conclusive grounds decision found that she was not a victim of trafficking. She failed to
maintain contact. When encountered again in August 2016, working illegally, she claimed asylum. She
has an appeal outstanding against the refusal of asylum. She was in immigration detention between 27
August and 10 October 2016. Her asylum claim was that at the age of 6, when her parents died, she
became liable for their debts to loan sharks. She was beaten, cut and burnt by them. She worked as a
child to pay off the debt. Aged 16, she had been forced into prostitution and trafficked into China, France
and the UK. A R35(3) report dated 15 September 2016 concluded that she had scars and wounds
consistent with her description of what happened to her as a child, and that she had mental trauma as well.


-----

Commission intervening) [2017] EWHC 2461 (Admin)

The doctor ticked the box for those who had concerns that the detainee may have been the victim of
torture. On 16 September, the case worker decided that the account of “mistreatment and torture” by
those to whom her parents owed money did “not demonstrate that the treatment you received was
knowingly sanctioned or carried out on behalf of the government of Vietnam. Therefore it is deemed that
you do not meet the definition of someone who has been the victim of torture.” The UNCAT definition had
already been set out in the decision. “Taking account of the information within the R35 and the 'adults at
risk' policy as stipulated in chapter 55b of the EIG when balanced against your immigration and absconding
history a decision has been made to maintain your detention.” She was released not long after this
litigation began, “for operational reasons.”

64. The SSHD conceded that this was professional evidence of a severe and traumatic experience at the
hands of adults when she was only 6, where she would have felt a sense of powerlessness and which still
affected her, rendering her vulnerable to harm in detention; she should have been recognised as an adult
at risk with Level 2 evidence. The SSHD appears to have treated HT as falling outside any specific
indicator, but within some more general unspecified indicator of risk in detention.

65. MO: She is a Nigerian national aged 40. Her husband brought her to the UK in 2004 on a visitor's
visa. She was detained in 2013 by immigration officials, but released with reporting requirements. She
was detained, on reporting, on 21 September 2016, and claimed asylum. The claim has not been
resolved. She was referred to the NRM as a result of a R35 report, which found reasonable grounds for
concluding that she was a victim of trafficking, and in consequence she was released from immigration
detention on 19 October; there is no conclusive grounds decision. She claimed that her husband was
violent and abusive, and had brought her into the UK to make her work as a prostitute. When she refused,
he whipped, punched and slapped her, and assaulted her in other ways. He abandoned her, taking her
passport. A R35(3) report dated 5 October 2016 said that her visible injuries were consistent with her
description of what had happened to her, and that her “nightmares and trust issues with relationships”
could have been caused by domestic abuse. The case worker response of 7 October, much as with HT,
set out the UNCAT definition of torture, and said that it was not accepted that the events were torture within
that definition and so did “not constitute independent evidence of torture.” Her continued detention was
necessary to facilitate removal. An ad hoc review of that same day concluded that, in the light of the
response to the R35 report, she did not come within the adult at risk policy.

66. The review of 18 October commented on the R35 report saying that it did not show torture as defined
by UNCAT but it did state that she was the “victim of domestic violence and as such it is considered that
the subject is a level 2 under the AAR policy.” Detention was maintained pending the NRM “reasonable
grounds” decision.

67. The SSHD accepted that the R35 report was Level 2 evidence of gender-based violence, making her
vulnerable in detention. In effect the R35 response should have responded in the way in which the 18
October detention review did.

68. OO: He is a Nigerian national aged 36, who came to the UK on a student visa in 2008, which expired
without renewal in 2010. He was encountered by immigration officials in May 2016, convicted of using a
false instrument to gain employment, sentenced to 4 months' imprisonment, entering immigration detention
on 22 July 2016, probably in the usual way after serving half his sentence. He claimed asylum on 5 August
2016; the claim has not been resolved. A R35(3) report dated 8 September 2016 noted OO's claim to have
been attacked in 2008, when a student, while having sex with his male partner in a dormitory room. 15
students had attacked them violently over about half an hour for having homosexual sex. The partner had
died. He had sought refuge with his pregnant sister but he said she had been attacked; she lost her baby.
The doctor said that the scarring “was plausible with the description of how the injuries were sustained.”
As with the others, the caseworker said that this was not torture as defined by UNCAT, which it set out,
because there was no evidence that the ill-treatment was “inflicted by or at the instigation of or with the
consent or acquiescence of a public official or other person acting in an official capacity.” The report was
also said not to explain why the medical evidence was thought consistent with the account given or what
other explanations there might be Although no level of evidence is specified there was thought to be a


-----

Commission intervening) [2017] EWHC 2461 (Admin)

significant risk of absconding, and detention was to be maintained until removal. It was maintained until 14
October 2016, a week after the pre-action protocol letter, after a review.

69. The SSHD accepted that Nigeria should have been considered as a state that acquiesces in
homophobic abuse; homosexual acts between men are a criminal offence, and support groups for gays are
outlawed. The Country Information for Nigeria states that effective protection is not available for LGBT
persons. The R35 report should therefore have been recognised as affording evidence of UNCAT torture.
There was also evidence of trauma and powerlessness. OO should have been treated as an adult at risk
with Level 2 evidence. He has now left the UK.

70. MJ: He is an Afghan national aged 21. He arrived in the UK in 2014, and claimed asylum in January
2015. He was encountered by immigration officials in July 2016, and detained on 19 July. He was
interviewed in September 2016. The claim was refused; his FtT appeal was dismissed, but his substantive
UTIAC appeal was heard on 22 February 2017; no result is known. Bail was granted by the FtT, leading to
release on 1 November 2016. A R35(3) report was made on 19 September. It recorded a claim that, while
a young boy, he had been kidnapped by the Taliban with two others, groomed for membership, and beaten
and stabbed when he tried to escape. He was thrown down the side of a mountain by the Taliban and left
for dead, but he was rescued, rejoined his family, which, after his recovery, arranged for him to leave
Afghanistan. The report concluded that his narrative appeared consistent with his injuries, and the doctor
felt that he may be the victim of torture. The case worker response said that as he had not demonstrated
that the treatment was “knowingly sanctioned or carried out on behalf of the government of Afghanistan”, it
did not meet the definition of torture. “Therefore it is not considered that you are an adult at risk.” An ad
hoc review, a few days later, did not alter that approach, nor did the review on 11 October 2016.

71. The SSHD conceded that the R35 report should have been treated as Level 2 evidence of torture
within the EIG definition, which extended beyond that in UNCAT and in the AARSG, to include torture
carried out by “a terrorist group exploiting instability and civil war to hold territory.” These words had been
included in the definition of torture as recited in the case worker response, as with the other case worker
responses above.

72. PO: He is a Nigerian national aged 39. He arrived in the UK in September 2014, was detained but
released within a month. He was re-detained on 21 September 2016, and he claimed asylum on 24
September. His claim remains unresolved. He was released from detention on 2 November 2016 for
operational reasons unspecified beyond “R35”. On 4 October, a R35(3) report was completed. It
recounted that PO was “beaten in the school + then taken way to security for 2 weeks.” He was beaten,
knifed and flogged. He had flashbacks and could not sleep. The case worker responded that this did not
fit the definition of torture as he was beaten by non-state actors. This position was maintained until
release. There was no more than Level 1 evidence under the AARSG.

73. The SSHD conceded that there was Level 2 evidence that PO was an adult at risk, and came within
the UNCAT torture definition for the same reasons as OO, plus the reference to beaten by security.

74. In the cases of HT, MO, MJ and OO, a consultant neuropsychiatrist, Dr Lohawala, provided a report
expressing the view that their condition had deteriorated in detention. Dr Wootton, a consultant forensic
psychiatrist, expressed the view in PO's case, that “the identity of the perpetrator of the torture” was not
relevant to the harm he suffered in detention, where “he experienced the same loss of agency and
powerlessness that he had during his previous traumatic experiences, and this triggered a worsening of his
symptoms”.

75. In three cases, and it may be in others as well, the template  R35 report included, among its notes for
the medical practitioner, the obvious requirements for legibility and completeness, and less obviously, this:

“The requirement to report need only be triggered by you having a concern that the detainee may have
been a victim of torture. However, you should not make a report where the detainee's experience of harm
or mistreatment does not meet the definition of torture given in section 3 above, or where you do not have


-----

Commission intervening) [2017] EWHC 2461 (Admin)

clinical concerns that the detainee may have been a victim of torture, including instances where there is no
basis for concern other than an unsupported claim by the detainee to have been a victim of torture.”

**The evidential basis for the change to the definition of “torture”**

76. The Claimants contended that the decision to change the definition of torture was not rational, lacked
any evidential basis, and flew in the face of what Burnett J had decided in EO.

77. Mr Strachan referred to the 2013 Danish Medical Journal paper by Storm and Engberg, a paper review
on the impact of immigration detention on the mental health of torture survivors, which concluded that it
was poorly documented. Two case studies were confined to torture survivors and involved but three
victims. But they did evidence serious mental health issues and symptoms related directly to the
experience of detention. The paper continued:

“Detention is the context in which much torture is executed; a strong reaction to similar surroundings at a
later point in time is evidently very likely. The data are supported by the fact that several of the included
studies find high levels of psychological problems among participants of whom torture survivors and other
traumatized refugees make up a large percentage. Whether there are any differences between torture
survivors and other severely traumatized refugees remains unknown due to the lack of studies on this
topic.”

78. The Claimants made extensive reference to the papers before Burnett J in EO, and to other evidence.
Nearly all of this was designed to show that the identity of the perpetrator of severe pain was not relevant
to the way in which detention would harm mental health.

79. Dr Clark, a GP whose experience includes writing medico-legal reports for Freedom from Torture and
who has been trained by Medical Justice in torture assessment under the Istanbul Protocol, stated, in her
witness statement, that problems with the return to the UNCAT rather than _EO definition of “torture”_
included that the detainee might not know the identity or role of the perpetrators or who they were acting
for, or of where the ill-treatment took place; the concepts of who consented or who acquiesced was not an
easy one for all who might be torture victims to understand, a problem compounded by language
difficulties or PTSD or other mental health problems; a more detailed history than time available, usually 15
minutes or so, allowed, would often be required for the issues of identity, consent and acquiescence to be
determined. She was also concerned that, as a doctor, she would be required to make non-medical
judgments about issues, such as the status of irregular armed forces, or state acquiescence, for example
where a mob had attacked where there was religious, sexual orientation or political hostility at state level.
Would, she asked, strict Islamic societies fall into the category of acquiescent states, where women are
punished in private by their families for transgressing their Islamic social norms?

80. Dr Clark dealt with the significance of the identity of the perpetrator of torture in this way:

“16. In my opinion the only relevance of the identity of the perpetrator to the impact of detention on a
survivor of torture, is that there may be particular triggers to distressing memories if detention in the UK is
similar to aspects of detention or trauma in their own country, such as being in a prison-like environment,
the sound of metal doors closing and keys and seeing staff in uniform.

17. However, if a survivor of torture more widely defined may also have experienced being in a locked
environment, heard and seen similar sights and sounds to those they are exposed to in detention in the
UK. Therefore, they might also experience the same triggers for intrusive thoughts, nightmares and
flashbacks as a result of their immigration detention in the UK.

18. Immigration detention has been found to have adverse effects on the mental health of detainees, and I
am not aware of any clinical evidence or research that says that this is confined to survivors of torture
where the perpetrator was a public official, a person acting in an “official capacity” or a person acting at the
instigation of or with the consent or acquiescence of a public official.”

81. She referred to the Bosworth literature review for the Shaw report, concluding that “the risk of
deterioration in mental health was likely to apply to all detainees who have experienced past ill-treatment,


-----

Commission intervening) [2017] EWHC 2461 (Admin)

irrespective of the identity of the perpetrator.” She treated that report as concluding that asylum seekers in
general, and victims of torture, were particularly vulnerable to mental health deterioration in detention.
Sexual violence, torture and pre-existing traumas were among the causes of mental health deterioration in
detention.

82. Torture survivors, whoever inflicted it, could be adversely affected in detention from seeing and
hearing the distress or behaviour of other detainees, an increased sense of isolation and separation from
support, and the fear of removal. Political commitment might be a protective factor for some, though.

83. Dr Clark also gave evidence of cases which she said fell within “EO torture”, but would fall outside
“UNCAT torture”, and whose detention would be harmful to them: homophobic attack by villagers, being
trafficked into forced labour, or into prostitution, abduction and rape by a criminal gang, an abusive
domestic relationship, rape at home and, in flight, rape again by the people smuggler. Other examples
were given by others: a Nigerian Christian attacked by Nigerian Muslims, Juju violence and trafficking from
Nigeria. Her analysis, as with so many, did not allow for those who fell within other indicators.

84. Dr Clark also expressed concern about how the new definition in DSO 9/2016, before amendment in
November, could affect the doctor-patient relationship, creating mistrust, and affecting a detainee's
willingness to seek medical care.

85. Dr Clark also produced a statement in reply to Ms Rouse. She emphasised the role of the R35(3)
Report in providing an effective opportunity for the detainee to report ill-treatment. She had not come
across the IS91 RA being used for that purpose. Medical Justice and the other specialist agencies for the
support of torture victims did not have the resources to make up for the lack of R35 reports and there was
often a delay of some months before they could provide a report to the Home Office. She expressed her
agreement with the position of the Royal College of Psychiatrists, RCP. She gave three examples of those
who had experienced severe ill-treatment at the hands of their family whose mental health had deteriorated
in immigration detention.

86. **Ms Schleicher, acting Director of Medical Justice, provided three witness statements. Her first**
explained why Medical Justice had become involved: she took “the purpose of a R35 report” as being “to
enable detainees who have a history of torture to obtain medical evidence of their past torture.” (That is
wrong to the considerable extent that it goes beyond the role of a R35 (3) report in providing independent
evidence of torture for the previous release policy in chap 55.10 EIG. She was concerned that the
protections for those who had previously received R35(3) reports was missing and it had not been made
up for by an increase in R35(1) reports. Doctors whose R35(3) reports were not reflecting the new
definition of torture were being asked to rectify this.

87. The SSHD's suggestion that the IS91RA risk assessment process, said to be in force from 12
September under DSO 8/2016, “Management of Adults at Risk in Immigration Detention”, was not
evidently in practice. Besides it was an internal process, with the forms not sent to the detainee or his
representatives, and did not trigger a mandatory detention review. EIG 55b suggested that the process
was about managing risks in detention rather than reviewing detention or release. That is how the interim
DSO 8/2016 reads to me as well. This point was elaborated in her third witness statement. Ms Hardy, in
her reply on behalf of the SSHD, gave examples of the use of the IS91RA forms to bring about
assessments of a detainee's continued suitability for detention, which had led to release in some instances.
It was not as confined in practice as Ms Schleicher had suggested. Ms Hardy also produced the final
version of DSO 8/2016 issued in February 2017, after consultation.

88. Ms Schleicher's long third statement, with substantial exhibits and case schedules was produced at
the end of January 2017 in reply to the Home Office. Some was argument, and much evidence was not
properly reply evidence; some was more of a general critique of failings in the system, than evidence
directed to the issues raised in the case. The Claimants objected to the Home Office reply, though not
because it incited yet further evidence. I permitted the Home Office evidence to be adduced.


-----

Commission intervening) [2017] EWHC 2461 (Admin)

89. She examined a sample of Medical Justice cases before the new policy came into effect in September
2016. She thought that these would have fallen outside the scope of the new UNCAT definition. Some
involved confinement and some did not. She expressed the view, having examined the case histories, that
there was no difference in the adverse effect which immigration detention had on the two groups. Some at
least were later acknowledged as refugees or granted humanitarian protection. She did not consider other
indicators which might or should have applied instead.

90. I find it difficult to see, on the material she provided, that they would or should have fallen outside the
scope of the specific indicators (notably sexual and gender based violence, and UNCAT torture with state
acquiescence) in the AARSG. Mr Cheeseman responded along those lines, though without detailed
consideration. That however is where the scope of R35 matters.

91. Ms Schleicher suggested that there were reasons why there had been an increase in the use of
R35(3) reports, other than those put forward by Ms Rouse. The quality of R35 reports and the case worker
response had improved after the Home Office had to improve following the _Detention Action litigation;_
detainees were more aware of their value now. There was more time for the lawyers to obtain such reports
with the suspension of the detained fast track, and for detainees to be prepared to explain what happened
to them. The EO definition of torture had been in use for many years before EO, as well as since, and so
the EO decision itself could not account for the increase in R35 reports. The absconding of those released
was possibly explicable by the absence of stable accommodation for those released on temporary
admission rather than on bail.

92. Mr Cheeseman gave examples of R35 (3) reports, responding to the EO definition, where he said that
the detainees had not been particularly vulnerable to harm: a man in his late 30s who, as a 12 year old,
had been beaten on his legs by his uncle with a thorny stick after questioning about his religious practice;
a street protester whose wrist was broken by a police baton; an alcohol smuggler intercepted in Iran, where
the authorities smashed the bottles and killed his horses. I am far from sure that these  amount to more
than errors in the understanding of the severity of what _EO torture really involves, errors of the sort to_
which all involved appear to be prey.

93. Ms Schleicher's casework examples of decisions after 12 September 2016 certainly suggests that the
system of R35 reports and the AARSG had not worked as intended, but that is common ground. What her
comments do not show is how strong were the immigration factors which led to the decision to maintain
detention. Mr Cheeseman's reply for the SSHD illustrated the poor immigration history and late asylum
claims.

94. **Dr Korzinski, co-founder of the Helen Bamber Foundation, and a trauma and psychosocial expert,**
said in his report commissioned by Duncan Lewis, that “the prohibition of torture is absolute.” “Torture” to
him was perpetrated by state and non-state actors, it could occur in places other than places of detention,
and could include beatings, humiliation and sadism. It should cover other types of extreme inter-personal
violence such as domestic violence, child abuse and trafficking. He cited Helen Bamber's evidence in EO:

“Prolonged and repeated exposure to catastrophic experiences (such as when the victim is in a state of
captivity, unable to flee, and/or under the control of the perpetrator) can result in trauma that is complex
and enduring. Such trauma often results in the victim feeling permanently damaged, the loss of previously
held belief systems, social withdrawal, the feeling of being constantly threatened, an inability to relate to
others and a fundamental change to the individual's previous personality. Impairment to memory and
capacity to articulate traumatic experiences are often observed within this population.

“Examples of the conditions in which such trauma is likely to occur include prisons, concentration camps,
slave labour camps, as well as brothels, other institutions of organised exploitation and within some
families in which the perpetrator creates a relationship of coercive control.

“The Foundation considers that the complex, human dimension of an individual's response to these
experiences must be given proper consideration. All clinical assessments are carried out by one of the


-----

Commission intervening) [2017] EWHC 2461 (Admin)

Helen Bamber Foundation's senior clinicians, often involving members of the multidisciplinary team, prior to
implementation of a care plan.

“In the UN Convention Against Torture (UNCAT), torture is defined as requiring (a) that the severe pain or
suffering was inflicted for the purpose of obtaining information or a confession or as punishment and (b)
that it was inflicted by, at the instigation of or with the consent or acquiescence of a person acting in an
official capacity.

“I have been asked to explain why those elements do not form the basis for treatment provided by the
Helen Bamber Foundation.”

In the cases we take on cruelty is rarely mindless; there is usually a focus to it. However, in working
therapeutically with victims of ill-treatment the most critical element is the effect of that ill-treatment upon
them rather than the purpose for which it was inflicted. ”

95. Whilst critical of the use of the UNCAT definition in the assessment of vulnerability to harm of those
who had experienced torture, I am not sure what other definition he was using for torture which, whatever it
was, was “absolutely prohibited”. It is not an accurate commentary on s134 CJA 1988, for example. His
definition appears to have covered all deliberate infliction of trauma, judged more by consequence rather
than purpose, so it is not obvious that he is using the definition of “torture” which resulted from EO.

96. However, he said that there had been a consensus among all those who submitted evidence in EO,
that there was a connection between having been tortured and the risk of further psychological and
physical harm from detention, a consensus which remained good.

97. He said, and it illustrates what Mr Strachan submitted was the misunderstanding of the Government
policy which lies at the heart of much of this case:

“9. The Government's policy has as its core a false distinction that risks in practice placing the needs of
victims who have been subjected to one form of torture over the needs of victims whose torture experience
does not fall within the strict criteria they have set (i.e. torture perpetrated by non-state rather than state
agents). I have not been able to find any scientific evidence that supports such a delineation.”

98. He explained the risks of detention causing harm in this way:

“13. What is most “redolent” of a victim's torture when faced with immigration detention is the total loss of
control and helplessness. The sensory stimulus associated with the presence of uniformed officials, the
clanking of doors and rattling of keys may replicate the physical environment which has accompanied
some victims' experience of torture. For others, the simple inability to control or influence the environment
in immigration detention has been described by torture victims both to me and to other clinicians, as
inducing the state of fear and helplessness they experienced when tortured. For people who have been
tortured in the ways described by Helen Bamber their experiences may have been very close to their
everyday life. It is the case with many victims of trafficking who I have treated clinically since 2004. Hence
seemingly innocuous experiences, ostensibly harmless sounds, the way light comes into window,
particulars smells (sic) and physical sensations, may become triggers of extreme emotional distress. When
triggered by traumatic reminders – such as the feeling of helplessness, or other sensory associations
(reminders) the past becomes present.”

99. Then, in agreement with Helen Bamber's EO evidence and that of others, he said that the identity of
the perpetrator “is not the most relevant feature in most cases.” Torture inflicted by a parent was the
exception. Treatment in detention was particularly difficult.

100. Dr Bell, a consultant psychiatrist at the Tavistock Institute, with extensive experience in immigration
and asylum cases, also produced a report. He described the harm done to those who, having been
“tortured”, using it seems the same broad approach as Dr Korzinski to that word, find themselves in
detention. Typically, they are suffering severe PTSD or depression or both, which may become chronic.
Adaptation and rehabilitation is far more readily commenced or maintained outside the further duress of
immigration detention. He expected no link between the severity or nature of the effects and whether the


-----

Commission intervening) [2017] EWHC 2461 (Admin)

perpetrator was a state or non-state actor, though the identity in a narrower sense could matter for some if
they knew the perpetrator, and for others if he was unknown. Those who had been tortured were
particularly vulnerable to the psychological effects of being detained.

101. He also pointed out that it was beyond the expertise of medical practitioners to determine state
involvement or complicity in torture, and the difficulty which attempting to do so created for doctor /patient
relations.

102. Professor Katona, a consultant psychiatrist and Medical Director at the Helen Bamber Foundation,
gave evidence in response to comments from the SSHD seeking to draw on the evidence he had given in
_EO. It was not his view that those mistreated whilst detained by the state or a state-like body were more_
likely to find the experience of further official detention more difficult than other survivors of similarly serious
ill-treatment. Both find immigration detention particularly distressing.

“6. …Whilst the experience of past ill-treatment will inevitably inform any subsequent experience of
immigration detention, in my view those who are ill-treated while detained by non-state actors, or who are
ill-treated without experiencing detention, find immigration detention particularly difficult and/or distressing
and are very vulnerable to the risks of adverse impact of immigration detention and indeed, are just as
vulnerable to such adverse impact as those who have experienced detention by the state or a state-like
body.”

103. The common features :

“8. …that make victims of severe ill-treatment particularly vulnerable to the adverse psychological effects of
immigration detention are the traumatic and disturbing nature of being subject to deliberately inflicted
severe ill-treatment and the consequential suffering that deliberate cruelty entails, together with the loss of
agency and powerlessness associated with being subjected to such ill-treatment. These factors are
intrinsic to the experience of severe ill-treatment and are not limited to those who have been held in official
detention facilities or similar contexts in their country of origin. It is for this reason that, in my clinical
opinion, there is no significant difference between the risk of harm and consequent therapeutic needs of a
person who has experienced ill-treatment like this at the hands of a state or state-like body, and someone
who has experienced similar treatment by non-state actors. The adverse psychological impact of such illtreatment and the trauma it causes are the same, as are the survivor's subsequent therapeutic needs.”

104. He included cruel, inhuman and degrading treatment (CIDT) in his definition of torture. He continued:

“11. As I explained in these previous statements, triggers for distress, exacerbation of symptoms of posttraumatic stress disorder (PTSD); traits of PTSD, and re-traumatisation certainly include being in a similar
environment; officers in uniforms; doors being locked and unlocked; and being cut off from normal life.
These are associated with official detention in their country of origin, but are not however exclusive to that
context. These factors are (in my clinical experience) common experiences of victims of torture and CIDT,
whether the ill-treatment is inflicted by state or state-like bodies, or by non-state agents such as clans,
tribes, religious sects or ethnic factions or groups, militias, cartels, and by criminal gangs, including human
traffickers, or other private individuals such as family members who perpetrate extreme domestic violence.
Such non-state agents also confine, guard and lock up their victims.”

105. Even if there is no formal captivity, even in a brothel or hotel or private house, severe ill-treatment
can be suffered in a context of loss of agency or powerlessness. The act of inflicting severe ill-treatment
involves some form of physical or mental constraint, including psychological control, whether for a short or
long period.

106. He gave examples of inter-communal violence in which he said that state agents played no part. I
am not sure that his examples bear out the absence of acquiescence by the state or the inaptness of the
terrorist group rider: the killing fields of Cambodia, civil war in Somalia and genocide in Rwanda. He was
of the view that violence within families could be as extreme as state, state-like and communal violence:
punishment of women for dishonouring a family; actual confinement to home was not a necessary
ingredient of the ill-treatment


-----

Commission intervening) [2017] EWHC 2461 (Admin)

107. He concluded:

“15. Ultimately, the precise triggers and stressors are many and varied: from the accounts I have been
given over the years, it may be simply the tone of voice of the guards in the immigration detention centre,
physical similarities with the perpetrator, (for example for women who are guarded by male officers in Yarl's
Wood), aggressive behaviour by other detainees (including, for example, homophobic abuse), disturbed
detainees (some of whom commit acts of self-harm), loud noises shouting, and the screams and night
terrors of others. All of these are common trigger factors for acute distress present in the immigration
detention context to which survivors of torture and CIDT are vulnerable irrespective of whether their
torture/CIDT was or was not inflicted by a state or state-like agent, or in the context of an official facility, in
their country of origin.

16. Immigration detainees experience isolation; being cut off from support, with detainees left to ruminate
about their traumatic experiences with their fears and uncertainty for their future safety, which are also
important triggers for psychological distress. They are all common reasons why victims of severe illtreatment, whoever may have inflicted it upon them and irrespective of the precise context, find immigration
detention to be particularly difficult and/or distressing, and which make them particularly vulnerable to
being adversely affected by it.”

108. Dr Katona also produced a schedule of cases which he said illustrated the harmful effect of detention
on those who had suffered torture at the hands of non-state actors. Mr Cheeseman's reply did not take
issue with that conclusion; rather he pointed out, correctly as it seems to me, that there were other
indicators in the AARSG, chiefly gender based violence, which would apply to each of them.

109. Dr Katona's analysis of the Storm and Engberg paper was that it could not be legitimately concluded
from it that those who had been tortured by state or state-like bodies were more likely to be adversely
affected by detention than other survivors of torture and severe ill-treatment. They did not actually draw
any such conclusion. Nor were the authors directing the analysis towards the distinction which the SSHD
was drawing. I consider that those comments are generally correct. Dr Katona also noted that the two
authors had not set out the definition of “torture” which they were applying, but I have found that,
unhappily, to be the case with many of those who have provided evidence or papers, including Dr. Katona
so far as I could tell.

110. The Office of the United Nations High Commissioner for Human Rights Voluntary Fund for Victims of
Torture paper of 2008, drawing on the work of a previous UN Special Rapporteur, Manfred Nowak, and
Elizabeth McArthur, to which Ms Rouse had referred, showed the importance of powerlessness to the
concept of torture. This was entirely consistent with Dr Katona's view; it did not show powerlessness to be
more of a feature of state torture than of non-state torture. Powerlessness was present in both.

111. The Addendum to the 2010 Report to the UN General Assembly on “torture and other cruel and
degrading or inhuman treatment or punishment” by Mr Nowak as Special Rapporteur, is a study of such
actions as “phenomena”. He asks “What is torture?” And he answers thus:

“A. What is torture?

43. The term “torture” should not be used in an inflammatory manner. It is reserved for one of the worse
possible human rights violations and abuses human beings can inflict upon each other, and therefore
carries a special stigma. It therefore holds a special position in international law: it is absolutely prohibited
and this prohibition is non-derogable. Where torture has been inflicted, it is a very serious crime against a
human being, who most likely will suffer from its consequences for the rest of his or her life, either
physically or mentally. According to the definition contained in the Convention against Torture, four
elements are needed in order for an act to be qualified as torture: firstly, an act inflicting severe pain or
suffering, whether physical or mental; secondly, the element of intent; thirdly, the specific purpose; and
lastly, the involvement of a State official, at least by acquiescence.

44. Only acts which cause severe pain or suffering qualify as torture. Severity does not have to be
equivalent in intensity to the pain accompanying serious physical injury such as organ failure impairment


-----

Commission intervening) [2017] EWHC 2461 (Admin)

of bodily functions or even death. Another element which distinguishes torture from cruel, inhuman or
degrading treatment or punishment is the powerlessness of the victim. Torture is predominantly inflicted on
persons deprived of their liberty in any context and therefore rendered particularly vulnerable to abuse.”

112. Mr Nowak also discusses the role of purpose and of the distinction between “torture”, thus defined,
and “cruel, inhuman or degrading treatment”, undefined:

“However, as the Special Rapporteur has argued before, the distinguishing factor is not the intensity of the
suffering inflicted, but rather the purpose of the conduct, the intention of the perpetrator and the
powerlessness of the victim. Torture constitutes such a horrible assault on the dignity of a human being
because the torturer deliberately inflicts severe pain or suffering on a powerless victim for a specific
purpose, such as extracting a confession or information from the victim. Cruel, inhuman or degrading
treatment or punishment, on the other hand, means the infliction of pain or suffering without purpose or
intention and outside a situation where a person is under the de facto control of another. It follows that one
may distinguish between justifiable and non-justifiable treatment causing severe suffering.”

113. He describes the role of “purpose” in the definition of torture:

“Purpose

35. Article 1 explicitly names several purposes for which torture can be inflicted: extraction of a confession;
obtaining information from a victim or a third person; punishment, intimidation and coercion; and
discrimination. However, there is a general acceptance that these stated purposes are only of an indicative
nature and not exhaustive. At the same time, only purposes which have “something in common with the
purposes expressly listed” are sufficient. Noteworthy of the examples included in article 1 is that most of
these purposes are related to “the interests or policies of the State and its organs.” They are linked to the
work of law enforcement authorities and similar State agents and implicitly refer to situations in which the
victim finds itself “at least under the factual power or control of the person inflicting the pain or suffering.””

114. A further section is headed “Powerlessness of the victim” under which he says this:

“Powerlessness of the victim

37. Torture, as most serious violation of the human right to personal integrity and dignity, is predominantly
inflicted on persons deprived of their liberty. Persons held in captivity, be it in police custody, remand
facility or prison, or deprived of their liberty in any other context, find themselves in a situation of complete
dependency and are therefore particularly vulnerable to any abuse. It is against this background that the
intentional infliction of severe pain or suffering for a specific purpose requires a particularly strong moral
stigma and legal prohibition.

…

The powerlessness of the victim was an essential criterion when the distinction between torture and cruel,
inhuman and degrading treatment was introduced into the Convention.”

115. This analysis is borne out by the Nowak/McArthur 2008 Commentary on the development of the
UNCAT definition of “torture” and the purpose or intention of its components.

116. In the Special Rapporteur's report to the UN General Assembly in 2008, some of these issues were
also discussed in a similarly entitled addendum. He said this of “powerlessness” as a possible additional
criterion for torture:

“28. The Special Rapporteur has suggested adding to these elements the criterion of powerlessness. A
situation of powerlessness arises when one person exercises total power over another, classically in
detention situations, where the detainee cannot escape or defend him/herself. However, it can also arise
during demonstrations, when a person is not able to resist the use of force any more, e.g. handcuffed, in a
police van etc. Rape is an extreme expression of this power relation, of one person treating another person
as merely an object. Applied to situations of “private violence”, this means that the degree of
powerlessness of the victim in a given situation must be tested. If it is found that a victim is unable to flee or


-----

Commission intervening) [2017] EWHC 2461 (Admin)

otherwise coerced into staying by certain circumstances, the powerlessness criterion can be considered
fulfilled.”

117. His analysis of the role of state acquiescence in domestic violence, exemplified his thinking on what
constitutes state acquiescence, in torture or CIDT:

“46. State acquiescence in domestic violence can take many forms, some of which may be subtly
disguised. For instance, “Civil laws that appear to have little to do with violence also have an impact on
women's ability to protect themselves and assert their rights. Laws that restrict women's right to divorce or
inheritance, or that prevent them from gaining custody of their children, receiving financial compensation or
owning property, all serve to make women dependent upon men and limit their ability to leave a violent
situation.” The Special Rapporteur considers that States should be held accountable for complicity in
violence against women, whenever they create and implement discriminatory laws that may trap women in
abusive circumstances. State responsibility may also be engaged if domestic laws fail to provide adequate
protection against any form of torture and ill-treatment in the home.”

118. The European Asylum Support Office Tool for the identification of persons with special needs draws
attention to the UNCAT definition of “torture” but adds that that definition is to define the crime of torture,
but for special procedural and reception needs in the asylum context, “the actor of the torture may not be
relevant, as the consequences [of the torture, as I read it] for the individual would be grave in any case.”

119. The Royal College of Psychiatrists, RCP, issued a position statement, with which the Royal College
of General Practitioners agreed. It expressed concern that the new policy would “significantly weaken the
existing safeguards for vulnerable people with a history of torture, trafficking or other serious ill-treatment.”
The UNCAT definition had not been developed to help decide who would be vulnerable to harm in
detention. EO “had rejected” the UNCAT definition “in favour of a broader definition, which focused on the
severity of the harm inflicted, rather than on the identity of the perpetrator of the harm”. The RCP endorsed
these views and “confirms that the issue of state responsibility for torture does not in itself determine the
impact of the ill-treatment or the resultant therapeutic needs of the individual. [It] is further of the view that
the issue of state responsibility for torture is not determinative of any consequent vulnerability to the
adverse effects of immigration detention.”

120. In elaboration, it said that there was no research evidence or clinical indication that the issue of state
responsibility for torture and ill-treatment predicted vulnerability to the adverse effects of detention. “Loss
of agency and powerlessness is the common feature…critical to the risk of harm if the person is again
subject to constraint…” The approach adopted risked missing other equally highly vulnerable people.
Medical practitioners should not be expected to reach conclusions about whether the perpetrator was or
was not a state actor or complicit or a terrorist group for the purposes of the new rider. It was also critical
of the impact which the letter, required to be sent if no R35 report were made, would have on the doctorpatient relationship. The policy weakened what it regarded as the already inadequate safeguards in force
at the time of the Shaw report.

121. Dr Lohawala, instructed by Duncan Lewis, produced a general report, but drawing on the four
individuals referred to above. He set out the position of others with whom he agreed including the RCP, Dr
Bell, Helen Bamber and Dr Katona, on the irrelevance of the identity of the perpetrator to the effects of
detention on those who have been tortured.

122. Dr Wootton, also instructed by Duncan Lewis, agreed with the evidence of the Helen Bamber
foundation in _EO, the reports by the RCP, and Dr Bell. The identity of the perpetrator of torture did not_
affect the risk of harm from detention; she explained, in summary, that “any reminder of torture is likely to
trigger traumatic memories, anxiety and arousal….” “The torture victim is being controlled and restricted in
both a situation of torture and also in a detention centre. This will then trigger their feelings of
powerlessness and helplessness, vulnerability, loss of choice and degradation which will increase their
sense of a serious current threat, and therefore exacerbate and increase their symptoms placing them at
further risk of harm.” The similarities in PO's case, above, between the homophobic assaults and
immigration detention were sufficient to trigger “loss of agency and powerlessness ”


-----

Commission intervening) [2017] EWHC 2461 (Admin)

**Conclusions on the definition of “torture”**

123. The principal issues raised by the Claimants' submissions are (1) whether the AARSG has purported,
unlawfully, to alter the meaning of “torture” in R35(3) DCR and, if so, what effect that has on the lawfulness
of the definition of “torture” in the AARSG more generally; (2) whether, properly interpreted, the AARSG
has excluded instances of “non-UNCAT torture” from its indicators of particular vulnerability to harm in
detention; (3) if so, whether the AARSG is unlawful on that account, either because the SSHD wrongly
assumed that that was not the effect of the AARSG, or because, in order to satisfy s59, more general
provision for unspecified indicators of particular vulnerability to harm in detention was necessary, or
because the use of the UNCAT definition of “torture” perpetuated a distinction between “UNCAT torture”
and “EO torture” which had, and had been held to have, no rational or evidence base. There are a number
of lesser issues which I shall also have to deal with.

**The AARSG and the meaning of “torture” in R35 DCR.**

124. The first issue is whether the difference between “UNCAT torture” and “EO torture” means that the
AARSG has purported, unlawfully, to alter the meaning of “torture” in R35(3) DCR.

125. Mr Strachan submitted that, if the definitions had to be, but were not, consistent in the DCR and
AARSG, the effect of the different AARSG definition was to repeal by necessary implication, the definition
in the DCR decided upon in EO and to replace it with the AARSG definition. In any event, there was no
inconsistency between the _EO definition of torture and the definition used in the AARSG, or in EIG 55b,_
and in any event there was no need for the definitions to be consistent.

126. I cannot accept those submissions. First, the decision in EO was about the meaning of “torture” in
R35(3), as well as in policy documents; see [98] where that is made explicit. This decision was not
appealed; the DCR were not amended. Their meaning has thus been authoritatively decided by a Court. It
is not open to the SSHD by issuing policy statements to alter the meaning of a statutory instrument,
whether expressly or by necessary implication. The AARSG is but guidance, so described by statute. It is
not a form of delegated legislation, albeit issued pursuant to a statutory duty and with formal expression of
Parliamentary approval. It is no more capable of altering delegated legislation, than delegated legislation is
capable of altering primary legislation, without a specific primary legislative power to do so. The AARSG
could no more expressly remove R35 itself than it could change the meaning of words used in it, whether
expressly or by some necessary implication. Therefore, “torture” in R35 continues to mean what EO found
it to mean.

127. It follows that DSO 9/2016 is unlawful in its advice to medical practitioners that no R35(3) report is
required where their concerns are of treatment which does not meet the UNCAT definition of “torture”, with
the specific terrorist group extension, that is severe pain or suffering inflicted by or with the consent or
acquiescence of someone acting in a public capacity or by terrorist groups holding territory. The two
template letters and template report are also unlawful for the same reason. The amendment of 11
November 2016, which advanced the role of the R35(1) report where the medical practitioner had concerns
that severe pain and suffering had been inflicted in circumstances which fell outside the definition of
“torture” in the DSO, is based therefore on a false premise as to the limits of R35(3), though it is capable of
mitigating the effect of the primary error. To the extent that the DSO definition applied to the way in which
Home Office staff considered the R35(3) report and decided what action to take upon it, it was unlawful
and their actions upon it too were unlawful.

128. Second, I accept that in theory Mr Strachan is right that the definition of “torture” in R35(3) can be the
_EO definition, while other definitions of “torture” can be used for other purposes in the AARSG or EIG 55b._
So, a R35(3) report could be prepared and assessed under the “EO torture” definition. A different definition
of “torture” could then be used for assessing whether someone was “particularly vulnerable to harm in
detention”. Alternatively, other indicators of vulnerability could be brought into account in consequence of
the particular features of the UNCAT or AARSG definitions of “torture”.


-----

Commission intervening) [2017] EWHC 2461 (Admin)

129. But, third, the issue cannot be left at that somewhat unreal juncture. This is because that is not the
basis upon which the AARSG, EIG 55b and DSO were drafted. They were drafted to be a consistent and
coherent whole, for ready application by case workers, Home Office staff, medical practitioners, detainees
and their advisers alike.  The whole is directed to consistency in indicators of harm, levels of evidence of
vulnerability to harm, weighing the risk of detention and assessing the strength of countervailing factors
warranting detention despite particular vulnerability to harm. R35(3) reports are part of the process
whereby information could be obtained for those with one of the defined indicators, and an important longstanding indicator of unsuitability for detention. The SSHD thought that the DCR definition had been
changed so that all adopted the same “UNCAT torture” definition, plus the terrorist group extension. If the
assumption is false, as I find it to be, that the same definition has been applied across all the documents,
the AASRG has been promulgated without consideration of a material consideration, namely that the
definition of “torture” for the purposes of R35 remains the EO definition, and the DCR remain unchanged.

130. This conclusion is reinforced by other related consequences. The DCR only apply once someone has
been detained; the AARSG applies both before and after detention. It would be very odd indeed for one
approach to vulnerability to apply before detention and another afterwards. Then, once in detention, those
who had suffered torture within the UNCAT definition could have the benefit of a R35 report, but those
who suffered torture outside the UNCAT definition would not - although they might fall within another
specific indicator of particular vulnerability to harm in detention. A further curious distinction would arise, in
the consideration of particular vulnerability to harm in detention, as I later find may happen, between
individuals claiming “EO torture” outside “UNCAT torture”, depending on whether an alternative specific
indicator applied or not. These oddities would have to be understood and applied by the caseworkers,
Home Office staff, medical practitioners, detainees and their advisers. This highlights that all three
documents were intended to be and were seen by the SSHD as being consistent with each other, and the
problems which arise, when in fact they are not. No advice was ever issued to the caseworkers on how to
deal with such inconsistency as would obviously be necessary. That is because it was never intended and
the problems were never considered.

**(2) Does the AARSG contain an exhaustive list of indicators?**

131. The second issue is whether the AARSG contains an exhaustive list of indicators of particular
vulnerability, such that some instances of vulnerability, which fall outside “UNCAT torture” but within “EO
torture” are excluded from the indicators of vulnerability. This is independent of the relationship between
the AARSG and the DCR. Mr Strachan submits that, correctly understood, the AARSG does not have that
effect; the specific list is not exhaustive. All those particularly vulnerable to harm in detention were provided
for, one way or another. How they were covered was not relevant. Mr Buttler agreed with Mr Strachan, as I
understood it, that the list of indicators in the AARSG was not exhaustive, but Ms Harrison did not.  I agree
with Ms Harrison.

132. In paragraph 7 of the AARSG, a person is regarded as being an adult at risk if they suffer from a
condition or have experienced a traumatic event, of which torture is an example, that would be likely to
render them particularly vulnerable to harm in detention. Likewise, if those considering or reviewing
detention are aware of evidence indicating a condition or event, of which torture again is but an example,
that would be likely to render someone particularly vulnerable to harm in detention, the adult is to be
regarded as being at risk.

133. Paragraph 8 is also generally expressed: the question is whether a particular individual should be
regarded as being at risk in terms of the AARSG. Where someone declares they have experienced a
traumatic event, that declaration forms part of the available evidence upon which an official will judge
whether the individual should be regarded as being at risk; the same applies to those covered by the
second bullet point in paragraph 7. Paragraph 9 deals with the evidence levels for whether somebody is at
risk, used to assess the likely risk of harm to the individual if detained. So far, it is all very general.

134. What follows in paragraphs 11 and 12 is crucial. They contain the specific indicators of risk: “a list of
conditions or experiences which will indicate that a person may be particularly vulnerable to harm in


-----

Commission intervening) [2017] EWHC 2461 (Admin)

detention”. There is no doubt that the list of indicators is intended to fulfil one of the aims of the new
approach, which is to recognise a much greater variety of circumstances which may make an individual
particularly vulnerable to harm in detention. One of those is “having been a victim of torture” which is
defined in the footnote by reference to the UNCAT definition.

135. The inclusion of the UNCAT definition (plus terrorist groups), with no specific reference to other
circumstances in which torture may be inflicted within the EO definition, leads me firmly to the conclusion
that the UNCAT definition (plus terrorist groups) must have been intended as the exclusive definition of
“torture”. This point is reinforced by the fact that, on the _EO definition albeit properly understood, there_
would have been no need to specify the UNCAT definition, since torture within the latter and narrower
definition would have fallen within the scope of torture in the former and more general definition. It would
also have been unnecessary to require consideration and investigation of state acquiescence in the
infliction of torture by non-state actors, or the particular and perhaps temporary powers exercised by
terrorist groups. It would have avoided the problem of medical practitioners, able to give evidence on
particular vulnerability to harm, also being expected to enquire into the political questions of state actors or
non-state actors, or state acquiescence, consent or instigation or the status of groups as terrorist or
holders of territory. I return to that later.

136. Paragraph 12 shows that the list in paragraph 11 is not exhaustive but it does so in very limiting
language: “it cannot be ruled out that there may be other, unforeseen conditions that may render an
individual particularly vulnerable to harm … in detention….” The AARSG therefore only accepts a limited
category of unforeseen conditions, which may possibly exist. That is the only additional indicator to the
ones specified in paragraph 11. The two paragraphs together contain no other provision for an indicator.

137. It is clear that they are not intended to cover, as a general category, all circumstances in which an
individual may be particularly vulnerable to harm if detained; paragraph 12 is not a general sweeping up
provision. If a general sweeping up provision had been intended for those with a particular vulnerability not
covered by a specific indicator, it would have been very simple to have stated it. I do not see that
paragraphs 11 and 12 together can be read other than as creating an exhaustive list, but not one
necessarily broad enough to cover all circumstances in which a person may be particularly vulnerable to
harm in detention. Paragraph 7 provides no assistance to Mr Strachan: in the light of paragraphs 11 and 12
it must be read as containing examples from what is an exhaustive list in paragraph 11, coupled with the
limited additional provision in paragraph 12.

138. It is also clear that there is a readily foreseeable category of cases, as Mr Buttler submitted, where a
person may be particularly vulnerable to harm, which fall outside the scope of “UNCAT torture”, outside the
scope of the other listed indicators but within the scope of “EO torture”. It may not be a large category, in
view of the other indicators, which cannot be ignored, but it exists. HT was an example: she was severely
beaten as a child by moneylenders who tried to force her to repay her parents outstanding debt. Another
would be that of someone kneecapped by a paramilitary group, which did not hold territory, as a
punishment for what it perceived as misbehaviour or to force a confession in a country which did not
acquiesce in such treatment. A person might be held and injured by religious fundamentalists as
punishment for apostasy or other offence against their religious code. The asylum claim might fail, but the
question is whether the individual is particularly vulnerable to harm in detention.

139. I accept Mr Strachan's submission that some, and perhaps most of those, who fall outside the
UNCAT definition will fall within at least one of the other indicators. The non-state actor victim of torture
may suffer from PTSD, or may have been the victim of gender-based violence. This may be so, but as it
would also be true of those who suffered torture within the UNCAT definition, I cannot conclude that the
other indicators are intended to fill in gaps in the definition of “torture”, rather than to be indicators in their
own right. As Mr Buttler submitted, there is no defined approach for those who declare that they have
suffered from “non-UNCAT _EO torture” or have medical evidence supporting their declaration, in the_
AARSG, unless they fall within another of the specified indicators.


-----

Commission intervening) [2017] EWHC 2461 (Admin)

140. Mr Strachan pointed to the language of EIG 55b, which describes some of the indicators of risk, and
refers to other specific experiences which may indicate that an individual may suffer particular harm if
detained, because those experiences may have affected the individual's mental state. “Indicators can
include: having been a victim of torture (as defined in [UNCAT]… having been a victim of sexual or genderbased violence… having been a victim of human trafficking….” He submitted that this showed that the
question to be asked was whether a person had had specific experiences affecting his mental state and
thus whether he would suffer particular harm if detained. It therefore covered any experience which had
that effect, and instances which fell outside the specific indicators, including torture as specifically defined
by reference to UNCAT, would nonetheless fall within the scope of the risk indicators read as a whole.

141. There is, in my judgment, a marked difference between the AARSG and EIG55b in the way the two
treat circumstances in which an individual may suffer particular harm if detained. EIG 55b appears to have
a much broader general category designed to encompass all those particularly vulnerable to harm if
detained, but who do not fall within a listed indicator. This would cover those who fall outside the scope of
“UNCAT torture” but within “EO torture.” Although related documents can be read together, the AARSG
ought to stand on its own as statutory guidance. In any event, in the hierarchy of documents, the statutory
guidance approved by Parliament has to be read as controlling the scope of EIG 55b. The difference
cannot be eliminated without preferring or giving dominant effect to one over the other. The latter cannot
contradict the former.

142. I accept that the SSHD had intended that the list of indicators should not be exhaustive and that that
intention is reflected in the language of EIG 55b, and in her evidence. But I do not consider that that result
has been achieved in the statutory guidance to which EIG 55b must relate.

143. I also accept that, whether or not it might be lawful or practicable to have different indicators or
definitions of torture between statutory guidance and operational guidance, such an outcome was never
intended, not least, as I have already discussed, because of the obvious practical difficulties of operating
one or more sets of indicators and definitions directed to the same purpose of avoiding or removing from
detention those particularly vulnerable to harm, unless there is a sufficiently strong countervailing
justification.

144. The error accepted by the SSHD, as I understand it, in the application of R35(3) by medical
practitioners is that they have not made a report where the torture is not “UNCAT torture”, regardless of the
other indicators which might apply. Case worker errors had not arisen in the application of the definition of
“UNCAT torture” but rather in the assumption that “non-UNCAT torture” was not an indicator of risk,
according to Mr Strachan. For example, such reports have been refused where a woman had been raped
and abused by her uncle as a child, or where another woman had suffered severe pain and suffering at the
hands of her husband, where a man had been kidnapped and detained by cult members who had tortured
him to obtain a blood oath.

145. But, in my judgment, the R35 errors arose from unlawful Guidance and provisions in DSO 9/2016; the
case worker errors were in part not errors at all; they were partly the result of a correct interpretation of
unlawful Guidance on the exhaustive nature of the indicators, and partly the result of a failure to consider
the application of other indicators where the “UNCAT torture” definition did not apply. I do not accept Mr
Buttler's submission that this latter point itself showed that the AARSG or EIG 55b were unlawful in
creating too great a risk of misinterpretation or unlawful application. I am surprised that the need to
consider other indicators where non-UNCAT “torture” was found was not more fully spelt out, but that
omission does not make for unlawfulness here.

**(3) The consequences of that interpretation**

146. Mr Buttler submitted that the consequence of Burnett J's judgment in _EO was that, if the UNCAT_
definition were used as an indicator of risk, a separate indicator for the other circumstances of torture
which fell within the definition, was required as a matter of law. Parliament, he submitted, intended to treat
“EO torture” as an indicator of risk rather than confine it to “UNCAT torture”. Ms Harrison emphasised the


-----

Commission intervening) [2017] EWHC 2461 (Admin)

purpose of s59 of the 2016 Act. Mr Strachan submitted that there was nothing unlawful about the use of
the UNCAT definition or of different definitions of “torture”.

147. On the basis of my interpretation of the AARSG, I accept that the AARSG is unlawful in the way in
which the torture indicator has been limited to the UNCAT definition of “torture”, plus terrorist groups
holding territory, and the limited additional category of unforeseen cases. This unlawfulness can be
expressed in a variety of ways.

148. First, s59 of the 2016 Act and the AARSG follow upon the Government's acceptance of the thrust of
Mr Shaw's recommendations in his report. The purpose of s59 of the Act was to focus on those who were
unsuitable for detention because they were particularly vulnerable to harm in detention. The indicators
were the tool developed in the AARSG for identifying those people. The overall changes used “indicators”
of the particularly vulnerable, which itself suggests something looser than the “categories” they replaced;
and there was a broader range of indicators than of categories.  The AARSG added what was called a
“dynamic category” for other vulnerable people but, as I have found, did so in rather limited terms.

149. In achieving its purpose, s59 focused on all those who were particularly vulnerable to harm in
detention, and not on a group of them or most of them. There is no discretionary provision for some such
vulnerable people to be omitted from the protection of the new approach. There is no identified statutory
purpose which is served by the omission of any person who is particularly vulnerable to harm in detention.
Whether or not there is a long or short list of specific indicators, the Act does not permit the AARSG to
exclude some particularly vulnerable people.

150. For the purpose of the AARSG, the experience of torture is an indicator of particular vulnerability to
harm in detention; the purpose of its definition is to serve as an indicator of that vulnerability. Its definition
is not there to define a criminal offence, nor to help show that an individual has a claim for humanitarian
protection or asylum on any basis. If a limited definition of “torture” is used for the “torture” indicator, the
circumstances thereby omitted have to be covered in some other way if the protection of those who are
particularly vulnerable to harm in detention is to be provided through the AARSG in the way intended by
s59, through the grant of the power to issue it.

151. Mr Strachan is right that there is nothing in s59 itself which states how torture should be defined; but
it intended that the statutory guidance should cover those who are adults at risk, because they are
particularly vulnerable to harm in detention. How that is done is affected by how “torture” is defined. Mr
Strachan is right that the SSHD is entitled to treat “UNCAT torture” as a free-standing indicator of
vulnerability where others at risk were covered by other indicators. But that only emphasises the
importance of ensuring that the other indicators have that effect. A general inclusionary provision is
required if some such cases are not the subject of specific indicators. That is missing from the AASRG.

152. So the AARSG thus formulated, falls short of meeting the statutory purpose which it is required to
meet on the basis that there are some, excluded from the scope of “UNCAT torture” who do not fall within
another indicator but yet are particularly vulnerable to harm in detention. It is to that extent, to put it another
way, beyond the powers of s59. It is unlawful on that basis. Parliamentary approval of guidance cannot
make it intra vires any more than Parliamentary approval of a statutory instrument can do so. I also note
that the Act had not changed the definition of “torture” in the DCR and Parliament was not told that a
different definition was being adopted for the AARSG. Parliament did not debate this particular issue
anyway, which reduces the extent to which particular caution is required before reaching the judgment I
have reached. That is the primary way upon which I find that the AARSG was unlawful under this third
head.

153. There is a second, related, basis on which the AARSG is unlawful. It draws a distinction between its
variant of “UNCAT torture” and “EO torture”, which affects the assessment of particular vulnerability to
harm in detention. There is no evidence that such a distinction relates to the relevant vulnerability. The
evidence rather is that it does not. The correct, albeit seemingly unintended, interpretation of the AARSG,
limiting the specific indicator of “torture” to the UNCAT definition, with no comprehensive alternative
coverage by other specific indicators or some more general provision has no rational or evidence base


-----

Commission intervening) [2017] EWHC 2461 (Admin)

154. The chief problem with the UNCAT definition, with or without the variant inclusion of torture by
terrorist groups holding territory, is that it excludes certain individuals whose experiences of the infliction of
severe pain and suffering may indeed make them particularly vulnerable to harm in detention. The
exclusion is created by the reference in the definition to the identity of the perpetrator: where the severe
pain or suffering is inflicted by a public official or other person acting in an official capacity, or at the
instigation of or with the consent or acquiescence of such a person. It includes acts inflicting severe pain or
suffering committed by terrorist groups exploiting instability or civil war to hold territory but not severe pain
or suffering committed by other groups or terrorist groups who are not exploiting instability or civil war or
who are not holding territory. That definition applies only to some of those who are particularly vulnerable
to harm in detention as a result of the infliction of severe pain and suffering.

155. The variant UNCAT definition could be a lawful definition of “torture”, meeting the purpose of s 59 of
the 2016 Act, if there were sound evidence that the identity of the perpetrator, state agent or terrorist group
holding territory, was key or highly material to the particular vulnerability of the victim to harm in detention.
But there is no such sound evidence. Burnett J in EO found, on the evidence before him, that the identity of
the perpetrator was not relevant to the definition of torture for the purpose of the policy then applicable to
protect those particularly vulnerable to the effects of detention.

156. The SSHD, in my judgment, was entitled to bring forward evidence beyond that in _EO to counter_
Burnett J's conclusion. However, I am satisfied that there is no new evidence of substance from her to
justify the exclusion of severe pain and suffering inflicted in situations of powerlessness by a range of nonstate actors, for the purposes of assessing particular vulnerability to harm in detention. I have set out at
some length the evidence deployed on behalf of the Claimants; the evidence relied on by the SSHD is not
of the same calibre or range, nor is it clearly directed to that particular issue.

157. I accept that there are circumstances in which the identity of the perpetrator can make the victim
particularly vulnerable to harm in detention, notably where the severe pain and suffering is inflicted by a
person in a position of trust, such as a family member. But the identity of the perpetrator, as a public or
non-public official, is of no real importance to whether the victim of the infliction of severe pain and
suffering is particularly vulnerable to harm in detention.

158. I have some sympathy with Mr Strachan's point that “UNCAT torture”, with or without the terrorist
group addition, merits particular focus because of what Mr Nowak, for example, identifies as its particularly
abhorrent nature, and because that is most likely to have occurred in detention, and in a situation of
powerlessness, either in state detention or where the state itself acquiesced in or was unwilling or unable
to prevent it; at least that obvious and important group had been defined and provided for. But that leaves
the problem of the omission of those who were not in the exhaustive list of indicators but are particularly
vulnerable to harm in detention. While there are features of torture by a state agent which mean that
detention in the UK can be redolent of the circumstances of torture to a victim of torture, the evidence
shows that it is not only torture by a state agent or equivalent terrorist group which has such features. Mr
Nowak was not, as I read it, focussing on the appropriate definition of “torture” for use in this very
particular context, but rather on those acts which should be prohibited, with legal sanction.

159. As I have already said, Mr Strachan is right that a number of circumstances which fall outside the
scope of “UNCAT torture” but within “EO torture” would fall within the scope of some other indicators. If
those other indicators did in fact cover all the other circumstances in which someone experienced nonUNCAT “torture”, this issue would not arise; the definition of “torture” in one indicator, subject to the issue
about R35, would be irrelevant.  But as that is not the case, those other indicators mitigate but cannot
resolve the problem.

160.  Instead, this gap gives rise to a further problem highlighted by Ms Harrison. She contended that if
victims of “EO torture”, who were not victims of “UNCAT torture”, did not fall within the scope of another
AARSG indicator, but only within some other unspecific indicator of the sort which Mr Strachan contended
the AARSG provided, they would be subject to an additional hurdle: they would have to show that they
were particularly vulnerable to harm in detention; it was not enough for them to provide a history in which


-----

Commission intervening) [2017] EWHC 2461 (Admin)

severe pain and suffering had been inflicted, for the specified purposes, in a situation of powerlessness. Mr
Strachan denied that that was the effect of the AARSG. Were there a further specific indicator, “having
been a victim of torture as defined in EO”, that indicator would necessarily indicate, as set out in paragraph
11, “that a person may be particularly vulnerable to harm in detention.” If the AARSG could be so
interpreted, Mr Strachan's answer would be right. But it cannot be so interpreted.

161.  However, if Mr Strachan were right that there was some unspecified category, which would cover
non-UNCAT victims of torture outside the scope of the other listed indicators, it is difficult to see by what
test those other circumstances could indicate that a person may be particularly vulnerable to harm in
detention, other than that the particular vulnerability to harm is itself demonstrated. That is an additional
hurdle, whether intended or not. That may not be of itself unlawful, but it could give rise to a discrimination
point.

162. Third, there is a further feature of the use of the UNCAT definition of “torture” in the AARSG which
the Claimants submit makes it unlawful. The judgement about whether somebody is particularly vulnerable
to harm in detention as a result of the infliction of severe pain and suffering is likely to be made by a
medical practitioner. The UNCAT definition of “torture”, with or without the terrorist group variant, requires
investigation and judgements to be made about political issues by medical practitioners who are very
unlikely to have the knowledge and expertise to make them. These political issues concern whether an
individual was a public official or whether the state had instigated, consented to or acquiesced in the
torture. As enlarged, the definition requires understanding of what is or is not a terrorist group, whether it
holds territory, and the circumstances in which it operates. It is by no means clear that the detainee, absent
assistance from lawyer or expert, would be in a position to assist the medical practitioner. The political
issue can be resolved by a caseworker; but the caseworker's intervention cannot be a substitute for the
medical practitioner on the question of whether somebody is particularly vulnerable to harm in detention.
There could thus be two investigations to establish whether someone fell within that indicator. This may be
cumbersome, but it would not be irrational of itself for the AARSG to so provide. But it is irrational for the
issue and its investigation to be left to the medical practitioner, if that definition is to be used, without further
provision in the AARSG dealing with how the non-medical issues raised by the UNCAT definition of
“torture” are to be covered. But that is how it was left.

163. The same factors apply, but with greater force, to the possible future use of the UNCAT definition in
the DCR, which the SSHD seems to wish to use if she lawfully can. I do not regard it as rational to require
a doctor to carry out an investigation into or reach a judgement on the political background to the severe
pain and suffering which is his focus. I have no difficulty understanding why a detainee might be reluctant
to go to a doctor, if he or she thought that it was going to require what was in effect a further interview on
the substance of a claim yet to be ruled on. That could still apply where the claim had already been ruled
on, and the detainee was awaiting removal; but it can do where fresh claims might be made. The R35(3)
process does not have a role for the caseworker in the provision of the report or within the investigation
with the detainee and the political issues, but only in its later assessment.

164. If the definition of “torture” used for the purposes of R35(3) were to be the UNCAT definition, with or
without the terrorist group addition, there would be no provision for a medical practitioner to report on “EO
torture” which fell outside the UNCAT definition, even if it fell into another indicator. Sexual violence is an
example. Such a report is however the most common way for someone in detention to obtain medical
evidence at Levels 2 or 3 for the purposes of the AARSG. That too is not unlawful, though it has not been
considered, and it could give rise to discrimination issues.

165. The amendment to DSO 9/2016 of 11 November 2016 highlights the problem. It required medical
practitioners, concerned about particular vulnerability to harm where a claim to have been tortured did not
meet the UNCAT definition of torture, nonetheless to report their concerns. This was to be done either by a
R35(1) report or by completing an IS91 RA Part C risk assessment. They were also required to err on the
side of caution in deciding whether a claim to have been tortured did or did not fit the UNCAT definition
because of the identity of the perpetrator; they should make a report and leave it to the Home Office to
make the assessment


-----

Commission intervening) [2017] EWHC 2461 (Admin)

166. R35(1) however is an insufficient answer. It has a different focus from a R35(3) report. The threshold
for the operation of R 35(1), a person “whose health is likely to be injuriously affected” by detention, is
equivalent to evidence at Level 3 of the AARSG. This is a significantly higher threshold than is needed for
the consideration of risk following self-declaration of an indicator of risk. It is significantly higher than that
required for a R35(3) report, which focuses on the existence of an indicator rather than direct evidence of
injurious effect on health. It is not aimed at the question of particular vulnerability to harm in detention,
though it will cut across it. IS91 RA Part C is not a substitute for a R35(3) report; it was more a source of
release than a trigger for thought about suitability for detention and weighing the counter-vailing factors.
Erring on the side of caution is obviously not changing the definition.

167.  These steps, in my judgment, may reduce the risk of error but the need for those steps and the
amendment highlight the problem, which is the role given to the political question of whether the
perpetrator of torture was a state or non-state agent, which is irrelevant to the question of whether
someone is particularly vulnerable to harm in detention, to which R35(3) reports are directed.  They also
rather undermine the justification for the use of that definition. This all may reflect the limitations of the
language of R35(3) where the issue is confined to “torture”, but the issue which now needs to be
addressed is “particular vulnerability to harm in detention.” The problem may be that R35 has not caught
up with the changed thinking on vulnerability in detention.

168. Fourth, Ms Harrison pointed to other differences between the EIG and the AARSG to suggest that
either or both were unlawful. The AARSG, at paragraph 9, refers to level 3 evidence as being professional
evidence that a period of detention for the individual at risk “would be likely to cause harm”. Level 2
evidence is professional evidence which “indicates that the individual is an adult at risk.” The EIG
elaborates level 3 evidence as evidence that detention “is likely to lead to a risk of significant harm to the
individual if detained for the period identified as necessary to effect removal….” (My italics). These are
differences of expression because “significant harm” is not the language of the AARSG. The EIG focuses
on the period of detention necessary to effect removal, but the AARSG uses a mixture of expressions
including both “a period” of detention and “the period identified as necessary to effect removal”. The fact
that these differences exist but are neither highlighted nor explained does not in my judgment make either
unlawful, nor the two together.

169. Nor do I consider there to be an unlawful inconsistency in relation to the detention of foreign national
offenders. The AARSG, paragraph 14, is expressed in general terms but is not inconsistent with the more
elaborate or specific guidance in EIG 55b, which refers to those facing a significant risk of harm in
detention if detained for the period necessary to effect removal, but who present a significant public
protection concern or had been subject to a custodial sentence of four years or more. There is no
presumption of detention even in those circumstances; they are still only being considered for detention.

170. Mr Strachan said that the reference to “ill-treatment” in the EIG but not in the AARSG was a stray
error; there was no specific evidence to that effect but, quite apart from Mr Strachan's instructions, that
seems to be a proper inference which I am prepared to accept. The reference to “ill-treatment” in the EIG
was not repeated in the DSO where “torture” is defined.

171. Fifth, none of this however is to say that the SSHD is obliged to adopt the EO definition of “torture” as
its definition in any redrafted R35 or Guidance or EIG. There are limitations to the usefulness of the _EO_
definition of “torture”, as I have touched on in [15]. It applies only to severe pain or suffering inflicted for a
limited range of purposes. There is no clear evidence from either side that that limited range of purposes
encompasses those purposes to the infliction of severe pain and suffering which may make somebody
particularly vulnerable to harm in detention. Mr Buttler submitted that this case did not involve any question
of whether the EO definition of “torture” required clarification or adaptation, because it limited the purposes
for which the infliction of severe pain and suffering amounted to torture; therefore I should say nothing
about it. Mr Strachan commented that if I had any observations on definitions and their use, the SSHD
would wish to hear them. I also cannot help but observe that if issues over definitions were capable of
leading to yet a further round of litigation, avoidable potentially through consideration of them now, there
are advantages to them being pointed out rather than in later litigation


-----

Commission intervening) [2017] EWHC 2461 (Admin)

172. I have some other difficulties with Mr Buttler's approach. At the heart of the expert evidence called by
the Claimants is the view that the crucial determinant of torture-related vulnerability to harm in detention is
the situation of powerlessness in which the severe pain and suffering are inflicted, and not the identity of
the perpetrator. The limitations of the _EO definition are in fact clear from the Claimants' own evidence,_
notably that of Dr Korzinski, quoting from Helen Bamber's evidence in EO, to the effect that, as cruelty is
rarely mindless, the most critical element is the consequence of the infliction of the severe pain and
suffering rather than the purpose for which it was inflicted, at least for therapeutic purposes.

173.  If Mr Buttler's submission on the evidence is correct, adoption of the EO definition is an inadequate
solution. EO may solve the state versus non-state actor issue, which is all it was intended to do. But that is
not the only issue now engaged, on the Claimants' evidence, or on the SSHD's intended approach. The
_EO definition is not confined to, or defined by, whether the severe pain or suffering was inflicted in a_
situation of powerlessness. The focus is on particular vulnerability to harm in detention, which is a concept
wider than EO torture.

174. I also note that the evidence of Dr Clark drew no distinction between torture and ill-treatment. Dr
Katona refers to ill-treatment, and included cruel, inhuman and degrading treatment in his definition of
“torture”. Yet it was not suggested on behalf of any party that ill-treatment which did not amount to torture
should be a specified indicator if it did not arise from or lead to any of the other specified indicators. It is
important therefore to be cautious about what definitions or defining characteristics are adopted for this
particular purpose of indicating risk of particular vulnerability to harm in detention. The _EO definition of_
torture is not consistent with the fullness of the evidence given in that case or this.

175. Subject to the relationship of the AARSG to the DCR, there is no reason why the definition of torture
used in the AARSG needs to be the UNCAT definition; it does not need to be the EO definition either. The
SSHD can develop her own definition for use for the particular purposes for which the DCR and AARSG
are intended to be put. The EO definition, shorn of the perpetrator's identity, focuses on the limited range of
purposes for which severe pain and suffering were inflicted, without itself focusing on whether that
definition necessarily identifies and only identifies the criteria for understanding the concept of a situation of
powerlessness and the impact which that has on the particular vulnerability to harm in detention of the
individual in question.

176. The difference between the UNCAT definition and the EO definition of “torture”, which the change in
approach to “particular vulnerability” highlights, is that the EO definition of “torture” is wholly unconstrained
by reference to any circumstances in which the pain and suffering is inflicted and focuses on the purposes
for which it was inflicted. Removing the identity of the perpetrator has removed the indirect effect of the
perpetrator's identity as a constraint on the circumstances within the scope of the definition. The UNCAT
definition, on the other hand, which included a wide but not comprehensive range of perpetrators, provides
for too limited a range of circumstances to cover those who were tortured in situations of powerlessness
such as to make them particularly vulnerable to harm in detention. Identity of the perpetrator in the UNCAT
definition acted as a constraint on circumstances, but in too narrow a way; in the EO definition, there was
no constraint on circumstance, and so no relationship between the acts and the situation of powerlessness.
Yet it is that situation which the evidence shows is the key to particular vulnerability to harm in detention.
Hence, the SSHD's understandable concern that the use of the EO definition was leading to R35 reports
which appeared remote from torture and particular vulnerability to harm in detention. I make these points
so as to be clear that the problems with the use of the UNCAT definition do not compel the SSHD to adopt
the EO definition instead.

177. All circumstances in which severe pain and suffering are inflicted, regardless of purpose, seem likely
to involve a situation of powerlessness for a longer or shorter period. However, the situation of
powerlessness to which the expert evidence refers must be something somewhat over and above that
which is inherent in the mere fact that the individual has been unable to prevent the infliction of severe pain
and suffering. It would otherwise be irrelevant to the question of vulnerability in detention. What the
evidence is pointing to is the relevance of the circumstances in which the severe pain and suffering were
inflicted Some of those circumstances indicate a particular vulnerability to harm in detention because of


-----

Commission intervening) [2017] EWHC 2461 (Admin)

the powerlessness of the individual. State inflicted torture, or torture which it acquiesced in, or consented to
or instigated, or torture by terrorist groups exercising control over territories are obvious situations of
powerlessness. But powerlessness may relate to the identity of the perpetrator, for example where there
has been abuse by family members in the home. It may include a prolonged period of severe pain and
suffering from which escape was prevented or not practically possible. The duration of the experience, the
severity of the pain and suffering and all the other circumstances in which it was inflicted, which does not
exclude that the identity of the perpetrator may add to the trauma of the experience, are all relevant to
powerlessness and thus to particular vulnerability. The definition of torture, if that indicator is to be retained,
and is to focus on why the circumstances in which it is inflicted may create particular vulnerability to harm
in detention, should focus on those aspects. Neither UNCAT nor EO definitions of torture are particularly
apt for that purpose.

**(4) Other points**

178. Mr Strachan submitted that there was no pleaded ground that the considerations set out in Ms
Rouse's witness statement, notably reducing the number of R35 reports, concern that too many were being
released who should not have been and that they were then absconding, were immaterial. If pleaded,
these points would have been answerable by evidence. In the light of the orders made by Jay J on 20
February 2017, refusing permission to the Claimants to make certain amendments to their grounds, I do
not need to consider their contention under this head. But some aspects are germane to the earlier
grounds.

179. The thrust of Mr Strachan's point was that although those considerations reflected desired outcomes,
they did not affect the focus of the objectives behind the changes. One desired outcome of the choice of
the UNCAT definition was to reduce the number of those who had not been tortured, and who were not
particularly vulnerable to harm, being treated as if they had been. The individual attacked in the course of a
neighbour dispute or a person attacked in the street because of his sexual orientation should not without
more be regarded as victims of torture. Independent evidence of an assault, without any correlation to
vulnerability to harm in detention being provided through an indicator or more direct medical evidence,
should not be treated as independent evidence of torture. EO torture did not necessarily involve detention
or the deprivation of personal liberty, which is much likelier with UNCAT torture. The expert evidence did
not say that all EO torture necessarily indicated particular vulnerability to harm in detention but only that the
identity of the perpetrator could affect but was not determinative of it.

180. I understand why the SSHD is concerned that the application of the EO definition of “torture” has led
to R35(3) reports being sought in greater numbers than before, that that has created a very considerably
increased workload for medical practitioners at detention centres, and that a number of such reports have
been based on descriptions of events which seem far removed from even a colloquial understanding of
torture. Reducing unmeritorious cases is not unlawful as an end. I appreciate that the Claimants' evidence
is that there are other factors at work, such as greater time in which to seek such reports and greater
awareness of them. I do not need to resolve these issues.

181. The answer however may be to spell out the requirement for and what is meant by a situation of
powerlessness, and the gravity or duration or severity of the pain and suffering which has to be inflicted to
amount to “torture”, which makes someone particularly vulnerable to harm in detention. Those who reach
decisions on detention need to have statutory guidance, elaborated in case worker instructions, which
focus on the true issue, which is whether the description of events and their circumstances show that a
person may be particularly vulnerable to harm in detention, and, where that is said to arise out of the
infliction of severe pain and suffering, whether that was in a situation of powerlessness. If they focus on
that and reach the conclusion that an individual may be particularly vulnerable to harm in detention, that is
simply the consequence of s59, and lawful guidance. It is relevant to the framing of guidance and casework
instructions that it enables decision-makers to focus on those who are particularly vulnerable to harm in
detention. It is not relevant to that issue that more people may seek R35 reports.


-----

Commission intervening) [2017] EWHC 2461 (Admin)

182. In the light of Jay J's Order, I do not need to consider the further contention that the SSHD ought to
have made enquiries as to what the UNCAT definition of torture meant particularly by reference to General
Comment No. 2 and state acquiescence in the infliction of torture. Ms Harrison and Mr Buttler made much
of the SSHD's comment that she had yet to decide whether that interpretation was one she adopted. Mr
Strachan explained that that was to do with the status of the Comment rather than the nature of the points
raised. Many of Mr Buttler's other criticisms of the SSHD could not be fitted into a category of error of law
anyway. Even were the SSHD undecided about the effect of General Comment No.2, that cannot make the
AARSG or its definition of “torture” unlawful. It is for the Court to decide its meaning.

183. The need for caution over the application of General Comments is illustrated by General Comment
No.3 which defines “victim of torture” in broad terms including the affected immediate family or dependents
of “the victim”, as well as persons who suffered harm intervening to help victims or to prevent victimisation.
No one has suggested that that should feature in the AARSG.

184. Permission was also refused to argue a ground based on legal certainty in the definition of torture.
But there is nothing in it anyway. Policy does not have to cover every eventuality or explain every point in
order to be sufficiently certain for the purposes of Lumba, above. The definition of torture in the AARSG is
very similar to that in s 134 Criminal Justice Act 1988 which creates the specific offence of torture, largely
adopting the UNCAT definition. It does not, however, specifically criminalise the acquiescent actor, but that
appears to be because it is thought adequately covered by domestic law under s8 Accessories and
Abettors Act 1861. There is also a defence of lawful authority which, where the offence is committed
outside the UK by someone not acting in a UK official capacity, depends on the law of the place where it is
committed. Apart from illustrating the variety of definitions, Mr Strachan relied on it to counter, in my
judgment successfully, the Claimants' contention that the definition of torture used in the AARSG or EIG or
DSO was inherently unclear, and so unlawful.  It also shows that definitions of “torture” can properly vary
with the purpose for which the word is defined.

185. There is no need, in the light of the conclusions which I have reached, to consider whether the
AARSG was also unlawful because it carried too high a risk of unlawful decisions. The jurisprudence relied
on is not straightforward and the factual evidence suggests that by December 2016, with improved training,
the high error rate had been overcome.

**The public sector equality duty**

186. I  concluded, after writing a considerable portion of the judgment on this issue, that there was no real
point in doing so. I say that without meaning any disrespect to the arguments on this topic of either Ms
Harrison, Ms Lieven or Mr Strachan.

187. The principal issue raised was whether the duty in s149 of the Equality Act 2010 had been fulfilled.
There was no final Policy Equality Statement, and the first two drafts did not grapple with what the
Claimants submitted were the problematic issues arising out of the interpretation which they said the
AARSG and EIG required. There was evidence of considerable consideration of equality issues, but it was
clear from Mr Strachan's submissions, and not surprisingly, that that had been undertaken on the basis that
his submissions as to their meaning and effect were correct. Were Mr Strachan's submission correct, he
might well be correct on many of the aspects of the public sector duty challenge. I have however come to
the conclusion that his submissions are wrong, and that the AARSG will have to be altered in certain
respects.

188.  It is not possible for the SSHD to reach a lawful view on the equality duty without understanding the
true meaning of her policies in the first place. It inevitably follows that her consideration of the equality
impacts and duties will have been undertaken on a false basis. The fact that, on the correct interpretation
of the AARSG, there might be a breach of the PSED, does not add anything to the contention that it needs
to be amended. Further discussion of and a remedy in relation to those duties simply reflects those earlier
errors of law. Remedies in relation to Equality Act duties presuppose that the policies are otherwise lawful.


-----

Commission intervening) [2017] EWHC 2461 (Admin)

189. If the policies are amended and made internally consistent in definition and structure, reflecting what
the SSHD submitted was their true intention, their lawfulness in relation to Equality Act duties can be
properly assessed initially by her. The form of amendment will be for the SSHD to determine. The SSHD
will also be able to consider the need for a final PES before reaching a decision on the content of new
AARSG; the absence of a PES cannot be fatal to the fulfilment of the s149 duty, but a series of draft PESs
can suggest that finality is to come after the decision is reached.

190. The SSHD, in preparing new AARSG, will also be able to consider the equality issues raised in Ms
Schleicher's third witness statement, and in Ms Harrison's exposition of some of the data relating to a
decline in the number of R35(3) reports, comparing the figures from  IRCs for male asylum seekers with
those from Yarl's Wood, the main IRC for female asylum seekers. In the light of the timing of that third
statement and Mr Strachan's responses, I was not prepared to reach any conclusion about its content and
did not consider that I had a sound basis for concluding, with requisite confidence, that  the duties in ss13
and 19 of the Act had been breached.

191. Ms Harrison and Ms Lieven also raised the interesting issues of whether the SSHD/ Minister was
personally obliged to fulfil the s149 Equality Act duty and with what role for officials, and the interaction
between possibly different views in R(Staff Side of the Police Negotiating Board) v Secretary of State for
_Work and Pensions_ _[2011] EWHC 3175 (Admin) and Bracking v Secretary of State for Work and Pensions_

_[[2014] EWCA Civ 1345, EqLR 60 at [26], approved  in Hotak v Southwark LBC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5DCP-FGG1-F0JY-C257-00000-00&context=1519360)_ _[2015] UKSC 30 [2016] AC_
811 at [73]. But I see little point in resolving that issue when the SSHD has undertaken in Court that
EIG55b would not be amended from its 6 December 2016 version unless the Minister personally had had
due regard to its effect on the PSED through a PES. With the Minister prepared to accept that, it seems
likely that revised AARSG would be considered in the same way; if not the argument is still available, and
the answer would not be obiter.

**Overall conclusion**

192. Aspects of the AARSG in relation to the definition of “torture” are unlawful: the correct interpretation
of “torture” in R35 was ignored; the list of indicators was exclusive; this conflicted with the purpose of s59,
and lacked a rational or evidence base. The UNCAT definition of “torture” intended for use in the AARSG
and R35 would require medical practitioners to reach conclusions on political issues which they cannot
rationally be asked to reach. All this meant that EA issues were not considered on the proper basis.

193. I will hear counsel on the appropriate form of relief, beyond the formal undertaking given on 22
December 2016 in the detailed grounds of defence not to reintroduce DSO 9/2016 in its original form
unless a) the Court ruled that the SSHD could use the UNCAT definition of “torture” in the AARSG and EIG
55b, and b) an amendment to R35 DCR, approved by Parliament, had come into force, defining “torture” as
in the AARSG.

**End of Document**


-----

