# R (on the application of JB (Ghana)) v Secretary of State for the Home
 Department [2022] EWCA Civ 1392

Court of Appeal, Civil Division

Bean, Peter Jackson and Baker LJJ

25 October 2022Judgment

**Lisa Giovannetti KC and Colin Thomann (instructed by** **Government Legal Department) for the**
**Appellant Secretary of State**

**Chris Buttler KC and Ayesha Christie (instructed by Duncan Lewis) for the Respondent JB**

Hearing date 6 October 2022

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.30am on 25 October 2022 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

.............................

**Lord Justice Bean :**

1. There are separate financial support regimes for asylum seekers and victims or potential victims of
**_modern slavery. Some individuals, including JB, the Respondent to this appeal, are both asylum seekers_**
and victims of modern slavery. The appeal concerns the period from 24 March – 28 August 2020 during
which the relationship between the two support regimes, and the financial entitlement of JB and others in
[the same position as him, was governed by paragraph 15.37 of a Home Office document entitled “Modern](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
**_[Slavery Act 2015 – Statutory Guidance for England and Wales” (“the MSAG”).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**

_The facts_

2. JB is a national of Ghana, who (on his case) arrived in the United Kingdom in March 2011. In
November 2019, he was arrested as an illegal entrant and taken into immigration detention. He claimed
asylum on 12 December 2019.

3. While in immigration detention JB was referred to the National Referral Mechanism (“NRM”) for victims
of trafficking. On 17 December 2019 the Single Competent Authority within the Home Office made a
positive “reasonable grounds” decision with respect to JB, and he thus became entitled to support as a
“potential victim of trafficking” (“PVoT”). There has been no final “conclusive grounds” decision on his
status.

4. From 23 December 2019 to 25 March 2020, JB lived in accommodation provided by a friend. He
received £35 per week and the assistance of a support worker.

5. In March 2020 JB's friend was no longer able to accommodate him. JB therefore applied for asylum
support under section 95 of the Immigration and Asylum Act 1999. He was granted temporary support


-----

under section 98, and provided with temporary asylum accommodation at a hotel in Birmingham, on a fullboard basis, from 25 March 2020. He continued to receive payments of £35 per week. On 31 March 2020
he was granted support pursuant to section 95.

6. On 14 August 2020, JB issued a claim for judicial review. He sought additional (and backdated)
payments, increasing his financial support to £65 per week, on the basis that he had been entitled to that
amount under the terms of the MSAG issued by the Home Secretary in March 2020. The guidance was
amended on 28 August 2020. By amended grounds filed on 3 September 2020 JB limited his challenge to
a claim for back-payments of the difference between the sums previously paid to him and the £65 per week
he claimed to be entitled to under the MSAG before its amendment.

7. We enquired how many people were in the same position as JB, and were told that the answer is
thought to be at most 63. With such a small cohort of claimants the costs of this appeal might be thought
disproportionate to the amount directly at stake. The Secretary of State was concerned, however, that
following the judge's decision in this case, some claims have been issued (though at present they are
stayed) challenging the amendment to the MSAG in August 2020: that challenge has far greater financial
implications.

_The European Convention on Action against Trafficking_

8. The European Convention on Action against Trafficking in Human Beings 2005 (“ECAT”) is the principal
international measure designed to combat human trafficking. It is concerned, inter alia, with the treatment
of those in respect of whom there are reasonable grounds to believe that they are victims of human
trafficking and the support to be provided to them by Contracting States.

9. The United Kingdom signed the Convention in March 2007 and ratified it on 17 December 2008. It has
not been incorporated into UK law. While individuals cannot enforce its provisions directly, insofar as the
Secretary of State has adopted parts of the Convention as her own policy in guidance, her officials must
follow that guidance unless there is good reason not to do so: R (EM) v SSHD _[2018] EWCA Civ 1070 at_
§19.

10. Article 12 of ECAT provides as follows:

Article 12 – Assistance to Victims

1. Each Party shall adopt such legislative or other measures as may be necessary to assist victims in their
physical, psychological and social recovery. Such assistance shall include at least:

a. standards of living capable of ensuring their subsistence, through such measures as: appropriate and
secure accommodation, psychological and material assistance;

b. access to emergency medical treatment;

c. translation and interpretation services, when appropriate;

d. counselling and information, in particular as regards their legal rights and the services available to them,
in a language that they can understand;

e. assistance to enable their rights and interests to be presented and considered at appropriate stages of
criminal proceedings against offenders;

f. access to education for children.

2. Each Party shall take due account of the victim's safety and protection needs.

11. Analogous provision was made under Article 11 of the EU Anti-Trafficking Directive (Directive
2011/36/EU), prior to the UK's withdrawal from the European Union at the end of the transition period. The
scope of this duty was examined by the Court of Appeal in the EM case. Peter Jackson LJ held at [65] as
follows:

“The general duty on the State under Arts. 11(2) and (5) of the Directive is to provide assistance and
support to a PVoT by mechanisms that at least offer a subsistence standard of living through the provision


-----

of appropriate and safe accommodation, material assistance, necessary medical treatment including
psychological assistance, counselling and information, and translation and interpretation services”.

_The Modern Slavery Victim Care Contract_

12. The NRM provides the machinery for determining whether someone is a potential or confirmed victim
of trafficking and for ensuring they receive the appropriate support. Support is delivered to Potential
Victims in England by the Salvation Army as prime contractor (and by its subcontracted support providers)
pursuant to the Victim Care Contract (“VCC”) made between the Home Office and the Salvation Army in
2015. Schedule 2 to the VCC provided that, upon entry into the NRM of an individual assessed as being a
Potential Victim, an initial risk assessment and needs-based assessment was to be undertaken, to
ascertain the immediate welfare needs of the Potential Victim and their dependents. Accommodation was
generally provided on a self-catered accommodation basis or, in exceptional circumstances, where
individuals were found not capable of preparing their own food due to disability, debilitating illness or
ongoing treatment, on a catered basis.

13. Schedule 2 to the MSVCC set out figures for subsistence payments in cash, in accordance with the
following table:

14. As part of a reform package announced in October 2017, the Home Office proposed to align
subsistence rates provided to Potential Victims to those received by asylum seekers.  In K & AM [2018]
_EWHC 2951 (Admin) [2019] WLR 92 Mostyn J considered the scope of “subsistence needs” as provided_
for under Article 11 of the Trafficking Directive, and Article 13 of the Reception Directive. He observed at
§29:

“[Counsel] drew my attention to regulation 9(4) of the Asylum Support Regulations 2000 which excludes,
among other things, the cost of computers (which would include smartphones), travel, recreational items
and entertainment in the assessment of "essential living needs" for the purposes of asylum support. But
some money for these purposes is surely reasonably required by a person in the highly vulnerable and
distressing position of a victim of trafficking. This has recently been in effect conceded by the Home
Secretary through the contract change of 1 November 2018, to which I refer below”.

Service User Type Value of Subsistence Payment

Service user in catered accommodation provided by the £35
contractor

Service user in self-catering accommodation provided by the £65
contractor

Service user accommodated by the authority and in receipt of £65 minus the amount of subsistence received by
subsistence payments through that service (sic) the authority

Service user not accommodated by the contractor or the £35
authority (e.g. living with friends or family)

_The Statutory Guidance_

15. Mostyn J, whose decision in the case of K & AM was not appealed, had been critical of the failure of
the Secretary of State to publish guidance for the provision of support to victims and potential victims of
trafficking as she was required to do by s 49(1)(b) of the Modern Slavery Act 2015. As already noted, that
statutory guidance was published on 24 March 2020. Although this was the day after the Prime Minister
had announced the first national lockdown in response to the COVID-19 pandemic, the document had
plainly been drafted before any lockdown was anticipated.

16. Financial support within the guidance was provided for at §15.35 to 15.36 (emphasis added):

15.35 Potential victims and victims of **_modern slavery who have entered the NRM, received a positive_**
Reasonable Grounds decision and are in VCC accommodation or outreach support will be paid financial

|Service User Type|Value of Subsistence Payment|
|---|---|
|Service user in catered accommodation provided by the contractor|£35|
|Service user in self-catering accommodation provided by the contractor|£65|
|Service user accommodated by the authority and in receipt of subsistence payments through that service|£65 minus the amount of subsistence received by (sic) the authority|
|Service user not accommodated by the contractor or the authority (e.g. living with friends or family)|£35|


-----

support. This payment will continue while they remain in VCC support for as long as they are assessed to
have a recovery need for this assistance. Financial support is intended to meet the potential victim's
essential living needs during this period and assist with their social, psychological and physical recovery.

15.36. The current rate of financial support payable by the Home Office to potential victims or victims of
**_modern slavery receiving VCC support depends on the accommodation they are in. The rates are as_**
follows:

_•£65 per week for those in self-catered VCC accommodation_

_•£35 per week for those in catered VCC accommodation_

- 39.60 per week for those receiving outreach support in other accommodation

- ubject to 15.38 below, child dependents of potential victims will also receive financial support from the
VCC”  [details of payments in respect of child dependents were then provided].

17. Paragraph 15.37 provided:

“The payment rates will be adjusted if the potential victim or victim of **_modern slavery receiving VCC_**
support is also an asylum seeker or failed asylum seeker receiving financial support under sections 95, 98
or section 4 of the Immigration and Asylum Act 1999 (“asylum support”). In these circumstances, the
individual will receive £65 per week, made up of payments from asylum support and a further payment
from the VCC to take the total payment to £65 per week.”

Paragraph 15.38 dealt with child dependents and it is unnecessary to set it out here.

18. In R (MD) v SSHD [2022] EWCA 336 Underhill LJ said at [24]:

“At the start of the period with which we are concerned para. F-001 of Schedule 2 to the VCC provided for
weekly “subsistence payments” to be made to adult potential victims of trafficking, described as “Service
Users”, in accordance with a table defining the amounts by reference to “Service User Type”. We are
concerned only with the third row of the table, which specifies the payments for service users
“accommodated by the Authority and in receipt of subsistence payments through that service”: the amount
payable in such a case is “£65 minus the amount of subsistence received by the Authority”. “The
Authority” is a reference to the Secretary of State. It is common ground that the reference to “the amount
of subsistence received by the Authority” is a slip for “from the Authority”. Even as corrected, the language
is rather opaque, but it is not in dispute that the effect is to require the deduction of sums received under
the Asylum Support Regulations by victims of trafficking who had made asylum claims. Thus a victim
receiving asylum support would receive an essential living needs payment from the Home Office under
regulation 10 (2) together with a “top-up” payment from the Salvation Army (though funded by the Home
Office) under the VCC to bring the total to £65; for the period from 6 February 2018, for example, the two
payments would be respectively £37.75 and £27.25. It is necessarily implicit in that approach that a
“subsistence payment” under the VCC is intended to cover more than essential living needs: as to this, see
para. 27 below.”

19. At [27] he continued:

“I need to refer to an episode in March 2018 which casts light on the Secretary of State's obligations as
regards subsistence payments. With effect from 1 March she reduced the amounts payable to service
users in the relevant category from £65 to £37.75, on the basis that she believed that it was wrong that
they should receive more than was received by asylum-seekers for essential living needs. In R (K and AM)
_v Secretary of State for the Home Department [2018] EWHC 2951 (Admin), [2019] 4 WLR 92, (to which I_
will refer as K) Mostyn J held that that reduction was unlawful because it was based on a misunderstanding
of the concept of “subsistence” in the Directive, to which the VCC was intended to give effect. In the
context of the Directive the term “subsistence” went beyond the minimum required to stave off destitution,
i.e. essential living needs, and also covered pecuniary assistance with the recovery needs which were
peculiar to victims of trafficking; and the “top-up” in the subsistence payment reflected that element. He
also held that the reduction was discriminatory by reference to article 14 of the ECHR and that the


-----

Secretary of State had been in breach of her duty under section 149 of the Equality Act 2010. The
Secretary of State did not appeal against that decision, and the level of payments was restored to £65. An
order was also made for her to pay the sums not paid since the unlawful change of policy. ”

20. He noted at paragraph [31] that:
“… the financial support provided for is intended to not only meet the essential living needs of victims but
also to assist more widely with their “social, psychological, and physical recovery” (a phrase deriving from
Article 12.1 of the ECAT).”

21. At [33] Underhill LJ said that paragraphs 15.37-38 of the Statutory Guidance issued in March 2020:
“....correspond to the arrangements operated under the VCC prior to the publication of the Guidance as
regards victims of trafficking who are recipients of asylum support. Specifically, para 15.37 sets out the topup arrangement explained at para 24 above.”

22. Amendments were made to the statutory guidance with effect from 28 August 2020 as the result of a
policy review. As amended, paragraph 15.38 (previously paragraph 15.37) provided:

“The payment rates will be adjusted if the potential victim or victim of modern slavery receiving MSVCC
support is also receiving support under sections 95, 98 or section 4 of the Immigration and Asylum Act
1999 (“asylum support”). In these circumstances, the individual is receiving asylum support because they
have been assessed as destitute or an assessment is being made on whether they are destitute. In both
cases support is provided by asylum support to meet their essential living needs. Generally, support to
cover essential living needs is provided through a payment of £39.63 per week, but in some cases
essential living needs are met through in-kind assistance, or a combination of in-kind assistance and
payments. A further payment will be made from the MSVCC of £25.40 (calculated as £65 per week minus
the current essential living rate of £39.63 provided by asylum support) to assist with their social,
psychological and physical recovery from exploitation.”

23. The rates specified for those receiving outreach support in other accommodation have been
periodically adjusted, most recently on 21 February 2022, and currently provide for a payment of £ 40.85
per week.

_Asylum support_

24. Provision for subsistence support provided to asylum seekers (including, but not limited to, those who
are also Potential Victims of trafficking) is made pursuant to Part VI of the Immigration and Asylum Act
1999.

25. Section 95 provides, so far as material:

“95.— Persons for whom support may be provided.

(1) The Secretary of State may provide, or arrange for the provision of, support for—

(a) asylum-seekers, or

(b) dependants of asylum-seekers,

who appear to the Secretary of State to be destitute or to be likely to become destitute within such period
as may be prescribed.

(2) In prescribed circumstances, a person who would otherwise fall within subsection (1) is excluded.

(3) For the purposes of this section, a person is destitute if—

(a) he does not have adequate accommodation or any means of obtaining it (whether or not his other
essential living needs are met); or

(b) he has adequate accommodation or the means of obtaining it, but cannot meet his other essential
living needs.


-----

[…]

(8) The Secretary of State may by regulations provide that items or expenses of such a description as may
be prescribed are, or are not, to be treated as being an essential living need of a person for the purposes
of this Part.

(9) Support may be provided subject to conditions.”

26. By s.96, support may be provided under s.95, inter alia, by the provision of accommodation adequate
for the needs of the supported person (s.96(1)) and by the provision of what appear to the Secretary of
State to be essential living needs to a supported person.

27. Temporary support is provided for by s.98, pending determination of eligibility under s.95.

[28. These provisions are underpinned by the Asylum Support Regulations 2000 (SI 2000/704) made](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW7-99F0-TX08-H0Y1-00000-00&context=1519360)
under ss 95-98 of the 1999 Act. Regulation 10(5) reads:

“Where the Secretary of State has decided that accommodation should be provided for a person [...] by
way of asylum support, and the accommodation is provided in a form which also meets other essential
living needs (such as bed and breakfast, or half or full board), [the amount specified] in paragraph (2) shall
be treated as reduced accordingly."

29. The rate of weekly support payments made under the asylum support regime has been subject to
detailed judicial consideration. In R (SG) v SSHD [2016] EWHC 2639 (Admin); [2017] 1 WLR 4567, Flaux
J (as he then was) held at [7]-[8]:

i. Asylum support was limited to those who are destitute, defined by section 95 of the 1999 Act as those
who do not have any adequate accommodation or means of obtaining it and those who cannot meet their
essential living needs.

ii. When an asylum seeker applies for support, and a decision is made to grant such support,
accommodation is provided, at no cost to the asylum seeker, under section 96(1)(a) of the 1999 Act. Utility
bills and council tax are met by the accommodation provider. The accommodation includes basic furniture
and household equipment (cooker, fridge, washing machine, cooking utensils, crockery and cutlery).

iii. In addition, the asylum seeker receives a weekly cash payment under section 96(1)(b) of the 1999 Act
to meet essential living needs such as food and clothing for him or herself and dependants, as set by the
relevant Regulations.

iv. In addition to the accommodation support provided in kind and the weekly cash payments, asylum
seekers have free access to the NHS. They obtain free prescriptions, dental care, eye tests and glasses.
They are reimbursed reasonable costs of travel to and from hospital for scheduled appointments and
benefit from free access to libraries.

_Support for asylum seekers in full board accommodation_

30. The services to be made available by providers of asylum accommodation are set out in Schedule 2 to
the Secretary of State's Asylum Accommodation and Support Services Contract. For initial
accommodation, Clause 2.3 sets out the Secretary of State's preference for this to be provided on a full
board basis. The service requirements include, by paragraph 4.1.4, the provision of food, including
breakfast, lunch and evening meals with a choice of at least one hot and one cold selection, as well as a
vegetarian option.  Personal toiletries and feminine hygiene products must be provided. By paragraph
4.1.5 vouchers and/or cash payments are to be provided, where the contractor is not otherwise able to
meet the Service Requirements.

31. In _R (JM) v SSHD_ [2021] EWHC 2514, Farbey J considered a challenge to the level of support
received by asylum seekers accommodated in hotels as part of their overall asylum support during certain
periods of the Covid 19 pandemic.  She summarised the position prior to the pandemic at [32]-[34]. A
person would be housed in initial accommodation while supported temporarily under s.98; typically on a full
board basis in a hostel, and without the asylum seeker receiving a cash payment for their essential living


-----

needs. Once the asylum seeker has been found eligible for support under s.95, longer-term
accommodation from the stock of “dispersal accommodation” was sourced by the Home Office's
accommodation providers. Such dispersal accommodation was generally self-catering in flats and houses,
and essential living needs met in cash through the operation of an electronic “Aspen card”. Pre-pandemic,
an individual could typically be expected to live in initial accommodation for only a short time. Even before
the pandemic, some individuals remained in initial accommodation for longer periods, typically because
they had complex needs, and some such individuals received support to cover their other “essential living
needs” in the form of in-kind provision, cash or vouchers, or a mixture of both.

32. The Secretary of State's long-standing policy was that the provision of essential living needs at hotels
and initial accommodation centres was the responsibility of the accommodation provider. It was only if the
provider was unable to meet those needs directly that they should do so by an additional cash or voucher
allowance.

33. The factual matrix changed following the decision, taken on 27 March 2020, that in view of the
pandemic, the requirement for asylum seekers to leave s.95 accommodation would be suspended for 3
months. In consequence, the Secretary of State was left to source additional accommodation for asylum
seekers coming into the support system on an urgent and ever-increasing basis. This was achieved,
largely, by accommodating those entrants in hotels.

_The Frequently Asked Questions document_

34. The Secretary of State periodically issues guidance to the Salvation Army and subcontractors on the
interpretation of the Policy. A 'Frequently Asked Questions' document entitled “FAQs about subsistence”
was first sent by the Head of the Victim Care Contract at the Home Office to the Salvation Army on 29
January 2020 “to be cascaded to support providers in order to address common questions”, and again on 6
April 2020. Question 2 and the answer to it are relevant:

“2. Subsistence for catered accommodation clients:

a) Are we correct in understanding that Catered Accommodation clients are entitled to and should get £35
pw regardless of benefits or income from work etc.?

Yes – unless they are receiving support from the asylum support system, in which case their financial
support should be £65 pw minus the NASS payment.”

35. Thus it appears that at the time the March 2020 guidance document was issued the Head of the Victim
Care Contract at the Home Office understood paragraph 15.37 to apply to all asylum seekers in receipt of
cash asylum support, regardless of whether they were accommodated in full-board or self-catered
accommodation.

_The decision below_

36. The Claimant applied for judicial review of the Home Secretary's failure to pay him £65 per week in
respect of the period from 31 March – 28 August 2020. Permission was granted by Lane J on 14 October
2020. The substantive hearing came before Peter Marquand sitting as a Deputy Judge of the High Court.
In the discussion section of his judgment he said:
“25. The Claimant's submissions may be shortly summarised as: an objective reading of the MSAG entitles
the Claimant to a total cash payment of £65 per week, less the cash payment received as asylum support.
The Defendant's submissions, which I have necessarily summarised, are that the MSAG needs to be
interpreted in context and with a purposive approach. In case of ambiguity, it is necessary to step back and
look at the matter in context. Raissi needs to be applied carefully to determine the objective intent of the
policy, including looking at all of the MSAG. There is no express provision covering in-kind assistance or
how it is to be dealt with. Paragraph 15.37 of the MSAG is directed towards mere financial support and not
in-kind support or a mixture of both. The clear intent of the policy was that for someone like the Claimant
the sum paid would be £35 per week. The rule of equality is relevant in treating people in similar
circumstances equally.


-----

26. It is clear from the evidence that before the pandemic a person claiming asylum and accommodated
under section 98 IAA would generally be placed in full board accommodation and not provided with any
additional financial assistance. After that temporary placement, if a section 95 IAA decision was made in
the person's favour, then they would be moved to "dispersal accommodation", which was generally selfcatered. They would receive the payment referred to in Regulation 10(2), which is referred to in the various
pieces of evidence as £39.60 or £39.63.

27. The pandemic altered what generally happened because of a lack of self-catered accommodation.
Therefore, increasing numbers of people seeking asylum and in receipt of a positive section 95 IAA
decision remained in full board accommodation. As Mrs Justice Farbey concluded in _JM, and as I_
understand the Defendant accepted, a person receiving support under section 95 IAA is entitled to a cash
weekly payment for their essential living needs where those have not been met by the "in kind" provision of
the full board accommodation. As is accepted, the Claimant in this case should have received such a
weekly cash sum from the date of his section 95 IAA decision.

28. I have considered paragraph 15.37 in the context of the MSAG and from the point of view of a
reasonable and literate person's understanding of the policy. I have borne in mind that I am to read the
policy objectively from the language used and not with the strictness of construction of a statute or
statutory instrument.

29. There is no ambiguity in the policy and there is no lacuna. The policy is clear as it states that a person
who is both a Potential Victim and an asylum seeker receiving financial support under, in this case, section
95 IAA will receive a total of £65 per week. This sum is to be made up of payments from asylum support
plus a further payment from the VCC. There is no basis to interpret "financial support" as meaning "the
sum due under Regulation 10(2)". This is not the natural and ordinary meaning of that phrase. The
understanding of the person or persons who drafted the FAQ was consistent with the interpretation that I
have reached – see the answers to questions 2 and 4. It makes no difference that the Claimant did not
receive, as a matter of fact, the financial support under section 95 IAA that he was entitled to, in whole or
part, during the relevant period, not that I understand that to be an argument put forward by the Defendant.

30. The person or persons who drafted paragraph 15.37 of version 1.01 of the MSAG either intended it to
be interpreted in that way or they had in mind what generally happened. They anticipated and expected
that Potential Victims or Victims who were also asylum seekers, or failed asylum seekers, receiving
financial support under the IAA would be in self-catering accommodation. This is consistent with Ms Tann's
evidence and that of Mr Ryder as they both record what generally happened. Notwithstanding what was in
the mind of the person or persons drafting version 1.01 of the MSAG, the policy as drafted does not reflect
the "consensus" referred to in the Defendant's Part 18 response (see paragraph 20 above) or paragraph
11 of Mr Ryder's statement quoted at paragraph 21 above. The Defendant may have hoped or expected
that is what the drafting stated or should state, but it does not. There is a very good reason why a policy
should be interpreted in the way set out in _Raissi and_ _Mahad. It is so that people to whom the policy_
applies can understand the policy from the document itself. If, because of the way a document has been
drafted, it becomes clear to the Defendant that the policy is not being implemented in the way that the
Defendant intended, then the solution is to change the policy. As stated above, the Defendant did change
the policy and the Claimant accepts from the date of that change that he is not entitled to the additional
payment to make his cash weekly sum £65 in total.

31. Looking at paragraphs 15.36 and 15.37 it might be considered that £35 per week for an asylum seeker
who is also a Potential Victim and in full board accommodation would seem "fair". They look to be in a
similar situation to a Potential Victim who was in catered VCC accommodation, who received £35.
However, although that might seem fair it is not what version 1.01 of the MSAG stated at paragraph 15.37.
As the evidence that the Claimant provided demonstrated, the sums received by Potential Victims and
Victims in similar circumstances can vary considerably due to the impact of other benefits. There is no
reason to "second guess" what was stated in paragraph 15.37.

32. In SC and Matadeen the circumstances were different in that those challenging the decision of a public
authority sought to argue they had not been treated equally to others. In this case, the Defendant argued


-----

that the rule of equality supports the reading the Defendant contends for in paragraph 15.37. The rule of
equality as advanced by the Defendant is not relevant to the circumstances of this case. If the drafting of
the paragraph 15.37 was not clear or there was a lacuna it might help in interpretation. However, as I have
found, that was not the case. I do not consider the interpretation I have reached of paragraph 15.37 in the
context of the MSAG to be obviously wrong so as to justify reaching a different conclusion. The simple
position is that the practice that was followed in the Covid-19 pandemic, as set out in the Defendant's
evidence, did not match the drafting of paragraph 15.37. If paragraph 15.37 was not meant to do what it
states, then the change in circumstances was not anticipated by those who drafted it, or it was not drafted
with sufficient precision.

33. I have found for the Claimant. The Defendant's policy on financial support to potential victims of
**_modern slavery at the relevant time stated that such a person would receive a total of £65 per week, less_**
any financial support received as an asylum seeker.”

_Submissions for the Secretary of State_

37. Ms Giovannetti KC submits that the key legal principles applicable to the interpretation of a policy
document are well established:

     - **_Firstly, the Court is not conducting a_** _Wednesbury review of the Defendant's interpretation: it is_
determining, for itself, the correct interpretation of the policy (see, e.g. R (Raissi) v SSHD [2008] QB 836);

     - Secondly, as with statutory interpretation, the starting point is to consider the language used. However,
the words used are to be construed in the context of the relevant background, including consideration of
the document as a whole (Odelola v Secretary of State for the Home Department [2009] 1 WLR 1230,
1233 (per Lord Hoffmann [4], applied in Mahad v ECO [2009] UKSC 16, and more recently see the Court
of Appeal in SSHD v Khattak _[2021] EWCA Civ 1873);_

     - Thirdly, a policy is “not to be construed with all the strictness applicable to the construction of a statute
or a statutory instrument” (per Lord Brown in Mahad).

     - Fourthly, just as the aim of statutory interpretation is to discern the intention of Parliament, in interpreting
a policy, the aim of the exercise is to discern the intention of the person or body promulgating that policy
(Re McFarland _[2004] UKHL 17, [2014] 1 WLR 1289);_

38. In R (Raissi) v SSHD [2008] QB 836, the Court was interpreting a compensation scheme. Hooper LJ
considered that ascertaining the intention of the policy maker involved consideration of the following
questions:

“What does the scheme mean? What was its purpose and scope? Who was the minister intending to
compensate?”

39. It was, he considered, “quite wrong” to approach “in a legalistic manner” the construction of the Home
Secretary's statement concerning the compensation of those who had spent a period in custody resulting
from a serious default on the part of a police officer or of some other public authority.

40. Even in the context of statutory construction, it has, moreover, long been established that the role of
the courts is not confined to resolving ambiguities in statutory language, but extends to correcting obvious
drafting errors: Inco Europe Ltd v First Choice Distribution [2000] 1 W.L.R. 586 and see also, closer to the
present context, the approach of Mostyn J to the table in the MSVCC set out above.

41. The effect of the decision below is that between March and August 2020 a group of people such as
[JB, a Potential Victim who was provided with full-board accommodation under the Immigration and Asylum](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y18P-00000-00&context=1519360)
_[Act 1999,was entitled to almost twice as much by way of financial support as a Potential Victim whose full-](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y18P-00000-00&context=1519360)_
board accommodation was provided under the Modern Slavery Victim Care Contract.

42. Ms Giovannetti submitted that on a correct interpretation of the March 2020 MSAG, the level of
financial payments was intended to turn upon the nature of the accommodation provided (i.e. whether it
was self-catering or full-board), not on the regime under which it is provided (whether it was provided under
the 1999 Act or the MSVCC)


-----

43. She argued that in construing paragraphs 15.36 and 15.37 of the MSAG, as it stood prior to 28 August
2020, the judge erred in law, since “neither paragraph provides in terms for the payment of £65 per week
by way of financial support to individuals whose essential living needs are met in fully catered
accommodation provided pursuant to s.95 IAA”. The submission, accepted by the judge, that the rate
payable to Potential Victims in _catered_ accommodation can be derived from “the plain words” of the
guidance, is mistaken. The guidance does not provide in terms as to how such in-kind assistance is to be
accounted for. Nor can the guidance within the MSVCC Table and paragraphs 15.36 and 15.37 sensibly
be construed without regard to the context and policy, or to the intention of the Secretary of State, which
can be assumed to include making fair and equitable provision for the different cohorts affected.  No good
reason has been identified for the difference in treatment created by the judge's construction. It effectively
doubles the support provided to Potential Victims in initial, fully catered, accommodation provided under
the 1999 Act.

44. The context of the policy considered by the judge was an unusual one: at the time the Secretary of
State issued the MSAG the drafter of the Guidance “would plainly have believed” that those such as JB,
who were in fully catered asylum support accommodation, fell outside the terms of paragraph 15.37. The
class of persons, such as JB, who were residing in fully catered asylum support accommodation were not
“receiving financial support” under the IA 1999 at the relevant time.

45. Accordingly, neither the MSVCC nor the MSAG addresses payments to be made to the cohort of
Potential Victims in _full board asylum accommodation. Likewise, neither makes express reference to the_
treatment of in-kind subsistence received for the purposes of the calculation of the financial payment made
under the MSVCC.  The practice, pre-pandemic, of moving those assessed as eligible for s 95 asylum
support to self-catered accommodation within a short time frame, is consistent with this framework. The
practice at the time was summarised by Mostyn J in K&AM (supra) at paragraph 14:

“What is absolutely clear is that for the second and third classes, that is victims of trafficking who are in
self-catered accommodation, the cash payment is £65, albeit in the third class the victim must give credit
for any money received by him or her under section 95 of the Asylum and Immigration Act 1999 and the
[Asylum Support Regulations 2000 (SI 2000/704). Under those Regulations the weekly subsistence](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW7-99F0-TX08-H0Y1-00000-00&context=1519360)
payment for asylum-seekers is £37.75. Thus, under the plain terms of the contract a victim in the thirdclass gets a top-up of £27.25 to achieve the headline figure of £65.”

46. In the present case, as in _K&AM, the rate of payment stipulated for those in fully catered_
accommodation provided under the MSVCC is a key part of the relevant context and informs the intended
level of support for others in fully catered accommodation.

47. Accommodation under both the MSVCC and the IA 1999 is made available on the basis of an
assessment of urgent need/destitution, leaving the individual reliant upon “in kind” or financial support
subsistence support to meet their essential needs. It cannot sensibly be inferred that policy maker
intended that one cohort should receive almost double the level of financial support provided to the other.
But that is the result of the judge's interpretation.

48. The submission, accepted by the judge, that the MSAG “clearly and unequivocally” provided for what
is, essentially, a duplicate payment in respect of essential living needs whilst individuals remained in initial,
full board, accommodation is mistaken. The MSAG simply made no express provision for those in catered
accommodation provided under s.95 IAA.

49. In ascertaining the intention of the Secretary of State, as promulgator of the policy, the following
factors are of material assistance:

i) Paragraph 15.37 catered for a specific scenario then anticipated to occur in practice: the placement of a
Potential Victim who has made an asylum claim in self-catered asylum accommodation. Essential living
needs are met, following dispersal to self-catered accommodation, by the payment of “financial support”.
The overall entitlement is capped at £65.00;

ii) The figure precisely matches that envisaged to be provided to Potential Victims placed in self-catered
accommodation provided by the Contractor of £65 00 per week (paragraph 15 36)


-----

iii) In stipulating that Potential Victims in self-catered asylum accommodation receive a sum equivalent to
those in self-catered MSVCC accommodation, the MSAG achieves a rational outcome.

iv) The practice of providers at the time (as illustrated by JB's receipt of £35, rather than £65 per week)
does not support the Respondent's construction of the policy. Rather, this practice (and the absence of a
challenge to it pre-cessation) provides an insight into the mutual understanding of the parties to the VCC of
the terms of the contract. It further undermines any submission that the reading of the VCC/the Guidance
is “unequivocal”.

50. For completeness, the judge's reliance upon standard responses to questions 1-3 given within an FAQ
document sent to the Salvation Army by the Secretary of State's Head of Victim Care Contract was
similarly mistaken. The document confirmed that account should not be taken of extraneous benefits and
_income from work when calculating VCC recovery payments for those in catered MSVCC accommodation._
The inclusion, within each answer, of the phrase “unless they are receiving support from the asylum
support system, in which case their financial support should be £65pw minus the NASS payment” is, in
context, the consequence of an obvious mistake. This is apparent most clearly from the response to
question 2: “Subsistence for catered accommodation clients” (i.e. those in VCC accommodation): by the
terms of the VCC, this cohort is unambiguously accorded a VCC subsistence payment of £35.00, rather
than £65.00.

51. The correct approach is to “interpret the document in accordance with the presumed intent of the
maker” (see Re McFarland and Raissi, supra, at §121). In that regard:

a) the MSAG expressly addressed the position of Potential Victims placed in self-catered accommodation
only; and

b) it is inherently unlikely that the Secretary of State intended to provide those in fully catered asylum
support accommodation with substantially higher payments (almost double) as compared to those in fully
catered MSVCC accommodation.

52. Insofar as the plain words of the policy did not give effect to the intention of the promulgator, it is open
to the Court to read in words, following the approach in Inco Europe Ltd v First Choice Distribution [2000] 1
W.L.R. 586.

53. The judge acknowledged that the Secretary of State's interpretation, by which Potential Victims in fullboard accommodation all receive the same amount, irrespective of the route by which that accommodation
is provided, “might seem fair”. His response was not that on closer examination it was not fair. Rather, it
was that “There is no reason to "second guess" what was stated in paragraph 15.37 [of the MSAG]”. But
that is predicated upon the MSAG clearly providing that those in accommodation under the 1999 Act
should receive payments at a higher level than those in accommodation provided under the MSVCC. As
explained above – it did not.

54. Rather, the intention of the promulgator of the policy stands to be interpreted by reference to the
factual background against which it was drafted, namely the Home Office's practice, pre-pandemic, in
respect of asylum support, by which:

i) emergency full board accommodation without the provision of additional financial support was provided
on an initial short-term basis only and;

ii) those whose claims for s.95 support had been accepted were swiftly moved on to self-catered
accommodation at which point financial support was provided.

_Submissions for the Respondent JB_

55. The Secretary of State's sole ground of appeal is that the judge “erred in law by interpreting the words
of the policy without due regard for the policy's purpose and context”. In her skeleton argument, the
Secretary of State also contends that the judge erred by not having regard to the “assumed… intention”
and “belief” of the Secretary of State at the time of issuing the policy. These contentions are wrong.


-----

56. First, the Secretary of State's reliance on _Re McFarland [2004] 1 WLR 1289(which was not a point_
taken before the judge at the substantive hearing) is misplaced. The Secretary of State relies on the
judgment of Lord Bingham to claim that a policy must be interpreted according to the “presumed intent of
the maker” and that “it is inherently unlikely” that the Secretary of State intended to provide victims in
catered asylum accommodation with higher payments than those in catered trafficking accommodation.
This is a misinterpretation of Re McFarland:

i) In that case the House of Lords was construing the meaning of a ministerial statement made in 1985:
the Home Secretary had announced, by way of a written answer to Parliament, an _ex gratia scheme for_
payment of compensation to persons whose criminal convictions had been quashed on appeal. The Home
Secretary had stated that he was “prepared to pay compensation” to persons who had spent time in
custody having been wrongfully convicted “where I am satisfied that it has resulted from serious default on
the part of a member of a police force or of some other public authority” (§8). Lord Bingham considered
that “magistrates would not in 1985 have been regarded as members of public authorities”, and thus that
the Home Secretary's reference in 1985 to “public authority” did not include magistrates (§15).

ii) Lord Bingham was clearly applying an objective interpretation of the term “public authority”, based on
the general understanding of the term at the time of the Home Secretary's statement. He was not
suggesting that the policy should be construed according to the Home Secretary's subjective intention.
Lord Scott, at §39, agreed that a magistrate would “not normally be regarded as a… public authority”.

iii) In any event, it is Lord Steyn's dicta in _Re McFarland, that “policy statements must be interpreted_
objectively in accordance with the language employed by the minister” and “the court does not defer to the
minister” but undertakes an “interpretative process… which must necessarily be approached objectively
and without speculation about what a particular minister may have in mind” which have been followed by
the Courts and accepted to be “good law” (see _R (Bloomsbury Institute Ltd) v Office for Students_ _[[2020]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60KG-4XX3-GXFD-81CP-00000-00&context=1519360)_
_[EWCA Civ 1074 §56), and which is consistent with subsequent Supreme Court authority such as Mahad v](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60KG-4XX3-GXFD-81CP-00000-00&context=1519360)_
_ECO and Tesco Stores v Dundee)._

57. Thus, in the present case, the question is not whether it is “inherently unlikely” that the Secretary of
State intended to provide victims housed in catered asylum accommodation with trafficking support at a
rate of £65/week minus their asylum cash support, when she made different provision for victims housed in
catered trafficking accommodation. The Court should not “read in words… [to] give effect to the intention of
the promulgator” as suggested in the Secretary of State's skeleton. It is irrelevant that the Secretary of
State, at the time of issuing the Policy, if she had thought about it, “would plainly have believed those such
as JB, who were in fully catered asylum support accommodation, fell outside the terms of §15.37”. Rather
the question is: what would an objective reader have understood the words of paragraph 15.37 to have
meant when the Policy was promulgated on 24 March 2020?

58. It appears that the Secretary of State no longer pursues the argument advanced in the High Court that
the words “financial support under section 95” in paragraph 15.37 should be construed as meaning “those
in receipt of the payment set out at Regulation 10(2)” of the 2000 Regulations. Such an argument is
hopeless; as the judge correctly found, since “[t]his is not the natural and ordinary meaning of that phrase”

[Judgment §29].

59. Instead, the Secretary of State now contends in her skeleton argument that persons “such as JB, who
were residing in fully catered asylum support accommodation were not 'receiving financial support' under
the IA 1999 at the relevant time”, and thus paragraph 15.37 should not be interpreted as applying to them.
This is wrong as a matter of fact and of construction:

i) The provision of full-board asylum accommodation was not a new concept introduced during the
pandemic – the statutory scheme has expressly provided for full-board asylum accommodation since 2000,
and for a cash payment to be made where necessary to ensure that all of a person's essential living needs
(including travel and communication costs) were met: see reg. 10(5) of the 2000 Regulations.

ii) The Secretary of State's own evidence was that, even prior to the pandemic, some asylum seekers who
were housed in full-board accommodation under the IAA received cash support: “For as long as the person


-----

remains in initial accommodation, support… is provided… in the form of full board in-kind provision, cash or
vouchers, or a mixture of both” (witness statement of Mr Bentley, §8-9). This included asylum seekers
supported under section 95 who remained in full-board accommodation awaiting dispersal to self-catered
accommodation (Bentley §10).

iii) Asylum seekers housed in full-board asylum accommodation pursuant to section 95 should have
received financial support under section 95 (and JB became entitled to this on 31 March 2020 when his
entitlement to section 95 support was recognised). As the judge correctly held, “It makes no difference that
the Claimant did not receive, as a matter of fact, the financial support under section 95 IAA that he was
entitled to, in whole or in part, during the relevant period, not that I understand that to be an argument put
forward by the Defendant” [Judgment §29].

iv) Thus, a “temporal” interpretation of paragraph 15.37, construing the words “financial support under
section 95” objectively, in light of the position at the time the Policy was promulgated, would result in the
same conclusion: that paragraph 15.37 applied to those in full-board asylum accommodation provided
under section 95 IAA.

60. Second, there is no basis upon which to read words into the policy, as the Secretary of State now
suggests (but did not argue below). The Secretary of State's reliance on the Court's power to correct
“obvious drafting errors” is misplaced:

i) The power described in _Inco Europe v First Choice Distribution [2000] 1 WLR 586applies to statutory_
construction, not to the interpretation of administrative policy.

ii) In any event, the three tests set out by Lord Nicholls in Inco Europe at 592F-G, which must be satisfied
before a court will add or remove words from a statute to correct a drafting error, are not met: “the court
must be abundantly sure of three matters: (1) the intended purpose of the statute or provision in question;
(2) that by inadvertence the draftsman and Parliament failed to give effect to that purpose in the provision
in question; and (3) the substance of the provision Parliament would have made… had the error in the Bill
been noticed”. Here, there was no contemporaneous evidence to enable the Court to be “abundantly sure”
that the Secretary of State did not intend victims of trafficking who received a mixture of cash asylum
support and in-kind support to fall within paragraph 15.37 of the Policy; on the contrary, the
contemporaneous FAQ document suggests the opposite.

iii) Even where those tests are met, there are limits to the Court's ability to read-in: “the insertion must not
be too big, or too much at variance with the language used by the legislature” (per Lord Nicholls in _Inco_
_Europe_ at 592H). In the present case, the insertion that would be required is significant: it requires the
Court to (i) remove the reference to section 95 IAA, and (ii) read in references to an entirely different
statutory provision: regulation 10(2) of the 2000 Regulations.

iv) The variation of the language required to give effect to the Secretary of State's proposed interpretation
of paragraph 15.37 of the Policy in the present case could not be further from the simple clarification made
by Mostyn J in _K & AM at paragraph 13. Mostyn J replaced “subsistence received by the authority” with_
“subsistence received from the authority”, where (i) it was objectively obvious that there was a grammatical
error because it was the authority who provided the money to the service user and not the other way
around; (ii) both parties agreed that this was what was intended.

61. Third, the Secretary of State's general contention that the judge “erred in law by interpreting the words
of the policy without due regard for the policy's purpose and context” is unsustainable. The judge plainly
had regard to the language of paragraph 15.37 of the Policy within the context and purpose of the Policy
as a whole [Judgment §25]. He took into account the situation of (non-asylum seeking) victims in catered
trafficking accommodation, who received £35 per week. But he also had regard to the fact that the sums
received by victims in similar circumstances can vary considerably due to the impact of other benefits

[Judgment §31]. Having taken full account of the relevant context, and correctly applied the principles
applicable to the interpretation of administrative policy, there is no error of law in the judge's conclusion that
the disparities in the level of trafficking support provided to victims of trafficking relied on by the Secretary
of State did not provide a “reason to 'second guess' what was stated in paragraph 15.37” [Judgment §31].


-----

62. JB does not dispute that the proper construction of paragraph 15.37 of version 1.01 of the Policy left
victims of trafficking housed in catered asylum accommodation better off than victims housed in selfcatered asylum accommodation. It might be thought that it was sensible for the Secretary of State to
equalise their treatment on 28 August 2020, in version 1.02 of the Policy. However, it is a feature of the
Secretary of State's Policy (which is not based on financial need, and does not take account of any sources
of income save for asylum support) that certain groups do better than others. An example is that victims
housed in self-catered trafficking accommodation who are in receipt of mainstream benefits of £94.15 per
week receive a further £65 per week in trafficking support, whereas victims accommodated by a charity or
a friend, who do not receive any state benefits or other financial support, receive just £39.60 per week in
trafficking support.

63. It is not the Court's task to assess the merits of version 1.01 of the Policy, or to redraft the policy in an
attempt to improve it. Constitutionally, that is the Secretary of State's function. As set out above, the
Court's task is to construe the Policy, according to its natural and ordinary meaning. This is what the judge
did, and there is no error of law in his judgment.

_Discussion_

64. In my view the judge was right for the reasons he gave. Paragraph 15.36 of the March 2020 Guidance
does draw a distinction between catered and self-catered VCC accommodation and, if the matter ended
there, the Claimant would not have been entitled to payments of £65 per week. But the matter did not end
there, because of the inclusion in the document of paragraph 15.37. This states in categorical terms that if
a potential victim of trafficking is also an asylum seeker and receiving asylum support, a further payment is
to be made to him to make a total (including the asylum support) of £65 per week. Nothing is said about
any offset for the value of meals provided in catered accommodation; nor is any distinction made between
claimants who are in catered accommodation and those who are in self-catered accommodation. It would
not have been difficult to draft a paragraph making such a distinction, and an amended scheme was
introduced five months later.

65. It seems to me a reasonable inference that the reason why paragraph 15.37 in the March 2020 version
reads as it does is because (as noted by Farbey J in the _JM case) the practice before the onset of the_
pandemic was that people in JB's position would typically spend only a short time (we were told 4-6 weeks
was a common period) in catered accommodation before being moved on. Although the document was
issued on 24 March 2020, it had been drafted before the onset of the pandemic and the beginning of the
series of lockdowns which we all remember. But that is not a reason to change the plain and obvious
meaning of paragraph 15.37.

66. I do not consider that there is any merit in the Secretary of State's argument that since JB was not in
fact “receiving financial support” (in the sense of cash payments) under the 1999 Act for a period beginning
on 24 March 2020 that placed him outside paragraph 15.37. I accept the submissions of Mr Buttler that,
firstly, most asylum seekers, even if housed in full board initial accommodation, had been receiving some
cash support as well; and that JB should have been, as was subsequently recognised. It would have
created a very curious anomaly if someone receiving very modest cash payments towards essential living
needs was entitled to be “topped up” to £65 per week, whereas someone receiving no such payments was
not.

67. It is well established that in construing a policy document a court should not subject the wording to the
kind of fine analysis which might be applied to a statute or a contract: see Tesco Stores Ltd v Dundee City
_Council [2012] PTSR 983 per Lord Reed. But the document must still be interpreted objectively. As Lord_
Steyn said in _Re McFarland_ [2004] 2004] 1 WLR 1289 at [24], although such documents need not be
construed as though they were legislation, and it "seems sensible that a broad and wholly untechnical
approach should prevail", nevertheless:
"…what is involved is still an interpretative process conducted by a court, which must necessarily be
approached objectively and without speculation about what a particular minister may have had in mind."


-----

68. The principle set out in cases such as Raissi and Mahad is that documents of this kind should mean
what they say, and should be interpreted as they would be read by a reasonable claimant or support
worker or advisor. Some of Ms Giovannetti's arguments, though expressed with her usual persuasiveness,
seemed to me to come close to asking us to interpret the document in accordance with what the drafter
would have written if he or she had thought about it more carefully, or even if he or she had been able to
foresee the appalling problems which the pandemic would bring.

69. I am entirely unable to accept the argument that paragraph 15.37 contained an obvious error within the
terms of Inco Europe Ltd vs First Choice Distribution [2000] 1 WLR 586. In the well-known passage in the
speech of Lord Nicholls of Birkenhead at [592] he said:
“The court must be able to correct obvious drafting errors. In suitable cases, in discharging its interpretative
function the court will add words or omit words or substitute words.”

70. He continued at [592E]:

“This power is confined to plain cases of drafting mistakes. The courts are ever mindful that their
constitutional role in this field is interpretative. They must abstain from any course which might have the
appearance of judicial legislation. A statute is expressed in language approved and enacted by the
legislature. So the courts exercise considerable caution before adding or omitting or substituting words.
Before interpreting a statute in this way the court must be abundantly sure of three matters: (1) the
intended purpose of the statute or provision in question; (2) that by inadvertence the draftsman and
Parliament failed to give effect to that purpose in the provision in question; and (3) the substance of the
provision Parliament would have made, although not necessarily the precise words Parliament would have
used, had the error in the Bill been noticed. The third of these conditions is of crucial importance.
Otherwise any attempt to determine the meaning of the enactment would cross the boundary between
construction and legislation”

71. In the present case it is not obvious what the substance of para 15.37 would have been if the drafter
had not made what Ms Giovannetti submits is an obvious error. Moreover, it is far from obvious that the
drafter did not intend a claimant in JB's position to receive a top-up to bring his total payments to £65 per
week. The construction of para 15.37 which the judge found to be correct is consistent with the terms of the
Victim Care Contract between the Home Office and the Salvation Army; and also with the answer given to
question 2 in the FAQs document first issued by the Home Office in January 2020 and re-issued soon after
the promulgation of the guidance on 6 April 2020. It is impossibly ambitious for the Secretary of State to
contend that there was an obvious mistake of the _Inco type in all three documents. As Mr Buttler put it,_
pithily and correctly, a flaw in the design of a policy is not the same as a drafting error.

72. In _MD this court was concerned with alleged discrimination arising out of a much more striking_
anomaly than the one in the present case. A particular group of claimants were receiving two cash
payments in respect of the same needs. It was not suggested by anyone in that case that that anomaly
could be ignored or the relevant regulations rewritten. As Underhill LJ said at [67] “making rules in these
complex interlocking areas, particularly where different departments are involved, must be far from
straightforward”.

73. The lawfulness of the amendment to the guidance made in August 2020 is not in issue before us; and
Mr Buttler did not seek on behalf of JB to challenge it or to argue that his client should have received £65
per week after the date of the amendment. I will only say that as at present advised I can see no reason
why the Secretary of State should have been precluded from making the amendment which she did.

74. For these reasons I would dismiss the appeal.

**Lord Justice Peter Jackson**

75. I agree.

**Lord Justice Baker**

76 I also agree


-----

**End of Document**


-----

