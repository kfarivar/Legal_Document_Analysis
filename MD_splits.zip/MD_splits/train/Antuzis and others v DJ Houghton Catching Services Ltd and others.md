# Antuzis and others v DJ Houghton Catching Services Ltd and others [2021]
 EWHC 971 (QB)

Queen's Bench Division

Griffiths J

23 April 2021Judgment

**Harry Lambert (instructed by Leigh Day) for the Claimants**

**The Second and Third Defendants in person**

The First and Fourth Defendants not present or represented

Hearing dates: 23-26 March, 30 March 2021;

further written representations received down to and including 16 April 2021

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**THE HON. MR JUSTICE GRIFFITHS :**

1. Following a judgment of Lane J on liability, this is my judgment after a trial to determine the Claimants'
quantum of damages against the First, Second and Third Defendants (“the Quantum Trial”). The First and
Fourth Defendants were not involved in this trial. The First Defendant was not separately represented but
the Second and Third Defendants represented themselves and gave evidence, and spoke for the position
of the First Defendant, which was their company.

**BACKGROUND**

2. The Claimants are Lithuanians who came to this country and worked for the First Defendant (“the
Company”) as chicken catchers on chicken farms. The farms contracted with the Company to provide this
service.

3. The background to the Quantum Trial is set out in detail in the reserved judgment of Lane J on liability

_[2019] EWHC 843 (QB) (“the Lane Judgment”). This also sets out the relevant law._

4. In brief, the Lane Judgment decided that the Second Defendant (“Mr Houghton”) and his partner the
Third Defendant (“Ms Judge”) are jointly and severally liable to all the Claimants for inducing breaches of
contract by their employers, the Company. I will refer to Mr Houghton and Ms Judge jointly as “the
Defendants”, since they were the defendants actively participating in the trial before me.

5. The Lane Judgment established (although the Defendants do not accept most of it) that these breaches
of contract consisted of failures to pay the Claimants the minimum wage they were entitled to by law. The
law in question is thoroughly and clearly set out in paras 10-27 of the Lane Judgment. The facts (and the
considerable body of evidence supporting Lane J's findings of fact) are also set out in the Lane Judgment. I
will not repeat them because it is better that the Lane Judgment itself is referred to.


-----

6. The findings of the Lane Judgment are binding on me, to the extent that they are Lane J's determination
of matters in issue between the parties to the proceedings before me.

**Procedural history**

7. After the Lane Judgment on 8 April 2019, Lane J made the following Order:

“1. Judgment is hereby entered against the First Defendant and in favour of the Claimants in respect of the
following issues:

(a) The First Defendant's failure to pay the Claimants for their work (including travel, overtime and “on call”
time) in accordance with the terms of the _[Agricultural Wages Act 1948 and relevant Agricultural Wages](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y0DP-00000-00&context=1519360)_
Orders and the First Defendant's contractual obligations;

(b) The deductions from the wages of the Claimants by the First Defendant of work-finding fees in breach
of the relevant Agricultural Wages Orders, in breach of contract, and in breach of Condition 7 of the
Gangmasters (Licensing Conditions) Rules 2009 (Prohibition on Charging Fees) or the 2006 equivalent;

(c) The deductions from the wages of the Claimants by the First Defendant of charges for accommodation
[in in excess of that permitted under the terms of the Agricultural Wages Act 1948 and relevant Agricultural](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y0DP-00000-00&context=1519360)
Wages Orders and in breach of contract;

(d) The withholding or non-payment of wages of the Claimants by the First Defendant in breach of
Condition 13 of the Gangmasters (Licensing Conditions) Rules 2009 (Prohibition on Withholding Payment
to Workers) or the 2006 equivalent, the _[Agricultural Wages Act 1948 and relevant Agricultural Wages](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y0DP-00000-00&context=1519360)_
Orders and in breach of contract;

(e) The non-payment or withholding of holiday pay required by the terms of the _[Agricultural Wages Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y0DP-00000-00&context=1519360)_
_[1948 and relevant Agricultural Wages Orders and by contract.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y0DP-00000-00&context=1519360)_

2. The Second and Third Defendants are (jointly and severally) personally liable to the Claimants for
inducing the First Defendant's contractual (and related statutory) breaches including but not limited to those
outlined in paragraph 1 of this Order, above.

3. The First and/or the Second and/or the Third Defendant shall pay to the Claimants damages in respect
of the breaches at paragraph 1 of this Order with quantum to be assessed…”

8. A series of orders was then made to identify and limit the issues for the Quantum Trial, as follows.

9. The Claimant was ordered to serve a Schedule of Loss “limited to the contractual … claims and
aggravated/exemplary damages” to be assessed at the Quantum Trial. It was to set out “the Claimants'
proposed methodology for calculating quantum in the contractual… claims.” The parties were then to try
and agree a methodology and, to the extent that it was not agreed, the Defendants were ordered to set out
their points of disagreement.

10. In the event, the Defendants did not challenge the Claimants' methodology before their time for doing
so expired, or at any time before the start of the trial, and the methodology in the Claimants' Schedules of
Loss is, therefore, the one I will apply. The Defendants do, however, challenge the figures, and have
served their own Counter Schedules.

11. As noted in an order of Hugh Mercer QC (sitting as a Deputy High Court Judge on 14 January 2021),
the parties agreed:

i) to divide the 11 claimants (in the three actions) into three broad categories of claim;

ii) to try three representative claims at the Quantum Trial, one from each category;

iii) to place the remaining eight claimants into one of the three categories; and

iv) to use the awards in the three representative claims “to value the remaining eight claims based on
averages or pro ratas, with any disputes as to the same to be resolved by the trial judge (whether at the


-----

trial or by way of written submissions thereafter), such that the court will make awards across all 11
claims”.

12. Hugh Mercer QC also ordered that the Defendants' Counter Schedules “must follow the same
methodology set out in the Schedules of Loss served by the Claimants”, reflecting the procedural position
already reached as a result of the earlier orders, which meant that the Claimants' methodology could no
longer be challenged by the Defendants.

13. The order of Hugh Mercer QC continued:

“This means that:

a. elements which affect the amount of losses claimed in the said Schedules of loss (e.g. number of hours
worked by each claimant per week) can reasonably be challenged subject to the findings of Mr Justice
Lane's judgment of 8 April 2019 (e.g. that chicken catchers worked “massively more than the hours
recorded on the payslips”);

b. however, the methodology to calculate the amount of losses claimed in the said Schedules of loss (e.g.
that in accordance with the Agricultural Wages Orders, the first 39 hours worked per week must be paid at
the basic rate subject to the night work supplement when applicable, and all hours worked per week after
the first 39 hours must be paid at the overtime rate), cannot be challenged.”

14. Finally, the order of Hugh Mercer QC directed that the Defendants' Counter Schedules of loss “must
follow the same headings set out in the Schedules of Loss served by the Claimants”. This they have done.

15. The parties agreed who the three representative claimants would be at the Quantum Trial.

i) Representing Category 1 (Claimants with two years' employment or more): Mr Tadas Balciauskas (“Mr
Balciauskas” or “C1”).

ii) Representing Category 2 (Claimants with between one and two years' employment): Mr Mindaugas
Stonkus (“Mr Stonkus” or “C2”).

iii) Representing Category 3 (Claimants with one year of employment or less): Mr Antanas Urnikis (“Mr
Urnikis” or “C3”).

16. They also agreed how to place the other eight Claimants into the categories:

i) In Category 1, Mr Nerijus Antuzis.

ii) In Category 2, Mr Robertas Urbonas and Mr Aurimas Markevicius.

iii) In Category 3, Mr Edmundas Mikuikevicius, Mr Vygantaqas Urbonas, Mr Airidas Kavaliauskas, Mr
Tomas Necajus and Mr Pranas Stirblys.

**THE ISSUES IN THE QUANTUM TRIAL**

A. Hours worked

17. It follows from the agreed methodology that my primary task is to assess how many hours each of the
three lead Claimants worked per week and for how many weeks. The agreed methodology means that, in
accordance with the Agricultural Wages Orders, the first 39 hours worked per week must be paid at the
basic rate subject to the night work supplement when applicable, and all hours worked per week after the
first 39 hours must be paid at the overtime rate (see para 13 above). These rates are set by law and are
not in dispute.

18. The Claimants are, by law, entitled to be paid, not only for hours when they were actually catching
chickens, but for other times. These include:

i) Hours when they were on call, i.e. “available at or near their place of work for the purpose of working
and when they [were] required to be available for such work” (see para 17 of the Lane Judgment, quoting
Article 17 of the Agricultural Wages (England and Wales) Order 2021).


-----

ii) Hours when they were travelling to and from the farms where they were required to catch chickens (see
para 18 of the Lane Judgment, again referring to Article 17).

19. The Claimants have proposed, and the Defendants have accepted, the following questions as a
reasonable way of approaching the question of the number of hours worked or for which the Claimants
were entitled to be paid.

i) On average/typically, how many “catching hours” did each Lead Claimant work per week? (not including
rest breaks). This may be informed by consideration of the following:

a) Typically, when did the working week begin and end?

b) Typically, how many shifts (i.e. each shift understood as each period between leaving and coming back
to their houses) did each Lead Claimant work per week?

c) Typically, how many chickens were loaded into each lorry?

d) Typically, how many lorries were loaded at each farm?

e) Typically, how many men worked at each farm?

f) On average (i.e. factoring in all variables) how long did it take for the above number of men to load one
lorry?

g) Whether the Lead Claimants worked at multiple farms per shift, and if so at how many farms on
average per shift?

h) Overall, on average, how many chickens did each Lead Claimant catch per week?

ii) On average, how many days did each Lead Claimant work per week?

iii) How many weeks did each Lead Claimant work for the Houghton Defendants?

iv) On average, how many “travel hours” did each Lead Claimant work per week? This has been broken
down into:

a) What was the average travel time from the Lead Claimants' houses to the farms and back to their
houses, per shift?

b) What was the average travel time between farms per shift?

20. As it turned out, neither the records nor the evidence enabled me to answer these questions with any
precision. In particular, both sides and all the witnesses agreed that the variety of circumstances meant
that it was very hard, even for those closely involved, to answer questions about an average figure for any
of these elements, as opposed to giving a picture based on a range of experience, from which an
estimated outcome might be reached on the balance of probabilities and by way of assessment of the
evidence as a whole. I will not, therefore, undertake the artificial exercise of answering every one of the
sub-questions in precise terms. I have, however, reviewed and evaluated the evidence on these and other
points in order to answer the principal questions numbered as (i), (ii) and (iii) in para 19 above.

B. Deductions

21. The next group of issues to be decided in the Quantum Trial relates to deductions made, or allegedly
made, from the wages recorded on the Claimants' payslips. The Claimants allege that there were
deductions for (1) employment fees; and/or (2) rent and/or (3) other allegedly unjustifiable (or, as the
Claimants put it, “spurious”) reasons. These issues need to be resolved before deciding what credit the
Defendants are entitled to for payments already made. The Defendants' position is that some deductions
were made, but were made entirely properly, and that the other deductions alleged by the Claimants were
not made at all.

22. The questions proposed to assist in the resolution of the deductions issues are as follows:

i) Employment Fees How many times has each Lead Claimant been charged an employment fee? In what
sum?


-----

It was not permissible to deduct employment fees from wages, and that has never been disputed: see para
25 of the Generic Particulars of Claim and paras 3 and 66 of the Lane Judgment. It is only the extent to
which such deductions were in fact made which is in issue.

ii) Deductions for Rent There is no dispute that deductions were made for rent. This was not, in itself,
necessarily unlawful. The two issues raised by the Claimants in order to dispute the rent deductions are:

a) Was it permissible to make deductions for rent at all? The Claimants argue that their accommodation
was unfit for human habitation and that deductions should be disallowed for that reason.

b) Did the deductions exceed the statutory cap on deductions for accommodation in the Agricultural
Wages Orders?

c) How much was deducted in rent per week, and for how many weeks?

iii) Other deductions For each Lead Claimant, how many times (or alternatively with what frequency) were
wages withheld altogether (i.e. payslip but no cheque)? In what sum?

C. Holiday pay and interest

23. The Claimants also claim holiday pay and interest. The Defendants have conceded these claims and
the amounts are agreed, so I do not need to consider them further. They will, however, be part of the order
consequent upon this judgment.

D. Aggravated and exemplary damages

24. Finally, the Claimants seek (a) aggravated damages and (b) exemplary damages. Both are disputed.

**THE EVIDENCE**

25. Each of the three Lead Claimants gave evidence to me and was cross examined by Mr Houghton.
They appeared to be honest, credible and reliable. Their evidence was consistent with the documents
(where comparison was possible), and with each other. It was consistent with the previous findings of Lane
J in these proceedings (in the Lane Judgment) and with the judgment of Supperstone J in a case brought
by other chicken catchers against the same Defendants: _Galdikas and others v DJ Houghton Catching_
_Services Ltd and others_ _[2016] EWHC 1376 (QB)._

26. Among the Claimant witnesses from whom Lane J heard evidence, and whom he found to be entirely
credible, were C1 (Mr Balciauskas) and C3 (Mr Urnikis) (Lane Judgment para 53), from whom I also heard
evidence.

27. Lane J also heard evidence, as I did, from both Defendants: Mr Houghton and Ms Judge. Mr Houghton
he found to be “a thoroughly unsatisfactory witness” (para 65), whose evidence was reliable only “in certain
very limited respects” (para 65). He described him as “someone who is prepared to say anything at all
which he thinks might serve his purpose” (para 70). Ms Judge, too, he described as “also a thoroughly
unsatisfactory witness” (para 76) who was “seriously evasive” (para 80). He also referred to “serious issues
regarding the honesty” of both the Defendants (para 78).

28. I have been able to form my own impression from the evidence given to me and it is consistent with
the assessment of Lane J, as I will explain in more detail in the course of this judgment.

29. In addition to the oral evidence, I was referred to a trial bundle which contained over 2,800 pages of
documents, including the following:
i) Payslips, and also records of payslips now missing, upon which some of the calculations and estimates
put to me have been based. The payslips themselves are helpfully summarised in Appendix 5 of the
Claimants' written opening.

ii) There are also some records of the numbers of chickens caught, which are of particular importance to
the submissions of both sides in the Quantum Trial. These numbers generally agreed although,
unfortunately, not at all complete.


-----

iii) There are some records of the driving times and destinations of drivers involved in ferrying the chicken
catchers from their house to the farms, and between farms.

30. The types of available documentation vary and so, although each individual category is never reliably
complete, or in some cases completely reliable, between them they allow a degree of cross-checking by
alternative approaches to analysing the data in order to inform my final estimate of the answers to the
questions in this case.

31. My answers cannot be (and do not have to be) absolutely 100% certain. They are the best answers
that can be reached on the available evidence, and they are reached on the balance of probabilities, in
accordance with the civil standard of proof.

A. Evidence on hours worked

32. It is clear to me (and it is one of the findings in the Lane Judgment) that the hours worked by the
Claimants grossly exceeded the hours recorded on their payslips, and it is also clear to me from the
evidence that not all the amounts on the payslips were actually paid.

33. Lane J found that the Defendants were operating the company “at all material times in a deliberate and
systematic manner, whereby chicken catchers were working massively more than the hours recorded on
the payslips.” (para 86 of the Lane Judgment). He found that no records were being kept; that the
accountants were, therefore, constructing the payslips as “a fictional exercise”; and that this was because it
was the Defendants' modus operandi that there should be “a flagrant disregard of the AWO requirements
as to the minimum pay” (para 86).

34. Before me, the Defendants conceded that the hours on the payslips were not based on any actual
record of hours worked. They are, I find, a completely unreliable record of those hours. They do, however,
have some value as evidence of the hours worked. This is because the payments in the payslips were
supposed to be a reflection, not of hours worked, but of the number of chickens caught; based on a rate of
£3 for every thousand brown chickens or £4 for every thousand white chickens (Lane Judgment para 59).
The number of chickens caught has a relationship with the number of hours spent catching them. These
rates were paid to each member of the catching team employed on the job. Thus, for every 1,000 brown
chickens caught by the team, £3 should have been paid to each member of the team (not divided between
them). However, even this is not completely reliable, because of the evidence that the payments made did
not always correspond to the sums on the payslips, and for other reasons I will explain.

_C1 – Tadas Balciauskas_

35. Mr Balciauskas gave evidence that he worked for the Defendants between November 2009 and
October 2012. He was brought to the UK in a van from Lithuania (for which he paid) and was told about the
precise nature of the work after the van had crossed into the UK.

36. Mr Balciauskas was taken straight to the accommodation at 57 Calder Road where he was to live with
other chicken catchers. There were three bedrooms, a double and a single, but the house was crammed
with many more than the beds could accommodate. There were “mattresses everywhere” (para 9, C1 first
statement), he himself was on a mattress in the sitting room with around six others, and the house was
“really horrible”. The total number in that house was “around 11”, including himself. This was a house
owned by Ms Judge, although others were owned by Edikas Mankevicius (“Edikas”). She collected the rent
personally, in cash (para 11).

37. After a dispute about one of the many occasions when pay was arbitrarily withheld for work done
(which I say more about below), Mr Balciauskas and others found themselves without work and excluded
from the house, so that he had to live in a tent until he was driven by hunger and destitution to return to
work for the Defendants. On his return, he was placed in a second house, at 40 Emsworth Road, which he
understood to be Edikas Mankevicius' own house. Including Mr Balciauskas himself, there were 14 people
in that house and he was one of 6 of them who had to sleep on mattresses in the sitting room (first
statement, para 62).


-----

38. The usual supervisor for his team was Vitas Mikalauskas (“Vitas”), although sometimes it was “Junjus”
and occasionally “Stasys” (para 16, C1 first statement). Vitas was a particularly hard task master. He would
hit the workers in the face “and they would be bleeding, and still have to work” (cross examination).

39. The team was not fixed: “One day there would be one group of people; another day there would be
another group of people” (cross examination).

40. Work usually started on Sunday at noon or 1 pm, and usually ended when Mr Balciauskas and the
others returned home from the last farm on Friday evening at around 8pm, 9pm or midnight (para 17, C1
first statement). At other times it might end earlier on Friday, or later, on Saturday morning. It is clear from
the evidence that the length of the working week was neither fixed nor entirely regular. During the working
week, there would be brief returns home, for perhaps an hour or so, after which he and the other catchers
would be called away to the next job. Mostly, they had to get their sleep in the minibuses.

41. “The farms were all over the country and we mostly visited two or three each trip” (para 23, C1 first
statement). Sometimes it was more than this, and the trip might then extend over several days (second
statement, para 8). The drivers were worked less hard than the drivers, so that in the course of a day or a
week, drivers might be used in relays (para 24, first statement), while the catchers ground their way
through the work of their 5 or 6 day week of working night and day. Thus, while records of driver hours and
routes are valuable evidence in a case in which few records of any sort were being kept, they are not
strictly aligned with the work of the catchers they carried and I will have to combine and assess them with
other evidence when answering the questions in the Quantum Trial.

42. The physical strength and stamina of Mr Balciuaskas, and most if not all of his colleagues, must have
been extraordinary to sustain this workrate. But even for him it took a toll. I accept the evidence (in paras
27 and 29 of his first statement) in this respect, which was not at all shaken in cross examination:

“If you told Jackie you could not go out again because you were exhausted, Jackie would just say you have
to go, or “speak to Edikas”. As I explain below, I think this was her way of stopping us from complaining as
Edikas would threaten us and say we would lose our job or wouldn't be paid that week. More than once I
personally texted her and said I was too tired or my feet were hurting or my hands. She would text back
either to tell me I had to work, or she would say speak to Edikas. We would get problems with our feet
because of the very long distances we had to walk so by the end of the week our feet were burning, and
sometimes we could hardly walk. We often had to change our footwear because the soles of our trainers
would just fall off.”

“If you complained to Edikas he would threaten you with losing your job, or being evicted or missing your
cheque that week. Edikas also made them afraid they would get no other job if they left. In this way, Edikas
put psychological pressure on us and so people would be afraid to complain. By telling us to speak to
Edikas, Jackie used Edikas to keep us under control. And then of course, as I explain below, you knew you
would not get two weeks wages owed to you if you left. When we started we were not paid for the first
week so we were always one week behind, and then we would not get the last week either.”

43. The Defendants strongly objected to the suggestion that they were involved in human trafficking, or
that that the Claimants, or any of their Lithuanian workers, were trafficked. Whether or not they were
trafficked is not an issue for the Quantum Trial, except perhaps when I come to consider the claims for
exemplary damages and aggravated damages. However, the evidence does satisfy me at least on the
balance of probabilities that they were the victims of the conduct criminalised in sections 1 – 3 of the
**_Modern Slavery Act 2015._**

44. The Defendants (who represented themselves, and are not legally qualified) highlighted what they
suggested was evidence that the Claimants were volunteers; that they were free to leave and did
eventually leave; and that (in the case, for example, of C1, Mr Balciauskas), having left, he returned to
work for them again, before leaving again. I take that evidence into account but it does not dissuade me.
Consent even from an adult does not preclude that person being a victim of **_[Modern Slavery Act 2015](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
offences (section 1(5); section 2(2)) and the Claimants were, at first, not aware of what they were getting
themselves into (section 3(5)). Subsequently, they had their freedom of choice severely constrained by


-----

their shortage of money (itself the result of the Defendants' unlawful failures to pay what they were entitled
to) and by the well-attested threats from Edikas.

45. Ms Judge actively harnessed the threat posed by Edikas by her regular use of the “Speak to Edikas”
formula in response to any complaint or query or request she did not approve of. This was very common,
and happened, for example, if arbitrary non-payment was queried, or if time-off to recover from illness was
requested. I am satisfied on the evidence that the Claimants worked as a result of force and threats
(through Edikas) and deception (about what they would be paid, and about what they were entitled to be
paid) designed to induce them to provide and continue to provide their services, notwithstanding their illtreatment by the Defendants (section 3(5) of the Modern Slavery Act 2015).

46. I am also satisfied that the Defendants arranged and facilitated the Claimants' travel within the
meaning of section 2, in that they recruited and harboured them when they were brought from Lithuania
with a view to being exploited. This is confirmed, for example, by the evidence of Mr Urnikis (C3) during
cross examination by Mr Houghton: “I spoke to someone. I paid a lot of money for travelling, and then I
was brought here… I didn't choose the bus that I was going to travel on. I was put on that bus and it
brought me straight to that house. So I think that was connected with them. With you”.

47. I am satisfied that even the houses not belonging to Ms Judge were tied to the work being done for the
Defendants by the Claimants; and to the exploitation and abuse of the Claimants by and on behalf of the
Defendants, while they were doing that work. There was no break between the trafficked journeys and the
houses; and there was a close and indissoluble link between the houses (whoever owned them) and the
work; that link being supported and maintained, in particular, by Ms Judge, whether she owned the house
in question (as she sometimes did) or worked with another landlord to operate the same system. Either
way, the system was operated by the Defendants and for the benefit of the Defendants' business.

48. Mr Houghton relied on the fact that the Defendants were never prosecuted for crimes in England, and
that convictions against them in Lithuania have been overturned on appeal. However, this is not strong
evidence in their favour, although a conviction would be evidence against them. A different standard of
proof applies in criminal proceedings to the standard of proof which applies in this trial. I am deciding the
case on evidence I have heard, and the lack of a criminal conviction or prosecution in England is neutral; it
proves nothing. There is no doubt that the Defendants lost their licence because of the Fourth Defendant's
decision, after investigation, that they were guilty of many of the wrongs which are in issue in the
proceedings before me. As to the Lithuanian case, again there is a limit to which I can be assisted by the
decision of a different court, in a different case, applying its own law. But it seems that the Defendants'
appeal in Lithuania was successful on the basis of an argument not based on the merits or on the facts, but
on a question of jurisdiction. I am told that a further appeal against their successful appeal is outstanding.
Consequently, I am not much assisted by these arguments.

49. Mr Houghton cross examined Mr Balciauskas about some photographs of him out socialising, and also
referred him to occasions when he was said to have been drunk, or drinking. I was not impressed by this
evidence. There appeared to be very few photographs, despite a period in question of years, and Mr
Balciauskas explained that he was ashamed of his working conditions (and posted two photographs in two
years in order to hide his shame, and on the rare and untypical occasions when he had photographs to
post of this nature).

50. So far as drinking was concerned, adult men are entitled to drink and to get drunk, and the
Defendants' apparent assumption that it was a point against the Claimants if they ever did so tended rather
to support the Claimants' case that they were not being treated as free adult workers with a right to spare
time. The key question is whether there was ever an occasion when drunkenness provided a justification
for docking the Claimants' pay. I am satisfied by the Claimants' evidence that they were not drunk at work,
and did not have the opportunity of getting drunk at work. If they were called to work at short notice when
they had already had a drink, their employer was not entitled to accept them for work on the one hand but
refuse then to pay them for it on the other. But my main conclusion from the evidence is that the
Defendants were clutching at straws here. The Claimants, I find, were not drunk at work, or drinking at
work, and there is nothing in this point to assist the Defendants.


-----

51. Mr Balciauskas said that Edikas Mankevicius (usually referred to as Edikas) worked with the
Defendants, and that Ms Judge used him to keep the chicken catchers “under control and deal with any
complaints we made. Edikas could threaten to evict us or decide to withhold our wages” (para 3, C1 first
statement).

52. The usual job was catching chickens and loading them into a lorry. Mr Balciauskas' evidence was that
a typical lorry load would be 6,336 brown chickens (para 9, C1 first statement). Because everyone thought
that pay was a function of the number of chickens caught (which it was, in fact, although by law it should
have been measured against hours worked), no records were kept or attention paid to the hours worked,
but the team did keep records of the number of chickens caught. At the Quantum Trial, therefore, evidence
was given in order to enable me to calculate hours and days worked from records of chickens caught,
although everyone accepted that this could only lead to an estimate.

53. Mr Balciauskas' evidence in this respect was, I find, a fair account of what was typical in his
experience (paras 10-11 of his second statement). He said that the time it would take to load a lorry with
chickens would depend both on the size of the lorry (although it was typically a lorry taking 6,336 brown
chickens, as I have mentioned) and on the size and layout of the farm:

“If I was working in a strong team and we were working as fast as we could and the chickens were in cages
it would take us between 1.5 to 2 hours to load a typical lorry. If the chickens were on the ground and
running freely around, it would take us around 1 hour to load a typical lorry. These chickens were easier to
catch as you could drive them all into the same area.

We could keep up this speed for maybe the first two lorries but then we would get tired and our work would
slow down. Then it could be between 2.5 to 3.5 hours to fill a typical lorry. One time when we were on a big
farm and there were only 5 of us working, it took us 6 hours to load one lorry. On average, I would say that
it took around 2 hours for a strong team to load a typical lorry.”

54. Mr Balciauskas was cross examined in some depth about the time taken to load different numbers of
chickens in different farm conditions, and depending on the set-up of the farm in question, when it differed
from the chickens in cages, or chickens on the ground, described in the witness statement extract I have
just quoted. He surprised even Mr Houghton (who undertook the cross examination, as a litigant in person)
by the moderation of his answers, and the degree of consensus between them about these matters.
Sometimes, Mr Balciauskas's estimates were more favourable to the Defendants than even Mr Houghton
himself proposed to suggest (i.e., he estimated shorter times for catching certain numbers of chickens in
certain conditions), and this is an important reason for finding him to be an honest and reliable witness,
despite giving evidence in his own cause. However, his evidence as a whole did not in any way undermine
or contradict the evidence I have quoted about “a typical lorry” and what time was required “on average”.

55. It seemed to me that Mr Houghton was asking about relatively unusual circumstances (including the
catching of chickens for vaccination rather than slaughter, so that they did not have to be loaded into lorries
at all), and it was also clear that Mr Balciauskas was answering from his own experience, which was of
working in a strong and experienced team, which would catch more quickly than others might (and even
his experience was “If there are new people in the team then it takes much longer”). Even Mr Balciauskas
said, however, that his team would get slower as they got tired, whereas Mr Houghton was asking always
about best-case scenarios: strong experienced men, working when they were fresh, in farms where
catching was easier than it was in the average or typical farm for one reason or another, or where the
numbers were smaller (so that slowing down because of tiredness had less of an impact). Mr Balciauskas
pointed out, at the end of his cross examination, “I was not asked about the very large farms where there
were millions of chickens”.

56. Mr Balciauskas said that, if the first lorry took one and a half hours, each subsequent lorry would take
an extra 15 or 20 minutes longer than the one before, as they got tired. He also said (in re-examination)
that the men's workrate slowed as one day succeeded another: “By the end of the second day, you are
shaking. You don't feel your hands or your feet, and the whole team is on the brink of exhaustion. The rate
is much slower.”


-----

57. Mr Balciauskas also made the point that the first chickens were easier and quicker to catch than the
last ones: “It is always quick to load the first lorry, but as you go further down the line, and the last one, we
have to catch all the remaining chickens: it can take even up to 3 or 4 hours” (cross examination).

58. There was an important disagreement between Mr Balciauskas and Mr Houghton about the number of
men on the catching team. Mr Balciauskas was adamant that the team would never exceed 11 (all
squeezed into one minibus), and was often 8 (the number of seats in the minibus), whereas Mr Houghton
(supported by Ms Judge and Ms Houghton-Judge) suggested that there would usually be two minibuses
and more than 11 men: perhaps 13 or 16. Since every team member was (in practice) remunerated by
reference to the number of chickens caught by the whole team, and not just to the chickens he personally
caught, a larger team would reduce the hours required to catch the chickens and secure the payment.
However, the Claimants were more credible and consistent witnesses than the Defendants, and their
evidence, in contrast to the Defendants', was never undermined by documents. In line with my assessment
of the witnesses (which coincides with the assessment in the Lane Judgment) I prefer the Claimants'
evidence. Consequently, I accept the smaller team numbers they testified to, of between 8 and 11 men. If
there was ever an occasion or occasions when there were more than 11, it will have been rare enough to
be counterbalanced (on average, and for example) by two occasions recalled by Mr Balciauskas (which I
accept) when there were only 6 men, although they had two or three lorries to fill at each farm.

59. Because of the nature of the work and the working pattern, the chicken catchers were entitled to be
paid even when they were waiting to start the chicken catching, or waiting to be driven away after finishing
it (see para 18 above). This means that there are hours which cannot be measured from the number of
chickens caught, because during those hours no chickens were caught. The time involved could be
significant, as appears from the evidence, which I accept, in paras 12 and 14 of Mr Balciauskas' second
statement:

“It was also quite common to come to a farm and wait 3 or 4 hours for the first lorry to arrive. I remember
the longest time we waited was 8 hours when we were told the lorry was stuck in traffic somewhere.
Sometimes I tried to sleep in the chicken barns when I was waiting for the lorry to arrive. After we had
loaded a lorry we would also sometimes be waiting for the next one to arrive and drive up. This was
normally around 5 to 10 minutes, just long enough to have a cigarette while the lorries changed over. This
was what happened if the lorries were there. But quite frequently the lorry would be late to arrive and then
we could be waiting an hour or two or more. And as I said before, sometimes we could be waiting for 3-4
hours for the first lorry to arrive.”

“The time we spent travelling to the farms also varied. There was one farm that we called Friday Farm,
which was close by and would take 30 minutes to get to. Sometimes Darrell or Jackie would take us there
because it was nearby. The longest journey was maybe 9 or 10 hours one way. I think this was somewhere
in Scotland, or around this area. Normally, the journey was between 2 and 4 hours.”

60. Mr Balciauskas was cross examined about journey times but here too it seemed to me that the
Defendants' questions were directed to unusual circumstances rather than building a picture of the
average. For example, Mr Balciauskas confirmed in cross examination that travel to Friday Farms took
“about 30 or 35 minutes, maybe a little longer”; but the driving records confirm his evidence that much
longer journeys were made to farms throughout the country.

61. Mr Houghton challenged Mr Balciauskas' reference in the evidence I have quoted to a farm
“somewhere in Scotland, or around this area” but this is resolved by the imprecision of “around this area”
given that the workers were not usually told where they were going, or how long it would take. Whether the
journey was into Scotland or simply near the border with Scotland is less important than the evidence, from
a credible witness, which I accept, that it was a journey of many hours (he thought 9 or 10 hours, but the
evidence of Mr Stonkus was about 6 hours, and the distance from Maidstone to the Scottish border is more
consistent with that). This was itself exceptional, but it plots a range which makes the shorter journeys the
wrong reference point for an average, just as this longest journey would be.


-----

62. The average, from which estimates can be made, will lie somewhere between the extremes. The
evidence remained, in Mr Balciauskas' re-examination as it had been in chief, that an average journey of
between 2 and 4 hours was “about right”. This is consistent with the documentary record, and I accept it.

_C2 – Mindaugas Stonkus_

63. Mindaugas Stonkus (C2) gave evidence and was cross examined. He is the lead Claimant in Category
2, i.e. those with between 1 and 2 years' employment by the Defendants. As a less experienced worker, he
might be expected to work more slowly, and to catch fewer chickens, and therefore to work longer hours to
catch the same number of chickens as Mr Balciauskas, and others in Category 1, who worked for more
than 2 years.

64. Mr Stonkus appeared to me older and less robust than Mr Balciauskas, although I must bear in mind
that we are now some years on from the events in question. This observation is, however, consistent with
his evidence that it would take him in a team of 8 about 3 hours to catch 10,000 chickens, even on the
favourable basis suggested to him by Mr Houghton (free range chickens) which is lower than Mr
Balciauskas' estimates. I conclude that he and those like him were slower workers than the elite members
who tended to be in Mr Balciauskas' team.

65. Mr Stonkus worked for the Defendants between September 2008 and October 2010. On arrival in the
UK, he was taken directly to the house at 57 Calder Road where he was to live. He was set to work the
following day. However, he was not paid for his first week of work. This was typical – all the workers were
kept in arrears of pay.

66. Mr Stonkus always started work on a Sunday at about noon or 1 pm, and finished on a Friday,
although the time of day on Friday when he arrived back home varied between 6 in the morning and 9 in
the evening. The work was constant and included working through the night, every night; on average he
would return to Calder Road perhaps 4 times, and then only briefly, during his Sunday to Friday working
pattern. The home-stop varied between 30 minutes and no more than 3 or 4 hours.

67. Mr Stonkus said that working time depended on how many men there were in the team to get the work
done; and this varied. His team supervisor also varied but, like Mr Balciauskas, he was most often placed
with Vitas. Vitas usually took the best workers. He was “a bit crazy” and was a hard taskmaster (this is
consistent with the evidence of Mr Balciauskas at para 38 above).

68. Journey times varied depending on the location of the farm. The shortest journey Mr Stonkus
remembers was “about 30 minutes or so” (Stonkus witness statement para 12) and the longest was “in
Scotland or as you come close to Scotland”, which was a journey he estimated at “around 6 hours” (para
12). This is a shorter estimate than that of Mr Balciauskas for what may have been the same journey (see
para 60 above) but both witnesses seemed to me to be truthful about a journey which was on any view
very long, and taken many years ago, when they had no reason to be paying close attention to timing. I will
adopt the shorter estimate of 6 hours but will bear in mind that this was one of the longer journeys.

69. The time spent on each farm also varied: “It could be 1 hour, 2 hours, 8 hours or 10 hours” (Stonkus
statement para 13). The number of lorries to be loaded could vary from 1 to 5, the latter being on “a really
big farm”. Mr Stonkus estimated that “it would take around 2 hours on average to load a typical lorry”
(statement para 13). This was longer than Mr Balciauskas' estimate and, in my judgment, plausibly
reflected the fact that he was not such a strong worker and was less experienced.

70. A variable mentioned only by Mr Stonkus was that in cold weather the lorry took more chickens than in
warmer weather, but this variable does not seem to have been significant enough to impact the figures
overall, and presumably averaged out over time.

71. Very little notice was given of each job – never more than a few hours, sometimes as little as 20
minutes – and so Mr Stonkus felt he was constantly on call (statement para 16).

72. Taking into account travel time as well as time working on the farms (which is legally correct, for
reasons I have explained), Mr Stonkus estimates his working week as being in excess of 100 hours, based
on 5 days and nights and a total of 20 hours of rest (Stonkus statement para 20)


-----

73. Mr Stonkus understood that he was paid (as, in fact, he was) by reference to the number of chickens
that his team caught, and not by hours, and the payment rate (£3 for every 1,000 brown chickens, for
example) was the same for him as for everyone.

74. Mr Stonkus said that they could not choose where to live. “We went where we were told to move to”
(cross examination).

75. The living conditions in the second house Mr Stonkus was moved to (Beaumont Road, which the
Defendants say did not belong to them but to one of their Lithuanian supervisors) were so bad that he
chose to sleep outside on a mattress. He found it impossible to sleep inside “because of all the people and
the bed bugs” (statement para 29). In the first house (Calder Road, which apparently belonged to Ms
Judge), he had his own room (cross examination). However, since there were 15 men in the house, it was
still difficult, with 6 or 7 people sleeping upstairs and the others downstairs sleeping on mattresses (cross
examination). One person was sleeping in an armchair. It was also infested with fleas.

76. Mr Houghton suggested to Mr Stonkus that the house was inspected by the Council and visited by
pest control; but I accept his evidence that this never happened when he was there. Mr Urnikis (C3) gave
evidence that he was aware of a house inspection just once, and when it happened all the occupants were
told to “leave the house for a while”, which they did (first statement para 50). This would have made it
possible to disguise the true nature of the conditions, and makes any inspection which may have taken
place of no value in refuting the evidence of the Claimants about the conditions in which they were being
forced to live.

77. The cross examination of Mr Stonkus by Mr Houghton did not undermine his evidence in chief. This
was not only because Mr Stonkus remained consistent and plausible in his answers, but also because, as
with Mr Balciauskas, the questions were on hypothetical bases which did not seem to be realistic about the
usual working conditions and times. For example, he was asked about working at farms where there were
trolleys, but said “this type of work was a rarity”; and he was also asked about vaccination work, which
even Mr Houghton did not contend was the norm. Also, as Mr Stonkus pointed out, the questions
overlooked travelling time, which could be many hours, and fell to be added to the 3 hours of work that
might be required to load chickens at a farm (depending on numbers, condition, and the other variables I
have mentioned). Mr Stonkus said that travel time to the first farm of a week or a day varied: “It could be 4
hours, 3 hours, 3 hours”.

78. Mr Stonkus (who was not present when Mr Balciauskas gave evidence), like him said that there were
never 14 men in a team. There was only one minibus, and at most 11 men in it. Sometimes, there would
be 8 men, or 9. “It depended on the farm and the number of lorries”.

_C3 – Antanas Urnikis_

79. Antanas Urnikis (C3) gave evidence and was cross-examined. He is the lead Claimant in Category 3,
i.e. those with one year of employment or less.

80. Mr Urnikis worked for the Defendants between April and August 2011. He now lives in Cornwall. He
took up the chicken catching job with the Defendants after answering an internet advertisement which said,
expressly, that no fee was payable, and that he would be given accommodation in which he would live with
“two or three others” (first statement para 7). He answered the advertisement and paid for his transport to
the UK in a van.

81. He arrived before 1 April 2011, on a Saturday. The house he was taken to was the one at 20
Beaumont Road. The people in his van (there were three of them) brought the number living there to about
11. This meant that the other two in the van had to sleep on chairs in the kitchen, but they left the next day
“because the conditions were so bad” (first statement para 12). As well as being overcrowded, the house
was infested with fleas or bugs, which they tried unsuccessfully to get rid of with various products. He slept
in his clothes and socks to try and keep them from biting him, but that did not work either. He was afraid to
complain about it to Ms Judge or to Edikas, “because I knew that making trouble meant you didn't get paid”
(first statement para 13). He was told by another worker that they could withhold pay “for the smallest
thing”


-----

82. Mr Urnikis had worked in the UK before and he already had a National Insurance number, which he
gave to the Defendants. However, they did not use it. Instead, his payslips had someone else's National
Insurance number and date of birth on them, although his name was correct. I heard and saw evidence
that this was a common practice at the Defendants' business.

83. Mr Urnikis was not given work in his first week. When he did start, he recalls his supervisors as various
people: one called Stasys, one called Vitas (the same Vitas as the other Claimant witnesses had as a
supervisor), and another called Simon. The size of team varied from job to job.

84. Mr Urnikis never had the same driver for the whole week. The drivers would not speak to him or his
fellow workers, even if they asked where they were going. They had to work it out from the satellite
navigation display, if they could. He recognised one destination as Drym in Cornwall, when he got there,
because he had worked there before. The journey there took 6 hours, and the journey back took 7 hours
because of traffic. Other journeys were all over the country, to places including farms near Liverpool and
farms near Manchester. These would have been a long way from their starting point in Maidstone.

85. For Mr Urnikis, as for the others, there was no uniform working pattern, but his evidence in chief about
what was usual was as follows (second statement paras 6-8 and para 10):
“In a typical week, I generally started work on either Monday at around 2 or 3pm, sometimes 5pm,
depending on the length of the journey to the first farm or sometimes on a Sunday evening at around 5pm.
Often our team would not return home until we had worked on at least 2 or 3 farms, and sometimes 3 or 4
farms in one trip. For each trip we were normally away around 24 hours, at least one night away, and then
we would return to the house. The amount of time that we had at home in between when we left on Sunday
or Monday and when we got back on Friday varied. We would sometimes come home and go again almost
immediately, or we might have 2 to 3 hours at home and then go again. If I were to give an average I would
say that we had around 2 hours at home each day between Monday to Thursday. There was no set time
that we would leave again during the week, but usually it was some time in the late afternoon.

The only nights I usually had at home between a Sunday and Friday was the Sunday and Friday night. In
total therefore, I would say on average, I worked and travelled around 88 hours between Monday and
Friday and 100 or more if I started on a Sunday.

Sometimes a new mini bus was going out but was short of people and needed some more people from the
old shift. It happened to me personally on one occasion that I was picked to change vans and so I did not
go home at the end of the shift and went on to other farms with a new driver.

… We usually finished work for the week on a Friday. Like any other day there was no set that time we
returned home but it was usually in the afternoon at some time between 2 and 4pm. I would then have
Saturday as a day off.”

86. Mr Urnikis estimates that he worked for over 100 hours per week, including travel, if he began work on
a Sunday, or around 90 hours if he began on a Monday (second statement para 16). This excludes the
time when he was “on call” but not at work or in the van.

87. Mr Urnikis said that in the house he was sent to in Beaumont Road there were up to 14 men living,
with new people arriving as others left, so that the numbers did fluctuate below this. A typical number
would seem, from his evidence in cross examination, to have been 10 or 11. He did not know if Ms Judge
owned this house (she says she did not) but he did know that the rent for it was deducted from his salary.
This to my mind shows that the house was connected with her and with the work she sent to those living in
it, even if she did not own it.

88. Mr Urnikis was given a P45 which did not reflect what he had actually been paid, because of the
regular practice of not providing payment matching the payslips upon which the P45 was based, whether
because of deductions or because of the arbitrary withholding of cheques altogether (aspects I will
consider in more detail, below). In this (that is, the unreliability of the payslips and other official records as a
statement of what was actually paid), his experience was typical of the experience of other Claimants.

_Jacqueline Judge_


-----

89. The Second Defendant, Jacqueline Judge (known as Jackie Judge) was the first defendant witness to
give evidence to me, and she was cross examined.

90. Ms Judge said that the pattern of the Claimants' work was Monday to Friday (not Sunday to Friday, or
Sunday to Saturday), but she did concede that they would do as much work as was available, even if it
went beyond that. She was shown an internal email showing a working week starting in Gloucestershire at
11 pm on a Sunday (which would be after the time taken to travel there from Maidstone) and continuing to
a farm in Northamptonshire where the work was to begin at 4 am on Friday (after which there would be the
time taken to finish the job, and the journey back to Maidstone). In between, this record showed stops at
multiple farms a day, all over the country: after the first farm in Northamptonshire, a farm in Staffordshire,
then farms in Lincolnshire and Devon, another in Devon, then a cancellation, then a farm in Shropshire,
then Powys, then Yorkshire, then another farm in Yorkshire, then back to Powys, then Devon, then
Somerset, then Glamorgan, then Lincolnshire, then Gwent, then Warwickshire, then another farm in
Warwick, and then the final farm in Northamptonshire. Ms Judge said this was not a typical week: “It is
excessive. Too many farms on particular days”. But she could point to no documents supporting her
evidence that a lighter itinerary was more usual. The consistent evidence of the Claimants was that it was,
indeed, typical; and since this was a document disclosed by Ms Judge, I am persuaded that her evidence
was incorrect and theirs was correct. Her own disclosure undermines her evidence and corroborates theirs.

91. She was shown a statement from a driver, Gary Spence, who said that “quite often we went from one
farm to another in the same night”. She said this happened, not quite often as he said, but “occasionally,
not frequently”. Again her evidence being inconsistent with the Claimants' evidence of back-to-back
working over the week, I prefer their evidence to hers, their evidence being supported by the statement of
one of her own drivers and also by other documents which were shown to her.

92. She said “They love working. They love doing the chickens”. The Claimants' evidence, which no
Defendant witness challenged or disagreed with, was that the work with chickens was relentless and
exhausting; that the conditions were unsavoury, in an environment of chicken excrement and fleas, and
that the work was horrible. No Claimant witness said that they loved the work and it seemed to me an
incredible suggestion that they did.

93. She denied that any worker had ever had money deducted for employment fees. She said the sums in
question were for repayment of loans. This was contradicted by the evidence of the Claimants, who were
more credible witnesses. It was also not clear how they could have been required to repay loans when the
employment fee deductions were made at the start of each employment period.

94. She said that all the sums in the payslips had been paid. This was inconsistent, not only with the
evidence of every Claimant, but also other evidence in the papers which was shown to her, such as
evidence gathered by the Gangmasters Licensing Authority. It was also hard to reconcile with her own
handwriting on payslips saying “Speak to Edikas”. Asked what if they were to “Speak to Edikas” about, if it
was not about non-payment of the money stated on the payslip, she said “It could be anything. Cigarettes.
Vodka.” She did not explain why she would ask them to “Speak to Edikas” about cigarettes or vodka at all,
let alone by writing on their payslips. She then suggested that perhaps the writing was by her sister when
she herself was on holiday. The Claimants' evidence, on the other hand, was that this was both said and
written, often, by Ms Judge herself, in order to deter them from querying non payment or other aspects of
their working conditions. The Claimants' evidence on this was more plausible. I accept it in preference to
hers.

95. Ms Judge confirmed an earlier statement in a pleading that Edikas (Mankevicius) was “a physically
threatening man” but denied using him as a shield to deny payment of the Lithuanian workers' wages. She
said that she hated him, and that a text from her to him apparently signed with a kiss (x) was “Probably an
accident. The c is next to an x. I am always texting under pressure.” She said that Edikas was, in fact,
violent and threatening to her and Mr Houghton; but never, she said, to any of the Claimants or other
workers. I am prepared to accept that he was violent and threatening: that seems to be agreed by every
witness. I am prepared to accept that he was someone even the Defendants came to fear (Mr Houghton
also gave evidence of this). But that is beside the point; because I also accept the overwhelming evidence


-----

that he was violent and threatening to the workers; and that Ms Judge knew this and exploited it, with her
“Speak to Edikas” formula for crushing dissent.

96. Ms Judge denied that there was ever overcrowding in any of the houses, unless “they had friends
there at the weekend”. This was contradicted by a pleading filed on her behalf which was shown to her, as
well as by documents and by the evidence of the Claimants. I accept the Claimants' evidence on this
(which is credible and corroborated by documents shown to her in cross examination), and reject hers.

97. Ms Judge did not accept any proposition put to her in cross examination, even when it was based on a
document. She denied that those paid more had worked longer hours. She denied the mathematics of the
calculations based on records of numbers of chickens caught. She denied ever having seen her own
Defence before, even after she was shown her signature at the end of it, verifying it with a statement of
truth. I concluded that she was not a witness on whose evidence I could place any reliance at all.

_Darrell Houghton_

98. Darrell Houghton (the Third Defendant) gave evidence and was cross examined. He said that the
Claimants wanted to work every day but in practice worked 4 or 5 days a week. This was not consistent
with the documents (sparse though the record is) or with the Claimants' own evidence, and it also seems
logically inconsistent. If they wanted to work every day (not because they liked the work, but because they
were trying to earn money), it is more likely that they did work the 6-day weeks (any shorter week being
exceptional) which their oral evidence, and the documentary evidence, supports.

99. Mr Houghton (and Ms Judge) denied that the workers (such as Mr Balciauskas) who caught more
birds than others were working longer hours than those catching fewer birds. He seemed to suggest that
everyone worked the same hours, and the whole difference in numbers could be explained by speed of
working. This did not seem to me to be credible. The workers carried on catching birds until each job was
done. No job was time limited. Although some were quicker at the work than others, there is no reason to
believe that their hours all came to the same regardless of their catching skills and speeds. I think it is
much more likely that the best and more experienced workers in Category 1, such as Mr Balciauskas, were
given bigger jobs and worked longer hours, which at least partly explains their higher catching numbers.

100. Mr Houghton's position on numbers was, I have already said, apparently based on unrealistic
assumptions. However, in cross examination he did not stick even to his own numbers but stretched them
to be even more favourable to the Defendants' case. This weakened his credibility.

101. Like Ms Judge, Mr Houghton denied any deductions were made for employment fees, characterising
them as loans. He maintained this even after being shown the Defence filed on his behalf in these
proceedings and signed by him in which the charging of employment fees was admitted (“It is accepted
that D J Houghton charged certain employees an employment fee which was passed on to Mr [Edikas]
Mankevicius…”). He said the loans were for buying cigarettes and alcohol and “I have no idea why I signed
this document”. Since the charging of employment fees was attested by every Claimant, and is part of the
facts found in the Lane Judgment, I have no difficulty in rejecting his evidence and his denial. But I also
infer that his evidence cannot be trusted on other matters. It is a serious matter to file a pleading verified
with a statement of truth and then in evidence to say the opposite and that you cannot explain why you
made the earlier statement.

_Rehannah Houghton-Judge_

102. The Defendants' daughter, Rehannah Houghton-Judge, gave evidence to me. She is in her third year
studying criminology and criminal justice at Portsmouth University. She is an adult now, but she was a child
at the time of those few matters which she can recall having witnessed in the period in question. However,
it is not only for that reason that I find I cannot place any reliance on her evidence at all. It is also because
she was a witness whose evidence appeared to be entirely driven by loyalty to her parents.

103. Ms Houghton-Judge's evidence, especially in cross examination, was mostly an unconvincing and
somewhat unappealing cocktail of speculation and denialism. She began her evidence in cross
examination by saying “I love my parents to pieces, they are everything to me” and, as she warmed to her


-----

theme that they were loving and caring, and treated everyone like her family, she said “I will obviously fight
my corner”. She dismissed evidence that the Claimants were malnourished, on the basis that she recalled
them at one point giving her sweets and salami (although she was a little shaky when trying to identify the
person or people referred to). She said that, if it was right (as they said) that they were reduced to eating
raw eggs on the farms because of the length of their shifts and the Defendants' failure to provide them with
anything to eat or drink which they did not scavenge for themselves, “It was their own fault for not bringing
their own food”. When she was referred to a police officer's statement in 2012 about one of the non-lead
Claimants in the Quantum Trial (Pranas Stirblys, who is in Category 3), describing him as looking as if “he
had been in a prisoner of war camp” and saying that her parents' workers appeared “very underweight”,
she said “That was their metabolism. Men normally have a faster metabolism than women”. In response to
a good deal of other evidence along the same lines, such as a statement from non-lead Claimant Tomas
Necajus saying “I arrived in England as a young healthy man weighing 92kg. After around 1.5 months at
the Houghtons my weight dropped to 71kg. I never sent my mother any photographs of me during this
period because I didn't want to cause her any heartache. She would not have recognised me with my
sunken cheeks and loss of hair…”, Ms Houghton-Judge said she had not seen anyone like that, and
compared the evidence of weight loss with her own experience of working on a farm when she was
overweight.

104. I was left with a troubling impression that Ms Houghton-Judge was more focussed on fighting her
corner and loyally supporting her parents than giving evidence which was the truth, the whole truth, and
nothing but the truth. It is, however, possible, from my observation of her, that she was merely indifferent to
what was going on, and blinded by loyalty to her parents, so that she genuinely believes (as she
suggested, with combative responses such as “Is it just the worker's word?”) that all the evidence was
trumped up, the findings of the Lane Judgment (to which she was referred) were wrong, and her parents
were, in fact, good people to work for. However, since her evidence lacked credibility, consistency,
independent corroboration, or reliability, it had, in my judgment, no weight even at those rare points where
it was based on her own knowledge or recollection.

_Omead Serati_

105. The Defendants also relied on a witness statement of Omead Serati, who was not required for cross
examination. He was Procurement Manager for Noble Foods (who appear to have contracted with the
Defendants' for their chicken catching services) between March 2006 and February 2015. He said he did
not see any welfare issues associated with the Defendants' staff. “Staff seemed well motivated and always
looking for more work”. He said the teams were required to travel “some distances, but never into Scotland.
I believe the most northern collection was Yorkshire”. He said he was “never informed of any worker abuse
by any of our employed lorry drivers”. He also said, “Noble paid DJ Houghton well, in my personal opinion.”

106. I did not find this statement inconsistent with the compelling and abundant evidence I heard, and
which Lane J heard and summarised in the Lane Judgment, as well as the evidence considered in the
related case, brought by other Claimants, against the same Defendants, in _Galdikas and others v DJ_
_Houghton Catching Services Ltd and others_ _[2016] EWHC 1376 (QB). In Galdikas, Supperstone J entered_
judgment for Mr Galdikas and five other Lithuanian claimants in respect of (i) the Defendants' failure to pay
them for their work in accordance with the terms of the relevant Agricultural Wages Order; and (ii) for
breach of Condition 7 (prohibition on charging fees) and Condition 13 (deductions from wages) of the 2009
Gangmasters Rules and Standards Gangmasters Licensing Authority Standards 4.3 and 6.3 in respect of
lack of facilities to wash, rest, eat and drink (para 75 of the judgment in Galdikas). Mr Serati says he did not
see and was not aware of “any welfare issues”, but it is clear from the evidence that they existed. Mr Serati
was not informed of worker abuse by his lorry drivers, but I accept the Claimants' evidence that the lorry
drivers (who were not Lithuanian) did not talk to them much, if at all.

**Discussion and conclusions on hours worked**

107. The parties' rival positions on the hours worked and payments due to the three Lead Claimants are
summarised in the final schedules and counter-schedules of loss which were produced during closing
submissions and reflected a measure of agreement. These demonstrate that the only disputed issue is the


-----

total number of hours worked, or for which they were entitled to be paid for other reasons, because they
represented travelling or waiting time. All the other elements are agreed. The dispute can therefore be
summarised, from those final schedules and counter-schedules, as follows:

i) In respect of Mr Balciauskas (C1):
a) The Claimants say he worked on average 73 hours overtime per week (plus 23 basic hours and 16
night hours), making a total of 112 hours on average per week.

b) The Defendants say he worked on average 26 hours overtime per week (plus 23 basic hours and 16
night hours), making a total of 65 hours on average per week.

ii) In respect of Mr Stonkus (C2):
a) The Claimants say he worked on average 63 hours overtime per week (plus 23 basic hours and 16
night hours), making a total of 102 hours on average per week.

b) The Defendants say he worked on average 26 hours overtime per week (plus 23 basic hours and 16
night hours), making a total of 65 hours on average per week.

iii) In respect of Mr Urnikis (C3):
a) The Claimants say he worked on average 45 hours overtime per week (plus 27 basic hours and 12
night hours), making a total of 84 hours on average per week.

b) The Defendants say he worked on average 26 hours overtime per week (plus 27 basic hours and 12
night hours), making a total of 65 hours on average per week.

108. The Claimants' figures are those which follow from their oral evidence, which I have accepted. This
evidence, which I have summarised above, included evidence of the usual working week, evidence of the
catching times, evidence of the pattern of brief return home during the working week, evidence of the
travelling time (including but not limited to the drivers' hours and itineraries) and evidence which can be
cross-checked to such records as exist of the numbers of chickens actually caught by certain teams in
certain weeks. It includes, also, evidence of the notional calculation of wages to be entered on the payslips
(although not necessarily paid), which does appear closely related to the number and type of chickens
caught. The number and type of chickens caught can then be used to cross check the catching times,
which is directly related to the number of chickens caught.

109. All of this was exhaustively discussed in the Claimants' opening and (to a lesser extent) closing
submissions. Neither the logic nor the mathematics of those submissions was challenged by Mr Houghton,
or in the Defendants' opening or closing submissions. Rather, the dispute was centred on the assumptions
fed into the mathematical analysis, in terms of the number of hours worked, the distances travelled, and
the time spent not catching chickens but on call, or at work waiting, or travelling. I found the cross checking
in the Claimants' opening persuasive. Although no methodology produces a precise figure, and without
contrivance one cannot by different methods arrive at identical figures, I am persuaded on the balance of
probabilities that the figures put forward by the Claimants are proved, while the figures put forward by the
Defendants are inconsistent with the evidence (except their own oral evidence, which I have rejected) and
are wrong.

110. I have considered whether the uncertainties to which I have repeatedly referred should lead me to
discount the hours claimed in the Claimants' evidence, on the basis that, although I have found them to be
entirely honest and convincing, they may nevertheless have been mistaken, and do not claim to have
perfect or precise recollection about hours worked, not least because of the lack of fixed working hours or
practices. I have decided not to do so. There are a number of reasons for this. First, any discount would be
arbitrary. The case put forward is a case not only based on recollection but cross checked against the
documentary record that exists, using assumptions and inputs which seem to be reasonable and
moderate. A discount would reflect a lack of certainty, rather than being based on any evidence. Second,
the uncertainty is due to the Defendants' own failures to keep the records required; or to calculate the pay
at the material times on the basis required by law. It would be wrong in principle for uncertainty created by


-----

the Defendants themselves to lead to a discount in the Defendants' favour. Third, I remind myself that I am
applying the civil standard of proof. That already allows for considerable uncertainty, since the civil
standard is only the balance of probabilities. However, once the claim is proved in a particular amount on
the balance of probabilities, it is wholly recoverable in that amount.

111. Consequently, I find the Claimants' case on hours to be proved as put forward by them.

B. Deductions

**_Deductions for rent - evidence_**

112. The Lane Judgment found that:

“…chicken catchers recruited for D1 were, in effect, required to live in particular accommodation. A chicken
catcher, as opposed to a supervisor, effectively had no choice in the matter. If he was to get regular work,
he had to live in one of D2 or D3's properties or one of the properties of Edikas” (para 81).

113. In relation to deductions for accommodation, Lane J found “There is no reasonable prospect of D1
succeeding in showing that accommodation fees of £40 a week were not deducted, on a wholesale basis,
from wages due to the chicken catchers.” (para 96). He rejected as “not credible” the Defendants'
submission that some of the accommodation charge of £40 related to an element of council tax and water
rates but decided that, even if it had so related, the charge “remains one for accommodation and, as such,
subject to the legislative restriction” (para 97). He decided that this imposed a maximum charge for
accommodation of the specified sum of £33.74 (for 2012; slightly less in previous years) (para 98).

114. Mr Balciauskas (C1) addresses deductions for rent in his second witness statement as follows (paras
27-29):

“I lived at two houses whilst working for the Houghtons. The first was 57 Calder Road and the second was
40 Emsworth Grove. I remember that two of the supervisors, Simon and Stasys, did not live at properties
owned by Jackie or Edikas but I was told by other workers that I would not be given work if I tried to live
elsewhere.

Each week, £40 would be deducted for rent. Sometimes Jackie gave me a payslip with the full amount
printed on the payslip then marked in pen on the payslip it said “£40” and “£50” and then a new total in pen
was shown with £90 deducted. The way this was done can be seen on the payslips dated 18 December
2009 and 8 January 2010 exhibited at TB2-3. The “£50” relates to the employment fee which I explain
below. Sometimes, there was nothing written on the payslip and we just received the cheque for an amount
that was less than the payslip.

Until around 2010 the rent was always deducted from our cheques, but at some point (I cannot remember
exactly when), Edikas began collecting the rent in cash for his houses and Jackie collected the rent for
hers.”

115. He gave evidence to the same effect in cross examination, and I accept it.

116. Mr Stonkus (C2) lived at two houses, the first being 57 Calder Road (statement para 21). He
understood that if he did not live where he was told, then he would not get work (statement para 21). This
is consistent with the call to work being sent to a representative at the house, so that you would not get it
unless you were there (statement para 16).

117. Mr Stonkus was very clear that rent was deducted from his pay every week; at the rate of £40 per
week in Calder Road and £50 per week in the second house (statement para 22).

118. Mr Urnikis (C3) paid £40 per week for rent, at the house at 20 Beaumont Road. He was uncertain
whether it belonged to Ms Judge or to Edikas, but his understanding from what he was told was that, if he
wanted work from the Defendants, he was compelled to live in this house. I accept that this was the case.
The work instruction went to the house, and the pick-up was from the house, often at short notice. No work
would be offered to anyone not in an approved house. Mr Urnikis said that, at one point, there were 12
people living in his house, all paying £40 rent weekly (first statement para 35).


-----

**_Deductions for rent – discussion and conclusions_**

119. The Claimants' challenge the deduction of any rent on the basis that the houses for which the rent
was charged were not fit for human habitation.

120. I accept that the houses were overcrowded. I also accept that fleas were a constant problem.
Overcrowding and fleas are the main complaints made by the Claimants.

121. However, overcrowding does not in itself make a house unfit for human habitation, nor in my
judgment does it make it wrong to charge rent for it. The level of rent was enough to make a good return
given the number of people paying it. But no Claimant seem to think he was paying too much rent as an
individual and no evidence was presented to me about market rents to support a submission that the rents
charged were extortionate.

122. The fleas probably came from the chickens. The Claimants' evidence was that the chickens had
fleas, and that the chicken catchers caught fleas when catching the chickens. The lack of facilities for the
workers to clean themselves up at the farms, or for changing their clothes between jobs, and the very
limited time they had to attend to any personal hygiene in the course of their long and intense working
weeks, meant that, once the fleas had moved from the chickens on to the men, the men were bound to
take the fleas home with them. Any man who by an individual change of clothes and shower got rid of his
own fleas, would in the overcrowded house no doubt catch new fleas from the other men, or from furniture
or other places where they waited for new hosts. And when he went out to catch chickens again, he would
probably catch fleas from them again anyway.

123. I am not satisfied that the houses were unfit for human habitation in the sense that the men should
not have been charged any rent for them, or that the deductions for rent should, on that ground, be wholly
disallowed. There is some evidence of inspections of the houses, albeit infrequent, and only after the men
had been asked to leave so that the overcrowding could be covered up. However, there is no evidence that
any inspection condemned the houses as unfit for human habitation.

124. I therefore reject the case that all the deductions for rent should be disallowed.

125. I do however accept that any deduction for rent could not exceed the statutory limits and that any
deduction exceeding those limits has to be repaid. Since the end of the hearing, the parties have refined
their position on statutory deduction limits. The Defendants have raised the suggestion that the Claimants
rented a room, and so the room rental limits apply; but I find on the evidence given to me that the men
shared the whole house, and shifted where they slept without formality, and did not have exclusive
possession of a room, or of any part of the house. Hence the deduction could not, by law, exceed £1.50
per week. This is so whether or not the Defendants owned the house in question.

126. I find that the actual deduction for rent was not less than £40 per week, which is the figure now
agreed between the parties. Consequently, the Claimants are entitled to recover £38.50 per week,
representing the excess deduction above the £1.50 permitted by law under the Agricultural Wages Orders.
The number of weeks in question is agreed between the parties. If the precise amount of deduction varies
between Claimants depending on the date in question and the deduction cap in force under the Agricultural
Wages Order in force at the time, this should be capable of agreement.

**_Deduction of employment fees – evidence and conclusions_**

127. The Defendants deny that any employment fees were ever deducted, but I have rejected their
evidence about this, for reasons I have given. I prefer the evidence of the Claimants.

128. So far as employment or work-finding fees are concerned, Lane J found that “There was a systematic
process of withholding money at £50 a week up to a maximum of £250 or £350, which continued until
2021”, and the evidence to the contrary from the Defendants on that issue was “hopeless”. Rather, the
evidence of the Claimants (including C1) “demonstrates to a very high degree of likelihood” that all the
Claimants “suffered these illegal deductions from their wages” (para 92). He noted “the evidence of Ms
Shanks regarding the average number of new workers each week, which correlates strongly with the


-----

payments made to Edikas” (para 94). Even if I were not bound by these findings (which I believe I am), I
would agree with them.

129. Mr Balciauskas gave evidence that, when he paid the person who took him in a van from Lithuania to
the house he lived in when first working for the Defendants, he understood that no more fees would be
payable. But when he got to the UK, he found that he had to pay Edikas £250 as an employment fee (first
statement para 36). This was done at the rate of £50 per week for 5 weeks. But sometimes, Ms Judge
would continue to make the deduction after 5 weeks, and, although she would promise to make the overdeduction up in future cheques, it was not clear if she had done so. Given the general policy of keeping the
workers on the shortest possible commons, which emerges from the whole of the evidence, I think it is
highly unlikely that this promise was kept once an over-deduction had taken place. The impression I had of
Ms Judge from her evidence to me was that she thought she was fully entitled to take these vulnerable
Lithuanian workers for all she could get, had no compassion for them, and no regrets about the multiple
failures to give them their contractual rights, let alone their legal rights, which was overwhelmingly
demonstrated in the evidence to me, as it was in the evidence set out in the Lane Judgment. I am sure
that, having successfully withheld money even beyond the £250 employment fee that was discussed (the
whole of which was, in any event, unlawful), she was never going voluntarily to relinquish it. Talk is cheap;
promises are cheap; Ms Judge was not a woman of her word (see, for example, Balciauskas first
statement para 52).

130. She was also, on the evidence, quite callous, at least towards her Lithuanian workers (see, for
example, Balciauskas first statement paras 67-73). I have no hesitation, on the evidence, in accepting and
agreeing with the observation of Mr Balciauskas that Ms Judge treated the Lithuanian workers as less than
“other human beings” (first statement para 84). Nothing in the evidence she gave to me, or about the way
in which she gave it, refuted the abundant evidence given to me of this.

131. Mr Balciauskas's evidence was that he had to pay an employment fee “around six or seven times in
total” (first statement para 38). After the first one, which was meant to be £250, the subsequent
employment fees were set at £350 on each occasion (first statement paras 38-39). I estimate the additional
fees taken by way of overpayment as a total of £100 (that is, two overpaid and unrefunded instalments of
£50). This gives a total figure for employment fees of £2,450, made up of 1 payment of £250, 2
overpayments of £50, and six further payments of £350 each. If one gives the Defendants the benefit of the
doubt as to whether the fee was paid six or seven times, the figure reduces to £2,100. The figure claimed
in the Schedule of Loss is a round £2,000 (against the Defendant's case of £100). I am therefore confident
in awarding the £2,000 claimed.

132. Mr Stonkus (C2) gave evidence that he, too, was told before he left Lithuania that there would be an
employment fee of £250. In his case, it was paid only once, by deduction from his wages at the rate of £50
per week for five weeks. Hence, in his case the claim under this head is just £250.

133. In the case of Mr Urnikis (C3), he was told about the employment fee only after he arrived in the UK:
indeed, he had been told expressly before he left that no such fee would be payable. He recalls it as £350,
which was deducted in instalments of £50.

134. These sums are recoverable by the Claimants.

**_Arbitrary deductions – evidence and conclusions_**

135. The Defendants' case is that there were no arbitrary or unjustified deductions. There was a conflict of
evidence between them and the Claimants on this. I prefer the evidence of the Claimants and accept that
these deductions were made.

136. Lane J found that there had been arbitrary deductions. This he referred to as:

“…the real mischief, compellingly articulated in the claimants' evidence and not credibly rebutted, that D2
and D3 operated a system of withholding wages for entirely invalid reasons. There is strong and
consistent evidence from the claimants that wages were withheld as a form of punishment for alleged
transgressions, such as holding parties and drinking alcohol. The witnesses gave evidence that recourse to


-----

borrowing was necessary, as a result of them not being paid. Mr Balciauskas identified a second reason in
cross-examination; namely, that wages were withheld as a form of leverage. This chimes with the GLA's
view that “the systematic and persistent withholding of wages [was] a way to trap workers and leave them
little or no option but to remain… in the hope that they would receive pay in the future”.

In this regard, the messages on payslips, telling the recipient to speak to or otherwise contact Edikas, can
be seen as the way in which D2 attempted to stifle any complaints in this regard. The evidence strongly
demonstrates that Edikas was an unsavoury individual who, as I have indicated, served D2's and D3's
purposes, albeit that their relationship with him was not without its own difficulties.” (Lane Judgment paras
102-103).

137. These findings are binding on me but they are, in any case, consistent with the evidence I have
heard, and seen, and accept.

138. The evidence of Mr Balciauskas was that he was not paid at all for his first week of work, and this
was normal practice for any new arrival (first statement, para 34). He was then paid one week in arrears,
when he was paid at all: that is, he was paid for the first time at the end of his second week. But when any
worker stopped working for any reason, they also left the house which was tied to their work, and they
were not paid for their final week either. This means that a total of two weeks was routinely unpaid: one
week at the start of a working period, and one week at the end. In other cases, however, it was more.

139. The evidence of Mr Stonkus (C2) was that he was not paid for his last fortnight of work (statement
para 30).

140. The evidence of Mr Urnikis (C3) was that he was not given work in his first week. This meant he was
not, of course, entitled to be paid. But he was then not paid for the first two weeks in which he did work. He
was told this was the way it worked: “When you were new, you didn't get paid” (first statement para 32).
The effect of all this was that he was always chronically short of money, and even in debt.

141. The evidence is that Ms Judge was, of all the Defendants, the person primarily responsible for the
way in which the Claimants were paid. Both Defendants tried to place the blame and the responsibility for
failures on their professional advisors, but it is clear from the evidence, including evidence given by those
advisors to Lane J, that they were acting at the direction of the Defendants and were constrained by the
policy of the Defendants and by the information (which was limited and inaccurate) given to them by the
Defendants. Therefore, the whole responsibility lies on the Defendants.

142. I am convinced from the evidence that the failure to pay the Claimants what they were legally due, or
even what was understood to be the basis (although illegal) upon which they would in fact be paid (namely,
by reference to chickens caught rather than hours worked, and without regard to minimum wage
legislation), was motivated, not only by meanness, rapacity and avarice on the part, especially, of Ms
Judge (although those motives were present), but also by the realisation that this systematic
underpayment, non-payment, and arbitrary unpredictability of payment would place the Claimants more
completely under the Defendants' control.

143. The manipulative withholding of wages was not limited to the start and finish of the working period. It
was used, even during the working relationship, to emphasise the dependence of the workers on every
whim of the Defendants, as when wages were docked for the whole house for a whole week because they
had a party for themselves on their day off, although they had cleared it with Edikas in advance (first
statement para 48). This was attributed to complaints from neighbours but it is neither normal nor lawful for
an employer to deny every person in a particular house the pay due for their work because of a neighbour's
complaint. At other times, pay was withheld at the whim of Edikas himself, giving reasons like “a coffee cup
not being washed up” (Balciauskas first statement para 50). Even then, it was Ms Judge who had the
deduction made (para 51), so she was fully complicit in it.

144. Mr Urnikis gave evidence that, on one occasion, Edikas came to the house when he was asleep and
so he did not come down straight away. He then did a full working week, but he was not paid for it, as a
punishment for this. It was explained to him that “it was the rule that when Edikas came, we had to
assemble downstairs as if we were in a prison” (Urnikis second statement para 22)


-----

145. In addition, there were occasions when pay was arbitrarily withheld (as noted in the quotation from
the Lane Judgment above), and this happened to Mr Balciauskas “fairly frequently, at least once every one
or two months” (first statement para 46). Sometimes there was no payslip either; but sometimes he was
given a payslip but no cheque (first statement para 47). This made the workers unhappy “and affected us
psychologically”; “When you don't get a cheque for a week's work and you have done nothing wrong,
believe me that is a very unpleasant feeling”, but Mr Balciauskas tried not to dwell on it (first statement
para 46).

146. Mr Stonkus (C2) gave evidence in line with that of Mr Balciauskas. He estimated that his wages were
not paid “at least once a month” (statement para 24). He would be given a payslip on these occasions, but
no cheque to go with it (para 27). Ms Judge was in charge of this.

147. Mr Urnikis (C3) said “We never knew if we were going to get paid or not” (first statement para 36). His
recollection is that this happened to him personally (as well being the common experience of those he lived
and worked with) “around four or five times” while he worked for the Defendants. I find this particularly
helpful when trying to put figures on this aspect generally. Mr Urnikis worked for the Defendants only
between April and August 2011, a period of about 20 weeks. He was not paid for his first 2 weeks of work
(leaving 18 weeks). I have no doubt that he would not have been paid for his final week, but he and others
took a stand, and involved the Citizens Advice Bureau, and stood up to the threats (including eviction)
which followed (first statement paras 42-45), as a result of which Ms Judge paid 2 weeks of the arrears,
leaving the rest of the non-payment unsatisfied.

148. The workers usually cashed their cheques at a local Money Shop, and records from these
transactions support and corroborate the Claimants' evidence about regular non-payment for weeks
worked.

149. Accepting Mr Urnikis' evidence (as I do), that he was unpaid for 4 or 5 weeks of his 18 week period of
regular work, suggests a non-payment rate of one week in four. This is consistent with and throws light
upon the less-precise evidence of other Claimants and from the records of the Money Shop. Mr Stonkus
claimed for non-payment at least once every month, and Mr Balciauskas for non-payment at least once
every one or two months. I see no reason to conclude from the evidence that the regularity with which
payment was withheld from Mr Urnikis was any different from the regularity with which it was withheld from
other workers. There seemed to be nothing personal, or rational, about deductions: indeed, if any infraction
in the house was invoked to justify non-payment, it was applied against everyone in the house
indiscriminately, without any attempt to single out actual miscreants. I therefore conclude on the balance of
probabilities that, on average, every worker was not paid at all for one week in every four weeks worked,
notwithstanding the production of a payslip for that week.

150. There was no legal basis for not paying men for all the work they had done. Consequently, the failure
to pay for the first week or so, either at the time or at the end of the working period, and the failure to pay
for the final week or weeks, and the arbitrary non-payments throughout the working relationship were
unlawful deductions which the Lead Claimants are entitled to have paid to them to the extent that it applies
to them.

C. Holiday pay and interest

151. Lane J also found that the Defendants “failed to allow workers to take any holiday” or “failed to pay
for holidays taken” (para 104) and entered judgment in that respect.

152. I need not identify and assess the evidence in relation to holiday and pay and interest, because the
quantum of this aspect has now been agreed between the parties.

D. Aggravated damages and exemplary damages

_Aggravated damages_

153. The Claimants claim aggravated damages. Aggravated damages (unlike exemplary damages) are
compensatory.


-----

154. The Claimants' claims against the Second and Third Defendants are in tort, for inducing breaches of
contract by the First Defendant (see para 4 above). All the sums that I have assessed so far have been
under-payments or non-payments of sums due, primarily, by law, because of the regulation of contractual
wages from which the Claimants were entitled to benefit. They do not, therefore, so far include any element
to represent the mental and physical sufferings of the Claimants.

155. I am satisfied that the Claimants will not be fully compensated unless the cumulative effect of the
treatment I have described is recognised in their damages, over and above the amounts and totals of
individual non-payments. Recovery of the money due now, even with interest, will not compensate the
Claimants for the whole effect upon them of their exploitation, manipulation and abuse by the Defendants
at the time in question, and in the manner that I have outlined above. The means of inflicting this abuse
was the First to Third Defendants' systematic denial of the Claimants' statutory rights. I am not
compensating them for personal injury, because this is not a personal injury claim. In awarding aggravated
damages, I am recognising that the effect of non-payment and under-payment was extreme, because of its
total and cumulative impact on them.

156. I assess the aggravated damages at 20% of the damages represented by the various basic money
claims. Therefore, those claims will in each case be uplifted by 20%. In this way, I award amounts which
are proportionate to the denial of rights in each case.

_Exemplary damages_

157. Exemplary damages are also claimed. Exemplary damages are punitive rather than compensatory.

158. In view of the substantial aggravated damages I have awarded, I do not think it necessary or
appropriate to award exemplary damages as well. If I had solid evidence of the amount of profit made by
the Defendants from the way in which they conducted their business, and if it appeared that this
significantly exceeded the damages awarded against them, I would have considered to what extent the
excess should have been taken from them by way of exemplary damages. However, I have no detailed
evidence of this, and there is the further consideration that the Claimants were not the only exploited
people, and so the excess profit (if and insofar as it was earned) made on the back of exploited workers
would not necessarily be the right basis for exemplary damages in favour of the ten Claimants in these
proceedings, let alone the three Lead Claimants.

159. It is enough that I compensate the Claimants for their losses, including their aggravated damages. I
will not, therefore, award or assess exemplary damages.

**End of Document**


-----

