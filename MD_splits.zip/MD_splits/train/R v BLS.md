# R v BLS [2022] EWCA Crim 1079

Court of Appeal, Criminal Division

Dingemans LJ, McGowan and Bourne JJ

29 July 2022Judgment

**Ben Douglas-Jones QC represented the Applicant**

**Andrew Johnson represented the Respondent**

Hearing date : 19 May 2022

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely by circulation to the parties' representatives by email and released to
The National Archives. The date and time for hand-down is deemed to be 11.00 hrs on 29 July 2022.

**Mrs Justice McGowan :**

**Introduction**

1. This application for leave to appeal conviction has been referred to the full court by the Registrar. An
extension of time of 1,386 days is required and the applicant seeks leave to call fresh evidence. There is
an application for anonymity, the applicant has not been identified in these proceedings to date. In light of
the findings of the First-tier Tribunal Immigration and Asylum Chamber (“FTT”) as to his status we grant the
[application and preserve his anonymity, see R v AAD & Ors [2022] EWCA Crim 106](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360) _._

2. On 24 April 2017 the applicant pleaded guilty before The Honorary Recorder of Liverpool, H.H.J
Goldstone QC, to producing a controlled drug of class B, cannabis, and having a bladed article. He was
sentenced on count 1, the drugs offence to a term of 22 months imprisonment and a consecutive term of 2
months on count 2, the possession of a bladed article.

3. The applicant is represented before us by Mr Ben Douglas-Jones QC and the respondent is
represented by Mr Andrew Johnson, neither of whom appeared in the court below. We are grateful to them
for their extremely helpful written and oral submissions.

4. The issue is whether the applicant had available to him a defence under section 45(1) Modern Slavery
Act 2015 (“the Act”), which would probably have succeeded. Section 45 provides a defence for victims of
slavery or trafficking who commit offences whilst acting under compulsion and that compulsion is
attributable to slavery or trafficking. In the case of an adult a reasonable person in the same situation,
having the same characteristics, would have had no realistic alternative to committing the offence.

5. It is argued by the applicant that he had such a defence and neither his counsel nor his solicitors
advised him of that. Accordingly he pleaded guilty when such a defence would probably have succeeded.

6. Further it is submitted that if the prosecution had been aware of his status at the time of his arrest and
charge they would or might well have not proceeded with the prosecution. It is also submitted that the
decision to proceed is an abuse of the process of the court.


-----

**Arrest and Prosecution**

7. The applicant was arrested in a car outside an address that police were searching under a warrant. He
had a key to the premises in his possession and £100 in his wallet. There was a knife in the driver's door
pocket. The house was a 'cannabis factory'. In the house was found cash in excess of about £600-£700 in
cash on the table in the living room and three mobile telephones. He told police that he was paid £200 per
week by the people who hired him and his duties only involved looking after the plants. He had also been
given the car by the people who paid him for watering the plants. He said he had been in the UK for 2
years and was only 16 years of age. He also gave an explanation for the possession of the knife. In fact he
was born on 8 August 1998 and was 19 years of age at the time.

8. In interview he told police that he had entered the UK illegally and had lived rough until he met a man
who had offered him the job of looking after the plants. He was paid £200 per week and lived at the house.
He was given the use of a motor vehicle and drove to a McDonald's once a week to meet the man for
payment.

9. The Magistrates carried out an age determination process and did not accept the applicant's account
that he was under 18. His case was sent to the Crown Court, where he pleaded guilty. He has waived
privilege and we have been assisted by the provision of his instructions and the recollection of counsel and
solicitors who appeared on his behalf. His solicitor recalls that the applicant did not give instructions which
raised any issues under the Act and it would not have been appropriate to raise such an issue given that
their instructions were that he was being paid “a reasonable weekly wage”. If there had been any indication
that he was the victim of slavery, the matter would have been pursued.

10. In mitigation it was said on his behalf that he was “exploited because of his vulnerable position and
was probably quite easily persuaded to take up the position that he was offered”. The judge did not accept
that submission and said “I don't think he took any persuasion at all. I think he was perfectly happy to play
the role which he did because it helped protect him against the risk of detention and deportation. That is
why he lied about his age when he was arrested.” It was also submitted that “he doesn't have family in this
country and … both parents died when he was but two or three years of age”. In passing sentence the
learned judge observed that the applicant had been involved in the cannabis production business for a
period of four months, he accepted that the applicant was “not in a position of responsibility” but was
“working under direction”. The judge found that the applicant was being paid between £200 and £300 per
week; had been provided with accommodation and had access to a motor vehicle.

**The Immigration and Asylum Proceedings**

11. On 2 May 2017 the Home Office gave notice of its intention to make a deportation order against the
applicant. On 8 November 2017, the applicant indicated his intention to apply for asylum. On 13
November 2017 an asylum screening interview was conducted. In that interview the applicant said he had
been trafficked across Europe and into the UK, he denied that he had been exploited but said that “the
mafia are after me” because his father owed them a large amount of money. On 29 November 2017 a
substantive asylum interview was conducted, the applicant told the interviewers that he had agreed to work
in the UK for five years to pay off his father's debt.

12. On 4 April, 2018 the applicant was referred via the National Referral Mechanism, (“NRM”) to the Single
Competent Authority, (“SCA”). On 13 June 2018 a trafficking interview was conducted. The applicant was
asked about his arrival in the UK, he said he spent a week in London before being taken to the north west.
He spent about five months in Haydock before he was arrested. He told his interviewers that he was
allowed to come and go and was paid money. He was asked in specific terms about his claim based on
slavery and trafficking grounds, he replied “I have never claimed to having been trafficked or of being a
slave. I agree that I could come and go as I pleased….. but I did get paid and have food and drink
provided.” He told the interviewer that he had about £800 or £900 on him at the time he was arrested.

13. On 10 October 2018, the SCA reached a “negative conclusive grounds decision”, having decided that
there were not reasonable grounds to suspect that he was a victim of trafficking. Later he provided two


-----

expert reports to the SCA who, on 26 February 2020, again determined that he was not a victim of
trafficking, a second “negative conclusive grounds decision”.

14. The applicant appealed against the Secretary of State's decision to refuse his applications for asylum
and for leave to remain on human rights grounds. The applicant's asylum claim was heard and allowed by
Judge Flynn in the FTT and his reasons were promulgated on 27 February 2020 (“the FTT decision”).

15. The respondent challenges the basis of the FTT decision on its merits. In any event, on 9 April 2020
the Secretary of State agreed to reconsider the decision. On 22 July 2020 the SCA found that there were
reasonable grounds to believe that the applicant was the victim of trafficking, (“the positive reasonable
grounds decision”). On 12 November 2020 the SCA concluded that the applicant was a victim of trafficking,
(“the positive conclusive grounds decision”).

16. It is against the background of those decisions that the applicant seeks leave to appeal against his
conviction.

**Grounds of Appeal and Response**

17. Mr Douglas-Jones QC submits that the applicant's appeal should succeed: firstly, because the
prosecution should not have been commenced or continued; secondly, because he had a defence under
section 45; and thirdly, because it was an abuse of process to prosecute him on the facts as the
prosecution knew or should have known them to be.

18. Mr Douglas-Jones argues that, if at the time of the decision to charge the applicant, the prosecution
had been aware of the facts as found in the decisions that it 'would' or 'might well' not have continued with
the prosecution. He argues that the police, CPS, defence lawyers and the Crown Court all failed to see
what should have been obvious, “the red flags”, namely that as a young Vietnamese man involved in the
production of cannabis the applicant demonstrated all the indicia of being a victim of trafficking or slavery.
He submits that the police failed to meet their duties under section 52 of the Act. He submits that there
were reasonable grounds for believing that the applicant was a victim and the police and/or the CPS
should have acted accordingly. He submits that if they did fail in that duty there is no further burden on him
to satisfy the test in AAD, he cites the line of authorities leading to R v Bani [2021] EWCA Crim 1958.

19. Further, he submits that the findings of the FTT and the NRM indicate that a defence under section 45
would probably have succeeded. He invites the court to use the decisions of the tribunal and the SCA as
an aid to our assessment of the merits of the statutory defence. He argues that solicitors and counsel
acting for the applicant in the Crown Court should have been alive to the issue of trafficking on the facts
available to them; and, if they had been alive to those factors they would, and should, have advised the
applicant accordingly. The defence should have been raised and would probably have succeeded. He
argues that inconsistencies in the applicant's accounts are merely supportive of a victim not being able to
trust anyone in authority and disclosing accurate information piecemeal as trust is established.

20. In the third limb of his submission he relies upon the abuse of process jurisdiction. In all the
circumstances of the case as the prosecution knew, or should have known them to be, it was an abuse to
instigate or continue this prosecution.

21. In response, Mr Johnson invites the court to approach the second limb of the appeal as a first step. He
submits that if the second route succeeds then the others are otiose and if it fails, the others cannot
succeed. We accept his submission that this is the best way to approach the arguments in this case.

22. Mr Johnson argues that the FTT judgment and the NRM report should not be conclusive. He submits
that they contain errors and omissions. He relies, in particular, on the fact that the FTT failed properly to
deal with the interviews under caution and the applicant's answers about his involvement in the production
of cannabis. The FTT found that the applicant had tried to escape, Mr Johnson points out that this is not an
account given at any other stage of this investigation, nor does it fit with the reality of the position. The
judgment fails to deal adequately with the issue of weekly payment, his access to a key to the property, his
possession of the car and his ability to come and go. He argues that its deficiencies are such that this court
should not see it as determinative.


-----

23. Mr Johnson has agreed that the court should hear the evidence of the applicant de bene esse and to
permit cross-examination of him on the salient points. We have heard the evidence of the applicant, it is
not necessary to recite it in full detail.

**The applicant's further evidence**

24. The applicant told us that he was taken to the property by “mafia guards”; that he was obliged to work
to pay off his father's debt and was given instructions on what to say if arrested. He was told he should tell
the police that he was under 18, that he went to the house to work and was paid for working. He said that
he had tried to escape on one occasion but that the guards had found him and brought him back. He
accepted that he had the use of the car, he had been told to leave the house every week day and drive to
McDonald's and he was told to spend the day there so it would appear to the neighbours as though he was
leaving to go to work. He was given money for petrol and to buy some sort of liquid for watering the plants.
He agrees that he had money on him when arrested and that there was money in the house. He denied
that he had told the police that he had £800 or £900, he said he could not challenge that answer because
he did not trust anyone, including the interpreter. He appeared uncertain about why he had not mentioned
being a victim of slavery until his asylum interview but said that his immigration solicitors gave him the
chance to explain. He accepted that he could have left the house and escaped if he had wanted. He
repeated that he was restricted in what he could do because his father's life was in the hands of his
traffickers. He was unclear in his answers about where his father lived or what had happened to him.

**The further submissions**

25. Mr Douglas-Jones submits that the applicant's account of being trafficked had not been challenged.
Mr Douglas-Jones accepts that there were difficulties in this case because of inconsistencies, but these
would be present in any case because of the mistrust of authorities. If one looks at this case from the other
end of the telescope the applicant had been consistent about what had happened in Vietnam, his journey
and his exploitation. The appeal should be allowed.

26. Mr Johnson submits that on the history of the accounts given and on the accepted facts about the
applicant's time at the house in Haydock, the defence under section 45 would not have succeeded. Even if
the applicant had been trafficked into the UK and employed to cultivate cannabis as part of a scheme to
repay his father's debt there was still no nexus between that and his continuing to work at the house. He
had money; the key to the house; he could come and go; he had the use of a car and it appears that his
'employers' only visited the house weekly at most. In his submission, if there is no factual connection to
show that the offending behaviour was as a result of compulsion attributable to slavery or trafficking, then a
defence under section 45 is not even raised and the appeal must fail on that ground. Any other alleged
failures by the prosecuting authorities under section 52 and by the defence in not raising the section 45
defence or on abuse of process grounds must also fail.

**Discussion**

27. The offending in this case occurred after section 45 of the Act had come into force on 31 July 2015. In
cases before that date, where the common law defence of duress was not available, the UK had complied
with its duties under the Convention by the use of the abuse of process jurisdiction. This court in _R v_
_Joseph & Ors_ _[2017] EWCA Crim 36 confirmed that the abuse of process jurisdiction was available to deal_
with cases which had been heard before the coming into force of section 45 in 2015. Reliance on this
jurisdiction still requires a 'nexus' to be established between the compulsion aspect of the trafficking or
slavery and the offending. Further, the court observed that the findings of the SCA are not binding but it is
likely that they would be followed by the court 'unless there was evidence to contradict it or significant
evidence that had not been considered' [20].

28. In AAD (supra) at [116] et seq, the court concluded that the jurisdiction was available in cases after the
coming into force of the statutory defence but they would be 'exceptional cases'. As clarified in AAD, it is
permissible in this court to rely on the findings of the NRM to establish status as a victim of trafficking but
an applicant or appellant must go further than that. Being a victim of trafficking, of itself, does not provide a
defence.


-----

29. To succeed under section 45 it is not enough for the applicant to demonstrate that he was a victim of
trafficking. He must also show that he was acting under compulsion **attributable to the slavery or**
trafficking and that a reasonable person with his characteristics would have no reasonable alternative but
to have acted in the same way.

30. We accept the judgment of the FTT and the report of the NRM as tools to assist our consideration of
the issues and we admit the fresh evidence de bene esse. We also have considered the evidence of the
applicant, taking full account of his language difficulties and his dependence on the assistance of an
interpreter.

31. This is a case that turns on its facts. The question at the core of the appeal is, if a defence had been
raised under section 45, is it probable that it would have succeeded? If we find that the actions of the
applicant were not as a result of compulsion then the police did not fail in their section 52 duty and the
prosecution did not fail in its application of the CPS guidance on prosecuting victims of trafficking who
commit criminal acts.

32. Even if we were to accept the applicant's case about being trafficked from Vietnam (and it is not
necessary to come to a final conclusion on that), we have no hesitation in finding that there was no nexus
between the applicant's being trafficked into the UK and his carrying out his function as a cannabis
gardener. This is because at the time of his arrest the applicant had £100 on his person; on the day of his
arrest he also had access to at least £600-700 in cash found in the house; he had a key to the house and
could come and go as he pleased; he had a car which he could drive in which he kept a knife, and he was
not under supervision. These facts are not consistent with a person being compelled to act for the
purposes of trafficking or slavery. Whatever the history of the applicant's journey to the UK (and as
indicated it is not necessary to make findings about that), it is apparent that by the time of his arrest the
applicant was not the subject of compulsion.

33. He could have left at any time. He gave an account of events which was not credible and did not
discharge any evidential burden on him. We also find that no reasonable adult, sharing his characteristics,
would have been left with no reasonable alternative but to act in the way he did.

34.  If we had determined that the defence under section 45 would probably have succeeded then we
would have granted the extension of time. We do not find that the defence would probably have succeeded
and therefore there is no need to grant the necessary extension of time and the application for an
extension of time and for leave to appeal against conviction are refused.

**End of Document**


-----

