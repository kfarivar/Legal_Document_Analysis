# Uhunamure v Belgian Judicial Authority [2021] EWHC 2719 (Admin)

Queen's Bench Division, Administrative Court (London)

Chamberlain J

8 October 2021Judgment

**James Stansfeld (instructed by Sonn Macmillan Walker) for the Appellant**

**Daniel Sternberg (instructed by the Crown Prosecution Service) for the Respondent**

Hearing dates: 7 October 2021

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Mr Justice Chamberlain:**

1 The appellant, Bright Uhunamure, renews an application for permission to appeal against a decision of
District Judge Branston contained in a reserved judgment handed down on 17 March 2021. The judge
ordered the appellant's extradition to Belgium on a European arrest warrant (“EAW”) seeking the
appellant's surrender for trial on six offences said to have been committed in Belgium, Italy, Nigeria and
elsewhere. The offences related to participation in an organisation consisting of Nigerian citizens who
traffic Nigerian women into enforced prostitution.

2 The issues before the judge were: first, whether the particulars in the EAW were sufficient to satisfy s. 2
of the Extradition Act 2003 (“the 2003 Act”); second, whether the offences charged were extradition
offences within the meaning of s. 10 of the 2003 Act; and third, whether extradition was barred by an
absence of a prosecution decision to try under s. 12A of the 2003 Act.

3 The judge rejected each of the appellant's challenges to his extradition. As to the first, the judge set out
the terms of s. 2 of the 2003 Act and the key authorities interpreting it, including in particular _Belgium v_
_Cando Armas_ _[2005] UKHL 67, [2006] 2 AC 1, Zakrzewski v Poland_ _[2013] UKSC 2, [2013] 1 WLR 324,_
_Fofana v France_ _[2006] EWHC 744 (Admin),_ _Ektor v Netherlands_ _[2007] EWHC 3106 (Admin),_ _Pelka v_
_Poland [2012] EWHC 3989 (Admin) and King v France_ _[2015] EWHC 3670 (Admin). He then analysed the_
EAW and concluded that it disclosed sufficient particulars of the circumstances in which the appellant was
alleged to have committed these six offences, including the conduct alleged to constitute the offences. He
set out in his judgment a summary of the relevant circumstances. He then considered the offences
themselves and concluded that the particulars given were sufficient to show how the appellant's conduct
constituted each of the offences for which he was sought. Next, the judge considered whether the EAW
was clear as to timing. In his view it was. As to the place where offences were said to have been
committed, this too was clear. There was no dispute that the relevant provisions of Belgian law had been
specified. He rejected the submission that further information dated 5 February 2021 from the Belgian
prosecutor, which referred to an intention to prosecute the appellant for four offences rather than six,
undermined the judicial authority's case that the information in the EAW was sufficient.

4 As to the second challenge to extradition, the judge set out ss. 10 and 64 of the 2003 Act and
summarised the case law interpreting these provisions. He was satisfied that all of the offences were


-----

extradition offences. His reasoning was as follows. The conduct occurred in the category 1 territory,
namely Belgium, in the sense that the effects of the conduct were intentionally felt there. This was the test
laid down by the House of Lords in Belgium v Cando Armas, which he had cited. The judge went on to say
that the conduct would constitute offences under the law of England and Wales if it occurred here (and if
necessary by way of conspiracy to commit the relevant substantive offence), namely human trafficking for
exploitation contrary to s. 2 of the **_Modern Slavery Act 2015, holding a person in slavery, servitude or_**
forced labour, contrary to s. 1 of that Act, facilitating a breach of immigration law by non-EU citizen,
contrary to s. 25 of the Immigration Act 1971, possessing criminal property contrary to s. 329 of the
Proceeds of Crime Act 2002 and/or concealing or disguising criminal property contrary to s. 327 of the
same Act.

5 The third challenge was rejected but is not pursued on appeal, so I need say no more about it.

6 The appellant appealed in time against the judge's decision on the ground that he erred in three
respects. All these grounds are pursued. Ground 1 is that the judge erred in concluding that the EAW
complies with s. 2(3) of the 2003 Act and that to continue with the extradition would amount to an abuse of
process. Ground 2 is that the judge erred in concluding that the warrant complies with s. 2(4) of the 2003
Act. Ground 3 is that the judge erred in concluding that all the offences in the EAW are extradition
offences, pursuant to s. 10 of the 2003 Act.

7 After the appeal was lodged and notified, the Belgian authorities proceeded with a first instance trial of
six offences, only five of which are particularised in the EAW. There were 15 defendants, some of whom
were present and others not. The appellant was not present, but his lawyer was. The trial began on 5 May
2021 and concluded on 26 May 2021. The appellant was convicted and sentenced to 30 months'
imprisonment, 15 of which were suspended. The appellant contends that this hearing was procedurally
unfair. He appealed and the appeal hearing is listed on 22 October 2021. It appears that the Belgian
prosecutor intends to continue to proceed in the absence of the appellant even if permission is granted and
that the Belgian prosecution authorities do not accept that the first instance hearing took place in the
appellant's absence, since he was represented by a lawyer.

8 In these circumstances, the appellant applies for permission to amend his grounds of appeal to add two
new grounds, 4 and 5. Ground 4 is that, by proceeding with the trial and appeal in the appellant's absence,
the Belgian authority has abused the extradition process in several respects. First, it is said that by
proceeding in Belgium without awaiting the conclusion of the extradition proceedings in this jurisdiction –
including without making any application to expedite the appeal – the extradition process has been
usurped. If the appeal proceeds on 22 October and the appellant is convicted, the conviction will become
final, the accusation EAW will have to be withdrawn and a fresh conviction warrant issued. Second, the
appellant submits that the appellant has been prejudiced. Given the position of the Belgian prosecution
authorities that the appellant has not been convicted in absentia, meaning (Mr Stansfeld submits) that he
would not be entitled to a re-trial if returned after the appeal hearing, he stands to lose his right to attend
his trial simply because he has exercised his right to appeal against the extradition order in this jurisdiction.
Third, the appellant now faces serving a sentence for an offence not among those for which extradition is
sought.

9 At the hearing, Mr Stansfeld refined his argument under this ground as follows. To proceed with an
accusation warrant whilst simultaneously proceeding with a trial and appeal in Belgium before the
proceedings to challenge the warrant are concluded in this jurisdiction is to subject the appellant to
improper pressure to abandon his extradition appeal. If he does not do so, and permission is granted, there
is a risk that he will be convicted without having had a fair opportunity to give evidence in his defence.
Even though he could not be extradited on a conviction warrant unless a guarantee of retrial were given,
he would still have been convicted, with all the consequences that would entail for his ability to leave the
UK, as well as travel and employment more generally.

10 Ground 5 alleges that extradition in these circumstances would expose him to a real risk of a procedure
which is flagrantly unfair.

11 I consider the grounds in turn


-----

12 As to ground 1, Mr Stansfeld notes that the EAW _does not seek the appellant's extradition for_
membership of a criminal organisation, for which he has been prosecuted; and that it _does seek his_
extradition for human smuggling, for which he has not been prosecuted. However, as Mr Stansfeld now
accepts, the Supreme Court's decision in _Zakrzewski shows that events taking place after issue of the_
warrant cannot retrospectively invalidate it for the purposes of s. 2 of the 2003 Act. The safeguard lies in
the abuse jurisdiction. Thus, Mr Stansfeld now argues that there was an abuse, namely continuing to seek
the appellant's extradition for six offences when the criminal proceedings did not pursue all of these
offences and did pursue an offence not in the EAW.

13 Mr Stansfeld relies on the decision in Lewicki v Italy _[2018] EWHC 1160 (Admin) in which the Divisional_
Court (Sharp LJ and Sweeney J) held that it was an abuse of process to extradite the appellant for
offences in circumstances where, by the time of the hearing, he had been acquitted of those offences in
Italy on the ground that the prosecution was time barred and there had been no appeal against the
acquittals.

14 The short answer to this point is that the circumstances of Lewicki were quite different to those of the
present case. In Lewicki, the acquittals were determinations that the appellant could not be prosecuted for
the offences in question as a matter of Italian law. The court concluded that in those circumstances it was
abusive to extradite the appellant for these offences. Mr Stansfeld submitted that _Lewicki_ applied by
analogy to this case. In my judgment, however, it is distinguishable. In this case, there has been no
acquittal and therefore no determination whether the appellant could be prosecuted for the offence as a
matter of Belgian law. In any event, the conviction at first instance does not have the character of a final
judgment. The fact that the proceedings in Belgium omitted one of the offences for which extradition is
sought says nothing one way or the other about whether it is intended to try the appellant for that offence.
The EAW, by contrast, does provide a proper basis for concluding that the Belgian judicial authority has
made a decision to try the appellant for that offence. In those circumstances, it is not arguable that
pursuing the extradition request amounts to an abuse of process. If the appellant is extradited and then not
prosecuted for the offence which was omitted in the first proceedings, there will be no prejudice to him: that
result would be to his benefit. These facts, taken alone, do not give rise to an arguable abuse of the
extradition process.

15 Nor is that conclusion affected by the fact that the proceedings in Belgium included an offence not set
out in the EAW. The appellant has the protection of the specialty provisions. If and when any sentence in
respect of the latter offence becomes final, the Belgian authorities will have to consider whether to execute
it. If they decide to do so, the specialty provisions will require them to make a request under the specialty
provisions. There is nothing to displace the presumption that these provisions will be respected.

16 I have considered the arguments under grounds 2 and 3 in some detail. Although Mr Sternberg for the
Belgian judicial authority had answers to those points, I have concluded that Mr Stansfeld's points, as
adumbrated in his skeleton argument and orally before me, are reasonably arguable. I will therefore grant
permission to appeal on those points and say no more about them.

17 Grounds 4 and 5 both arise from the decision of the Belgian authority to begin and continue extradition
proceedings while at the same time trying the appellant in his absence in the Belgian courts. In my
judgment, the key to understanding that decision is to be found in the statement of Mr Thomas Gillis, the
appellant's Belgian solicitor, which the appellant applied to admit in evidence. I am prepared to admit this
statement, which relates in the main to events post-dating the decision of the judge below.

18 The proceedings in the Belgian courts were against 15 defendants. Some were present and some,
including the appellant, were not. At first instance, the judge took the view that the case should proceed
against all of the defendants. He refused an application on the appellant's behalf to postpone the trial on
the basis that three of the defendants were in preliminary custody. Rightly or wrongly, he declined to sever
the appellant's case from the other defendants.

19 It is the appellant's case that this, and the subsequent notification that the prosecution intend to
proceed with the appeal on 22 October 2021, amount to an abuse. But this depends on the contention that


-----

the current stance of the Belgian authorities puts improper pressure on the appellant. In my judgment, the
contents of Mr Gillis' statement do not support this contention and, indeed, undermine it.

20 Mr Gillis' statement refers at paragraph 9 to an indication from the prosecutor's office that they would
withdraw the EAW if the appellant accepted his sentence. This was said to amount to an attempt to
pressurise the appellant into abandoning his appeal in Belgium. There is no evidence that the appellant
has been affected by any such pressure to date: he has not accepted his sentence and gives no indication
of any intention to do so. In any event, the pressure upon which Mr Stansfeld relied in his oral submissions
was of a different kind: pressure to abandon his appeal against extradition in this jurisdiction. But there is
no evidence that he is subject to this kind of pressure either.

21 In paragraph 13 of his statement, Mr Gillis refers to a decision of 7 April 2020 by the highest court in
Belgium, the Hof van Cassatie, in a case concerning an individual on bail in the UK that “the jurisprudence
of the European Court of Human Rights, but also the bare legal principle of the right on a fair trial, require
that a person is given the possibility to attend a trial, and the fact that he is released on bail in the UK
awaiting the further extradition procedure nor the fact that he has the right to be represented by a lawyer in
Court in Belgium does not in any way take this fundamental right away from him”.

22 At this stage, it is not known how the appeal court will respond when this case is cited to them, as Mr
Gillis has confirmed it will be. On its face, the evidence of Mr Gillis suggests that Belgian law confers on the
appellant a right to be present in person at his trial. This is not surprising in a jurisdiction where Article 6
ECHR applies. But if the appellant _were finally convicted after a trial at which he was not present, that_
result would have been achieved because of the operation of Belgian law and the decisions of the Belgian
courts, not by abuse of the extradition procedure in this jurisdiction. In that case, any remedy would lie in
Belgium, not here.

23 It is also relevant that, if the appellant were finally convicted without having been present at a trial, and
the Belgian authorities sought his extradition pursuant to a conviction warrant, they would have to give a
retrial guarantee because of s. 20 of the 2003 Act.

24 For these reasons, I conclude that it is not reasonably arguable that the current stance of the Belgian
authorities in proceeding with the appeal give rise to an abuse of process.

25 Ground 5 is, in my judgment, also unarguable. Although it is true that the first instance judge proceeded
in the appellant's absence, that decision must be seen in the light of the fact that – as the judge would have
been well aware – any conviction would not constitute a final judgment. In the light of the authority referred
to in paragraph 13 of Mr Gillis's statement, and the presumption that Belgium will comply with its
obligations under Article 6 ECHR, it is not possible to say that there is a real risk that the appellant will be
subject to a procedure which is flagrantly unfair by virtue of being finally convicted in his absence. The
contrary is not reasonably arguable.

26 For these reasons, permission is granted on grounds 2 and 3 and refused on grounds 1, 4 and 5.

**End of Document**


-----

