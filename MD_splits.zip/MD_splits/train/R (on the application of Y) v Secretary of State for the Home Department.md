# R (on the application of Y) v Secretary of State for the Home Department 

 [2021] EWHC 2155 (Admin)

QBD, ADMINISTRATIVE COURT

CO/4789/2020

Linden J

Tuesday, 29 June 2021

29/06/2021

MR JUSTICE LINDEN:

Introduction

1. By order of Mr David Pittaway QC, dated 21 April 2021, the claimant's application for permission to claim judicial
review, and for an order pursuant to CPR Part 18, was adjourned to be considered at this hearing.

2. Mr Berry appeared for the claimant and Miss Emily Wilsdon appeared for the defendant.

Background

3. The claimant is a Sudanese national. He arrived in the United Kingdom, having been intercepted in a boat in the
English Channel, on 29 September 2020. On arrival, he claimed that his date of birth was 17 November 2003,
making him 16, but he was assessed as being at least 25 years of age and assigned a date of birth of 17 November
1994. He was served with illegal entry papers, claimed asylum and was detained.

4. An initial screening interview took place on 3 October 2020 whilst the claimant was at IRC Yarl's Wood. In the
registration questionnaire, in relation to that interview, he is noted as having given a date of birth of 17 November
1994, although I am bound to say that that entry is an odd one given that this was his assigned date of birth and, of
course, not the date of birth that he had claimed on entry. The registration questionnaire also notes the claimant as
saying that he had used another date of birth, namely, 17 November 2003, and that, of course, was the date of birth
that he claimed on entry.

5. On 4 October 2020, a EURODAC search indicated that the claimant had previously claimed asylum in Malta on
22 August 2020 and in Germany on 26 August 2020. The outcome of these applications is unknown, on the
evidence at least, but the defendant says, with some justification, that the inference is that he absconded during or
at the end of the process of applying.

6. An induction interview was conducted at Colnbrook on 5 October 2020, with the aid of an interpreter, at which
the GCID case records state that the claimant said that his age was as per the CID records; that is, 25 or over.
Again, this is an odd entry given the age that the claimant maintained on entry to the United Kingdom.

7. On 6 October 2020, the claimant was transferred to Brook House.

8. On 8 October 2020, the defendant submitted a request to Germany and to Malta, pursuant to Article 18.1 of the
Dublin III Regulation.


-----

9. On 14 October 2020, the claimant was notified that Germany had accepted that it was the state responsible for
considering his application for asylum and that it had confirmed that the claimant had been accepted for return. The
claimant's date of birth in the documents from Germany was given as 1 January 2001, on which basis he was
nearly 20 on entry to the United Kingdom at the end of September 2020.

10. On 15 October 2020, an NRM referral was made by the defendant in respect of the claimant.

11. On 17 October 2020, a Rule 35 report was submitted and a review of the claimant's case was conducted, in the
light of this report, on 20 October 2020. The claimant was accepted by the defendant as an adult at risk level 2 on
the basis of evidence of torture. However, his detention was maintained owing to the imminence of his removal and
the risk of absconding.

12. On 21 October 2020, a negative reasonable grounds assessment was made in relation to the claimant's
trafficking claim. In broad summary, the assessment accepted that there was evidence of torture, that he had been
transported and that threats and violence had been used against him, but found no evidence of his being required
to carry out forced labour, or of an intention that he would be, or of any other form of exploitation. He, therefore,
could not satisfy this element of the definition of “trafficking”.

13. On 28 October 2020, the claimant was served with directions for his removal to Germany on 5 November 2020.

14. On 29 October 2020, the defendant received a letter before action, which attached a letter from Medical Justice
dated 28 October 2020, an undated letter from a Dr Elizabeth Ashford/Clark and a reasonable grounds decision
dated 8 October 2020. As a result of this, on 31 October 2020, removal directions were deferred, given that a
human rights claim had been made in the letter before action.

15. I understand that, on 2 November 2020, removal directions were reset for 24 November 2020.

16. On 6 November 2020, the defendant was notified that West Sussex County Council had been requested by the
claimant's representatives to carry out an age assessment and that the West Sussex multi-agency safeguarding
hub had said that they would provide him with accommodation pending that assessment. In the light of this
information, the claimant was released on 9 November 2020. Given that he was to undergo a more formal age
assessment process, his removal was held no longer to be imminent and detention, therefore, was no longer
deemed to be appropriate.

17. On 18 December 2020, Mr David Christie-Davies, a senior social worker in the children's asylum team at West
Sussex County Council, wrote to say that the Council would not be undertaking an age assessment in relation to
the claimant after all. The reasons which he gave for that decision included the following:

.

“We have no substantive evidence that Ahmed is not his stated age of 17. He maintains that he has always stated
that this date of birth is 17/11/2003 and he provided UKBF when he first arrived in the UK, but UKBF ignored this
and assessed Ahmed as being significantly over the age of 25.

In consideration of Age Assessing Ahmed, he has had a period of observation by his Support Workers and other
professionals involved in his care since he was placed with us on the 05/11/20.

The observations covered Ahmed's physical appearance, presentation and his social interaction with his peers and
adults, whilst also considering the level of independence that he is presenting.

The observations from his support workers did not indicate that Ahmed was significantly over his stated age of 17
years and his interaction with other young people, support staff and other professionals was considered age
appropriate during observations. I have now had considerable contact with Ahmed both directly and indirectly and
from my own observations, Ahmed has given me no reason to believe that he is an adult and not the age that he is
claiming to be.


-----

As per statutory guidelines, our local authority does not subject young people to age assessments unless we have
significant evidence that they much older than they claim to be, which is not the case regarding Ahmed.”

I note that Mr Christie-Davies' position was reiterated in materially the same terms in a letter dated 1 March 2021,
which was put before the court.

18. Continuing with the chronology, on 22 December 2020, proceedings were issued. On 3 February 2021,
Summary Grounds of Defence were lodged. A request for further information pursuant to Part 18 was made by the
claimant on 17 February 2021 and a Reply was filed on 9 April 2021.

The claim for judicial review

19. The claimant challenges three aspects of his treatment since his arrival in the United Kingdom. First, he
challenges the decision that there were no reasonable grounds to find that he was a victim of trafficking; secondly,
he challenges the initial assessment of his age on arrival in the United Kingdom; and, thirdly, he claims that his
detention between 29 September and 9 November 2020 was unlawful.

The challenge to the no reasonable grounds decision

20. In the pleaded case, the defendant's decision that there were no reasonable grounds to conclude that the
claimant was a victim of trafficking is said by the claimant to be irrational, in that there was evidence on the basis of
which a reasonable observer could believe that he had been the victim of trafficking. Secondly, it is said that, in
relying on the screening interview alone, the defendant acted in breach of her policy “Statutory Guidance Under the
**_[Modern Slavery Act 2015” (V1.02) dated August 2020.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**

21. In writing and in his oral submissions, Mr Berry referred me to the definition of “trafficking” in Article 4 of the
European Convention on Action Against Trafficking in Human Beings (“ECAT”) which is as follows:

“(a)'Trafficking in human beings' shall mean the recruitment, transportation, transfer, harbouring or receipt of
persons, by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of deception, of
the abuse of power or of a position of vulnerability or of the giving or receiving of payments or benefits to achieve
the consent of a person having control over another person, for the purpose of exploitation. Exploitation shall
include, at a minimum, the exploitation of the prostitution of others or other forms of sexual exploitation, forced
labour or services, slavery or practices similar to slavery, servitude or the removal of organs; (emphasis added)

(b) The consent of a victim of 'trafficking in human beings' to the intended exploitation set forth in subparagraph (a)
of this article shall be irrelevant where any of the means set forth in subparagraph (a) have been used”

22. In his oral submissions, although not in his pleaded case, Mr Berry emphasised the words “at a minimum” in
the last four lines of limb (a) of the definition. Mr Berry also referred to Articles 10 and 13 of ECAT and to Articles 2
and 11 of the Anti-Trafficking Directive, and he relied on passages from the judgment of Miss Helen Mountfield QC
in H v. Secretary of State for the Home Department [2015] EWHC 1725 at paras.53 and 69 to 78. That decision
[was overturned by the Court of Appeal in a decision, the Neutral Citation for which is 2016 EWCA Civ 565, but, on a](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5K28-G3W1-F0JY-C53G-00000-00&context=1519360)
brief perusal of the decision, it does not appear that the Court disapproved of the approach to the Article 4 definition
suggested by Miss Mountfield QC. That approach emphasises - and I accept at least for present purposes that it is
arguable – that:

a. The reasonable grounds decision gives rise to an objective question, namely, whether the evidence provides
grounds upon which a reasonable observer could believe that the individual is a victim of trafficking. The threshold
is the low one of suspicion rather than proof, bearing in mind the relevant guidance.

b. Secondly, and importantly, the question whether there are reasonable grounds may be answered in the
affirmative, notwithstanding that there may be reasonable grounds to conclude that the individual was not a victim
of trafficking. That is because of the relatively low threshold which a claimant needs to get over, at least at this
stage of the assessment of whether they are a victim of people trafficking.


-----

c. Thirdly, a decision maker, and indeed the court, should not readily conclude that there are no reasonable
grounds to conclude that the individual is a victim of people trafficking, merely because there may be gaps in the
evidence or inconsistencies, particularly bearing in mind the period for reflection which follows the decision during
which a closer examination of the facts can take place.

23. Mr Berry also referred to paras.3.5, 14.50 and 14.72 of the Statutory Guidance which I need not set out.

24. The relevant part of the defendant's no reasonable grounds decision sets out a summary of the claimant's
account. It notes that he says that he was captured by people wearing face coverings on the way to Tripoli in Libya
and they put a cloth over his head. They took him to a small room and forced him to call his mother for a ransom of
$30,000. The note records that the claimant had said that he was not forced to work or to commit any crimes:

“The description of Forced Labour is contained in the decision annex attached to this letter. You said you were not
forced to work or commit a crime of any sort. The treatment you received and that you were forced to call your
family for money has been acknowledged, however, it is considered that this is an attempt to extort money from you
and is not indicative of forced labour. From the information provided there is no indication that you were forced to
do anything against your will (with the exception of calling your family), and it is considered that the account
provided is dissimilar to the descriptions of forced labour as noted above. There is no information to suggest that
you were subjected to any other type of exploitation.”

25. I asked Mr Berry to show me the evidence of exploitation, which provided reasonable grounds to believe that
the claimant was the victim of trafficking, and he took me to two passages in the screening interview:

“IO: How did they torture you?

App: I was travelling from Bani Walid to Tripoli when a group of gangsters covering their face put something over
my head and told me 'come with us'. They took me to a place inside a small room, told me to call my family and
father and said to give them $30,000 USD. I told them my father was dead and they told me to call my mother.”

Mr Berry also relied on the question and answer at 7.14:

“IO: Can you describe what happened on a typical day?

App: They used to give me 1 piece of bread and 1 cup of water every day. As well there was torture. They didn't do
anything else to force us to get in touch with our family for ransom.”

26. As I have noted, in his oral submissions Mr Berry in his oral submissions emphasised the words “at a minimum”
in the definition of trafficking and he argued that, therefore, the list of matters which the concept of exploitation is
required to include is not exhaustive. He argued, therefore, that kidnapping somebody with a view to holding them
for ransom fell within, or ought to fall within, the concept of exploitation for the purposes of the Article 4 definition.

27. In my view, the short answer to this ground is that there is no evidence of the exploitation element of the Article
4 definition. There is no evidence of that in the screening interview, nor is there in the Statement of Facts and
Grounds, nor is any such evidence provided in the claimant's witness statement, which was apparently prepared
with the assistance of lawyers, and nor, indeed, was any such evidence, or were any such facts, pointed to in the
Reply which was filed by the claimant.

28. Mr Berry's argument, based on the words “at a minimum”, was introduced into the case for the first time in his
oral submissions. That does not mean that I decline to consider it on its merits, but, in my view, that argument does
not get close to establishing that the decision that there were not reasonable grounds in this case for concluding
that the claimant was a victim of trafficking was irrational. Essentially, that is for two reasons:

a. I accept Miss Wilsdon's submission that, although the words “at a minimum” indicate that the concept of
exploitation, as stated in Article 4, is not an exhaustive definition, one can have regard to the matters that are then
listed as, as it were, examples: the exploitation of the prostitution of others or forms of sexual exploitation, forced
labour or services, slavery or practices similar to slavery, servitude or the removal of organs. I do not accept that


-----

kidnapping someone and requiring them to phone their mother to ask for a ransom falls within the concept of
exploitation, as contemplated within Article 4 of the definition.

b. But, even if that is wrong, one has to read the whole of the definition, which refers to individuals being recruited,
_transported, transferred, harboured or received for the purposes of exploitation. Again, in my view, there is no_
evidence which would go close to establishing that it was irrational for the NRM to come to the conclusion that there
were no reasonable grounds to hold that the whole of the definition in the present case was satisfied.

29. For those reasons, I dismiss the ground which challenges the decision that there were no reasonable grounds
for considering that the claimant was a victim of people trafficking.

The challenge to the initial age assessment

30. With respect, this aspect of the claim lacks focus and obscures what I consider to be the only arguable point.
The challenge to the initial assessment of the claimant's age is pleaded on the basis of irrationality. Various points
are made at paras.42 to 49 of the Statement of Facts and Grounds under the heading “Grounds for judicial review”.
It is said that:

a. The assessment was made before the screening interview and appears to have been made purely on the basis
of physical appearance and demeanour;

b. As regards physical appearance, there is no evidence that various (what the pleading calls) “factors” were
considered. Those factors are as follows:

“(i) ethnicity and genetic background,

(ii) opportunities to manage their basic physical health and self-care needs,

(iii) that with good care and some recovery time, the claimant's physical appearance may appear younger within a
short period of time,

(iv) nutrition and illnesses that can affect physical appearance, and

(v) that children in some countries are more likely to have engaged in physical work.”

c. Similarly, in relation to demeanour, there is no evidence of consideration of:

“(i) trauma, post-traumatic stress disorder (PTSD) and depression may affect the claimant's demeanour, especially
for those who have been tortured,

(ii) that some young people take on responsibilities normally associated with adulthood at an earlier age,

(iii) the effect of the claimant's culture on their interaction,

(iv) the journey, which may have been long and traumatic,

(v) the Claimant's level of understanding of what is going on and language barriers,

(vi) and the short period of time for observation.”

d. The claimant's age should have been reconsidered on receipt of the Dublin III acceptance letter from Germany
dated 14 October 2020, which gave a date of birth of 1 January 2001. If the age in the German records had been
accepted, it is said, then the claimant would have been a little under 20 when he arrived and should have been
given the benefit of the doubt. Reliance is also placed on an unsigned half-page document from a Ms Ellen
Bennington from Care4Calais dated 25 November 2020 and it is alleged that failing to take information of the sort
received from Germany is a practice of the defendant.


-----

31. Elsewhere in the Statement of Facts and Grounds at para.41, as part of the legal framework section, it is
suggested that assessment of asylum seekers as being significantly over the age of 25 is happening routinely and
that it appears that quick and inadequate visual assessments take place without interview and that any decision as
to age thereafter stands until such time as the local authority undertakes a proper assessment. There are also
references to the assessment in the present case being perfunctory, and there is then reference to the Care4Calais
document date 25 November 2020.

32. In the section headed “Background facts”, particular emphasis is placed on the fact that West Sussex is not
disputing the claimant's professed age of 17. At para.40 of the Statement of Facts and Grounds, the claimant then
pleads as follows:

“If a claimant is detained, but a court later find that the claimant whom the Defendant has treated as an adult was a
child, even if she reasonably believed that the individual was an adult, any period of detention whilst that person
[was in fact a child may be unlawful, see R(TN) v Secretary of State [2020] EWHC 481 (Admin).”](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5YBY-6BM3-CGXG-02XT-00000-00&context=1519360)

The claimant's reply then pleads at para.10,

“The defendant's summary defence does not engage with the submission that, as the claimant is a child, he has
been unlawfully detained”.

Paragraph 12 makes, essentially, the same point by reference to R(on the application of) AA (Sudan) v. Secretary
_of State for the Home Department [2016] EWHC 1453 (Admin.), albeit that case also went to the Court of Appeal,_
on which occasion the decision was approved.

33. At the beginning of the hearing, I raised with the advocates my provisional view that the real point in this case is
the point which arises out of the decision of the Court of Appeal in R (on the application of) AA (Sudan) v. Secretary
_of State for the Home Department [2017] EWCA (Civ.) 138, where the Court of Appeal held that, under paras.16 to_
18 of Schedule 2 to the Immigration Act 1971 - which deal with the Secretary of State's powers of detention in
respect of adults and minors, respectively - the question whether a given person is a child is a question of
precedent fact. If they are an adult, then the usual principles in relation to unlawful detention apply; if they are a
child, then there is provision for them to be detained for a period of up to 24 hours but no longer. The fact that the
issue of the age of the individual is one of precedent fact seems to me to mean that the test for the purposes of
permission must be that laid down by Sir Anthony May in R (FZ) v. London Borough of Croydon _[2011] EWCA Civ_
_59, namely, whether the material before the court raises a factual issue which, taken at its highest, could not_
properly be decided in the Claimant's favour at a contested factual hearing. If, on the other hand, the claimant
could, on the material before the court, succeed in showing that they were aged under 18 during their period of
detention, then permission should be granted.

34. Miss Wilsdon helpfully indicated that she agreed with that analysis and Mr Berry did not dissent either. As I put
to Miss Wilsdon in the course of her submissions, it means, in effect, that the question in relation to permission, for
the purposes, at least of the precedent fact issue, is whether the claimant's case that he was aged under 18
throughout the period of his detention is bound to fail on the materials before the court.

35. Even applying the relatively low threshold stated by Sir Anthony May, the question of permission in the present
case is not straightforward.

a. As I have indicated, two officers considered the claimant's demeanour and appearance and assessed him as
being aged over 25;

b. Secondly, the claimant does not actually give evidence of his age in his witness statement or explain why a court
or a tribunal should accept that his date of birth was 17 November 2003;

c. Thirdly, the evidence suggests that he did claim that this was his age when he arrived on 29 September 2020,
but there is some evidence that he may not have made that claim at his interviews on 3 and 5 October 2020, as I


-----

have indicated. There is also evidence that he told the German authorities in August 2020 that he was born on 1
January 2001.

36. All of these matters enabled Miss Wilsdon to make a powerful submission that I could take the view at this
stage that the claimant's case in relation to his age was bound to fail. On balance, however, I conclude that I am
not able to take such a firm view on the materials before me. In this regard, I accept Miss Wilsdon's submission
that the documents from West Sussex County Council, dated 18 December 2020 and 1 March 2021, do not
unequivocally state that the claimant's date of birth was, indeed, 17 November 2003 or, more realistically, that he
was, indeed, under the age of 18 at all at material times, including at the time of the two documents. I agree with
Miss Wilsdon that there are indications in the letters written by West Sussex County Council that they have decided
pragmatically that, since they do not have powerful or objective evidence with which to contradict the claimant's
case as to his age, they have applied what appears to be the Council's policy of not subjecting the individual to the
age assessment process.

37. Having said that, I am influenced by the fact that Mr Christie-Davies is a senior social worker working in the
children's asylum team. I do not read his letter as simply saying that, “We would never ultimately be able to prove
that the claimant 's age was older or that the claimant was an adult and, therefore, we have not tried”. I am
particularly influenced by the penultimate paragraph in the passage which I have set out already in my judgment,
where he states that, the team having made observations, and he himself having made observations in relation to
the claimant's interaction with other young people, support staff and other professionals, it was considered that the
claimant's approach was “age appropriate” during the observations. That appears to me to suggest that the Council
was taking the position that the claimant was acting consistently with his claimed age. If one then goes back to the
evidence which is said to be against the claimant, the assessment of the two officers appears to have been carried
out relatively swiftly - that is relative to the observations which the Council has been able to make - and their
conclusion appears to be a very long way from that of the Council, in that they appear to have taken the view that
he was clearly aged over 25. Here, arguably the gap between the two assessments undermines the reliability of the
officers' assessment, although I accept that there is a degree of circularity about this point.

38. Other than that, the defendant's case in relation to evidence that the claimant was an adult is based on entries
in the records of 3 October and 5 October 2020, which may be capable of an explanation other than that which is
given by the defendant. There is, of course, also what the claimant told the German authorities, but it is a familiar
experience for asylum seekers to give different accounts of their dates of birth only for the conclusion later to be
that their age was, indeed, under 18 at the material time.

39. For all of those reasons, I do not feel able to say that the permission should be refused in relation to the issue
of the claimant's age and it would follow from that that permission should be granted in relation to the issue of
unlawful detention, at least on the basis that it is arguable that the claimant was a child during the period of his
detention. Ultimately Miss Wilsdon, whilst ably contesting the proposition that there are materials to show that the
claimant was under the age of 18 at the material time, accepted those consequences in the event that I did not
agree with her.

40. That leaves the question whether there should be permission in relation to any of the other arguments
advanced by or on behalf of the claimant. I asked Mr Berry whether he would accept, for example, that the
question of the rationality or otherwise of the officers' decision became academic if permission were to be granted
in the way in which I have granted it. Having taken instructions, he indicated that he wished to pursue all of the
points that he has pleaded and, therefore, I will deal with them briefly.

41. Dealing, first, with the question of the rationality or otherwise of the immigration officers' assessments of the
claimant's age on 29 September 2020, I have been taken to various passages in the defendant's Guidance entitled
“Assessing age” Version 3. For present purposes, it is sufficient to note the passage at p.291:

“Due to a recent Court of Appeal judgment and subject to any further consultation that the Home Office engages in,
it is the Home Office's interim policy position, that for a person to be assessed as an adult in these circumstances,
their physical appearance and demeanour must very strongly suggest that they are 25 years of age or over. This


-----

interim policy position is without prejudice to any position which the Home Office maintains in ongoing legal
proceedings and/or reaches following any consultation carried out”.

42. The document also provides further guidance for those carrying out the assessment, requiring them to apply
the benefit of the doubt and stating, in terms, that, where there is uncertainty about whether an individual is an adult
or a child, they should be treated as a child and referred to the local authority with a request for a Merton compliant
age assessment. The Guidance also sets out, at internal pp.13 to 15, factors which may be relevant to the
assessment of physical appearance and demeanour and, in short, the factors in question are largely the factors
pleaded by Mr Berry in the Statement of Facts and Grounds, which factors he alleges for the purposes of his
irrationality challenge, the officers failed to take into account. The Guidance also requires the assessment to be
carried out by two officers, the second of which must be of no lower rank than Chief Immigration Officer, and it
requires them both to make separate assessments based on their personal observations of the individual
concerned.

43. The current Guidance was amended following the decision of the Court of Appeal in BF(Eritrea) v. Secretary of
_State for the Home Department [2019] EWCA (Civ.) 82. It is to be noted that it states more than once that the_
person's physical appearance and demeanour must “very strongly” suggest that they are 25 years old or over.

44. In his Reply, the claimant confirms that this Guidance is not challenged, although its application is. In answer
to a question from the court, Mr Berry also confirmed that nor is the claimant seeking to mount a systemic challenge
against the defendant's approach in relation to these matters. He confirmed, therefore, that this case concerns the
particular decision taken in the claimant's particular case, albeit, he says, evidence about other cases may be
relevant to that question.

45. In the present case, the evidence, in the form of the assessing officer's report in relation to the claimant, states
that, in accordance with the Statutory Guidance, two immigration officers of the requisite rank carried out separate
assessments of the claimant's age and determined that his physical appearance and demeanour very strongly
suggested that he was 25 years of age or over and that, as no other credible evidence existed to the contrary, he
was, therefore, assigned a date of birth of 17 November 1994. Both assessing officers' assessments were
undertaken after they interacted with the claimant or after they had observed his interaction with others.

46. Mr Knott, who is a chief immigration officer, provides further explanation at p.733 of the bundle as follows:

“During the initial collection of information the applicant stated that he was .17 years of age. Assistant Immigration
Officer Oliver Eastwood believed that the applicant was older than 17 years of age. All assessments begin with
initial impression made from visual presentation. An initial impression of age range is formed based on height, facial
features including facial hair, skin line/folds, etc; voice tone, and general impression. I therefore looked at the
applicant to be satisfied with the assessment. In the absence of documentary evidence and based on his size, facial
features (specifically) alongside his facial hair growth (prominent even when shaved), muscularity, behaviour and
my own experience. I am fully satisfied that he is 25 years of age or older ( around 26 years of age). Based on the
assessment I am in agreement with Assistant Immigration Officer Eastwood that the applicant is at least the 25
years of age stated and he will be registered on our system as such. Photograph retained on file. IS97M and BP7
have both been completed and issued as appropriate. Age Dispute Flag raised on CID and special conditions
updated.”

47. The claimant was also told in Arabic that his age was disputed and he was provided with the standard form
letter (IS97M), which notifies him that the decision at that stage does not prevent him from approaching his local
authority's children's services department with a view to them undertaking their own assessment of his age.  The
letter then provides further guidance in relation to that matter.

48. I do not accept that it is arguable that the immigration officers' decision in this case amounted to an irrational
application of the Statutory Guidance and/or a decision which was irrational on the basis that there had been a
failure to take into account the relevant considerations identified in the Guidance. There is no positive evidence that
they failed to take this into account, for example, in the form of cogent evidence from the claimant that would
demonstrate that the factors were strongly in play in his case or that they had been drawn to the individuals'


-----

attention and yet they had been ignored. The officers in the present case carried out an initial assessment and they
provided the claimant with the information that he needed to challenge it, which in due course he did.

49. Nor do I accept that there was an obligation to review the issue of the claimant's age when the documents
emanating from Germany on 14 October 2020 stated that his date of birth was 1 January 2001. This date meant
that he was nearly 20 when the initial assessment was carried out at the end of September and, therefore, an adult.
Had there been further enquiries, as Mr Berry advocated, an email dared 21 April 2021 from a Mr Foerster, who is
an immigration officer in the German Federal Office for Migration and Refugees, states that 1 January 2001 was the
claimant's claimed date of birth and that this was not disputed (i.e. the claimant's own position was that he was an
adult).  Therefore, greater curiosity, as advocated by Mr Berry, it appears, would not have improved the claimant's
position, particularly in relation to the question of detention.

50. The substantive decision of West Sussex on which the claimant relies, and on which I have relied in giving
permission to the extent indicated, was not known during the period of the claimant's detention. But, in any event,
the claimant's social worker makes clear that no Merton compliant age assessment has been carried out in his
case. That position was, as I have indicated, reiterated by Mr Christie-Davies. The position of West Sussex, on or
after 18 December 2020, does not demonstrate that the assessment carried out by the immigration officers on 29
September 2020 was irrational, albeit, as I have indicated, it may be relied upon by the claimant as evidence that
that assessment was wrong.

51. The Care4Calais document dated 25 November 2020 does not take matters further. As I have indicated, it is
an unsigned half-page document. It runs to four paragraphs. What one can derive from it is that Care4Calais has
assisted 500 individuals in relation to the relevant project since July 2020: 21 of these have been, in the view of
Care4Calais, unaccompanied asylum-seeking children. In the case of at least 18 of the 21, the individuals have
claimed that they were incorrectly age assessed upon arrival, and 15 of the 18, it appears, were assessed as being
25 years old. That information, with great respect, does not bear on the particular decision taken in the claimant's
case at all. Nor, if there were a systemic challenge pleaded, would it come even close to establishing a basis for
such a challenge. Given that, the evidence does not demonstrate anything relevant to the present proceedings. It
merely demonstrates that Care4Calais has come across 18 cases where individuals have claimed that they were
wrongly age assessed. If there were evidence that, in fact, they were wrongly age assessed, and that there are
many other cases of this sort, that might begin to move towards the sort of situation where a systemic challenge
could be mounted, but there would be a lot further to go and, as I have indicated, Mr Berry confirmed that he was
not pursuing such a challenge.

52. In coming to a view about the rationality challenge, I have also taken into account a letter from PAFRAS dated
12 March 2021 on which the claimant seeks to rely. That letter provides evidence in relation to three other cases
where it is suggested that the relevant unit made assessments which subsequently proved to be wrong. Again,
that, taken on its own or combined with the Care4Calais information, does not begin to establish a case of systemic
failing which the court could entertain and, in any event, such a claim is not pleaded or pursued.

53. For all of those reasons, I would refuse permission to mount a challenge to the rationality of the immigration
officers' decision of 29 September 2020 as to the claimant's age. Such a challenge is not reasonably arguable.

54. In addition to this, I accept that such a challenge is academic. It is academic, essentially because the relief
sought in relation to the age assessment challenge (that is Ground 2) is to quash the decision of the immigration
officers, but, as I pointed out in the course of argument, things have obviously moved on. The question whether or
not that decision was irrational and/or should be quashed will not affect the decision on unlawful detention. As I
have indicated, if, on the balance of probabilities, the claimant was aged under 18 at all material times, then this
claim for unlawful detention will succeed. If, on the other hand, he was an adult, then his claim for unlawful
detention will not succeed on the basis that the decision of 29 September 2020 was irrational. If it succeeds at all, it
will succeed on the basis of what his age is actually determined to be.

55. For all of those reasons, I dismiss the rationality challenge to the age assessment.


-----

56. As far as Ground 3, unlawful detention, is concerned, Mr Berry pursues the argument that there was unlawful
detention, even if the court ultimately concludes that the claimant at the time of his detention was an adult. It has
therefore fallen to me to consider whether permission should be granted to pursue that line of argument as opposed
simply to the argument that there was unlawful detention on the basis of his being a child.

57. Having considered those arguments, I have concluded that I am not going to shut Mr Berry out from running
the arguments on an alternative basis. It appears to me at this stage that the arguments, other than the argument
on the basis that the claimant was a child, do not have particular merit. It appears that there was a basis on which
the decision makers could conclude that there was a significant risk of absconding in this case. It also appears to
me that the matter was kept under regular review and that, by the time there was evidence of significant concerns in
relation to the claimant's mental health, his removal was imminent and, therefore, decisions to continue his
detention were justifiable. Having said that, and therefore having given a clear indication that the strength of the
unlawful detention case, if it has any strength, must be founded upon the proposition that he was a child at all
material times, I do not at this stage refuse permission to run the wider argument. I decline to close the argument
out, essentially, because one does not know, ultimately, what the findings of fact will be as to the claimant's true
age, his level of maturity and so on and it might be that there were unfortunate and unforeseen consequences of
my saying that, in the event that it was concluded that he was a shade over 18 at the relevant time, it necessarily
followed that his detention was lawful.

58. Having given that indication on the merits, I have concluded that I will, nevertheless, grant permission to the
claimant for unlawful detention to go forward on both bases.

___________

**End of Document**


-----

