Department [2016] EWHC 1912 (Admin)

# R (on the application of TDT, by his litigation friend, Topteagarden) v
 Secretary of State for the Home Department [2016] EWHC 1912 (Admin)

Queen's Bench Division, Administrative Court (London)

McGowan J

29 July 2016Judgment

**Mr Chris Buttler (instructed by Simpson Millar LLP) for the Claimant**

**Mr Gwion Lewis (instructed by** **The Government Legal Department) for the** **DefendantHelen**
**Mountfield QC** and Nick Armstrong (Instructed by the Equality and Human Rights Commission) for the
**Intervener**

Hearing dates: 20/04/2016 and 28/04/2016

- - - - - - - - - - - - - - - - - - - - 
- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Mrs Justice McGowan:**

1. The Claimant, (“TDT”), is a national of Vietnam. His age is in dispute. This challenge is brought on his
behalf by his litigation friend, Tara Topteagarden, **(“TT”). She is the Trafficked Boys' Advisor at the**
Refugee Council. The decision under challenge was taken on 6 November 2015 in which the Defendant
**(“SSHD”) released him from administrative detention without first putting safeguarding measures in place.**
It is said that the Defendant is in breach of her positive duty under Article 4 of the European Convention on
Human Rights and the Convention on Action against Trafficking in Human Beings; that she was or ought to
have been aware of credible grounds to suspect that the Claimant was the victim of trafficking and she was
wrong to dispute his age. The Equality and Human Rights Commission **(“EHRC”) has been given**
permission to intervene, its concerns are with the wider issues of the State's positive obligations to putative
victims of trafficking and, in particular, the treatment of children who may be the victims of trafficking. It
supports the claim for declaratory relief. The Defendant resists the claim, arguing that there were not
circumstances giving rise to a credible suspicion of trafficking in the specific case of the Claimant; that the
claim is academic and, in any event premature, as the Claimant is still missing and no 'conclusive grounds'
decision has yet been made. West Sussex County Council (“the Local Authority”) and Kent Police (“the
**Police”) were joined as the First and Second Interested Parties respectively but ceased to be Interested**
Parties on 30 November 2015.

2. A very large number of issues have been raised in the case. I have not determined every point. Whilst I
have considered all points canvassed and argued, I have only made findings on those matters necessary
to determine the claim.

_The Background_


-----

Department [2016] EWHC 1912 (Admin)

3. On 8 September 2015 the Claimant was found by Police officers in the back of a lorry in Kent. A number
of other males were found at the same time. In total there were 16; 4 from Syria, 4 from Iran, 1 from Iraq
and 7 from Vietnam. He was detained at Dover Immigration Removal Centre under paragraph 16 of
schedule 2 Immigration Act 1971 on the stated grounds, “There is insufficient reliable information to decide
_whether to grant you temporary admission or release” and “You have not produced satisfactory evidence of_
_your identity, nationality or lawful basis to be in the UK.” On 10 September Form IS97M was completed_
and it was determined that he would be treated as an adult because it was said, _“Your physical_
_appearance/demeanour very strongly suggest that you are significantly over 18 years of age.” He had_
claimed that his date of birth was 5 December 1999.

4. Three of the Vietnamese males who had been found in the same lorry and detained had gone missing
by 28 October, two remained missing as at 6 November; one had left his foster placement but had returned
there.

5. The Claimant was, at that time, represented by the previous firm of solicitors. They sought his
temporary admission into the UK on two occasions and challenged the assessment of him as being over
18. The question of his being the victim of trafficking was not raised until 23 October. His current solicitors
were instructed on or by 23 October.

6. On 28 October TT, who has expertise in the trafficking of children, made a formal referral to the UK
Human Trafficking Centre stating that, in her opinion, there was reason to believe that he was a victim of
child trafficking. She was certified as his litigation friend on 3 November.

_History of the Proceedings_

7. On 29 October a pre-action protocol letter was sent to the Defendant asking for release of the Claimant
but not before stringent safeguarding measures had been put in place. The letter set out a number of
concerns relating to the high incidence of trafficking amongst Vietnamese teenaged children and young
adults. It proposed a meeting to include the Local Authority and the Police and that a plan to prevent
trafficking or re-trafficking should be drawn up before his release. There was no reply.

8. On 6 November a claim for Judicial Review and urgent relief was issued. That claim sought the release
of the Claimant from detention “but only on terms that will minimise the risk of him being re-trafficked”. It
was claimed that there was strong evidence that the Claimant was a child victim of trafficking. Urgency was
sought because he was detained and therefore not receiving the care and support he needs. The claim set
out that the Local Authority was willing to assist. In particular, the application said, “Immediate release is
_inappropriate because of the very high risk that the Claimant will be re-trafficked”._ In addition, the
application sought an order requiring, amongst other points, that by 9 November the Defendant;

i) File and serve a “reasonable grounds” decision under the National Referral Mechanism as to whether it
agrees that there are reasonable grounds to believe that the Claimant may be a victim of trafficking,

ii) State whether it agrees to release the Claimant,

iii) In consultation with the Local Authority and the Police, shall set out any proposals for the production of
a risk assessment and a protection plan to minimise the risk or re-trafficking if the Claimant was to be
released on a voluntary basis or by court order.

_Events of 6 November_

9. The claim was delivered to the Government Legal Department on 6 November at 12.25pm. The
[Defendant takes issue that that amounted to service under the Crown Proceedings Act 1947. That is not](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-H0X0-TWPY-Y0K0-00000-00&context=1519360)
an issue which has to be determined. What is not in dispute is that notice of resistance to immediate and
unconditional release was communicated to the Defendant before the time of release.

10. At 1.30 pm the Claimant was told by an immigration official that he might be released and was asked if
he had an address he could go to if he was. That message was passed on to his solicitors by him in a
telephone call lasting from 2.33pm to 2.48pm. At 3.18pm the solicitors acting emailed the Defendant and


-----

Department [2016] EWHC 1912 (Admin)

the Government Legal Department stating that the Claimant should not be released without at least 6
hours' notice so that, if necessary, an emergency injunction could be sought. At some point during the
afternoon, after the telephone call at 2.48pm, the Defendant released the Claimant from detention. He
disappeared and has not been traced. There is no evidence as to his whereabouts but those who act for
him believe that he has been re-trafficked.

11. Coincidentally on 6 November Nicol J ordered that the time for an Acknowledgment of Service be
abridged to 7 days and that the papers should be put before a Judge for urgent consideration of the
application and interim relief.

12. On 10 November an application for a hearing was issued on behalf of the Claimant. It was submitted
that the Defendant was in breach of her duty to protect him as a victim of trafficking under Article 4 and she
should explain her action and what steps would be taken to recover him. It was also said that the Claimant
would be seeking that the original claim be amended to seek a declaration of the breach and damages.

13. On 13 November the Defendant served her Summary Grounds of Defence. It was contended that as
the original claim for Judicial Review sought the Claimant's release that the claim was now academic as he
had indeed been released on 6 November. It went on to submit that any decisions about there being
reasonable grounds to believe that the Claimant may be a victim of trafficking or about the Claimant's age
could not be pursued, at that time, as the Claimant had disappeared.

_Legislative Background_

[14. It is unlawful for a public authority to act in a way which is incompatible with a convention right, s.6(1)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BN90-TWPY-Y1FH-00000-00&context=1519360)
**_Human Rights Act 1998. Article 4 of the European Convention on Human rights prohibits slavery and_**
forced labour, the relevant provisions are;

1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.

Article 4 imposes a duty on the Defendant to take reasonable steps to protect an individual from being
trafficked or re-trafficked. That duty is identified as “investigative”, “administrative” and “operational” or
“protective”. The operational or protective duty is engaged when an individual is at “real and immediate”
danger of being re-trafficked.

15. The age of the Claimant is disputed. When he was detained it was concluded by immigration officials
that he was significantly over 18, based on his physical appearance and demeanour and in the absence of
credible evidence to the contrary. That follows current guidance on age assessment for detained persons.
[However, Section 51 Modern Slavery Act 2015 has created a presumption about the age of a detained](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C266-00000-00&context=1519360)
person who is or might be, on reasonable grounds, the victim of trafficking.

**_(1) This section applies where—_**

**_(a) a public authority with functions under relevant arrangements has reasonable grounds to_**
**_believe that a person may be a victim of human trafficking, and_**

**_(b) the authority is not certain of the person's age but has reasonable grounds to believe that the_**
**_person may be under 18._**

**_(2) Until an assessment of the person's age is carried out by a local authority or the person's age is_**
**_otherwise determined, the public authority must assume for the purposes of its functions under_**
**_relevant arrangements that the person is under 18._**

**_(3) “Relevant arrangements” means arrangements for providing assistance and support to persons_**
**_who are, or who there are reasonable grounds to believe may be, victims of human trafficking, as_**
**_set out in—_**

**_(a) guidance issued under section 49(1)(b);_**


-----

Department [2016] EWHC 1912 (Admin)

**_(b) any regulations made under section 50(1)._**

**_[(4) “Local authority” has the same meaning as in the Children Act 1989 section 105 of that Act).](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:56J5-43R1-DYCN-C1YG-00000-00&context=1519360)_**

16. The Defendant has drafted guidance, issued under s. 49(1)(b) of the Act to deal with its “functions
under relevant arrangements” so that when there are reasonable grounds to believe that a detained person
may be under 18 and there are reasonable grounds to believe that she may be a victim of trafficking then
she must be treated as a child pending a local authority age assessment, _(Victims of_ **_Modern Slavery,_**
_Competent Authority)._

17. **_Directive 2011/36/EU_** identifies trafficking as a serious crime which creates a gross violation of
fundamental rights. Its prevention is described as a priority. It sets out enhanced protection for children. It
further describes the provision which should be made for such victims, either as potential defendants in
criminal cases or more generally. It has not yet been brought fully into effect.

Although the directive was enacted on 5 April 2011 its transposition, due by 6 April 2013, has not yet taken
place.

18. In ratifying and implementing **_The Anti-Trafficking Convention the United Kingdom assumed_**
protective and remedial obligations to trafficking victims. The Defendant's duty to provide assistance under
the Anti-Trafficking Convention is engaged no later than the point at which a decision is made that there
are reasonable grounds to believe a particular appellant to be a victim of trafficking.

**_Article 10. 2 Each Party shall adopt such legislative or other measures as may be necessary to_**
**_identify victims as appropriate in collaboration with other Parties and relevant support_**
**_organisations. Each Party shall ensure that, if the competent authorities have reasonable grounds_**
**_to believe that a person has been victim of trafficking in human beings, that person shall not be_**
**_removed from its territory until the identification process as victim of an offence provided for in_**
**_Article 18 of this Convention has been completed by the competent authorities and shall likewise_**
**_ensure that that person receives the assistance provided for in Article 12, paragraphs 1 and 2._**

|Recit al|1 8 ) I t i s n e c e s s a r y f o r v i|Col3|
|---|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_c_**
**_t_**
**_i_**
**_m_**
**_s_**

**_o_**
**_f_**

**_t_**
**_r_**
**_a_**
**_f_**
**_f_**
**_i_**
**_c_**
**_k_**
**_i_**
**_n_**
**_g_**

**_i_**
**_n_**

**_h_**
**_u_**
**_m_**
**_a_**
**_n_**

**_b_**
**_e_**
**_i_**
**_n_**
**_g_**
**_s_**

**_t_**
**_o_**

**_b_**
**_e_**

**_a_**
**_b_**
**_l_**
**_e_**

**_t_**
**_o_**

**_e_**
**_x_**
**_e_**
**_r_**
**_c_**
**_i_**
**_s_**
**_e_**

**_t_**

|Col1|c t i m s o f t r a f f i c k i n g i n h u m a n b e i n g s t o b e a b l e t o e x e r c i s e t|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)

|Col1|h e i r r i g h t s e f f e c t i v e l y . T h e r e f o r e a s s i s t a n c e a n d s u p p o r t s h o|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_u_**
**_l_**
**_d_**

**_b_**
**_e_**

**_a_**
**_v_**
**_a_**
**_i_**
**_l_**
**_a_**
**_b_**
**_l_**
**_e_**

**_t_**
**_o_**

**_t_**
**_h_**
**_e_**
**_m_**

**_b_**
**_e_**
**_f_**
**_o_**
**_r_**
**_e_**
**_,_**

**_d_**
**_u_**
**_r_**
**_i_**
**_n_**
**_g_**

**_a_**
**_n_**
**_d_**

**_f_**
**_o_**
**_r_**

**_a_**
**_n_**

**_a_**
**_p_**
**_p_**
**_r_**
**_o_**
**_p_**
**_r_**
**_i_**
**_a_**
**_t_**

|Col1|u l d b e a v a i l a b l e t o t h e m b e f o r e , d u r i n g a n d f o r a n a p p r o p r i a t|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_e_**

**_t_**
**_i_**
**_m_**
**_e_**

**_a_**
**_f_**
**_t_**
**_e_**
**_r_**

**_c_**
**_r_**
**_i_**
**_m_**
**_i_**
**_n_**
**_a_**
**_l_**

**_p_**
**_r_**
**_o_**
**_c_**
**_e_**
**_e_**
**_d_**
**_i_**
**_n_**
**_g_**
**_s_**
**_._**

**_M_**
**_e_**
**_m_**
**_b_**
**_e_**
**_r_**

**_S_**
**_t_**
**_a_**
**_t_**
**_e_**
**_s_**

**_s_**
**_h_**
**_o_**
**_u_**
**_l_**
**_d_**

**_p_**
**_r_**
**_o_**
**_v_**
**_i_**

|Col1|e t i m e a f t e r c r i m i n a l p r o c e e d i n g s . M e m b e r S t a t e s s h o u l d p r o v i|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_d_**
**_e_**

**_f_**
**_o_**
**_r_**

**_r_**
**_e_**
**_s_**
**_o_**
**_u_**
**_r_**
**_c_**
**_e_**
**_s_**

**_t_**
**_o_**

**_s_**
**_u_**
**_p_**
**_p_**
**_o_**
**_r_**
**_t_**

**_v_**
**_i_**
**_c_**
**_t_**
**_i_**
**_m_**

**_a_**
**_s_**
**_s_**
**_i_**
**_s_**
**_t_**
**_a_**
**_n_**
**_c_**
**_e_**
**_,_**

**_s_**
**_u_**
**_p_**
**_p_**
**_o_**
**_r_**
**_t_**

**_a_**
**_n_**
**_d_**

**_p_**
**_r_**

|Col1|d e f o r r e s o u r c e s t o s u p p o r t v i c t i m a s s i s t a n c e , s u p p o r t a n d p r|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)

|Col1|o t e c t i o n . T h e a s s i s t a n c e a n d s u p p o r t p r o v i d e d s h o u l d i n c l u d e|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_a_**
**_t_**

**_l_**
**_e_**
**_a_**
**_s_**
**_t_**

**_a_**

**_m_**
**_i_**
**_n_**
**_i_**
**_m_**
**_u_**
**_m_**

**_s_**
**_e_**
**_t_**

**_o_**
**_f_**

**_m_**
**_e_**
**_a_**
**_s_**
**_u_**
**_r_**
**_e_**
**_s_**

**_t_**
**_h_**
**_a_**
**_t_**

**_a_**
**_r_**
**_e_**

**_n_**
**_e_**
**_c_**
**_e_**
**_s_**
**_s_**
**_a_**
**_r_**
**_y_**

**_t_**
**_o_**

**_e_**
**_n_**
**_a_**
**_b_**

|Col1|a t l e a s t a m i n i m u m s e t o f m e a s u r e s t h a t a r e n e c e s s a r y t o e n a b|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_l_**
**_e_**

**_t_**
**_h_**
**_e_**

**_v_**
**_i_**
**_c_**
**_t_**
**_i_**
**_m_**

**_t_**
**_o_**

**_r_**
**_e_**
**_c_**
**_o_**
**_v_**
**_e_**
**_r_**

**_a_**
**_n_**
**_d_**

**_e_**
**_s_**
**_c_**
**_a_**
**_p_**
**_e_**

**_f_**
**_r_**
**_o_**
**_m_**

**_t_**
**_h_**
**_e_**
**_i_**
**_r_**

**_t_**
**_r_**
**_a_**
**_f_**
**_f_**
**_i_**
**_c_**
**_k_**
**_e_**
**_r_**
**_s_**
**_._**

**_T_**

|Col1|l e t h e v i c t i m t o r e c o v e r a n d e s c a p e f r o m t h e i r t r a f f i c k e r s . T|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_h_**
**_e_**

**_p_**
**_r_**
**_a_**
**_c_**
**_t_**
**_i_**
**_c_**
**_a_**
**_l_**

**_i_**
**_m_**
**_p_**
**_l_**
**_e_**
**_m_**
**_e_**
**_n_**
**_t_**
**_a_**
**_t_**
**_i_**
**_o_**
**_n_**

**_o_**
**_f_**

**_s_**
**_u_**
**_c_**
**_h_**

**_m_**
**_e_**
**_a_**
**_s_**
**_u_**
**_r_**
**_e_**
**_s_**

**_s_**
**_h_**
**_o_**
**_u_**
**_l_**
**_d_**
**_,_**

**_o_**
**_n_**

**_t_**
**_h_**
**_e_**

**_b_**

|Col1|h e p r a c t i c a l i m p l e m e n t a t i o n o f s u c h m e a s u r e s s h o u l d , o n t h e b|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_a_**
**_s_**
**_i_**
**_s_**

**_o_**
**_f_**

**_a_**
**_n_**

**_i_**
**_n_**
**_d_**
**_i_**
**_v_**
**_i_**
**_d_**
**_u_**
**_a_**
**_l_**

**_a_**
**_s_**
**_s_**
**_e_**
**_s_**
**_s_**
**_m_**
**_e_**
**_n_**
**_t_**

**_c_**
**_a_**
**_r_**
**_r_**
**_i_**
**_e_**
**_d_**

**_o_**
**_u_**
**_t_**

**_i_**
**_n_**

**_a_**
**_c_**
**_c_**
**_o_**
**_r_**
**_d_**
**_a_**
**_n_**
**_c_**
**_e_**

**_w_**
**_i_**

|Col1|a s i s o f a n i n d i v i d u a l a s s e s s m e n t c a r r i e d o u t i n a c c o r d a n c e w i|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_t_**
**_h_**

**_n_**
**_a_**
**_t_**
**_i_**
**_o_**
**_n_**
**_a_**
**_l_**

**_p_**
**_r_**
**_o_**
**_c_**
**_e_**
**_d_**
**_u_**
**_r_**
**_e_**
**_s_**
**_,_**

**_t_**
**_a_**
**_k_**
**_e_**

**_i_**
**_n_**
**_t_**
**_o_**

**_a_**
**_c_**
**_c_**
**_o_**
**_u_**
**_n_**
**_t_**

**_t_**
**_h_**
**_e_**

**_c_**
**_i_**
**_r_**
**_c_**
**_u_**
**_m_**
**_s_**
**_t_**
**_a_**
**_n_**
**_c_**
**_e_**
**_s_**
**_,_**

|Col1|t h n a t i o n a l p r o c e d u r e s , t a k e i n t o a c c o u n t t h e c i r c u m s t a n c e s ,|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_c_**
**_u_**
**_l_**
**_t_**
**_u_**
**_r_**
**_a_**
**_l_**

**_c_**
**_o_**
**_n_**
**_t_**
**_e_**
**_x_**
**_t_**

**_a_**
**_n_**
**_d_**

**_n_**
**_e_**
**_e_**
**_d_**
**_s_**

**_o_**
**_f_**

**_t_**
**_h_**
**_e_**

**_p_**
**_e_**
**_r_**
**_s_**
**_o_**
**_n_**

**_c_**
**_o_**
**_n_**
**_c_**
**_e_**
**_r_**
**_n_**
**_e_**
**_d_**
**_._**

**_A_**

**_p_**
**_e_**
**_r_**
**_s_**
**_o_**
**_n_**

|Col1|c u l t u r a l c o n t e x t a n d n e e d s o f t h e p e r s o n c o n c e r n e d . A p e r s o n|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_s_**
**_h_**
**_o_**
**_u_**
**_l_**
**_d_**

**_b_**
**_e_**

**_p_**
**_r_**
**_o_**
**_v_**
**_i_**
**_d_**
**_e_**
**_d_**

**_w_**
**_i_**
**_t_**
**_h_**

**_a_**
**_s_**
**_s_**
**_i_**
**_s_**
**_t_**
**_a_**
**_n_**
**_c_**
**_e_**

**_a_**
**_n_**
**_d_**

**_s_**
**_u_**
**_p_**
**_p_**
**_o_**
**_r_**
**_t_**

**_a_**
**_s_**

**_s_**
**_o_**
**_o_**
**_n_**

**_a_**
**_s_**

**_t_**
**_h_**
**_e_**

|Col1|s h o u l d b e p r o v i d e d w i t h a s s i s t a n c e a n d s u p p o r t a s s o o n a s t h e|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)

|Col1|r e i s a r e a s o n a b l e - g r o u n d s i n d i c a t i o n f o r b e l i e v i n g t h a t h e o|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_r_**

**_s_**
**_h_**
**_e_**

**_m_**
**_i_**
**_g_**
**_h_**
**_t_**

**_h_**
**_a_**
**_v_**
**_e_**

**_b_**
**_e_**
**_e_**
**_n_**

**_t_**
**_r_**
**_a_**
**_f_**
**_f_**
**_i_**
**_c_**
**_k_**
**_e_**
**_d_**

**_a_**
**_n_**
**_d_**

**_i_**
**_r_**
**_r_**
**_e_**
**_s_**
**_p_**
**_e_**
**_c_**
**_t_**
**_i_**
**_v_**
**_e_**

**_o_**
**_f_**

**_h_**
**_i_**
**_s_**

**_o_**
**_r_**

**_h_**

|Col1|r s h e m i g h t h a v e b e e n t r a f f i c k e d a n d i r r e s p e c t i v e o f h i s o r h|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_e_**
**_r_**

**_w_**
**_i_**
**_l_**
**_l_**
**_i_**
**_n_**
**_g_**
**_n_**
**_e_**
**_s_**
**_s_**

**_t_**
**_o_**

**_a_**
**_c_**
**_t_**

**_a_**
**_s_**

**_a_**

**_w_**
**_i_**
**_t_**
**_n_**
**_e_**
**_s_**
**_s_**
**_._**

**_I_**
**_n_**

**_c_**
**_a_**
**_s_**
**_e_**
**_s_**

**_w_**
**_h_**
**_e_**
**_r_**
**_e_**

**_t_**
**_h_**
**_e_**

**_v_**
**_i_**
**_c_**
**_t_**
**_i_**
**_m_**

|Col1|e r w i l l i n g n e s s t o a c t a s a w i t n e s s . I n c a s e s w h e r e t h e v i c t i m|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_d_**
**_o_**
**_e_**
**_s_**

**_n_**
**_o_**
**_t_**

**_r_**
**_e_**
**_s_**
**_i_**
**_d_**
**_e_**

**_l_**
**_a_**
**_w_**
**_f_**
**_u_**
**_l_**
**_l_**
**_y_**

**_i_**
**_n_**

**_t_**
**_h_**
**_e_**

**_M_**
**_e_**
**_m_**
**_b_**
**_e_**
**_r_**

**_S_**
**_t_**
**_a_**
**_t_**
**_e_**

**_c_**
**_o_**
**_n_**
**_c_**
**_e_**
**_r_**
**_n_**
**_e_**
**_d_**
**_,_**

**_a_**
**_s_**
**_s_**
**_i_**

|Col1|d o e s n o t r e s i d e l a w f u l l y i n t h e M e m b e r S t a t e c o n c e r n e d , a s s i|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)

|Col1|s t a n c e a n d s u p p o r t s h o u l d b e p r o v i d e d u n c o n d i t i o n a l l y a t l e a s|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_t_**

**_d_**
**_u_**
**_r_**
**_i_**
**_n_**
**_g_**

**_t_**
**_h_**
**_e_**

**_r_**
**_e_**
**_f_**
**_l_**
**_e_**
**_c_**
**_t_**
**_i_**
**_o_**
**_n_**

**_p_**
**_e_**
**_r_**
**_i_**
**_o_**
**_d_**
**_._**

**_I_**
**_f_**
**_,_**

**_a_**
**_f_**
**_t_**
**_e_**
**_r_**

**_c_**
**_o_**
**_m_**
**_p_**
**_l_**
**_e_**
**_t_**
**_i_**
**_o_**
**_n_**

**_o_**
**_f_**

**_t_**
**_h_**
**_e_**

**_i_**

|Col1|t d u r i n g t h e r e f l e c t i o n p e r i o d . I f , a f t e r c o m p l e t i o n o f t h e i|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)

|Col1|d e n t i f i c a t i o n p r o c e s s o r e x p i r y o f t h e r e f l e c t i o n p e r i o d , t h e|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_v_**
**_i_**
**_c_**
**_t_**
**_i_**
**_m_**

**_i_**
**_s_**

**_n_**
**_o_**
**_t_**

**_c_**
**_o_**
**_n_**
**_s_**
**_i_**
**_d_**
**_e_**
**_r_**
**_e_**
**_d_**

**_e_**
**_l_**
**_i_**
**_g_**
**_i_**
**_b_**
**_l_**
**_e_**

**_f_**
**_o_**
**_r_**

**_a_**

**_r_**
**_e_**
**_s_**
**_i_**
**_d_**
**_e_**
**_n_**
**_c_**
**_e_**

**_p_**
**_e_**
**_r_**
**_m_**
**_i_**
**_t_**

**_o_**
**_r_**

|Col1|v i c t i m i s n o t c o n s i d e r e d e l i g i b l e f o r a r e s i d e n c e p e r m i t o r|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_d_**
**_o_**
**_e_**
**_s_**

**_n_**
**_o_**
**_t_**

**_o_**
**_t_**
**_h_**
**_e_**
**_r_**
**_w_**
**_i_**
**_s_**
**_e_**

**_h_**
**_a_**
**_v_**
**_e_**

**_l_**
**_a_**
**_w_**
**_f_**
**_u_**
**_l_**

**_r_**
**_e_**
**_s_**
**_i_**
**_d_**
**_e_**
**_n_**
**_c_**
**_e_**

**_i_**
**_n_**

**_t_**
**_h_**
**_a_**
**_t_**

**_M_**
**_e_**
**_m_**
**_b_**
**_e_**
**_r_**

**_S_**
**_t_**
**_a_**
**_t_**
**_e_**

|Col1|d o e s n o t o t h e r w i s e h a v e l a w f u l r e s i d e n c e i n t h a t M e m b e r S t a t e|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_,_**

**_o_**
**_r_**

**_i_**
**_f_**

**_t_**
**_h_**
**_e_**

**_v_**
**_i_**
**_c_**
**_t_**
**_i_**
**_m_**

**_h_**
**_a_**
**_s_**

**_l_**
**_e_**
**_f_**
**_t_**

**_t_**
**_h_**
**_e_**

**_t_**
**_e_**
**_r_**
**_r_**
**_i_**
**_t_**
**_o_**
**_r_**
**_y_**

**_o_**
**_f_**

**_t_**
**_h_**
**_a_**
**_t_**

**_M_**
**_e_**
**_m_**
**_b_**
**_e_**
**_r_**

**_S_**
**_t_**
**_a_**
**_t_**

|Col1|, o r i f t h e v i c t i m h a s l e f t t h e t e r r i t o r y o f t h a t M e m b e r S t a t|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_e_**
**_,_**

**_t_**
**_h_**
**_e_**

**_M_**
**_e_**
**_m_**
**_b_**
**_e_**
**_r_**

**_S_**
**_t_**
**_a_**
**_t_**
**_e_**

**_c_**
**_o_**
**_n_**
**_c_**
**_e_**
**_r_**
**_n_**
**_e_**
**_d_**

**_i_**
**_s_**

**_n_**
**_o_**
**_t_**

**_o_**
**_b_**
**_l_**
**_i_**
**_g_**
**_e_**
**_d_**

**_t_**
**_o_**

**_c_**
**_o_**
**_n_**
**_t_**
**_i_**
**_n_**
**_u_**
**_e_**

**_p_**
**_r_**
**_o_**
**_v_**

|Col1|e , t h e M e m b e r S t a t e c o n c e r n e d i s n o t o b l i g e d t o c o n t i n u e p r o v|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)

|Col1|i d i n g a s s i s t a n c e a n d s u p p o r t t o t h a t p e r s o n o n t h e b a s i s o f t|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_h_**
**_i_**
**_s_**

**_D_**
**_i_**
**_r_**
**_e_**
**_c_**
**_t_**
**_i_**
**_v_**
**_e_**
**_._**

**_W_**
**_h_**
**_e_**
**_r_**
**_e_**

**_n_**
**_e_**
**_c_**
**_e_**
**_s_**
**_s_**
**_a_**
**_r_**
**_y_**
**_,_**

**_a_**
**_s_**
**_s_**
**_i_**
**_s_**
**_t_**
**_a_**
**_n_**
**_c_**
**_e_**

**_a_**
**_n_**
**_d_**

**_s_**
**_u_**
**_p_**
**_p_**
**_o_**
**_r_**
**_t_**

**_s_**
**_h_**
**_o_**
**_u_**
**_l_**
**_d_**

|Col1|h i s D i r e c t i v e . W h e r e n e c e s s a r y , a s s i s t a n c e a n d s u p p o r t s h o u l d|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_c_**
**_o_**
**_n_**
**_t_**
**_i_**
**_n_**
**_u_**
**_e_**

**_f_**
**_o_**
**_r_**

**_a_**
**_n_**

**_a_**
**_p_**
**_p_**
**_r_**
**_o_**
**_p_**
**_r_**
**_i_**
**_a_**
**_t_**
**_e_**

**_p_**
**_e_**
**_r_**
**_i_**
**_o_**
**_d_**

**_a_**
**_f_**
**_t_**
**_e_**
**_r_**

**_t_**
**_h_**
**_e_**

**_c_**
**_r_**
**_i_**
**_m_**
**_i_**
**_n_**
**_a_**
**_l_**

**_p_**
**_r_**
**_o_**
**_c_**
**_e_**
**_e_**

|Col1|c o n t i n u e f o r a n a p p r o p r i a t e p e r i o d a f t e r t h e c r i m i n a l p r o c e e|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_d_**
**_i_**
**_n_**
**_g_**
**_s_**

**_h_**
**_a_**
**_v_**
**_e_**

**_e_**
**_n_**
**_d_**
**_e_**
**_d_**
**_,_**

**_f_**
**_o_**
**_r_**

**_e_**
**_x_**
**_a_**
**_m_**
**_p_**
**_l_**
**_e_**

**_i_**
**_f_**

**_m_**
**_e_**
**_d_**
**_i_**
**_c_**
**_a_**
**_l_**

**_t_**
**_r_**
**_e_**
**_a_**
**_t_**
**_m_**
**_e_**
**_n_**
**_t_**

**_i_**
**_s_**

**_o_**
**_n_**
**_g_**
**_o_**
**_i_**
**_n_**
**_g_**

|Col1|d i n g s h a v e e n d e d , f o r e x a m p l e i f m e d i c a l t r e a t m e n t i s o n g o i n g|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)

|Col1|d u e t o t h e s e v e r e p h y s i c a l o r p s y c h o l o g i c a l c o n s e q u e n c e s o f|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)


**_t_**
**_h_**
**_e_**

**_c_**
**_r_**
**_i_**
**_m_**
**_e_**
**_,_**

**_o_**
**_r_**

**_i_**
**_f_**

**_t_**
**_h_**
**_e_**

**_v_**
**_i_**
**_c_**
**_t_**
**_i_**
**_m_**
**_'_**
**_s_**

**_s_**
**_a_**
**_f_**
**_e_**
**_t_**
**_y_**

**_i_**
**_s_**

**_a_**
**_t_**

**_r_**
**_i_**
**_s_**
**_k_**

**_d_**
**_u_**
**_e_**

**_t_**
**_o_**

**_t_**
**_h_**
**_e_**

**_v_**
**_i_**

|Col1|t h e c r i m e , o r i f t h e v i c t i m ' s s a f e t y i s a t r i s k d u e t o t h e v i|
|---|---|


-----

Department [2016] EWHC 1912 (Admin)

**_c_**
**_t_**
**_i_**
**_m_**
**_'_**

**_s_**

**_s_**
**_t_**
**_a_**
**_t_**
**_e_**
**_m_**
**_e_**
**_n_**
**_t_**
**_s_**

**_i_**
**_n_**

**_t_**
**_h_**
**_o_**
**_s_**
**_e_**

**_c_**
**_r_**
**_i_**
**_m_**
**_i_**
**_n_**
**_a_**
**_l_**

**_p_**
**_r_**
**_o_**
**_c_**
**_e_**
**_e_**
**_d_**
**_i_**
**_n_**
**_g_**
**_s_**
**_._**

19. The leading authority on the positive obligations arising under Articles 4 of the Convention is Rantsev
**_v Cyprus and Russia (2010) 51 EHRR 1. It was a case concerning the trafficking into Cyprus of Russian_**
women to work as cabaret artistes. It sets out the history of the development of European jurisprudence in
this area and reviewed the relevant authorities in considerable detail.

**2. General principles of Article 4**

|Col1|c t i m ' s s t a t e m e n t s i n t h o s e c r i m i n a l p r o c e e d i n g s .|
|---|---|
|||


-----

Department [2016] EWHC 1912 (Admin)

**_1. The Court reiterates that, together with Articles 2 and 3, Article 4 enshrines one of the basic_**
**_values of the democratic societies making up the Council of Europe (Siliadin, cited above, § 82)._**
**_Unlike most of the substantive clauses of the Convention, Article 4 makes no provision for_**
**_exceptions and no derogation from it is permissible under Article 15 § 2 even in the event of a_**
**_public emergency threatening the life of the nation._**

**_2. In assessing whether there has been a violation of Article 4, the relevant legal or regulatory_**
**_framework in place must be taken into account (see, mutatis mutandis, Nachova and Others v._**

**_Bulgaria [GC], nos. 43577/98 and 43579/98, § 93, ECHR 2005‑VII). The Court considers that the_**

**_spectrum of safeguards set out in national legislation must be adequate to ensure the practical and_**
**_effective protection of the rights of victims or potential victims of trafficking. Accordingly, in_**
**_addition to criminal law measures to punish traffickers, Article 4 requires member States to put in_**
**_place adequate measures regulating businesses often used as a cover for human trafficking._**
**_Furthermore, a State's immigration rules must address relevant concerns relating to_**
**_encouragement, facilitation or tolerance of trafficking (see, mutatis mutandis, Guerra and Others v._**

**_Italy, 19 February 1998, §§ 58 to 60, Reports of Judgments and Decisions 1998‑I; Z and Others v._**

**_the United Kingdom [GC], no. 29392/95, §§ 73 to 74, ECHR 2001‑V; and Nachova and Others, cited_**

**_above, §§ 96 to 97 and 99-102)._**

**_3. In its Siliadin judgment, the Court confirmed that Article 4 entailed a specific positive obligation_**
**_on member States to penalise and prosecute effectively any act aimed at maintaining a person in a_**
**_situation of slavery, servitude or forced or compulsory labour (cited above, §§ 89 and 112). In order_**
**_to comply with this obligation, member States are required to put in place a legislative and_**
**_administrative framework to prohibit and punish trafficking. The Court observes that the Palermo_**
**_Protocol and the Anti-Trafficking Convention refer to the need for a comprehensive approach to_**
**_combat trafficking which includes measures to prevent trafficking and to protect victims, in_**
**_addition to measures to punish traffickers (see paragraphs 149 and 163 above). It is clear from the_**
**_provisions of these two instruments that the Contracting States, including almost all of the member_**
**_States of the Council of Europe, have formed the view that only a combination of measures_**
**_addressing all three aspects can be effective in the fight against trafficking (see also the_**
**_submissions of Interights and the AIRE Centre at paragraphs 267 and 271 above). Accordingly, the_**
**_duty to penalise and prosecute trafficking is only one aspect of member States' general_**
**_undertaking to combat trafficking. The extent of the positive obligations arising under Article 4_**
**_must be considered within this broader context._**

**_4. As with Articles 2 and 3 of the Convention, Article 4 may, in certain circumstances, require a_**
**_State to take operational measures to protect victims, or potential victims, of trafficking (see,_**
**_mutatis mutandis, Osman, cited above, § 115; and Mahmut Kaya v. Turkey, no. 22535/93, § 115,_**

**_ECHR 2000‑III). In order for a positive obligation to take operational measures to arise in the_**

**_circumstances of a particular case, it must be demonstrated that the State authorities were aware,_**
**_or ought to have been aware, of circumstances giving rise to a credible suspicion that an identified_**
**_individual had been, or was at real and immediate risk of being, trafficked or exploited within the_**
**_meaning of Article 3(a) of the Palermo Protocol and Article 4(a) of the Anti-Trafficking Convention._**
**_In the case of an answer in the affirmative, there will be a violation of Article 4 of the Convention_**
**_where the authorities fail to take appropriate measures within the scope of their powers to remove_**
**_the individual from that situation or risk (see, mutatis mutandis, Osman, cited above, §§116 to 117;_**
**_and Mahmut Kaya, cited above, §§ 115 to 116)._**

**_5. Bearing in mind the difficulties involved in policing modern societies and the operational choices_**
**_which must be made in terms of priorities and resources, the obligation to take operational_**
**_measures must, however, be interpreted in a way which does not impose an impossible or_**
**_disproportionate burden on the authorities (see, mutatis mutandis, Osman, cited above, § 116). It is_**
**_relevant to the consideration of the proportionality of any positive obligation arising in the present_**


-----

Department [2016] EWHC 1912 (Admin)

**_case that the Palermo Protocol, signed by both Cyprus and the Russian Federation in 2000,_**
**_requires States to endeavour to provide for the physical safety of victims of trafficking while in their_**
**_territories and to establish comprehensive policies and programmes to prevent and combat_**
**_trafficking (see paragraphs 153 to 154 above). States are also required to provide relevant training_**
**_for law enforcement and immigration officials (see paragraph 155 above)._**

**_6. Like Articles 2 and 3, Article 4 also entails a procedural obligation to investigate situations of_**
**_potential trafficking. The requirement to investigate does not depend on a complaint from the_**
**_victim or next-of-kin: once the matter has come to the attention of the authorities they must act of_**
**_their own motion (see, mutatis mutandis, Paul and Audrey Edwards v. the United Kingdom, no._**

**_46477/99, § 69, ECHR 2002‑II). For an investigation to be effective, it must be independent from_**

**_those implicated in the events. It must also be capable of leading to the identification and_**
**_punishment of individuals responsible, an obligation not of result but of means. A requirement of_**
**_promptness and reasonable expedition is implicit in all cases but where the possibility of removing_**
**_the individual from the harmful situation is available, the investigation must be undertaken as a_**
**_matter of urgency. The victim or the next-of-kin must be involved in the procedure to the extent_**
**_necessary to safeguard their legitimate interests (see, mutatis mutandis, Paul and Audrey Edwards,_**
**_cited above, §§ 70 to 73)._**

**_7. Finally, the Court reiterates that trafficking is a problem which is often not confined to the_**
**_domestic arena. When a person is trafficked from one State to another, trafficking offences may_**
**_occur in the State of origin, any State of transit and the State of destination. Relevant evidence and_**
**_witnesses may be located in all States. Although the Palermo Protocol is silent on the question of_**
**_jurisdiction, the Anti-Trafficking Convention explicitly requires each member State to establish_**
**_jurisdiction over any trafficking offence committed in its territory (see paragraph 172 above). Such_**
**_an approach is, in the Court's view, only logical in light of the general obligation, outlined above,_**
**_incumbent on all States under Article 4 of the Convention to investigate alleged trafficking_**
**_offences. In addition to the obligation to conduct a domestic investigation into events occurring on_**
**_their own territories, member States are also subject to a duty in cross-border trafficking cases to_**
**_cooperate effectively with the relevant authorities of other States concerned in the investigation of_**
**_events which occurred outside their territories. Such a duty is in keeping with the objectives of the_**
**_member States, as expressed in the preamble to the Palermo Protocol, to adopt a comprehensive_**
**_international approach to trafficking in the countries of origin, transit and destination (see_**
**_paragraph 149 above). It is also consistent with international agreements on mutual legal_**
**_assistance in which the respondent States participate in the present case (see paragraphs 175 to_**
**_185 above)._**

20. The test of “real and immediate” has been considered definitively in the case of Rabone v Pennine
**_HHS Foundation Trust [2012] UKSC 2 by Lord Dyson, MR._**

37. **_I accept that it is more difficult to establish a breach of the operational duty than mere_**
**_negligence. This is not least because, in order to prove negligence, it is sufficient to show that the_**
**_risk of damage was reasonably foreseeable; it is not necessary to show that the risk was real and_**
**_immediate. But to say that the test is a high one or more stringent than the test for negligence does_**
**_not shed light on the meaning of "real and immediate" or on the question whether there was a real_**
**_and immediate risk on the facts of any particular case._**

38. **_It seems to me that the courts below were clearly right to say that the risk of … suicide was_**
**_"real" in this case. On the evidence … it was a substantial or significant risk and not a remote or_**
**_fanciful one……………..._**

39. As for whether the risk was "immediate"…………... In the case of In re Officer L [2007] 1 WLR
**_2135, para 20, Lord Carswell stated that an apt summary of the meaning of an "immediate" risk is_**
**_one that is "present and continuing". In my view, one must guard against the dangers of using_**
**_other words to explain the meaning of an ordinary word like "immediate". But I think that the_**


-----

Department [2016] EWHC 1912 (Admin)

**_phrase "present and continuing" captures the essence of its meaning. The idea is to focus on a risk_**
**_which is present at the time of the alleged breach of duty and not a risk that will arise at some time_**
**_in the future_**

_The Approach_

21. The Claimant says that there is a clear breach of the Defendant's protective or operational duty under
Article 4 because she failed to take reasonable steps to protect the Claimant in circumstances where she
knew, or ought to have known, that there was a credible suspicion that he was a victim of trafficking. The
submission goes further and argues that the “breach in this case is symptomatic of a wider problem” and
that the alleged breach in this case identifies a gap in protection for victims and potential victims of
trafficking and is therefore also a breach of the wider duty. A large volume of evidence has been served to
support the contention that others, with experience and expertise in this field, were of the view that the
Claimant was under 18 at the time of his detention, was the victim of trafficking and was therefore at a real
and immediate risk of being trafficked or re-trafficked. It is submitted that the Defendant has failed to
comply with her obligations under Article 4. The questions for the court, in its own judgement, are identified
as follows;

i) Did the Claimant's circumstances put him into the category where an operational duty arose or was
capable of arising?

ii) Did the Defendant know or should she have known of circumstances giving rise to a credible suspicion
that the Claimant had been trafficked and was at a real and immediate risk of being re-trafficked?

iii) What steps, if any, were taken to protect him and were they reasonable?

iv) Consequently, is the Defendant in breach of her duties under Article 4?

22. Mr Buttler makes the submission that there were grounds giving rise to a credible suspicion, based on
the combination of circumstances; the high incidence of trafficking amongst Vietnamese nationals,
particularly those in their teens in combination with the fact that the Claimant was travelling in a lorry with
other Vietnamese males who may have been trafficked and that three of them had disappeared by the time
of the decision. Further that there was uncertainty about his age and the clear view of his solicitor that he
was under 18. There is a wealth of evidence dealing with the prevalence of Vietnamese nationals amongst
those who are trafficked into the UK. It is not possible to be certain about the proportionate incidence but it
is accepted to be high. All of these features were known to the officials who detained and eventually
released the Claimant.

23. The Equality and Human Rights Commission intervenes with leave. Its role under statute in this field is
well known and acknowledged. Its intention is expressed as being to focus on the wider legal and policy
framework rather than on the facts of the individual case. It submits that the failures in this individual case
are evidence of “a wider systems failure”. That the policy and guidance available is inadequate to enable
those charged with discharging the Defendant's duties under Article 4 to meet those obligations. It is
submitted that the transposition date of the Directive was more than three years ago. Consequently, its
proposals have not been brought into effect in that there are still no independent child trafficking advocates
and that no “relevant functions” within s 51 of the **_Modern Slavery Act 2015 have been determined. It_**
argues that the guidance provided does not go anything like far enough properly to identify risk and then to
provide adequate measures to deal with that risk.

24. The Defendant argues that the claim in this case relates solely to the decision of 6 November 2015 to
release the Claimant in the manner described, without safeguarding measures having been put in place.
She argues that there was no evidence that this individual was at a real and immediate risk of being
trafficked or re-trafficked at the time. Mr Lewis submits that neither the Claimant nor the Intervener has
leave to argue for a declaration that the entire system of dealing with known or suspected victims of human
trafficking is unlawful. The order by May J of 27 January 2016, granting permission to the Claimant to bring
Judicial Review proceedings says,


-----

Department [2016] EWHC 1912 (Admin)

“There is a reasonably arguable challenge under Art 4 to the SoS' decision to release the claimant from
detention without putting protective measures in place. If the parties seek to amend their grounds of
challenge/defence following a “conclusive grounds” decision in the claimant's case then they may apply to
do so pending the hearing date. It is inferred from the Amended Grounds of Defence that a “conclusive
grounds decision is to be made imminently (see para 4 of the Amended Grounds of Defence). There will be
no order to expedite the hearing whilst the claimant's whereabouts remain uncertain. For that reason there
will also be a general liberty to apply.”

On 11 April 2015 Hickinbottom J granted the application to intervene on the ambit of the State's positive
obligation to putative victims of trafficking and, in particular, child victims. In the observations to his order
he said,

“The Claimant challenges the Secretary of State's decision to release him from administrative detention, on
the grounds that, in releasing him, she breached her duty to take reasonable steps to protect him from the
risk of re-trafficking in breach of her positive Article 4 obligations. The EHRC seeks to intervene……..In my
view, the EHRC's part in the claim, albeit, modest in extent, might be particularly useful for the court”

25. The Defendant submits that the evidence served in support of the Claimant's case sets out the general
problem, which is accepted, of the high prevalence of trafficking amongst teenage Vietnamese nationals. It
is submitted that this, even in combination with concerns expressed about others from the same lorry, does
not move the position from the general to the particular in order to establish that there were grounds for
credible suspicion that the Claimant had been or may have been the victim of trafficking. Further that there
was no basis upon which a real and immediate risk of re-trafficking could be established.

_Analysis_

26. All the parties have presented complex and detailed arguments, both orally and in writing, with great
skill. The broader arguments raise questions of principle and general application. There is a wealth of
material to support the genuinely held and earnestly expressed concerns of those who represent the
Claimant's interests that there is a significant problem of trafficking, not limited to but prevalent amongst
Vietnamese nationals. There is no doubt about the sincerity of their belief that he was and is the victim of
trafficking.

27.  If there was a credible basis to suspect that he was trafficked into the UK then he has not been
offered reasonable protection against being re-trafficked. The questions at the core of the case are, first,
was he trafficked or was there enough material to give rise to a credible suspicion that he had been
trafficked? Second, if he was trafficked does that mean that he was at a real and immediate risk of being
re-trafficked?

28. Applying the test set out in Rantsev to the issues, namely, “In order for a positive obligation to take
**_operational measures to arise in the circumstances of a particular case, it must be demonstrated_**
**_that the State authorities were aware, or ought to have been aware, of circumstances giving rise to_**
**_a credible suspicion that an identified individual had been, or was at real and immediate risk of_**
**_being, trafficked or exploited”. What are the circumstances said to give rise to the credible suspicion? It_**
is accepted that simply being a Vietnamese national of about 18 years of age is not enough. The incidence
is high but not high enough for that automatically to give rise to grounds for a credible suspicion. It is
submitted on the Claimant's behalf that there is more, there is the fact that he was travelling in a lorry with
other Vietnamese males, who were thought may be victims of trafficking and that one of them had
disappeared from foster care and two from detention. It is also submitted that those who represent him had
put forward evidence of their belief that he was under 18. There were 16 males in the same lorry, 9 of
whom were not Vietnamese nationals. There is no suggestion that the other nationals were victims of
trafficking. It is difficult to see how the Claimant's presence in the lorry with other Vietnamese, about whom
the same concerns were expressed, can without more, amount to grounds for credible suspicion. It is
further submitted that three of the other Vietnamese males had disappeared by 6 November. That is true


-----

Department [2016] EWHC 1912 (Admin)

but one returned in due course. That such persons disappear frequently and for a variety of reasons is
obvious.

29. On the age issue it is clear, given that the male who disappeared and returned was in foster care that
some consideration had been given to the age of the detainees and he had been assessed as young
enough for foster care rather than detention. The immigration officials who considered the age of the
detained Vietnamese nationals must, on the day of detention or later, have applied the guidelines and
determined that at least one of them was or may have been under 18. The determination of the Claimant's
age at that point is disputed but it is not demonstrably unreasonable. There was a conflict of opinion which
was not determined before his disappearance. The certainty on the part of the Claimant's witnesses that he
was under 18 and has since been trafficked does not prove that he has and does inform the decision taken
on 6 November 2015, which is the decision under challenge.

30. Although I do not find such grounds established I have gone on to consider the Rabone test, namely,
looking for a substantial or significant risk of re-trafficking which is present and continuing. On the premise
that there were grounds for the credible suspicion that the Claimant had been trafficked into the UK it is
argued that having been trafficked he was at a real and immediate risk of being re-trafficked. Even if there
were credible grounds for suspicion, what more is there to give rise to a real and immediate risk? It is
accepted that being Vietnamese and about 18 is not enough but that, actually, is the basis upon which the
submission is founded. It is said that in such cases it is common practice for contact between the traffickers
and the trafficked to be re-established after detention and for there to be a “voluntary” or forced reunion.
Accepting that evidence, it is still based on the age and nationality of the Claimant without any or any
sufficient additional grounds to establish the basis of this challenge.

31. Accordingly, I do not find an operational breach of Article 4 in this case. Article 4 imposes positive
duties on the defendant, including but not limited to the implementation and enforcement of proper systems
to ensure compliance with those duties. If it had been necessary for the determination of this case, I would
be likely to have agreed with the Claimant's and Intervener's submissions that a general failure to comply
with the positive duties created by Article 4 could amount to a failure in an individual case. It was not
necessary and I do not make that finding. There was an operational duty owed to the Claimant, and on the
evidence available to me it was adequately fulfilled. The release of the Claimant on 6 November was not
unlawful. As there was no specific failure I do not find a systemic failure.

32. That there is an obligation to discover and protect those who are the victims of human trafficking is
obvious. It is a mark of a civilised state, it places a high and continuing burden on the Defendant. It must be
discharged by the maintenance and enforcement of proper systems based, in large measure, on adequate
training of frontline staff and the provision of safe and secure facilities. It requires vigilant scrutiny to
maintain an adequate minimum standard. That adequate minimum standard was achieved in this case.

33. However, it must be added that given the representations that were made, from late October but
particularly on 6 November, his release should not have taken place until those representing him had been
allowed to make an urgent application for an injunction. The fact that representations changed over time
from a request for immediate and unconditional release to release conditional upon safeguarding
measures being in place does not justify release in disregard of the request for such a delay to allow
access to the courts.

34. Accordingly, this claim for judicial review fails.

**End of Document**


-----

