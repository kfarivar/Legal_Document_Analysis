# R v Balmont (Nathan) [2018] EWCA Crim 2747

CA, CRIMINAL DIVISION

201803468 A2

LJ Bean, Nicol J, Pepperall J

Friday, 16 November 2018

16/11/2018

1. LORD JUSTICE BEAN:  On 13th April 2018 in the Crown Court at Cardiff before Judge Lloyd‑Clarke the

appellant pleaded guilty to five counts of supplying a controlled drug of Class A (cocaine) and was sentenced to
four years' imprisonment consecutive on each count. But he had previously been the subject of a sentence of
twelve months' custody suspended for two years imposed for two offences of burglary on 9th February 2017, again
at the Crown Court at Cardiff, and so fell to be sentenced again in respect of that offence. The suspended

sentence was activated to the extent of ten months, which was, in the usual way, made consecutive to the four‑year

sentence, making a total sentence of four years and ten months' imprisonment. He now appeals against sentence
by leave of the single judge.

2. No complaint is made, nor could it be, of the four‑year sentence for the instant offences; but Mr Lewis, on his

behalf, submits that to have activated ten months of the twelve‑month suspended sentence was excessive, given

that the suspended sentence order had had attached to it a condition of performing unpaid work and the appellant
had completed all of that unpaid work.

3. This court is concerned not with the activated suspended sentence in isolation, but with the totality of the
sentence. We have to consider whether four years and ten months in all was excessive, and for that purpose we
need first to look at the drugs offences.

4. The five counts on the indictment to which the appellant pleaded guilty (counts 5‑9 inclusive) covered five

separate incidents, spread over a period of a few weeks in November 2017.

5. The learned judge in passing sentence described them as follows:

"... you have a significant role; you have an operational function; you involved others in the operation; you were
working for financial advantage; and you clearly had an awareness and understanding of the scale of the
operation."

6. The search of the appellant's home had not itself led to the finding of drugs on the premises, but police were
able to recover text messages and data information from a mobile telephone seized. An expert officer for the
prosecution, reviewing that evidence, came to the conclusion that the appellant was operating a street level crack
cocaine supply business.

7. The appellant would package and hand on drugs to a much younger man, Mr Mezei, who was just 16 at the time
of these offences. The appellant was paying Mezei between £100 and £150 a day to perform this function. Mr
Mezei was determined by the National Crime Agency to have been the victim of **_modern slavery. The expert_**


-----

concluded that it was a profitable business for the appellant, providing a significant amount of street deals, and that
the appellant appeared to have been profiting to the tune of £400 a day. As the judge emphasised in sentencing,
the appellant was not himself addicted to hard drugs and therefore the business was simply being run for significant
financial gain.

8. Although young ‑ he was 21 by the time of sentencing ‑ he had a number of previous convictions: 26 offences,

with sixteen court appearances in respect of them. It is right to say that his only previous convictions or cautions in
respect of drugs were relatively minor matters concerned with Class B drugs.

9. Viewing that history, we consider that the learned judge's starting point before discount for plea of six years'

imprisonment was quite modest. It could very easily have been six‑and‑a‑half or seven years' imprisonment for

these five counts. It is correct, of course, that the relevant category range from the Sentencing Guidelines is three
years six months to seven years; and no one suggests that in a case of this kind it would be appropriate to multiply
by five the sentence which would have been imposed in respect of a single count. Nevertheless, as we say, a

starting point of at least six‑and‑a‑half years would, in our view, have been amply justified. There is no dispute

about the appellant's entitlement to the one‑third discount for a plea of guilty at the earliest opportunity. So a six

years six months' starting point would have led to four years four months' imprisonment for the substantive
offences; and even if the judge had then activated the suspended sentence only to the extent of half, that would
have led to exactly the same result.

10. It is therefore unnecessary, in our view, to decide whether the discount of only one‑sixth from the maximum

twelve months of the suspended sentence's activation was too limited a reduction having regard to the observations
[of this court, for example, in the case of McDonagh [2017] EWCA Crim 2193. We are quite unable to say that the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RB7-J2W1-F0JY-C3FN-00000-00&context=1519360)
total sentence of four years ten months' imprisonment was excessive. Accordingly, this appeal must be dismissed.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part**
thereof.

165 Fleet Street, London EC4A 2DY

Tel No: 020 7404 1400

Email: Rcj@epiqglobal.co.uk

**End of Document**


-----

