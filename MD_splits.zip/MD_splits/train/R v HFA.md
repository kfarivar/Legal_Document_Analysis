# R v HFA [2022] EWCA Crim 1226

Court of Appeal, Criminal Division

Males LJ, McGowan J, and HHJ Chambers

30 June 2022Judgment

MR H MacDONALD appeared on behalf of the Applicant

_________

**WARNING: reporting restrictions may apply to the contents transcribed in this document,**
**particularly if the case concerned a sexual offence or involved a child. Reporting restrictions prohibit the**
**publication of the applicable information to the public or any section of the public, in writing, in a broadcast**
**or by means of the internet, including social media. Anyone who receives a copy of this transcript is**
**responsible in law for making sure that applicable restrictions are not breached. A person who breaches a**
**reporting restriction is liable to a fine and/or imprisonment. For guidance on whether reporting restrictions**
**apply, and to what information, ask at the court office or take legal advice.**

**This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in**
**accordance with relevant licence or with the express consent of the Authority. All rights are reserved.**

**J U D G M E N T**

RECORDER OF WOLVERHAMPTON:

1. The applicant, HFA, now [an age] (born on [a date]), renews his application for leave for an extension of time (11
days) in which to apply for leave to appeal against sentence having been refused by the single judge (Freedman J).

2. On 4 March 2022, following pleas of guilty, he was sentenced by Mr Recorder Roques sitting in the Crown Court
at Lewes as follows:

- Count 1, possessing a controlled drug of Class A (MDMA - 4,858 Ecstasy tablets) contrary to section 5(3) of the
_[Misuse of Drugs Act 1971,3 years' detention in a young offenders' institution.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XT0-TWPY-Y0K9-00000-00&context=1519360)_

- Count 2, possessing a controlled drug of Class B, (amphetamine - 764 gms dry weight) contrary to section 5(3) of
[the Misuse of Drugs Act 1971,6 months' detention in a young offenders' institution concurrent.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XT0-TWPY-Y0K9-00000-00&context=1519360)

3. In the early hours of 18 October 2020 police were called to an incident. A number of people were seen fleeing
the scene and one of those was the applicant, who was stopped by police under threat of taser. There was some
dispute with the police, but ultimately the applicant was searched and a small quantity of drugs was found on his
person. There were four blue and three red Ecstasy tablets, each bearing a Ziggy Stardust emblem, and one
orange Ecstasy tablet embossed with a Fanta logo. There was also 1.52 gms of amphetamine in a grip seal bag.
In addition, the applicant had three mobile telephones.

4. The applicant's address in [a road], was searched. A bag was found in the applicant's bedroom, inside of which
were further quantities of drugs. There were approximately 4,858 Ecstasy tablets in total of blue and red totalling


-----

1.725 kilos, each with the same Ziggy Stardust emblem. There was also 1,195 gms of amphetamine in the form of
compressed damp powder. Later forensic analysis showed it to be 764 gms dry weight of a purity of 8 per cent,
which was consistent with the purity of amphetamine that would be on the street if it was cut with caffeine.

5. In interview the applicant gave a prepared statement saying:

"I am not involved in supplying drugs. I am not a dealer. The drugs found on me were mine for my personal use. I
understand from my solicitor that more items were found during a search of my home. I do not know what this is. I
do have a friend who asks to leave things at the house. I did not ask what it was. I didn't mind him leaving stuff.
He was going to collect it when he next came round. I do not want to give his details. I don't want to get anyone in
trouble."

6. The applicant pleaded guilty on a written basis which was accepted by the prosecution. He was storing the
drugs on behalf of violent criminals who had exploited him in 2019 when the Single Competent Authority had
concluded that he was a Victim of **_Modern Slavery. On that previous occasion the Youth Offending Service_**
considered that he had been trafficked from Brighton to the West Country and had been exploited criminally. On
this occasion, whilst asserting that he had been threatened with violence by the same people who had trafficked
[him previously, he conceded that the defence under section 45 of the Modern Slavery Act 2015 was not available](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
to him because he accepted that a reasonable person in the same situation as him with his characteristics would
have had a realistic alternative to acting as alleged.

7. The applicant has three convictions for four offences between 13 June and 24 October 2019. These included:
assault occasioning actual bodily harm, possessing an offensive weapon in a public place, possessing a Class B
controlled drug, and possessing a bladed article. He had not previously served a custodial sentence. He had no
previous convictions for supplying drugs.

8. The Recorder took into account a pre‑sentence report and a psychiatric report. The applicant is of

Bulgarian/Iranian heritage, having left Bulgaria when he was [an age]. After a short period in Germany, he came to
the United Kingdom. Dr S concluded that as a result of being the victim of knife crime when he was [an age], he
was probably suffering from post traumatic stress disorder.

9. The grounds of appeal are that the sentence was manifestly excessive, in that the Recorder adopted a flawed
approach to the identification of the starting point within the category range. The court justified an uplift in starting
point by identifying aggravation in harm based in quantity, but then failed to adjust downwards to reflect the volume
and weight of factors including lower culpability and reducing seriousness. Had the proper approach been adopted,
the court would have arrived at a shorter term that permitted consideration of alternatives to an immediate sentence
of detention.

10. In helpful oral submissions before us by Mr MacDonald it is in essence argued that insufficient weight had been
given to a combination of factors, in particular the applicant's age, maturity, that he had continued to be a Victim of
Trafficking and in addition his mental health.

11. Proper emphasis had been made in submissions regarding what was said in the case of R v Clarke [2018] 1 Cr
App R (S) 52 that "reaching the [an age] does not present a cliff edge for the purposes of sentencing".

12. In well‑structured sentencing remarks the Recorder followed the guidance of the Sentencing Council in respect

of drugs offences and sentencing children and young persons. The supply of Class A drugs was categorised as

harm category 2 at top end, reflecting the very large number of tablets above the indicative mid‑range and his

lesser role reflecting his basis of plea. The starting point was therefore 5 years' custody, but the Recorder went

upwards to presumably around 5‑and‑a‑half years to reflect that there were nearly 5,000 tablets with a street value

of about £50,000.

13. The Recorder then reduced the starting point to 4 years to reflect the applicant's age, the background of
trafficking and all of his other mitigation He expressly addressed the fact that the applicant was [an age] at the time


-----

of the offence, and so had regard to the principles of sentencing: that is welfare and preventing reoffending for
children and young persons. The sentence was reduced by 25 per cent to 3 years' detention in a young offenders'
institution to reflect his plea of guilty. The Recorder assessed the supply of Class B drugs, amphetamine, as
category 3 offence/lesser role. Totality was expressly addressed by indicating that in fixing the sentence of 3 years
on count 1 he was aggregating the applicant's overall criminality and was making the sentence on count 2
concurrent.

14. We are not persuaded that the Recorder failed to take into account the applicant's age or failed to recognise
that he had committed the offence in circumstances of modern slavery. The structure and approach to sentencing

in this case was correct. However, given the significance of age and maturity, underlined by the pre‑sentence and

psychiatric reports, the undisputed recent history of motivation due to being a Victim of Trafficking, plus the mental
health element as outlined in the psychiatric report, in our judgment looking at the factors in combination and
cumulatively, insufficient weight was attached to these factors to the extent that it can properly be said that the
sentence was manifestly excessive.

15. Accordingly, we grant leave for an extension of time and leave to appeal against sentence. On count 1, having
taken a starting point of 66 months, as did the Recorder, we reduce that to 40 months and then by 25 per cent to
reflect the plea of guilty. Therefore, the sentence will be 30 months in a young offenders' institution. Count 2 will
remain unaltered. There will be a concurrent sentence of 6 months in a young offenders' institution. To that extent
this appeal against sentence is allowed.

LORD JUSTCE MALES: A representation order Mr MacDonald?

MR MacDONALD: Please.

LORD JUSTICE MALES: Yes. Thank you.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or**
part thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400 Email: Rcj@epiqglobal.co.uk

**End of Document**


-----

