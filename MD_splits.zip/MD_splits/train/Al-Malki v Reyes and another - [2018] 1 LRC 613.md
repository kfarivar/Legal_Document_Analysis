# Al-Malki v Reyes and another [2018] 1 LRC 613

[2017] UKSC 61

SUPREME COURT

LORD NEUBERGER, LADY HALE, LORD CLARKE, LORD WILSON AND LORD SUMPTION SCJJ

15–17 MAY, 18 OCTOBER 2017

**International law — State immunity — Diplomatic immunity — Exceptions — Appellant employed as**
**domestic servant by respondent diplomat and his wife at diplomatic residence — Appellant alleging**
**mistreatment and discrimination during employment and failure to page minimum wage — Employment**
**Tribunal determining respondents entitled to diplomatic immunity — Respondents subsequently leaving**
**diplomatic post and returning to home state — Court of Appeal upholding Employment Tribunal decision —**
**Whether employment or treatment of domestic servant constituting act performed in the course of**
**diplomat's official functions — Whether diplomat able to rely on diplomatic immunity as bar to proceedings**
**after leaving post — Vienna Convention on Diplomatic Relations 1961, arts 31, 39.**

**Practice and procedure — Service — Service of claim form to diplomatic agent — Appellant employed as**
**domestic servant by respondent diplomat and his wife at diplomatic residence — Appellant alleging**
**mistreatment and discrimination during employment and failure to page minimum wage — Claim form sent**
**by post to respondents' private residence — Whether service of claim form by post to private residence**
**violating protections conferred on diplomats and their residences.**

R, a Philippine national, had been employed by Mr and Mrs Al-Malki (together, 'the respondents') as a domestic
servant in their London residence between 19 January and 14 March 2011. At that time, Mr Al-Malki was a member
of the diplomatic staff of the embassy of Saudi Arabia in London. R alleged that during her employment the
respondents maltreated her by requiring her to work excessive hours, failing to give her proper accommodation,
confiscating her passport and preventing her from leaving the house or communicating with others; and that they
paid her nothing until her employment terminated upon her escape. Consequently, R brought proceedings in the
Employment Tribunal ('ET') against the respondents alleging direct and indirect race discrimination, unlawful
deduction from wages and failure to pay her the national minimum wage. The proceedings were served by post on
the respondents' solicitors and by post to their private residence. The ET determined that Mr Al-Malki was entitled
to diplomatic

**[*614] immunity pursuant to art 31[a] of the Vienna Convention on Diplomatic Relations 1961 ('the Convention'), as**
[incorporated into English law by virtue of s 2[b] of the Diplomatic Privileges Act 1964, and that Mrs Al-Malki benefited](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y0D1-00000-00&context=1519360)
from derivative immunity as his family member under art 37[c] of the Convention. Thereafter, in August 2014, Mr AlMalki ceased to be a member of the Saudi mission in London and he and Mrs Al-Malki left the United Kingdom. A
diplomatic agent who was no longer in post and who had left the country was entitled to immunity only on the
narrower basis authorised by art 39[d] of the Convention. The ET's decision was upheld by the Court of Appeal and
R appealed. R contended that the ET had jurisdiction to hear her claims under the exception in art 31(1)(c) of the
Convention that diplomatic immunity did not apply to 'an action relating to any professional or commercial activity
exercised by the diplomatic agent in the receiving State outside his official functions'. The respondents crossappealed, contending that they were never validly served with the claim form as service on a diplomatic agent
o ld iolate his person and his residence contrar to arts 29[e] and 30[f] of the Con ention respecti el


-----

**HELD: Appeal allowed in part.**

(1) The person of a diplomatic agent was violated if an agent of the receiving state or acting on the authority of the
receiving state detained him, impeded his movement or subjected him to a personal restriction or indignity. The
delivery by post of a claim form did not do any of those things. It simply served to give notice to a defendant that
proceedings had been brought against him, so that he could defend his interests, for example by raising his
immunity. The mere conveying of information, however unwelcome, by post to a defendant, was not a violation of
the premises to which the letter was delivered. Otherwise, the same objection would apply to any mode of service
which started procedural time running, including service through diplomatic channels (see [16], below).

(2) Fundamental to the operation of the Convention was the distinction between those immunities which were
limited to acts performed in the course of a protected person's functions as a member or employee of the mission,
and those which were not. What an agent of a diplomatic mission did in the course of his official functions was done
on behalf of the sending state. In such a case, the individual agent was entitled to both diplomatic and state
immunity. By comparison, the acts which an agent of a diplomatic mission did in a personal or non-official capacity
were not acts of the state which employed him. They were acts in respect of which any immunity conferred on him
could be justified only on the practical ground that his exposure to civil or criminal proceedings in the receiving state
was liable to

1

**[*615] impede the functions of the mission to which he was attached. Article 31(1) of the Convention conferred**
immunity on diplomatic agents in post in respect of both private and official acts, subject to specific exceptions.
Under art 39(2), once a diplomatic agent's functions had come to an end, his immunities under art 31 would
normally cease from the moment when he left the territory of the receiving state. Thereafter he remained immune
only in respect of official acts, namely those which he performed for or on behalf of the sending state. In the instant
case, it was clear that the employment or treatment of R by the respondents were not acts performed in the course
of Mr Al-Malki's official functions. As the only immunity available to him was the residual immunity under art 39(2), it
followed that that immunity could not apply as the acts were not done in the course of his official functions.
Likewise, Mrs Al-Malki was no longer entitled to any immunity at all. It did not matter that the respondents were
entitled to diplomatic immunity when the present proceedings were commenced. An action brought against persons
entitled to diplomatic immunity was not a nullity. It was merely liable to be dismissed. Diplomatic immunity was a
procedural immunity and the procedural incidents of litigation normally fell to be determined by a court at the time of
the hearing. Thus a waiver of immunity after the commencement of proceedings would dispose of any diplomatic
immunity which previously existed. The result of a change in a defendant's status was not materially different. In the
instant case, there were valid proceedings on foot. Accordingly, the respondents were not entitled to diplomatic
immunity in respect of the claims made by R in the underlying proceedings and the case would be remitted to the
ET to determine those claims on their merits. In those circumstances, the question whether the exception in art
31(1)(c) applied to Mr Al-Malki had he still been in post did not strictly speaking arise (see [17], [18], [20], [48]–[54],
[below). Dicta of Diplock LJ in Empson v Smith [1965] 2 All ER 881 at 887applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-94H0-TWP1-61C4-00000-00&context=1519360)

Per Lord Sumption (Lord Neuberger concurring). The employment of a domestic servant to provide purely personal
services is not a 'professional or commercial activity exercised by the diplomatic agent'. The fact that the

a   Article 31 of the Convention is set out at [8], below.

b _[Section 2 of the Diplomatic Privileges Act 1964, so far as material, is set out at [9], below.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y0D1-00000-00&context=1519360)_

c   Article 37 of the Convention, so far as is material, is set out at [8], below.

d   Article 39 of the Convention, so far as is material, is set out at [8], below.

e   Article 29 of the Convention, so far as is material, is set out at [8], below.

f A i l 30 f h C i f i i l i [8] b l


-----

employment of Ms Reyes may have come about as a result of human trafficking makes no difference to this. If Mr
Al-Malki had still been in post, he would have been immune, because the employment and treatment of Ms Reyes
did not amount to carrying on or participating in carrying on a professional or commercial activity. Her employment,
although it continued for about two months, was plainly not an alternative occupation of Mr Al-Malki's. Nothing that
was done by him or his wife was done by way of business. A person who supplies goods or services by way of
business might be said to exercise a commercial activity. But Mr and Mrs Al-Malki are not said to have done that.
They are merely said to have used Ms Reyes's services in a harsh and in some respects unlawful way. There is no
sense which can reasonably be given to art 31(1)(c) which would make the consumption of goods and services the
exercise a commercial activity (see [4], [51], below).

Per Lord Wilson (Lady Hale and Lord Clarke concurring). This court will not answer in any binding form the central
question presented to it: does an action instituted in the tribunal against a foreign diplomat in the UK by his

**[*616] former domestic servant brought to the UK to work in his home in (assumed) conditions of modern slavery**
relate 'to any … commercial activity exercised by [him here] outside his official functions' within the meaning of art
31(1)(c) of the 1961 Convention? It is difficult for this court to forsake what it perceives to be a legally respectable
solution and instead to favour a conclusion that its system cannot provide redress for an apparently serious case of
domestic servitude here in our capital city. Far preferable would it be for the International Law Commission, midwife
to the 1961 Convention, to be invited, through the mechanism of art 17 of the statute which created it, to consider,
and to consult and to report upon, the international acceptability of an amendment of art 31 which would put beyond
doubt the exclusion of immunity in a case such as that of Ms Reyes (see [56]–[58], [67], [68], below).
**Cases referred to**

_[Baccus SRL v Servicio Nacional del Trigo [1956] 3 All ER 715, [1957] 1 QB 438, [1956] 3 WLR 948, UK CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP60-TWP1-609F-00000-00&context=1519360)_

_Baoanan v Baja (2009) 627 F Supp 2d 155, US DC (S NY)._

_Benkharbouche v Secretary of State for Foreign and Commonwealth Affairs; Secretary of State for Foreign and_
_[Commonwealth Affairs v Janah [2017] UKSC 62, [2018] 1 LRC 650, (2017) 43 BHRC 378, [2017] 3 WLR 957, UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RK3-69N1-DYJ0-82VY-00000-00&context=1519360)_
SC.

_Democratic Republic of the Congo v Belgium (Case concerning Arrest Warrant of 11 April 2000) [2002] ICJ Rep 3,_
ICJ.

_El-Hadad v Embassy of the United Arab Emirates (2000) 216 F 3d 29, US Ct of Apps._

_[Empson v Smith [1965] 2 All ER 881, [1966] 1 QB 426, [1965] 3 WLR 380, UK CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-94H0-TWP1-61C4-00000-00&context=1519360)_

_Fonseca v Larren (30 January 1991, unreported), Port SC._

_[Fothergill v Monarch Airlines Ltd [1980–84] LRC (Comm) 215, [1980] 2 All ER 696, [1981] AC 251, HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M61-F6S1-DYJ0-80X3-00000-00&context=1519360)_

_Fun v Pulgar (2014) 993 F Supp 2d 470, US DC._

_Gonzales Paredes v Vila (2007) 479 F Supp 2d 187, US DC._

_I Congreso del Partido_ _[[1981] 2 All ER 1064, sub nom](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-60K0-00000-00&context=1519360)_ _Playa Larga (Owners of cargo lately laden on board) v I_
_Congreso del Partido (Owners) [1983] 1 AC 244, [1981] 3 WLR 328, UK HL._

_Jones v Ministry of Interior of the Kingdom of Saudi Arabia (Secretary of State for Constitutional Affairs,_
_intervening), Mitchell v Al-Dali_ _[[2006] UKHL 26, [2007] 1 LRC 492, [2007] 1 All ER 113, [2007] 1 AC 270, UK HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-8384-00000-00&context=1519360)_

_Jurisdictional Immunities of the State (Germany v Italy (Greece intervening)) [2012] ICJ Rep 99, ICJ._

_Legal Consequences for States of the Continued Presence of South Africa in Namibia (South West Africa) [1971]_
ICJ Rep 16 ICJ


-----

_Mohamed X v Fettouma Z (17 October 2012), 11/01255 Legifrance, Montpellier CA._

_Montuya v Chedid (2011) 779 F Supp 2d 60, US DC._

_Oil Platforms (Islamic Republic of Iran v United States of America) [2003] ICJ 161, ICJ._

_Park v Shin (2002) 313 F 3d 1138, US Ct of Apps (9th Cir)._

**[*617] Pfarr v Anonymous 17 SA 1468/11 (ILDC 1903) (2011), Berlin-Brandenburg CA;** _rvsd NZA 2013, 343,_
Federal Employment Court.

_Propend Finance Pty Ltd v Sing (1997) 111 ILR 611, UK CA._

_[R v Secretary of State for the Home Dept, ex p Adan [2001] 1 All ER 593, [2001] 2 AC 477, [2001] 2 WLR 143, UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J90-TWP1-6023-00000-00&context=1519360)_
HL.

_[Rantsev v Cyprus (2010) 28 BHRC 313, (2010) 51 EHRR 1, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_

_Sabbithi v Al Saleh (2009) 605 F Supp 2d 122, US DC._

_[Shaw v Shaw [1979] 3 All ER 1, [1979] Fam 62, [1979] 3 WLR 24, UK Fam D.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DFG-81D0-TWP1-613T-00000-00&context=1519360)_

_[Stag Line Ltd v Foscolo, Mango & Co Ltd [1932] AC 328, [1931] All ER Rep 666, UK HL.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V1D-FSP2-D6MY-P05C-00000-00&context=1519360)_

_Sumitomo Shoji America Inc v Avagliano (1982) 457 US 176, US SC._

_Swarna v Al-Awadi (2010) 622 F 3d 123, US Ct of Apps (2nd Cir)._

_Tabion v Mufti (1996) 107 ILR 452, US CA (4th Cir)._

_Taddese v Abusabib [2013] ICR 603, UK EAT._

_Triquet v Bath (1764) 3 Burr 1478, (1764) 97 ER 936._

_United States v Public Service Alliance of Canada, Re Canada Labour Code_ _[[1993] 2 LRC 78, [1992] 2 SCR 50,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JX4-YNV1-DYJ0-82K7-00000-00&context=1519360)_
Can SC.

_United States v Stuart (1989) 489 US 353, US SC._

_[Wokuri v Kassam [2012] EWHC 105 (Ch), [2012] 4 LRC 741, [2012] 2 All ER 1195, [2013] Ch 80, UK Ch D.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:56NB-TP91-DYJ0-81CN-00000-00&context=1519360)_

_[Zoernsch v Waldock [1964] 2 All ER 256, [1964] 1 WLR 675, UK CA.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP90-TWP1-605P-00000-00&context=1519360)_
**Legislation referrred toCanada**

State Immunity Act.
_Portugal_

Civil Code.
_United Kingdom_

Diplomatic Immunities (Commonwealth Countries and Republic of Ireland) Act 1952.

Diplomatic Privileges Act 1708.

_[Diplomatic Privileges Act 1964.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61B0-TWPY-Y0N2-00000-00&context=1519360)_

[Employment Tribunals (Constitution and Rules of Procedure) Regulations 2004, SI 2004/1861.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW6-WRX0-TX08-H1G7-00000-00&context=1519360)


-----

_[State Immunity Act 1978.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6160-TWPY-Y1K0-00000-00&context=1519360)_
_United States_

Diplomatic Relations Act 1978.

Foreign Sovereign Immunities Act 1976.
**Other sources referred to**

American Law Institute Restatement (3rd) of the Foreign Relations Law of the United States (1986).

Arab Charter on Human Rights 2004.

Convention for the Protection of Human Rights and Fundamental Freedoms 1950 (Rome, 4 November 1950; TS 71
(1953); Cmnd 8969).

**[*618] Convention on Action against Trafficking in Human Beings (Warsaw, 16 May 2005) (CETS no 197).**

Council of Europe State Practice regarding State Immunities (2006).

Covenant of the League of Nations.

Denza 'Vienna Convention on Diplomatic Relations—Introductory Note' (available at
http://legal.un.org/avl/ha/vcdr/vcdr.html).

Denza Diplomatic Law (4th edn, 2016).

Ewins Independent Review of the Overseas Domestic Workers Visa (16 December 2015).

Fox The Law of State Immunity (2002).

Grotius De Jure Belli ac Pacis (1625).

Harvard Law School Draft Convention on Diplomatic Privileges and Immunities (1932).

Havana Convention on Diplomatic Officers (1928).

International Protocol to Prevent, Supress and Punish Trafficking in Persons, Especially Women and Children
(Palermo, 2000).

Mansion Harrap's Standard French and English Dictionary (ed Ledésert) (rev 1980).

Treaty of Amity, Economic Relations, and Consular Rights (Tehran, 15 August 1955).

United Nations Conference on Diplomatic Intercourse and Immunities (1961).

United Nations Convention against Transnational Organised Crime (2000).

United Nations Convention on Jurisdictional Immunities of States and their Property 2004 (A/RES/59/38).

Vienna Convention on Consular Relations (Vienna, 24 April 1963).

Vienna Convention on Diplomatic Relations 1961 (Vienna, 18 April 1961; TS 19 (1965); Cmnd 2565).

Vienna Convention on the Law of Treaties (Vienna; 23 May to 30 November 1969; TS 58 (1980); Cmnd 7964).

_Yearbook of the International Law Commission 1957._

_Yearbook of the International Law Commission 1958._
**Appeal and cross-appeal**


-----

The appellant, Ms Reyes, appealed against the decision of the Court of Appeal (Lord Dyson MR, Arden and Lloyd
[Jones LJJ) of 5 February 2015 ([2015] EWCA Civ 32, [2016] 2 All ER 136) dismissing her appeal from the decision](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JF5-45X1-DYBP-M0GN-00000-00&context=1519360)
[of the Employment Appeal Tribunal (UKEAT/0403/12/GE, [2013] IRLR 929), which upheld the claims to diplomatic](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59TP-7XT1-DYPB-W2RS-00000-00&context=1519360)
immunity by the respondents, Mr and Mrs Al-Malki, a Saudi diplomatic agent and his wife, and reversed the
decision of the employment tribunal. The respondents cross-appealed on the issue of service. The Secretary of
State for Foreign and Commonwealth Affairs and Kalayaan joined the proceedings as interveners. The facts are set
out in the judgment of Lord Sumption.

_Timothy Otty QC and Paul Luckhurst (instructed by ATLEU) for the appellant/cross-respondent._

**[*619] Sir Daniel Bethlehem KCMG QC and Sudhanshu Swaroop QC (instructed by Reynolds Porter Chamberlain**
_LLP) for the respondents/cross-appellants._

_Richard Hermer QC, Tom Hickman, Flora Robertson and Philippa Webb (instructed by Deighton Pierce Glynn) for_
the intervener (Kalayaan) (written submissions only).

_Ben Jaffey QC and Jessica Wells (instructed by the Government Legal Department) for the intervener (Secretary of_
State for Foreign and Commonwealth Affairs) (written submissions only).

18 October 2017. The following judgments were delivered.

**LORD SUMPTION**

(with whom Lord Neuberger agrees).
**Introduction**

**[1] Ms Reyes, a Philippine national, was employed by Mr and Mrs Al-Malki as a domestic servant in their residence**
in London between 19 January and 14 March 2011. Her duties were to clean, to help in the kitchen at mealtimes
and to look after the children. At the time, Mr Al-Malki was a member of the diplomatic staff of the embassy of Saudi
Arabia in London. Ms Reyes alleges that she entered the United Kingdom on a Tier 5 visa which she obtained at
the British embassy in Manila by producing documents supplied by Mr Al-Malki, including a contract showing that
she would be paid £500 per month. She alleges that during her employment the Al-Malkis maltreated her by
requiring her to work excessive hours, failing to give her proper accommodation, confiscating her passport and
preventing her from leaving the house or communicating with others; and that they paid her nothing until after her
employment terminated upon her escape on 14 March. The proceedings have been conducted to date on the
assumption, which has been neither proved nor challenged, that these allegations are true. I shall also make that
assumption. In addition, I shall assume that these allegations amount to trafficking in persons within the meaning of
the International Protocol to Prevent, Supress and Punish Trafficking in Persons, Especially Women and Children
(Palermo, 2000), although that is very much in dispute.

**[2] In June 2011, Ms Reyes began the present proceedings in the Employment Tribunal alleging direct and indirect**
race discrimination, unlawful deduction from wages and failure to pay her the national minimum wage. The Court of
[Appeal ([2015] EWCA Civ 32, [2016] 2 All ER 136, [2016] 1 WLR 1785) has held that the Employment Tribunal has](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JF5-45X1-DYBP-M0GN-00000-00&context=1519360)
no jurisdiction because Mr Al-Malki was entitled to diplomatic immunity under art 31 of the Vienna Convention on
Diplomatic Relations 1961 (Vienna, 18 April 1961; TS 19 (1965); Cmnd 2565), and Mrs Al-Malki was entitled to a
derivative immunity under art 37(1) as a member of his family.

**[3] The main issues on the appeal concern the effect of art 31(1)(c) of the Convention, which contains an exception**
to the immunity of a diplomat from civil jurisdiction where the proceedings relate to 'any professional or commercial
activity exercised by the diplomatic agent in the receiving state

**[*620] outside his official functions'. This raises, among other issues, the question how, if at all, that exception**
applies to a case of human trafficking. Since there is some evidence that human trafficking under cover of
diplomatic status is a recurrent problem, this is a question of some general importance. Its broader significance
explains the intervention, by leave of this court, of the Secretary of State for Foreign and Commonwealth Affairs and
of Kalayaan, a charity that supports migrant domestic workers, some of whom have been trafficked. For the same


-----

reason, I shall deal fully with the issues that were argued in the Court of Appeal and before us, although not all of
them arise on the conclusions that I have reached.

**[4] In my opinion, the employment of a domestic servant to provide purely personal services is not a 'professional or**
commercial activity exercised by the diplomatic agent'. It is therefore not within the only relevant exception to the
immunities. The fact that the employment of Ms Reyes may have come about as a result of human trafficking
makes no difference to this. But the appeal should be allowed on a different and narrower ground. On 29 August
2014, Mr Al-Malki's posting in London came to an end and he left the United Kingdom. Article 31 confers immunity
only while he is in post. A diplomatic agent who is no longer in post and who has left the country is entitled to
immunity only on the narrower basis authorised by art 39(2). That immunity applies only so far as the relevant acts
were performed while he was in post in the exercise of his diplomatic functions. The employment and maltreatment
of Ms Reyes were not acts performed by Mr Al-Malki in the exercise of his diplomatic functions.
**The legal framework**

**[5] The legal immunity of diplomatic agents is one of the oldest principles of customary international law. Its history**
can be traced back to the practices of the ancient world and to Roman writers of the second century. 'The rule has
been accepted by the nations', wrote Grotius in the seventeenth century, 'that the common custom which makes a
person who lives in foreign territory subject to that country, admits of an exception in the case of ambassadors': De
_Jure Belli ac Pacis, ii.18. But, although recognition of diplomatic immunity is all but universal in principle, until_
relatively recently both states and writers differed on the categories of people to which the immunity applied and its
precise ambit in each category. In particular, they differed on the existence and extent of any exceptions. In Britain,
the matter was dealt with by the Diplomatic Privileges Act 1708, which conferred absolute immunity on
ambassadors and their staff from civil jurisdiction, in accordance with what British authorities regarded as the rule of
international law. In Triquet v Bath (1764) 3 Burr 1478 at 1480, (1764) 97 ER 936 at 937Lord Mansfield described
the Act as declaratory of the law of nations, and it remained in force until 1964. The United States adopted the
British Act in 1790, and France adopted a corresponding rule by legislation in 1794. In other countries, however,
exceptions of greater or lesser breadth were recognised, among others for private transactions relating to title to
real property, certain employment disputes and liabilities arising out of business activities in the receiving state.
There were also differences about the application of the

**[*621] immunity to diplomatic agents of a sending state who were nationals of the receiving state.**

**[6] These differences gave rise to a number of attempts during the nineteenth and twentieth centuries to codify the**
law of diplomatic relations with a view to achieving a common set of rules and enabling them to operate on a
reciprocal basis. The Havana Convention among the states of the Pan-American Union (1928) and the influential
draft convention drawn up by the Harvard Law School (1932) were notable examples. But there was no universally
accepted code before 1961. The Vienna Convention on Diplomatic Relations, which was adopted in that year, has
been described by Professor Denza, the leading academic authority on the law of diplomatic relations, as 'a
cornerstone of the modern international order': Diplomatic Law (4th edn, 2016) p 1. It has been perhaps the most
notable single achievement of the International Law Commission of the United Nations. The text was the result of
an intensive process of research, consultation and deliberation extending from 1954 to 1961. Draft articles were
submitted to the governments of every member state of the United Nations, and were subject to detailed review and
comment. Eighty one states participated in the final conference at Vienna in March and April 1961 which preceded
the adoption of the final text. Since its adoption, it has been ratified by 191 states, being every state in the world bar
four (Palau, the Solomon Islands, South Sudan and Vanuatu). A number of states ratified subject to declarations or
reservations, but none of these related to the articles which are primarily relevant on this appeal. As it stands, the
Convention provides a complete framework for the establishment, maintenance and termination of diplomatic
relations. It not only codifies pre-existing principles of customary international law relating to diplomatic immunity,
but resolves points on which differences among states had previously meant that there was no sufficient consensus
to found any rule of customary international law.

**[7] As the International Court of Justice has pointed out (Democratic Republic of the Congo v Belgium (Case**
_concerning Arrest Warrant of 11 April 2000)_ [2002] ICJ Rep 3 at paras 59–61), diplomatic immunity is not an
immunity from liability. It is a procedural immunity from the jurisdiction of the courts of the receiving state. The


-----

receiving state cannot at one and the same time receive a diplomatic agent of a foreign state and subject him to the
authority of its own courts in the same way as other persons within its territorial jurisdiction. But the diplomatic agent
remains amenable to the jurisdiction of his own country's courts, and in important respects to the jurisdiction of the
courts of the receiving state after his posting has ended. I do not under-estimate the practical problems of litigating
in a foreign jurisdiction, especially for someone in Ms Reyes's position. Nor do I doubt that diplomatic immunity can
be abused and may have been abused in this case. A judge can properly regret that it has the effect of putting
severe practical obstacles in the way of a claimant's pursuit of justice, for what may be truly wicked conduct. But he
cannot allow his regret to whittle away an immunity sanctioned by a fundamental principle of national and
international law. As the fourth recital of the Vienna Convention points out, 'the purpose of such privileges and
immunities is not to benefit individuals but to ensure the efficient

**[*622] performance of diplomatic missions as representing states'.**

**[8] Diplomatic immunity is dealt with at arts 22 and 29 to 40 of the Convention. These provisions confer different**
degrees of immunity on persons connected with a diplomatic mission, according to their status and function. For
present purposes, the provisions primarily relevant are as follows:

**'Article 22**

1. The premises of the mission shall be inviolable. The agents of the receiving state may not enter them,
except with the consent of the head of the mission.

2. The receiving state is under a special duty to take all appropriate steps to protect the premises of the
mission against any intrusion or damage and to prevent any disturbance of the peace of the mission or
impairment of its dignity.

**Article 29**

The person of a diplomatic agent shall be inviolable. He shall not be liable to any form of arrest or detention.
The receiving state shall treat him with due respect and shall take all appropriate steps to prevent any attack on
his person, freedom or dignity.

**Article 30**

1. The private residence of a diplomatic agent shall enjoy the same inviolability and protection as the premises
of the mission.

**Article 31**

1. A diplomatic agent shall enjoy immunity from the criminal jurisdiction of the receiving state. He shall also
enjoy immunity from its civil and administrative jurisdiction, except in the case of:

(a)   a real action relating to private immovable property situated in the territory of the receiving State,
unless he holds it on behalf of the sending State for the purposes of the mission;

(b)   an action relating to succession in which the diplomatic agent is involved as executor, administrator,
heir or legatee as a private person and not on behalf of the sending state;

(c)   an action relating to any professional or commercial activity exercised by the diplomatic agent in the
receiving State outside his official functions.

2. A diplomatic agent is not obliged to give evidence as a witness.

3. No measures of execution may be taken in respect of a diplomatic agent except in the cases coming under
sub-paragraphs (a), (b) and (c) of paragraph 1 of this article, and provided that the measures concerned can be
taken without infringing the inviolability of his person or of his residence.


-----

4. The immunity of a diplomatic agent from the jurisdiction of the receiving state does not exempt him from the
jurisdiction of the sending state.

**[*623] Article 32**

1. The immunity from jurisdiction of diplomatic agents … may be waived by the sending state.

**Article 37**

1. The members of the family of a diplomatic agent forming part of his household shall, if they are not nationals
of the receiving state, enjoy the privileges and immunities specified in articles 29 to 36.

**Article 38**

1. Except insofar as additional privileges and immunities may be granted by the receiving state, a diplomatic
agent who is a national of or permanently resident in that state shall enjoy only immunity from jurisdiction, and
inviolability, in respect of official acts performed in the exercise of his functions.

**Article 39**

2. When the functions of a person enjoying privileges and immunities have come to an end, such privileges and
immunities shall normally cease at the moment when he leaves the country, or on expiry of a reasonable
period in which to do so, but shall subsist until that time, even in case of armed conflict. However, with respect
to acts performed by such a person in the exercise of his functions as a member of the mission, immunity shall
continue to subsist …

**Article 41**

1. Without prejudice to their privileges and immunities, it is the duty of all persons enjoying such privileges and
immunities to respect the laws and regulations of the receiving state.

**Article 42**

A diplomatic agent shall not in the receiving state practise for personal profit any professional or commercial
activity.'

**[9]** _[Section 2(1) of the Diplomatic Privileges Act 1964 provides that the articles of the Vienna Convention annexed](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61C0-TWPY-Y0D1-00000-00&context=1519360)_
in Sch 1 'shall have the force of law in the United Kingdom'. Schedule 1 contains arts 1, 22 to 40 and 45 of the
Convention. They include all the articles dealing with diplomatic immunities.
**Principles of interpretation**

**[10] It is not in dispute that so far as an English statute gives effect to an international treaty, it falls to be interpreted**
by an English court in accordance with the principles of interpretation applicable to treaties as a matter of
international law. That is especially the case where the statute gives effect not just to the substance of the treaty but
[to the text: Fothergill v Monarch Airlines Ltd [1980–84] LRC (Comm) 215, esp at 218–220, 222–224, 227–228, 235–](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5M61-F6S1-DYJ0-80X3-00000-00&context=1519360)
236, _[[1980] 2 All ER 696, esp at 699–700, 702–704, 706–707, 712, per Lord Wilberforce, Lord Diplock and Lord](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KV0-TWP1-6134-00000-00&context=1519360)_
Scarman respectively.

**[11] The primary rule of interpretation is laid down in art 31(1) of the Vienna Convention on the Law of Treaties**
(Vienna; 23 May to 30 November

**[*624] 1969; TS 58 (1980); Cmnd 7964): 'A treaty shall be interpreted in good faith in accordance with the ordinary**
meaning to be given to the terms of the treaty in their context and in the light of its object and purpose.' The
principle of construction according to the ordinary meaning of terms is mandatory ('shall'), but that is not to say that
a treaty is to be interpreted in a spirit of pedantic literalism. The language must, as the rule itself insists, be read in
its context and in the light of its object and purpose. However, the function of context and purpose in the process of


-----

interpretation is to enable the instrument to be read as the parties would have read it. It is not an alternative to the
text as a source for determining the parties' intentions.

**[12] In the case of the Convention on Diplomatic Relations, there are particular reasons for adhering to these**
principles:

(1)   Like other multilateral treaties, the text was the result of an intensely deliberative process in which
the language of successive drafts was minutely reviewed and debated, and if necessary amended. The
text is the only thing that all of the many states party to the Convention can be said to have agreed. The
scope for inexactness of language is limited.

(2)   The Convention must, in order to work, be capable of applying uniformly to all states. The more
loosely a multilateral treaty is interpreted, the greater the scope for damaging divergences between
different states in its application. A domestic court should not therefore depart from the natural meaning of
the Convention unless the departure plainly reflects the intentions of the other participating states, so that it
can be assumed to be equally acceptable to them. As Lord Slynn observed in R v Secretary of State for
_[the Home Dept, ex p Adan [2001] 1 All ER 593 at 597, [2001] 2 AC 477 at 509, an international treaty has](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-4J90-TWP1-6023-00000-00&context=1519360)_
only one meaning. The courts 'cannot simply adopt a list of permissible or legitimate or possible or
reasonable meanings and accept that any one of those when applied would be in compliance with the
Geneva Convention'.

(3)   Although the purpose of stating uniform rules governing diplomatic relations was 'to ensure the
efficient performance of the functions of diplomatic missions as representing states', this is relevant only to
explain why the rules laid down in the Convention are as they are. The ambit of each immunity is defined
by reference to criteria stated in the articles, which apply generally and to all state parties. The recital does
not justify looking at each application of the rules to see whether on the facts of the particular case the
recognition of the defendant's immunity would or would not impede the efficient performance of the
diplomatic functions of the mission. Nor can the requirements of functional efficiency be considered simply
in the light of conditions in the United Kingdom. The courts of the United Kingdom are independent and
their procedures fair. It is difficult to envisage that exposure to civil claims would materially interfere with
the efficient performance of diplomatic missions. But as the Secretary of State for Foreign and
Commonwealth Affairs pointed out, the same cannot be assumed of every legal system in every state. The
threat to the efficient performance of diplomatic functions arises at least as much from the risk of trumped
up or baseless allegations and

**[*625] unsatisfactory tribunals as from justified ones subject to objective forensic appraisal. It may fairly be**
said that from the United Kingdom's point of view, a significant purpose of conferring diplomatic immunity of
foreign diplomatic personnel in Britain is to ensure that British diplomatic personnel enjoy corresponding
immunities elsewhere.

(4)   Every state party to the Convention is both a sending and receiving state. The efficacy of the
Convention depends, even more than most treaties do, on its reciprocal operation. Article 47(2) of the
Convention authorises any receiving state to restrict the application of a provision to the diplomatic agents
of a sending state if that state gives a restrictive application of that provision as applied to the receiving
state's own mission. In some jurisdictions, such as the United States, the recognition of diplomatic
immunities is dependent as a matter of national law on their reciprocity. As Professor Denza observes, p 2:
'For the most part, failure to accord privileges or immunities to diplomatic missions or their members is
immediately apparent and is likely to be met by appropriate countermeasures.' In the graphic words of her
introduction to the Vienna Convention on the United Nations law website, a state's 'own representatives
abroad are in a sense hostages who may on a basis of reciprocity suffer if it violates the rules of diplomatic
immunity': http://legal.un.org/avl/ha/vcdr/vcdr.html.

**Service of process**

**[13] A preliminary question arises on this appeal as to whether the claim form was validly served on the Al-Malkis.**
A number of modes of service were attempted, but the only one which is now relied on is service by post to their
private residence in accordance with r 61(1)(a) of the Employment Tribunals (Constitution and Rules of Procedure)


-----

Regulations 2004, _[SI 2004/1861. It is said on the Al-Malkis' behalf that the rule cannot authorise service on a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4SW6-WRX0-TX08-H1G7-00000-00&context=1519360)_
diplomatic agent because this would violate his person contrary to art 29 of the Convention and his residence
contrary to art 30. I can deal shortly with this point, because it has failed at every stage below and has been dealt
with by the Court of Appeal in terms with which I am in substantial agreement.

**[14] The starting point is that we are not at this point concerned with the question whether the diplomatic agent is**
immune from jurisdiction in respect of the particular proceedings. Other articles of the Convention deal with that.
Those articles recognise that the jurisdictional immunity of a diplomatic agent will not apply to all proceedings: they
may relate to a matter within an exception, or the immunity may have been waived. The present question is whether
there is an immunity from service, or from certain modes of service, implicit in the inviolability of a diplomat's person
and private residence. This immunity is distinct from and additional to his immunity from jurisdiction. If it applies,
then arts 29 and 30 of the Convention, being unqualified, must prevent service by post in all proceedings whether or
not there is any jurisdictional immunity in respect of them. Indeed, it would also apply to other communications by
the state which have nothing to do with legal proceedings, such as demands for rates or tax assessments on a
diplomat's

**[*626] private income, notwithstanding that these may be properly demanded under art 34 of the Convention.**

**[[15] In the case of states, the mode of service is prescribed by s 12 of the State Immunity Act 1978. Service must](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6150-TWPY-Y1GD-00000-00&context=1519360)**
be effected on a state by the transmission of the document through the Foreign and Commonwealth Office. Article
22 of the United Nations Convention on Jurisdictional Immunities of States and their Property 2004 (A/RES/59/38),
when it is in force, will require service of process on states to be effected on states through diplomatic channels in
the absence of agreement on any other mode of service. There is, however, no corresponding provision relating to
[service on diplomatic agents either in the Diplomatic Privileges Act 1964 or in the Vienna Convention on Diplomatic](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61B0-TWPY-Y0N2-00000-00&context=1519360)
Relations. According to the Secretary of State, a practice has become established of serving process on diplomatic
agents through diplomatic channels on the foreign state or its mission in the United Kingdom. But there is no
statutory basis for this practice. Nor, now that the law on diplomatic immunity has been codified, is there any basis
for it in international law, unless service violates the diplomatic agent's person or residence. Moreover, in the
absence of some basis in domestic law, it is not even a legally effective mode of service, since there is no way that
the foreign state can be required to accept service on behalf of the diplomatic agent, if it chooses not to do so.

**[16] The person of a diplomatic agent is violated if an agent of the receiving state or acting on the authority of the**
receiving state detains him, impedes his movement or subjects him to any personal restriction or indignity. It is
arguable that personal service on a diplomatic agent would do that, although it is not an argument that needs to be
considered here. Premises are violated if an agent of the state enters them without consent or impedes access to or
from the premises or normal use of them: see art 22 relating to the premises of a mission, which is applied by
analogy to a diplomatic agent's private residence under art 30(1). The delivery by post of a claim form does not do
any of these things. It simply serves to give notice to the defendant that proceedings have been brought against
him, so that he can defend his interests, for example by raising his immunity if he has any. The mere conveying of
information, however unwelcome, by post to the defendant, is not a violation of the premises to which the letter is
delivered. It is not a trespass. It does not affront his dignity or affect his right to enter or leave or use his home. It
does of course start time running for subsequent procedural steps and may lead to a default if no action is taken.
But so far as this is objectionable, it can only be because there is a relevant immunity from jurisdiction. It is not
because the proceedings were brought to the diplomatic agent's attention by post. Otherwise the same objection
would apply to any mode of service which starts time running, including service through diplomatic channels as
proposed by the Secretary of State.
**Jurisdictional immunity: article 31(1)(c)**

**[17] Articles 31 to 40 of the Convention represent an elaborate scheme which must be examined as a whole.**
Fundamental to its operation is the distinction, which runs through the whole instrument, between those

**[*627] immunities which are limited to acts performed in the course of a protected person's functions as a member**
or employee of the mission, and those which are not. The distinction is fundamental because what an agent of a
diplomatic mission does in the course of his official functions is done on behalf of the sending state. It is an act of


-----

the sending state, even though it may give rise to personal liability on the part of the individual agent. In such a
case, the individual agent is entitled to both diplomatic and state immunity, and the two concepts are practically
indistinguishable: see _Jones v Ministry of Interior of the Kingdom of Saudi Arabia (Secretary of State for_
_[Constitutional Affairs intervening), Mitchell v Al-Dali [2006] UKHL 26, [2007] 1 All ER 113, [2007] 1 AC 270(at [10],](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4MSH-2RS0-TWP1-600Y-00000-00&context=1519360)_

[66]–[78] per Lord Bingham and Lord Hoffmann respectively). By comparison, the acts which an agent of a
diplomatic mission does in a personal or non-official capacity are not acts of the state which employs him. They are
acts in respect of which any immunity conferred on him can be justified only on the practical ground that his
exposure to civil or criminal proceedings in the receiving state, irrespective of the justice of the underlying
allegation, is liable to impede the functions of the mission to which he is attached. The degree of impediment may
vary from state to state and from case to case. But the potential problem for the conduct of international relations
has been recognised from the earliest days of diplomatic intercourse, and in the United Kingdom ever since the
arrest of the Russian ambassador for debt as he returned from an audience with Queen Anne led to the passing of
the Diplomatic Privileges Act 1708.

**[18] The Vienna Convention distinguishes between diplomatic agents (ie ambassadors and members of their**
diplomatic staff), the administrative and technical staff of the mission, their respective families, and service staff of
the mission. The highest degree of protection is conferred on diplomatic agents. In their case, the Convention
substantially reproduces the previous rules of customary international law, by which a diplomatic agent was immune
from the jurisdiction of the receiving state (i) in respect of things done in the course of his official functions for an
unlimited period, and (ii) in respect of things done outside his official functions for the duration of his mission only:
[see Zoernsch v Waldock [1964] 2 All ER 256 at 261, 263, 265–266, [1964] 1 WLR 675 at 684, 688, 691–692 per](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP90-TWP1-605P-00000-00&context=1519360)
Willmer LJ, Danckwerts LJ and Diplock LJ respectively. Thus art 31(1) confers immunity on diplomatic agents
currently in post in respect of both private and official acts, subject to specific exceptions for the three designated
categories of private act. Under art 39(2), once a diplomatic agent's functions have come to an end, his immunities
under art 31 will normally cease from the moment when he leaves the territory of the receiving state. Thereafter, he
remains immune in the receiving state only with respect to 'acts performed … in the exercise of his functions as a
member of the mission'. This is commonly known as the 'residual' immunity. It is one of four cases in which, in
contrast to the immunity under art 31, a protected person's immunity is limited to official acts, the others being (i)
the immunity conferred on a diplomatic agent who is a national of or permanently resident in the receiving state,
which is limited to 'official acts performed in the exercise of his functions' (art 38(1)); (ii) the immunity conferred on
administrative and technical staff of a mission, which

**[*628] 'shall not extend to acts performed outside the course of their duties' (art 37(2)); and (iii) domestic staff of**
the mission, whose immunity is confined to 'acts performed in the course of their duties' (art 37(3)). The same
distinction applies to consular officers and employees under art 43 of the parallel Vienna Convention on Consular
Relations (Vienna, 24 April 1963). Their immunity is limited to 'acts performed in the exercise of consular functions'.

**[19] Article 31(1)(c) is one of three carefully framed exceptions to the general immunity from civil jurisdiction**
conferred on diplomatic agents in post. The exception applies if both of two conditions are satisfied: (i) that the
action relates to a 'professional or commercial activity exercised by the diplomatic agent', and (ii) that the exercise
of that activity was 'outside his official functions'. These are distinct requirements. If the relevant acts were within
the scope of the diplomat's official functions, the enquiry ends there. He is immune. Moreover, he will retain the
residual immunity in respect of them even after his posting comes to an end. But if he is still in post and the relevant
activity is outside his official functions, the operation of the exception will depend on whether it amounts to a
professional or commercial activity exercised by him.

**[20] Accordingly, the first question is what are a diplomatic agent's official functions. The starting point is the**
functions of the mission to which he is attached. They are defined in art 3 of the Convention, and comprise all the
classic representational and reporting functions of a diplomatic mission. It is, however, clear that the official
functions of an individual diplomatic agent are not necessarily limited to participating in the activities defined by art
3. They must in the nature of things extend to a wide variety of incidental functions which are necessary for the
performance of the general functions of the mission. But whether incidental or direct, a diplomatic agent's official
functions are those which he performs for or on behalf of the sending state. The test is whether the relevant activity
was part of those functions That is the basis on which the courts in both England and the United States have


-----

[approached the residual immunity in art 39(2): see, as to England, Wokuri v Kassam [2012] EWHC 105 (Ch), [2012]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55SM-PJ31-DYBP-M3MY-00000-00&context=1519360)
_[2 All ER 1195, [2013] Ch 80(at [23]–[26]) (Newey J) and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55SM-PJ31-DYBP-M3MY-00000-00&context=1519360)_ _Taddese v Abusabib_ [2013] ICR 603at paras 29–34
(Employment Appeal Tribunal); and as to the United States, Baoanan v Baja (2009) 627 F Supp 2d 155 at paras 3–
5; Swarna v Al-Awadi (2010) 622 F 3d 123 at paras 4–10 (Second Circuit Court of Appeals). I think that it is correct,
and equally applicable to the corresponding expression in art 31(1).

**[21] If the relevant activity was outside the diplomatic agent's official functions, the next question is whether it**
amounts to a professional or commercial activity exercised by him. The following points should be made about this:

(1)   An activity is not the same as an act. Article 31(1)(c) is concerned with the carrying on of a
professional or commercial activity having some continuity and duration, ie with a course of business.

(2)   But it is not only a question of continuity or duration. It is also a question of status. In the ordinary
meaning of the words, the 'exercise' of

**[*629] a 'professional or commercial activity' means practising the profession or carrying on the business.**
The diplomatic agent must be a person practising the profession or carrying on (or participating in carrying
on) the business. He must, so to speak, set up shop. The position is even clearer in the equally authentic
French text, where the word 'exercer' means 'to practise, follow, pursue, carry on (profession, business)': J
E Mansion Harrap's Standard French and English Dictionary (ed Ledésert) (rev 1980).

(3)   This is confirmed by art 42, which provides that a diplomatic agent 'shall not in the receiving state
practise for personal profit any professional or commercial activity'. Article 42 uses the same phrase,
'professional or commercial activity', as art 31(1)(c). The difference between the language of the exception
in art 31(1)(c) and that of the prohibition in art 42 is simply the use in the latter of the expression 'for
personal profit' in place of 'outside his official functions'. The essential point, however, is that in both
articles, the reference is to the diplomat carrying on or participating in a professional or commercial
business. This is what Laws J decided in the only English case on art 31(1) until this one: Propend Finance
_Pty Ltd v Sing (1997) 111 ILR 611 at 635–636 (the point did not arise in the Court of Appeal). I think that he_
was right.

(4)   As I shall demonstrate below, this is precisely what the draftsmen of the Convention and the states
who agreed it intended to achieve.

(5)   There are obvious reasons why an exception such as that in art 31(1)(c) should have been limited to
someone participating in a professional or commercial business. It is inherent in the concept of
jurisdictional immunity that it will shelter a serving diplomat (and in some circumstances a former diplomat)
against legal proceedings in the receiving state. It is not inherent in that concept that the immunity will
enable him to exercise a distinct business activity in competition with others while sheltering him from the
modes of enforcing the corresponding liabilities which are an ordinary incident of such an activity.

(6)   A wider scope for exception (c) would expose diplomatic agents in post in the United Kingdom (and
potentially British diplomatic agents abroad) to local proceedings not only in respect of their employment of
domestic servants but in respect of any transaction in the receiving state for money or money's worth, save
perhaps for those which were isolated or uncharacteristic. The substantial effect would be to limit the
immunity to acts done in the exercise of the diplomat's official functions, even in the case of a diplomat in
post. The immunity in respect of non-official acts would mean very little, for every purchase that a diplomat
might make in the course of his daily life from a business carried on by someone else would be a
commercial activity exercised by the diplomat for the purposes of art 31(1)(c). This would be contrary to the
carefully constructed scheme of the Convention for different categories of protected person.

**[*630] The authorities**

**[22] Apart from the decision of Laws J in** _Propend Finance Pty Ltd v Sing, to which I have just referred, the_
authorities most directly in point are decisions of the federal courts of the United States. These are a valuable
source of law in this area, because of the long-standing engagement of the US courts with international law and the
existence of a highly developed body of domestic foreign relations law belonging to the same tradition as our own.
The statutory background is substantially the same as it is in the United Kingdom. Section 5 of the US Diplomatic


-----

Relations Act 1978 provides that any action or proceeding brought against an individual entitled to immunity from
such action or proceeding under the Vienna Convention on Diplomatic Relations shall be dismissed. During the
passage of the Act, the State Department advised Congress that the exception in art 31(1)(c) merely exposed
diplomats to litigation based upon activity expressly prohibited in art 42: Diplomatic Immunity: Hearings on S 476, S
_477, S 478, S 1256 S 1257 and HR 7819_ (Senate Committee on the Judiciary, Subcommittee on Citizens' and
Shareholders Rights and Remedies), 95th Cong, 2d Sess 32 (1978). This advice, as I have pointed out above, was
in accordance with both the language and purpose of the Convention. It is also endorsed by the American Law
Institute's authoritative Restatement (3rd) of the Foreign Relations Law of the United States (1986) para 464, where
it is observed (Note 9) that—

'[t]he denial of immunity in cases arising out of private commercial or professional activities has little
significance for the United States since the United States forbids its diplomatic officers to engage in commercial
or professional activities unrelated to their official functions, and in general does not permit such activities by
foreign diplomats in the United States.'

**[23] The leading case is Tabion v Mufti (1996) 107 ILR 452, a decision of the Fourth Circuit Court of Appeals. The**
plaintiff was employed for two years as a domestic servant in the private residence of a Jordanian diplomat. Her
allegations were broadly similar to those of Ms Reyes. They included deception, false imprisonment and persistent
underpayment. In response to a claim for diplomatic immunity, her argument was that 'because “commerce” is
simply the exchange of goods and services … “commercial activity” necessarily encompasses contracts for goods
and services, including employment contracts.' The court examined the terms of the Convention and its background
and negotiating history, and upheld the claim for immunity on the principal ground that the expression 'commercial
activity' 'relates only to trade or business activity engaged in for personal profit' (at 454). In reaching this conclusion,
they took account of a statement of interest submitted by the State Department, which asserted that the exception
'focuses on the pursuit of trade or business activity; it does not encompass contractual relationships for goods and
services incidental to the daily life of the diplomat and family in the receiving State' (at 455). But they appear to
have gone rather further than the State Department in suggesting (at 455–456) that 'day to day living services …
incidental to daily life were also within a diplomatic agent's official functions'. Since a diplomat's acts in obtaining
day-to-day living services are remote from the performance of his

**[*631] official functions and are not done on behalf of the sending state, for my part, I do not find it possible to**
accept this last point. Even in the United States it appears to have been rejected in cases on the residual
immunities conferred by art 39(2) of the Convention, to which I have already referred (para [20]). But on their
principal ground, I think that the court was correct.

**[24] The decision in** _Tabion v Mufti_ has consistently been followed in other circuits on materially similar facts:
_Gonzales Paredes v Vila (2007) 479 F Supp 2d 187, Sabbithi v Al Saleh (2009) 605 F Supp 2d 122, vacated in part_
on other grounds, no 07 Civ 115 (DDC Mar S 2011); Montuya v Chedid (2011) 779 F Supp 2d 60; Fun v Pulgar
(2014) 993 F Supp 2d 470. It is also endorsed by Professor Denza: Diplomatic Law (4th edn, 2016) pp 251–253.

**[25] It is true that the Appeals Court's conclusion on the principal point was influenced by the State Department's**
statement of interest and that the constitutional division of powers in the United States requires the courts to show
'substantial deference' to the executive's views on such matters. But, like Lord Dyson MR in the Court of Appeal, I
do not regard this as undermining the authority of the decision. In the first place it is clearly established doctrine in
the United States that the views of the executive, although commanding respect, are not determinative: see
_Sumitomo Shoji America Inc v Avagliano (1982) 457 US 176 at 184–185, United States v Stuart (1989) 489 US 353_
at 369. Secondly, the US Court of Appeals plainly formed its own view on the questions at issue. Thirdly, the
Department's statement of interest, a copy of which has been put before us, is concerned mainly to put the
negotiating history before the court. Otherwise it simply analyses the relevant legal principles, very much as the
submissions of the Secretary of State as intervener have done on this appeal.
**Diplomatic and state immunity**

**[26] Mr Otty QC, who appeared for Ms Reyes, sought to reinforce his case on art 31(1)(c) by pointing out that under**
the restrictive theory of state immunity, the immunity of states is limited to acts which they perform as states. He


-----

argues that the functional analogies between state immunity and diplomatic immunity mean that a corresponding
rule should apply to the latter, ie that any act done in a purely private capacity must be regarded as 'commercial', or
at any rate as lying outside the permissible scope of the immunity. This argument in effect treats the words 'outside
his official functions' in art 31(1)(c) of the Convention on Diplomatic Relations as explanatory of the expression
'professional or commercial activities' and deprives the latter of any independent effect.

**[27] Manifestly, diplomatic and state immunity have a number of points in common. Both are immunities of the**
state, which can be waived only by the state. Both may extend to individual agents of the state, acting as such. Both
are creatures of international law. And, although only diplomatic immunity has been codified by treaty, the
embryonic United Nations Convention on Jurisdictional Immunities of States is generally regarded as an
authoritative statement of customary international law on the major points which it covers. These factors led Laws J,
in Propend Finance Pty Ltd v Sing (1997) 111 ILR 611 at 633–634 to suggest that 'the law relating to diplomatic
immunity is

**[*632] not free-standing from the law of sovereign or state immunity, but is an aspect of it', and to cite with**
[apparent approval a dictum of Jenkins LJ in Baccus SRL v Servicio Nacional del Trigo [1956] 3 All ER 715 at 734,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP60-TWP1-609F-00000-00&context=1519360)

[1957] 1 QB 438 at 470to the effect that the protection accorded to a diplomat under the Diplomatic Privileges Act
1708 (then in force) could not be greater than that accorded to a foreign sovereign.

**[28] However, the analogy should not be pressed too far. In some significant respects, the immunities of diplomatic**
agents are wider than those of the state. This is because their purpose is to remove from the jurisdiction of the
receiving state persons who are within its territory and under its physical power. Human agents have a corporeal
[vulnerability not shared by the incorporeal state which sent them. Section 16 of the State Immunity Act 1978, which](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6160-TWPY-Y0G3-00000-00&context=1519360)
defines the ambit of state immunity in the United Kingdom, and art 3 of the UN Convention on the Jurisdictional
Immunities of States, both provide that the rules relating to state immunity are not to affect diplomatic immunity.
These provisions are necessary because, as Professor Denza points out in Diplomatic Law (4th edn, 2016) p 1:

'As international rules on state immunity have developed on more restrictive lines, there has always been a
saving for the rules of diplomatic and consular law and an increasing understanding that although these sets of
rules overlap they serve different purposes and cannot in any sense be unified.'

**[29] For present purposes, the most significant difference in the ambit of the two categories of immunity concerns**
[the treatment of acts of a private law character. Section 3(1)(a) of the State Immunity Act 1978, which defines the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6160-TWPY-Y0VV-00000-00&context=1519360)
ambit of state immunity in the United Kingdom, provides that a state is not immune in respect of proceedings
relating to a 'commercial transaction entered into by the state'. For this purpose, a commercial transaction is a
'transaction or activity (whether of a commercial, industrial, financial, professional or other similar character) into
which a state enters or in which it engages otherwise than in the exercise of sovereign authority': s 3(3)(c). The
corresponding provisions of the United Nations Convention on Jurisdictional Immunities of States are in almost
identical terms: see arts 2(1)(c) and 10. In _I Congreso del Partido_ _[[1981] 2 All ER 1064 at 1074, sub nom](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KT0-TWP1-60K0-00000-00&context=1519360)_ _Playa_
_Larga (Owners of cargo lately laden on board) v I Congreso del Partido (Owners) [1983] 1 AC 244 at 267, Lord_
Wilberforce, after reviewing the national and international authorities, held that the section gave statutory effect to
the distinction in international law between acts jure imperii and acts jure gestionis. Its application depended on—

'whether the relevant act(s) upon which the claim is based, should, in that context, be considered as fairly
within an area of activity, trading or commercial, or otherwise of a private law character, in which the state has
chosen to engage, or whether the relevant act(s) should be considered as having been done outside that area,
and within the sphere of governmental or sovereign activity.'

**[30] The difficulty about the appellant's proposed analogy between state**

**[*633] and diplomatic immunity is that the immunity of a diplomat in post, unlike that of a state, unquestionably**
extends to some transactions which are outside his official functions, and therefore almost inevitably of a private law
character. I have drawn attention above (paras [17]–[18]) to the distinction which runs through the Convention on
Diplomatic Relations and the parallel Vienna Convention on Consular Relations (Vienna, 24 April 1963), between
those immunities which are limited to acts performed in the course of a protected person's official functions and


-----

those enjoyed by diplomatic agents in post, which are not so limited. It is plain from this scheme that the exception
for 'commercial activities' exercised by a diplomatic agent is not simply another way of excepting acts in the
performance of the diplomat's official functions. Moreover, the immunities of a diplomatic agent in post are extended
by art 37(1) of the Convention to his family, who will generally have no official functions.

**[31] It is right to add that contracts of employment are not treated as a commercial transaction for the purposes of**
[the State Immunity Act 1978: see s 3(c). They are subject to a distinct code under s 4, which provides that subject](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6160-TWPY-Y1K0-00000-00&context=1519360)
to specified exceptions a state is not immune as respects proceedings relating to a contract of employment made in
or to be performed in the United Kingdom. There are broadly corresponding provisions in art 11 of the United
Nations Convention. However, although the status of private servants is the subject of a number of provisions of the
Convention on Diplomatic Relations, there is no provision in it corresponding to s 4 of the United Kingdom State
Immunity Act or art 11 of the United Nations Convention.

**[32] These differences explain why the authorities on which Mr Otty principally relied for this point are not of much**
assistance. With one exception (to which I shall return), they were cases about state immunity, in which the court
applied the classic distinction between acts jure gestionis and jure imperii to the employment of non-diplomatic staff.
Thus in _United States v Public Service Alliance of Canada, Re Canada Labour Code_ _[[1993] 2 LRC 78, [1992] 2](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JX4-YNV1-DYJ0-82K7-00000-00&context=1519360)_
SCR 50 the question at issue was whether the United States was entitled to state immunity under the Canadian
State Immunity Act in proceedings relating to the terms on which it employed Canadian citizens at a US naval base
in Canada. In particular, objection was taken to the inclusion of a 'no strike' term. The case had nothing to do with
diplomatic immunity. The issue had a superficial resemblance to the present one only because the Canadian State
Immunity Act excepted any 'commercial activity' from the scope of the immunity. It is, however, clear from the
reasoning of the majority of the Supreme Court of Canada that in the context of a statute designed to give effect to
the restrictive doctrine of state immunity in customary international law, a 'commercial activity' meant an act done
[otherwise than in the exercise by the state of sovereign authority: see [1993] 2 LRC 78 at 89–91, [1992] 2 SCR 50](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JX4-YNV1-DYJ0-82K7-00000-00&context=1519360)
at 71–73 (La Forest J). The court ultimately held that while some obligations of an employer (for example, to pay
wages) were enforceable in the Canadian courts as being of a private law character, a state employer's imposition
of terms judged appropriate to the military function of the base was an exercise of sovereign authority and as such
immune. In the United States, where the Foreign Sovereign Immunities

**[*634] Act has an exception in the same terms as the Canadian Act, the same approach has been adopted: see El-**
_Hadad v Embassy of the United Arab Emirates (2000) 216 F 3d 29; Park v Shin (2002) 313 F 3d 1138 at paras 27–_
36.

**[33] The exception is Fonseca v Larren (30 January 1991), a decision of the Supreme Court of Portugal, reported in**
_State Practice regarding State Immunities (Council of Europe, 2006). This was a true case of diplomatic immunity,_
in which the court held that art 31 of the Convention on Diplomatic Relations did not apply to the employment of a
domestic servant in the private residence of a French diplomatic agent. The court did not claim to be applying the
exception in art 31(1)(c). Instead they applied to the Convention a principle sanctioned by the Portuguese Civil
Code in the case of domestic legislation, which called for what the court regarded as an 'extensive interpretation of
this precept [jurisdictional immunity] in keeping with its spirit, going beyond its letter and the “ratio legis” that
determined it'. On that basis, they appear to have recognised an implied additional exception to the immunity for
matters within the jurisdiction of the Portuguese Labour Courts, on the ground that such acts would not constitute
exercises of sovereign authority under the restrictive doctrine of state immunity. It is apparent that the Portuguese
court proceeded on domestic law principles of construction which would not be applied to a treaty in England (or
internationally), and on the basis of an analogy with state immunity which is difficult to support on any generally
accepted principles of international law.
**The travaux**

**[34] These conclusions are confirmed by an examination of the travaux préparatoires.**

**[35] Of the three exceptions in art 31(1), only (a), relating to private dealings with immovable property in the**
receiving state, had been recognised by customary international law before the Convention. Exceptions (b) and (c)
were matters on which states had not previously been agreed, and exception (c) was particularly controversial. It


-----

had not been included in the draft articles submitted by the Special Rapporteur (Mr Sandstrőm) at the outset of the
process. It was introduced by amendment by the Austrian Commissioner on 22 May 1957 in the course of the Ninth
Session: see Yearbook of the International Law Commission 1957, i, 97, paras 70–81. As originally introduced, it
was confined to professional activities. This was said to be akin to art 24 of the Harvard draft articles of 1932, which
referred to a person who 'engages in a business or who practises a profession'. The proposer considered that
cases to which the amendment would apply would be 'comparatively rare', and even those who opposed it agreed
with this. They opposed it on the ground that diplomatic agents 'practically never' engaged in such activities, which
would be inconsistent with the dignity of their diplomatic status. The Egyptian Commissioner supported the
amendment and proposed to add the reference to a 'commercial activity':

'If a diplomatic agent engaged in a professional or commercial activity—the word “commercial” should
undoubtedly be inserted in the amendment—he should enjoy no immunity, but be treated on precisely

**[*635] the same footing as other persons who practised the same profession or engaged in the same**
commercial activities … The dignity itself of a diplomatic agent required that he should not engage in activities
outside his official duties.'

He then proposed the text of what became art 31(1)(c), which was adopted.

**[36] In May 1958, the Special Rapporteur reported to the Commission on observations received from governments.**
He reported that the United States had opposed the inclusion of exception (c). But the Special Rapporteur proposed
that it should be retained, observing: 'It would be quite improper if a diplomatic agent, ignoring the restraints which
his status ought to have imposed upon him, could, by claiming immunity, force the client to go abroad in order to
have the case settled by a foreign court.' Commenting on the suggestion of the Australian government that
commercial activity 'appears to require some definition', he observed: '[T]he use of the words “commercial activity”
as part of the phrase “a professional or commercial activity” indicates that it is not a single act of commerce which is
meant [but] a continuous activity.' The Special Rapporteur's comment was reviewed in the course of the Tenth
Session in 1958: Yearbook of the International Law Commission 1958, i, 244 (paras 26–34). It was suggested by
the Czechoslovakian commissioner in response to the commentary on exception (c) that the text might in fact cover
an isolated commercial transaction. Sir Gerald Fitzmaurice (Rapporteur for the Session) questioned this:

'Paragraph 1(c) of the article applied to cases where a diplomatic agent conducted a regular course of
business “on the side”. Such isolated transactions as, for instance, buying or selling a picture, were precisely
typical of the transactions not subject to the civil jurisdiction of the receiving State. Annoying as it might be for
the other parties to such transactions in the event of a dispute, it was essential not to except such transactions
from the general rule for, once any breach was made in the principle, the door would be open to a gradual
whittling away of the diplomatic agent's immunities from jurisdiction.'

In the result, the observation in the commentary was deleted, the consensus being that the text was clear and the
observation unnecessary. The report on the session to the General Assembly (ibid, ii, 98) commented on exception
(c) in the following terms:

'The third exception arises in the case of proceedings relating to a professional or commercial activity
exercised by the diplomatic agent outside his official functions. It was urged that activities of these kinds are
normally wholly inconsistent with the position of a diplomatic agent, and that one possible consequence of his
engaging in them might be that he would be declared persona non grata. Nevertheless, such cases may occur
and should be provided for, and if they do occur the persons with whom the diplomatic agent has had
commercial or professional relations cannot be deprived of their ordinary remedies.'

**[*636] [37] Article 42 was inserted at a very late stage, by an amendment proposed by the Colombian delegation at**
the international conference of March and April 1961 which immediately preceded the adoption of the final text:
United Nations Conference on Diplomatic Intercourse and Immunities (1961), i, 172 (paras 24–27), 211–213 (paras
1–37). The reason advanced by the proposer of the amendment was that otherwise what became art 31(1)(c) might
be read as implicitly authorising the exercise of professional or commercial activities, albeit on the basis that it was
not immune Everyone agreed that that would be incompatible with diplomatic status It was therefore proposed that


-----

the Convention should affirm in a separate article the existing understanding that the carrying on of a business or
profession by a diplomatic agent in the territory of the receiving state was incompatible with diplomatic status. The
proposer considered that it was desirable to limit the occasions on which exception (c) would arise by avoiding a
situation in which 'the diplomatic agent would be acting simultaneously in two different capacities, only one of which
was covered by diplomatic privileges and immunities'. The discussion which followed showed that the principle was
generally accepted, on the footing that the prohibited activities covered what the Ecuadorian delegate called 'the
exercise of an outside gainful activity', and the delegate of Ceylon 'a regular professional activity from which a
permanent income was derived, and not an occasional activity, particularly of a cultural character'. There was
general agreement that it would not extend to occasional activities such as lecturing, even if paid. All the
participants took it for granted that the activity which gave rise to the exception in art 31(1)(c) was the same as the
activity which was treated as incompatible with the status of a diplomatic agent in art 42.

**[38] From this history, three points can be extracted:**

(1)   the activities covered by arts 31(1)(c) and 42 were intended to be the same;

(2)   they were activities involving the assumption by a diplomatic agent of a dual status, by which
incompatible occupations were being pursued by the same person; and

(3)   occasions for the operation of either provision were expected to be very rare.

**The trafficking dimension**

**[39] The Protocol to Prevent, Supress and Punish Trafficking in Persons, Especially Women and Children**
(Palermo, 2000) supplements the United Nations Convention against Transnational Organised Crime. Article 3
defines 'trafficking in persons' as—

'the recruitment, transportation, transfer, harbouring or receipt of persons, by means of the threat or use of
force or other forms of coercion, of abduction, of fraud, of deception, of the abuse of power or of a position of
vulnerability or of the giving or receiving of payments or benefits to achieve the consent of a person having
control over another person, for the purpose of exploitation. Exploitation shall include, at a minimum, the
exploitation of the prostitution of others or other forms of

**[*637] sexual exploitation, forced labour or services, slavery or practices similar to slavery, servitude or the**
removal of organs.'

Article 5 requires state parties to establish trafficking as a criminal offence and to ensure that their legal systems
afford victims the possibility of obtaining compensation. The Protocol has been ratified by 168 states, including the
United Kingdom and Saudi Arabia, and by the European Union.

**[40] It is in principle possible for a rule of customary international law to be displaced by another rule of a higher**
order, or for a treaty obligation to be displaced by a peremptory norm (jus cogens) of international law, ie by a
conflicting rule of international law permitting no derogation: see, as to treaty obligations, art 53 of the Vienna
Convention on the Law of Treaties. But Mr Otty QC expressly disclaimed reliance on any such principle. He was in
my view right to do so, for reasons which should be mentioned since they have a bearing on his other arguments.
Diplomatic immunity, like state immunity, is an immunity from jurisdiction and not from liability. Its practical effect is
to require the diplomatic agent to be sued in his own country, or in respect of non-official acts in the receiving state,
once his posting has ended. There is therefore no conflict between a rule categorising specified conduct as
wrongful, and a rule controlling the jurisdictions in which or the time at which it may properly be enforced. It was for
this reason that in Jones v Ministry of Interior of the Kingdom of Saudi Arabia (Secretary of State for Constitutional
_[Affairs intervening), Mitchell v Al-Dali [2007] 1 LRC 492, [2007] 1 All ER 113, Lord Bingham (para [24]) and Lord](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-8384-00000-00&context=1519360)_
Hoffmann (para [44]) both adopted the observation of Hazel Fox in the then current edition of _The Law of State_
_Immunity_ (2002) p 525, that state immunity 'does not contradict a prohibition contained in a _jus cogens_ norm but
merely diverts any breach of it to a different method of settlement'. In _Jurisdictional Immunities of the State_
_(Germany v Italy (Greece intervening)), the International Court of Justice endorsed the Appellate Committee's_
reasoning on this point, and gave it what is perhaps its clearest expression at paras 92–97. Rejecting an argument


-----

based on the peremptory character of the prohibition of war crimes and crimes against humanity, the court put the
matter in this way:

'This argument therefore depends upon the existence of a conflict between a rule, or rules, of jus cogens, and
the rule of customary law which requires one State to accord immunity to another. In the opinion of the Court,
however, no such conflict exists. Assuming for this purpose that the rules of the law of armed conflict which
prohibit the murder of civilians in occupied territory, the deportation of civilian inhabitants to slave labour and
the deportation of prisoners of war to slave labour are rules of jus cogens, there is no conflict between those
rules and the rules on state immunity. The two sets of rules address different matters. The rules of state
immunity are procedural in character and are confined to determining whether or not the courts of one state
may exercise jurisdiction in respect of another state. They do not bear upon the question whether or not the
conduct in respect of which the proceedings are brought was lawful or unlawful … The application of rules of
state

**[*638] immunity to determine whether or not the Italian courts have jurisdiction to hear claims arising out of**
those violations cannot involve any conflict with the rules which were violated.'

The court went on to point out that the existence of an international law obligation to provide for the recovery of
compensation made no difference to this analysis:

'Nor is the argument strengthened by focusing upon the duty of the wrongdoing state to make reparation,
rather than upon the original wrongful act. The duty to make reparation is a rule which exists independently of
those rules which concern the means by which it is to be effected. The law of state immunity concerns only the
latter; a decision that a foreign state is immune no more conflicts with the duty to make reparation than it does
with the rule prohibiting the original wrongful act … To the extent that it is argued that no rule which is not of the
status of jus cogens may be applied if to do so would hinder the enforcement of a jus cogens rule, even in the
absence of a direct conflict, the Court sees no basis for such a proposition. A jus cogens rule is one from which
no derogation is permitted but the rules which determine the scope and extent of jurisdiction and when that
jurisdiction may be exercised do not derogate from those substantive rules which possess jus cogens status,
nor is there anything inherent in the concept of _jus cogens_ which would require their modification or would
displace their application.'

**[41] In these circumstances, Mr Otty wisely confined his case on this aspect of the appeal to the proposition that the**
international obligation to recognise a crime and a tort of human trafficking affected the scope of the exception for
professional or commercial activities in art 31(1)(c) of the Convention on Diplomatic Relations. The argument is (i)
that trafficking is treated by the Palermo Protocol as an inherently commercial activity, in which an employer
participates by employing the victim; and (ii) that the profit element, if it is required, is established by the financial
benefit which the employer generally obtains by paying less than the going rate or the legal minimum or nothing at
all.

**[42] The fundamental difficulty about this argument is that it involves modifying the concept of a 'professional or**
commercial activity' in the light of the growing concern of international law with human trafficking subsequent to the
Convention on Diplomatic Immunity. There are limited circumstances in which this is a legitimate technique of
interpretation, but it is subject to principled limits. Article 31(2) and (3)(a) and (b) of the Vienna Convention on the
Law of Treaties envisage that a treaty may in appropriate cases be interpreted in the light of a linked treaty, whether
made at the same time or subsequently. Linked treaties are generally interpretative or explanatory of the principal
treaty. It is not suggested that the principle applies here. But a broader principle is applied by art 31(3)(c) of the
Vienna Convention on the Law of Treaties, which requires account to be taken of 'any relevant rules of international
law applicable in the relations between the parties'. The effect is

**[*639] to make limited provision for the interpretation of treaties in the light of subsequent developments of**
international law. The circumstances in which it applies are that the relevant provision of the principal treaty was
ambulatory, in the sense that it envisaged that future changes occurring after it was made would affect its
application. The example commonly cited is the International Court of Justice's advisory opinion on _Legal_
_C_ _f_ _St t_ _f th_ _C_ _ti_ _d P_ _f S_ _th Af i_ _i_ _N_ _ibi_ _(S_ _th W_ _t Af i_ _) [1971] ICJ R_


-----

16. Article 22(1) of the Covenant of the League of Nations provided for the grant of mandates for the administration
of former colonies and territories 'which are inhabited by peoples not yet able to stand by themselves under the
strenuous conditions of the modern world'. The mandate territory was to be administered on the 'principle that the
wellbeing and development of such peoples form a sacred trust of civilisation'. The court interpreted art 22 in the
light of the subsequent development in international law of the concept of self-determination:

'Mindful as it is of the primary necessity of interpreting an instrument in accordance with the intentions of the
parties at the time of its conclusion, the court is bound to take into account the fact that the concepts embodied
in article 22 of the Covenant—“the strenuous conditions of the modern world” and “the wellbeing and
development” of the peoples concerned—were not static, but were by definition evolutionary, as also,
therefore, was the concept of the “sacred trust”. The parties to the Covenant must consequently be deemed to
have accepted them as such.' (Para 53.)

The intention that the principal treaty should accommodate future change must therefore be found within the treaty
itself. This is fundamental, for art 31(3)(c) of the Vienna Convention on the Law of Treaties is a principle of
interpretation. It is not a principle of revision. With respect, I cannot accept that Oil Platforms (Islamic Republic of
_Iran v United States of America) [2003] ICJ 161, which Lord Wilson cites as illustrative of a wider principle, has any_
bearing on the point. The International Court of Justice did not in that case interpret the 1955 Treaty of Amity
between Iran and the United States in the light of a subsequent and unrelated treaty or any other subsequent
developments in international law. It interpreted an exception in the treaty for 'measures … necessary to protect

[the] essential security interests of the parties' in the light of customary international law relating to the use of force
and the right of self-defence: see paras 41, 44, 73. The two concepts were clearly closely related and the relevant
principles of customary international law were of very long standing.

**[43] The first objection to the argument in this case is that no such intention can be discerned in art 31(1)(c) of the**
Convention on Diplomatic Relations. The concept of a 'professional or commercial activity' exercised by a
diplomatic agent is not ambulatory. The expression does not express a general value whose content may vary over
time. It is a fixed criterion for categorising the facts, whose meaning and effect was extensively discussed during the
drafting and negotiation of the text. There is no reason to suppose that it refers today to anything other than what it
referred to in 1961.

**[*640] [44] Secondly, the international obligations of states in relation to human trafficking are embodied in treaties,**
primarily in the Palermo Protocol, which is the only relevant treaty to which both the United Kingdom and Saudi
Arabia are parties. The Protocol is not in any way concerned with jurisdictional immunity. Its sole relevance is as a
source of international policy against human trafficking. But it does not follow from that policy that diplomatic
immunity cannot be available in cases of trafficking. The intention of the parties to the Protocol that trafficking
should be unlawful is entirely consistent with the subsistence of rules determining where and when civil claims or
criminal charges may properly be determined. For the same reason, international law immunities have been held to
be available in cases involving torture (Jones v Saudi Arabia), breach of the laws of armed conflict (Jurisdictional
_Immunities of the State) or crimes against humanity (Democratic Republic of the Congo v Belgium (Case_
_concerning Arrest Warrant of 11 April 2000))._

**[45] Third, nothing in the Palermo Protocol requires that human trafficking must be classified as a 'commercial**
activity' when it would not otherwise be, whether for the purpose of diplomatic immunity or for any other purpose.
The commerciality or otherwise of the activities defined as trafficking are irrelevant to the definition. As defined in art
3 of the Protocol, trafficking may consist in a number of different operations, including the recruitment,
transportation, transfer, harbouring and receipt of persons. It may also consist in fraud, deception or the abuse of
power or vulnerability. Commonly, a chain of intermediaries will be involved, each participant doing some of these
things but not necessarily all of them. It is not inherent in any of these acts that they will necessarily be done in the
exercise of a commercial activity. That will depend on the precise circumstances. In particular, it will depend on the
nature of each participant's involvement. Thus one would expect an intermediary who recruits or transports a
trafficked person for money to be exercising a commercial activity. The same is likely to be true of someone who
receives a trafficked person for, say, prostitution. These are business operations. But the mere employment of a
domestic servant on exploitative terms is not a commercial activity, and the fact that it is unlawful, contrary to


-----

international policy and morally repugnant cannot make it into one. One can readily imagine circumstances in which
someone who employed a trafficked person as a domestic servant had obtained her through a chain of
intermediaries engaged in human trafficking as a business, although that does not appear to have happened in Ms
Reyes's case. In such a case, the employer may incur criminal or civil liability along with the other participants who
brought the victim to his door. But his liability would be for the trafficking. It would not without more make him a joint
participant in the intermediaries' business. Doubtless, without customers professional traffickers would have no
business, but that does not make the customers into practitioners of a commercial activity. By way of analogy, if I
knowingly buy stolen property from a professional fence for my personal use, both of us will incur criminal liability
for receiving stolen goods and civil liability to the true owner for conversion. The fence will also be engaging in a
commercial activity. But it does not follow that the same is true of me.

**[46] For the same reason, it cannot matter that the trafficking may enable**

**[*641] the ultimate employer to pay the victim less than the proper rate or nothing at all. To pursue the analogy, I**
will no doubt pay the fence less for the stolen goods than I would have had to pay for the same goods to an honest
shopkeeper. But that does not alter the characterisation of my purchase, which is no more the exercise by me of a
commercial activity in the one case than it is in the other. Likewise, the employment of a domestic servant to
provide purely personal services cannot rationally be characterised as the exercise of a commercial activity if she is
paid less than the going rate or the national minimum wage, but not if she is paid more. One might perhaps loosely
say that the victim is being treated as a commodity. But a figure of speech should not be confused with a legal
concept.

**[47] Finally, the implications of human trafficking for the scope of diplomatic immunity have been considered on a**
number of occasions by the federal courts of the United States. On its facts, Tabion v Mufti may well have been a
case of trafficking, and _Gonzales Paredes v Vila_ (2007) 479 F Supp 2d 187 almost certainly was. But the point
appears to have been raised overtly for the first time in Sabbithi v Al Saleh (2009) 605 F Supp 2d 122, a decision of
the District Court for the District of Columbia. The court rejected the argument that the employer's participation in
trafficking constituted a commercial activity within art 31(1)(c), essentially because it made no difference to the
characterisation of the act of employing or maltreating a domestic servant, even on exploitative terms and at
'marginal wages'. The same view was taken in _Montuya v Chedid (2011) 779 F Supp 2d 60 and_ _Fun v Pulgar_
(2014) 993 F Supp 2d 470 where the facts were similar. The rare cases from European jurisdictions point to the
same answer. In _Pfarr v Anonymous_ 17 SA 1468/11 (ILDC 1903) (2011), which concerned the exploitation of a
domestic servant in circumstances very like those of the present case, the Berlin-Brandenburg Court of Appeal
declined to recognise an exception for grave violations of human rights. (The appeal was allowed by the Federal
Employment Court, NZA 2013, 343, only because by the time that the appeal was heard, the diplomat was no
longer in post). The possibility that the commercial activities exception might apply does not seem to have occurred
to the court. In Mohamed X v Fettouma Z (17 October 2012), 11/01255 Legifrance, it was considered by the Court
of Appeal of Montpellier in a case where the employer had made considerable financial savings by his exploitation
of a Moroccan housemaid. The argument was rejected on the ground that the arrangements for the management of
a diplomat's private residence and family life 'could not be regarded as a professional or commercial activity outside
his official functions'.
**Application to Ms Reyes's case**

**[48] The first question is whether the employment or treatment of Ms Reyes by the Al-Malkis were acts performed**
in the course of Mr Al-Malki's 'official functions'. In my judgment, it is clear that they were not. Difficult questions of
fact may arise when a private servant is employed in a diplomat's residence for purposes connected with the work
of the mission. But on any view Mr Al-Malki's official functions cannot have extended to the employment of domestic
staff to do the cleaning, help in the

**[*642] kitchen and look after his children. These things were not done for or on behalf of Saudi Arabia. The Court**
[of Appeal ([2016] 2 All ER 136 at [19]) thought that such activities were 'conducive' to the performance of his official](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JF5-45X1-DYBP-M0GN-00000-00&context=1519360)
functions. No doubt they were. But that could be said of almost anything that made the personal life of a diplomatic
agent easier. It does not make the employment of Ms Reyes part of Mr Al-Malki's official functions as a diplomatic
agent. Since Mr Al-Malki's functions as a diplomatic agent have now come to an end, he is no longer entitled to any


-----

immunity under art 31. The only immunity available to him is the residual immunity under art 39(2). It follows from
the fact that the relevant acts were not done in the course of his official functions that that immunity cannot apply.
Likewise, Mrs Al-Malki is no longer entitled to any immunity at all.

**[49] Does it matter that Mr and Mrs Al-Malki were entitled to immunity under art 31(1) and 37(1) respectively at the**
time when the present proceedings were commenced? In my opinion it does not. An action brought against persons
entitled to diplomatic immunity is not a nullity. It is merely liable to be dismissed. There are therefore valid
proceedings currently on foot. Diplomatic immunity is a procedural immunity. The procedural incidents of litigation
normally fall to be determined by a court as at the time of the hearing. Thus a waiver of immunity after the
commencement of proceedings would dispose of any diplomatic immunity which previously existed. The result of a
change in the defendant's status is not materially different. A striking illustration is supplied by the decision of the
Court of Appeal in _Empson v Smith_ _[[1965] 2 All ER 881, [1966] 1 QB 426. Proceedings were begun against Mr](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-94H0-TWP1-61C4-00000-00&context=1519360)_
Smith, a member of the administrative staff of the Canadian High Commission in London, claiming damages under
a private tenancy agreement. At the time when the proceedings were commenced he enjoyed the same immunity
under the Diplomatic Immunities (Commonwealth Countries and Republic of Ireland) Act 1952 as the diplomatic
staff of an ambassador. Under the Act of 1708, that immunity was absolute. By the time of the hearing, however,
[the Acts of 1708 and 1952 had been replaced by the Diplomatic Privileges Act 1964, which conferred immunity on](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61B0-TWPY-Y0N2-00000-00&context=1519360)
administrative and technical staff only in respect of acts done in the course of their duties. Mr Smith was held to be
[entitled only to the limited immunity under the 1964 Act. As Diplock LJ point out by way of analogy ([1965] 2 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-94H0-TWP1-61C4-00000-00&context=1519360)
_[881 at 887, [1966] 1 QB 426 at 439) 'if the defendant had ceased to be en poste while the plaint was still](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-94H0-TWP1-61C4-00000-00&context=1519360)_
outstanding the action could then have proceeded against him.' Indeed, that was the position in _Shaw v Shaw_

_[[1979] 3 All ER 1, [1979] Fam 62. The wife filed a petition for a dissolution of her marriage to a diplomat attached to](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DFG-81D0-TWP1-613T-00000-00&context=1519360)_
the United States embassy. At the time, he was immune, but the petition was allowed to proceed once the
husband's posting came to an end and he left the United Kingdom. The same view has been taken in other
jurisdictions where similar issues have arisen: see Denza, pp 257–258.

**[50] The respondents' main answer to these points is that Mr Al-Malki's official functions extended to the**
employment of his domestic staff. I have rejected that submission. But they also submit that even on the footing that
his official functions did not extend to the acts relied on by Ms Reyes, she did not take the point in the Court of
Appeal and should not be allowed to take

**[*643] it here. I reject that submission also. If I thought that any injustice would be done by allowing the point to be**
taken in this court, I would be in favour of remitting the matter to the courts below. But I do not think so. The point
was reserved shortly after judgment in the Court of Appeal and was fairly taken in the appellant's printed case in
this court. The relationship between arts 31 and 39(2) always was relevant, since it is a fundamental part of the
scheme of the Convention. It is not suggested that the answer can turn on any disputed point of fact. There may in
due course be implications for costs, but that is another matter.

**[51] In those circumstances, the question whether the exception in art 31(1)(c) would have applied to Mr Al-Malki**
had he still been in post does not strictly speaking arise. If he had still been in post, I would have held that he was
immune, because the employment and treatment of Ms Reyes did not amount to carrying on or participating in
carrying on a professional or commercial activity. Her employment, although it continued for about two months, was
plainly not an alternative occupation of Mr Al-Malki's. Nothing that was done by him or his wife was done by way of
business. A person who supplies goods or services by way of business might be said to exercise a commercial
activity. But Mr and Mrs Al-Malki are not said to have done that. They are merely said to have used Ms Reyes's
services in a harsh and in some respects unlawful way. There is no sense which can reasonably be given to art
31(1)(c) which would make the consumption of goods and services the exercise a commercial activity.
**The European Convention on Human Rights**

**[52] It follows from the view that I take of the immunity claim that it is unnecessary to deal with Ms Reyes's**
alternative argument based on the European Convention for the Protection of Human Rights and Fundamental
Freedoms 1950 (Rome, 4 November 1950; TS 71 (1953); Cmnd 8969).
**Disposal**


-----

**[53] I would allow the appeal.**

**[54] It remains to deal with the consequential orders. The present appeal has been decided on the assumption that**
the facts stated in Ms Reyes's evidence are true. There has been no evidence from Mr and Mrs Al-Malki, and no
statement of their case on the facts. In those circumstances, the relief sought by Mr Otty is an order remitting the
matter to the Employment Tribunal to determine whether on the facts Mr Al-Malki's employment and treatment of
Ms Reyes were acts done in the exercise of his functions as a member of the mission. However, before inflicting on
the parties a further round of argument on the claim to immunity, I would wish to be satisfied that there is a real
issue on that point in the light of this court's judgment. As at present advised, it appears to me that there could be
such an issue only if there were a dispute about the nature of the functions which Ms Reyes was employed to
perform or, possibly, about the circumstances in which her employment came to an end. Accordingly, unless within
21 days written submissions are received from the parties justifying some other course, I would declare that Mr and
Mrs Al-Malki are not entitled to diplomatic

**[*644] immunity in respect of the claims made by Ms Reyes in these proceedings and remit the case to the**
Employment Tribunal to determine those claims on their merits. In the case of Mr and Mrs Al-Malki, those
submissions would have to identify any subsisting issue of fact going to their claim for immunity.

**LORD WILSON**

(who agrees with Lord Sumption, save that he expresses doubts on one point, and with whom Lady Hale and Lord
Clarke agree).

**[55] I agree that the appeal should be allowed by reference to the apparent loss of immunity on the part of Mr Al-**
Malki (and therefore of Mrs Al-Malki) when in August 2014 he ceased to be a member of the Saudi mission in
London and when therefore they left the UK. The loss of immunity is no more than apparent because the appeal
proceeds only on assumed facts. By reference to the facts alleged by Ms Reyes, one can conclude that none of the
actions taken by Mr Al-Malki in relation to Ms Reyes were 'acts performed by [him] in the exercise of his functions
as a member of the mission' within the meaning of art 39(2) of the Vienna Convention on Diplomatic Relations 1961
(Vienna, 18 April 1961; TS 19 (1965); Cmnd 2565). But, although the court has done no more than to assume these
alleged facts to be correct, it may be that Mr and Mrs Al-Malki take no real issue with this part of her allegations;
and in those circumstances I subscribe to the disposal proposed by Lord Sumption in para [54], above.

**[56] It follows that this court will not answer in any binding form the central question presented to it in such detail**
and with such conspicuous ability: does an action instituted in the tribunal against a foreign diplomat in the UK by
his former domestic servant brought to the UK to work in his home in (assumed) conditions of **_modern slavery_**
relate 'to any … commercial activity exercised by [him here] outside his official functions' within the meaning of art
31(1)(c) of the 1961 Convention?

**[57] I am pleased that the court will not answer that question in any binding form. Lord Sumption's emphatic answer**
to the question is No. His answer is (if he will forgive my saying so) the obvious answer. It may be correct. But my
personal experience has been that, the more one thinks about the question, the less obviously correct does his
answer become.

**[58] By reference to five aspects of the background, let me explain myself.**

**[59] First, the UK confronts a significant problem in relation to the exploitation of migrant domestic workers by**
foreign diplomats. Kalayaan, the Intervener, which is the principal UK charity devoted to advising and supporting
migrant domestic workers, gives the following evidence:

(1)   Between about 200 and 250 domestic workers enter the UK each year under a diplomatic overseas
domestic worker's visa.

(2)   The proportion of domestic workers who are the victims of trafficking is considerably higher in
diplomatic households than in other households.


-----

(3)   Thus in one representative period 17 out of 55 referrals to the government agency set up to identify
the trafficking of domestic workers

**[*645] related to diplomatic households whereas, had such referrals been in proportion to the number of**
workers in other households, there would have just been one.

(4)   The explanation for the high ratio of trafficked workers in diplomatic households is largely because
perceived immunity from claims for compensation leads diplomats to consider that they can exploit them
with impunity.

(5)   The perceived immunity makes trafficking with a view to domestic servitude a low risk, high reward
activity for diplomats.

It was these concerns which led Mr Ewins QC, in his Independent Review of the Overseas Domestic Workers Visa
dated 16 December 2015, to recommend at para 165(1) that overseas domestic workers in diplomatic households
should be employed by the foreign state, which (see para [63], below) he reasonably understood to have no civil
immunity, rather than by the individual diplomats; but the government appears to have rejected the
recommendation.

**[60] Second is the universality of the international community's determination to combat human trafficking. In para**

[39], above Lord Sumption refers to the Palermo Protocol 2000 which was the product of a resolution of the UN
General Assembly to promote the evolution of an international instrument which addressed the trafficking of women
and children. The protocol, ratified both by Saudi Arabia and the UK, contains elaborate commitments by each state
party to criminalise trafficking; to make material provision for victims in aid of their physical, psychological and social
recovery; by art 6(6), to 'ensure that its domestic legal system contains measures that offer victims of trafficking in
persons the possibility of obtaining compensation for damage suffered'; to strengthen border controls; and so on.
Then came the Council of Europe Convention on Action against Trafficking in Human Beings (CETS no 197),
adopted in Warsaw on 16 May 2005. As was noted in the explanatory report which accompanied it, trafficking in
human beings was a world-wide phenomenon and had become a major scourge in Europe. The preamble to this
2005 Convention described its purpose as being to improve the protections afforded by the Palermo Protocol. Its
detailed provisions for strong national mechanisms to identify trafficking and for international co-operation are
irrelevant. But it is noteworthy that, by way of expansion of the requirement in art 6(6) of the Palermo Protocol that
victims should obtain compensation, the 2005 Convention made clear, in art 15(3) and (4), that the obligation was
to provide for victims to obtain compensation 'from the perpetrators' as well as from the state; and also noteworthy
that the UK claims to have discharged this obligation by, among other things, providing the facility for application to
the tribunal. In my view it is irrelevant that, for obvious reasons, Saudi Arabia was unable to accede (as did the UK)
to the 2005 Convention. It is equally irrelevant that, for obvious reasons, the UK was unable to ratify (as did Saudi
Arabia) the Arab Charter on Human Rights adopted by the League of Arab States on 22 May 2004, which, by art
10(1) and (2), declared that no one should be held in servitude under any circumstances and that trafficking in

**[*646] human beings for the purposes of any form of exploitation was prohibited. The relevance of these**
instruments is that they underscore the equal level of determination of the UK, of Saudi Arabia and in effect of every
state in the world to stamp out trafficking.

**[61] Third: what is trafficking and, in particular, who is guilty of it? In para [39], above Lord Sumption quotes the**
definition of it in art 3 of the Palermo Protocol, repeated in art 4 of the 2005 Convention. It is the definition in
accepted use. For present purposes most of the definition can be omitted and what remains is 'the recruitment,
transportation, transfer, harbouring or receipt of persons, by means of … the abuse of power or of a position of
vulnerability … for the purposes of exploitation'. As was said in para 78 of the explanatory report which
accompanied the 2005 Convention, 'the definition endeavours to encompass the whole sequence of actions that
leads to the exploitation of the victim'. As was observed by the European Court of Human Rights in _Rantsev v_
_[Cyprus (2010) 28 BHRC 313, (2010) 51 EHRR 1 at para 281, the vice of trafficking is that it 'treats human beings as](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JM8-RN31-DYBP-W0VW-00000-00&context=1519360)_
commodities to be bought and sold and put to forced labour, often for little or no payment'.

**[62] How apt (one therefore asks) is the analogy offered by Lord Sumption in paras [45] and [46], above between a**
h f t l d t h i d l h M Al M lki f t ffi k d i t? N ith


-----

suggests Lord Sumption, engages in the 'commercial activity' of the thief or handler of the goods and of the recruiter
or transporter of the migrant. But another rational view is that the relevant 'activity' is not just the so-called
employment but the trafficking; that the employer of the migrant is an integral part of the chain, who knowingly
effects the 'receipt' of the migrant and supplies the specified purpose, namely that of exploiting her, which drives the
entire exercise from her recruitment onwards; that the employer's exploitation of the migrant has no parallel in the
purchaser's treatment of the stolen goods; and that, in addition to the physical and emotional cruelty inherent in it,
the employer's conduct contains a substantial commercial element of obtaining domestic assistance without paying
for it properly or at all.

**[63] Fourth is the fact that, in the words of Laws J in Propend Finance Pty Ltd v Sing (1997) 111 ILR 611 at 633,**
diplomatic immunity is an aspect of state immunity. The parties to the 1961 Convention therefore recorded in their
second recital to it that, in agreeing its terms, they had in mind the sovereign equality of states. So it must be at
least relevant to notice that, in accordance with the movement in the doctrine of sovereign immunity in customary
[international law from being absolute to being restrictive, Parliament enacted ss 3 and 4 of the State Immunity Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6160-TWPY-Y0VV-00000-00&context=1519360)
1978. Section 3(1) excludes immunity in respect of a state's entry into a commercial transaction, defined in sub-s
(3) as, among other things, any contract for the supply of goods or services. At the end of that subsection
Parliament provided that the section did not apply to a contract of employment between a state and an individual. In
the absence of that provision the section clearly would have applied to such a contract. The purpose of excluding a
contract of employment from the ambit of s 3 was, so I infer, only that it required fuller treatment in a section of its
own. This is

**[*647] s 4, which, by sub-s (1), excludes immunity in respect of such a contract where made in the UK or where the**
work is to be performed here, albeit subject to exceptions provided in later subsections. It is true that sub-s (1)(a) of
s 16 of the 1978 Act purports to exclude the application of s 4 to proceedings concerning the employment of the
members of a mission, including staff in its domestic service. But for present purposes the subsection can be put to
one side because today, in Benkharbouche v Secretary of State for Foreign and Commonwealth Affairs; Secretary
_[of State for Foreign and Commonwealth Affairs v Janah [2017] UKSC 62, [2018] 1 LRC 650, this court dismisses](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RK3-69N1-DYJ0-82VY-00000-00&context=1519360)_
appeals against declarations that, in so far as it bars employment-related claims against a foreign state derived
from EU law, the subsection should be disapplied and that, in so far as it bars other such claims, it is incompatible
with art 6 of the European Convention for the Protection of Human Rights and Fundamental Freedoms 1950
(Rome, 4 November 1950; TS 71 (1953); Cmnd 8969).

**[64] Section 5 of the Canadian State Immunity Act analogously excludes immunity from proceedings relating to a**
foreign state's commercial activity; and in _United States v Public Service Alliance of Canada, Re Canada Labour_
_Code_ _[[1993] 2 LRC 78 at 94–95, [1992] 2 SCR 50 at 79, the Canadian Supreme Court accepted that a contract of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JX4-YNV1-DYJ0-82K7-00000-00&context=1519360)_
employment was generally a commercial activity, while holding that the proceedings for recognition of a union's
right to represent Canadian employees at the US naval base had a sovereign element sufficient to preserve the
immunity.

**[65] I cannot readily explain why proceedings relating to a contract of employment entered into by a foreign state,**
for performance in the UK, will not in principle attract immunity in circumstances in which, if the contract is entered
into by a diplomat, it will in principle attract immunity.

**[66] Fifth is the purpose of diplomatic immunity, helpfully defined in the fourth recital to the 1961 Convention as**
being 'not to benefit individuals but to ensure the efficient performance of the functions of diplomatic missions as
representing States'. If a person's duties under a contract of employment made between her and a foreign diplomat
relate to the latter's official functions, the immunity is appropriately provided, in accordance with its purpose, by the
last four words of art 31(1)(c). But in the present case, for reasons explained by Lord Sumption, there is no
apparent link between the duties of Ms Reyes and the official functions of Mr Al-Malki. And so if, even in that
situation, diplomatic immunity were to arise, the question would become: how does that accord with its purpose?

**[67] The major perceived problem lies, of course, in the words of art 31(1)(c), in particular of three words**
'commercial activity exercised'. The interpretation of the article is required by art 31(1) of the Vienna Convention on
the Law of Treaties (Vienna; 23 May to 30 November 1969; TS 58 (1980); Cmnd 7964) ('the Vienna Convention') to


-----

be undertaken 'in accordance with the ordinary meaning to be given to [its] terms … in their context and in the light
of its object and purpose'. So the focus is on the ordinary meaning of the words; and the purpose of the 1961
Convention is relevant only to the extent that it throws light upon their ordinary meaning. I am persuaded that, when
agreeing to the terms of the 1961 Convention, the parties would have rejected any suggestion that the proceedings
brought by Ms Reyes related to

**[*648] any commercial activity exercised by Mr Al-Malki. I am, with respect to Lord Sumption's contrary opinion**
expressed in para [42], above, less persuaded that, even if (which is debatable) art 31 of the 1961 Convention does
not by its terms contemplate any future development of its meaning, the latter would have been unable to develop
over 56 years. Article 31(3)(c) of the Vienna Convention requires the interpretation of an article to take account of
any relevant rules of international law applicable in the relations between the parties; and the requirement is not
further qualified. The fact that in the _Namibia_ case, which Lord Sumption there cites, the international court
discerned the contemplation of development within the terms of the article under scrutiny does not exclude in other
circumstances the natural development of the meaning of an article in accordance with the development of
international law, in particular the emergence of an international prohibition against trafficking; nor does the
absence of an ability to discern it within a term mean that the parties who agreed it intended otherwise. In _Oil_
_Platforms (Islamic Republic of Iran v United States of America) [2003] ICJ 161 the International Court of Justice was_
required to determine whether, in destroying oil platforms belonging to Iran, the US had breached an article of the
Treaty of Amity which it had made with Iran in 1955. In interpreting the article the court, at para 41, turned to current
rules of international law on the use of force without considering whether the article had expressly contemplated
future development of its meaning. It was enough that the parties could not have intended that the article be
interpreted without reference to them.

**[68] The other perceived problem is that an international treaty calls for international interpretation 'by reference to**
[broad principles of general acceptation' (Stag Line Ltd v Foscolo, Mango & Co Ltd [1932] AC 328 at 350, [1931] All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V1D-FSP2-D6MY-P05C-00000-00&context=1519360)
_[ER Rep 666 at 676); and never more obviously than when every state despatches its diplomats abroad in](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V1D-FSP2-D6MY-P05C-00000-00&context=1519360)_
expectation of their protection under it. So it would be a strong thing for this court to diverge from the US
jurisprudence set out in the Tabion case, cited in para [23], above, and to adopt the robust interpretation of art 31(1)
for which Ms Reyes contends. On the other hand it is difficult for this court to forsake what it perceives to be a
legally respectable solution and instead to favour a conclusion that its system cannot provide redress for an
apparently serious case of domestic servitude here in our capital city. In the event my colleagues and I are not put
to that test today. Far preferable would it be for the International Law Commission, mid-wife to the 1961
Convention, to be invited, through the mechanism of art 17 of the statute which created it, to consider, and to
consult and to report upon, the international acceptability of an amendment of art 31 which would put beyond doubt
the exclusion of immunity in a case such as that of Ms Reyes.

**LADY HALE and LORD CLARKE**

(who agree with Lord Wilson).

**[69] We agree, for the reasons given by Lord Sumption in that connection, that if art 39 applies, then Mr and Mrs Al-**
Malki are not entitled to immunity.

**[*649] We also agree with his proposed disposal of the case. It follows that the proper construction of art 31(1)(c)**
does not arise. However, had it arisen, we would associate ourselves with the doubts expressed by Lord Wilson as
to whether the construction adopted by Lord Sumption in this particular context is correct especially in the light of
what we would regard as desirable developments in this area of the law.

**End of Document**


-----

