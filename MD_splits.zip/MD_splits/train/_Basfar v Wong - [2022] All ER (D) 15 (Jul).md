# *Basfar v Wong [2022] All ER (D) 15 (Jul)

[2022] UKSC 20

Supreme Court

Lord Briggs, Lord Hamblen, Lord Leggatt, Lord Stephens and Lady Rose SCJJ

6 July 2022

**EMPLOYMENT – DIPLOMATIC PRIVILEGE – WHETHER RESPONDENT DIPLOMAT ENTITLED TO IMMUNITY**
**IN CLAIM ALLEGING MODERN SLAVERY AND BREACH OF EMPLOYMENT RIGHTS**
Abstract

_The Supreme Court (by a majority) ruled that, on the assumed facts, an employment claim for wages and breaches_
_of employment rights (the claim), brought by the appellant migrant domestic worker who alleged that she had been_
_a victim of_ **_modern slavery, fell within the exception from immunity provided for in art 31(1)(c) of the Vienna_**
_Convention on Diplomatic Relations. Accordingly, the court held that, if the appellant's allegations were proved, the_
_respondent (a diplomat representing the Kingdom of Saudi Arabia in the UK and the appellant's former employer)_
_did not have immunity from the civil jurisdiction of the courts of the UK. The court so ruled in circumstances where_
_the employment tribunal (the tribunal) had dismissed the respondent's application to strike out the claim, but the_
_Employment Appeal Tribunal had allowed his appeal. The court held that, applying the general rule of interpretation_
_set out in art 31(1) of the Vienna Convention on the Law of Treaties 1969, employing a domestic worker did not,_
_itself, constitute the exercise of a 'commercial activity' by a diplomatic agent, within the meaning of the exception,_
_but that it was necessary to examine the context and, importantly, the purpose of the relevant provision. The court_
_held that, on the assumed facts, the respondent and his family had enjoyed the benefit of the appellant's services_
_for almost two years, initially for a fraction of her contractual entitlement to wages and latterly for no pay at all, which_
_had amounted to a substantial financial benefit. Accordingly, the court held that the deliberate and continuing_
_course of conduct by which that benefit had been gained was properly characterised as the exercise of a_
_commercial activity, that the case was a 'paradigm example of domestic servitude' and that the tribunal's judgment,_
_refusing to strike out the claim, would be reinstated._
Digest

The judgment is available at: [2022] UKSC 20

**Background**

The appellant (W), a national of the Philippines, was a migrant domestic worker who worked in the household of the
respondent (B), a diplomat representing the Kingdom of Saudi Arabia in the UK.

W claimed to be a victim of human trafficking who had been forced to work for B and his family in circumstances
amounting to modern slavery, after they had brought her with them to the UK in August 2016. She alleged that she
had been: (i) confined, at all times, to B's house, except to take out the rubbish; (ii) held virtually incommunicado;
(iii) made to work from 7 am to around 11.30 pm each day, with no days off or rest breaks; and (iv) subjected to
other degrading and offensive treatment.


-----

W brought a claim against B in the employment tribunal for wages and breaches of her employment rights. She
alleged that, after arriving in the UK, she had not been paid for seven months, that she had been paid a fraction of
her contractual entitlement in July 2017, and that she had not been paid again until she had escaped in May 2018.

B applied for the claim to be struck out on the ground that he had diplomatic immunity from suit.

Under art 31 of the Vienna Convention on Diplomatic Relations 1961 (the Diplomatic Convention), incorporated into
[UK domestic law by the Diplomatic Privileges Act 1964 (DPA 1964), diplomatic agents enjoyed complete immunity](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61B0-TWPY-Y0N2-00000-00&context=1519360)
from the criminal jurisdiction of the receiving state and they were also generally immune from its civil jurisdiction.
However, there was an exception for civil claims relating to 'any professional or commercial activity exercised by the
diplomatic agent in the receiving state outside his official functions.'

The employment tribunal (the tribunal) declined to strike out W's claim. The Employment Appeal Tribunal (the EAT)
allowed B's appeal and issued a certificate that the case was suitable for an appeal directly to the Supreme Court,
'leapfrogging' the Court of Appeal.

The Supreme Court granted permission for the appeal.

**Issues and decisions**

Whether the conduct alleged constituted a 'commercial activity exercised' by B, such that W's claim fell within the
exception from immunity in art 31(c) of the Vienna Convention.

It was agreed that the alleged conduct in question had been outside B's official functions.

On the assumed facts, W's claim fell within the exception from immunity provided for in art 31(1)(c) of the Vienna
Convention on Diplomatic Relations. It followed that, if those facts were proved, B did not have immunity from the
civil jurisdiction of the courts of the UK. Unless admissions were made, a hearing was, therefore, required to
determine the truth of the allegations. Accordingly, the appeal would be allowed and the tribunal's judgment,
refusing to strike out the claim, would be reinstated (see [107] of the judgment).

The principle of legal immunity for diplomatic agents was a fundamental principle of national and international law.
As recorded in the fourth recital to the Diplomatic Convention, the purpose of diplomatic privileges and immunities
'is not to benefit individuals but to ensure the efficient performance of the functions of diplomatic missions as
representing States' (see [11], [12] of the judgment).

The key provision, for present purposes, was the exception to immunity from the civil jurisdiction of the receiving
state provided for in art 31(1)(c) of the Diplomatic Convention. That exception applied in the case of: 'an action
relating to any professional or commercial activity exercised by the diplomatic agent in the receiving State outside
his official functions.' Further, art 42 of the Diplomatic Convention stated that: 'A diplomatic agent shall not in the
receiving state practise for personal profit any professional or commercial activity'. The provisions of the Diplomatic
[Convention enacted into UK law by DPA 1964 had to be interpreted, not by applying domestic principles of statutory](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61B0-TWPY-Y0N2-00000-00&context=1519360)
interpretation, but according to the generally accepted principles by which international conventions were to be
interpreted as a matter of international law. Those principles were set out in the Vienna Convention on the Law of
Treaties 1969 (the Treaties Convention). The general rule of interpretation was stated in art 31(1) of the Treaties
Convention as followed: 'A treaty shall be interpreted in good faith in accordance with the ordinary meaning to be
given to the terms of the treaty in their context and in the light of its object and purpose' (see [13]-17], [39] of the
judgment).

[In Al-Malki and another v Reyes and another [2018] 1 All ER 629, the present court had unanimously held that the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RNF-6RT1-DYBP-M0KY-00000-00&context=1519360)
employment and alleged acts of maltreatment of the claimant by the respondent diplomat had not been performed
'in the exercise of his functions as a member of the mission', within the meaning of art 39(2). As discussed by Lord
Sumption (with whom the rest of the court had agreed on that point), a diplomatic agent's 'functions as a member of
the mission' in art 39(2) were the same as 'his official functions' in art 31(1)(c) and were, in each case, those
functions which the diplomatic agent performed for, or on behalf of, the sending state. In the present case, it was


-----

not suggested that B's alleged acts had been a 'professional' activity. The question was whether they had been a
'commercial activity exercised' by him, within the meaning of art 31(1)(c) of the Diplomatic Convention (see [14],

[15] of the judgment).

The Special Rapporteur did not point to any alleged error in the reasoning in _Reyes [as summarised in the_
judgment] and the present court agreed with that reasoning. However, it could not agree with the view expressed by
Lord Sumption in _Reyes, at para 21(2), that the ordinary meaning of 'exercising' a 'commercial activity' was_
restricted to 'carrying on a business' or 'setting up shop'. The ordinary meaning of the words included those
concepts, but it was not limited to them. Nor did the word 'exercée' in the French text have any materially different
connotation from the English word 'exercised' (see [24], [28] of the judgment).

Applying the general rule of interpretation set out in art 31(1) of the Treaties Convention, employing a domestic
worker did not, itself, constitute the exercise of a 'commercial activity' by a diplomatic agent, within the meaning of
the exception. As a matter of ordinary language, buying goods and services could be described as the exercise of a
commercial activity, irrespective of the purpose for which they were purchased. The same could be said of entering
into a contract of employment as an employer (or employee) and receiving (or supplying) personal services under
such a contract. In the relevant enactments, the concept of a 'commercial activity' included the employment of a
domestic worker (and purchasing goods or other services). However, the court did not suggest that that
interpretation could be transposed to the context of diplomatic immunity. The law on state immunity showed that the
question whether purchasing goods and services, and entering into a contract of employment, was to be regarded
as exercising a 'commercial activity' could not be answered just by interrogating the ordinary meaning of those
words. Those words, like any ordinary English words, were capable of bearing different shades of meaning
according to the context in which, and purpose for which, they were being used. In the context of state immunity,
exercising a 'commercial activity' included employing a private domestic servant or purchasing goods in a shop.
Whether the words bore the same meaning where they were used in art 31(1)(c) of the Diplomatic Convention was
a question that could only be answered by examining the context and, importantly, the purpose of that provision
(see [17], [27]-[33] of the judgment).

It would be contrary to the purpose of conferring immunity on diplomatic agents to interpret the words 'any …
commercial activity' in art 31(1)(c) as including activities incidental to the ordinary conduct of daily life in the
receiving state, such as purchasing goods for personal consumption or purchasing medical, legal, educational or
domestic services privately (see [34]-[38] of the judgment).

However, exploiting a domestic worker by compelling her to work in circumstances of **_modern slavery was not_**
comparable to an ordinary employment relationship of a kind that was incidental to the daily life of a diplomat (and
his family) in the receiving state. There was a material and qualitative difference between those activities.
Employment was a voluntary relationship, freely entered into and governed by the terms of a contract. By contrast,
the essence of modern slavery was that it was not freely undertaken. Rather, the work was extracted by coercion
and the exercise of control over the victim. That usually involved exploiting circumstances of the victim which make
her specially vulnerable to abuse. Those constraints generally made it impossible or very difficult for the worker to
leave. A major source of vulnerability was physical and social isolation. The other side of isolation was invisibility to
the outside world. A domestic worker who was effectively incarcerated in the household of her employer was, in
practice, beyond the reach of public authorities or private charities who might be able to help if they were aware of
her situation (see [43]-[57] of the judgment).

In the present case, the extent of the control over W's person and dominion over her labour exercised by B on the
assumed facts of the case had been so extensive and despotic as to place her in a position of domestic servitude.
The extreme dependency created by such total isolation had, on the assumed facts, been augmented by
psychological abuse. Dependency had further been increased by withholding pay. On the assumed facts, B and his
family had enjoyed the benefit of W's services for almost two years, initially for a fraction of her contractual
entitlement to wages and latterly for no pay at all. That had been a substantial financial benefit. The deliberate and
continuing course of conduct by which that benefit had been gained was properly characterised as the exercise of a
commercial activity. Compelling a migrant domestic worker to provide her labour in circumstances of **_modern_**
**_slavery could not reasonably be likened to paying for dry cleaning or ordinary domestic help. Unlike such day-to-_**


-----

day living services, such exploitation was an abuse of the diplomat's presence in the receiving state and fell far
outside the sphere of ordinary contracts incidental to the daily life of the diplomat and family members which the
immunity serves to protect (see [46], [47], [51]-[57] of the judgment).

The argument which had chiefly led two Justices and the Court of Appeal in _Reyes to express the view that_
exploiting a domestic servant was not a commercial activity had been that the answer to that question could not
depend on the rate of remuneration which the individual was paid. In the Court of Appeal, Lord Dyson MR had said,
at paragraph 34, that: 'The fact that an employer derives economic benefit from paying his employee wages that
are lower than the market rate does not mean that he is engaging in a commercial activity.' To similar effect, in his
minority judgment in the Supreme Court, at para 46, Lord Sumption had said that: 'the employment of a domestic
servant to provide purely personal services cannot rationally be characterised as the exercise of a commercial
activity if she is paid less than the going rate or the national minimum wage, but not if she is paid more'. Those
observations had clearly been correct. It could not rationally be said that the defining characteristic of slavery whether in its traditional or modern form - was that a slave did not receive the national minimum wage or the market
rate of remuneration for his services. That would be like saying that the essential difference between a prisoner and
a free person was that the rate of pay for prison work was less than the individual could earn in the outside world.
While true, it missed the critical distinction - which was between freedom and captivity (see [62], [63] of the
judgment).

In deciding whether the proceedings in Reyes or in the present case fell within art 31(1)(c), the relevant question
was not whether the parties to the Diplomatic Convention, if informed of the facts of those cases, would have
thought that they fell within art 31(1)(c). It was whether, on the proper interpretation of the text which the parties
adopted, the proceedings fell within the meaning of that provision. To answer the latter question, the court had to
ascertain the common intention of the contracting parties. The process of identifying that intention was simply one
of applying arts 31 to 33 of the Treaties Convention (see [69] of the judgment).

In interpreting and applying art 31(1)(c) of the Diplomatic Convention, the only relevance of international law
regarding trafficking and other forms of **_modern slavery was indirect. The critical distinction was between: (i)_**
ordinary domestic employment arrangements which were incidental to the daily life of a diplomat in the receiving
state and did not fall within art 31(1)(c); and (ii) exploitation of a domestic worker for profit which amounted to a
'commercial activity' when practised by a diplomatic agent. Regard had to be had to the present rules of
international law: the concepts of slavery, servitude and forced labour, together with human trafficking, which were
often grouped together under the description of 'modern slavery' (see [72]-[82] of the judgment).

In cases of the present kind, the forms of **_modern slavery primarily relevant were likely to be forced labour and_**
servitude. It was those international law concepts which provided appropriate criteria for distinguishing between, on
the one hand, the voluntary employment of a domestic worker which was an ordinary incident of living in the
receiving state and, on the other hand, the exploitation of a domestic worker which was properly characterised as a
commercial activity for the purpose of art 31(1)(c) of the Diplomatic Convention. The assumed facts of the present
case made it a paradigm example of domestic servitude. B's treatment of W, on the assumed facts, had amounted
to a form of **_modern slavery, whether it had been forced labour, servitude or trafficking. That showed that the_**
relationship between them had not been that of employment, freely entered into, so as to have been an ordinary
part of B's daily life in the UK as a resident diplomat. Further, it showed that his conduct had amounted to a
commercial activity practised (in so far as it had mattered) for personal profit (see [96]-[100] of the judgment).

A further point made on behalf of B was that an employment tribunal could only compensate a claimant for claims
that it had jurisdiction to hear and that such claims did not include an action for trafficking. The same point could be
made about claims for compensation for subjection to servitude or forced labour, which equally were not claims that
an employment tribunal had jurisdiction to determine. However, W was not claiming compensation for violation of
her human rights through being trafficked or held in servitude or required to perform forced labour. Those concepts
were relevant only to rebut B's plea of diplomatic immunity. There was no doubt that a court or tribunal had power
to decide whether it had jurisdiction to hear a claim. To decide whether or not the plea of immunity from the
jurisdiction of the English courts was well founded, it was necessary to determine whether W's claim was an action
'relating to' a commercial activity exercised by B outside his official functions. In their ordinary meaning, the words


-----

'relating to' in art 31(1)(c) required only that there should be a significant connection between the subject matter of
the action and the commercial activity exercised by the diplomatic agent, and not that the facts relied on to establish
that the relevant activity was 'commercial' should be limited to those which need to be proved as ingredients of the
claimant's causes of action. Such a connection was clearly present on the assumed facts of the present case, as
W's allegations of unlawful deductions from wages and failures to comply with the law relating to working time and
the national minimum wage arose directly from, and had been part of, the exploitative conduct which was alleged
for the purpose of rebutting the plea of immunity to constitute a commercial activity (see [103], [104] of the
judgment).

Further, and among other things, the court should notice an argument advanced on behalf of B that, if trafficked
domestic workers who had been forced to work for a diplomat in circumstances of modern slavery were allowed to
make a civil claim in an employment tribunal for wages wrongly withheld, British diplomats abroad might be
exposed to retaliatory measures. There were two problems with that argument. First, it was difficult to see how such
a risk, even if genuine, could affect the meaning of the phrase 'commercial activity' in art 31(1)(c). Second, there
was no evidence to support the existence of such a risk (see [105], [106] of the judgment).

_Reyes v Al-Malki (Secretary of State for Foreign and Commonwealth Affairs)_ _[[2015] EWCA Civ 32, [2016] 2 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JF5-45X1-DYBP-M0GN-00000-00&context=1519360)_
_[136, [2016] 1 WLR 1785, [2015] All ER (D) 56 (Feb) explained](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JF5-45X1-DYBP-M0GN-00000-00&context=1519360)_

_Al-Malki and another v Reyes and another_ _[[2017] UKSC 61, [2018] 1 All ER 629, [2017] 3 WLR 923, [2017] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RNF-6RT1-DYBP-M0KY-00000-00&context=1519360)_
_[(D) 85 (Oct) explained](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5PRN-G9R1-DYBP-N2T4-00000-00&context=1519360)_

_Fothergill v Monarch Airlines Ltd_ _[[1980] 2 All ER 696, [1980] 3 WLR 209, [1980-84] LRC (Comm) 215 considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KV0-TWP1-6134-00000-00&context=1519360)_

_[R v Tang [2008] HCA 39, [2009] 2 LRC 592 considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5334-77C1-DYJ0-83C5-00000-00&context=1519360)_

_[Rantsev v Cyprus and Russia (Application 25965/04) 51 EHRR 1, [2010] ECHR 25965/04 considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X02K-00000-00&context=1519360)_

_A local authority v AG and others (children) (domestic abuse)_ _[[2020] EWFC 18, [2021] 1 All ER 257, [2020] 3 WLR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:61SB-3TB3-GXFD-84JX-00000-00&context=1519360)_
[133, [2020] 1 FLR 1265, [2020] All ER (D) 119 (Mar) considered](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:603T-DXC3-GXFD-80H1-00000-00&context=1519360)

Appeal allowed.

[Decision of The Employment Appeal Tribunal [2020] IRLR 248 Reversed.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5YD0-JNY3-GXFD-81K8-00000-00&context=1519360)

Timothy Otty QC, Paul Luckhurst, Professor Philippa Webb and Ishaani Shrivastava (instructed by Wilson Solicitors
LLP) for W.

Mohinderpal Sethi QC, Sophia Berry and Bláthnaid Breslin (instructed by Reynold Porter Chamberlain LLP,
London) for B.

Tom Hickman QC and Flora Robertson (written submissions only) (instructed by Deighton Pierce Glynn (London))
for the first intervener, Kalayaan.

Professor Parosha Chandran (written submissions only) (instructed by Duncan Lewis, London) for the second
intervener, United Nations Special Rapporteur on Trafficking in Persons especially Women and Children.
This content is based on the case summary published by the UK Supreme Court and is published with permission.
The original summary can be found here: https://www.supremecourt.uk/press-summary/uksc-2020-0155.html

**End of Document**


-----

