Immigrants) (Residential Landlords Association and other....

# *Secretary of State for the Home Department v R (on the application of Joint
 Council for the Welfare of Immigrants) (Residential Landlords Association
 and others intervening) [2020] EWCA Civ 542

Court of Appeal, Civil Division

Davis, Henderson and Hickinbottom LJJ

21 April 2020Judgment

**Sir James Eadie QC, David Pievsky QC and David Lowe**

(instructed by Government Legal Department) for the Appellant

**Phillippa Kaufmann QC and Jamie Burton (instructed by Leigh Day) for the Respondent**

**Justin Bates and Brooke Lyne (instructed by Anthony Gold Solicitors)**

for the First Intervener

**Nick Armstrong (instructed by The Equality and Human Rights Commission)**

for the Second Intervener

**Martin Westgate QC, James Kirk and Daniel Clarke (instructed by Liberty)**

for the Third Intervener

Hearing dates: 15-17 January 2020

Further written submissions: 4 February 2020

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Lord Justice Hickinbottom :**

**Introduction**

1. It is in the public interest that a coherent immigration policy should not only set out the criteria upon
which leave to enter and remain in a particular state will be granted, but also discourage the unlawful entry
to, or continued presence in, that state of those who have no right to enter or be there.

2. As well as potentially exploiting the individuals who wish to enter and remain in that state but have no
right to do so, those who, for their own financial gain, facilitate such unlawful entry or continued presence
act contrary to that public interest. Consequently, EU Council Directive 2002/90/EC of 28 November 2002
defining the facilitation of unauthorised entry, transit and residence requires Member States to adopt
sanctions against “any person who, for financial gain, intentionally assists a person who is not a national of


-----

Immigrants) (Residential Landlords Association and other....

a Member State to reside within the territory of a Member State in breach of the laws of the State
concerned on the residence of aliens” which are “effective, proportionate and dissuasive” (articles 1 and 3).

3. Part 3 Chapter 1 (i.e. sections 20-37) of the _[Immigration Act 2014 (“the 2014 Act”) (“the Scheme”),](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)_
which currently only applies to England, builds on earlier provisions providing for criminal sanctions for
anyone who facilitated the commission of a breach of immigration law by a non-European Union citizen. It
prohibits landlords in the private rental sector – of whom there an estimated two million in the UK – from
letting their properties to those who are not British, EEA or Swiss citizens and who (i) require but do not
have leave to enter or remain in the United Kingdom or (ii) have such leave but only upon condition that
prevents them from occupying such premises (collectively, “irregular immigrants”). This is one of a battery
of provisions designed to encourage those who are resident in the UK to regularise their immigration status
or leave the country, which include restrictions on employment, using NHS facilities, and obtaining bank
accounts, driving licences etc. These are generally known as the “compliant environment” or, more
usually, “hostile environment” provisions.

4. The Joint Council for the Welfare of Immigrants (“the Joint Council”), an independent charity, is a
particular advocate for fairness, equality and proper respect for human dignity for immigrants. On 8
February 2018, it issued judicial review proceedings against the Secretary of State challenging the
lawfulness of the Scheme, on the basis that its provisions are incompatible with article 14 when read with
article 8 of the European Convention on Human Rights (“the ECHR”). It is important to note the nature of
the challenge. It was not brought by any individual claiming that he or she has been the victim of
discrimination as a result of the operation of the Scheme: rather, it was a challenge to the validity of the
statutory provisions themselves. Furthermore, the challenge was not in respect of any adverse effect of
the Scheme upon those towards whom it was directed (i.e. irregular immigrants whose right to rent was
deliberately curtailed by the Scheme), but the alleged unintended but (it is said) inevitable discriminatory
consequences for certain categories of those with a right of abode or leave to enter/remain and thus a right
to rent, namely those without British passports and especially those without British passports and without
ethnically British attributes such as name.

5. After a four-day hearing, on 1 March 2019, in a commendably thorough judgment, Martin Spencer J
allowed the judicial review; and made declarations that (i) the Scheme is incompatible with article 14 read
with article 8 of the ECHR, and (ii) a decision to commence the Scheme in Scotland, Wales and Northern
Ireland without further evaluation of its efficacy and discriminatory effect would be irrational and a breach of
the public sector equality duty in section 149 of the Equality Act 2010 (“the PSED”). The Secretary of State
now appeals that order.

6. Before us, Sir James Eadie QC with David Pievsky and David Lowe appeared for the Secretary of
State, and Phillippa Kaufmann QC with Jamie Burton appeared for the Joint Council. There are three
interveners.

i) Justin Bates and Brooke Lyne appeared for the National Residential Landlords Association (“the
NRLA”). The NRLA is an organisation which represents the interests of residential landlords, formed on 1
January 2020 as the result of a merger of the Residential Landlords Association (“the RLA”) and the
National Landlords Association. The RLA intervened before the court below. At the time of merger, the
RLA had 30,000 members and associate members with a combined portfolio of about 300,000 properties.
The NRLA has about 80,000 members.

ii) Nick Armstrong appeared for the Equality and Human Rights Commission (“the Commission”). The
Commission is an independent non-departmental government body, established by the _[Equality Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61F0-TWPY-Y1BD-00000-00&context=1519360)_
_[2006,dedicated to promoting and upholding equality and human rights across Great Britain.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61F0-TWPY-Y1BD-00000-00&context=1519360)_

iii) Martin Westgate QC with James Kirk and Daniel Clarke appeared for the National Council of Civil
Liberties (“Liberty”). Liberty is an independent membership organisation dedicated to, amongst other
things, campaigning for fair and equal treatment.

As the outset, I thank all Counsel, and their supporting teams, for their substantial assistance.


-----

Immigrants) (Residential Landlords Association and other....

**[The Scheme: Sections 20-37 of the Immigration Act 2014](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C1CH-00000-00&context=1519360)**

7. As I have already indicated, sections 20-37 of the 2014 Act were not the first provisions to impose
sanctions upon those who facilitated illegal immigrants residing in the UK. By section 25 of the Immigration
Act 1971 (“the 1971 Act”) in its original form, it was an offence punishable by a fine and/or up to six months'
imprisonment for someone knowingly to harbour anyone whom he knew or had reasonable cause to
believe was an illegal immigrant. By section 143 of the Nationality, Immigration and Asylum Act 2002,
section 25 of the 1971 Act was replaced by a new provision under which it was a criminal offence to do an
act which facilitated the commission of a breach of immigration law by an individual who was not a citizen
of the EU knowing or having reasonable cause for believing (i) that the act facilitates the commission of a
breach of immigration law by that individual and (ii) that the individual was not a citizen of the EU. In
parallel with these provisions, Part VI of the Immigration and Asylum Act 1999 and Schedule 3 to the
Nationality, Immigration and Asylum Act 2002 restricted welfare support, including housing benefit, for
irregular immigrants.

8. No doubt partly as a result of these provisions, and also natural commercial caution, responses to the
consultation held as part of the Impact Assessment of the proposed new provisions which became sections
20-37 of the 2014 Act suggested that 70% of landlords understandably already carried out and recorded
identity document checks on those to whom they rented property (page 12), and about 40% checked a
passport (page 9).

9. The 2014 Act provided for a new scheme, designed to prevent irregular immigrants from being able to
rent accommodation on the open market, in which landlords are tasked with checking that their tenants are
not irregular immigrants.

10. The Scheme applies to “residential tenancy agreements” (“RTAs”) which, by section 20, includes all
arrangements where a person is permitted to occupy a property as their only or main residence in return
for the payment of rent, unless the arrangement falls into one of the exclusions set out in Schedule 3 (none
of which is relevant to this appeal).

11. Section 21 defines the category of persons disqualified from occupying premises under an RTA
because of their immigration status, as follows (so far as relevant to this appeal):

“(1) For the purposes of this Chapter a person (“P”) is disqualified as a result of their immigration status
from occupying premises under [an RTA] if –

(a) P is not a relevant national, and

(b) P does not have a right to rent in relation to the premises.

(2) P does not have a 'right to rent' in relation to premises if –

(a) P requires leave to enter or remain in the United Kingdom but does not have it, or

(b) P's leave to enter or remain in the United Kingdom is subject to a condition preventing P from
occupying the premises.

(3) But P is to be treated as having a right to rent in relation to premises (in spite of subsection (2)) if the
Secretary of State has granted P permission for the purposes of this Chapter to occupy premises under [an
RTA].

(4) …

(5) In this section 'relevant national' means –

(a) a British citizen

(b) a national of an EEA state other than the United Kingdom or

(c) a national of Switzerland.”


-----

Immigrants) (Residential Landlords Association and other....

12. This disqualification is enforced by way of a prohibition on landlords letting property to irregular
immigrants. Section 22 prohibits landlords from “authorising” an adult to occupy premises under an RTA if
the adult is disqualified as a result of his or her immigration status, as follows:

“(1) A landlord must not authorise an adult to occupy premises under a residential tenancy agreement if
the adult is disqualified as a result of their immigration status.

(2) A landlord is taken to 'authorise' an adult to occupy premises in the circumstances mentioned in
subsection (1) if (and only if) there is a contravention of this section.

(3) There is a contravention of this section in either of the following cases.

(4) The first case is where [an RTA] is entered into that, at the time of entry, grants a right to occupy
premises to –

(a) a tenant who is disqualified as a result of their immigration status,

(b) another adult named in the agreement who is disqualified as a result of their immigration status,

(c) another adult not named in the agreement who is disqualified as a result of their immigration status
(subject to subsection (6)).

(5)  …

(6) There is a contravention as a result of subsection (4)(c) only if –

(a) reasonable enquiries were not made of the tenant before entering into the agreement as to the relevant
occupiers, or

(b) reasonable enquiries were so made and it was or should have been apparent from the enquiries that
the adult in question was likely to be a relevant occupier.”

13. Section 32 of the 2014 Act requires the Secretary of State to issue a code of practice for the purposes
of sections 20-37 of the Act, which is the subject of the Parliamentary negative approval procedure. That
code (Right to Rent Immigration Checks: Landlords' Code of Practice) (“the Code of Practice”) was issued
in October 2014 and has been subsequently revised.

14. Where a landlord lets accommodation to an irregular immigrant in breach of section 22, he is
potentially liable to a number of sanctions or other adverse consequences.

i) Section 23 empowers the Secretary of State to give the landlord a penalty notice for a penalty of up to
£3,000. Section 24 sets out a number of statutory excuses available to a landlord served with a penalty
notice, which include that the landlord can show that an agent acting on his behalf is liable for the
contravention or that “the prescribed requirements were complied with before the [RTA] was entered into”
(section 24(2)). Those requirements are prescribed by regulation (see paragraphs 15-18 below).
However, the Secretary of State may serve a penalty notice without establishing whether a landlord has or
may have an excuse for an apparent contravention of the Scheme (section 28(1)). Where, following any
representations, a penalty notice is maintained, a landlord has the right to appeal to the county court where
the appeal is in the form of a de novo hearing (section 30).

ii) Section 39 of the Immigration Act 2016 (“the 2016 Act”) amended the 2014 Act to make the breach of
section 22 by a landlord a criminal offence, where the landlord “knows or has reasonable cause to believe
that the premises are occupied by an adult who is disqualified as a result of their immigration status…”
(section 33A of the 2014 Act), for which the maximum sentence is five years' imprisonment and/or a fine
(section 33C). It is a defence for the landlord to prove that he has, within a reasonable time, taken
reasonable steps to terminate the RTA (section 33A(6)).

iii) Section 40 of the 2016 Act inserted a new section 33D into the 2014 Act, under which the Secretary of
State may serve a notice on the landlord informing him that the premises are occupied by an irregular
immigrant, whereupon the landlord may (a) terminate the agreement, or (b) seek possession under new


-----

Immigrants) (Residential Landlords Association and other....

[mandatory grounds under the Rent Act 1977 and the Housing Act 1988. If the landlord does not take such](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8H0-TWPY-Y1B6-00000-00&context=1519360)
action, then he is liable to prosecution under section 33A.

iv) Where a landlord is convicted of a section 33A offence, the offence is a “banning order offence” under
the _[Housing and Planning Act 2016: the First-tier Tribunal has the power to make a “banning order”,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5JVN-B9D1-DYCN-C3DC-00000-00&context=1519360)_
prohibiting the offender from letting housing in England. A breach of a banning order is subject to a civil
penalty of up to £30,000, and is a criminal offence with a maximum sentence of 51 weeks' imprisonment
and/or a fine (sections 21-23 of that Act). A landlord subject to a banning order (i) must be placed on the
Database of Rogue Landlords and Property Agents (section 29) and (ii) may also be deprived of a
[landlord's licence required by the Housing Act 2004.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61X0-TWPY-Y0SS-00000-00&context=1519360)

v) A finding that a landlord has let accommodation to an irregular immigrant may have other adverse
commercial consequences, e.g. under any mortgage of the property.

15. The “prescribed requirements” for the purposes of the Scheme are set out in the Immigration
(Residential Accommodation) (Prescribed Requirements and Codes of Practice) Order 2014 (SI 2014 No
2874) as amended (“the 2014 Order”). By article 3, a landlord complies with the prescribed requirements if
he obtains documents prescribed in article 4 and takes the steps required by article 5 to verify, retain, copy
or record the contents of those documents.

16. Article 4 and the Schedule to the 2014 Order describe documents that are sufficient to evidence leave
to remain, and thus a “right to rent”. The Schedule has two lists: the first comprising documents any one of
which will suffice, and the second comprising documents at least two of which are required. With a view to
assisting landlords, the Code of Practice lists the same documents, but differently grouped into List A (for
those with time unlimited leave to remain) and List B (for those with time limited leave). List A is then split
into Group 1 (where a single document will suffice) and Group 2 (where a combination of any two
documents are required). So far as the documents as listed in the Code are concerned:

i) List A Group 1 includes a British, EEA Member State or Swiss passport or national identity document, a
UK residence card or biometric immigration document, or any other passport (even if expired) which shows
the holder has the right of abode or indefinite leave to remain in the UK.

ii) List A Group 2 includes a UK or Ireland birth certificate, a full UK driving licence, recent benefits papers,
a recent letter from a Government department confirming that the person is known to them, and a recent
letter from a British passport holder confirming that they have known the person for three months.

iii) List B includes a current passport from any country or a current UK biometric residence permit or Home
Office immigration status document showing a right to stay in the UK for a limited period, and a current
residence card as a family member of an EEA or Swiss national.

17. Parvaiz Asmat is a Policy Projects Manager at the Home Office. In uncontested evidence, in
paragraph 36 of his statement dated 20 August 2018, he said of these requirements:

i) 80% of tenants in the private rental sector have passports (although not necessarily British).

ii) 97% of people without a passport were born in the UK and are likely to be British citizens, and therefore
entitled to a British passport.

iii) There are under 6,000 short term residents in the UK with no passport.

iv) One million biometric residence permits have been issued since 2008, from that date such permits
being the only documents issued to non-EEA nationals who have permission to remain in the UK for more
than six months; and their family members have been issued with biometric residence cards.

In short, the vast majority of potential tenants in the private sector will be able to satisfy the prescribed
requirements by producing a single document.

18. The 2014 Order recognises that, in some cases, a prospective tenant will not be able to produce the
required documents, e.g. where the documents have been retained by the Home Office in respect of an
on going application or appeal In those circ mstances articles 4(b) and 5 of the 2014 Order pro ide for a


-----

Immigrants) (Residential Landlords Association and other....

“Landlord Checking Service”. The landlord completes an on-line form, in response to which the Home
Office confirms or denies that the individual is a regular immigrant. If there is no response within 48 hours,
the landlord can proceed with an RTA as if the person is not disqualified.

19. Therefore, in summary, although it uses the term “right to rent” as a term of art defined in section
21(2), the 2014 Act does not create any rights at all; rather, it curtails the ability or freedom of irregular
immigrants to rent accommodation. It enforces that restriction by prohibiting landlords from renting
accommodation to irregular immigrants, and imposing sanctions on landlords who do. It works by making
a landlord _prima facie liable for renting premises to an irregular immigrant or allowing an irregular_
immigrant to occupy such premises (section 22) and subject to a civil penalty if he does so (section 23);
but, unless he knows or reasonably believes a tenant or occupier is an irregular immigrant, he will have an
excuse in respect of such a penalty where he can show that (i) he used an agent to let the property or (ii)
he complied with certain “prescribed requirements” which essentially oblige a landlord to ask for (and take
copies of) certain identity documents. The obligation is the more burdensome for landlords because (i) it
applies, not just to the tenant who enters into the RTA, but to all individuals who the landlord, following
appropriate enquiries, may reasonably expect to occupy the premises under the RTA, and (ii) where a
tenant or other occupier has a “limited right to rent” (i.e. has time limited leave to remain, and so may
become an irregular immigrant during the course of the period of the RTA), the landlord will need to repeat
the checks after the longer of one year or the duration of that person's “limited right to remain” (sections
24(6) and 27 of the 2014 Act). The potential adverse consequences for a landlord if he breaches section
22 are not however restricted to any civil penalty: there are potential criminal sanctions which may
ultimately result in the landlord going to prison and, even if the landlord acted reasonably in making checks
etc, he may lose the tenant and even be required to take expensive possession proceedings if it turns out
that the tenant was, or becomes, an irregular immigrant.

**The Risk of Discrimination**

20. The risk that the new scheme might in practice result in discrimination on grounds of nationality and/or
race was made clear by the Joint Council – and was appreciated by the Secretary of State – from the
outset. The focus of this concern was not upon the effect of the proposals on those in respect of whom it
was primarily targeted, i.e. irregular immigrants who are disqualified from renting private accommodation.
Rather, the concern was that the Scheme would unlawfully discriminate against non-disqualified persons
who had the right of abode or leave to enter/remain in the UK but did not have a British passport especially
if they had attributes (such as name) which were apparently not ethnically British. The concern was that
landlords, facing potentially severe sanctions for breach, would behave defensively and prefer prospective
tenants who could easily and unequivocally show that they had the right to live in the UK, and thus the right
to rent, by means of a British passport.

21. Thus, in response to the Secretary of State's initial July 2013 consultation document, “Tackling illegal
immigration in privately rented accommodation”, the Joint Council said this:

“[The Joint Council's] main concern is that these proposals are very likely to lead to racial profiling and
discrimination against BME [Black and Minority Ethnic] prospective tenants.… [The proposed immigration
status checks] will serve to encourage indirect discrimination and in many cases direct discrimination. It
will be far easier for a landlord to let his or her property to a British/EU national who will simply have to
produce their passport to confirm status. The consultation itself quotes the Department for Communities
and Local Government study that indicates more than half of those in private rented accommodation are
non-British or Irish residents and that most new migrants are housed in the private rental sector. Thus,
migrants will be disproportionately affected by these proposals.

Landlords fearful of breaking the law or facing a fine will find it far easier to avoid renting to anybody who
could have a complicated immigration history or anybody whose status is not immediately clear. This will
undoubtedly result in BME individuals losing out on tenancies and increasing their chances of being made
homeless.”


-----

Immigrants) (Residential Landlords Association and other....

22. The Secretary of State clearly appreciated that risk. Following the period of consultation, on 25
September 2013 she issued the Impact Assessment in respect of the proposed legislation to which I have
already referred (see paragraph 8 above). Annex 2 set out a summary of consultation responses.
Paragraph (d) dealt with “Discrimination”, as follows:

“The consultation gave a clear message that discrimination against foreign born tenants is unacceptable.
Particular concern was raised that the regulations would result in discrimination motivated not because of
overt prejudice but because of administrative convenience where some people are more likely than others
to have readily available documentation. The Government is equally concerned to address the risk that the
new checking duty will result in unlawful discrimination.

The legislation will include provision for a statutory non-discrimination code providing clear guidance on the
steps landlords must follow to avoid unlawful discrimination, which may be taken into account by tribunals
considering claims of unlawful discrimination. In addition, the Government will put into place administrative
support and guidance for landlords and will continue to work across the sector to embed the new
procedures and raise confidence among landlords that they can continue to provide accommodation
without risk.

The Government believes that any added administrative burden can be mitigated by supporting
prospective tenants to satisfy the evidence requirement at the point at which they apply for tenancies.
Prospective tenants will be assisted and guided in creating their own evidence pack to meet the
requirements so that the duty on landlords will be minimised.”

23. Section F of the Impact Assessment dealt with “Risks”. One of the risks identified was that the
availability of more severe sanctions for a breach by landlords of the prohibition on letting to irregular
immigrants might result in defensive behaviour by landlords in respect of those they select as tenants
(emphasis in the original).

“Heavier penalties may provoke discrimination against those perceived to be a higher risk based on
**an unfounded belief that the person may be a foreign national.**

Legal migrants and landlords will be supported by the Home Office through on-line guidance and advice
services to minimise the risk that legal migrants might be viewed as a greater risk than prospective tenants
from within the settled population. Migrants will be advised as to how to collate and present a package of
appropriate documents that meets the requirements in advance of seeking accommodation. Landlords
wishing to check that the requirements have been met will be supported through telephone advice.”

24. The Secretary of State's formal response to the consultation was issued on 10 October 2013. It
recognised that landlords were concerned about the administrative burden that the Scheme imposed upon
them; but considered that the well-established scheme for employers indicated that the checking
requirements need not be burdensome or costly for landlords (paragraph 10(b)).

25. The Government response included, at Annex C, a Policy Equality Statement. This said that 58% of
consultation respondents had expressed concern that the new scheme might lead to greater racial
discrimination including a risk that landlords might discriminate on the basis of administrative convenience,
that is:

“The new rules might lead landlords to discriminate against people who they perceive to be foreign rather
than conduct proper checks to ascertain their actual status.”

In response, the Secretary of State said:

“The level of checks required are de minimis – usually to the extent of copying one document with no need
for further action. The Home Office will make regulations specifying the document types that must be
checked and copied, and the document list has been constructed so that it reflects existing checking best
practice by landlords and encompasses documents which are commonly held by the vast majority of those
entitled to live in the UK. A Code of Practice will provide guidance in assisting landlords to conduct such


-----

Immigrants) (Residential Landlords Association and other....

checks without breaching equality legislation. The need to treat all tenants equally will be reinforced in
guidance and tools provided for landlords.

…

Respondents to the consultation raised concerns that [non-EEA migrants who are not settled here] may
suffer administrative discrimination, where landlords may consider that conducting more complex checks
will prove more burdensome. The Government recognises that extra support may be required in some
circumstances to ensure that legitimate visitors and legal migrants are not barred from the housing market
(for example, the Home Office is committed to providing a service that will deal with general telephone
enquiries asking for advice and allow landlords to request swift confirmation of a person's status).

Where migrants with outstanding applications or appeals know that they need to undergo a landlord check
in advance, the Home Office will provide a pre-certification service for these migrants, enabling them to
obtain the documentation they need upfront. The Home Office also intends to amend the immigration
application process to allow applicants to retain their biometric residence permit when making an
immigration application. This will allow the migrant to show evidence of their identity, nationality and
immigration status to a landlord [and] enable the landlord to carry out a speedy and accurate check with
the Home Office on the person's current status.”

26. The potential for the new provisions to result in a breach of articles 8 and 14 of the ECHR was
considered in a memorandum prepared by the Home Office in conjunction with several other Government
departments, in support of the Secretary of State's statement under section 19(1)(a) of the Human Rights
Act 1998 that, in her view, the new statutory provisions were compatible with Convention rights. The
memorandum stated:

“96. … While there is no right under article 8 ECHR to be provided with housing ([Chapman v United
Kingdom (ECtHR Application No 27238/95) (2001) 33 EHRR 18]), the prohibition will prevent individuals
from accessing the private rented sector in order to rent their only or main residence, and will further
prevent individuals from living together at privately rented premises as their only or main residence where
one of them is disqualified from occupation by reason of their immigration status. It therefore has the
potential to impact on an individual's right to respect for his home, private and family life.

97. …

98. The restriction on establishing a residence in the private rented sector as one's only or main residence
prevents the individual living his own personal life as he chooses and potentially prevents him from living
with members of his family and in that respect engages his right to respect for private and family life.
However, the restriction can be justified on the basis that it is both necessary and proportionate in pursuit
of the legitimate aim of immigration control.…

99. The restriction will also impact on the right to respect for family life enjoyed by both the individuals
themselves, and also British citizens, EEA nationals and those with an unlimited right to reside in the
United Kingdom who will be prevented from arranging accommodation for themselves and any adult family
member who is disqualified from occupation. This engages article 8 and arguably article 14. In relation to
article 8, the restriction can be said to be justified and proportionate for the reasons stated above. In
relation to article 14, the margin of appreciation is relatively wide given the differential treatment is based
on immigration status, which involves an element of choice and the socio-economic nature of the subject
matter (see [Bah v United Kingdom (ECtHR Application No 56328/07) [2012] 54 EHRR 21 at [47]]). The
restrictions here are therefore justified for the reasons set out above.

100. The Department is therefore satisfied that these provisions are compatible with articles 8 and 14.”

As can be seen, this appeared to recognise that the restriction of occupation of premises by irregular
immigrants engaged article 8 as well as article 14, but it did not specifically consider the potential
discriminatory treatment adverse to those who had the right to rent but whom landlords would find it less
administratively convenient to deal with because (e.g.) they did not have a British passport.


-----

Immigrants) (Residential Landlords Association and other....

27. However, that potential discrimination was considered elsewhere. In addition to the documents to
which I have already referred, section 33(1)(b) of the 2014 Act requires the Secretary of State to issue a
code of practice “specifying what a landlord… should or should not do to ensure that, while avoiding liability
[to pay a penalty under this Chapter, the landlord also avoids contravening… the Equality Act 2010,so far](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)
as relating to race…”. That provision was inserted in response to concerns that landlords might
discriminate in the way they administered right to rent checks. Before issuing such a code, the Secretary
of State is obliged to consult the Commission and appropriate landlord organisations (section 33(3)), and to
consult publicly on the draft code (section 33(4)). The code must be brought into force by Order of the
Secretary of State, which is again subject to the Parliamentary negative resolution procedure.

28. After due consultation, the code (Code of Practice for Landlords: Avoiding unlawful discrimination
when conducting “right to rent” checks in the private rented residential sector) was published in October
2014, and revised in 2016 (“the Discrimination Code of Practice”). It emphasises that discrimination on
grounds of race is unlawful; and expressly deals with the issue of potential collateral discrimination by
landlords on the basis of administrative convenience. Under the heading, “How to avoid race
discrimination”, it says this:

“As a matter of good practice landlords and their agents should apply the right to rent checks in a fair,
justifiable and consistent manner regardless as to whether they believe the prospective tenant to be British,
settled or a person with limited permission to be here.

Landlords should ensure that no prospective tenants are discouraged or excluded, either directly or
indirectly, because of their personal appearance or accent or anything else associated with a person's
race. They should not make and act upon assumptions about a person's immigration status on the basis of
their colour, nationality, ethnic or national origins, accent, ability to speak English or the length of time they
have been resident in the UK.

The best way for landlords to ensure that they do not discriminate is to treat all prospective tenants fairly
and in the same way, making sure their criteria and practices in this regard are appropriate and necessary.

**Fair practices**

…

Prospective tenants should not be treated less favourably if they produce acceptable documents showing a
time-limited right to stay in the UK. Once a person who has time-limited permission to stay in the UK has
established their initial and ongoing entitlement to stay, they should not be treated less favourably than
others even if further right to rent checks are subsequently required, as prescribed by the Scheme and set
out in the code of practice. Neither should a landlord treat less favourably a prospective tenant who has
the required combination of documents showing their right to rent (for example a driving licence with a long
UK birth certificate) but does not have a passport. There should be no need to ask questions about a
prospective tenant's immigration status where it is clear that they have permission to stay here. Any
subsequent further checks need only establish that the tenant is still here with permission. If a person is
not able to produce acceptable documents a landlord should not assume that they are living in the UK
illegally. Subject to business requirements, landlords should try to keep the offer of accommodation open
in order to provide a prospective tenant the opportunity to produce documents that will demonstrate their
right to rent, but they are not obliged to do so.”

**Implementation of the Scheme**

29. The 2014 Act received Royal Assent on 14 May 2014, and it was implemented on a pilot basis in
Birmingham and the West Midlands from 1 December 2014.

30. On 3 September 2015, the Joint Council published its own evaluation of the Scheme, “No Passport
Equals No Home”, based upon a small survey of landlords with 27 “tests”. The report accepted that, even
prior to the Scheme, “discrimination in the housing market is already commonplace” (paragraph 7) (see


-----

Immigrants) (Residential Landlords Association and other....

also page 23 of the Joint Council's October 2015 Impact Assessment: “No Passport Equals No Home”).
The key conclusion of paragraph 7 on “Impact on Tenants & Landlords” stated:

“42% of landlords said that the Right to Rent requirements have made them less likely to consider
someone who does not have a British passport. 27% are reluctant to engage with those with foreign
accents or names. Checks are not being undertaken uniformly for all tenants, but are instead directed at
individuals who appear 'foreign'”.

31. On 20 October 2015, the Secretary of State announced that the Scheme would be rolled out across
the whole of England on 1 February 2016 which, in the event, it was.

32. On that same day (20 October 2015), the Secretary of State published an evaluation of the pilot
scheme, using multiple research methods including three online pulse check surveys (of 110-124
respondents), a one-off survey of 114 landlords and 68 tenants with a control group outside the pilot area,
interviews and focus groups with staff from (amongst others) landlords, tenants and voluntary and
community sector organisations; and a “mystery shopping” exercise undertaken by an independent
organisation better “to understand any potential discrimination in housing access linked to the Scheme”.
The mystery shopping exercise used six fictitious potential tenants, namely (i) a White potential tenant with
an English accent (a “White shopper”) and (ii) a BME potential tenant with an accent typical of his country
of origin (“a BME shopper”), each in one of three scenarios, namely (a) a student with time-limited leave to
remain/right to rent, (b) a UK national divorcee with a permanent right of abode/right to rent but with limited
documentation and (c) a low-income single parent family, vulnerably housed but with permanent right of
abode or leave to remain/right to rent. The exercise was conducted both in the pilot area, and in a
comparator control area (i.e. an area where the Scheme was not in operation); and assessed not only
initial contact but also subsequent encounters through to offer/rejection of a tenancy.

33. As its Executive Summary stated, the evaluation concluded that “landlords… intended to and were
carrying out Right to Rent checks”. The mystery shopping exercise suggested there was no evidence of
any significant difference in tenants' access to accommodation between the pilot area and the comparator
area, or between White shoppers and BME shoppers regarding the final outcome from rental search:
although a higher proportion of White shoppers than BME shoppers received a response to their initial
enquiry (60% compared with 40%) and a higher proportion of BME shoppers were asked to provide more
information during rental enquiries, BME shoppers were in fact more likely to be offered viewings of
properties compared with White shoppers (53% compare with 33%). However, it accepted that “comments
from a small number of landlords reported during the mystery shopping exercise and focus groups did
indicate a potential for discrimination” (page 5).

34. A Home Office Policy Equality Statement published on 23 October 2015 summarised the findings of
the evaluation thus:

“The evaluation found no hard evidence of systematic discrimination towards foreign nationals from letting
agents or landlords, or that their access to the housing market was restricted as a result of the Scheme. At
an overall level there did not appear to be major differences for White British and BME shoppers in
accessing accommodation between the phase 1 location and the comparator area. There was evidence of
differences at particular stages of the process of renting a property, although these were not necessarily
indicative of discrimination against BME shoppers. A very small number of potentially discriminatory
attitudes were reported. Whilst the evaluation did not find hard evidence of systematic discrimination, the
Government will continue to provide clear guidance on how to avoid acting in this manner…. Any landlord
who discriminates is acting unlawfully and liable to prosecution.”

35. In February 2016, Shelter (an independent charity involved in homelessness and housing issues)
published a report of a survey of 1,071 private landlords conducted in June and July 2015, i.e. before the
full roll out of the Scheme, at which stage nearly half of the respondents (46%) were still unaware of the
Scheme. 41% of respondent landlords who did not rely on agents agreed that, “It's natural that stereotypes
and prejudices come into it when I decide who to let to”. However, 33% of respondents said that, as a
result of the right to rent checks it was less likely or much less likely that they would rent to someone who


-----

Immigrants) (Residential Landlords Association and other....

did not hold a British passport; and 35% that it was less likely or much less likely that they would rent to
persons who appeared to be, or whom the respondent perceived to be, “immigrants”. Of just those who
had input into decisions as to tenants, i.e. those who did not rely solely on agents (830 respondents), the
figures were 43% and 44% respectively. On the other hand, 8% said that it was more or much more likely
that they would rent to those who did not hold a British passport or who did appear to be an immigrant. In
the same survey, 63% of landlords surveyed said they would prefer not to let to housing benefit claimants
with 42% operating an outright bar.

36. In February 2017, the Joint Council published its own assessment of the impact of the Scheme,
“Passport please: The impact of the Right to Rent checks on migrants and ethnic minorities in England”,
based on a survey of landlords, letting agents and organisations working with affected groups, and its own
mystery shipping exercise.

37. The mystery shopping exercise involved enquiries made of landlords by six fictitious potential tenants,
as follows:

i) Peter: British citizen, ethnically British name, British passport;

ii) Harinder: British citizen, non-ethnically British name, British passport;

iii) Ramesh: non-British citizen, non-ethnically British name, indefinite leave to remain (settled status) and
time unlimited 'right to rent' evidenced through one unspecified document;

iv) Colin: British citizen, ethnically British name, no passport but time unlimited 'right to rent' evidenced
through two unspecified documents;

v) Parimal: British citizen, non-ethnically British name, no passport but time unlimited 'right to rent'
evidenced through two unspecified documents; and

vi) Mukesh: non-British citizen, non-ethnically British name, 2 years' limited leave to remain evidenced
through one document.

38. 1,708 enquiries were sent out, to which there were 867 responses. Landlords were sent initial enquiry
emails, and their responses (positive, negative and no response) were compared. On the basis of paired
data (i.e. data limited to a comparison of cases where requests had been made to a landlord by both
applicants), there was a statistically significant difference of large effect size in the treatment of the nonBritish citizen Ramesh in favour of the British passport holder Harinder, but not in favour of Peter against
Harinder, supporting the suggestion that the legislation has the effect of causing discrimination on the
ground of nationality; and a difference, although of no statistical significance, in favour of Colin against
Parimal, and consequently insufficient evidence to support the hypothesis that the legislation has the effect
of causing racial discrimination where the applicants for accommodation are British citizens without a
passport. The unpaired data did not evidence any statistically significant difference between any of the
potential tenants.

39. Given the inconclusive data on the racial discrimination point, the mystery shopping exercise in
respect of Parimal and Colin alone was repeated in August/September 2018, with 510 enquiries and 463
responses. This time, whilst 25% of the 226 landlords who responded positively or neutrally to a query
from Colin responded negatively or did not respond at all to a query from Parimal, only 8% of the 189
landlords who responded positively or neutrally to a query from Parimal responded negatively or did not
respond at all to a query from Colin. That was a statistically significant difference of large size effect
supporting the proposition that, where an applicant did not have a British passport, there was racial
discrimination against those who did not have British ethnic attributes such as name.

40. In addition, the February 2017 Joint Council report relied upon online surveys of landlords (108
responses), letting agents (208 responses) and organisations working in fields related to migration,
housing and discrimination (45 responses). An online survey of tenants had insufficient responses to be
meaningful. The key findings from the landlords' survey, upon which Ms Kaufmann relied were as follows:


-----

Immigrants) (Residential Landlords Association and other....

i) 42% of landlords who responded to the survey said that they would be less likely to rent to anyone who
did not have a British passport, which rose to 48% when they were explicitly asked to consider the (then
new) criminal sanction. There were in addition eight agents who said that, as a result of the Scheme,
landlords had expressed an unwillingness to rent to tenants who do not hold a British passport. The report
concluded that landlords are less willing to accept tenants who do not hold a British passport as a result of
the Scheme.

ii) 51% of the landlords said that they were now less likely to consider letting to foreign nationals from
outside the EU, with 18% saying they were less likely to rent to EU nationals as well. The report concluded
that foreign nationals were being discriminated against as a result of the Scheme.

41. In July and August 2017, Dr Tom Simcock (Senior Researcher for the RLA) carried out a similar
exercise, with a survey of landlords' attitudes, with results set out in a report dated November 2017 and
helpfully summarised in paragraphs 43-49 of the statement of David Smith (then the Policy Director of the
RLA) dated 27 November 2018. He specifically sought the views of the 30,000 RLA members and 35,000
RLA non-member service users, and responses from the wider landlord community were encouraged
through websites and social media. There were 2,792 responses. So far as relevant to this appeal, the
results of the survey were as follows:

i) 42% of landlords reported that they were less likely to consider letting to any prospective tenant without
British passport, 47% that they were less likely to consider letting to foreign nationals from outside the
EU/EEA, and 48% that they were less likely to consider letting to those who have only a right to let for a
time limited period.

ii) In the 18 month period between February 2016 and July/August 2017, 6% of landlords had in fact
refused a tenancy application as a result of the right to rent checks.

From this survey, Mr Smith concludes (at paragraph 53 of his statement) that, as a result of the Scheme:

“Landlords are significantly less likely to consider letting to anyone without a British passport, and even
less likely to consider letting to foreign nationals outside the EU.”

42. A second survey conducted by Dr Simcock and Noora Mykkanen (a Research Assistant for the RLA)
in June-August 2018 and reported in December 2018 obtained 2,478 responses from landlords sought in a
similar way. 44% of the respondents reported that they were less likely to consider letting to individuals
without a British passport, 20% less likely to rent to EU/EEA nationals and 53% that they were less likely to
rent to people with limited time to remain. The survey showed that in the 30 month period between
February 2016 and July/August 2018, about 5% of landlords had in fact refused a tenancy application as a
result of the right to rent checks.

43. In the meantime, in March and April 2018, the Ministry of Housing, Communities and Local
Government conducted a survey of about 8,000 private landlords and letting agents registered with one of
the government-backed tenancy deposit protection schemes, most of which dealt with issues not relevant
to this appeal. However:

i) In response to the question, “Which, if any, of the following types of tenants are you not willing to let to?
(Select all that apply)”, 25% of 6,584 landlords selected “Non-UK passport holders”.

ii) In answer to a question about compliance requirements, 15% of landlords said they had not carried out
a right to rent check for their most recent letting and 62% said that they had (some letting having taken
place before the Scheme had come into force).

The survey data were collected in such a way that the results could be weighted so that those responses
were considered representative of over 350,000 landlords who were registered with a protection scheme.

**The Grounds of Appeal**

44. In the judicial review, the Joint Council claimed that, in imposing obligations on landlords to check
whether potential and actual tenants were irregular immigrants enforced by civil and criminal sanctions the


-----

Immigrants) (Residential Landlords Association and other....

Scheme caused discrimination on grounds of nationality and/or race against those who did not hold British
passports and, in particular, those who did not hold British passports and who did not have apparently
ethnically British attributes such as name, for which the Secretary of State was responsible, and which
breached article 14 of the ECHR read with article 8. Although it also claimed that there was a violation of
article 8, before Martin Spencer J it took (and it maintains) the position that this is essentially a
discrimination case which is better viewed in article 14 terms. I have already indicated the nature of the
challenge (see paragraph 4 above): it is a challenge to the validity of the statutory provisions themselves.

45. Article 8 provides:

“1. Everyone has the right to respect for his private and family life, his home and his correspondence.

2. There shall be no interference by a public authority except such as is in accordance with the law and
necessary in a democratic society in the interests of national security, public safety, or the economic wellbeing of the country, for the prevention of disorder or crime, for the protection of health or morals, or for the
protection of the rights and freedoms of others.”

This article therefore provides for a qualified right, in two senses. First, article 8(1) simply gives a “right to
respect” for private and family life etc. Second, even where an individual can show that that there has
been an interference with the rights falling within article 8(1), that interference can be justified by the state
under article 8(2) in which case it will not amount to a violation of the article.

46. Article 14 provides:

“The enjoyment of the rights and freedoms set forth in this Convention shall be secured without
discrimination on any ground such as sex, race, colour, language, religion, political or other opinion,
national or social origin, association with a national minority, property, birth or other status.”

Again, even where such discrimination can be shown, the state may be able to justify it such that there is
no breach of article 14, particularly where the substantive right involved is a qualified right (Petrovic v
Austria (European Court of Human Rights (“ECtHR”) (Application No 20458/92) (2001) 33 EHRR 14 at

[20]).

47. Martin Spencer J concluded that the Scheme did not fall within the direct scope of (and so did not
breach) article 8; but it fell within the broader ambit of article 8, it was discriminatory on grounds of
nationality and/or race, such discrimination was unjustified, and thus article 14 was breached. In terms of
relief, he granted a declaration that (i) the Scheme is incompatible with article 14 read with article 8, and (ii)
a decision by the Secretary of State to commence the Scheme in Scotland, Wales and/or Northern Ireland
without further evaluation of its efficacy and discriminatory impact would be irrational and would constitute
a breach of the PSED.

48. The Secretary of State appeals on the following grounds.

Ground 1: The judge erred in holding that the Scheme and/or the facts of this case fall within the ambit of
article 8 for the purposes of article 14. The Joint Council cross-appeal on the ground that, whilst the judge
was right to hold that the facts of this case as he found them to be fall within such ambit, he was wrong to
conclude that they do not fall within the scope of article 8 such that, in addition to an interference with
article 14, there is a direct interference with article 8 rights which requires justification by the state. Like the
discrimination under article 14, it is submitted that the interference with the article 8 rights is not justified.

Ground 2: The judge erred in finding that, on the evidence, the Scheme results in discrimination on
grounds of nationality and/or ethnicity; or, alternatively, in not making an adequate assessment of the
discrimination so caused.

Ground 3: The judge erred in holding that the state, in the form of the Secretary of State, is responsible for
any such discrimination.

Ground 4: The judge erred in concluding that any discriminatory effects of the Scheme are not justified as
a proportionate means of achieving a legitimate aim.


-----

Immigrants) (Residential Landlords Association and other....

Ground 5: Even if the Scheme falls within the ambit of article 8 and results in unjustified discriminatory
effects for which the Secretary of State is responsible, and thus is in breach of article 14, the judge erred in
granting a declaration of incompatibility in respect of the whole scheme.

Ground 6: He was also wrong to make a declaration that, without further evaluation of the efficacy and
discriminatory effect of the Scheme, the extension of the Scheme to the other home nations would be
irrational and a breach of the PSED.

49. Whilst the issue of ambit may be logically prior, as both Sir James Eadie and Ms Kaufmann submitted
that the nature and/or degree of discrimination bears upon that issue, I will deal with Grounds 2 and 3 first,
before moving to ambit (Ground 1) and justification (Ground 4), and finally to Grounds 5 and 6 which
primarily concern relief.

**Grounds 2 and 3: Causation**

50. Martin Spencer J found that, on the evidence, the Scheme resulted in discrimination on grounds of
nationality and/or ethnicity; and the Secretary of State was responsible for this discrimination. In Grounds
2 and 3, Sir James submits that the judge erred, in (i) concluding that there was any such discrimination;
(ii) failing to make any adequate assessment of any discrimination there might have been, the nature and
level of discrimination of course being relevant, not only to causation, but also the issue of ambit and/or
justification; (iii) concluding that any discrimination arose from the Scheme; and (iv) concluding that any
discrimination caused by the Scheme was the responsibility of the Secretary of State, rather than
exclusively that of landlords operating the Scheme unlawfully. These grounds can conveniently be dealt
with together.

51. Before the judge and before us, it was common ground between the parties that the market for rental
accommodation in the private sector in most parts of the country is a “sellers' market”, i.e. demand far
outstrips supply, so that a landlord or agent will have a considerable choice of potential tenants. In terms
of causation, this was (said the judge) “the starting point”. He continued (at [70]):

“The scheme places on landlords a heavy administrative burden with potentially serious penal
consequences and is therefore both costly and risky. Given that most landlords have only one interest,
namely letting their property and maximising their income, delays in letting which lead to periods of nonoccupancy are unwelcome and the scheme heavily incentivises landlords to let to those individuals who do
not need a 'right to rent' and in particular where their status is uncontrovertibly established with a passport.
Thus, unless a potential occupier has convincing documentation establishing his British/EEA nationality
and in particular a passport, it is to be expected that landlords and agents will use proxies instead, the
obvious candidates being name, accent, colour and other signifiers of ethnicity. Such discrimination
comprises direct race discrimination and, as such, is contrary to section 13 of the Equality Act 2010…”.

52. This appears to have been the foundation of the judge's factual findings in relation to causation. Three
points are noteworthy.

i) The judge (in my view, correctly) identified the discrimination as essentially based on nationality rather
than race – the landlords wish to have British tenants – although, where the potential tenant does not have
a British passport, the proxies for nationality are ethnically-based.

ii) Without prejudice to Ms Kaufmann's submission that the Scheme caused or contributed to that
discrimination (in the sense that, but for the Scheme, the level of discrimination would have been less), the
judge found (again, in my view, rightly) that any discrimination against potential tenants who do not hold
British passports or do not have ethnically-British attributes is in any event direct discrimination by the
relevant landlords on the basis of nationality and/or race.

iii) On the evidence, the judge found that “most landlords have only one interest, namely letting their
property and maximising their income”. I shall return to that factual finding shortly (see paragraphs 68-69
below).


-----

Immigrants) (Residential Landlords Association and other....

53. The evidence upon which Ms Kaufmann relied to prove that the Scheme “inevitably” results in
discrimination for which the Secretary of State is responsible comprises primarily the evidence from the
mystery shopping exercises, supported by the various surveys of landlords and some anecdotal evidence,
to which I have already referred.

54. The Joint Council's mystery shopping exercises were key. It was submitted that they showed
statistically significant differences supporting the propositions that, as a result of the Scheme, (i) landlords
discriminated on grounds of nationality in favour of those with a British passport against those without; and
(ii) in respect of those without a passport, they discriminated on grounds of race in favour of those with
stereotypical ethnically British attributes (such as name, colour and accent) against those without. Whilst
the contemporaneous documents speak of race discrimination in relation to the second proposition, as I
have indicated, those exercises (supported by the landlord survey evidence and other evidence, such as
that of Mr Smith) suggest that ethnicity was in fact being used as a proxy for nationality, the landlords being
driven by the desire to let to “low risk” British nationals.

55. These exercises were criticised on behalf of the Secretary of State, both below and before us, notably
in paragraphs 30-37 of the statement of Mr Asmat and in submissions. The main criticisms were as
follows:

i) In respect of the February 2017 mystery shopping exercise, the different treatment of Harinder and
Ramesh (said to be as a result of their respectively having and not having a British passport) may equally
have been the result of the former having a passport rather than because he was British, particularly as
Peter did better than Colin and Harinder did better than Parimal. The evidence does not support the
proposition that landlords prefer British (as opposed to other) passports.

ii) There may have been a bias in the exercise, because Peter and Harinder offered a “British passport”,
whereas Ramesh offered merely a “Home Office document” and Colin (and, apparently, Parimal) merely
unidentified “other ID”. The disparity may have resulted from landlords preferring the offer of a specific
qualifying document. As the Discrimination Code of Practice (quoted at paragraph 28 above) confirms, it is
not unlawful for a landlord to favour a potential tenant who appears willing to provide a document or
documents demonstrating that he has a right to rent over those who do not.

iii) The exercise restricted consideration to “paired” data only. Even if such data have greater significance,
“unpaired” data have some statistical value too. The unpaired data showed no statistical differences, but
that in itself was worthy of some consideration.

iv) The exercise treated all non-responses as negative responses, and all “neutral” responses as positive
responses.

v) The February 2017 report did not find any statistically significant evidence of discrimination on the
grounds of ethnicity as between Parimal and Colin. Although the later report did find such evidence, the
evidence again should have been considered as a whole.

vi) The February 2017 exercise comparing Ramesh and Harinder – which found a statistically significant
difference, which suggested discrimination on grounds of British passport (i.e. nationality) – was not
repeated; so there is no evidence of replicability.

vii) The February 2017 exercise was performed in the first year of the Scheme's operation. Over time, it
could be expected that tenants and landlords would become more familiar with the Scheme, and the
results obtained do not necessarily reflect the mature position.

viii) The Joint Council's Report of September 2015 accepted that “discrimination in the housing market is
already commonplace” (see paragraph 30 above). The mystery shopping exercise did not properly
address the extent to which that discrimination was exacerbated, if at all.

ix) There was considerable evidence that landlords often asked for passports or similar identification
documentation even before the Scheme (see, e.g., paragraph 8 above). Again, the exercise did not
address the consequences of the change resulting from the Scheme.


-----

Immigrants) (Residential Landlords Association and other....

x) The mystery shopping exercises were limited to initial responses only, without taking into account the
tenancy-seeking process as a whole (as did the Secretary of State's own October 2015 exercise: see
paragraph 32 above).

xi) Turning to the surveys, the level of response was low. The Joint Council's September 2015 survey
(see paragraph 30 above) was based on 27 tests. For its February 2017 survey (see paragraph 40
above), only 108 landlords responded, together with 208 letting agencies and 17 from “organisations
working with or on behalf of affected groups”. Other surveys (including the RLA surveys: see paragraphs
41-42 above) had a larger response group, but still under 3,000 despite the fact that RLA approached
65,000 individuals and sought responses from other landlords on the internet. The largest survey (and the
only one with over 3,000 responses) was the Ministry of Housing 2018 survey of 8,000 landlords and
agents, which indicated that no more than 25% of landlords discriminated in the ways suggested (see
paragraph 43 above).

xii) Those responding to the surveys relied upon by the Joint Council were not selected: there could
therefore be less confidence in the representative nature of the responses, and specifically there was a risk
that those who responded for whatever reason did not like the Scheme and thus that the results were
infected with response bias.

56. Ms Kaufmann submitted that many of these criticisms, looked at individually, lacked any real force; but
in any event they could not stand in the face of the consistent evidence from the mystery shopping
exercises, as supported by the survey evidence, that landlords were discriminating against those without
British passports or proxy characteristics; and discriminating as a result of the Scheme.

57. Of the Secretary of State's own October 2015 mystery shopping survey, she submitted that it lacked
evidential weight, because “it failed to ask the right questions”, namely questions to test for discrimination
on the basis of nationality (as opposed to race or ethnicity) and, in relation to testing for BME
discrimination, it failed to test for those perceived to be foreign.

58. In support of the mystery shopping evidence, Ms Kaufmann relied on the evidence from the landlord
surveys to which I have referred. She submitted, with some force, that these speak with a consistent
voice: the Joint Council's own September 2015 survey found that 42% of landlords said that the checks
required by the Scheme made it less likely that they would consider letting to someone who does not have
a British passport (see paragraph 30 above) and, with the exception of the Ministry of Housing's 2018
survey (which produced a figure of 25%), the later surveys were generally in line with that figure.

59. That is confirmed by the statement of Chaitanya Patel, the Legal Policy Director of the Joint Council,
dated 30 January 2018 who, commenting on the survey evidence, said (at paragraph 37):

“What this shows is that surveys conducted by different agencies at different times have received a
consistent response from landlords on this point. Landlords have made their position quite clear: a very
significant proportion of them will discriminate on the basis of nationality or citizenship as a result of the
Right to Rent Scheme.”

In his view, “the logic of the Right to Rent Scheme incentivises precisely such behaviour” (paragraph
39(c)).

60. In terms of anecdotal evidence, Ms Kaufmann relied upon the evidence of Matthew Downie, the
Director of Policy and External Affairs at Crisis, an organisation that provides help to homeless people. In
paragraph 13 of his statement dated 27 November 2018 (quoted by Martin Spencer J at [94(iv)] of his
judgment), he said:

“We have anecdotal evidence from our services that Crisis clients have struggled to find private rented
sector accommodation because landlords would not accept them without a British passport. This includes
people from the Windrush generation, even those who have naturalisation documents. For example, Crisis
has been working with a client from the Windrush generation who was forced to find new accommodation


-----

Immigrants) (Residential Landlords Association and other....

after there was a fire in her house. The client had a right to rent, however new landlords would not accept
her as a tenant, because she did not have a British passport…”.

61. Looking at the evidence as a whole, Ms Kaufmann submitted that non-British tenants who have a
permanent right to rent face a clear disadvantage when compared with their British counterparts, as a
result of the Scheme.

62. Before the judge below, she was supported in particular by Mr Bates for the RLA. As recorded by
Martin Spencer J in his judgment, he submitted that, given the nature of the private rental sector:

“78. … It is… inevitable that a landlord would take a low risk approach.

79. Mr Bates submitted that the primary driver for any landlord will be the amount of rent that can be
recovered and that a landlord will be liable for the payment of tax and facilities even during void periods
when the property is empty. The rational landlord will seek to avoid the situation and therefore anything
that interrupts prompt re-letting will be avoided if possible. He submitted that the rational landlord, faced
with a tenant who could move in on the day who has a British passport and one who cannot because they
do not have a British passport will inevitably take the one with the British passport.”

63. In respect of these issues, Martin Spencer J preferred the submissions of Ms Kaufmann and Mr Bates.
He said (at [93]):

“In my judgment the evidence, when taken together, strongly showed not only that landlords are
discriminating against potential tenants on grounds of nationality and ethnicity but also that they are doing
so because of the Scheme. Whilst any individual piece of evidence would not, by itself, be sufficient to lead
to this conclusion, the evidence as a whole when taken together powerfully shows that this is the result. In
my judgment, there is a consistency through the surveys and arising from the mystery shopper exercises
that this is happening and the causal link with the Scheme was not only asserted by the landlords but is a
logical consequence of the Scheme for the reasons convincingly submitted by, in particular, Mr Bates on
behalf of the RLA.”

64. He then set out a summary of the evidence upon which Ms Kaufmann relied – agreeing with her that
the evidence from the Secretary of State's October 2015 pilot survey had a similarly low level of response
to those upon which the Joint Council relied, and the Secretary of State's criticisms of the Joint Council's
exercise “are redundant in the face of the consistent and striking picture which emerges from the various
large-scale surveys which now exist” (at [95]) – before continuing (at [96]):

“In conclusion, I was struck by the consistency of the evidence from the various different sources including
the [Joint Council], Shelter, Crisis, the RLA, the report by the Independent Chief Inspector of Borders and
Immigration and so forth. It is a short step to conclude that such discrimination is as a result of the
Scheme when the landlords say so and when it is logical for them so to act for the reasons cogently set out
by Mr Bates on behalf of the RLA. The extent of the discrimination is such that it is a short further step to
conclude that this is having a real effect on the ability of those in the discriminated classes to obtain
accommodation, either because they cannot get such accommodation at all or because it is taking
significantly longer for them to secure accommodation. It seems to me that the anecdotal case referred to
by Mr Downie is likely to be a typical example of the effect of the Scheme and, in so far as I have described
the two conclusions above as short steps, they are ones which I am prepared to, and do, take.”

65. As I have described, Sir James submits that the judge erred, in (i) concluding that there was any
discrimination on grounds of nationality and/or race; (ii) failing to make any adequate assessment of any
discrimination there might have been, the nature and level of discrimination of course being relevant to the
issue of ambit and/or justification; and (iii) concluding that any discrimination was caused by the Scheme,
rather than by landlords operating the Scheme unlawfully.

66. I have not found these issues easy – I am afraid not as easy as Martin Spencer J apparently found
them to be. Whilst this court takes a cautious approach when considering findings of fact (including factual
assessments) by the judge below (see, e.g., R (Smech Properties Limited) v Runnymede Borough Council


-----

Immigrants) (Residential Landlords Association and other....

_[2015] EWCA Civ 42; [2016] JPL 677 at [29] per Sales LJ, as he then was), regrettably, I am unable to_
agree with all of Martin Spencer J's analysis and intermediate assessments and other findings of fact; but,
nevertheless, I have ultimately concluded that he was right to find that those who had a right to rent, but did
not have British passports (or, particularly, had neither such passports nor ethnically-British attributes),
were the subject of discrimination on the basis of their actual or perceived nationality; and that that
discrimination was caused by the Scheme in the sense that, but for the Scheme, that level of such
discrimination would not have occurred. My reasons are as follows.

67. To deal, first, with two minor points.

i) Whilst the Secretary of State's October 2015 survey was indeed small, the Ministry of Housing's 2018
survey (which suggested discrimination, but at a lower level than suggested by the surveys upon which the
Joint Council rely) was by far the largest (see paragraph 43 above).

ii) The report by the Independent Chief Inspector of Borders and Immigration did not deal with this issue –
he was primarily concerned with absence of appropriate monitoring, to which I will return (see paragraphs
143 and following below).

68. More importantly, Sir James objected to the proposition, suggested particularly by Mr Kaufmann and
Mr Bates and taken up by the judge, that it was “rational” or “logical” for landlords to discriminate against
those without British passports and/or apparent ethnically British attributes such as name. I too find this a
troubling concept. It appears to be based upon the premise that “most landlords have only one interest,
namely letting their property and maximising their income…” (see [70] of the judge's judgment, quoted at
paragraph 51 above) so that “it is rational in the purely economic sense for a landlord to avoid the risks [of
letting to a non-British citizen] which he can do by renting to British passport holders” (see [82]).

69. However, like Sir James, I cannot accept the concept of an individual acting “rationally” or “logically” by
taking a course of action which, whilst being in his own interests, is to his knowledge discriminatory and
unlawful. As Ms Kaufmann rightly stressed – as did Martin Spencer J (see [1] of his judgment) –
discrimination on the basis of any protected characteristic is insidious, and on the basis of such sensitive
core attributes such as sex, sexual orientation or race is a particular anathema. Whilst discrimination by
landlords on the basis of nationality and/or race as a result of the administrative burdens and enforcement
provisions imposed on them by the Scheme may have been foreseeable, or even inevitable (as Ms
Kaufmann submitted), I simply do not see how it can be properly be described as “rational” or “logical”.

70. In any event, the premise is not supported by the evidence. On the basis of the Joint Council's
evidence at its highest, less than half of landlords discriminate in the manner suggested. Despite the
“risks” of doing so, on the evidence, at least a majority of landlords manage to comply with the Scheme
without unlawfully discriminating against those who are actually or apparently non-British. Whilst I well
understand the pressures on landlords, there is no evidence to explain why the minority discriminate
against potential tenants who are actually or apparently not British, in circumstances in which at least half
of them can and do comply with the Scheme without being discriminatory. On the basis of the evidence,
contrary to Ms Kaufmann's submission, discrimination as a result of the Scheme, whilst quite possibly
foreseeable, was clearly not inevitable. Indeed, leaving aside anecdotal evidence, the best (and, it
appears, the only) evidence of actual discrimination – as opposed to evidence of likely intent, or evidence
based on fictitious (“mystery shopper”) tenants – is that from the RLA landlord surveys in 2017 and 2018,
consistently to the effect that, in the first 30 months of the Scheme being in operation, only 5-6% landlords
in practice discriminated in the manner suggested in this claim (paragraphs 41(i) and 42 above).

71. In respect of the criticisms of the Joint Council's mystery shopper exercises, I accept that not all are
particularly compelling. For example, that the statisticians who analysed the data treated all nonresponses as negative responses and all “neutral” responses as positive responses seems to me to be
unexceptionable. However, others appear to me to have some force, e.g. the possible bias as a result of
the specificity of documents offered. The fact that, for one reason or another, none of the exercise results
upon which the discrimination claims are based has been replicated also reduces the confidence one can


-----

Immigrants) (Residential Landlords Association and other....

have in them (although, of course, the extent to which other evidence supports the conclusion does
increase that level of confidence).

72. Similarly, the limitations on the survey exercises are obvious. Whilst it is said that the surveys relied
upon by the Joint Council had no comparator group because no such group was possible after the full roll
out in England (and the rental market system in the other home countries is significantly different), it is a
fact that, unlike the Secretary of State's October 2015 survey (see paragraphs 32-34 above), there was no
control group. Furthermore, the samples of the surveys relied upon by the Joint Council (like, I accept, the
Secretary of State's pilot survey in October 2015) were small. There are about two million private sector
landlords in the UK. The Joint Council February 2017 landlord survey elicited only 108 responses from
landlords and another 208 from letting agents. Of this survey, Mr Asmat observed that “this is a relatively
low level of response from which to draw the kind of wide-ranging findings the [Joint Council seek] to do”
(paragraph 31 of his 20 August 2018). Whilst the judge dismissed the force of that “in the face of the
consistent and striking picture which emerges from the various large-scale surveys which now exist” (see

[95] of his judgment), the RLA surveys approached 65,000 landlords and non-landlord members, as well as
seeking responses through websites and social media, and obtained only 2,792 and 2,478 responses
respectively. Those who responded were not selected. Those conducting the Shelter survey, by drawing
the sample from the YouGov panel, attempted to improve the representative nature of the data provided –
and were confident that they had obtained a very good representation of private landlords – but, because
very little is known about the demographic profile of landlords in the UK, accepted that it was not possible
to weight the survey results to be representative of all landlords (see page 6). The largest survey was the
Ministry of Housing's 2018 survey of about 8,000 private landlords and letting agents registered with one of
the government-backed tenancy deposit protection schemes, in which the landlords were selected so that
the data obtained could be weighted, which increased confidence in the representative nature of the
results. The RLA surveys drew their sample in a more restrictive way.

73. Therefore, whilst of course the survey evidence provides useful data, it seems to me that Sir James'
submission that it needs to be approached with some caution, particularly when seeking to extrapolate its
conclusions to the two million private landlords in the UK, has some force.

74. Furthermore, there was clear evidence to the effect that landlords discriminated on grounds of
nationality and/or race before the Scheme was implemented: for example, the Joint Council's own
September 2015 Report said that “discrimination is already commonplace” (see paragraph 30 above), and
the Shelter Report said that 41% of landlords in its survey admitted that it is “natural for prejudices and
stereotypes to come into letting decisions” (see paragraph 35 above). Whilst I appreciate that the surveys
(including the Shelter survey) sought to ascertain whether landlords would be more likely to let (or consider
letting) to people who were not (or who did not appear to be) British, consideration of the evidence as a
whole has to take into account the underlying level of discrimination.

75. For those reasons, I do not agree with every aspect of Martin Spencer J's approach or his findings.
However, whilst the burden of proving discrimination falls upon the person who asserts it – in this case, the
Joint Council – in the context of article 14, the courts recognise the difficulty in proving discrimination and
they take a broad brush approach to evidence (see, e.g., DH v Czech Republic (ECtHR Application No
57325/00) (2008) EHRR 3 at [178]-[179]). Despite the criticisms made on behalf of the Secretary of State
and my observations above, on the basis of all the evidence, I am satisfied that, as a result of the Scheme,
some landlords do discriminate against potential tenants who do not have British passports, and
particularly those who have neither such passports nor ethnically-British attributes such as name. By “as a
result of the Scheme”, I mean that, but for the Scheme, the level of discrimination would be less. Almost all
of the evidence – notably the evidence from mystery shopping exercises and surveys – points clearly in
that direction.

76. However, as a distinct issue, Sir James contends that the judge erred in failing to make any adequate
assessment of the nature and level of any discrimination there might have been. In particular, he criticised
the inference drawn by the judge at [60] of his judgment (as it happens, in relation to the issue of ambit), as
follows:


-----

Immigrants) (Residential Landlords Association and other....

“In considering the question of 'ambit', the starting point must be what is alleged to be happening as a
result of the Scheme. This is that, to put it shortly, those with a perfect right to rent are being discriminated
against in their quest for a property to rent on grounds of nationality or race. However, this does not make
it impossible for those in the category of those discriminated against to get housing: at its highest, the
evidence establishes that they will find it harder, in other words, it will take them longer. Nevertheless, I am
asked to draw an inference that, given the scale of discrimination, there will be some who have been
unable to find accommodation at all, or for such a long period that their family life has been interfered with.
For the purposes of considering the ambit of article 8, I am prepared to draw that inference.”

77. I agree that, on the evidence, this goes too far insofar as it suggests that there will be tenants who are
simply unable to find any private accommodation because they lack a British passport. As the judge
himself indicated, the evidence does not suggest that it is impossible for even those against whom
landlords discriminate to get private housing at all. Whilst any discrimination on the basis of status is to be
decried, the level of discrimination supported by the evidence here must not be inflated. The evidence
from the RLA landlord surveys in 2017 and 2018, was that, in the first 30 months of the Scheme being in
operation, 5-6% landlords in practice discriminated in the manner suggested in this claim. Even as to likely
intent, the evidence from the Joint Council's own initial survey was that 42% of landlords said that the right
to rent requirements had made them less likely to consider someone who does not have a British passport,
and 27% said they were reluctant to engage with those with foreign accents or names (see paragraph 30
above). The other surveys (except that of the Ministry of Housing, where the percentage was significantly
lower at 25%: see paragraph 43 above) appear to be broadly in line with those figures. However, even on
the basis of the figures derived from the evidence most advantageous to the Joint Council's case (and
leaving aside any discount for the statistical weaknesses in the data), just over half of private landlords do
not discriminate in any way. Nearly half being guilty of discrimination is, of course, a high proportion – it is
shocking – but it means that a potential tenant in the category most discriminated against (no British
passport, and no ethically-British attributes) will on average take no longer than twice the time to obtain a
tenancy as it would take someone with a British passport. Whilst, of course, some potential tenants will be
unfortunate and take longer than the average time, the evidence cannot support the contention that there
are potential tenants who will never obtain private accommodation.

78. In terms of the consequences of the discrimination, in the light of the evidence that some landlords
discriminate on the basis of administrative convenience, Sir James also emphasised the following which,
he submitted, put the degree and consequences of any discrimination into context.

i) Evidence from the Joint Council (and, to an extent, Shelter) that some landlords discriminated against
potential tenants on grounds of nationality and/or race in any event (see paragraphs 30, 35 and 74 above).

ii) Uncontested evidence that, prior to the Scheme being in place, 70% of landlords already carried out
and recorded identity document checks on those to whom they rented property, and 40% checked a
passport (see paragraph 8 above).

iii) Uncontested evidence as to the numbers of those who might be the subject of discrimination, to the
effect that most potential private sector tenants will have a British or EU/EEA passport (or be entitled to
such a British passport) and the vast majority will be able to satisfy the prescribed requirements by
producing a single document (see paragraph 17 above).

iv) So far as housing is concerned, the position of those the object of such discrimination. This evidence
was not directly before Martin Spencer J, but is the subject of a helpful agreed note before us. Such
persons will, of course, be non-disqualified persons for the purposes of the Scheme; and therefore, if they
are unintentionally homeless, they will be able to obtain assistance under Part VII of the Housing Act 1996
if they are eligible (i.e. they are a refugee, a person habitually resident with indefinite leave to remain, a
person with limited leave to remain not subject to a condition requiring him to maintain and accommodate
himself and his dependents without recourse to public funds, or a person not subject to immigration
control) and have a priority need (such as households with children, a pregnant woman or a person
vulnerable on grounds of, e.g., old age, mental illness or physical disability). If ineligible for support under


-----

Immigrants) (Residential Landlords Association and other....

the Housing Act, (a) households with dependent children may be eligible for assistance under section 17 of
the Children Act 1989 if one or more of the children are “in need” (e.g. if they are homeless), (b) single or
childless couples may be entitled to assistance under the _[Care Act 2014,but they will only be](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-W431-DYCN-C3MY-00000-00&context=1519360)_
accommodated if their need for care and support cannot be met by the local authority without the authority
also providing accommodation and (c) persons who are believed to be the victims of trafficking or modern
**_slavery who have received a reasonable grounds decision will be entitled to secure accommodation_**
lasting until the later of a negative conclusive grounds decision or at least 45 days after any positive
conclusive grounds decision.

79. Therefore, whilst I am satisfied that, as a result of the Scheme, some landlords do discriminate against
potential tenants who do not have British passports and those who do not have ethnically-British attributes,
the nature and level of discrimination must be kept in perspective. That is, of course, an important factor in
relation to justification (see paragraphs 112 and following below).

80. On the basis that the Scheme caused discrimination, as I have found, Sir James had a further
argument, namely that there is insufficient nexus between the legislative provisions and the discrimination
to render the statute discriminatory, i.e. any discrimination is exclusively that of landlords as private citizens
for which the state bears no responsibility. However, although that could be cast as a causation argument
(and in his judgment my Lord, Davis LJ, considers it as such, and firmly concludes that there is insufficient
nexus for the claim to succeed: see paragraphs 158-163 below), that is a point which, in my view, is more
appropriately dealt with as a strand of justification (see paragraphs 112 and following below).

**Ground 1: Ambit**

81. It is now well-established and uncontroversial that article 14 is not a free-standing provision generally
proscribing discrimination on the grounds of a relevant status, but it relates only to the enjoyment of one of
the substantive ECHR rights – in this case, article 8.

82. However, for article 14 to be engaged, it does not require a breach of that substantive right, for
otherwise it would add nothing to the protection given by those rights and would be at most a mere
reinforcing provision. Nevertheless, it must have some relationship with a substantive right. Citing
authority going back to Abdulaziz, Cabales and Balkandali v United Kingdom (ECtHR Application Nos
9214/80, 9473/81 and 9474/81) (1985) 7 EHRR 471 at [71], in Stec v United Kingdom (ECtHR Application
Nos 65731/01 and 65900/01) (2005) 41 EHRR SE18 at [38] the Grand Chamber of the ECtHR put it this
way:

“The Court recalls that article 14 complements the other substantive provisions of the [ECHR]. It has no
independent existence since it has effect solely in relation to the 'enjoyment of the rights and freedoms'
safeguarded by those provisions…. The application of article 14 does not necessarily presuppose the
violation of one of the substantive rights guaranteed by the [ECHR]. It is necessary but it is also sufficient
for the facts of the case to fall 'within the ambit' of one or more of the [ECHR] articles…”.

The formulation of the requirement that the facts of the case fall “within the ambit” of one or more of the
substantive rights set out in the ECHR has been generally adopted (see, e.g., Ghaidan v Godin-Mendoza

_[2004] UKHL 30; [2004] AC 557 at [10] per Lord Nicholls of Birkenhead)._

83. It is difficult to disagree with Baroness Hale's observation in In re McLaughlin [2018] UKSC 48; [2018]
1 WLR 4250 at [20]:

“It is fair to say that the English courts have made rather heavy weather of the ambit point, particularly in
connection with article 8, because of its broad and ill-defined scope”.

In my respectful view, our courts have laboured over European authorities in an attempt to identify a set of
rules for the definition of “ambit” of substantive rights in this context which can be applied in the case
before them and, indeed, generally; whilst, as on other issues, the ECtHR has taken a relaxed and loose
approach to the concept which makes such close and comprehensive analysis difficult if not impossible.


-----

Immigrants) (Residential Landlords Association and other....

84. However, two propositions as to what falls within the “ambit” of article 8 for article 14 purposes can
perhaps be drawn from the Strasbourg cases.

85. First, if circumstances fall within the scope of article 8 then they also fall within its ambit. Therefore,
where there is violation of article 8, in the sense that there is an interference with rights falling within the
scope of article 8(1) which is not justified, that is also a violation of article 14 if it is discriminatory on the
basis of a relevant status. That is uncontroversial.

86. It is not so well-established that, even where there is an interference with rights falling within article
8(1) that is justified under article 8(2), that may also fall foul of article 14 if it is discriminatory. Ms
Kaufmann submitted that that was so. Sir James submitted that it was not. We were not referred to any
direct authority on that proposition, either way; but, whilst I appreciate the differences, in my view it draws
support from the parallel with cases in which the substantive right is absolute (rather than qualified), but
certain circumstances are expressly excluded from its scope. For example, although, by article 4(3) of the
ECHR, the definition of “forced or compulsory labour” as proscribed by article 4(1) expressly excludes “any
work or service which forms part of normal civic obligations”, an obligation to serve in the fire brigade or on
a jury discriminatory in favour of women has been held to fall within the ambit of article 4 and article 14
applied (Schmidt v Germany (ECtHR Application No A/291-B) (18 July 1996) and Adami v Malta (ECtHR
Application No 17209/02) (2007) 44 EHRR 3). In my view, for the reasons I shall give, the point does not
directly arise for determination in the appeal before us; but, in principle, I do not see why any conduct that
interferes with a qualified substantive right such as those in article 8(1) should not fall within the ambit of
that substantive right irrespective of whether it is justified; although, of course, in those circumstances the
state may be able to show that, as well as its interference with the substantive right, its discriminatory
conduct is also justified.

87. Second, where a state takes positive action which, whilst not required by article 8 (in the sense that a
failure to take such action would not have constituted an interference with rights within the scope of article
8(1)), demonstrates its respect for private and family life etc, this will fall within the ambit of article 8.
Therefore, where the state granted parental leave allowance to mothers and not fathers, whilst that did not
fall within the scope of article 8, the ECtHR held that it fell within its ambit for the purposes of article 14
(Petrovic). Indeed, as Sir Terence Etherton MR said in Smith v Lancashire Teaching Hospitals NHS
Foundation Trust [2017] EWCA Civ 1916; [2018] QB 804 at [42]:

“There are numerous Strasbourg authorities to that effect, in which the positive measure is described as a
'modality' of the right conferred by the substantive provision of the Convention.”

Whilst the term is not found in the Strasbourg cases themselves, since Smith, such circumstances have
been referred to as “positive modality cases”, as they were in this case.

88. Turning to the instant appeal, on the basis of these propositions, Ms Kaufmann and those appearing
for the Interveners submitted that the facts of this case fell within the ambit of article 8 on one of three
bases.

89. First, in her cross-notice of appeal, Ms Kaufmann submitted that Martin Spencer J erred in concluding
that the facts of this case did not fall within the scope of article 8. At [60] of his judgment (quoted at
paragraph 76 above), the judge found that “given the scale of discrimination, there will be some who have
been unable to find accommodation at all, or for such a long period that their family life has been interfered
with”. I have already dealt with the finding that some potential tenants will be unable to obtain
accommodation at all: in my view, such a finding could not properly be made on the available evidence
(see paragraph 77 above). With regard to his alternative conclusion, that there will be some who will be
unable to find accommodation for such a long period “that their family life has been interfered with”, Ms
Kaufmann submits that, on the basis of that finding, the judge ought to have gone on to conclude that, as
the discrimination interfered with the right to family life of non-British applicants for private rental
accommodation, article 8 was directly engaged.

90. Second, Mr Westgate for Liberty submitted that this is a positive modality case.


-----

Immigrants) (Residential Landlords Association and other....

91. Ms Kaufman does not consider this to be such a case, because the Scheme is not designed positively
to promote the substantive right to enjoyment of family or private life etc, but rather restricts access to an
entitlement which (she submits) enhances enjoyment of that substantial right in the form of the ability to
enjoy private and family life in a (rented) home (see, e.g., paragraphs 58-59 of her Skeleton Argument).
However, in pressing her argument that this is a “negative modality” case within the ambit of article 8 (see
paragraph 93 below), she submits that it is highly material that (i) the boundary between a state's positive
and negative obligations is unclear, (ii) a negative obligation can often be expressed in terms of an
equivalent positive obligation and (iii) whilst, in the common law, we refer to a pre-existing freedom to enter
into a lease (which the Scheme negatively infringes), as a matter of civil law, it is likely that there will be an
express right afforded by the state to enter into such contracts (see, e.g., articles 1102 and 1713 of the
French Civil Code, article 1322 of the Italian Civil Code and article 1255 of the Spanish Civil Code).

92. This was picked up by Mr Westgate. Following a historical review of the development of the law in
relation to the holding of land by non-British citizens, he developed the argument into a submission that this
is properly considered as a positive modality case, because at common law the only aliens who were able
to hold a lease were merchants and the law has been positively developed by Parliament in the Aliens Act
1844 through to the 2014 Act progressively to allow non-British citizens to hold a lease. It is in the context
of that positive development that any discrimination in this case arises. Furthermore, he submits, since the
enactment of the _[Housing Act 1985,occupation of premises as a person's “sole or main residence” has](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJW0-TWPY-Y0XD-00000-00&context=1519360)_
been the gateway through which that person has access to various state benefits through various statutory
schemes. By restricting occupation of a residence at all, the Scheme restricts access to this broader range
of benefits, which themselves constitute a demonstration of respect for people's ability to establish and
maintain homes, and private and family lives. For that reason too, he submits, this can be regarded as a
positive modality case.

93. Third, Ms Kaufmann, supported by those representing the Interveners, submits that, even if not a
positive modality case, the Scheme restricts access to, and thus the ability to enjoy, private and family life
in a rented home which has more than a tenuous connection with the core values of article 8 which include
the need for settled accommodation required for private and family life to develop and flourish. This, it was
submitted, can be described in terms of a “negative” infringement of a pre-existing freedom (hence, a
“negative modality” case).

94. Martin Spencer J rejected the contention that the facts of this case fall within the scope of article 8,
primarily because he considered that such a finding would be inconsistent with the clear Strasbourg
jurisprudence that article 8 does not give a person a right to a home. Whilst the positive modality argument
was not argued before him, he accepted that the facts of this case came within the ambit of article 8
effectively as a negative modality case, because Strasbourg jurisprudence regards racial discrimination
with particular anathema and analysing this case in negative modality terms would not acknowledge any
right to a home (see [68]). The judge continued (again at [68], emphasis in the original):

“Although article 8 does not give anyone the right to a home, in my judgment it gives everyone the right to
seek to obtain a home for themselves and their family even if they are eventually unsuccessful, and the
playing field should be even for everyone in the market for housing, irrespective of their race and
nationality. Where the state interferes with the process of seeking to obtain a home, in my judgment it
must do so without causing discrimination and this either engages article 8 or comes within its ambit. If the
Government's arguments were correct, a law could be passed which enacted a rule that landlords may
only rent to white, British nationals and this would not engage article 8 and therefore not offend against the

[ECHR] because article 8 does not give a right to a home, and this would not be a positive modality case.
That cannot be right.”

95. I agree with the judge's conclusion that the facts of this case do not fall within the scope of article 8,
essentially for the reasons given by him.

i) Article 8 expressly grants an individual the “right to respect for… _his home” (emphasis added)._
Therefore, whilst a requirement for a person to move out of a particular dwelling that is his home may


-----

Immigrants) (Residential Landlords Association and other....

interfere with the article 8 rights of him and/or his family, it is well-established that article 8 does not in
terms give any general right to a home (see, e.g., Chapman (cited at paragraph 26 above) at [99], and
Demopoulos v Turkey (ECtHR Application Nos 46113/99, 3843/02, 13751/02, 13466/03, 10200/04,
14163/04, 19993/04 and 21819/04) (2010) 50 EHRR SE14 at [136]).

ii) Ms Kaufmann drew the distinction between a positive obligation on the state to provide a home (which
she accepts is not within the scope of article 8), and an obligation to refrain from taking a measure which
interferes with the ability to find and obtain a home (which, she submits, is afforded by article 8); but,
although Martin Spencer J appears to have found some force in this submission, in my view that
distinction does not assist Ms Kaufmann in this context. Because there is no right to a home, leaving aside
for the moment any possible discrimination, there is nothing to prevent a state imposing general restrictions
on the ability to find and obtain a home. Sidabras v Lithuania (ECtHR Application Nos 55480/00 and
59330/00) (2006) 42 EHRR 6 (which concerned a ban on former members of the Lithuanian branch of the
KGB applying for any public-sector and many private-sector posts) does not support Ms Kaufmann here,
because, having found a breach of article 14 read with article 8, the ECtHR declined to consider whether
there had been a violation of article 8 taken on its own (see [63]).

iii) I deal with the judge's findings in relation to the effects of the Scheme on those against whom
discrimination is alleged above (see paragraphs 70 and following, especially paragraph 77); but it is clear
that, where the judge said at [60] of his judgment, that the scale of discrimination meant that “their family
life had been interfered with”, he was clearly not accepting that it fell within the scope of article 8, a
proposition he specifically rejected at [61].

iv) Ms Kaufmann relied upon the Government's acceptance that the Scheme engaged article 8 in
paragraph 99 of the section 19(1) memorandum (quoted at paragraph 26 above), which appeared to
recognise that the restriction of occupation of premises engaged article 8 as well as article 14. However,
as I have explained, that memorandum only considered the human rights implications for irregular
immigrants (who are more likely to find themselves homeless if not allowed to rent accommodation in the
private sector); and, in any event, whether the Scheme is within or outside the scope of article 8 is a matter
of law for the court.

96. For those reasons, I do not consider that the facts of this case fall within the scope of article 8(1) of the
ECHR; although, if I am wrong in that conclusion, for the reasons I give below (see paragraphs 112 and
following), I consider that any interference with those rights would not be disproportionate such as to lead
to the conclusion that the Scheme is incompatible with article 8.

97. I find the question of whether the facts of this case fall within the ambit of article 8 for the purposes of
article 14 far more challenging. However, for the following reasons, for the purposes of this appeal I am
prepared to assume that they do.

98. For my own part, I did not find the submissions based upon a close analysis of positive and negative
modality, itself based on the state's positive and negative obligations, of great assistance. As I have
indicated, these are not terms generally used in the Strasbourg cases; and I do not consider that the
Master of the Rolls was advocating any formal classification of modalities in Smith. There would be an
inherent difficulty in precisely defining where the boundary lay between positive and negative obligations,
recently acknowledged by me in R (Akbar) v Secretary of State for Justice [2019] EWHC 3123 (Admin) at

[70] and recognised by the ECtHR itself in Kroon v Netherlands (ECtHR Application No 18535/91) (1995)
19 EHRR 263 at [31]. Further, not only does the ECtHR generally shy away from such formalism, in Case
Relating to Certain Aspects of the Laws on the Use of Languages in Education in Belgium (The Belgium
Linguistics Case) (1979-80) 1 EHRR 252 at [B9], the ECtHR said, in this very context (emphasis added):

“In such cases there would be a violation of a guaranteed right or freedom as it is proclaimed by the relevant article
read in conjunction with article 14. It is as though the latter formed an integral part of each of the articles laying
down rights and freedoms. No distinctions should be made in this respect according to the nature of these rights
_and freedoms and of their correlative obligations, and for instance as to whether the respect due to the right_


-----

Immigrants) (Residential Landlords Association and other....

_concerned implies positive action or mere abstention. This is, moreover, clearly shown by the very general nature_
of the terms employed in article 14: 'the enjoyment of the rights and freedoms set forth in this Convention shall be
secured'.”

99. However, it is clear from the Strasbourg authorities that the “ambit” of article 8 is not restricted to its
“scope” and positive modalities. In Petrovic (the case put forward as the quintessential positive modality
case) itself, citing Schmidt and Dahlström v Sweden (ECtHR Series A No 21) (1976) 1 EHRR 632 at [32] to
which we were also referred, the ECtHR said (at [28]) (emphasis added):

“The Court has said on many occasions that article 14 comes into play whenever “the subject-matter of the
disadvantage… constitutes one of the modalities of the exercise of a right guaranteed”, or the measures
_complained of are 'linked to the exercise of a right guaranteed'”._

100. Similarly, in Adami (cited at paragraph 86 above) at [O-17], Sir Nicolas Bratza said this (again,
emphasis added):

“The central question which arises is what constitutes 'the ambit' of one of the substantive articles, in this
case article 4. It has been argued that 'even the most tenuous links with another provision in the
Convention will suffice' for article 14 to be engaged (see Grosz, Beatson and Duffy, The 1998 Act and the
European Convention (Sweet & Maxwell, 2000) at paragraph C14-10) Even if this may be seen as going
too far, it is indisputable that a wide interpretation has consistently been given by the Court to the term
'within the ambit'. Thus, according to the constant case law of the Court, the application of article 14 not
only does not presuppose the violation of one of the substantive Convention rights or a direct interference
with the exercise of such right, but it does not even require that the discriminatory treatment of which
complaint is made falls within the four corners of the individual rights guaranteed by the article. This is best
_illustrated by the fact that article 14 has been held to cover not only the enjoyment of the rights that states_
are obliged to safeguard under the Convention but also those rights and freedoms that a state has chosen
to guarantee, even if in doing so it goes beyond the requirements of the Convention. This would indicate in
my view that the 'ambit' of an article for this purpose must be given a significantly wider meaning than the
'scope' of the particular rights defined in the article itself. Thus, in the specific context of article 4 of the
Convention, the fact that work or service falling within the definition of 'normal civic obligations' in
paragraph 3 are expressly excluded from the scope of the right guaranteed by paragraph 2 of that article,
in no sense means that they are also excluded from the ambit of the article seen as a whole.”

That emphasises that “ambit” must be widely construed, an uncontroversial proposition; but, more
particularly, it uses positive modality cases as a mere non-exhaustive illustration of that width. Both of
those points are also to be found in the Master of the Rolls' judgment in Smith at [62].

101. Martin Spencer J concluded that the facts of this case fell within the ambit of article 8 for two reasons.

102. First, he considered that the nature and extent of the discrimination in this case went to the issue of
ambit. However, whilst some of the authorities faintly suggest that discrimination may be a factor in the
assessment of ambit (see, e.g., Van der Mussele v Belgium (ECtHR Application No 8919/80) (1983) 6
EHRR 163 at [43]), I find it difficult to see how the existence, nature and extent of any discrimination for the
purposes of article 14 can logically (and without circularity) bear upon the ambit of any substantive right for
those same purposes. They are, of course, relevant to justification – but that is a different issue.

103. Second, the judge considered that to find that the facts of this case fell within the ambit of article 8
would not be tantamount to recognising a right to a home. I agree; but, in my respectful view, that is
insufficient on its own to establish that the facts of this case fall into the ambit of article 8.

104. The Strasbourg authorities indicate that, where a positive measure of the state is being considered, it
is sufficient that that measure has more than a tenuous connection with the core values protected by the
substantive article (here, article 8). I appreciate that this is not a classic positive modality case; but it does
involve a positive measure by the state in the form of the Scheme. Whilst perhaps generous to the Joint
Council, I shall proceed on the basis that that “more than tenuous link” is the appropriate test. It certainly
reflects the generous width of the concept of “ambit” consistently applied by the ECtHR


-----

Immigrants) (Residential Landlords Association and other....

105. However, even on the basis that that is the test, the authorities that bear upon the ambit of article 8 in
the context of housing cases do not suggest any clear or consistent approach.

106. Bearing in mind the width of the concept to which I have referred, instinctively one is drawn towards
the conclusion that the facts of this case fall within the ambit of article 8. That is supported to an extent by
ECtHR authorities. The broad proposition that “Article 8 secure[s] to the individual a sphere within which
he can freely pursue the development and fulfilment of his personality” has been frequently repeated by the
ECtHR (see, e.g., A-MV v Finland (ECtHR Application No 53251/13 at [76] and the authorities referred to
there). In Bah (cited at paragraph 26 above), it was contended that an applicant with indefinite leave to
[remain in the UK who was not given priority for social housing under the Housing Act 1996 because her](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4K0-TWPY-Y051-00000-00&context=1519360)
son, who had later joined her in the UK, had been given leave to remain only on condition that he did not
have recourse to public funds, had been discriminated against under article 14 in conjunction with article 8
of the ECHR. The court held that this fell within the ambit of article 8, saying (at [40]):

“The impugned legislation in this case obviously affected the home and family life of the applicant and her
son, as it impacted upon their eligibility for assistance in finding accommodation when they were
threatened with homelessness.”

107. Similarly, turning to domestic cases, in R (HA) v Ealing London Borough Council [2015] EWHC 2375
_(Admin); [2016] PTSR 16, Goss J considered, obiter, whether the local authority's policy that applicants for_
secure accommodation under section 193 of the Housing Act 1996 must have lived in its area for a
minimum of five years discriminated against women who were the victims of violence. In finding that it did,
he explained the link with article 8 as follows (at [29]):

“… The link here is said to be home and family life. There is no enshrined right to a physical home; the
right is to the enjoyment of a family life. However, this can, in reality, only be enjoyed in settled
accommodation. Accordingly, I am satisfied there is a sufficient link.”

108. In R (H) v Ealing London Borough Council [2017] EWCA Civ 1127; [2018] PTSR 541, Sir Terence
Etherton MR quoted that with approval, and applied it to a housing priority scheme which (he held)
discriminated against women (see [100]-[102]). Underhill LJ agreed that “rights which are intended to take
a family out of precarious accommodation fall within the ambit of article 8” (at [132]; but Davis LJ (at [128])
was unwilling to accept on the arguments he had heard that there was a “right” to settled or permanent
accommodation within the reach of article 8. All of those observations, too, were obiter.

109. In R (Ward) v Hillingdon London Borough Council [2019] EWCA Civ 692; [2019] PTSR 1738, where
the issue arose again (although it proved not to be determinative), a different constitution of this court
considered the question of the required link with article 8 in cases involving accommodation “best left to a
case in which it matters” (at [109]).

110. I respectfully agree. Davis LJ concludes that the facts of this case do not fall within the ambit of
article 8 for the purposes of article 14 (see paragraphs 169-175 below). Whilst I see the considerable force
in what he says, it seems to me that, on balance, the ECtHR authorities suggest that the facts of this case
might well fall within the ambit of article 8 and Strasbourg has produced few cases in which an article 14
claim has failed because the facts have been held to have fallen outside the ambit of a substantive right
(although Botta v Italy (ECtHR Application No 21439/93) (1998) 26 EHRR 241, which concerned access to
private beaches, was one such). Because of my firm conclusion in relation to justification (see paragraphs
112 and following below), it is unnecessary to express a conclusion on the ambit issue, and I prefer not to
do so. In my view, that is an issue which can more appropriately be considered in a case where it is
determinative.

111. For those reasons, I shall proceed on the assumption, in the Joint Council's favour, that, whilst not
falling within the scope of article 8, the facts of this case fall within its ambit.

**Ground 4: Justification**


-----

Immigrants) (Residential Landlords Association and other....

112. On the basis that there was relevant discrimination which fell within the ambit of article 8 of the
ECHR, the vital question here – as is so often the case – is whether there is “an objective and reasonable
justification” for the difference in treatment to which the measure (i.e. the Scheme) gives rise.

113. In Bank Mellat v HM Treasury (No 2) _[2013] UKSC 39; [2014] AC 700 at [74], Lord Reed JSC_
helpfully formulated the test for justification in four questions, as follows:

“(1) whether the objective of the measure is sufficiently important to justify the limitation of a protected
right;

(2) whether the measure is rationally connected to the objective;

(3) whether a less intrusive measure could have been used without unacceptably compromising the
achievement of the objective; and

(4) whether, balancing the severity of the measure's effects on the rights of the persons to whom it applies
against the importance of the objective, to the extent that the measure will contribute to its achievement,
the former outweighs the latter.”

In this case, it is common ground that limbs (1), (2) and (3) are satisfied, the legitimate objective of the
statutory provisions being to support a coherent immigration system in the public interest, the Scheme
being a means rationally connected to that objective, and there is no less intrusive measure that could
have been used that would not have unacceptably compromised the achievement of that objective.

114. That leaves limb (4) which is, in my view, at the heart of this appeal. The issue raised in it can be
framed in terms of whether the impact of the right's infringement is disproportionate to the likely benefit of
the impugned measure (see Bank Mellat at [74] per Lord Reed; and R (SC) v Secretary of State for Work
and Pensions [2019] EWCA 615 at [84] per Leggatt LJ); or whether a fair balance has been struck between
the rights of the individual and the interests of the community (Bank Mellat at [20] per Lord Sumption JSC).

115. Two issues were raised concerning the correct approach to the question raised in limb (4) in the
circumstances of this case.

116. First, as I have already indicated, this claim was not brought by any individual claiming that he or she
has been the victim of discrimination as a result of the operation of the Scheme. Rather, it is a challenge to
the validity of the statutory provisions themselves. Sir James submitted that a challenge to a legislative
measure has to be distinguished from the operation of that measure in individual cases.

117. In respect of the former, as Baroness Hale, Lord Reed and Lord Hodge JJSC (with whom Lord
Wilson of Culworth and Lord Hughes of Ombersley JJSC agreed) put it in Christian Institute v Lord
Advocate [2016] UKSC 51; (2017) SC (UKSC) 29:

“This court has explained that an ab ante challenge to the validity of legislation on the basis of a lack of
proportionality faces a high hurdle: if a legislative provision is capable of being operated in a manner which
is compatible with Convention rights in that it will not give rise to an unjustified interference with article 8
rights in all or most cases, the legislation itself will not be incompatible with Convention rights (R (Bibi) v
Secretary of State for the Home Department _[2015] UKSC 68; [2015] 1 WLR 5055 at [2] and [60] per_
Baroness Hale, at [69] per Lord Hodge).”

In that case, the argument that the provision for a named person service in Part 4 of the Children and
Young People (Scotland) Act 2014 gave rise to a disproportionate interference with the article 8 rights of
children and parents failed because “it cannot be said that its operation will necessarily give rise to
disproportionate interference in all cases” (see [94]-[96]).

118. Bibi concerned a challenge to paragraph 295 of the Immigration Rules, which imposed a requirement
on a foreign spouse or partner of a British citizen or person settled in the UK to pass a test of competence
in the English language which, it was claimed, was irrational under common law, and also in breach of
article 8 and/or unjustifiably discriminatory in securing the enjoyment of that right contrary to article 14. As
Baroness Hale (with whom Lord Wilson agreed) said (at [2]):


-----

Immigrants) (Residential Landlords Association and other....

“The [claimants] have set themselves a difficult task. It may well be possible to show that the application of
the rule in an individual case is incompatible with the Convention rights of a British partner….  It is much
[harder to show that the rule itself is inevitably unlawful, whether under the Human Rights Act 1998 or at](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
common law…”.

Whilst finding that the rule, in the light of the then-current guidance, was likely to be incompatible with the
ECHR rights of a number of sponsors, she concluded (at [60]):

“I would not strike down the rule or declare it void. It will not be an unjustified interference with article 8
rights in all cases. It is capable of being operated in a manner which is compatible with the Convention
rights. Hence the appellants must be denied the remedy they seek.”

Lord Hodge (with whom Lord Hughes agreed) put it thus:

“… I think that there may be a number of cases in which the operation of the rule in terms of the current
guidance will not strike a fair balance. But there may also be cases in which it will. The court would not be
entitled to strike down the rule unless satisfied that it was incapable of being operated in a proportionate
way and so was inherently unjustified in all or nearly all cases… As a result, the appellants fail to show
that the rule itself is an unjustifiable interference with article 8 rights.”

Therefore, although some of these observations speak in terms of remedy, it is clear that all of the
members of the court (see Lord Neuberger of Abbotsbury PSC at [77]) held that legislation will not be
unjustified (and, so, not unlawful) unless it is incapable of being operated in a proportionate way in all or
nearly all cases.

119. Given that the Scheme is clearly capable of being operated in a proportionate way in most individual
cases – indeed, it seems to me that it is _capable of being operated by landlords in such a way in_ _all_
individual cases – in my view, this is a complete answer to the claim on both article 8 grounds (if, contrary
to my view, the facts of this case fall within the scope of that article) and the article 14 claim. Bibi was, of
course, a claim made under both articles, and it is clear that the court considered the proposition applied to
the justification in respect of both article 8 and article 14 read with article 8.

120. However, even if that were not so, for the following reasons I would have held that the discrimination
to which the Scheme gives rise was justified.

121. That brings me to the second issue concerning the correct approach to the question raised in limb (4)
of the Bank Mellat test.

122. Before Martin Spencer J, it was common ground that the correct legal test to be adopted in relation to
this question was as set out by Lord Mance JSC (with whom Lord Neuberger PSC and Lord Hodge JSC
agreed) in In re Recovery of Medical Costs for Asbestos Diseases (Wales) Bill [2015] UKSC 3; [2015] AC
1016 at [52]:

“I conclude that there is Strasbourg authority testing the aim and the public interest by asking whether it
was manifestly unreasonable, but the approach in Strasbourg to at least the fourth stage involves asking
simply whether, weighing all relevant factors, the measure adopted achieves a fair or proportionate
balance between the public interest being promoted and the other interests involved. The court will in this
context weigh the benefits of the measure in terms of the aim being promoted against the disbenefits to
other interests. Significant respect may be due to the legislature's decision, as one aspect of the margin of
appreciation, but the hurdle to intervention will not be expressed at the high level of 'manifest
unreasonableness'. In this connection, it is important that, at the fourth stage of the Convention analysis,
all relevant interests fall to be weighed and balanced. That means not merely public, but also all relevant
private interests. The court may be especially well placed itself to evaluate the latter interests, which may
not always have been fully or appropriately taken into account by the primary decision-maker.”

123. Martin Spencer J concluded (at 123]) that the adverse effects on those the subject of the
discrimination he had identified had not been justified by the Secretary of State:


-----

Immigrants) (Residential Landlords Association and other....

“For the reasons submitted by Miss Kaufmann…, which I accept, I have come to the firm conclusion that
the [Secretary of State] has failed to justify the Scheme, indeed [she] has not come close to doing so. On
the basis that the first question for the court to decide is whether Parliament's policy, accorded all due
respect, is manifestly without reasonable foundation, I so find.  On that basis, there is no balancing of
competing interests to be performed. However, even if I am wrong about that, I would conclude that, in the
circumstances of this case, Parliament's policy has been outweighed by its potential for race discrimination.
As I have found, the measures have a disproportionately discriminatory effect and I would assume and
hope that those legislators who voted in favour of the Scheme would be aghast to learn of its discriminatory
effect as shown by the evidence [before me]. Even if the Scheme had been shown to be efficacious in
playing its part in the control of immigration, I would have found that this was significantly outweighed by
the discriminatory effect. But the nail in the coffin of justification is that, on the evidence I have seen, the
Scheme has had little or no effect and, as Miss Kaufmann submitted, the [Secretary of State] has put in
place no reliable system for evaluating the efficacy of the Scheme…”.

124. Before this court, there was less common ground with regard to the correct test.

125. Relying particularly upon the judgment of Lord Toulson JSC in R (MA) v Secretary of State for Work
and Pensions [2016] UKSC 58; [2016] 1 WLR 4550 at [32]-[38], Sir James submitted that a measure such
as this, aimed at preventing illegal immigration, concerns “economic and social matters which are preeminently for national authorities” such that the assessment of Parliament that its adverse effects are
proportionate to the benefits to the public should be accepted unless manifestly without reasonable
foundation. In R (DA) v Secretary of State for Work and Pensions [2019] UKSC 21; [2019] 1 WLR 3289 at

[65], a welfare benefits (“bedroom tax”) case, it was made clear that, despite what Lord Mance said in the
Recovery of Medical Costs case, the manifestly without reasonable foundation test applied to all of the
Bank Mellat limbs including justification.

126. Ms Kaufmann, also relying on DA especially at [56]-[65] per Lord Wilson JSC, and at [117] per Lord
Carnwath JSC (with whom Lord Reed DPSC and Lord Hughes agreed), submitted that that test has only
ever been applied (and only applies) in the field of welfare benefits. This is not a welfare benefits case;
and, so, the manifestly without reasonable foundation test does not apply. The simple balancing test
applies.

127. The test of whether the adverse effects of a measure are manifestly without reasonable foundation
derives from the ECtHR in the context of assessments by a national legislature as to what is in the public
interest when implementing or applying EU law. The first reference in the Strasbourg jurisprudence
appears to have been in James v United Kingdom (ECtHR Application No 8795/79) (1986) EHRR 123, a
case in which it was contended that the compulsory transfer of the ownership of real property by the
[exercise by tenants of rights of acquisition conferred by the Leasehold Reform Act 1967 breached article 1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-H0X0-TWPY-Y1MN-00000-00&context=1519360)
of the First Protocol to the ECHR and article 14 read with that substantive provision. In finding that there
had been no breach, the court said (at [46]):

“Because of their direct knowledge of their society and its needs, the national authorities are in principle
better placed than the international judge to appreciate what is 'in the public interest'. Under the system of
protection established by the Convention, it is thus for the national authorities to make the initial
assessment both of the existence of a problem of public concern warranting measures of deprivation of
property and of the remedial action to be taken. Here, as in other fields to which the safeguards of the

[ECHR] extend, the national authorities accordingly enjoy a certain margin of appreciation.

Furthermore, the notion of 'public interest' is necessarily extensive. In particular, as the Commission noted, the
decision to enact laws expropriating property will commonly involve consideration of political, economic and social
issues on which opinions within a democratic society may reasonably differ widely. The Court, finding it natural that
the margin of appreciation available to the legislature in implementing social and economic policies should be a
wide one, will respect the legislature's judgment as to what is 'in the public interest' unless that judgment be
manifestly without reasonable foundation. In other words, although the Court cannot substitute its own assessment


-----

Immigrants) (Residential Landlords Association and other....

for that of the national authorities, it is bound to review the contested measures under article 1 of Protocol No 1 and,
in so doing, to make an inquiry into the facts with reference to which the national authorities acted.”

It is important to note that (i) whilst raising issues concerning social and economic policies, James was not
a welfare benefits case, and (ii) the “manifestly without reasonable foundation test” was seen as emerging
from the margin of appreciation afforded to democratically-elected and democratically-accountable national
authorities in implementing social and economic policies.

128. Similarly, in the field of human rights, our courts have recognised that certain matters involving
controversial issues of social and economic policy are by their nature more suitable for determination by
the democratically-elected Parliament or the democratically-accountable executive than by the courts, such
that, unless manifestly without reasonable foundation, their assessment should be respected (see, e.g., R
(SG) v Secretary of State for Work and Pensions [2015] UKSC 16; [2015] 1 WLR 1449 at [92]-[93] per Lord
Reed JSC).

129. Where it applies, manifestly without reasonable foundation has often been treated as a distinct test of
justification. For example, in Humphreys v HM Revenue and Customs Commissioners [2012] UKSC 18,
which concerned a claim under article 14 read with article 8 that the Child Tax Credit Regulations 2002 (SI
2002 No 2007) discriminated on the grounds of sex where there were separated parents, Baroness Hale
(with whom the other members of the court agreed) said (at [19]):

“It seems clear from Stec… that the normal strict test for justification of sex discrimination in the enjoyment
of Convention rights gives way to the 'manifestly without reasonable foundation' test in the context of state
benefits.”

130. However, as emphasised by Baroness Hale in Humphreys (at 22]) and Lord Wilson in DA (at [60]), it
does not follow that a measure alleged to be discriminatory should escape careful scrutiny. The correct
approach was set out by Lord Wilson in DA (at [66]):

“How does the criterion of whether the adverse treatment was manifestly without reasonable foundation fit
together with the burden on the state to establish justification…? For the phraseology of the criterion
demonstrates that it is something for the complainant, rather than for the state, to establish. The
rationalisation has to be that, when the state puts forward its reasons for having countenanced the adverse
treatment, it establishes justification for it unless the complainant demonstrates that it was manifestly
without reasonable foundation. But reference in this context to any burden, in particular to a burden of
proof, is more theoretical than real. The court will proactively examine whether the foundation is
reasonable; and it is fanciful to contemplate its concluding that, although the state had failed to persuade
the court that it was reasonable, the claim failed because the complainant had failed to persuade the court
that it was manifestly unreasonable.”

131. As I have indicated, Ms Kaufmann submitted that the manifestly without reasonable foundation test,
as applied by our courts to domestic state measures when considering justification, is restricted to welfare
benefits cases, of which this case is not one.

132. In respect of those submissions, I accept the following:

i) Recently, in JD and A v United Kingdom (ECtHR Applications Nos 32949/17 and 34614/17) (24 October
2019) (another “bedroom tax” case) at [88], the ECtHR said that, whilst there is a wide margin of
appreciation in the context of general measures of economic or social policy, such measures must not
violate the prohibition of discrimination as set out in article 14 and must comply with the requirement for
proportionality. The court continued:

“Hence, in that context the Court has limited its acceptance to respect the legislature's policy choice as not
'manifestly without reasonable foundation' to circumstances where an alleged difference in treatment
resulted from a transitional measure forming part of a scheme carried out in order to correct inequality…”.


-----

Immigrants) (Residential Landlords Association and other....

ii) We were not referred to any case in our domestic law where the criterion of manifestly without
reasonable foundation has been considered (let alone applied) in the context of the consideration of a
legislative or executive measure other than in the field of welfare benefits.

iii) Whilst he did not restrict his observations to welfare benefit cases, in SG, Lord Reed did add this rider
(at [93]): “… controversial issues of social and economic policy, _with major implications for public_
_expenditure”; and, in DA, Lord Wilson said (at [65]) that the test applied “at any rate in relation to the_
Government's need to justify what would otherwise be a discriminatory effect of a rule _governing_
_entitlement to welfare benefits…”._

133. However:

i) Insofar as JD and A differs from the jurisprudence in the Supreme Court cases to which I have referred,
we are bound by the latter.

ii) The manifestly without reasonable foundation criterion as used domestically derives from the ECtHR
case of James, a non-welfare benefits case (see paragraph 127 above).

iii) None of the domestic cases expressly states that the application of the manifestly without reasonable
foundation criterion only applies in the context of welfare benefits, and does not apply generally to a
measure implementing economic or social policy. Some either assume that it applies generally to such
measures (see, e.g., Langford v Secretary of State for Defence [2019] EWCA Civ 1271; [2019] Pens LR 21
at [54] (a case concerning the armed forces pension scheme)) or otherwise accept (at least, obiter) that it
applies (see, e.g., R (Turley) v Wandsworth London Borough Council [2017] EWCA Civ 189; [2017] HLR
21 at [25] per Underhill LJ, and Simawi v Mayor and Burgesses of the London Borough of Haringey [2019]
_EWCA Civ 1770 at [55]-[65] per Lewison LJ (both social housing cases). See also, now, R (Drexler) v_
Leicestershire County Council [2020] EWCA Civ 502, referred to below at paragraph 134).

iv) Welfare benefits, of course, comprise an area of policy in which both economic and social
considerations feature very large. However, there is no apparent logic or rationale for restricting the socioeconomic policy areas in which Parliament and the executive, as democratically-responsible bodies, are
uniquely qualified to assess the public interest as against other interests, to those of welfare benefits.
There are other sensitive areas, such as social housing and immigration, in which it may equally be said
that they are the most appropriate assessors of what is in the public interest and whether the adverse
impacts of any proposed or actual measure are proportionate to the benefits in the public interest.

134. For those reasons, if I were required to determine the matter, I would say that the manifestly without
reasonable foundation criterion applies to the issue of justification in this case. Whilst I have come to that
conclusion on the basis of only the arguments and authorities to which we were referred, I note that, in a
judgment handed down since the hearing of this case, a different constitution of this court has also
concluded that the manifestly without reasonable foundation test applies when the impugned measure is,
not welfare benefits, but another area of socio-economic policy (in that case, a decision of a local authority
to amend its Special Educational Needs Home to School/College Transport Policy) (Drexler at [51]-[75]).

135. However, in my view, whether the manifestly without reasonable foundation criterion applies is not
determinative in this case, for two interrelated reasons.

136. First, although, as I have described, some authorities (both Strasbourg and domestic) appear to have
focused on whether the manifestly without reasonable foundation test applied or not, as I indicated in
Akbar at [98], I do not regard this as a simple binary question. In a case where there is a difference in
treatment, such as this, I said (at [98]):

“The 'area of judgment' [afforded to an arm of Government] depends upon the nature of the ground on
which the difference in treatment is significantly based.  If it is based on (e.g.) race, nationality, gender,
religion or sexual orientation, then a reviewing court will look, with especial intensity, for particularly
convincing and weighty reasons to justify that treatment.  But the area of judgment is also dependent upon
other factors, such as the objective of the measure: in certain areas,… democratically-elected or 

-----

Immigrants) (Residential Landlords Association and other....

accountable branches of government are better placed to determine whether something is in the public
interest and, if so, the weight to be accorded to that factor in the public interest. In those areas, the courts
will allow the relevant branch of government a greater margin of judgment, dependent upon a whole variety
of factors such as the branch of government involved (and, if it is the executive, the extent to which
Parliament had control over the measure by (e.g.) the positive or negative resolution procedure), the aims
of the measure, and the extent to which the branch of government had those aims in mind at the time the
measure was introduced.… [A]s well as affecting the area of judgment allowed to the branch of
government introducing the measure, for essentially the same reasons, these matters also bear upon the
appropriate intensity of review by any reviewing court.”

137. This is reflected to an extent in the earlier authorities. For example, as I have described (paragraph
127 above), the “manifestly without reasonable foundation” criterion emerged in James simply as a
manifestation of the margin of appreciation (or, more properly, “margin of judgment”) afforded to
democratically-elected and -accountable national authorities in implementing social and economic policies;
and the relationship of the criterion to the margin of appreciation is also apparent from JD and A (see
paragraph 132(i) above).

138. This relationship is also helpfully discussed by Leggatt LJ in SC at [85] and following, In particular,
he said:

87. … [T]here are compelling reasons for according the full area of judgment allowed to the UK under the

[ECHR] in matters of social and economic policy to the legislature and the executive. Within the UK's
constitutional arrangements, the democratically elected branches of government are in principle better
placed than the courts to decide what is in the public interest in such matters. Those branches of
government are in a position to rank and decide among competing claims to public money, which a court
adjudicating on a particular claim has neither the information nor the authority to do. In making such
decisions, the legislature and the executive are also able and institutionally designed to take account of
and respond to the views, interests and experiences of all citizens and sections of society in a way that
courts are not. Above all, precisely because decisions made by Parliament and the executive on what is in
the public interest on social or economic grounds are the product of a political process in which all are able
to participate, those decisions carry a democratic legitimacy which the judgment of a court on such an
issue does not have. For such reasons, in judging whether a difference in treatment is justified, it is now
firmly established that the courts of this country will likewise respect a choice made by the legislature or
executive in a matter of social or economic policy unless it is 'manifestly without reasonable foundation'.

88. …

89. Although it is not immediately obvious how the 'manifestly without reasonable foundation' test relates
to the assessment of proportionality that the court must undertake, the explanation may be that the court is
required to ask whether the difference in treatment is manifestly disproportionate to a legitimate aim. This
would accord with the statement of the European Court in Blečić v Croatia (2005) 41 EHRR 13, para 65,
that it will accept the judgment of the domestic authorities in socio-economic matters 'unless that judgment
is manifestly without reasonable foundation, _that is, unless the measure employed is manifestly_
_disproportionate to the legitimate aim pursued' (emphasis added). It also reflects how the Supreme Court_
applied the test in the recent case of In re McLaughlin [2018] UKSC 48; [2018] 1 WLR 4250, at [38]-[39]
(Baroness Hale) and [83] (Lord Hodge)”.

139. Leggatt LJ thus recognised that the manifestly without reasonable foundation test is not met simply
because the measure has a legitimate aim and is rationally connected to that aim: it must also be a
proportionate means to achieving that aim. It thus still requires a balancing exercise of the end and
means. It has been recognised that that is entirely consistent with the approach of Lord Wilson in [66] of
DA (see Langford, cited at paragraph 133(iii) above, at [54]).

140. The manifestly without reasonable foundation criterion, as used domestically, is derived from the
Strasbourg court, which, as I have already indicated (paragraph 98 above), generally shies away from
formalism Properly construed in my view the criterion cannot simply apply to some cases where there is


-----

Immigrants) (Residential Landlords Association and other....

an issue of justification in respect of a measure involving an element of social or economic policy
separated from other cases by a bright line. No such line can sensibly be drawn: the degree of social and
economic policy involved in any measure will be infinitely variable. In my view, the criterion simply
recognises that, where there is a substantial degree of economic and/or social policy involved in a
measure, the degree of deference to the assessment of the democratically-elected or -accountable body
that enacts the measure must be accorded great weight because of the wide margin of judgment they have
in such matters. The greater the element of economic and/or social policy involved, the greater the margin
of judgment and the greater the deference that should be afforded. That is, for obvious reasons,
particularly so when that body is Parliament. However, if the measure involves adverse discriminatory
effects, that will reduce the margin of judgment and thus the degree of deference. That will be particularly
so where the ground of discrimination concerns a core attribute such as sex or race. That, in my respectful
view, explains Baroness Hale's observation in Humphreys (quoted at paragraph 129 above): she could not
have meant that, where some element of social or economic policy is concerned, that simply “trumps” any
degree of discrimination.

141. If that analysis is right, whether seen in terms of the application of the manifestly without reasonable
foundation criterion or simply in terms of the usual balancing exercise inherent in the assessment of
proportionality, the result should be the same (see also the (I accept, possibly more limited) observations of
Singh LJ, with whom Bean and Newey LJJ agreed, in Drexler at [76]).

142. Looking at the issue of justification for the discrimination in this case, as I have found it to be, on the
basis of the usual balancing exercise, I am satisfied that it is justified. In coming to that conclusion, I have
taken into account, in particular, the following factors.

143. The relevant measure is an Act of Parliament implementing a socio-economic policy, against the
backdrop of EU Council Directive 2002/90/EC which requires Member States to adopt appropriate
sanctions against a landlord or other person who, for financial gain, assists a person who is not a national
of a Member State to reside in a Member State in breach of the laws of that state (see paragraph 2 above).
As such, very considerable deference must be afforded to Parliament's assessment of the public interest,
and as to whether the adverse effects for individuals are outweighed by the public benefits of the measure.

144. The aim of the Scheme is to reduce irregular immigration by prohibiting irregular immigrants from
obtaining accommodation in the private rental sector, and thus encouraging them to regularise their
immigration status by obtaining leave to remain or leaving the UK. The Scheme appears to be successful
in the sense that there is no evidence that irregular immigrants do now obtain such accommodation. Ms
Kaufmann has led evidence – which Martin Spencer J accepted (see [111]-[123] of his judgment) – that the
Scheme is ineffective in persuading irregular immigrants to leave the UK. She relied upon evidence from
the Joint Council's February 2017 Report (see paragraph 40 above) that only 31 out of 654 individuals who
came to the Home Office's attention as a result of the Scheme have since been removed from the UK, and
there was no evidence to suggest that the balance had any right to remain. Furthermore, she relied upon
Freedom of Information requests, reports of the Independent Chief Inspector of Borders and Immigration
and a response of the Secretary of State to the Home Affairs Committee in May 2018 to show that the
Secretary of State had no system for evaluating the efficacy of the Scheme. In the absence of such
evidence, she submitted that the Secretary of State could not begin to justify the discrimination caused by
the Scheme.

145. However, as Mr Asmat points out in his statement (at paragraph 48) and Sir James in his
submissions:

i) The Scheme is just one part of a set of measures designed collectively to deter illegal immigration by
making various facilities and services (including employment and NHS services, as well as
accommodation) unavailable to irregular immigrants.

ii) The evidence is that private sector accommodation has generally been made unavailable to them.


-----

Immigrants) (Residential Landlords Association and other....

iii) The logic, reflected in the Directive, is that this will discourage illegal immigration, as well as making
more privately rented accommodation available to those who are entitled to be present in the UK.

iv) The precise impact of the Scheme is very difficult to quantify, and it is simplistic simply to correlate
actual removals of those who have come to the attention of the immigration authorities with “success” of
the Scheme in its aim: the number of individuals who are deterred from coming to or staying in the UK as a
result of the Scheme is unknown and unknowable, and in any event it is the deterrence of the whole
platform of measures that is relevant.

v) If only 300 persons are deterred, the Scheme would have a financial benefit for the UK.

vi) Whether the Scheme has been effective is difficult, if not impossible, to verify empirically, and is
essentially a matter of judgment for Parliament.

146. While the degree to which the Scheme has contributed to its aim of discouraging illegal immigration is
difficult to quantify – and, I accept, more data collection and analysis might have been done in attempt to
assess it – in my view, the evidence points towards the Scheme having made _some, and more than_
insignificant, contribution to that aim. I note that, as recorded above (paragraph 113), it is common ground
that (i) the objective of the Scheme as a measure is sufficiently important to justify the limitation of a
protected right, (ii) the measure is rationally connected to the objective and (iii) a less intrusive measure
could not have been used without unacceptably compromising the achievement of the objective.  In my
view, the judge was wrong to dismiss the public benefits derived from the Scheme; and to conclude, as he
did, that the Scheme has had “little or no effect” so far as its aim of curbing illegal immigration is
concerned.

147. In respect of the Scheme's adverse effects, Ms Kaufmann submitted that Parliament enacted the
provisions unaware of the discrimination that would be (and, in the event, has been) caused by them; and
the judge said that he assumed and hoped that those Members of Parliament who voted in favour of the
legislative Scheme “would be aghast to learn of its discriminatory effect as shown by the evidence…” (at

[123]). However, it is clear that, when enacting the provisions, Parliament was aware of the _risk of_
discrimination by landlords implementing the Scheme against potential tenants who did not have a British
passport and, in particular, those who did not have ethnically British attributes such as name; and was
aware of how it was proposed that that risk be managed through section 33 of the 2014 Act (which was
introduced to deal with that identified risk) and the Discrimination Code of Practice. We simply do not
know, and cannot properly speculate, as to what might have been the expectation of Parliament as a
whole, and its individual members, with regard to the management of that risk. It certainly cannot be
assumed that they considered the risk would be managed so that the discrimination by landlords against
potential tenants on grounds of nationality and/or race would not increase as a result of the introduction of
the Scheme. In any event, in respect of the original enactment of the provisions, it is not to the point that
the discrimination which has in fact occurred may be greater than that then expected. If the discrimination
is greater than Parliament envisaged when enacting the provisions, about which I express no view, then
that is a matter for Parliament (or the Secretary of State) to address.

148. Whilst discrimination in all its forms is, of course, abhorrent:

i) The Scheme does not intend, encourage or directly create discrimination. Indeed, far from it. The
discrimination is entirely coincidental, in that the measure does not unlawfully discriminate against the
target group but only collaterally because, in implementing the Scheme, as a result of the checks required
by the Scheme and the possible sanctions for letting to irregular immigrants, landlords engage in direct
discrimination on grounds of nationality; and section 33 and the Discrimination Code of Practice clearly
recognise and seek to address that discrimination by landlords.

ii) Although the Scheme requires them to perform checks on whether potential tenants are disqualified
from occupying premises under an RTA (because they are irregular immigrants), that does not make
landlords agents of the state for these purposes: they engage in discrimination in implementing a statutory
scheme as private citizens (cf cases such as DH and R (European Roma Rights Centre) v Immigration


-----

Immigrants) (Residential Landlords Association and other....

Officer at Prague Airport [2004] UKHL 55; [2005] 2 AC 1, in which officers of the state operated a statutory
scheme in a discriminatory manner). Whilst, speaking for myself, I am prepared to accept that a statutory
scheme may be discriminatory because it results in discrimination by private citizens in its implementation,
that is subject to (i) the (very substantial) caveat that the operation of the scheme must give rise to
disproportionate interference in all cases (see paragraph 116-119 above) and (ii) in any event, the fact that
the discrimination arises from the operation of a statutory scheme by private individuals is relevant to the
justification balancing exercise.

iii) Whilst I do not suggest that this is a point of any great force, although the evidence is that, in respect of
potential tenants who do not have a British passport, landlords effectively use ethnic proxies for nationality,
the primary ground of discrimination is nationality not race.

iv) As Humphreys confirms (quoted at paragraph 129 above), even where discrimination is on the basis of
a core attribute such as sex or race, great weight still has to be afforded to the assessment of Parliament in
respect of a measure which implements economic or social policy, and its assessment that such
discrimination is proportionate to the legitimate aim of the measure.

149. Landlords discriminate against those who do not have British passports as a result of administrative
convenience and a fear of the consequences of letting to an irregular immigrant. However:

i) As I have described, the administration involved is not burdensome: it requires the checking and
copying of one (or, at most, two) identity documents, estimated to take 20 minutes or so, albeit in respect
of all potential occupiers and on possibly multiple occasions for those without permanent leave to remain.
For those without documents to which the Landlord Checking Scheme applies, it requires a check which
will take no more than two days.

ii) Employers have similar obligations in respect of employees, and appear to cope without difficulty and
apparently without discrimination. Ms Kaufmann sought to distinguish the profiles of landlords and
employers, but it is difficult to do so without evidence: whilst the evidence is that many landlords have only
one property, there are many employers with one or only a few employees.

iii) The evidence is that many – most – landlords comply with the administrative requirements without
discriminating. As I have said, it is unknown why all cannot do so. Those who do not comply not only
engage in unlawful discrimination contrary to the _[Equality Act 2010,they have an unfair commercial](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_
advantage over the majority who do.

iv) Enforcement of the Scheme, and the Equality Act obligations, is essentially also a matter for
Parliament. Ms Kaufmann submits that, compared with the potential sanctions for letting to irregular
immigrants, sanctions for breaching the duty not to discriminate under the Equality Act are ineffective: a
“rational” landlord will act defensively, and prefer to favour potential tenants with British passports (even if
discriminatory) because it is very unlikely that any action will be taken in respect of the discrimination.
However, Parliament has determined that the Equality Act obligations are enforceable through the county
court. If individual potential tenants cannot realistically take such proceedings, the Commission is able to
step in.

150. The nature and level of discrimination is also a relevant factor. I have dealt with this above
(paragraphs 76-79).  In short, the best evidence of discrimination which has in fact taken place comes
from the RLA surveys, which suggest that, over the first 30 months, 5-6% of landlords discriminated
against potential tenants who did not have British passports. The evidence of likely intent produces a
figure of over 40%. That discrimination will cause delay for some regular immigrants who seek
accommodation in the private rental market. However, they do not necessarily become homeless: the
[most vulnerable may be entitled to some assistance (e.g.) under the Housing Act 1996.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4K0-TWPY-Y051-00000-00&context=1519360)

151. With respect to the contrary conclusion of the judge, considering all those factors (including the
discrimination to which it gives rise), whether seen in terms of the manifestly without reasonable foundation
criterion or on a simple proportionality balancing exercise, I consider the Scheme to be a proportionate
means of achieving its legitimate objective and thus justified


-----

Immigrants) (Residential Landlords Association and other....

**Grounds 5 and 6: Relief**

152. For those reasons, I do not consider the Scheme to be unlawful as being in breach of article 14 of the
ECHR when read with article 8. In those circumstances, I can deal with Grounds 5 and 6 (which focus on
relief) shortly.

153. Ground 5 concerns the appropriateness of granting a declaration of incompatibility, which of course
falls with the substantive claim.

154. As for Ground 6, Sir James submits that Martin Spencer J was wrong to make a declaration that,
without further evaluation of the efficacy and discriminatory effect of the Scheme, the extension of the
Scheme to the other home nations would be irrational and a breach of the PSED. On the basis that the
substantive claim failed, he submitted that it would be premature to make such a declaration, in
circumstances in which no decision has yet been made to roll out the Scheme to the other home countries.
I agree. Whether it will be appropriate to make a further evaluation of the Scheme in the light of the current
evidence as to discrimination will be a matter for the Secretary of State at the relevant time.

**Conclusion**

155. For those reasons, I would allow the appeal, and dismiss the Joint Council's cross appeal.

**Lord Justice Henderson :**

156. For the reasons given by Hickinbottom LJ, with which I agree, I too would allow the appeal and
dismiss the Joint Council's cross appeal.

**Lord Justice Davis :**

157. I am in no doubt at all that this appeal should be allowed and the claim dismissed. It seems to me, in
fact, that the consequences of upholding the judge's decision would potentially be profound and would
potentially involve a significant encroachment on the rule of law.

158. My fundamental objection to the claim is, put shortly, this. Essential to these proceedings is the
proposition that the Scheme itself has caused and is responsible for the asserted discrimination. I simply
cannot and will not accept that. The whole essence of the Scheme – by the primary legislation, by the
Code, by the available guidance, by the applicability of the discrimination provisions and remedies
available under the _[Equality Act 2010and so on – is precisely to contrary effect. Thus so far from](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_
encouraging or incentivising discrimination, as is asserted, it seeks to do the opposite.

159. The reality is, to the extent that the surveys and shopping exercises are reliable, that in so far as
there is, or may be, discrimination on the part of a minority (not, note, even a majority) of landlords then
that is because they will have, to suit themselves, chosen not to comply with the law: essentially (put
bluntly) for their own perceived administrative convenience and/or economic advantage. But that is their
choice. It is not in any true sense compelled by the Scheme. On the contrary, as Hickinbottom LJ notes at
paragraph 119 of his judgment, the Scheme is capable of being operated proportionately by landlords in all
cases.

160. It therefore is simply not acceptable, in my view, to attribute responsibility for this postulated
discrimination to the legislature on the footing that such behaviour – albeit flatly contrary to the provisions,
indeed requirements, of the Scheme taken as a whole – is “logical” or “rational”. The courts cannot be
heard to entertain such a proposition. It may be “rational” for a hungry person who has no money to steal
bread from a baker's shop: but he has no valid excuse all the same. The claimant's arguments, and the
judge's acceptance of them, in effect involve private landlords being treated (under cover of knowing
references to the “real world”), as mere economic and profit-driven automata. That cannot be entertained.
Ms Kaufmann's and Mr Bates' submission that the Scheme “positively incentivises” landlords to
discriminate is quite wrong. The Scheme, taken as a whole, in fact is designed to achieve the opposite. It
is also no answer to say that (some) landlords are only, for fear of penalties, adopting a “risk averse”
approach b t there is no risk if the lo all and conscientio sl seek to follo the (q ite onero s b t in


-----

Immigrants) (Residential Landlords Association and other....

truth, not particularly onerous) requirements of the Scheme. Overall, the rational landlord, who is to be
deemed to know his legal obligations, is to be taken as being the law-abiding landlord. Rational people,
indeed, acknowledge the fundamental importance to society of adherence to the law.

161. The point can further be tested in this way. Landlords, or some of them, clearly do not like these
provisions, imposing as they do certain time-consuming obligations on them and with the risk of sanction
for non-compliance: as evidenced by the enthusiastic endorsement of this claim by the Residential
Landlords Association. But if this claim is right, they will in effect have brought about a declaration as to
the incompatibility of the Scheme by reason of their own discriminatory and potentially unlawful conduct in
not complying with it. If that is an acceptable argument, then one wonders about the implications for the
requirements imposed upon, for example, employers in comparable situations; or indeed for all those many
cases where people dislike the time-consuming requirements of what they choose in this context to see as
“red tape”. That, indeed, is why I view this case as potentially a challenge to the rule of law and is why, in
my view, the courts must not countenance it.

162. And it goes further. These proceedings necessarily focus on those who, it is said, will be (indirectly, if
not directly) discriminated against – viz those with a right to rent but with no British passport and no British
attributes such as name. The proceedings, for obvious reasons, are not focused on those who are in fact
the _direct targets of the Scheme (viz unlawful immigrants with no right to rent). But it is a reasonable_
inference that these proceedings may be in part collaterally designed to bring down the entire Scheme for
all purposes; views doubtless being held in some quarters, understandably enough, to the effect that the
Scheme also can operate unjustly and inhumanely on the direct targets of the Scheme (including – not
least – their families). In that respect, therefore, these proceedings also may stand as a proxy for that
further aim. In fact, if this claim is well-founded then it is extremely hard to see how _any_ such scheme
could work. So non-compliance by some landlords will then have brought about, by virtue of that very noncompliance, that further consequence. That too, in my opinion, is not acceptable.

163. It is also this feature – that discrimination is not sanctioned under this Scheme – which in my opinion
makes this case obviously different from cases such as DH and European Roma Rights Centre (cited at
paragraph 75 and 148(ii) above). In those cases, the legislative measures in question, when followed,
directly and necessarily as a matter of effect if not as a matter of intention brought about the discrimination;
and moreover did so through state organs (the state education system and state immigration service
respectively). But that is not so in this case, in either respect. To the extent that Mr Westgate also
suggested, on the latter point, that, in this context, landlords were to be equated with state agents I reject
that. They are not state agents: they are private landlords, contracting as they see fit, provided always
they comply with the law. Besides, even in the formal language of agency this argument fails. An agent
can only lawfully act within his authority: and if (some) landlords are choosing to discriminate in the way
suggested then they are not acting within their postulated “authority” at all. Rather, they are acting directly
contrary to it (having regard to the provisions of the Code etc). As Lady Hale pointedly said in R (Roberts)
v Commissioner of Metropolitan Police [2015] UKSC 79; [2016] 1 WLR 210– the stop and search case – at

[47] of her judgment:

“The law itself is not to blame for individual shortcomings which it does its best to prevent.”

Precisely so.

164. These considerations encapsulate the essential reasons for my rejection of the claimant's (and
Interveners') case. But I will, albeit relatively briefly, seek to put my objection into the context of the
Grounds of Appeal advanced and as dealt with by Hickinbottom LJ.

165. Whilst I certainly agree that the considerations arising under Ground 3 also may fall within the
matters requiring consideration for the purposes of assessing the arguments under article 14, I would not
for myself, as will be gathered, refrain from expressing a conclusion on this ground. My conclusion thus is
that, to the extent that there is discrimination, the Scheme (and thereby the State) is not responsible for it.
As will be gathered, I take the view that it is landlords, by their own actions, who are. It is, I think,


-----

Immigrants) (Residential Landlords Association and other....

legitimate to interfere with the judge's finding on this as, with respect, it is tainted by his whole approach to
the “logicality” of landlords so behaving.

166. If that conclusion is right, that would of itself dispose of this appeal. But as my Lords prefer not to
express a conclusion on this ground I will deal with the other grounds.

167. As to Ground 2, this raises complex issues of fact. I too am rather surprised that the judge thought
the evidential position as straightforward as he seems to have done. In my view, there are formidable
objections to or limitations on the evidence presented by the claimant as to the existence of discrimination,
which Hickinbottom LJ has helpfully summarised: for example, the lack of replication in the mystery
shoppers exercise, the lack of comparator or control group for the surveys, the relatively small numbers of
responses (and where, in some instances, neutral responses were treated as positive responses), the
evidence of prospective discrimination in any event irrespective of the Scheme: and so on. However, I
accept that there also are criticisms that can be made of the evidence adduced on behalf of the Secretary
of State: again as outlined by Hickinbottom LJ. To my mind, the evidence, viewed overall, seems
inconclusive.

168. Hickinbottom LJ has identified the reservations attaching to the judge's evidential approach on this
aspect of the case. Nevertheless, he takes the view on the evidence that a conclusion that there is
discrimination on the part of landlords is correct. Without expressing a final view of my own on this issue, I
am content for the present purposes to proceed on the assumption that that is so.

169. That, then, leads to the issue of ambit, for the purposes of article 14.

170. It is scarcely surprising that judges in this jurisdiction have made “heavy weather” (in the phrase of
Lady Hale) of this kind of point. The European jurisprudence seems to have developed in such an
unstructured and open-ended way that to identify a sure and principled approach, which is then to be
applied to the individual facts of each case, seems next to impossible. It is, of course, possible to view that
open-endedness as a thoroughly good thing. But, as against that, it can lead to uncertainty and
inconsistency in outcomes for individual cases. Moreover, it has long been established that article 14,
though having a degree of autonomy, is not in itself a free-standing right; rather, it is designed to be an
adjunct to the other substantive rights in the Convention. But article 14 seems, to me at least, increasingly
to be permitted to be acquiring a status and reach which it surely can hardly have been intended to have
had at inception: the more so when the words “or other status” are also given a wide meaning, as likewise
seems to be the trend. Certainly my own experience, such as it is, would tend to suggest that article 14
has ceased to retain its (honourable) position of long-stop – it now tends, if anything, to be deployed as an
opening bowler.

171. At all events, I agree with the judge and with Hickinbottom LJ that the position here, on the facts,
does not directly engage article 8. There is, as conceded, no right under article 8 to a home. Nor is there
an evidenced basis for drawing an inference that such discrimination as may exist would lead to
homelessness (as opposed to some degree of delay, inconvenience and injury to feelings). The
arguments in the Respondents' Notice are to be rejected.

172. As to article 14, it is on one view rather dismaying that the law requires drawing both a linguistic and
a substantive distinction between a situation being within the “scope” of article 8 and being (for the
purposes of article 14) within the “ambit” of article 8. The debate is hardly helped, either, by the
introduction of the concepts of “positive modalities” and “negative modalities”: as illustrated by this case,
where Ms Kaufmann and Mr Westgate could not even agree whether the present case was one of “positive
modality” or “negative modality”. As to that, if labels are to be used, then I would regard this, in agreement
with Ms Kaufmann, as a “negative modality” case (and, on that footing, Ms Kaufmann could cite no case
from the Strasbourg jurisprudence that in terms decides that such a situation can be brought within the
reach of article 14). But, that said, I think Ms Kaufmann and Mr Westgate are probably right in saying that
the Strasbourg jurisprudence does not in law really distinguish between such modalities.


-----

Immigrants) (Residential Landlords Association and other....

173. I appreciate that the direction of travel set by Strasbourg decisions is indeed increasingly broad and
inclusive with regard to article 14. But, given that article 14 is not in itself a free-standing right, there surely
must be some limit to the reach of that article. And I do not consider that that limit can change simply
depending on whether or not there is some element of discrimination and whether or not a “suspect”
characteristic (such as race or religion or sexual orientation) is said to be involved, although I of course
accept that particularly close scrutiny may be called for where a “suspect” characteristic is involved..

174. Many measures potentially have, on an open-ended reading of article 14, the capacity to come within
the reach of that article (and therefore potentially attract judicial review claims and arguments in courts of
law that they necessarily require justification): just because so many measures are, by their very nature
albeit on rational and explicable grounds, in one sense discriminatory. It is of the stuff of legislation and
regulations, for example, to have the effect: this group may have this benefit, that group may not; this
group may have this advantage, that group may not; this group need not pay for this service, that group
must. But that, in my view, cannot of itself suffice. As Lord Nicholls, for example, said in M v Secretary of
State for Work and Pensions [2006] UKHL 11; [2006] 2 AC 91 at [14]:

“The more seriously and directly the discriminatory provision or conduct impinge upon the values
underlying the particular substantive article, the more readily it will be regarded as within the ambit of that
article: and vice versa.”

And as Lord Walker confirmed in [82]-[83] of his judgment in that case, not every act of discrimination is
within the ambit of article 8 for the purposes of article 14. I agree.

175. My own assessment would be that the connection with article 8, in the circumstances of this
particular case, is too indirect and cannot be described as “more than tenuous”. In my view, it is at best
tenuous: and if that is so then at least the Strasbourg jurisprudence is clear that that will not suffice (see,
for example, the case of Adami cited at paragraph 86 above). There being no right to a home, and
potential homelessness, as such, here not being sufficiently evidenced, a degree of delay and
inconvenience in securing a letting where there is initial discrimination – it being borne in mind that the
majority of landlords will comply with the Scheme and not discriminate – does not, in my opinion, suffice.
None of the authorities cited to us (including Grzelak v Poland (ECtHR Application No 7710/02) as
particularly relied on by Ms Kaufmann) suggests, in my opinion, that article 14 is to be taken that far: even
accepting, of course, that all cases are ultimately fact-specific.

176. However, even on the footing that this case does come within article 14, I wholly agree with the
reasoning and conclusion of Hickinbottom LJ on the issue of justification. For that reason alone, and
conclusively, this claim should fail.

177. The Scheme, taken as a whole, is designed to achieve compliance with the law and at the same time
designed, in pursuit of its aims, to prevent discrimination. It is, as I have said, perfectly capable of
achieving that; and moreover it can do so without imposing any very great (even if to a degree tiresome)
obligations on landlords: who will in any event, in most instances, be used to making checks on
prospective tenants. Indeed, as I also have already indicated, compliance and non-discrimination will be
achieved if landlords simply seek to obey the law and follow the Discrimination Code of Practice and,
where necessary, avail themselves of the guidance.

178. Moreover, as stated by Lady Hale and Lord Carnwath in R (MM (Lebanon)) v Secretary of State for
the Home Department [2017] UKSC 10; [2017] 1 WLR 771 at [56]-[58], it is not enough that the measure in
question may lead to infringements of the principle of proportionality in individual cases. It is only so if the
measure in question is so framed as to make non-compliance in individual cases practically inevitable. But
that assuredly is not the position in the present case. Cases such as Christian Institute and Bibi (cited at
paragraph 117 above) further illustrate how difficult it is for a legislative scheme such as this to be found
incompatible.

179. This legislative scheme has a legitimate policy purpose. It is consistent with the 2002 Directive. It
preserves remedies under the _[Equality Act 2010. It was fully debated and consulted on in all relevant](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_


-----

Immigrants) (Residential Landlords Association and other....

respects, including discrimination, before being brought into effect. It is well-established, indeed essential,
that a margin of appreciation or judgment should be accorded to the legislature of states in this sort of
case. That is why such a measure ordinarily must be shown, in such a context, to be “manifestly without
reasonable foundation”, in the sense explained by Lord Wilson in DA (cited at paragraph 125 above),
before the courts will interfere.

180. This case, for the reasons given by Hickinbottom LJ and with which I agree, falls a very long way
short of meeting that criterion. In fact, I agree with him that it does not meet the criterion of
disproportionality even at the very “lowest” level of assessment, balancing the relevant considerations. A
fair balance was struck.

181. The appeal is therefore allowed, and the Joint Council's cross appeal dismissed. The parties are to
endeavour to agree any outstanding points and submit a Minute of Order accordingly. If any matter cannot
be resolved, concise written submissions are to be lodged and the court will then decide the matter on the
papers.

**End of Document**


-----

