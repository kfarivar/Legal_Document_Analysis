# R v TN [2022] EWCA Crim 1022

Court of Appeal, Criminal Division

William Davis LJ, Cutts J, HHJ Deborah Taylor

28 June 2022Judgment

MR A. JOHNSON (instructed by the CPS) appeared on behalf of the Prosecution.

MR B. DOUGLAS-JONES QC (instructed by Birds) appeared on behalf of the Applicant.

___________

If this Transcript is to be reported or published, there is a requirement to ensure that no reporting restriction will be
breached. This is particularly important in relation to any case involving a sexual offence, where the victim is
[guaranteed lifetime anonymity (Sexual Offences (Amendment) Act 1992), or where an order has been made in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)
relation to a young person.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**JUDGMENT**

LORD JUSTICE WILLIAM DAVIS:

1 In February 2018, houses in Merseyside and Greater Manchester were searched by the police after they
uncovered a conspiracy to produce cannabis. At an address in Bootle, on Merseyside, there was soil and
equipment associated with the growing of cannabis, together with fraudulent documents apparently used in
the renting of other properties. At three of those other properties the police found large scale cannabis
farms.

2 The tenant of the address in Bootle was a man named JN. His girlfriend was TN. JN and TN were
arrested in March 2018 when they were driving on the M6 near Carlisle. They had a very large amount of
cash in their possession. They were charged with conspiracy to produce cannabis.

3 TN's sister is this applicant. She was arrested in June 2018. A mobile telephone used in the conspiracy
was attributed to her by the police. It was believed that the applicant had been involved in renting
properties later used as cannabis farms. When she was interviewed, she said she had been in the UK
since early 2017, having entered the country illegally in the back of a lorry. She denied any involvement in
the conspiracy.

4 In due course the applicant was charged with the conspiracy involving JN and TN. They, and others,
were tried in the Crown Court at Preston, commencing in September 2018. On 10 October 2018, two
counts were added to the indictment in relation to the applicant; possessing criminal property, namely a
Louis Vuitton handbag bought for £2,750, which the applicant on her arrest had in her possession, and
entering into a money laundering arrangement from March 2018, namely taking steps to collect monies
owed to JN when JN had been remanded in custody after his arrest on the M6. These counts were added
near to the close of the prosecution case, after discussion between the prosecution and counsel then
representing the applicant.  She pleaded guilty.


-----

5 She also pleaded guilty to a separate indictment charging a conspiracy to pervert the course of public
justice. After her sister's arrest, the applicant had taken steps to obtain a false birth certificate in her
sister's name, purporting to show that her sister was aged sixteen. Had that been accepted by the judge
who dealt with TN at her first appearance at the Crown Court, it is likely that she would have been
remanded to secure accommodation rather than some institution within the youth custody estate. Had that
occurred, she would have had the chance to abscond.

6 On 11 December 2018, the applicant was sentenced to concurrent sentences of detention of four
months and ten months in respect of the counts of possessing criminal property and entering into a money
laundering arrangement. A consecutive sentence of eight months' detention was imposed in relation to the
conspiracy to pervert the course of public justice. Her application for an extension of time of 993 days for
leave to appeal against those sentences has been referred to the full court by the single judge.

7 She is represented today by Benjamin Douglas-Jones QC. The prosecution are represented by Andrew
Johnson. Neither appeared in 2018 in the Crown Court at Preston.

8 The basis of the application is that material is now available in relation to the applicant's status as a
victim of trafficking, which was not available to the sentencing judge. In particular, a conclusive grounds
decision of the single competent authority (SCA) made under the national referral mechanism (NRM) on 24
February 2021. It is not said that the convictions were unsafe. This is not a case where, had the
conclusive grounds decision been available in 2018, the prosecution would not have proceeded. Nor was
there, even on the basis of that decision, any defence available under the **_[Modern Slavery Act 2015.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
Rather, the submission is that had the judge known of the applicant's status, it would have afforded very
significant mitigation so as to reduce the sentence substantially. In oral submissions, Mr Douglas-Jones
argues that in reality it would have led to a non-custodial sentence.

9 The prosecution, in responding to the application, note that the conclusive grounds decision was based
on an untested account given by the applicant. They invite us to consider whether we should hear
evidence from the applicant (see _AAD_ _[[2022] EWCA Crim 106 at [82]). In any event, they say that the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_
circumstances of the applicant's case provide no basis for any interference with the sentence imposed in
2018.

10 The pleas to the offences pursuant to the Proceeds of Crime Act 2003 were tendered on a written
basis. The applicant said that JN was involved with her sister. She became aware that JN was involved in
some sort of offending which resulted in the realisation of criminal property in the form of cash. She had
played no part in that offending prior to the arrest and remand of JN and her sister. She had never
conspired to produce cannabis. But following the arrest and remand of JN and her sister, she was directed
by JN to try and collect money owed to him as a result of his criminal activity. He wanted her to send
money into prison to him and TN. The applicant said that she felt compelled to agree to help him. She
was to telephone people JN identified to her and request that they provide money owed to him. She was
told that this was the only way to help her sister. In the event she was not successful in obtaining any
money.

11 The basis went on to deal with the Louis Vuitton handbag. The applicant said that it had been dropped
off with her by TN prior to her arrest. Her understanding was that it was purchased for TN by JN as a
Valentine's Day present. She knew it must have been purchased using the proceeds of crime.

12 The written basis of plea concluded with these words:

“I maintain that I was the victim of trafficking into the UK but accept that I voluntarily participated in the two
offences to which I have pleaded guilty.”

13 The proposition that the applicant had been trafficked was a central theme of her defence in the trial.
Her defence statement acknowledged that she had tried to obtain money on behalf of JN. Insofar as this
amounted to criminal conduct, it was said in the defence statement that this was a direct consequence of
the applicant being a victim of trafficking. The exploitation was said to have involved kidnapping, false
imprisonment, slavery and different forms of violent and sexual abuse.


-----

14 In the course of the trial, the prosecution served Facebook evidence which undermined the account
that the applicant previously had given to the police as to the nature of the trafficking and exploitation to
which she had been subject. Objection to the late introduction of this evidence was made by way of a
detailed skeleton argument. That skeleton argument set out in detail the nature of the applicant's defence
under s.45 of the 2015 Act, as was then being put forward. It addressed the point that it was impossible for
the applicant to deal with the evidence when it came so late in the day. In the event, this argument was
never resolved and the point was never determined because the applicant tendered the pleas of guilty as
we have already set out.

15 Counsel who appeared for the applicant at trial has since explained that those pleas were tendered
freely and the applicant accepted that her trafficked status did not affect her participation in criminality in
2018.

16 When the case was opened by the prosecution at the sentencing hearing, reference was made to the
applicant's trafficked status. Her case, in terms of the statement she had made to the police in 2017, had
been that she had been trafficked after the death of her parents. The Facebook material, amongst other
things, rebutted the proposition that her parents were dead. Thus, said the prosecution, the suggestion
that the applicant had been trafficked was fatally undermined.

17 When mitigating on behalf of the applicant, counsel did not refer to the applicant's trafficked status one
way or the other. He has explained that he was alive to the difficulty created by the Facebook material. At
that time he had no instructions from the applicant which enabled him to explain the apparent contradiction
between the account she had given to the police and this material now available. Were the issue of
trafficking to have been the subject of a _Newton hearing, he, as he explained, could not have advanced_
any case which could satisfactorily explain the contradiction.

18 The personal mitigation on which counsel relied was the fact that the applicant was the sole carer for
her baby son, the child being aged fifteen months at the date of sentence. The baby had been taken into
care when the applicant was remanded in custody.

19 When sentencing, the judge applied the guideline relating to money laundering offences in the
_[Proceeds of Crime Act 2002. It is not suggested that he did so inappropriately by reference to the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C680-TWPY-Y037-00000-00&context=1519360)_
applicant's role. In relation to the sentence to be imposed for perverting the course of justice, the judge
concluded that the proposed interference was very serious and justified a sentence after trial of twenty-one
months' custody. This conclusion is not criticised. The judge applied a reduction of between twenty-five
and thirty-three per cent, depending on which offence he was looking at, to allow for the mitigating factors
he identified, namely the applicant's age and immaturity and, in particular, the separation she had had to
suffer from her very young child. He then gave further credit for plea and totality. The judge made no
reference at all to the applicant's trafficked status or, indeed, to the contentions of the prosecution on that
issue.

20 At the time of sentence, the SCA had made a positive reasonable grounds decision that the applicant
was potentially a victim of trafficking. This was in April 2017, after an initial referral by Greater Manchester
Police. The applicant subsequently made a witness statement. This is the one in which she said that her
father had died in 2002 and her mother in 2013. She said that after her mother's death a woman had come
to her village in Vietnam and offered the applicant and her sister, TN, work. That had involved them being
taken to a location elsewhere in Vietnam and being forced to act as a sex worker. When she refused to
have sex, she was beaten and starved. Subsequently she and her sister were flown to another country,
not the United Kingdom, where again she was forced to have sex with men. Finally, they were brought to
the UK in a lorry, at which point the applicant was separated from her sister. She was taken to a house
being used as a cannabis farm. There she was forced to look after the men who were tending the crop
and she was raped by those men. In April 2017, she escaped from that house. That was when she had
gone to the police in Manchester, hence the referral to the NRM by the Greater Manchester Police.

21 In February 2019, so after the date of sentence, the SCA made a conclusive grounds decision that the
applicant was not a victim of trafficking. The basis for this decision essentially was that the applicant was
not a credible witness The decision was based in part on the pleas of guilty tendered by the applicant to


-----

the offences which we have already outlined. Further, the information posted on Facebook, it was said,
was wholly inconsistent with the witness statement she had made.

22 The applicant challenged this decision, as she was entitled to do. She then provided a second witness
statement. The way in which she said that she had been exploited in this second witness statement was
very different to the account she had given previously. It differed in terms of when the exploitation had
begun, the circumstances of the exploitation and the role of her parents. In relation to the first statement,
which was very different to the second, she said that she had been given a story to tell by her traffickers
and she had been too scared to tell the truth.

23 Thereafter, the applicant was served with a notice of a decision to deport her, presumably by reference
to her status as a foreign criminal. She requested a reconsideration of that decision. There appears to
have been a claim for asylum. There was then a second SCA decision, which again was negative. This
time the applicant applied for judicial review of that decision. After initial refusal of the application to apply
for judicial review, the Court of Appeal gave permission to appeal against the findings of the Administrative
Court. The upshot was that the Home Office agreed to reconsider the negative conclusive grounds
decisions. So it was that on 24 February 2021 the SCA accepted, on a balance of probabilities, that the
applicant had been a victim of modern slavery in Vietnam between 2000 and 2016, for the purposes of
forced labour and prostitution, and in the UK from the end of 2016 to April 2017, namely the date she had
gone to the police, for the purposes of sexual exploitation and domestic servitude.

24 In oral argument, Mr Douglas-Jones set out the terms of the decision and the nature of the exploitation
in some detail. We do not consider that we need to.  The decision speaks for itself. It sets out a
harrowing set of events affecting the applicant. The decision referred to the applicant's convictions in 2018
in these terms:

“… [they] took place after your escape from the traffickers and it is considered that you acted willingly and
accepted responsibility for your actions.”

25 It is this decision which forms the cornerstone of the applicant's case before us. Self-evidently, the
decision in February 2021 was not available in 2018. Some reliance is also placed on two other reports.
Dr Wiley, a community paediatrician, examined the applicant in May 2017. She observed an avulsed nail
on the applicant's middle finger. She did not link this to the applicant's account of having been trafficked
but it is said that it certainly is consistent with that account.

26 On 4 October 2018, a nurse, named Jane Bradshaw, examined the applicant. This was in the course
of the trial at Preston Crown Court. It was an examination conducted at the behest of the solicitors then
representing the applicant. Ms Bradshaw found scarring on the applicant's hand and thigh which may have
been caused by a sharp instrument. The scars were not recent. The avulsed nail “may have been caused
by a traumatic injury”.

27 These reports were available at the time of the hearings in the Crown Court at Preston. Ms Bradshaw's
report was obtained for the purpose of those proceedings. Neither was placed before the sentencing
judge. We have already explained the difficulty which faced the applicant's then counsel in relation to the
whole issue of trafficking.

28 The first question for us is whether we should grant the application to extend time for applying for leave
to appeal. The applicant's current representatives received the positive conclusive grounds decision on 24
February 2021. We consider that the chronology from that point, which we do not propose to rehearse in
detail, does disclose a relatively leisurely approach to progressing an appeal that was already two years
out of time. For instance, there was an unexplained three-month hiatus in the summer of 2021 before
counsel, who acted in 2018, was asked for his comments. It is to be noted that counsel who was so asked
responded within twenty-four hours of the request. We certainly would not refuse an extension of time on
this ground alone but it is a relevant factor.

29 Of greater significance is the principle that an extension of time will be granted if it is in the interests of
justice to do so. Put another way, we must ask if the applicant would suffer a significant injustice were we
not to extend time The basis upon which it is said that we should interfere with the sentence imposed is


-----

that there was a mitigating factor which was not placed before the judge.  Had it been, it would at the very
least have reduced the length of the sentence. However, the sentence has been served and served some
time ago. Mr Douglas-Jones argues that the injustice here is the stigma of a custodial sentence. We are
doubtful as to whether in real terms there is true injustice in this case. Nonetheless, we consider that the
better course is for us to consider the proposed grounds on their substantive merits. If they disclose
compelling support for the proposition that the sentences imposed were manifestly excessive, that will be a
factor which requires us to extend time. Conversely, if there are no substantive merits then there would be
no proper basis to do so.

30 We should say at this point that we do not propose to receive the evidence of Dr Wiley or Jane
Bradshaw. It was available at the time of the sentencing hearing. There is, in our view, no reasonable
excuse for the failure to rely on it. We understand the explanation given by counsel but it is not an
explanation which justifies us receiving the evidence now. In any event, taken on its own, it would not have
made any difference to the sentences imposed. For more than one reason, the requirements of s.23 of the
Criminal Appeal Act 1968 are not met in relation to this evidence. But that evidence is only tangential to
this application. It is the evidence of the positive conclusive grounds decision of February 2021 which is
crucial and which was not available at the time of the sentencing hearing.

31 The issue is whether the matters set out in the decision would have led to a substantial reduction in the
sentences imposed. We do not consider it necessary to hear evidence from the applicant, namely to
determine whether we should depart from the conclusions in the 2021 decision. We are content to proceed
on the basis that those conclusions are and were well-founded, notwithstanding the inconsistency between
the account given by the applicant in 2017 and her later witness statement. The conclusive grounds
decision expressly abjured any link between the applicant's traffic status and her offending in 2018. In
2018, the applicant was acting with her sister and her sister's boyfriend in a criminal enterprise and she did
so willingly. Those are the express terms of the decision.

32 In that context, the respondent cites L [2013] 2 Cr App R 23 [33]. Indeed, Mr Douglas-Jones drew our
attention to the same passage, in which Judge LJ (as he then was) said this:

“In some cases the facts will indeed show that he [a reference to the trafficked person] was under levels of
compulsion which mean that, in reality, culpability was extinguished. If so, when such cases are
prosecuted, an abuse of process submission is likely to succeed. That is the test we have applied in these
appeals. In other cases, more likely in the case of a defendant who is no longer a child, culpability may be
diminished but nevertheless be significant. For these individuals prosecution may well be appropriate, with
due allowance to be made in the sentencing decision for their diminished culpability. In yet other cases, the
fact that the defendant was a victim of trafficking will provide no more than a colourable excuse for
criminality which is unconnected to and does not arise from their victimisation. In such cases an abuse of
process submission would fail.”

33 Clearly that passage was concerned with the type of case in which the prosecution would, or would not,
consider whether it was appropriate to prosecute at all. However, as is clear, the reference to “a
colourable excuse for criminality” has substantial relevance to the sentencing decision.

34 In our judgment, the material now available, notwithstanding the arguments of Mr Douglas-Jones,
would not have made any significant difference to the sentences imposed. First, the prosecution made
specific reference to the lack of evidence that the applicant had been trafficked. However, the judge did
not make a finding. Effectively the position was left neutral. Thus, this is not a case in which the judge
sentenced on the express basis that the applicant had not been trafficked. It simply was left out of
account.

35 Second, when sentencing the judge did take into account the applicant's age and immaturity. He
referred to the basis of plea, which included a reference to trafficking.

36 Third, the judge gave substantial discount for the clear and obvious fact that the applicant was the
mother of a very young child and had been separated from the child, and would continue to be so. That
led to what one might regard as a very generous reduction in the sentence.


-----

37 Taking all those matters into account, we conclude that, given the lack of any apparent coercion or
exploitation at the time of the offending, our conclusion is the judge would not have reduced the sentences
any further or, if he would have done, it would have not been to any appreciable extent.

38 Mr Douglas-Jones argues that there was a real nexus between the trafficking and the offending. The
applicant was under enduring compulsion. The only safe place she had was with her sister. With great
respect to Mr Douglas-Jones, we reject that argument. In April 2017 the applicant approached the police.
Her sister and her sister's boyfriend, on the evidence, were engaged in a substantial conspiracy at some
point later in 2017, certainly in early 2018. This applicant was charged with involvement in that criminal
activity but was not convicted of it and we must proceed on the basis that she was not involved. Her
involvement came at a later point when her sister, and her sister's boyfriend, were in custody. It was the
fact they were in custody that led to the offending. In those circumstances, it seems to us that enduring
compulsion had nothing to do with it, much as the SCA's decision set out.

39 It follows that we do not consider that any substantive appeal has any prospect of success. In those
circumstances, it is not in the interests of justice to extend time and we, therefore, refuse that application.

40 We deal finally with the issue of anonymity. An interim order was made so that the applicant's name
was anonymised for this hearing. We have considered the guidance of the Vice-President of the Court of
Appeal (Criminal Division) at paras.[9]-[15] of _R v L and R v N_ _[[2017] EWCA Crim 2129. In criminal](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RB1-V161-F0JY-C314-00000-00&context=1519360)_
proceedings the starting point is the importance of the principle of open justice and anonymity orders can
and will be made but they must be justified as being strictly necessary.

41 There are two important considerations in relation to anonymity which are relevant to this case. First,
cases involving asylum or international protection issues in the context of tribunal proceedings or civil
proceedings, particularly in the Court of Appeal (Civil Division), generally will be anonymised. There is an
argument that consistency would suggest that the same approach should be taken in criminal cases.
However, against that, as we say, must be set the principle of open justice.

42 Second, those who have been the victims of trafficking may be the subject of reprisals, either because
they have actively cooperated with the authorities or their complaint has identified those by whom they
have been trafficked, and that will be of particular significance where the trafficking is linked to the
offending.

43 In this instance, the matters set out in the applicant's statement do not, in our judgment, lead to any
real risk of reprisal. None is suggested in any evidence we have seen. This is certainly not a case in
which the applicant has given information about her traffickers to the police. As we have found, she did not
commit these offences in the context of being trafficked.

44 In all the circumstances, we do not consider that this is a case in which anonymity is required. We do
not consider that the principle of open justice is overcome.

45 We should mention for completeness the proposition that was put to us that this applicant was the
subject of sexual offences and, therefore, would be subject to protection anyway. The provisions of the
1992 Act are intended to protect those where the offence that has been committed against them is a
sexual offence. Plainly by implication, some form of parallel protection might be sought. But given the
overall circumstances of this case, we are not satisfied that this is a proper case for anonymity and
therefore the case will be reported in the ordinary way.

__________

**CERTIFICATE        Opus 2 International Limited hereby certifies that the above is an**
accurate and complete record of the Judgment or part thereof.Transcribed by Opus 2 International LimitedOfficial
_Court Reporters and Audio Transcribers5 New Street Square, London, EC4A 3BFTel: 020 7831 5627   Fax:_
**_020 7831 7737civil@opus2.digitalThis transcript has been approved by the Judge_**

**CERTIFICATE**


-----

Opus 2 International Limited hereby certifies that the above is an accurate and complete record of the
Judgment or part thereof.

_Transcribed by Opus 2 International Limited_

_Official Court Reporters and Audio Transcribers_

**_5 New Street Square, London, EC4A 3BF_** **_Tel: 020 7831 5627_**
**_Fax: 020 7831 7737_**

**_civil@opus2.digital_**

This transcript has been approved by the Judge

**End of Document**


-----

