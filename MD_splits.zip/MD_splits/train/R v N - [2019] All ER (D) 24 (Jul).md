# R v N [2019] All ER (D) 24 (Jul)

[2019] EWCA Crim 984

Court of Appeal, Criminal Division

EnglandandWales

Nicola Davies LJ, Martin Spencer and Swift JJ

7 June 2019

**Criminal law – Victim of trafficking – Unsafe conviction**
Abstract

_A fair decision based on the facts of a conclusive grounds decision which should have been made and the evidence_
_[upon which it would have been based would be that a defence pursuant to s 45 of the Modern Slavery Act 2015](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)_
_would probably succeed. Accordingly, the Court of Appeal, Criminal Division, allowed the defendant's appeal_
_against conviction for production of a Class B drug (cannabis) and quashed the conviction._
Digest

The judgment is available at: [2019] EWCA Crim 984

**Background**

The defendant pleaded guilty to one count of production of a Class B drug (cannabis) and was sentenced to four
months' imprisonment. He appealed against conviction.

**Issues and decisions**

Whether the conviction was unsafe because, as a victim of trafficking (VOT), the defendant ought not to have been
prosecuted for the offence and, had the issue been raised, it would have been appropriate for the trial judge to stay
the proceedings as an abuse of process.

The principles to be derived from previous decisions of the court were, first, neither art 26 of the Council of Europe
[Convention on Action against Trafficking in Human Beings, nor art 8 of Directive (EU) 2011/36 conferred a blanket](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9X13-GXFD-80CM-00000-00&context=1519360)
immunity from prosecution on VOTs.

Second, instead, the UK's international obligations required the careful and fact sensitive exercise by prosecutors of
their discretion as to whether it was in the public interest to prosecute a VOT. That discretion was vested in the
prosecutor, not the court.

Third, the decisions of the First-tier Tribunal (Immigration and Asylum Chamber) and the competent authority as to
whether an individual was a VOT did not bind prosecutors or the court, but would be respected (subject to
submissions as to their basis or limitations), unless there was a good reason not to follow them.

Fourth, there was no closed list of factors bearing on the prosecutor's discretion to proceed against a VOT.
Generalisation was best avoided. That said, factors obviously impacting on the discretion to prosecute went to the
nexus between the crime committed by the defendant and the trafficking. If there was no reasonable nexus


-----

between the offence and the trafficking then, generally, there was no reason why (on trafficking grounds) the
prosecution should not proceed. If there was a nexus, in some cases the levels of compulsion would be such that it
would not be in the public interest for the prosecution to proceed. In other cases, it would be necessary to consider
whether the compulsion had been continuing and what, if any, reasonable alternatives had been available to the
VOT. There would be cases where a decision to prosecute would be justified, but due allowance could be made for
mitigating factors at the sentencing stage (see [20] of the judgment).

Given the defendant's presence in a house containing so many cannabis plants, for which he had provided no
explanation when interviewed, there had been a proper evidential basis to warrant charging him. Prior to his
appearance in the Crown Court, there had been no information available to the prosecution which could or should
have raised a concern that the defendant could be a VOT. There had been no grounds which would have warranted
referral to an appropriate agency because those who had arrested the defendant – and thereafter, the prosecution
– had been given no information to alert them to such an issue. In the circumstances, there were no grounds to
challenge the original decision of the prosecution to prosecute (see [36] of the judgment).

The information placed before the court had been sufficient to raise an issue that the defendant had been a
possible credible VOT. That should have been apparent to the defendant's advocate, the representative of the
prosecution and the judge. It would have been open to the judge to raise the issue. He had not done so. However,
the CPS Legal Guidance on Human Trafficking, Smuggling and Slavery expressly provided for the situation. Had
the guidance been followed, as it should have been, the prosecutor should have sought an adjournment to ensure
that the steps set out in the relevant section of the guidance, namely, the duty to make proper enquiries and to refer
through the national referral mechanism, should have taken place. Had that been done, it was reasonable to
conclude that the referral would have resulted in the conclusive grounds decision, that the applicant was a victim of
human slavery (see [40] of the judgment).

[In applying the s 45(1)(d) of the Modern Slavery Act 2015 test, account had to be taken of the reasonable person](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)
in the same situation as the applicant and having the applicant's relevant characteristics, as a result of which he
had no realistic alternative but to do the act. The factual position, as found by the conclusive decision, was that for a
short time, the defendant had had no travel documents; he had had a history of being beaten by traffickers following
his earlier escape in another country; he had been in a new country; and he had had no contact with any persons
other than those involved with the traffickers. The prosecution's submission that, in those circumstances, s 45(1)(d)
was not met, failed to appreciate the reality of the defendant's situation, and his circumstances, which included his
history at the hands of the traffickers in other countries and resultant fears (see [43] of the judgment).

Were appropriate weight to be given to those facts, as contained in the conclusive decision, a decision would or
should have been made that the defence pursuant to s 45 would probably succeed. No public interest consideration
would outweigh such a determination (see [44] of the judgment).

Following the appropriate guidance at the time, the defendant's case should have been adjourned for referral to the
national referral mechanism. Following the conclusive decision, a fair decision based on the facts of that decision
and the evidence upon which it would have been based would be that a defence pursuant to s 45 would probably
succeed. In the circumstances, the conviction could not be regarded as safe (see [45] of the judgment).

Accordingly, the appeal would be allowed. The defendant's conviction was unsafe and would be quashed (see [46]
of the judgment).

_R v GS_ _[[2018] All ER (D) 90 (Aug) considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T28-JYB1-DYBP-N2GW-00000-00&context=1519360)_

Benjamin Newton for the defendant.

James Marsland for the Crown.
Karina Weller - Solicitor (NSW) (non-practising).


-----

**End of Document**


-----

