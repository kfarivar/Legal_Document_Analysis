# Independent Workers Union of Great Britain v Central Arbitration Committee

 [2018] EWHC 1939 (ADMIN)

QBD, ADMINISTRATIVE COURT

CO/810/2018

MRS JUSTICE SIMLER DBE

Friday, 15 June 2018

15/06/2018

IN THE HIGH COURT OF JUSTICE
QUEEN'S BENCH DIVISION
THE ADMINISTRATIVE COURT

J U D G M E N T

MRS JUSTICE SIMLER DBE:

1 This is a renewed application for permission to apply for judicial review. The application was listed for a

30‑minute hearing in the ordinary way. That time estimate was patently inadequate. It was inadequate to

accommodate the submissions the claimant wished to make and became all the more inadequate when it was clear
that the interested party wished to be heard as well.  It is regrettable that the parties did nothing to address that
problem and that neither side applied for a longer hearing. Nonetheless, I heard the application in court 37 on
Tuesday but was unable to give judgment immediately because of other urgent applications awaiting hearing that
day.

2 Today is the first opportunity I have had to accommodate giving this judgment whilst also affording the parties
and the press some notice of it.

3 Following the hearing on Tuesday and the Supreme Court's judgment in _Pimlico Plumbers Ltd v Smith_ _[2018]_
_UKSC 29, the parties made written submissions. I have considered those submissions in reaching my conclusions._

4 The claimant, the Independent Workers Union of Great Britain, is a trade union wishing to be recognised by
Deliveroo under the _[Trade Union and Labour Relations (Consolidation) Act 1992 ("the 1992 Act") for collective](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6180-TWPY-Y0XF-00000-00&context=1519360)_
bargaining purposes in respect of a group of delivery riders. Unions can seek recognition from employers, pursuant
to s.70A and Sch.1 of the 1992 Act in respect of individuals who are workers, as defined by s.196(1) of the 1992
Act.

5 Following a hearing by the Central Arbitration Committee ("the CAC") by a decision dated 14 November 2017,
and subsequently revised on 20 November 2017, the CAC found that the riders in the proposed bargaining unit
were not workers. As the grounds for judicial review state at paragraph7:

"The basis for this conclusion was the finding by the CAC that the substitution clause at cl.8 of the new contract of
11 May 2017 was genuine and operated in practice so that in consequence the riders were not obliged to provide


-----

personal service, a necessary ingredient of the definition of worker in s.296. Thus they did not qualify as limb (b)
workers and were not eligible to be the subject of a recognition claim."

6 The claimant seeks to challenge that conclusion by this application for judicial review. Permission was refused
by Butcher J on the papers. He concluded that the attack on the CAC's decision is essentially a challenge to its
findings of fact that the substitution right was genuine and operated in practice and that determination of fact is not
susceptible to judicial review.

7 The critical statutory provision in issue is s.296(1) of the 1992 Act. This sets out the definition of "worker" as
follows:

"(1) In this Act worker means an individual who works, or normally works or seeks to work—

(a) under a contract of employment, or

(b) under any other contract whereby he undertakes to do or perform personally any work or services for another
party to the contract who is not a professional client of his, or …”

8 The claimant sought to rely on the definition of worker in s.296(1)(b); referred to as the limb (b) definition. That

definition is similar to the definitions of "worker" in other employment rights‑based legislation including the

_[Employment Rights Act 1996, s.230(3)(b), and s.83(2) of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60V0-TWPY-Y0P0-00000-00&context=1519360)_ _[Equality Act 2010; but it is not identical to those](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_
definitions.  The CAC did not regard the difference as material and, in line with the well-established approach to
limb (b) worker status cases, proceeded on the footing that to fall within limb (b) an individual must work under a
contract whereby he or she undertakes personally to perform work or services for another party so that the critical
issue for the CAC was whether under the new contract riders undertook to perform personally. That, as the CAC

held, broke down into two sub‑issues: first, whether there was an obligation to perform work and, secondly, the

question of personal service.

9 It was common ground before the CAC (and before me) that whether a person undertakes personally to perform
work or services depends entirely on the contract between the parties and that the essential question in each case
is: what were the terms (whether in writing, oral or both) of the agreement? Further, bearing in mind that the
approach to the construction of agreements in the work context should recognise that the parties to such
agreements do not have equal bargaining power, the task is to find the true agreement or the actual legal
obligations of the parties as a matter of substance and not merely as a matter of form or labelling. Consequently, in
order to carry out the exercise of discovering the actual legal obligations of the parties in terms of personal service,

the fact‑finding tribunal examines all relevant evidence, including the written agreement and the way in which the

parties conducted themselves in practice.

10 The CAC heard this case over four days. At paragraphs 29 and 30 it identified the witnesses of fact heard on
both sides. These were numerous. At paragraph 51 onwards it dealt with the written agreements between the
parties and in particular the new contracts that had recently been introduced. The parties agreed that the CAC
should consider the question of worker status by reference to the new contracts rather than any earlier ones.

11 The CAC found that the new contracts were issued on 11 May 2017 with a covering letter addressed to the
riders which specifically drew attention to the substitution clause, explaining to riders that they could appoint
another person to work on their behalf with Deliveroo at any time and that a substitute working for the rider could
log in using the rider's own phone or app details. The covering letter also informed riders that they could work for
other companies including competitors; and that they could choose and wear whatever kit they wished to wear
when riding for Deliveroo (see paragraphs54 and 55).

12 As to the new contract itself, cl.2 (as the CAC set out at paragraph 56) provides that the rider is:

"not obliged to do any work for Deliveroo, nor is Deliveroo obliged to make any work available to you. Throughout
the term of this Agreement you are free to work for any other party including competitors of Deliveroo."


-----

At clause 2.4 the contract read:

"It is entirely up to you whether, when and where you log in to perform deliveries, save that it must be in an area in
which Deliveroo operates and at a time when that area is open for deliveries."

At clause 2.51 the contract read:

"While logged into the App, you can decide whether to accept or reject any order offered to you and if you do not
wish to receive offers of work at any time, you can use the 'unavailable' status."

13 At paragraphs 58 and 59, the CAC referred to the warranties to be given by riders under the new contract as a
"strict condition of the New Contract". Those warranties related to rights to residency and work, not having any

unspent convictions, complying with all legal obligations and obtaining third‑party liability insurance for themselves.

In relation to insurance, the new contract states, "any substitute appointed by you need not have their own
insurance so long as they are covered under your insurance".

14  The CAC dealt with other clauses at paragraphs 60‑64. Significantly, it dealt with the substitution clause, cl.8 of

the new contract, which recognised a right to appoint a substitute in the following terms:

"8.1 Deliveroo recognises that there may be circumstances in which you may wish to engage others to provide the
Services. Deliveroo is not prescriptive about this and you therefore have the right, without the need to obtain
Deliveroo's prior approval, to arrange for another courier to provide the Services (in whole or in part) on your behalf.
This can include provision of the Services by others who are employed or engage directly by you; however, it may
not include an individual who has previously had their Supplier Agreement terminated by Deliveroo for a serious or
material breach of contract or who (while acting as a substitute, whether for you or a third party) has engaged in
conduct which would have provided grounds for termination had they been a direct party to a Supplier Agreement.
If your substitute uses a different vehicle type to you, you must notify Deliveroo in advance.

8.2 It is your responsibility to ensure your substitute(s) have the requisite skills and training, and to procure that they
provide the warranties at clause 5 above to you for your benefit and for Deliveroo's benefit. In such event you
acknowledge that this will be a private arrangement between you and that individual and you will continue to bear
full responsibility for ensuring that all obligations under this Agreement are met. All acts and omissions of the
substitute shall be treated as though those acts and/or omissions were your own. You shall be wholly responsible
for the payment to and remuneration of any substitute at such rate and under such terms as you may agree with
that substitute, subject only to the obligations set out in this Agreement, and the normal invoicing arrangements as
set out in this Agreement between you and Deliveroo will continue to apply."

15 Having set out the clause and dealt with the terms of the contract between the parties, the CAC dealt with the

conduct of the parties in practice at paragraphs 66‑75 and with the way in which the substitution clause worked in

practice at paragraphs 76‑85. It is apparent from the CAC's decision that the CAC was acutely aware of the

infrequency of substitution in practice (see, for example, findings at paragraphs 76, 78, 79 and 81) and its ultimate
conclusions were plainly reached in light of this and the other findings of fact it made.

16 The CAC recognised that the starting point of its consideration of worker status was the terms of the new
contract which contained all the contractual terms between the parties. This was not accordingly a case where
terms had to be discovered from a raft of different materials or manuals or from things said and done in the course
of the relationship.

17 The CAC's central conclusions on this issue are at paragraphs 100‑102 where it held that the central and

insuperable difficulty for the claimant is the finding that the substitution right was genuine in the sense that
Deliveroo had decided in the new contract that riders should have a right to substitute themselves "both before and
after they have accepted a particular job" and the evidence that this was operated in practice.


-----

18 In light of that central conclusion, the CAC concluded that it could not be said that the riders undertook to do
personally any work or services for Deliveroo. This was fatal to the claimant's claim. The CAC found that "riders
are free to substitute at will," recognising the lack of incentive for doing so but concluding that this did not make the
substitution provisions a sham and that the factual situation in this case was very different from that which obtained
in cases like Uber (relating to private hire drivers) or CitySprint.

19 Having reached those conclusions, at paragraph 103, the CAC regarded it as unnecessary to dissect other
features of the contractual relationship. It dealt briefly with the regulatory regime relied on by the claimant as
undermining the substitution clause, concluding that it did not do so. Finally, at paragraph 104 in relation to the
Art.11 and s.3 Human Rights Act 1998 arguments advanced by the claimant, the CAC held:

"… on the specific facts of this case and the unfettered and genuine right of substitution that operates both in the

written contract and in practice, the argument does not succeed. In a less clear‑cut case the position might have

been different."

20 Against that background, I turn to consider the individual grounds advanced by Mr Hendy QC on behalf of the
claimant bearing in mind that at this stage I am concerned to determine only whether the application raises
arguable grounds for judicial review.

21 Ground 1 challenges the CAC's decision on the basis that it erred in its construction of the substitution clause at
cl.8 of the new contract. Particular reliance is placed on the conditions imposed by both cl.8.1 and cl.8.2 said to
operate so as to qualify and/or constrain the right to use a substitute. First, the substitute may not be an individual
who has previously had their supplier agreement terminated by Deliveroo for a serious or material breach or who
has engaged in conduct which would have provided grounds for termination had they been a direct party to a
supplier agreement (referred to in argument as the "bad egg" provision). Secondly, cl.8.2 makes riders responsible
for ensuring that any substitute has the requisite skills and training, the right to reside and work in the UK, no
unspent convictions for criminal offences and complies with all other legal obligations which apply from time to time,
including those contained in the Highway Code. Thirdly, there are other conditions imposed by cl.6, for example, in
relation to insurance, cl.11 in relation to password protection, and cl.12 in relation to ensuring that any substitute
[complies with the provisions of the Modern Slavery Act 2015.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)

22 Mr Hendy submits that in reaching the conclusion that the contractual substitution clause was genuine and
operated in practice, the CAC erred in failing to consider whether the term reflected the reality of the agreement
between Deliveroo and the riders, given the imbalance in bargaining power between the two. It was not enough to
consider simply whether substitutes could be procured. It was incumbent on the CAC to consider whether the
constraints imposed by the contract (as reflected above) on the exercise of the power to substitute did in fact reflect
the reality.

23 Mr Hendy relies on the fact that the few examples of purported substitution given in evidence reflected no
evidence whatever that those conditions were ever fulfilled or were ever intended to be fulfilled and submits that the
CAC did not consider whether the evidence of substitution was of riders exercising the power to do so under the
new contract or regardless of what the contractual terms were. That, together with the rarity of substitution
occurring in practice and the practical implications of multiple riders engaging substitutes at the same time, which
would result in Deliveroo losing control over the operation and rendering it unable to service its promise to
customers, should have been addressed and would have led to the conclusion that the clause did not reflect the
reality of the agreement between the parties. Mr Hendy submits in writing that the decision of the Supreme Court in
_Pimlico Plumbers strengthens and fortifies those arguments._

24 I do not consider that this ground raises any arguable error of law. As Lord Wilson made clear at paragraph 32
of Pimlico Plumbers:

"The sole test is, of course, the obligation of personal performance; any other so‑called sole test would be an

inappropriate usurpation of the sole test."


-----

That reflects the statutory language which expressly requires an individual to have undertaken by the contract to
perform personally the work or services in order to qualify as a limb (b) worker. In the _Pimlico Plumbers case,_
where the contracts in question gave Mr Smith, the plumber, no express right to appoint substitutes to do his work,
the Supreme Court held that the tribunal found and was entitled to find that Mr Smith had a limited facility to
substitute by arranging, having accepted a job, for another Pimlico operative to do the work, so that there was no
unfettered right to substitute at will (see paragraphs 25 and 27). Accordingly, at paragraph 28, Lord Wilson said
that the question becomes whether such a limited right to substitute only to another Pimlico operative in the context
of that case was inconsistent with an obligation of personal performance.

25 The approach to the question of worker status accordingly remains that the contractual terms are the critical
starting point and that an obligation of personal performance is the sole test and is required. A right to substitute
may be inconsistent with personal performance but is not necessarily so. Where the right to substitute is
significantly limited, it is unlikely to be inconsistent with the obligation of personal performance. On the other hand,
however, a general right of substitution in which the employer party is uninterested in the identity of the substitute
provided, only that the work gets done, will negate an obligation of personal service.

26 In this case, unlike in Pimlico Plumbers, there is an express contractual right writ large in cl.8 and drawn to the
attention of riders. Clause 8 permits substitution to anyone who does not fall within the "bad egg" exception. As the
CAC held at paragraph 101, the riders could "either do it themselves in accordance with the contractual standard,
or get someone else to do it". That someone else did not have to be another Deliveroo rider but could be anyone
save for bad eggs. Again, at paragraph 102, the CAC held:

"The delivery has to be undertaken by a person; however it does not have to be the Rider that personally performs
it: Riders are free to substitute at will."

27 That wide power of substitution meant that Deliveroo had no assurance as to who was making deliveries.
Again, as the CAC observed at paragraph 78 in the context of dealing with specific evidence about riders who go on
holiday and lend the device to a friend who then substitutes:

"Deliveroo will not be aware of the identity of the substitute, or the fact that one has been used on any particular
occasion."

28 Clause 8.2 of the contract and the other conditions relied on by Mr Hendy in this ground, which makes it the
rider's responsibility to ensure that any substitute has the requisite skills and to procure the warranties, etc., does
not fetter the right to substitute or limit the wide power to do so. Rather, the conditions in cl.8.2 and elsewhere
operate to ensure that the substitute chosen is as qualified as the rider to do the work. In practice and in the
context of the work in issue in this case (riding a bike to effect food deliveries) this is a large pool of eligible people
that no doubt includes most riders for Deliveroo's competitors and many others beyond.

29 In contrast to the situation in _Pimlico Plumbers, the contractual obligations addressed to the riders under the_
new contracts can be read across to the substitutes. The CAC recognised the high degree of trust required in the
substitute by a rider, both because the substitute has to have either the rider's phone or Deliveroo password to
download the rider's app onto his or her phone, and "because of the contractual commitments borne by the rider on
behalf of the substitute" (see paragraph 102). The CAC expressly considered these provisions but concluded that
they did not undermine the right to substitute as a matter of contractual right and in practice; ultimately concluding,
at paragraph 103 that:

"By allowing an almost unfettered right of substitution, Deliveroo loses visibility, and therefore assurance over who
is delivering services in its name, thereby creating a reputational risk... but that is a matter for them."

At paragraph 104 on the specific facts of this case the CAC concluded there was an "unfettered and genuine right
of substitution that operates both in the written contract and in practice..."


-----

30 It is not arguable that in reaching those conclusions, the CAC misconstrued cl.8 of the contract. Express and
careful consideration was given to cl.8. Further, the conclusions I have just summarised were open on the
evidence and as a matter of law. The contrary is not arguable in my judgment.

31 Moreover, in reaching those conclusions, it is clear that the CAC conducted a careful examination of the
evidence from a position of being properly sceptical, recognising the problem identified by Elias LJ (as the then
was) in earlier cases, of "armies of lawyers" creating a substitution clause to alter the true substance of the
relationship.  The CAC took particular care because of what it described as “the substitution conundrum” (see
paragraph 98), namely what was the point of a rider using a substitute when he could simply switch off the app and
why would Deliveroo permit it as a matter of commercial good sense.

32 It seems to me in this case, unlike other worker status cases including Pimlico Plumbers, there was a clear and
widely drawn written substitution clause in the new contracts, albeit with the conditions to which Mr Hendy refers.
The clause was drawn to the attention of all riders. It was operated in practice. It applied even after a delivery had
been accepted and throughout the delivery journey. The infrequency of use of a substitute expressly recognised by
the CAC was rightly viewed in the context of the rider's own obligations under the contract: in particular, the fact that
the rider was under no obligation to accept a job or be available for work; under no obligation to log onto the app;
and if logged on, under no obligation to make themselves available. Further, if logged on and marked as available,
the rider was under no obligation to accept a job offered (see paragraph 76). There was no sanction or adverse
consequence for the rider who took any of those steps for example failing to log on or be available. Importantly,
riders were free to work for Deliveroo's competitors at the same time as having the Deliveroo app open. The CAC
had all these factors in mind and made no error of law in relying on them.

33 As to the argument based on separate contracts for each delivery, I do not consider that this point can arguably
assist the claimant, given the CAC's finding that the right of substitution applied even after a delivery had been
accepted (paragraphs 81, 100 and 101.) The fact that there was no obligation on a rider to accept an order in the
first place means that the contractual right of substitution must, as a matter of construction, cover the case where a
delivery has in fact been accepted.

34 For the same reasons as those I have just given in relation to ground 1, I do not consider that ground 5 is
arguable. Ground 5 contends that the CAC erred in its interpretation of the limb (b) worker personal service
requirement; but the statutory requirement of personal service is express and both the Court of Appeal and now the
Supreme Court in _Pimlico Plumbers have confirmed that the contractual obligation of personal service may be_
defeated by a substitution clause that is inconsistent with such an obligation, and will be defeated by a generalised
right of substitution.

35 Ground 2 contends that the CAC erred in its consideration of the relevant regulatory regime. Mr Hendy submits
that the law presumes that a contractual clause will be operated lawfully in compliance with applicable statutory
duties and any applicable regulatory regime. Here he contends that if a substitute is engaged, in addition to there
being no evidence that the warranties in cl.5 were ever obtained by riders in respect of substitutes, Deliveroo had
no way of ensuring that its own statutory obligations were fulfilled. He argues that the CAC's approach to this issue
was in error of law because the CAC should have concluded that Deliveroo's unexplained indifference to
compliance with these obligations can only lawfully have been based on the fact that the substitution clause did not
reflect the reality of the agreement.

36 Again, I do not consider this ground to be arguable. The CAC expressly considered the regulatory regime. It
registered its concerns. However, ultimately it concluded that concerns in relation to compliance with that regime
did not affect its finding that the substitution clause was genuine and was operated in practice. While it is clear that
the regulatory regime can and often does form part of the factual matrix for determining worker status in any
particular case, as HHJ Eady QC held in Uber v Aslam UKEATT/0056/17/DA, the weight to be attached to such a
factor is supremely a matter for the fact-finding tribunal, here the CAC. It addressed this issue squarely but was not
persuaded that the risks raised by reference to the food hygiene and health and safety regulatory regime cast doubt
on the evidence given by Deliveroo witnesses that it accepted, or rendered the right of substitution not genuine or
unreal.


-----

37 As the CAC explained at paragraph 103, if by allowing an almost unfettered right of substitution. Deliveroo lost
visibility and assurance over who was delivering services in its name, that might create a reputational risk and
potentially a regulatory risk, but that did not mean that the substitution clause is not a genuine one in the specific
circumstances and facts of this case. Again, that was a conclusion open to the CAC in light of the evidence and the
facts found, and I cannot see that any arguable error of law arises from it.

38 Ground 3 raises a point of construction and contends that the CAC erred in its interpretation of s.296(1)(b) of
the 1992 Act. Here Mr Hendy relies on what he describes as a key distinction between that provision and the sister
provision in s.230(3)(b) of the Employment Rights Act 1996; namely that "worker" for the purposes of s.296(1) is an
individual who works or "normally works" under a contract for personal services whereas “normally works” is not
found in s.230(3)(b). Mr Hendy submits that the limited examples of substitution, such as they were, showed that
for most riders, substitution was unrealistic and did not reflect the reality of the new contracts. Even on the findings
of the CAC, the evidence demonstrated that the workforce did "normally work" by way of personal service, thus
satisfying the definition of personal service under s.296 of the 1992 Act. The CAC therefore erred in failing to find
that this was so and erred in holding at paragraph 103 that the facts of this case did not require a more detailed
analysis of the subtle differences in the limb (b) worker definition as between the 1992 Act and the other

employment rights‑based definitions to which I have referred.

39 This ground is also not arguable. The phrase in s.296(1) of the 1992 Act, "normally work", cannot be isolated in
the way the claimant seeks to isolate it. It must be read in the context of the section as a whole. The focus of the
provision is on the contract under which the work is done and not simply on whether the work is done or the way the
work is done. To qualify on a plain reading of s.296(1)(b) the contract under which riders "normally work" must be a
contract by which they promise (or undertake) to do the work personally. In other words, the focus is on what the
contract requires and whether it requires personal service. If, as the CAC found, the contract does not oblige the
rider to work personally, it is irrelevant as a matter of construction of s.296(1)(b) whether he normally uses a
substitute or not.

40 Mr Hendy contends that this gives no meaning to the word "normally" in the phrase "normally work". I disagree
and consider, as Mr Jeans QC contends, that the words "normally work" are there because a person can work
under two or more different contracts and the contract that should be looked at is the one under which he normally
works. Moreover, if Mr Hendy were right on his construction, the statute need only have said a worker is a person
who normally works. That is not what is provided for, and the construction advanced under this ground is simply
not arguable in my judgment.

41 For all these reasons, grounds 1 to 3 and 5 fail to raise arguable errors of law as grounds for judicial review and
may not proceed.

42 With some hesitation I have reached a different conclusion in relation to ground 4, which argues that the
collective bargaining rights in Art.11 require an interpretation of s.296(1) and the personal performance obligation
hat does not exclude these riders from exercising those rights. The CAC did not engage with this argument
because of its factual findings, but arguably the point required to be addressed as a matter of principle, irrespective
of the strength of the facts of the particular case. In relation to this ground, therefore, I am persuaded that it merits
fuller consideration and have concluded that permission should be granted in relation to ground 4. In those
circumstances, the less said about this ground perhaps the better, and I leave further analysis of the arguments to
another day.

43 The result is that save in relation to ground 4 which is permitted to proceed, the remaining grounds may not do
so.

That leaves the question of cost capping, and the costs order in light of this judgment. It seems to me that probably
costs must now be costs in the judicial review.

MR HENDY: Yes. That must be right.


-----

MRS JUSTICE SIMLER: So the costs order made by Butcher J will be set aside and costs of this hearing will be
costs in the judicial review.

Does either of you want to say anything more about cost capping?

MR HENDY: My Lady, I don't. We've made our submissions in writing and don't want to take up more of your
Ladyship's time.

MR JEANS: Same here.

MRS JUSTICE SIMLER: Yes. Very well. The claimant seeks a cost capping order pursuant to CPR 46.16 limiting
or removing the liability it might have on judicial review for the interested party's costs. It contends that these are
proceedings that are public interest proceedings within the meaning of s.88(7) of the Criminal Justice and Courts
Act 2015 because the employment status of delivery riders is of common interest to hundreds of thousands of
individuals in Britain engaged in the gig economy, and the issue raises a matter of general public importance. It
submits that the proceedings are an appropriate means of determining the issues and indeed the only means of
determining them in the absence of any right of appeal from a decision of the CAC. Moreover, the claimant is the
only possible legal person who can challenge the CAC's decision.

The claimant relies on the fact that it is a small independent trade union whose members are low‑paid workers. It

has limited financial means and negligible assets and it points in contrast to the substantial resources of Deliveroo.
It says that if the cost capping order is refused, it will have no reasonable option other than to withdraw this claim.
Moreover, it is the case that the claimant's legal representatives, both solicitors and counsel, have acted pro bono
throughout, and although solicitors are no longer retained, counsel are retained on a pro bono basis.

The cost capping order is opposed by Deliveroo.

I have had regard to the factors set out in ss.89 and 89 of the Criminal Justice and Courts Act 2015 and have
concluded that the application should be refused. I am not persuaded that these are public interest proceedings.
They are proceedings brought by a trade union to secure recognition for itself, and on behalf of its members and for
their benefit. Those members pay subscriptions to the claimant for it to act as a union on their behalf in
circumstances just such as these.

Worker status cases are highly fact sensitive and a decision in one case does not and cannot apply to the facts of
an altogether different case. Here the decision of the CAC turned on the meaning and effect of specific contracts
agreed between Deliveroo and its riders. Its decision is not of common interest to all workers in the gig economy,
and turned on the application of the law to the specific facts of this particular case. Notwithstanding the fact that I
have given permission to proceed with judicial review on ground 4, I consider it unlikely that the outcome of this
case will form any sort of precedent for other companies or industries given its own stark facts. For all these
reasons, accordingly, I do not consider the issues to be ones of general public importance, still less ones that the
public interest requires to be resolved in these proceedings.

I accept that the claimant is an appropriate person to represent the interests of the riders affected by this decision
and of course, that the legal representatives are acting free of charge. It seems to me however, that there is some
evidence that the claimant has a surplus in its general fund and there are, no doubt, other avenues that can be
pursued to secure finances for this claim other than through membership fees of the union. Indeed, on 16 May
2018, the claimant launched a crowd funding appeal seeking to raise up to £50,000 to cover its costs of this
litigation and referred expressly to the permission stage and the fact that it had already been saddled with a costs

bill. The web page for that appeal stated, as at 7 June 2018, that the appeal had raised £23,000‑odd. The page

states that any money not spent would go into the claimant's fighting fund. I am therefore far from persuaded that
this claimant will be forced to withdraw if no costs capping order is made.

Finally, it seems to me that this is a case where both the claimant and its members are likely to benefit significantly
themselves if worker status is achieved and the claimant is recognised.


-----

Accordingly, for all those reasons the costs capping application is refused.

I should make case management directions, unless there is anything either of you wish to say. Is there any reason
why standard directions shouldn't apply?

MR JEANS: I don't think so. We are looking at, what, 35 days for full grounds?

MRS JUSTICE SIMLER: Yes. So the standard directions would be that the defendant and any other person
served with the claim form who wishes to contest the claim or support it on additional grounds must file and serve
detailed grounds for contesting the claim or supporting on additional grounds, and any written evidence within 35
days of service of this order.

Any reply and any application by the claimant to lodge further evidence must be lodged within 21 days of service of
the detailed grounds for contesting the claim.

Then the standard direction is for the claimant to file and serve a trial bundle not less than four weeks before the
date of the judicial review hearing.

Then for the claimant to file and serve a skeleton argument not less than 21 days before the date of the hearing.

For the defendant and any interested party to file and serve their skeleton argument not less than 14 days before
the hearing.

And for the claimant to file an agreed bundle of authorities not less than three days before the date of the hearing.

All of those are the standard directions.  Are you content that they should apply?

MR HENDY: We are Ma'am.

MRS JUSTICE SIMLER: Thank you very much. In terms of listing directions: a day?

MR HENDY: Yes.

MR JEANS: Given that we've only got the one ground, yes; I would have said so.

MR HENDY: My Lady, given the overruns that we have already had, might it not be more sensible to say a day and
a half?

MRS JUSTICE SIMLER: Well, a day and a half would certainly enable the judge, one would hope, if matters
proceed more swiftly, to give judgment.

MR HENDY: Yes.

MRS JUSTICE SIMLER: Yes. I think that is prudent.

MR HENDY: It's a matter of impression.

MRS JUSTICE SIMLER: Yes. Time estimate listed for a day and a half. I think certainly not suitable for a deputy.
It must be a High Court Judge.

MR HENDY: Yes.

MRS JUSTICE SIMLER: Are there any other considerations?

MR HENDY: Well, my Lady, I'm not sure your Ladyship can direct it, but it would be helpful if we had a judge
experienced in employment law.


-----

MRS JUSTICE SIMLER: Yes. I will include in the direction: to be listed before a High Court Judge, preferably one
with experience of employment law.

MR HENDY: Right.

MRS JUSTICE SIMLER: Is there anything else?

MR JEANS: No. Other than to thank your Ladyship for giving judgment so promptly. And can I thank your
Ladyship on behalf of all of us for the time that we have taken, knowing your Ladyship's very, very busy list.

MRS JUSTICE SIMLER: Thank you very much. Thank you both for all your assistance.

_________

Transcribed by Opus 2 International Ltd.
(Incorporating Beverley F. Nunnery & Co.)
Official Court Reporters and Audio Transcribers
5 New Street Square, London EC4A 3BF
Tel: 020 7831 5627   Fax: 020 7831 7737
admin@opus2.digital
__________
This transcript has been approved by the Judge

**End of Document**


-----

