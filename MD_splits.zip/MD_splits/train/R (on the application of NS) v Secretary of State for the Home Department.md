# R (on the application of NS) v Secretary of State for the Home Department

 [2019] EWHC 861 (Admin)

Queen's Bench Division, Administrative Court (London)

Darryl Allen QC, sitting as a Deputy High Court Judge

4 April 2019Judgment

**Samantha Knights QC (instructed by Luqmani Thompson & Partners) for the Claimant**

**Christopher Staker (instructed by Government Legal Department) for the Defendant**

JUDGMENT: APPROVED BY THE COURT FOR HANDING DOWN (SUBJECT TO EDITORIAL CORRECTIONS)

DARRYL ALLEN QC:

**Anonymity**

1. By Order of Mr Justice Morris dated 25th November 2017, pursuant to CPR 39.2, the Claimant shall be identified
only as NS.

**Introduction**

2. The Claimant is an Indonesian national. She alleges that she is a victim of human trafficking and that she was a
child at the date of the trafficking. She challenges the Defendant's Competent Authority Conclusive Grounds
decision of 12th July 2017 [“the CG Decision”] that she is not a victim of trafficking; she seeks a quashing order in
respect of that decision and a declaration that the decision was in breach of policy and law.

3. At the heart of the case is a dispute about the Claimant's age. This dispute is central to the CG Decision as the
test for the identification of a child victim of trafficking differs to that applied to an adult.

**Background: The Claimant's account**

4. The Claimant is an Indonesian national. Her evidence, disputed by the Defendant, is that she was born on 22nd
September 1990. She was born in the village of Serang Banten on the island of Merak Anyer. She states that her
father died when she was 11 years old. She attended school from the age of six but left at about 13, at which point
she went to Jakarta to work and to help to support her family.

5. The Claimant alleges that when she was about 14 years of age [circa 2004/05], an agency came to her village
seeking to recruit women to work abroad as domestic servants. The Claimant states that she wanted work and
advised the agency representative(s) of her age; she was advised that she would need a passport which showed
that she was 18 years old. Her case is that she was assisted by the agency who procured a legitimate Indonesian
passport with a false date of birth to enable her to secure work.

6. On 25th April 2006, the Claimant was issued with an Indonesian passport with a date of birth of 22nd September
1981, giving her an age of 24 as opposed to 15, which she now states was her true age [C/179].

7. The Claimant travelled to Saudi Arabia, where she worked for a family for almost two years. She says that she
as req ired to ork se en da s a eek orking er long ho rs ith breaks b t s bject to erbal ab se


-----

Notwithstanding those demands and conditions, on her return to Indonesia she accepted an offer of further work
from the same agency, this time for a family in Qatar.

8. In late 2007, the Claimant started work for the Al-Thani family in Qatar. She states she was treated badly but not
as badly as she had been treated in Saudi Arabia. In July 2008, the family travelled to the UK with the Claimant
accompanying them on a domestic worker visa. The Claimant states that she was treated very badly, that she was
not provided with any pay and she was not provided with sufficient food. She escaped from the family while she
was in London and sought help from an Indonesian woman “she met in the park one day”, who put her in touch with
Kalayaan, the charity which assisted her at that time and continues to assist her in these proceedings.

9. The Claimant reported her treatment to the police in 2008. No action was taken. She lost touch with Kalayaan
and the police. She supported herself through domestic work and without recourse to public funds. She lived with
an Indonesian woman for a period; she started a relationship and lived with a partner for approximately seven
months; she then lived with a friend and later in different places in London.

10. In August 2015, the Claimant started to suffer from back pain. She did not have a GP. She eventually attended
hospital as her back pain had become unbearable. In March 2016, she was diagnosed with TB and admitted to
hospital for treatment. By that stage, TB infection had spread to her lungs, brain, eyes, lymph nodes and spine.

11. In May 2016, the Claimant underwent major spinal surgery. She was discharged but subsequently admitted with
post-operative infection. She was finally discharged in September 2016.

12. On 24th June 2016, the Claimant came into contact with Kalayaan again. She was identified as a potential
victim of trafficking and referred by Kalayaan [acting as “First Responder”] to the National Referral Mechanism. The
referral form appears at [B138/151] and states that the Claimant was a minor and described what had happened to
her.

13. On 18th July 2016, the Defendant's Competent Authority made a positive “Reasonable Grounds” decision in the
Claimant's favour that she was a victim of trafficking.

14. On 28th November 2016, the Claimant's solicitors made detailed submissions and provided several medical
reports to the Competent Authority in support of her claim to be a victim of trafficking and for a period of leave to
remain due to her need for complex medical treatment.

15. On 19th December 2016, police officers carried out an ABE interview in the light of the Claimant's allegations of
trafficking [C184].

16. On 9th January 2017, the Medaille Trust, a trafficking support provider, provided updated medical information.

17. On 8th February 2017, the Competent Authority made a negative Conclusive Grounds Decision that the
Claimant was not a victim of trafficking [B/71-89].

18. On 10th April 2017, Kalayaan sought reconsideration of that decision and provided additional evidence in
support, including the Claimant's school diploma obtained from a relative in Indonesia [B/30-68].

19. On 12th April 2017, the Claimant received a copy of her passport and domestic worker visa from the Home
Office.

20. On 15th May 2017, Kalayaan submitted further documentation including the Claimant's original school
certificate [which is in addition to the diploma] [B30-B39].

21. On 12th July 2017, the Competent Authority made the CG Decision which is the subject of these proceedings. It
withdrew its earlier decision of 8th February 2017. Once again it made a negative decision that the Claimant was
not a victim of trafficking.

**Documentary evidence**


-----

22. A limited number of contemporaneous documents were available to the decision maker1 :

22.1. The Claimant's passport [C179] – It was accepted that this was the Claimant's. It was also accepted
that the date of birth shown on the passport was 22nd September 1981, although the Claimant disputed
that the date of birth was correct. The passport also records that the Claimant's place of birth was
“SERANG”.

22.2. The Claimant's UK domestic worker visa application [C177] – The Claimant's father [S**** N******]
and mother [S***** N******]2 were named. Her date of birth, consistent with her passport, was given as
22nd September 1981. The Claimant's full name was given.

22.3. The visa applications made by the Claimant's Qatari employers [C180 and 182] – These applications
were linked to the Claimant's application and were made by Mr and Mrs Al Thani, both of whom were
Qatari nationals.

22.4. Visa application confirmation of the Claimant's sponsor for entry to the UK [C189]

22.5. An Indonesian school graduation certificate for the years 2003/04 [B33/34] - The certificate bears the
Claimant's first name but has no family name. It records a date of birth of 22nd September 1990. It was
issued on 28th June 2004, consistent with graduation for a child aged 13. It bears a photograph of a female
student.

22.6. An Indonesian Primary School Diploma dated 12th April 2004 [B61/63] – This Diploma bears the
Claimant's first name. It records a date of birth of 22nd September 1990. The person named on the
diploma is said to be the “Child of S*****” . The place of birth is recorded as “SERANG”. The diploma bears
a photograph of a female student.

23. There has been no suggestion that the school certificate or diploma are forged or false documents. The issue
was and is whether they relate to the Claimant.

24. The CG Decision refers to and considers the passport and the school certificate; it does not refer to the diploma
at all; it does not refer to or consider the information provided in the visa applications.

**Procedural history**

25. The Claimant's solicitors sent a pre-action protocol letter on 19th September 2017. The Defendant responded
on 3rd October 2017; she refused to reconsider the CG Decision. These proceedings were issued on 18th October
2017.

26. On 24th November 2017, the Claimant was granted permission to serve Amended Grounds. On 6th April 2018,
the Defendant served Amended Grounds of Summary Defence.

27. On 27th April 2018, Richard Clayton QC, sitting as a Deputy High Court Judge, granted permission on all
grounds on the papers.

28. On 5th June 2018, the Defendant served Detailed Grounds of Defence.

29. On 13th June 2018, Richard Clayton QC adjourned the substantive hearing listed for 19th June 2018. Various
requests for further information and disclosure followed.

**The CG Decision**

30. The CG Decision appears at various places within the bundle; I will focus my attention on the version at [A187**206]. The decision maker stated, “For the reasons set out below, it is considered that you are not a credible witness**
_and therefore, no weight is attached to your evidence.” [A196]._

31. The documentation submitted by the Claimant/on the Claimant's behalf was considered. The school certificate
was specifically considered, with the decision maker concluding, “… it is noted that the name of the person listed on
_the certificate is simply 'N******'; there is no family name When taking this into account it is considered the_


-----

_document fails to confirm your claim that your date of birth is 22 September 1990 as it cannot be confirmed that the_
_document is actually yours. The photograph on the document has been taken into consideration, however, it is_
_noted that the photograph would have been taken on or prior to 28 June 2004 which is over 13 years ago and_
_therefore cannot be relied upon as a sole basis to confirming this document as evidence of your identity and age._
_As such it remains that the Home Office believes your date of birth to be 22 September 1981. The rest of your claim_
_will be considered below addressing inconsistencies within your account. …” [A197]._

32. There was no suggestion or conclusion that the certificate was a false or forged document; the grounds for
rejection were that it could not be confirmed that the document was in fact the Claimant's.

33. The decision maker identified and relied upon the date of birth recorded in the Claimant's passport. She referred
to the Claimant's failure to give her complete full name when she first came into contact with the UK authorities, and
concluded “When taking this into account it is considered you have attempted to deceive the authorities in the UK.
_Due to this it is considered that your credibility has been significantly damaged.” [A197]._

34. Thereafter the decision maker referred to a number of inconsistencies in the Claimant's account which led to the
conclusion, “When taking the above information into account it is considered you have been internally inconsistent
_and inconsistent with external evidence, as such it is considered your credibility has been severely damaged.”_

[A199], and later, “As noted above the credibility of your account has been tested and found to be lacking,
_consequently your claim has been rejected. The information provided by your Support Provider, your legal_
_representative and medical documents do not counter these findings and as such no weight is placed upon this_
_information in terms of your claim to be a victim of exploitation. In summary, based on the available evidence and_
_their respective assessments above, it is not accepted that you are a victim of modern slavery and your case is_
_rejected in full below.” [A203]._

35. It was decided that that the date of birth shown on her passport was hers and that she was an adult as at the
date of the alleged trafficking. It was further decided that she did not meet any of the criteria for a finding that she
had been a victim of human trafficking viz. (a) her time in Saudi Arabia, (b) her time in Qatar, or (c) her time in
London [A203- 204]. Similarly, her claims to have been a victim of slavery, servitude or forced or compulsory labour
were rejected on the same grounds, the decision maker concluding, “As you do not meet the definition of human
_trafficking above, it is also considered that you not meet the definition of slavery,, servitude or forced/compulsory_
_labour as the findings regarding your evidence are deemed to stand and fall across the two considerations” [A206]._

**The legislative framework**

36. The Trafficking Convention – The Council of Europe Convention on Action Against Trafficking [“ECAT”] came
into force in the UK on 1st April 2009. ECAT required competent authorities to determine whether an individual had
in fact been the victim of trafficking.

37. Article 10 of ECAT provides,

_(1) Each party shall provide its competent authorities with persons who are trained and qualified in_
_preventing and combating trafficking in human beings, in identifying and helping victims, including children,_
_and shall ensure that the different authorities collaborate with each other as well as with relevant support_
_organisations, so that victims can be identified in a procedure duly taking into account the special situation_
_of women and child victims and, in appropriate cases, issued with residence permits under the conditions_
_provided for in Article 14 of the present Convention._

_(2) Each Party shall adopt such legislative or other measures as may be necessary to identify victims as_
_appropriate in collaboration with other Parties and relevant support organisations. Each Party shall ensure_
_that, if the competent authorities have reasonable grounds to believe that a person has been victim of_
_trafficking in human beings, that person shall not be removed from its territory until the identification_
_process as victim of an offence provided for in Article 18 of this Convention has been completed by the_
_competent authorities and shall likewise ensure that that person receives the assistance provided for in_
_Article 12, paragraphs 1 and 2._


-----

_(3) When the age of the victim is uncertain and there are reasons to believe that the victim is a child, he or_
_she shall be presumed to be a child and shall be accorded special protection measures pending_
_verification of his/her age._

_(4) As soon as an unaccompanied child is identified as a victim, each Party shall:_

_(a) provide for representation of the child by a legal guardian, organisation or authority which shall act in_
_the best interests of that child;_

_(b) take the necessary steps to establish his/her identity and nationality;_

_(c) make every effort to locate his/her family when this is in the best interests of the child._

38. The Trafficking Directive – On 14th October 2011, EU Directive 2011/36/EU on preventing and combating
trafficking in human beings and protecting its victims [“the Trafficking Directive”] came into force in the UK. The
Trafficking Directive is in part intended to give effect to ECAT3 .

39. Article 2 of the Trafficking Directive provides the definition of trafficking, and provides,

(1) _Member States shall take the necessary measures to ensure that the following intentional acts are_
_punishable: The recruitment, transportation, transfer, harbouring or reception of persons, including the_
_exchange or transfer of control over those persons, by means of the threat or use of force or other forms of_
_coercion, of abduction, of fraud, of deception, of the abuse of power or of a position of vulnerability or of the_
_giving or receiving of payments or benefits to achieve the consent of a person having control over another_
_person, for the purpose of exploitation._

_(2) A position of vulnerability means a situation in which the person concerned has no real or acceptable_
_alternative but to submit to the abuse involved._

_(3) Exploitation shall include, as a minimum, the exploitation of the prostitution of others or other forms of_
_sexual exploitation, forced labour or services, including begging, slavery or practices similar to slavery,_
_servitude, or the exploitation of criminal activities, or the removal of organs._

_(4) The consent of a victim of trafficking in human beings to the exploitation, whether intended or actual,_
_shall be irrelevant where any of the means set forth in paragraph 1 has been used._

_(5) When the conduct referred to in paragraph 1 involves a child, it shall be a punishable offence of_
_trafficking in human beings even if none of the means set forth in paragraph 1 has been used._

_(6) For the purpose of this Directive, 'child' shall mean any person below 18 years of age._

40. Consent is irrelevant when identifying child victims of trafficking [see Article 2(5)].

41. European Convention on Human Rights – Article 4 of the ECHR provides,

_(1) No one shall be held in slavery or servitude._

_(2) No one shall be required to perform forced or compulsory labour._

42. The European Court of Huma Rights has held that Article 4 imposes a duty to protect victims of trafficking [see
_Rantsev v. Cyprus and Russia (2010) 51 EHRR 1 at §284]. It includes the connected and prior duty to identify_
victims of trafficking.

43. The duty to identify victims of trafficking was considered by the Court of Appeal in TDT v. Secretary of State for
_the Home Department_ _[2018] EWCA Civ 1395, where it was held [§18],_

_The duty is triggered, as we have seen from para.286 of Rantsev, where it is “demonstrated that the State_
_authorities were aware, or ought to have been aware, of circumstances giving rise to a credible suspicion_
_that an identified individual had been, or was at real and immediate risk of being trafficked”. …_

44. As a matter of domestic law, on the present authorities, a failure by the Competent Authority to follow the
li bl id i d i i th t t i ti f h t ffi ki ld t i it lf b b h


-----

of Article 4 [see R (H) v. Secretary of State for the Home Department _[[2016] EWCA Civ 565 and MS (Pakistan) v.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5K28-G3W1-F0JY-C53G-00000-00&context=1519360)_
_Secretary of State for the Home Department_ _[2018] EWCA Civ 594]. On behalf of the Claimant, Ms Knights QC_
accepts that I am bound by those authorities but “reserves her position on this point should the claim proceed to the
_Court of Appeal”._

45. The Domestic Regime – The UK did not implement ECAT or the Trafficking Directive via legislation. It elected to
establish a National Referral Mechanism [“NRM”] and issued policy guidance. The NRM is a three stage process:

45.1. Stage One – Referral of potential victims by a “first responder” to a Competent Authority.

45.2. Stage Two – The Competent Authority will determine whether there are “reasonable grounds” to
believe a person is a victim of trafficking – “the reasonable grounds decision”. If a positive reasonable
grounds decision is made then the person will be given 45 days of recovery, reflection and associated
support.

45.3. Stage Three – The Competent Authority will determine conclusively whether the person is a victim of
trafficking – “the conclusive grounds decision”. If a positive conclusive grounds decision is issued then the
Competent Authority will consider whether to grant a period of leave to remain.

46. The Home Office has published guidance on the operation of the NRM, “Victims of **_modern slavery –_**
_Competent Authority Guidance” [“the Guidance”]. The Guidance in force as at the date of the CG Decision in this_
case was updated in March 2016 and appears at [Auth 8].

47. The Guidance sets out three criteria which must be satisfied for an adult to qualify as a victim of trafficking

[pp.31-33]:

_Action_

_To be a victim of human trafficking, the person needs to be subjected to the act of either:-_

_• recruitment_

_• transportation_

_• transfer_

_• harbouring_

_• receipt_

_… …_

_Means_

_An adult victim of human trafficking must have been subject to a 'means' – the threat or use of force or_
_other form of coercion to achieve the consent of a person having control over another person._

_The apparent consent of a victim to be controlled and exploited is irrelevant when one or more of the_
_following has been used to get that consent:_

_• the threat or use of force_

_• abduction_

_• fraud_

_• deception_

_• the abuse of power or of a position of vulnerability_

_• the giving or receiving of payments or benefits_

_It is not necessary for there to have been any 'means' for a child to be a victim, because children cannot_
_give informed consent. Any child who is recruited, transported, or transferred for the purpose of human_


-----

_trafficking is considered to be a potential victim, whether or not they have been forced or deceived. See_
_Child victims for further guidance on handling a child's case._

_A potential victim of trafficking who may have been a victim as a child, but only identified and referred into_
_the NRM after reaching adulthood is tested under child criteria in assessing whether they were trafficked._
_The practical effect of this is that they do not have to meet the means test._

_… …_

_Exploitation_

_To be a victim, someone must have been trafficked for the purpose of 'exploitation' which may take the_
_form of either:_

_• sexual exploitation_

_• forced labour or services_

_• slavery or practices similar to slavery_

_• servitude_

_• forced criminality_

_• removal of organs (also known as organ harvesting)_

… …

48. As can be seen, if the Claimant was an adult as at the date of the events complained of she must satisfy all
three criteria; if she was a child at those dates then she need only satisfy “action” and “exploitation”.

49. The Claimant's case is that she was exploited for the purpose of (a) forced labour or services, and (b) servitude.
In that regard, the Guidance states [pp.35-36],

_Trafficking: exploitation – forced labour_

_Forced labour is not restricted to a particular sector of the labour market but cases have been identified in_
_these sectors:_

    - manufacturing

    - food processing

     - agriculture

     - hospitality

_For forced labour within the home, see the domestic servitude section. As with other forms of trafficking_
_related exploitation, a high level of harm and control or coercion is needed to trigger the UK's obligation_
_under the Council of Europe Convention on Action against Trafficking in Human Beings. Forced labour_
_represents a severe violation of human rights and is a restriction of human freedom._

_The International Labour Organisation (ILO) defines forced work as:_

_'All work or service which is exacted from any person under the menace of any penalty and for which the_
_person has not offered himself voluntarily'._

_This definition is a useful indication of the scope of forced labour for the purposes of human trafficking._
_Siliadan v France 2005 (Application no. 73316/01) European Court of Human Rights took this as the_
_starting point for considering forced labour threshold and held that for forced labour, there must be work:_

    - exacted under the menace of any penalty which is performed against the will of the person concerned,
_that is, for which the person has not offered themselves voluntarily_

_Forced labour cannot be equated (considered) simply with either:_


-----

     - working for low wages and/or in poor working conditions

    - situations of pure economic necessity, as when a worker feels unable to leave a job because of the real
_or perceived absence of employment alternatives_

_For more information on the indicators of trafficking, see the Human Trafficking – guidance for frontline_
_staff._

_… …_

_Trafficking: exploitation – domestic servitude_

_Domestic servitude often involves people working in a household where they are:_

      - ill treated

     - humiliated

    - subjected to exhausting working hours

     - forced to live and work under unbearable conditions

     - forced to work for little or no pay

_The problems of domestic workers held in servitude are made worse by the fact it is often very difficult for_
_them to leave their employers and seek help. Abusive employers create physical and psychological_
_obstacles by, for example, instilling fear in the domestic slave by threatening them, or their relatives, with_
_further abuse or deportation, or by withholding their passport._

_Children living in domestic servitude may not see it as exploitation because they may have been used for_
_domestic servitude in their home countries and it may appear like an extension of the same arrangement._
_Some children may have been groomed and see the domestic servitude as normal work they have to do in_
_return for food and lodgings. There is evidence to suggest if children are kept in domestic servitude by_
_powerful members of their community or family members they are unable to report the abuse due to the_
_psychological control._

_…_

_For more information on domestic servitude, see the United Nations Office on Drugs and Crime – Domestic_
_'service' or domestic slavery?_

50. Modern Slavery – Modern slavery includes human trafficking but also includes cases of slavery, servitude and
compulsory labour. A person may not be a victim of trafficking but a victim of **_modern slavery. The Guidance_**
specifically provides [p.39- 40],

_… In England and Wales, Competent Authority decision makers must decide whether, if someone is not a_
_victim of trafficking, they are nonetheless a victim of another form of modern slavery. …._

_… …_

_Slavery, servitude and forced or compulsory labour are prohibited by Article 4 of the European Convention_
_on Human Rights and illegal across the UK, but each jurisdiction has its own legislative framework of_
_prohibitions. For the purposes of the NRM the UK recognises that slavery, servitude and forced or_
_compulsory labour have the same meaning as they do under Article 4 of the European Convention on_
_Human Rights. This ensures a consistent approach for victims across the UK._

**_Modern slavery: forced or compulsory labour (victim not trafficked)_**

_UN Convention No.29 concerning forced or compulsory labour defines 'forced or compulsory labour' as 'all_
_work or service which is exacted from any person under the menace of any penalty and for which the said_
_person has not offered himself voluntarily._

_… …_


-----

_For a person to be a victim of forced or compulsory labour there must have been 2 basic components:_

    - means

     - service

_However, there does not need to be a means used for children as they are not able to give informed_
_consent._

_Child forced or compulsory labour (victim not trafficked as there has been no element of movement) will_
_therefore consist of one basic component: service._

_… …_

_Where a case meets the test for forced and/or compulsory labour, they would receive a positive conclusive_
_grounds decision. The concepts of servitude and slavery are explained below for completeness._

**_Modern slavery: servitude_**

_'Servitude' means an obligation to provide a service that is imposed by the use of coercion._

_Servitude is an 'aggravated' form of forced or compulsory labour. The fundamental distinguishing feature_
_between servitude and forced or compulsory labour is in the victim feeling that their condition is permanent_
_and that the situation is unlikely to change._

**_Modern slavery: slavery_**

_The 1926 Slavery Convention defines slavery as 'the status or condition of a person over whom any or all_
_of the powers attaching to the right of ownership are exercised'._

_This concept of ownership is what makes slavery distinct – for example a situation where an individual was_
_being controlled by another would not meet this threshold, unless there was clear evidence the person was_
_being used as a commodity. It is a form of servitude with the additional concept of ownership._

_Threat of penalty – eg threat or use of force, coercion, abduction, fraud, deception,_

_Means_ _abuse of power or vulnerability_

_As a result of the means an individual provides a service for benefit, eg begging, sexual_

_Service_ _services, manual labour, and domestic service_

51. As with trafficking, a child need not establish “means” in order to establish forced or compulsory labour,
servitude or slavery.

**Age assessment**

52. As set out above, it is important to determine whether the person was a child as at the date of the events which
are said to constitute trafficking or **_modern slavery. A child does not have to satisfy the means requirements in_**
either case. That also applies to a person who is an adult as at the date of entering the NRM but who was a child as
at the date of the index events.

53. The Guidance itself does not include any specific provision as to how the Competent Authority should assess
age in the event of a dispute. What the Guidance does state is [pp.46-47],

_Potential child victims of modern slavery who are now adults_

_In some cases, a potential victim of modern slavery may have been a victim as a child, but only identified_
_and referred into the NRM after reaching adulthood. In these circumstances, the Competent Authority_
_should treat the potential victim as having been a child at the time of the_ **_modern slavery incident and_**
_follow the guidance covering children within the NRM decision making process. This means assessing the_
_if th_ _hild t_ _k_ _bl_ _d_ _d_ _l_ _i_ _d d_ _i i_

|Means|Threat of penalty – eg threat or use of force, coercion, abduction, fraud, deception, a buse of power or vulnerability|
|---|---|
|Service|As a result of the means an individual provides a service for benefit, eg begging, sexual s e rvices, manual labour, and domestic service|


-----

_However an adult who enters the NRM who may have been a victim as a child would be treated as an_
_adult for the purposes of support, services and safeguarding, for the purposes of requiring consent to enter_
_the NRM and for immigration leave purposes._

_Establishing age_

_In some cases a person referred to the NRM may claim to be a child but it is suspected that they are an_
_adult._

_It is sometimes difficult to establish the age of a potential child trafficking or modern slavery victim where_
_there is a dispute over age._

_In such cases the Competent Authority and other agencies within the NRM will continue to treat the_
_individual as a child until age is established. However, whether an individual is a child or an adult must be_
_established before the Competent Authority reaches its conclusive grounds decision. The first responder_
_should have commissioned an age assessment where appropriate. The Competent Authority should check_
_whether this has been commissioned. There is guidance on assessing the age of a potential child modern_
**_slavery victim on Horizon._**

_Where an age assessment has been conducted by the Local Authority and has determined that the_
_potential victim is an adult, the Competent Authority must seek consent from the potential victim to remain_
_in the NRM before the case is progressed any further._

_It may be the case that the potential victim challenges the outcome of an age assessment. The Competent_
_Authority must accept the determination of the Local Authority until such time as any challenge is_
_concluded._

54. There is no dispute that the Claimant was an adult when she entered the NRM. The dispute is whether she was
a child at the time of events in Saudi Arabia, Qatar and on her arrival in the UK. The Guidance is silent as to how
age should be assessed in those circumstances.

55. There was some confusion as to what age assessment following what guidance was in fact undertaken by the
decision maker in this case.

56. By letter dated 26th June 2018 [A282], the Claimant's solicitors requested disclosure of the guidance described
as “available on Horizon” under the “Establishing Age” section of the Guidance [see above].

57. By letter dated 31st July 2018 [A272], the Claimant's solicitors proposed that an age assessment could be
undertaken at that time by appropriately trained social work professionals to determine whether the Claimant was
27 [as contended for by the Defendant] or 36 [as found by the Defendant].

58. On 3rd August 2018, the Government Legal Department [“the GLD”] replied to those letters. With regard to the
proposal to carry out an age assessment, the GLD stated,

_… The SSHD would resist that request. An age assessment is designed to work out if somebody is a child_
_or an adult, and is not suitable for determining an adult's age once they have entered adulthood, and_
_certainly not to the degree of exactitude to be able to tell a difference of 8 years of age. I attach the SSHD's_
_guidance on age assessments._

59. The guidance attached to that letter appears at [C31]. It is the Home Office “Assessing Age” guidance published
on 26th February 2018. That would be the relevant guidance to follow if conducting a formal age assessment in July
2018, as had been proposed by the Claimant's solicitors.

60. In response to that letter, on 28th August 2018, the Claimant's solicitors wrote to the GLD, stating,

_This document [“Assessing age”] was published on 26 February 2018, i.e. well after the Conclusive_
_Grounds decision was made in this case (the first decision being made in February 2017, and the second,_
_reconsidered decision in July 2017). We continue to request disclosure of the full policies/guidance on_
_assessing age in place at the time of the relevant decisions_


-----

61. By letter dated 17th September 2018 [Supp 6], the GLD replied,

_My client confirms that:_

      - _The guidance I sent earlier with the words “archive” in the watermark was the guidance used for your_
_client. [emphasis added]_

The guidance “with the words 'archive' in the watermark” appears at [C1]. That is the Home Office “Assessing Age”
guidance in force as at 2017.

62. It therefore appeared, from that letter, that the 2017 Assessing Age guidance had been used and applied in the
assessment of the Claimant's age. However, that was not the position adopted by the Defendant at the hearing, the
Defendant's Skeleton Argument asserting,

_The age assessment policies at [C1-C30] and [C31-92] are similarly concerned with determining whether a_
_person claiming asylum is a child at the time of claiming asylum. These policies are not relevant to the_
_case of a person who is indisputably an adult at the time of claiming asylum, but who claims to have been_
_a child at the time of events giving rise to the asylum claim._

63. Because of the importance of the age assessment in this case and as a result of the inconsistency between the
letter of 17th September 2018 and the position adopted by the Defendant at the hearing, I ordered the Defendant to
serve a witness statement confirming what age assessment guidance, if any, was followed and applied in the
Claimant's case. I granted the Claimant permission to adduce further evidence or to respond if so advised. There
was some delay in the Defendant producing that witness evidence, which did not find its way to me until the end of
January 2019.

64. I now have the benefit of a witness statement from Ms Angela McIlveen, a Team Leader within the NRM, who
was the Senior Decision Maker who completed both Conclusive Grounds Decisions in this case. Ms McIlveen
states that the Claimant's case was considered on the basis that she was an adult at the time of entering the NRM
but claimed to have been a child at the time of the index events. She confirms that the Assessing Age guidance at

[C1-30] was in force at the time but states that it was not relevant in this case as there was no question as to
whether the Claimant was an adult or a child as at the date of the assessment [see §7]. She further confirms that
the Claimant did not undergo a formal age assessment. She states that the GLD letter of 17th September 2018,
suggesting that the Assessing Age guidance was in fact used in the Claimant's case “is not correctly worded”.

65. In response, the Claimant lodged written submissions from Ms Knights QC making three main points: (i) the
Defendant's attempt to explain the previous reference to “used” was challenged, (ii) Ms McIlveen's confirmation that
the Claimant did not undergo an age assessment demonstrates “plainly an error of law because as the VMS policy
_is clear the Competent Authority must form a view as to an individual's age before deciding whether or not they are_
_a victim of trafficking”, and (c) the confusion surrounding the Defendant's approach to the question of age_
assessment “must be taken into account when assessing the substantive case put forward by the Defendant
_overall.”_

66. In my judgment, the Defendant's analysis of the Guidance and the correct approach to be adopted in
circumstances such as the Claimant's is to be preferred:

66.1. The “Potential child victims of **_modern slavery who are now adults” section of the Guidance_**
does not prescribe or mandate that a formal age assessment is carried out, or the form that such an
assessment should take.

66.2. The “Establishing age” section of the Guidance addresses the situation where a person referred to
the NRM claims to be a child at that stage but is suspected to be an adult. That section of the Guidance
specifically directs the reader to the “Assessing Age” guidance found on Horizon. In those circumstances it
is eminently sensible and appropriate to consider a formal age assessment.

66.3. The same cannot be said where there is no dispute that the Claimant is an adult as at the date of
entering the NRM.


-----

66.4. In the absence of a requirement to carry out a formal age assessment, the correct approach where
an adult claims to have been a child as at the date of the index events is for the Competent Authority to
determine his/her age on the balance of probabilities on the totality of the evidence before it, following the
general guidance given as to how to approach the decision making process [p.65],

_The 'balance of probabilities' essentially means that, based on the evidence available, human trafficking or_
**_modern slavery is more likely than not to have happened. This standard of proof does not require the_**
_Competent Authority to be certain that the event occurred. In reaching their decision the Competent_
_Authority must weigh the balance of probabilities by considering the whole human trafficking or_ **_modern_**
**_slavery process and the different and interrelated actions that need to have taken place._** **To**
**make their decision, they must weigh the strength of the indicators or evidence presented,**
**including the credibility of the claim, and use common sense and logic based on the particular**
**circumstances of each case** _. See Assessment of modern slavery by the Competent_
_Authority. [emphasis added]._

66.5. It is essential that the decision maker determines whether the person was a child or an adult as at the
date of the index events before going on to consider whether he/she was a victim of human trafficking
and/or modern slavery [see Guidance p.47]. That does not mandate that a formal age assessment must
be carried out.

67. As to what approach was adopted here, it is clear from the GLD letter of 3rd August 2018, that the age
assessment guidance produced was the guidance which would be followed were a formal age assessment to be
carried out at that stage. It was provided in response to the Claimant's request for an age assessment to be carried
out in 2018.

68. The impression given by the letter of 17th September 2018, was that the 2017 “Age Assessment” guidance had
been “used” in that it had been applied in the Claimant's case to undertake a formal age assessment. That was not
the case. I accept that that guidance was “used” only insofar as to decide whether the Claimant fell into the
category of individuals who should undergo a formal age assessment [see GLD letter of 8th November 2018]. For
the reasons given, the Claimant was not within that category and therefore the guidance as to how to conduct a
formal age assessment were not relevant in her case.

69. It is obvious on the face of the CG Decision that a formal age assessment was not undertaken – there is no
reference to or description of such an assessment being undertaken. The GC Decision is self-evidently consistent
with the decision maker, Ms McIlveen, making a finding of fact on the balance of probabilities as to the Claimant's
date of birth on the totality of the evidence considered by her. I accept Ms McIlveen's evidence on this issue.

**Standard of Review**

70. It is common ground that the standard of review involving a decision as to whether a person is a victim of
trafficking requires “a heightened or more rigorous scrutiny” with “the need to show by their reasoning that every
_factor which tells in favour of the applicant has properly been taken into account.” [see Sir Stephen Silber in SF v._
_Secretary of State for the Home Department_ _[2015] EWHC 2705 (Admin)]. However, the decision maker need only_
take relevant factors into account.

**The Claimant's Grounds**

71. The Claimant's Amended Grounds in respect of which permission to seek judicial review was given are:

Ground (1) – The Defendant failed to adhere to published policy guidance on the substantive assessment
of the conclusive grounds decision and/or is irrational

71.1. Failed to consider all relevant evidence with anxious scrutiny.

71.2. Breach of her own published policy when assessing credibility.

71.3. Failed to consider factors in the Claimant's favour.


-----

71.4. Failed to take account of mitigating circumstances based on medical information and physical and
psychological indicators of trafficking.

71.5. Failed to consider the trafficking definition under Articles 2 and 11 of the Trafficking Directive, Articles
4 and 10 of ECAT and pp.31-33 of the Guidance.

71.6. The multiple breaches of published policies vitiated the decision, which was irrational in any event.

Ground (2) – The Defendant breached minimum requirements of procedural fairness and/or her published
policies on procedures when making a negative conclusive grounds decision

71.7. Breach of minimum standards of procedural fairness and/or published policies.

71.8. Failing to give the Claimant a proper opportunity to explain inconsistencies prior to a decision being
made where explanations would have been available prior to the decision being made.

72. Those grounds were expanded upon and developed in the Claimant's Skeleton Argument and oral submissions
at the hearing as follows.

73. Breach of Policy: Age Assessment – (a) failing to establish age prior to making the conclusive ground decision;
(b) failing to apply the Assessing Age guidance in substance or in form; (c) failing to determine the Claimant's age
on the totality of the evidence “in the round”; (d) failing to carry out a formal age assessment.

74. Failure to take relevant considerations into account – The Defendant failed to take all relevant evidence into
account, in particular, failing to take account of (a) the Claimant's explanation for the incorrect date on her passport;
(b) numerous positive trafficking indicators in the Claimant's case; (c) objective evidence which supports a situation
of trafficking; (d) the Claimant's evidence that she had been taken to the UK when considering whether an “act” had
occurred for the purpose of the trafficking test; (e) the Claimant's mitigating circumstances, including all of the
medical information and the physical and psychological indicators.

75. Procedural unfairness – (a) failing in the evidence gathering duty to contact professionals to clarify issues about
which there was dispute, most critically the Claimant's age; (b) failing to carry out an interview with the Claimant; (c)
basing the decision on documentation, namely a copy of the Claimant's passport, her domestic visa and the
transcript of her police interview, which were not provided to the Claimant until after the decision was made.

76. Irrationality – (a) attaching “no weight” to the Claimant's evidence when a number of aspects of the Claimant's
account were confirmed as accurate by independent evidence, and her account was consistent with objective
evidence; (b) undue reliance upon inconsistencies that were either relatively minor and/or not of themselves
sufficiently relevant to the actual decision making process; (c) failing to carry out a balanced assessment, weighing
the alleged inconsistencies and concerns about the Claimant's evidence against the weight of the evidence in her
favour; (d) concluding that no weight could be placed on the letters in support of her claim to be trafficked as there
was no medical evidence confirming that her medical condition was a direct result of having been trafficked.

**Defendant's Response**

77. The Defendant disputes the Claimant's allegations of substantive and procedural failings:

77.1. The Defendant considered all relevant factors with appropriate care.

77.2. She followed her own published policies and procedures.

77.3. She considered the totality of the evidence, including any factors in the Claimant's favour, and
reached a decision she was entitled to reach.

77.4. She considered “the whole trafficking process” and specifically identified and considered objective
evidence as to the prevalence of human trafficking in the relevant geographic areas when making her
decision.

77.5. She was entitled to take inconsistencies in the Claimant's account into account.


-----

77.6. She was entitled to take into account the absence of medical evidence attributing the Claimant's
symptoms to a particular cause, specifically that her symptoms of trauma were attributable to having been
trafficked as opposed to the development of and suffering due to the tuberculosis.

77.7. The Defendant having found that the Claimant was not a child as at the date of the index events, the
Claimant therefore had to satisfy all three of the trafficking criteria. The Defendant was aware of,
understood and applied the correct criteria.

77.8. All of the documentary evidence referred to [passport, domestic worker visa and police interview]
were disclosed to the Claimant's representatives in April 2017, over two months before the decision
complained about.

77.9. It was open to the Defendant to proceed to make the CG Decision without contacting medical
professionals or seeking further information or clarification by way of interview or otherwise.

77.10. A formal age assessment was not required.

77.11. Any breaches of the Guidance or other public law errors, if established, were not material to the
outcome.

78. In his oral submissions, Mr Staker submitted that this was a case in which the Claimant's account, even if
accepted, could not account to human trafficking or modern slavery. I reject that submission on two grounds. First,
nowhere was it said within the CG decision that the Claimant's account, even if accepted and taken at its highest,
could not amount to human trafficking or **_modern slavery; that was not the approach adopted by the decision_**
maker. Second, in my judgment it would be open to a decision maker directing herself reasonably to conclude that
the Claimant's account did amount to human trafficking and/or modern slavery.

**Discussion**

79. The Claimant's claim succeeds on three grounds:

79.1. Failure to consider all of the evidence in the Claimant's favour;

79.2. Attaching no weight to the Claimant's evidence;

79.3. Flawed approach to the trafficking criteria.

Failure to consider all of the evidence in the Claimant's favour

80. As set out above, there was limited documentary evidence. Plainly, the Claimant's passport, if a true and
accurate record of her date of birth, would weigh heavily against her claim that she was born on 22nd September
1990. However, the Claimant adduced a school graduation certificate and a diploma which she said were hers and
which both showed a date of birth of 22nd September 1990. If those documents were genuine documents _and_
_related to the Claimant then they could/would provide good evidence in the Claimant's favour._

81. The Defendant specifically considered the graduation certificate. The decision maker's assessment of that
document appears at [A197]. The decision maker positively relies upon the fact that “there is no family name” and
only bears the Claimant's first name [A197]. The decision maker concluded that she was not satisfied that the
certificate was the Claimant's and stated that it “cannot be relied upon as a sole basis to confirming [sic] this
_document as evidence of your identity or age.”_

82. That conclusion was one which was open to her. However, the graduation certificate was **not the only**
document or “sole basis” relied upon to confirm the Claimant's identity and date of birth; she also relied upon the
diploma [B61/63]. That document is not referred to or considered at any stage in the CG Decision.

83. The diploma includes information not included in the graduation certificate. Not only does it include the
Claimant's first name and her date of birth, it also states that the named person is the “Child of S*****” [B63]. That is
almost identical [bar one letter] to the name which the Claimant provided for her father in her application for a
domestic worker visa [C177]. Although not a “family name”, it is additional information which suggests that the


-----

diploma might in fact be the Claimant's. It also states that the named person was born in “SERANG”; that is the
same as the place of birth listed on (i) the Claimant's passport, which the decision maker positively concluded was
the Claimant's, and (ii) her domestic visa application. Again, it is further information which suggests that the diploma
might be the Claimant's.

84. It is also to be noted that the Defendant was able to locate the Claimant's visa application and a copy of her
passport using information provided by the Claimant in her witness statement, “namely the surnames of your father
_(S**** N******), mother (S***** N******) and siblings ….” [see GC Decision @ A197]._

85. Plainly the diploma was a relevant document which had to be considered. Information within it – the reference to
being the child of “S*****” and a place of birth of “SERANG” - was potentially consistent with the document referring
to and belonging to the Claimant. It was consistent with information provided by the Claimant in her visa application.
There was no suggestion that the diploma or the graduation certificate were false or forged; the only issue was
whether they were the Claimant's.

86. In my judgment it was essential that the decision maker gave careful consideration to the contents of all of the
documents relied upon by the Claimant, including the diploma and the visa application. “Anxious scrutiny” of all
relevant considerations demanded that she did so. The decision maker's failure to do so and to cross-refer the
contents of the diploma with other documents represent fundamental failures in her approach.

87. This is particularly the case when one considers (i) the decision maker's analysis starts with and proceeds from
her findings as to the reliability of the documentation provided by the Claimant [A197], and (ii) the decision maker
relied upon her finding as to the Claimant's date of birth to demonstrate inconsistencies in the Claimant's account

[see A198, A199 and A201].

88. Mr Staker submitted that I could be satisfied that the decision maker would have reached the same conclusion
in relation to the diploma as she reached in relation to the graduation certificate. I am not satisfied that I can. As set
out above, the diploma includes additional information, potentially consistent with this document being the
Claimant's, which is not included in the graduation certificate. In those circumstances I am not prepared to assume
what conclusion the decision maker would have reached in relation to that document which added to the evidence
in support of the Claimant's account.

89. The issue of whether the Claimant was a child or not was central to the determination of whether she was
required to satisfy all three of the trafficking criteria [if an adult] or only two [if a child]. Further, the decision maker's
rejection of the Claimant's evidence as to her date of birth was a significant adverse factor when she went on to
consider the Claimant's credibility in general [see for example **A198,** **A203 and** **A205]. Had the decision maker**
reached the conclusion that the diploma was the Claimant's and correctly showed her date of birth as 22nd
September 2000, consistent with the Claimant's account, then that could/would have been a significant positive
factor when considering her credibility generally.

90. The Defendant's failure to consider the diploma, its contents, its potential consistency with the information given
in the visa application and the passport, and the possibility that it was in fact the Claimant's, represent a failure to
consider all relevant evidence contrary to the Guidance and contrary to basic principles of procedural fairness.

91. The Defendant's failure to consider the diploma and to make a finding as to the Claimant's date of birth in the
light of her assessment of the diploma is, in my judgment, so fundamental that it vitiates the Defendant's approach
to the Claimant's credibility and the decision as a whole.

Attaching no weight to the Claimant's evidence

92. The decision maker asserted on a number of occasions that “no weight” was to be attached to the Claimant's
evidence [see A196]. Whilst it is of course a matter for the decision maker to decide what weight is to be attached
to the Claimant's evidence balanced against all of the other evidence, where contemporaneous unchallenged
documentary evidence supports the Claimant's account, it cannot be said that “no weight” could be attached to any
of her evidence.


-----

93. By way of example:

93.1. The Claimant's account that she had travelled to the UK as a domestic worker was independently
verified by her domestic worker visa [C177].

93.2. That the Claimant had worked for and travelled to the UK with the Al-Thanis was independently
verified by the fact that Mr Al-Thani was the named “sponsor” for the Claimant's domestic worker visa
application [C189] .

93.3. That she worked for the Al-Thanis in Qatar was also supported by the fact that her visa application (i)
was issued on the same day as the Al-Thanis' applications, (ii) was issued in Doha as was the Al-Thani's,
and (iii) was for a near identical six month period 16th /17th July 2008 to 16th /17th January 2019 [see
**C177-182].**

93.4. That she was born in Serang was verified by her passport [C179].

94. An assessment of the Claimant's credibility must involve careful consideration of evidence and factors
supporting her account balanced against evidence and factors contradicting or undermining her account. The
decision maker failed to carry out a balanced assessment of positive and negative factors and focussed exclusively
upon the alleged inconsistencies in the Claimant's account without recognising any of the consistencies or positive
factors.

95. In my judgment it was not open to the decision-maker to attach “no weight” to the Claimant's evidence and her
approach to the assessment of the Claimant's credibility was flawed as a result.

Flawed approach to the trafficking criteria

96. Whether the Claimant was an adult or a child, she would have to establish that she was subject to an “act” of
transportation, recruitment, transfer, harbouring or receipt.

97. The decision maker addressed this issue in relation to Saudi Arabia at [A203], stating,

_… It is considered you approached the agent yourself and have therefore failed to show that you were_
_recruited. It is noted that you claim you were transported to Saudi Arabia._

_However, in line with the assessment above, it is not considered you meet part 'a' of the definition._

98. She addressed the issue in relation to Qatar and the UK at [A204],

_You have stated that you again approached the same agency this time you went to Qatar to work for two_
_years. During this time you were taken on holiday with the family to the UK. It is considered you claim you_
_were transported. However, in line with the assessment above, it is not considered you meet part 'a' of the_
_definition._

99. The Claimant's account that she was transported to Saudi Arabia, Qatar and the UK was not challenged. It is
plain that she was transported to the UK as a visa was issued for her arrival in the UK at the same time as the AlThani family [see C177, C180 and C182]. Similarly, she must have been transported to Qatar in order to be in the
employment of the Al-Thanis, a Qatari family [C180 and C182].

100. In my judgment, it was not open to the Defendant to conclude that the Claimant had not been transported to
the UK. The documentary evidence demonstrated without question that she was. There was no evidence to
suggest to the contrary. The finding that she did not satisfy the “act” criteria in respect of her transportation to the
UK was perverse.

101. Similarly, in my judgment, in the absence of a clear reasoned finding that the Claimant's account that she had
been transported to Qatar was rejected, the finding she did not satisfy the “act” criteria in respect of her
transportation to Qatar was perverse. The Claimant provided the name of her employers [Al-Thani] and that she
had worked for them in Qatar. Mr Al-Thani was the Claimant's sponsor for her visa application [C189]. On the


-----

evidence before the decision maker, it was not open to her to conclude, if she did conclude, that (a) the Claimant
had not worked for the Al-Thanis in Qatar, or (b) that she had not been transported to Qatar.

102. Whilst it may have been open to the Defendant to conclude that the Claimant had not worked in Saudi Arabia
at all, nowhere does she set out that conclusion in the GC Decision. In the absence of an express finding that the
Claimant had not worked in Saudi Arabia at all, the finding she did not satisfy the “act” criteria in respect of her
transportation to Saudi Arabia was perverse.

103. The fact that the Defendant reached perverse and unsustainable conclusions on the first trafficking criteria in
respect of each of the three complaints of trafficking is a fundamental failure. In my judgment it demonstrates a
failure to properly and fairly evaluate the evidence and reach conclusions reasonably open to the decision maker. It
is consistent with, and in my judgment demonstrates, a rejection of the entirety of the Claimant's evidence without
proper consideration of the totality of the evidence.

The Claimant's remaining grounds

104. In the light of my findings as to (a) the correct approach to age assessment in a case such as this, and (b) the
approach actually adopted by the decision maker in this case, the Claimant's complaints about the failure to carry
out a Merton 4 compliant age assessment fall away.

105. As to the alleged failure to take relevant considerations into account, save for the failure to consider the
diploma and the visa applications, in my judgment the decision maker took all other relevant considerations into
account as shown by the CG decision itself. The decision maker expressly acknowledged that there was objective
evidence of trafficking in the relevant geographic areas [A192-195]. She took that into account when balancing that
evidence against the specific evidence in the Claimant's individual case.

106. In my judgment the Defendant did not fail in her “evidence gathering duty” [Claimant Skeleton §96]. She
received extensive written submissions and additional documentation from Kalayaan which was considered [save
for the diploma and visa applications] in the CG decision.

107. As conceded by Ms Knights QC, the Defendant is not obliged to carry out an interview of every potential
trafficking victim. It is a matter for the Defendant to decide whether further investigation or an interview is required.
In the circumstances of this case where the Claimant was supported by Kalayaan and where extensive
documentation and written submissions had been submitted in response to the first negative conclusive grounds
decision [of 8th February 2017] [see B40-B60], it was open to the Defendant to proceed to make the CG decision
on the basis of the totality of the material placed before her.

108. As set out above, the Claimant's challenge that the CG decision was based upon documentation that had not
been provided to the Claimant [namely the passport, domestic worker visa and transcript of police interview] was
factually wrong. That challenge falls away.

109. The Defendant was entitled to identify and rely upon inconsistencies in the Claimant's account and
inconsistencies with other external evidence. However, for the reasons already given, what she was not entitled to
do was to disregard the Claimant's evidence in its entirety and ignore consistencies in the Claimant's account.

110. The Defendant did take into account the medical and other mitigating evidence [see A201-202]. That evidence
was not probative as to whether the Claimant had been a victim of trafficking or modern slavery as she contended.
The weight to be attached to that evidence was a matter for the decision maker.

**Disposal**

111. In the light of my findings as set out above:

111.1. The Conclusive Grounds decision of 12th July 2017 is quashed.

111.2. The matter is to be reconsidered by the Defendant and a fresh Conclusive Grounds decision is to be
produced


-----

**Postscript**

112. Following receipt of the draft judgment, the parties have agreed a draft order which I now make.

1 Additional documentation such as medical notes and records were available but these were of limited
value in relation to the central issues.

2 The full names appear in the document but have not been reproduced to preserve the Claimant's
anonymity, consistent with the order of Mr Justice Morris.

3 See Lord Dyson MR at §105 in _R (Gudanaviciene) v. Director of Legal Aid Casework [2015] 1 WLR_
2247.

4        R (B) v London Borough of Merton _[2003] EWHC 1689 (Admin) documentation from Kalayaan_
which was considered [save for the diploma and visa applications] in the CG decision.

**End of Document**


-----

