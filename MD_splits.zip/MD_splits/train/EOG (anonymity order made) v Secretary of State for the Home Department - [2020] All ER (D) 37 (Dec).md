# EOG (anonymity order made) v Secretary of State for the Home Department

 [2020] EWHC 3310 (Admin)

Queen's Bench Division, Administrative Court (London)

Mostyn J

3 December 2020Judgment

**Amanda Weston QC and Miranda Butler (instructed by Duncan Lewis Solicitors) for the Claimant**

**Robin Tam QC and William Irwin (instructed by The Treasury Solicitor) for the Defendant**

Hearing date: 24 November 2020

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Mr Justice Mostyn:**

1. The Council of Europe Convention on Action against Trafficking in Human Beings (“ECAT”) was signed
in Warsaw on 16 May 2005. Its paramount objectives, as stated in its recitals, are respect for victims'
rights; protection of victims; and action to combat trafficking. In a similar vein, Article 1 provides that the
purposes of ECAT are (a) to prevent and combat trafficking in human beings and (b) to protect the human
rights of the victims of trafficking and to design a comprehensive framework for the protection and
assistance of victims and witnesses.

2. Although ECAT has not been formally incorporated into our domestic law it has been held that a failure
by the government to apply its principles will be justiciable (see, for example, _R (PK (Ghana)) v Home_
_Secretary [2018] 1 WLR 3955and_ _MS (Pakistan) v Secretary of State for the Home Department_ _[2020]_
_UKSC 9 at [20]). Further, the_ **_[Modern Slavery Act 2015 states in its explanatory notes that the Act was](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
passed against the backdrop of ECAT and other international instruments and that the guidance that the
Secretary of State is obliged to issue under section 49 must take into account the international
requirements set out in the Convention. The latest version of that guidance (version 1.02) was re-issued in
August 2020 (“the Main Guidance”).

3. Therefore, ECAT is as close to being incorporated in our domestic law, without actually being so, as it is
possible to be.

4. The obligations imposed by ECAT are discussed and explained in its Explanatory Report also dated 16
May 2005 (“the Explanatory Report”) and have been further considered in authorities stretching to the
Supreme Court.

5. I will also be referring to a further piece of guidance: Discretionary Leave Considerations for Victims of
**_Modern Slavery the latest version of which (3.0) was issued on 9 October 2020 (“the DL Guidance”)._**

6. Those documents and authorities set out how this country has sought to comply with its international
obligations. The arrangements that have been made are well-known. They are pithily summarised by
Baroness Hale of Richmond in MS (Pakistan) v Home Secretary at [2].


-----

7. In this country a person who is a suspected victim of trafficking is referred to the National Referral
Mechanism (“NRM”). This is a body within the Home Office which acts as the competent authority for the
purposes of ECAT. Its creation was by executive action alone; it has no statutory origin. Its staff must be
trained and qualified in preventing and combatting trafficking. Using legislative and other measures it must
seek to “identify” the referred person as a victim. Article 10 provides that the process of identification has
two stages. First, there is a preliminary sift to determine if there are “reasonable grounds” to believe that a
person has been a victim of trafficking (see the Explanatory Report at paras 131 and 132). If that decision
is positive then the potential victim:

i) cannot be removed from this country (see Article 10.2 and the Explanatory Report at para 132);

ii) gains the benefit of the “recovery and reflection period” referred to in Article 13 which must last at least
30 days (but which probably should be longer (see the Explanatory Report at para 177)) and which is set at
45 days in this country (see the Main Guidance at paras 7.1 and 7.2); and

iii) gains entitlement to the assistance specified in Article 12(1) and (2) (see the Explanatory Report at
paras 135 and 147).

8. The assistance to be afforded to potential victims under Articles 12.1 and 12.2 is that which is
necessary for them in their physical, psychological and social recovery. At a minimum it includes (i) money
for accommodation and psychological and material assistance; (ii) access to emergency medical
treatment; (iii) access to education for children; and (iv) a general obligation to take account of the victim's
safety and protection needs. The Explanatory Report states at para 150:

“The aim of the assistance provided for in sub-paragraphs (a) to (f) [of Article 12.1] is to “assist victims in
their physical, psychological and social recovery”. The authorities must therefore make arrangements for
those assistance measures while bearing in mind the specific nature of that aim.”

The obligation on the state to assist potential victims awaiting a conclusive grounds decision in their
physical, psychological and social recovery is at the heart of the dispute in this case.

9. For most potential victims these obligations are largely met by the government paying for
accommodation; providing a weekly subsistence allowance of £65; and affording access to the NHS and
education for children.

10. Although it is not stated explicitly, it is obvious that an underlying principle of ECAT and its Explanatory
Report is that the preliminary reasonable grounds decision should be taken very quickly. This imperative of
expedition is reflected in the Main Guidance paras 7.2, 14.48 and 14.57 where it is stated that a
reasonable grounds decision should be made within five working days “wherever possible”.

11. The second stage of the process of identification is for the Single Competent Authority (“SCA”), the
decision-making arm of the NRM, to decide on the balance of probability if the referred person is indeed a
victim of trafficking. This is known as the “conclusive grounds” decision.

12. A positive conclusive grounds decision gives rise to an entitlement to a 45-day run-off of the interim
support referred to above (see the Main Guidance at paras 7.1 and 7.2). More significantly, it opens the
door under Article 14 to the possibility of the issue of a renewable residence permit. I shall deal with this in
detail below. A conclusive grounds decision also allows for the meeting of long-term recovery needs for
those with such needs.

13. It is implicit in the terms of ECAT that the conclusive grounds decision should be taken in a reasonable
time. In R (O) v SSHD _[2019] EWHC 148 (Admin) Garnham J at [67] stated:_

“… decisions must be taken in a reasonable time. What is reasonable, however, will turn on the nature of
the power being exercised, the effect of exercising, and failing to exercise, the power, and all the
circumstances of the case.”

14. The need to make a conclusive grounds decision in a reasonable time is reflected in the Main
Guidance. At para 7.1 it states:


-----

“The SCA will make a Conclusive Grounds decision no sooner than 45 calendar days after the reasonable
grounds decision, to determine whether 'on the balance of probabilities' there are sufficient grounds to
decide that the individual is a victim of **_modern slavery. This decision is based on evidence made_**
available to the SCA. Following a positive Conclusive Grounds decision, victims will be exited from support
only when appropriate to do so. Victims with a positive Conclusive Grounds decision will receive at least 45
calendar days of support during the move-on support period.”

Para 7.2 states:

“Conclusive Grounds decision is made by the SCA. The Conclusive Grounds decision should generally be
made as soon as possible after 45 calendar days.”

At para 14.77 it states:

“There is no target to make a Conclusive Grounds decision within a specific timeframe. A Conclusive
Grounds decision should be made as soon as possible after the 45-calendar day Recovery Period has
ended, unless the SCA has received a request to delay the decision. The 45-day period begins when the
SCA makes a positive Reasonable Grounds decision. The SCA is responsible for making a Conclusive
Grounds decision.”

And at para 14.243:

“To make sure that a Conclusive Grounds decision can be made as near as possible to day 45 (although
that may not be possible in every case), a review date for day 30 should be set to:

- monitor progress on the case

- check it is on target for a conclusive decision.”

(Emphasis added)

15. I turn to residence permits. Under Article 14 of ECAT a residence permit “shall be issued to a victim”
where the competent authority considers that their stay in the national territory is “necessary owing to their
personal situation” or where it is considered that their stay is “necessary for the purposes of cooperation
with the authorities in investigation or criminal proceeding.” For the purposes of Article 14 a “victim” is
someone who has had the benefit of a conclusive grounds decision, not merely a reasonable grounds
decision.

16. In this country the victims who will be seeking a residence permit under Article 14 will be those who
are not British or EEA citizens.

17. The Explanatory Report para 181 explains how the immediate return of a victim to her country of origin
is unsatisfactory both for the victim and the law enforcement authorities combating the trafficking. It
explains how a return may lead the victim back into the hands of traffickers; how it is unlikely to deter other
victims from falling into the same trap; and how it may expose victims to a risk of reprisal. From the lawenforcement perspective the availability of residence permits is a measure calculated to encourage victims
to cooperate. Para 183 expresses the first ground where it would be reasonable to grant a residence
permit as: “the victim's personal circumstances must be such that it would be unreasonable to compel them
to leave the national territory”. Para 184 explains that the personal situation requirement will take in a
range of situations, such as the victim's safety, state of health, family situation or some other factor which
should be considered.

18. The issue of a residence permit pursuant to Article 14 triggers the further entitlements referred to in
Articles 12.3 and 12.4. Those entitlements are: (a) access to necessary medical or other assistance to
which the victim does not have adequate resources and access; and (b) in accordance with nationally
devised rules, access to the labour market and to vocational training and education. The entitlements are
only available to victims who are “lawfully resident” in the state in question. The Explanatory Report at para
165 explains that lawful residence covers those victims issued with residence permits under Article 14.
Para 166 goes on to say:


-----

“[Article 12.4] provides that each Party is to adopt the rules under which victims lawfully resident in the
Party's territory are allowed access to the labour market, to vocational training and to education. In the
drafters' view these measures are desirable for helping victims reintegrate socially and more particularly
take greater charge of their lives. However, ECAT does not establish an actual right of access to the labour
market, vocational training and education. It is for the Parties to decide the conditions governing access.
As in paragraph 3, the words “lawfully resident” refer, for instance, to victims who have a residence permit
referred to in Article 14 or who have the Party's nationality. The authorisation referred to need not involve
issuing an administrative document to the person concerned that allows them to work.”

19. ECAT does not establish an absolute right of the beneficiary of a residence permit under Article 14 to
work but, rather, mandates that the contracting states should devise rules whereby such persons can
access the labour market. However, that distinction is of no relevance in this country as the relevant policy
here permits a victim who has received our version of an Article 14 residence permit to work in any field
and to access public funds.

20. The policy in this country is set out in the DL Guidance. The Article 14 residence permit will be a grant
of discretionary leave. The standard grant is for 30 months. The decision whether to grant discretionary
leave is made by the SCA. Consistently with the terms of Article 14, consideration of whether there should
be a grant of discretionary leave will only arise once there has been a positive conclusive grounds
decision.

21. Page 6 of the DL Guidance states that a victim will not qualify for discretionary leave solely because
the SCA has confirmed that he or she is a victim of **_modern slavery. It says: “there must be reasons_**
based on their individual circumstances to justify a grant of discretionary leave”.

It states at page 7:

“Discretionary leave may be considered under this specific policy where the SCA has made a positive
conclusive grounds decision that an individual is a victim of modern slavery and they satisfy one of the
following criteria:

- leave is necessary owing to personal circumstances

- leave is necessary to pursue compensation

- victims who are helping police with their enquiries.”

And at page 11:

“A positive conclusive grounds decision does not result in an automatic grant of immigration leave.
However, unless the confirmed victim has an outstanding asylum claim at the time the positive conclusive
grounds decision is made, automatic consideration should normally be given at the same time, or as soon
as possible afterwards, to whether a grant of discretionary leave is appropriate under this policy.”
(Emphasis added)

22. Therefore, it can be seen that the policy which has been adopted, reflecting the tacit imperative of
expedition inherent in ECAT, is that a conclusive grounds decision should be made “as soon as possible”
after the 45-day recovery period has finished. And that a decision about discretionary leave, where that is
relevant, should be made at the same time as the conclusive grounds decision or “as soon as possible”
thereafter.

23. In R (O) v SSHD a wholesale attack was mounted against the NRM on the grounds that it was beset
by systemic, chronic delay and as such its functioning was irrational in public law terms and therefore
unlawful. Between [41] and [45] Garnham J analysed the statistics as they stood in the final quarter of
2018. The statistics revealed great delays. However, at [99] Garnham J held on the evidence before him:

“Furthermore, it appears from the evidence and the agreed statistics that the position is now improving.
The problems appear to have been identified and resources are being devoted to improving the speed at
which cases are determined.”


-----

24. In the case before me I have been directed by a witness statement made by Nicola Simpson, the head
of the NRM Sustainability and Policy Team, to a URL1 which allowed the download of an Excel
spreadsheet prepared by government statisticians containing a wealth of information about the functioning
of the NRM. From that it has been possible to extract data which undermines the belief of Garnham J that
things were improving. On any view things have gone from bad to worse.

25. I have also seen a letter from the Independent Anti-slavery Commissioner, Dame Sara Thornton, to
Victoria Atkins MP, the Parliamentary Undersecretary for Safeguarding and Vulnerability, dated 18 October
2019. This letter reveals the scale, past and present, of the backlog of unresolved cases at the NRM.

26. I set out in the following table the pertinent data extracted from the above-mentioned sources:

27. This table, and the underlying data, make for very dispiriting reading. The table shows a remorseless
increase in cases referred to the NRM. While it is true that the number of reasonable grounds decisions
has matched the incoming caseload, the same cannot be said of conclusive grounds decisions. There was
an increase in such decisions between 2017 and 2018 but the number in 2018 was only about half of what
was needed to deal with the volume of incoming cases; and in 2019 it was only just over a third. Hence the
increase in the backlog from 7,000 to 9,000 cases which at the current disposal rate will take between two
and three years to conclude. The present average (mean) number of 462 days (i.e.15 months) to dispose
conclusively of cases will inevitably worsen given the scale of the backlog.

28. The data also belies Garnham J's projection in [41], based on the statistical evidence before him, that
in 2018 the number of referrals would fall to 4,245 as well as his projection in [43] that the average length
of time for making a conclusive grounds decision was falling. He estimated that for 2017 the average
length of time for making such a decision had fallen to 327 days. In fact, it was 356 days, and rose sharply
in 2018 to 462 days where it stayed for 2019.

29. These delays are mirrored by the personal experience of the claimant in this case. She was referred to
the NRM on 11 September 2018. She did receive a reasonable grounds decision, albeit negative, within six
days. The NRM agreed to reconsider that decision. It took, remarkably, until 11 June 2019 for the claimant
to receive a positive reasonable grounds decision. That was 273 days after her initial referral to the NRM.
By the time that she made her judicial review application on 11 December 2019, 456 days after her initial
referral, she had not received a conclusive grounds decision. She did not receive a conclusive grounds
decision until 28 April 2020, an astonishing 595 days after her initial referral to the NRM. That conclusive
grounds decision should have led to an automatic consideration of discretionary leave yet at the date I
write this judgment, 26 November 2020, she has not yet been granted or refused such leave. 211 days
have elapsed since the conclusive grounds decision without a decision having been made about
discretionary leave. An astonishing 806 days have elapsed between her initial referral to the NRM and
today.

30. The effect of these delays has been to hit the claimant very hard. She entered this country on 20
September 2017 having been granted a Tier 5 Youth Mobility Scheme Visa, which entitled her to work and
which was valid until 20 September 2019. Unfortunately, in April 2018 she fell under the domination of a
man who abused her sexually and forced her into prostitution. Eventually she managed to escape, and as
stated above, on 11 September 2018 she was referred into the NRM. On 25 June 2019 the claimant
started work with a trafficking support organisation. She was able to do so because her visa remained
unexpired. She very much enjoyed this work and on any view her ability to do it was an important
component in her psychological and social recovery with which the state was obligated to assist her under
the terms of the Convention. However, as stated above, her visa was due to expire on 20 September 2019.
Therefore, a few days before that, on 14 September 2019, she ceased work, and has not worked since.
Since then she has been dependant on payments from the state.

31. 14 September 2019 was more than a year after her referral into the NRM. Even allowing for
management and resource difficulties any reasonable estimation of the likely timescales for decisions on
reasonable grounds, conclusive grounds and discretionary leave would have led to the conclusion that they
would have been completed with plenty of time to spare within a year. The claimant therefore must have
had a not unreasonable expectation that she would have been able to have continued with her work once


-----

her visa had expired because by then, surely, she would have reasoned, she would have gained
discretionary leave.

32. But no. Instead the claimant was forced to give up her employment and was cast into the “hostile
environment” mandated by the _[Immigration Act 2014 for overstayers and other illegal migrants. The](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)_
features of this environment were well described in R (Balajigari) v SSHD [2019] 1 WLR 4647by Underhill
LJ at [81]:

“Secondly, Mr Biggs relied on the legal consequences for an applicant who remained in the UK without
leave, which have been rendered more severe by the so-called “hostile environment” provisions introduced
by the _[Immigration Act 2014. It is, in the first place, a criminal offence to be in the UK without leave to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)_
remain: see section 24 of the Immigration Act 1971. As regards practical consequences, a person without
leave faces severe restrictions on their right to work (see section 24B of the 1971 Act), to rent
accommodation (section 22 of the 2014 Act), to have a bank account (section 40 of the 2014 Act) and to
hold a driving licence (sections 97, 97A and 99 of the Road Traffic Act 1988); nor will they be entitled to
free treatment from the NHS: section 175 of the National Health Service Act 2006. He submitted that those
consequences are bound to have a serious impact on a migrant's private life irrespective of any removal
action.”

33. So it can be seen as a result of the defendant's delay the claimant finds herself in a most unhappy
situation where she, as an overstayer, is branded a criminal (although no one has seriously suggested she
would actually be prosecuted), deprived of access to basic services, unemployed, dehumanised and
penalised. She has filed some moving evidence describing her sense of failure and emotional isolation
since she has been deprived of the opportunity to work. The treatment meted out to her is far removed
from the idea of social and psychological recovery.

34. The claimant's claim for judicial review argues that her predicament on 11 December 2019 was the
consequence of the application to her of an unlawful policy by the defendant. Specifically, she argues that
(1) the defendant's policy of excluding a recipient of a reasonable grounds decision from a grant of
discretionary leave is unlawful and (2) the defendant's refusal to treat a referral into the NRM as an
application to vary her existing visa leave, thereby extending that leave under section 3C Immigration Act
1971, is likewise unlawful. Further, she argues that as a non-British, non-EEA national she is treated less
favourably than a British or EEA national for the purposes of Article 14 of the European Convention on
Human Rights and this discrimination also renders the policy unlawful.

35. The claimant has been careful not to rerun the arguments based on chronic systemic delays
unsuccessfully mounted by Ms Lieven QC in _R(O) v SSHD._ Ms Weston QC recognises that a judicial
review based on delay is always a very steep climb requiring clear proof of irrationality. Rather, Ms Weston
QC has been careful to confine the claim in the way I have set out above.

36. However, the merit or otherwise of the claim has to be judged in the specific factual context where all
referrals to the NRM appear to be beset by extreme delay and where those delays arguably have resulted
in unacceptable treatment being meted out to this claimant.

37. If there had been no delays, and if the claimant's referral to the NRM had been processed within the
timescales advertised in the two policy documents, then she would have had no case to bring before this
court. Well before her visa ran out she would have received her conclusive grounds decision together with
a decision on discretionary leave. One way or another her position would have been certain. She would
either have been lawfully continuing to work; or she would have been preparing to return to her homeland if
she had not already done so.

38. Therefore, the argument of Ms Weston QC was refined during her oral submissions. She argued that
in circumstances where such gross delays arose it was incumbent on the defendant to include within the
existing policy terms which regulated the leave position of a person who had received a positive
reasonable grounds decision. Ms Weston QC placed strong reliance on article 10.2. This provides:

“Article 10 – Identification of the victims


-----

2.  Each Party shall adopt such legislative or other measures as may be necessary to identify victims as
appropriate in collaboration with other Parties and relevant support organisations. Each Party shall ensure
that, if the competent authorities have reasonable grounds to believe that a person has been victim of
trafficking in human beings, that person shall not be removed from its territory until the identification
process as victim of an offence provided for in Article 18 of this Convention has been completed by the
competent authorities and shall likewise ensure that that person receives the assistance provided for in
Article 12, paragraphs 1 and 2.”

39. This makes abundantly clear, she argues, that following a reasonable grounds decision discretionary
leave to remain, in some form, must be granted to that person. An obligation not to remove must mean the
same as an authorisation to stay. And an authorisation to stay can only be expressed by a grant of
discretionary leave. Yet, a decision on reasonable grounds says nothing about being allowed to stay at that
point in time. The decision dated 11 June 2019 sent to the claimant only addressed the future. It said: “if
you are not a UK or EU/EEA national, and you receive a positive decision at Conclusive Grounds stage,
then we will consider whether you will qualify for Discretionary Leave under the Modern Slavery policy.”

40. Ms Weston QC bolsters her argument about the meaning of Article 10.2 by reliance on some rather
ambiguous drafting in Article 13.1. As explained above, this provides for a recovery and reflection period,
set at 45 days in this country, to start immediately following a positive reasonable grounds decision. Article
13.1 provides

**“Article 13 – Recovery and reflection period**

1. Each Party shall provide in its internal law a recovery and reflection period of at least 30 days, when
there are reasonable grounds to believe that the person concerned is a victim. Such a period shall be
sufficient for the person concerned to recover and escape the influence of traffickers and/or to take an
informed decision on cooperating with the competent authorities. During this period it shall not be possible
to enforce any expulsion order against him or her. This provision is without prejudice to the activities
carried out by the competent authorities in all phases of the relevant national proceedings, and in particular
when investigating and prosecuting the offences concerned. During this period, the Parties shall authorise
the persons concerned to stay in their territory.”

Ms Weston QC argues that the mention of “this period” in the final sentence (which I have underlined)
refers to, and is governed by, the scenario in the immediately preceding sentence namely the time taken to
undertake the activities carried out by the competent authorities in all phases of the relevant national
proceedings. Ms Weston QC says that “these activities” plainly extend to reaching a conclusive grounds
decision. Therefore, in that period the state must authorise the person to stay here. That can only be done
by a grant of discretionary leave.

41. Although this is a respectable argument I do not agree with it. Nor do I think it is necessary to enable
the primary argument about the meaning of Article 10.2 to succeed. Although the drafting is ambiguous it
seems to me that the reference to “this period” in the final sentence is indeed to the recovery and reflection
period. Article 13 is about the recovery and reflection period and nothing else. Had the final sentence been
referring to a different period it would have said “that period” to distinguish it from the period referred to in
the heading of the Article and in its first three sentences.

42. Reverting to her primary argument, Ms Weston QC submits that the absence of the grant of any kind
of leave, however limited, to the beneficiary of a reasonable grounds decision is a fatal failure to implement
the clear requirement not to remove such a person from the national territory as provided for in Article 10.2.
As pointed out by Underhill LJ in Balajigari it is a criminal offence for anyone who is not a British or EEA
citizen to be in this country without leave. It is unthinkable, it is argued, that a government agency whose
obligation is to promote the psychological and social recovery of potential victims of trafficking should
withhold interim leave from such people and force them into the status of criminality and exposure to the
chill winds reserved for overstayers and other illegal immigrants.

43. Ms Weston QC argues that any new policy would necessarily have to deal with those potential victims
who had no leave as well as those potential victims who, like the claimant, had extant leave entitling them


-----

to work. As regards the latter class Ms Weston QC argues that the new policy should apply the principle
embodied in section 3C of the Immigration Act 1971 and treat the reasonable grounds decision as having
the effect of extending the existing leave until the process was concluded.

44. Mr Tam QC argues that the true complaint of the claimant is about the delay that she has suffered at
each stage of her journey through the system. He does not dispute that the data appears to show a further
deterioration since Garnham J considered the statistics in late 2018. He accepts that the delay in dealing
with all three stages of the claimant's progress has been most regrettable. However, he argues that this
attack on the policy is completely misplaced when there were remedies available to the claimant in respect
of the delay that she was suffering. First, she could have sought discretionary leave outside the
Immigration Rules on the ground that she was a potential victim of trafficking and had been waiting an
unconscionably long time for a conclusive grounds decision. Had she made that application before her visa
expired then section 3C would have operated to have extended that leave until her application was
determined.

45. Second, she could make a claim for humanitarian protection or asylum if she feared harm were she to
be made to return to her homeland. Third, and similarly, she could make a human rights claim relying on
Article 4 of the European Convention on Human Rights were she to be returned to her homeland. If she
had made either of the latter two applications then an adverse decision would have attracted a right of
appeal to the First-Tier Tribunal. Therefore, as she had these alternative routes of challenge it would be
inappropriate for the court to allow a more wide-ranging attack on the policy itself.

46. As for the attacks on the policy Mr Tam QC argues that it has been formulated precisely in accordance
with the state's international obligations under ECAT. By its terms ECAT contemplates that a potential
victim of trafficking might simultaneously be present illegally in the national territory and still require
protection and recovery. See, for example, Article 13.1, which contemplates the temporary suspension of
an expulsion order.

47. In her reply Ms Weston QC characterised the three potential applications that Mr Tam QC suggests
her client might make as being straw men which required dismantling. Under the existing published policy
for the grant of discretionary leave outside the Immigration Rules the criterion is very stringent. Compelling
compassionate grounds must be demonstrated and even then the grant of leave will be very sparingly
exercised. She maintains that her client would have no chance whatsoever of being granted leave on that
ground. Similarly, the two latter claims that Mr Tam QC trailed would be essentially impossible having
regard to the fact that her homeland is New Zealand. Any decision-maker would safely assume she would
receive full protection in New Zealand if she faced any harm.

48. My conclusion is as follows. I agree with Ms Weston QC that there is an unlawful lacuna in the existing
policy inasmuch as it fails to implement the obligation in Article 10.2 formally to protect persons in receipt of
a positive reasonable grounds decision from removal from this country's national territory pending the
conclusion of the process. Suffering such persons to remain as overstayers, or as illegal immigrants, does
not fulfil the obligation. The defendant must formulate a policy that grants such persons interim
discretionary leave on such terms and conditions as are appropriate both to their existing leave positions
and to the likely delay that they will face. It is not for me to prescribe what such terms and conditions
should be. I agree with Mr Tam QC that constitutionally that is a matter reserved to the defendant.
However, the terms and conditions must obviously be lawful and this would mean that someone in the
position of the claimant, who has a time-limited right to work, should not have the arbitrary adverse
consequence of a removal of that right meted out to her simply by virtue of the delays that she is likely to
face.

49. What interim discretionary leave policy the defendant should formulate in relation to those potential
victims who have no leave of any type to be here will be a matter for her to decide.

50. I therefore will grant a declaration which incorporates my decision set out in para 48 above. I ask
counsel to seek to agree the terms of the declaration. If they cannot do so then I will rule on any disputed
wording.


-----

51. Having made my primary decision, I can deal with the discrimination claim extremely shortly. For the
reasons given by Mr Tam QC I am completely satisfied that this claim has no substance whatsoever. I do
not accept that a non-British, non-EEA potential victim of trafficking is a qualifying status for the purposes
of Article 14 of the European Convention on Human Rights. If I am wrong about that and if there is
differential treatment then in my judgment it is abundantly objectively justified as it relates to the
immigration conditions of the claimant and her comparator. It is indisputable that it is objectively justified to
dispense different treatment to two people in otherwise identical positions by reference to their immigration
statuses. That is the very essence of immigration control. I agree that this ground is devoid of merit.

52. That is my judgment.

_______________________________

**End of Document**


-----

# EOG (anonymity order made) v Secretary of State for the Home Department

 [2020] All ER (D) 37 (Dec)

[2020] EWHC 3310 (Admin)

Queen's Bench Division, Administrative Court (London)

Mostyn J

3 December 2020

**Immigration – Trafficking people for exploitation – Timescales for victim identification**
Abstract

_The claimant brought judicial review proceedings claiming, among other things, that: (1) the policy applied by the_
_defendant Secretary of State of excluding a recipient of a reasonable grounds decision from a grant of discretionary_
_leave was unlawful; and (2) the Secretary of State's refusal to treat a referral into the National Referral Mechanism_
_as an application to vary her existing visa leave, thereby extending that leave under s 3C of the_ _[Immigration Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_
_[1971, was likewise unlawful. The Administrative Court held, among other things, that there was an unlawful lacuna](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_
_in the existing policy inasmuch as it failed to implement the obligation in art 10.2 of Council of Europe Convention_
_on Action against Trafficking in Human Beings formally to protect persons in receipt of a positive reasonable_
_grounds decision from removal from the UK's national territory pending the conclusion of the process._
_Consequently, the court made a declaration to that effect and required the defendant to formulate a policy that_
_granted such persons interim discretionary leave on such terms and conditions as were appropriate both to their_
_existing leave positions and to the likely delay that they would face._
Digest

The judgment is available at: [2020] EWHC 3310 (Admin)

**Background**

The proceedings concerned a claim for judicial review concerning the policies applied by the defendant Secretary of
State in circumstances where a person was a suspected victim of trafficking.

In the UK, a person who was a suspected victim of trafficking was referred to the National Referral Mechanism
(NRM), a body within the Home Office which acted as the competent authority for the purposes of the Council of
Europe Convention on Action against Trafficking in Human Beings (ECAT). Article 10 of ECAT provided that the
process of identification had two stages. First, there was a preliminary sift to determine if there were 'reasonable
grounds' to believe that a person had been a victim of trafficking. If that decision was positive then the potential
victim: (i) could not be removed from the UK; (ii) gained the benefit of the 'recovery and reflection period' referred to
in art 13 which should last at least 30 days and which was set at 45 days in the UK; and (iii) gained entitlement to
the assistance specified in art 12(1) and (2) of ECAT. The second stage of the process of identification was for the
Single Competent Authority (SCA), the decision-making arm of the NRM, to decide on the balance of probability if
the referred person was indeed a victim of trafficking, known as the 'conclusive grounds' decision. A positive
conclusive grounds decision gave rise to an entitlement to a 45-day run-off of the interim support referred to. More
significantly, it opened the door under art 14 to the possibility of the issue of a renewable residence permit. The
policy in the UK was set out in the guidance: Discretionary Leave Considerations for Victims of Modern Slavery,


-----

the latest version of which (3.0) was issued on 9 October 2020 (the DL Guidance). It was implicit in the terms of
ECAT that the conclusive grounds decision should be taken in a reasonable time. The art 14 residence permit
would be a grant of discretionary leave. Accordingly, the policy which had been adopted, reflecting the tacit
imperative of expedition inherent in ECAT, was that a conclusive grounds decision should be made 'as soon as
possible' after the 45-day recovery period had finished, and that a decision about discretionary leave, where that
was relevant, should be made at the same time as the conclusive grounds decision or 'as soon as possible'
thereafter.

In the present case, the claimant had entered the UK on 1 September 2017, having been granted a Tier 5 Youth
Mobility Scheme Visa, which entitled her to work until 20 September 2019. case. Unfortunately, in April 2018, she
fell under the domination of a man who abused her sexually and forced her into prostitution. Eventually she
managed to escape, and on 11 September 2018, she was referred to the NRM. She did receive a reasonable
grounds decision, albeit negative, within six days. The NRM agreed to reconsider that decision. It took until 11 June
2019 for the claimant to receive a positive reasonable grounds decision. That was 273 days after her initial referral
to the NRM.

In June 2019, the claimant started work with a trafficking support organisation. She was able to do so because her
visa remained unexpired. She very much enjoyed that work and on any view her ability to do it was an important
component in her psychological and social recovery with which the state was obligated to assist her under the
terms of ECAT. However, as previously stated, her visa was due to expire on 20 September 2019. Therefore, a few
days before that, on 14 September 2019, she ceased work, and had not worked since. Since then she had been
dependant on payments from the state.

By the time that she made her judicial review application on 11 December 2019, 456 days after her initial referral,
she had not received a conclusive grounds decision. She did not receive a conclusive grounds decision until 28
April 2020, 595 days after her initial referral to the NRM. That conclusive grounds decision should have led to an
automatic consideration of discretionary leave yet at the present date, namely 26 November 2020, she had not
been granted or refused such leave. 211 days had elapsed since the conclusive grounds decision without a
decision having been made about discretionary leave: 806 days had elapsed between her initial referral to the NRM
and the present date. The effect of those delays had hit the claimant very hard.

The claimant's claim for judicial review argued that her predicament on 11 December 2019 was the consequence of
the application to her of an unlawful policy by the defendant. Specifically, she argued that: (1) the defendant's policy
of excluding a recipient of a reasonable grounds decision from a grant of discretionary leave was unlawful; and (2)
the defendant's refusal to treat a referral into the NRM as an application to vary her existing visa leave, thereby
extending that leave under s 3C of the _[Immigration Act 1971,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)_ was likewise unlawful. She argued that in
circumstances where such gross delays arose it was incumbent on the defendant to include within the existing
policy terms which regulated the leave position of a person who had received a positive reasonable grounds
decision. Further, she argued that as a non-British, non-EEA national she had been treated less favourably than a
British or EEA national for the purposes of art 14 of the European Convention on Human Rights and that that
discrimination also rendered the policy unlawful (the discrimination claim).

**Issues and decisions**

Whether the defendant's existing policies were unlawful.

The date the claimant had ceased work, 14 September 2019, had been more than a year after her referral into the
NRM. Even allowing for management and resource difficulties any reasonable estimation of the likely timescales for
decisions on reasonable grounds, conclusive grounds and discretionary leave would have led to the conclusion that
they would have been completed with plenty of time to spare within a year. The claimant therefore should have had
a not unreasonable expectation that she would have been able to have continued with her work once her visa had
expired because by then, surely, she would have reasoned, she would have gained discretionary leave. However,
that did not happen. Instead the claimant was forced to give up her employment and was cast into the 'hostile
[environment' mandated by the Immigration Act 2014 for overstayers and other illegal migrants. Consequently, as a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)


-----

result of the defendant's delay, the claimant found herself in a most unhappy situation where she, as an overstayer,
was branded a criminal (although no one had seriously suggested she would actually be prosecuted), deprived of
access to basic services, unemployed, dehumanised and penalised. She had filed some moving evidence
describing her sense of failure and emotional isolation since she had been deprived of the opportunity to work. The
treatment meted out to her was far removed from the idea of social and psychological recovery (see [31]-[33] of the
judgment).

Although ECAT had not been formally incorporated into UK domestic law, it had been held that a failure by the
government to apply its principles would be justiciable. Further, the **_[Modern Slavery Act 2015 (MSA 2015) had](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
stated in its explanatory notes that _[MSA 2015 had been passed against the backdrop of ECAT and other](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_
[international instruments and that the guidance that the Secretary of State was obliged to issue under MSA 2015 s](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C273-00000-00&context=1519360)
_[49 should take into account the international requirements set out in the Convention. The latest version of that](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C273-00000-00&context=1519360)_
guidance (version 1.02) had been re-issued in August 2020. Accordingly, ECAT was as close to being incorporated
in UK domestic law, without actually being so, as it was possible to be (see [2], [3] of the judgment).

In agreement with the claimant, there was an unlawful lacuna in the existing policy inasmuch as it failed to
implement the obligation in art 10.2 of ECAT formally to protect persons in receipt of a positive reasonable grounds
decision from removal from the UK's national territory pending the conclusion of the process. Suffering such
persons to remain as overstayers, or as illegal immigrants, did not fulfil the obligation. The defendant had to
formulate a policy that granted such persons interim discretionary leave on such terms and conditions as were
appropriate both to their existing leave positions and to the likely delay that they would face. It was not for the court
to prescribe what such terms and conditions should be: constitutionally that was a matter reserved to the defendant.
However, the terms and conditions should obviously be lawful and that would mean that someone in the claimant's
position, who had a time-limited right to work, should not have the arbitrary adverse consequence of a removal of
that right meted out to her simply by virtue of the delays that she was likely to face. What interim discretionary leave
policy the defendant should formulate in relation to those potential victims who had no leave of any type to be in the
UK would be a matter for the defendant to decide (see [48], [49] of the judgment).

With regard to the discrimination claim, For the reasons given by the defendant, that claim had no substance
whatsoever. It was not accepted that a non-British, non-EEA potential victim of trafficking was a qualifying status for
the purposes of art 14 of the Convention. If that was wrong and there was differential treatment then, it was
abundantly objectively justified as it related to the immigration conditions of the claimant and her comparator. It was
indisputable that it was objectively justified to dispense different treatment to two people in otherwise identical
positions by reference to their immigration statuses. That was the very essence of immigration control. That ground
was therefore devoid of merit (see [51] of the judgment).

A declaration would be made to the effect that there was an unlawful lacuna in the existing policy inasmuch as it
failed to implement the obligation in art 10.2 and that the defendant had to formulate a policy that granted such
persons interim discretionary leave on such terms and conditions as were appropriate both to their existing leave
positions and to the likely delay that they would face (see [50] of the judgment).

_MS (Pakistan) v Secretary of State for the Home Department_ _[2020] UKSC 9_ _[[2020] 3 All ER 733 [2020] INLR 460](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:60J0-VFB3-GXFD-805F-00000-00&context=1519360)_

_[[2020] All ER (D) 111 (Mar) applied;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5YFR-KFB3-CGXG-04P8-00000-00&context=1519360)_ _R (on the application of O and another) v Secretary of State for the Home_
_Department_ _[2019] EWHC 148 (Admin)_ _[[2019] All ER (D) 164 (Jan) followed; R (on the application of Balajigari) v](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V0C-18T2-8T41-D0RB-00000-00&context=1519360)_
_Secretary of State for the Home Department and other appeals_ _[2019] EWCA Civ 673_ _[[2019] 4 All ER 998 [2019] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5XJR-HW73-GXFD-830J-00000-00&context=1519360)_
[WLR 4647 [2019] All ER (D) 134 (Apr) considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8W0H-B402-8T41-D41B-00000-00&context=1519360)

Order accordingly.

Amanda Weston QC and Miranda Butler (instructed by Duncan Lewis Solicitors) for the claimant.

Robin Tam QC and William Irwin (instructed by The Treasury Solicitor) for the defendant.

Neneh Munu Barrister.


-----

**End of Document**


-----

