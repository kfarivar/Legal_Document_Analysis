# R v Ginar

_[[2023] EWCA Crim 1121, [2024] 2 All ER 767, [2024] 1 WLR 1264, [2023] All ER (D) 23 (Oct)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6C21-VRJ3-RSWX-K23D-00000-00&context=1519360)_

**Court: Court of Appeal, Criminal Division**
**Judgment Date: 26/09/2023**

# Catchwords & Digest


-----

# Cases referring to this case

R v Musse

_[2024] EWCA Crim 1012_
Applied

R v Arbati

_[[2024] EWCA Crim 589](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6C45-JS53-RRNV-V3FD-00000-00&context=1519360)_
Applied

# Cases considered by this case

R v Kolawole

_[[2004] EWCA Crim 3047, (2004) Times, 16 November, [2004] All ER (D) 439 (Nov)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFT1-DYBP-P55M-00000-00&context=1519360)_
Distinguished

**End of Document**


25/07/2024

CACrimD

16/05/2024

CACrimD

11/11/2004

CACrimD


-----

