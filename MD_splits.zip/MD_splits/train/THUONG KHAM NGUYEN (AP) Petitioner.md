# THUONG KHAM NGUYEN (AP) Petitioner 2022 Scot (D) 19/9

[2022] CSOH 70

Court of Session (Outer House)

OPINION OF LORD ERICHT

Petitioner: Caskie; Drummond Miller LLP

Respondent: Maciver; Office of the Advocate General

30 September 2022

**OPINION OF LORD ERICHT**
**Introduction**

[1]     The petitioner wishes to work while awaiting determination of his asylum application by the respondent. The
respondent has granted him permission to work on a restricted to the list of occupations on the Shortage
Occupation List (“SOL”), but refused him permission to work in occupations which are not specified in that list. The
petitioner seeks reduction of that refusal.
**The application for permission to work**

[2]     On 7 April 2021 the petitioner's solicitors applied on the petitioner's behalf for permission to work in the
following terms:

“Please note this client has been waiting over 12 months for a decision on his asylum case. Please now grant him
permission to work. Please note our client is still waiting to receive an invitation to attend his substantive interview
at the Home Office. We would be grateful if an interview could be arranged.

Our client is finding failure to work is impacting on his mental health. He is depressed at having to wait so long for a
decision on his application. It is affecting his mental state. He is in a state of anxiety. He is a victim of trafficking. He
was forced to work in China. He bears scars on his head from beatings he received. He has none of the skills
required for the Shortage Occupation List. Further to this, we would be grateful if he could be afforded the
opportunity to work outside of the Shortage Occupation List. He was unable to continue school in Vietnam past
Grade 9. His education is very limited.

Our client worries regarding his case. He has trouble sleeping. He has nightmares about his experiences. During
the day he stays in his room. He does not have the opportunity to integrate with others. He would be better able to
integrate were he working. This would afford him a greater sense of meaning in life. In these circumstances kindly
exercise your discretion. Kindly grant him permission to work in jobs outside of the Shortage Occupation List. This
would help him in that he is much more likely to find work. He believes he would be a lot happier and less anxious
were he afforded permission to work in occupations outwith the SOL. He believes his stress would be greatly
reduced were he to be able to find work outside the SOL. He has few qualifications which would enable him to work
within the SOL. ….”

[3]     On 5 October 2021 the respondent replied as follow:


-----

“You have asked whether you may take employment while your application for asylum is being considered. This
letter is a grant of permission to work in principle pending you obtaining the appropriate Application Registration
Card (see paragraphs below).

Please note that employment is restricted to posts listed on the Migration Advisory Committee's (MAC) Shortage
Occupation List (SOL). Information about the SOL can be found on the Home Office website: www.gov.uk/uk-visasimmigration. This permission does not give you permission to be self-employed or to engage in business or
professional activity.”

[4]     By letter dated 16 November 2021 the petitioner's solicitors asked the respondent to reconsider the grant of
permission to work the decision dated 5 October 2021, stating:

“In our submission the decision to restrict the grant of permission to work to the Shortage Occupation List (SOL) is
unlawful.

It is submitted that the decision has failed to have adequate regard to the terms of IJ (Kosovo) v SSHD _[2020]_
_EWHC 3487 (Admin). By restricting the grant of permission it is submitted that the Secretary of State has failed to_
pay attention to the particular circumstances of our client. The Secretary of State has failed to give adequate
consideration to the fact that our client is a victim of trafficking. The Secretary of State has failed to adequately
consider our client's history and the effect his trafficking experience has had on him, and the benefit he would
receive were he afforded permission to work outside of the SOL. In our submission the Secretary of State's failure
to grant discretionary leave to remain as a victim of trafficking/ modern slavery is also unlawful. We refer to the
case of KTT v SSHD [2021] EWHC 2722 (Admin) in relation to this. The court found that the pursuit of an asylum
claim based on a fear of being re-trafficked is a relevant 'personal situation' within the meaning of Article 14 ECHR
and may therefore require a grant of leave to those whose stay is necessary for that purpose. It is submitted that if
discretionary leave was granted to our client he would have permission to work in the UK.

In any event this client has now been waiting more than two years for a decision on his case. To date he is still
waiting for the Home Office to invite him to his substantive interview. A relevant matter for the Secretary of State to
consider is that she has permitted the backlog of asylum seekers who have waited over a year for a decision to
grow to over 70,000 people. It is likely that our client's claim will remain outstanding for the foreseeable future.

It is submitted that in the meantime it would be unjustifiable for permission to work to be restricted to the SOL given
the various benefits that were set out in the original application.”

[5]     The respondent replied on 29 November 2021 stating:

“5. Response to the matters raised

i) We have spoken to the relevant team and they have advised that they have decided not to exercise discretion in
order to grant your client Permission to Work outside the Shortage Occupation List. They have advised that despite
your client's claim to have been trafficked and the impact this has had on him, his circumstances are not different
from other Asylum seekers, and do not justify a grant of Permission to Work outside the Shortage Occupation List.

ii) Please find attached a copy of the decision letter dated 26 November 2021 setting out full reasons for this
decision.

iii) Consequently the decision to restrict your client's grant of Permission to Work to the Shortage Occupation List is
maintained.”

[6]     The decision letter of 26 November 2021 was in the following terms:

“I have considered whether or not discretion should be exercised in the applicants favour to grant permission to
work (PTW) unrestricted to occupations on the Shortage Occupation List (SOL).


-----

The Immigration Rules are designed to provide for the vast majority of those who request permission to work, whilst
their asylum claim is outstanding. Where the criteria under Paragraph 360 of the Immigration Rules is not met, it will
normally be justifiable to refuse such a request. However, the Secretary of State has the ability to exercise
discretion within such a consideration and the Secretary of State has the power to grant permission to work
[unrestricted to occupations on the SOL, which flows from residual discretion under the Immigration Act 1971, where](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8G0-TWPY-Y1GP-00000-00&context=1519360)
it could or would be unjustifiable.

You assert that as the applicant is a victim of trafficking, and due to the effect that his trafficking experience has had
on him, he should be afforded permission to work outside the SOL.

The Mental Health Foundation report of 2016 entitled 'Fundamental Facts About Mental Health' states 'A 2015
study found that one third of trafficked boys and girls had experienced physical or sexual violence (or both) and, of
those, 23% had sustained a serious injury. Mental health issues were common: more than half of young trafficked
survivors (56%) screened positive for depression, a third (33%) for an anxiety disorder and a quarter (26%) for
PTSD. 12% reported that they had tried to harm or kill themselves in the month before the interview, while 15.8%
reported having suicidal thoughts in the past month.' (page 44).

Therefore, distressing as the applicants situation is, this does not distinguish him from any other asylum seeking
applicant who asserts they are a victim of trafficking. Careful consideration has been given to the European
Convention on Action against Trafficking and in particular the applicants physical, psychological and social recovery
needs.

Whilst it is noted that you assert that the trafficking experience has had an impact on him, it is considered that the
applicant is able to volunteer to work. They are able to do so at large charitable organisations, which also acts as a
means of avoiding being taken advantage of, allows the same benefits to your mental health and helps integrate
with society.

Therefore PTW unrestricted to the SOL is refused.

Volunteers are those who give their time for free to charitable or public sector organisations without any contractual
obligation or entitlement. They are not employees or workers as defined by various statutory provisions.

Volunteering can be undertaken at any stage of the asylum process but such activities must not interfere with
scheduled events such as a substantive asylum interview, regular reporting event or re-documentation interview.
These events will not be rescheduled to accommodate volunteering. Organisations offering such opportunities will
need to allow some flexibility so that volunteers can attend interviews or appointments around their volunteering.
Volunteering must also not undermine the effective removal of those who do not need protection and do not qualify
to remain in the UK on any other basis.

Asylum seekers can volunteer whilst their claim is considered without being granted permission to work. It is Home
Office policy to support asylum seekers volunteering for charities or public sector organisations….

To summarise, the principal difference is that volunteering must not amount to unpaid work, or job substitution. In
particular:

- there should be no payment, other than reasonable travel and meals expenditure actually incurred (not an
allowance for the same)

- there should be no contractual obligations on the volunteer and they should not enjoy any contractual entitlement
to any work or benefits

- the volunteer is helping a registered voluntary or charitable organisation, an organisation that raises funds for
either of these, or a public sector organisation

- volunteering is not a substitute for employment, that is fulfilling a role that a salaried worker would normally fulfil.”


-----

[7]     In this judicial review the petitioner seeks reduction of the decision dated 26 November 2021.
**Immigration Rules and Guidance**

[8]     Rule 360 of the Immigration Rules is as follows:

“360 An asylum applicant may apply to the Secretary of State for permission to take up employment if a decision at
first instance has not been taken on the applicant's asylum application within one year of the date on which it was
recorded. The Secretary of State shall only consider such an application if, in the Secretary of State's opinion, any
delay in reaching a decision at first instance cannot be attributed to the applicant. 360A If permission to take up
employment is granted under paragraph 360, that permission will be subject to the following restrictions:

(i)   employment may only be taken up in a post which is, at the time an offer of employment is accepted,
included on the list of shortage occupations published by the United Kingdom Border Agency (as that list is
amended from time to time);

(ii)   no work in a self-employed capacity; and

(iii)   no engagement in setting up a business.

360B If an asylum applicant is granted permission to take up employment under paragraph 360 this shall only be
until such time as his asylum application has been finally determined.”

[9]     The list of shortage occupations is set out in an appendix to the Immigration Rules. The list specifies certain
posts which require particular qualifications or skill (eg engineers, scientists, programmers and software
professionals, musicians and dancers). It also contains occupations for which a high level of qualification or skill is
not required, for example care assistant, care worker, carer, home care assistant, home carer and support worker.

[10]     The respondent has a residual discretion to permit an asylum seeker to work in a job not specified on the
SOL. The respondent has published guidance to Home Office staff about handling requests for permission to work
(Permission to work and volunteering for asylum seekers, 4 May 2021). In relation to the residual discretion to
permit asylum seeker to work in a job not specified on the SOL, the guidance states:

“Application of discretion

Where the Immigration Rules are not met, it will be justifiable to refuse an application for permission to work unless
there are exceptional circumstances raised by the claimant. If caseworkers consider that the circumstances of an
application are exceptional they should refer the matter to a technical specialist to review whether the matter should
[be considered on a discretionary basis (under our residual discretion flowing from Section 3 of the Immigration Act](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-B8H0-TWPY-Y09P-00000-00&context=1519360)
1971). Such discretion would allow a grant of permission to work, notwithstanding the requirements of the
Immigration Rules. What amounts to exceptional circumstances will depend upon the particular facts of each case.
A grant of permission to work on a discretionary basis is expected to be rare and only in exceptional circumstances.

In cases involving victims and potential victims of trafficking the primary objectives of the Council of Europe
Convention on Action against Trafficking in Human Beings (ECAT) will be a relevant consideration, particularly with
regards to their physical, psychological and social recovery. The caseworker should consider all the factual
information and evidence submitted ensuring it is fully addressed particularly where a decision has been taken to
consider the application on a discretionary basis.”
**Submissions for petitioner**

[11]     Counsel for the petitioner submitted that should the petitioner succeed, it would be for the Secretary of
State to address that in her policy if required (Craig v _HMA_ [2022] 1 WLR 1270 paragraph 44-46; _SK (Japan)_ v
_SSHD 2013 SLT 74). While it was for the respondent to define her policy, it was for the court to determine the true_
meaning of the policy and determine whether the application of the policy in all relevant circumstances meant that
the decision in a particular case was lawful.

[12]     Counsel submitted that the lives of asylum seekers who are prevented from working was generally
significantly more difficult than those who were not A person prevented from working required to live on only £36


-----

per week which may be reasonable for a limited period but not long-term. Counsel's position was that restricting
permission to work where a claim for asylum had been outstanding for a year or less was not unreasonable, and
the policy of easing that restriction for asylum seekers who had seen their claim outstanding for over a year to jobs
on the shortage list was not per se unreasonable. However, where the period involved extended far beyond a year
before an asylum decision was issued, the policy of having no long stop on how long the restriction to working on
jobs on the shortage occupation list is applied becomes unreasonable.

[13]     Counsel submitted that the world had changed since _R (Rostami)_ v _Secretary of State for the Home_
_Department [2013] EWHC 1494 (Admin). There was full employment. The number of asylum applications made in_
the United Kingdom was fairly stable between 2005 and 2020. The number of asylum applications increased
significantly in 2021 largely due to increasing numbers of arrival by small boats. The trend of increasing numbers of
asylum claims at the end of 2021 had continued into 2022. 5,902 asylum claims were made in the period January to
March 2021 compared to 12,508 in the period January to March 2022. That substantial increase was not fully
explained by small boat arrivals. 1,363 entered by small boat between January and March 2021 compared to 4,540
between January and March 2022, representing a threefold increase. The top five nationalities entering by small
boat in the first quarter of 2022 were Afghan, Iranian, Iraqi, Syrian and Eritrean, all of whom have very high chance
of being granted asylum.

[14]     Counsel further submitted that the stand out problem of the asylum system today was the time it takes for
decisions to be made, which was a recent development: the backlog of asylum seekers waiting more than 6 months
for a decision to be made had trebled since 2019. There is a 20 week wait even to register an asylum claim. At the
end of March 2022, there was a backlog of 89,344 cases awaiting an initial decision for asylum claims made since
2006, which number had more than quadrupled since the end of 2016. The reason for the growing delays was that
fewer decisions were being made and the number of asylum claims had increased. Despite an increase in staffing
levels, the percentage of cases in which a decision is being made within 6 months had declined drastically since
2014. This has led to more asylum seekers being provided with support during their claim and having their right to
work curtailed, which means additional short term cost to the taxpayer. It also means longer term costs because the
longer a person is out of work, the harder it is re-enter the labour market. The majority of asylum seekers will
ultimately be recognised as refugees and allowed to remain in the United Kingdom long term, and are more likely to
do so with mental health problems arising during the extended delay.

[15]     Counsel further submitted that in the year ended March 2022, 75% of initial asylum decisions were grants
of protection. Success rate for some nationalities was very high (Afghanistan 91%, Eritrea 97%, Iran 88%, Sudan
95%, Syria 98%). Some of those refused protection would go on to win their appeals. The average time for the
First-tier Tribunal to decide an asylum case was 48 weeks in the period July to September 2021.

[16]     Counsel submitted that the above was relevant to the reasonableness of restricting permission to work to
the SOL to this petitioner. Those factors compound the individual characteristics of the petitioner, the combination
of which factors means the decision was unlawful in particular in the absence of reasoning. The specific
circumstances distinguish the petitioner from the majority of asylum seekers. Few asylum seekers are from Vietnam
and even fewer Vietnamese asylum seekers find being unable to work affects their mental health. Working would
provide an opportunity to integrate in a country where he has a very high prospect of making his permanent home.
The respondent erred in looking for exceptional circumstances in a cohort which was all the same. Unpaid
volunteering did not have the mental health benefits of paid work.
**Submissions for the respondent**

[17]     Counsel submitted that “rare” or “exceptional” were not a test to be passed, but merely an indication of the
expectation that the respondent will exercise her discretionary power to grant permission to work beyond that
envisaged by the rules infrequently and only in exceptional circumstances. The purpose of these words was not to
fetter her discretion. The exercise of that discretion is a matter for the respondent and not the court. The court's
function is to assess whether the respondent properly assessed the petitioner's request, and she did so. There was
no error of law. Counsel further submitted the respondent was entitled to conclude from the material cited by her
that there are large numbers of persons who claim to be victims of trafficking and who display mental health
difficulties, and accordingly the petitioner's circumstances were not exceptional.


-----

[18]     Counsel submitted that the respondent took full account of the relevant circumstances and was entitled to
reach the decision which she had. The petitioner's assertions regarding the asylum backlog, the overall success
rates or the broader policy factors were not relevant matters. It is for the Secretary of State to formulate policy and
she enjoys a wide margin of discretion in doing so (Rostami).

[19]     Counsel further submitted that the personal circumstances of the petitioner were taken into account, and
the petitioner's arguments were made on the premise that the petitioner had either been recognised as a victim of
trafficking or would be granted asylum, both of which were hypothetical.
**Analysis and decision**

[20]     The petitioner's main ground of challenge was directed at asylum seekers not being permitted to work
while awaiting an asylum decision. There was also a challenge to the reasons for the decision in this particular
case.
**Restrictions on work by asylum seekers**

[21]     In this petition the petitioner seeks to bring under review the same matter which was considered in
_Rostami, namely:_

“Under domestic rules, once an application has been pending for a year, an asylum seeker may apply to the
Secretary of State for permission to take up employment. However, if permission is granted, it is subject to the
restriction that employment can only be taken up if the relevant job is included on a list of specific occupations
published by the Secretary of State from time-to-time ('the Shortage Occupation List', or 'the SOL'). It is that
restriction which is challenged in this claim. ” (Rostami, paragraph 2).

[22]     That restriction was examined in detail in Rostami and found to be lawful.

[23]     The court explained the background to the restriction:

“44. The 'list of shortage occupations published by the UK Border Agency' (the SOL) which informs the restriction
on employment set out in paragraph 360A(i) (for initial applicants) and 360D(i) (for subsequent applicants) is a
reference to a list of jobs originally developed under the work permit arrangements, and later as part of the eligibility
criteria for Tier 2 (General) Migrants of the Point Based System. Under that system, skilled workers may migrate to
the UK for up to three years to undertake work for employers with a sponsorship licence, to do jobs in 'shortage
occupations', i.e. jobs that cannot readily be filled from the resident labour market. Other than ministers of religion,
elite sportspeople and skilled workers moving from an overseas branch of a company to a UK branch, under the
Points Based System only those who are able to undertake such employment are able to come to the UK for the
specific purpose of work.

45. The SOL is prepared by the Secretary of State following advice from the Migration Advisory Committee ('the
MAC'), an independent non-departmental public body comprising labour market economists and migration experts,
commissioned by the UK Government to review the UK labour market to identify where labour market shortages
exist in the UK (i.e. as to where there are occupations in which it is not possible to fill vacancies by recourse only to
UK nationals, other EU citizens and others with a right to work in the UK), using published methodology which is not
challenged in these proceedings. Such occupations are recommended for designation as shortage occupations. It
recommended its initial list in September 2008, and has reviewed that list regularly since. The MAC having made its
recommendations, the Secretary of State determines the final list. Prior to July 2012, the SOL was incorporated into
guidance issued by the Secretary of State, namely the Occupation Codes of Practice: since then, it has been
incorporated directly into the Immigration Rules as tables set out in Appendix K ....”

[24]     In coming to the conclusion that the restriction was lawful, the court stated:

“81 Paragraphs 360A(i) and 360D(i) of the Immigration Rules, and the SOL which they introduce as a restriction on
employment of asylum seekers, therefore has the main public policy objective of ensuring that asylum seekers are
granted access to the UK labour market without adversely impacting on UK nationals and other EU citizens, as they
are only granted access to jobs identified as ones which the resident labour market are unable to fill….


-----

92. Nor do I consider [the SOL] restriction disproportionate. In coming to that conclusion, I have taken into account
all of the matters raised before me, including those to which I have referred above, but, particularly, the following.

...

iii) The SOL achieves a number of legitimate and linked public interest objectives. In the labour market, it seeks to
prioritise the citizens of the UK and the rest of the EU territories, a legitimate public policy which, as I have indicated
in (ii) above, is specifically recognised in article 11 of the Reception Directive: it thus ensures that asylum seekers
are granted access to the UK labour market without adversely impacting on UK nationals or other EU citizens, as
they are only filling positions that have been identified as requiring skills which resident labour can fill. By doing so,
UK work output is also increased. It also seeks to place asylum seekers in no better position than economic
migrants who seek to come to the UK under the Points Based System. That discourages economic migrants from
making unmeritorious asylum claims to obtain a preference in the labour market. That too is a legitimate political
aim. These are strong public interest factors. The protection of the domestic labour force is particularly weighty
factor at times of rising unemployment amongst UK nationals and other EU citizens.

iv) Furthermore, we are here in an area of policy within the scope of immigration, social benefits and economic
strategy. In such areas of high policy, the State has a wide margin of appreciation, because they involve the
balancing of particularly important public interest factors and the rights and interests of individuals. Those
individuals include not only the Claimant and other asylum seekers, but also individuals who do have a right to work
but are or may become unemployed. In such areas, the courts are particularly cautious before interfering with
decisions made by the State.

…

viii) The national and hence public interest in ensuring that foreign workers are directed to occupations where a
shortage of skilled labour has been identified, together with the interests of those individuals with a right to work in
the UK as a result of their citizenship, have to be balanced against the interests of asylum seekers to obtain
employment in jobs in which UK nationals and/or other EU citizens could and would otherwise be engaged.

…

xii) Leaving aside the obvious financial benefits that accrue from employment, I do not find that the inability to work,
in itself, has had any significant adverse effect on the Claimant, or on asylum seekers as a whole. He, and they,
suffer from low income and generally being in limbo, during consideration of their asylum applications; but not
specifically from an inability to work. There is no 13

compelling evidence that the Claimant, or asylum seekers generally, suffer to any significant extent by an inability to
make social contact through work.

…

93.   In the circumstances, in my judgment, the imposition of a condition on asylum seekers access to the
labour market, restricting such employment to jobs which UK nationals and other EU citizens are unable to
fill, is both necessary and appropriate in pursuit of the legitimate public interest in protecting the domestic
labour force. …. It seems to me impossible to say that the Secretary of State has failed to strike an
appropriate balance between the interests of asylum seekers in working on the one hand, and the public
interest in ensuring that positions taken by such individuals does not adversely affect the rights to work of
UK nationals and other EU citizens to work. … …

97.   There is, therefore, nothing unlawful in the Secretary of State prescribing a list to which employment
of asylum seekers will be restricted. It is noteworthy that other Member States have adopted a similar
approach, without criticism or comment from the European Commission (see paragraph 85 above).”

[25]     Counsel for the petitioner sought to persuade me that the increase in numbers of asylum seekers and the
delay in making decisions since the Rostami case constitute a change of circumstances which make it necessary


-----

that the policy of restriction of permission to SOL be reviewed. However, that is a political issue which falls within
the province of the respondent. It is not a legal issue for a decision by a court. The law as set out in _Rostami_
remains the law. An increase in numbers of asylum seekers or delay in dealing with applications makes no
difference to the reasoning set out in _Rostami_ as to the public interest objectives of the restriction, or the wide
margin of appreciation enjoyed by the state in these matters of high policy. As there is no material change of
circumstances which would permit the court to depart from Rostami, the decision in Rostami remains an accurate
statement of the law and should be followed.

[26]     A further criticism of the restriction made by counsel for the petitioner was that few asylum seekers had
the skills for the posts in the SOL. That is not a ground on which I can depart from Rostami. There is nothing new in
that criticism: it also applied at the time of _Rostami. Indeed, since the date of_ _Rostami, it has become easier for_
asylum seekers to find a post in the SOL: the list has been expanded by the addition of care jobs which require little
by way of formal qualification. Counsel submitted that this made no difference as asylum seekers would be
excluded from these jobs because it would not be possible to obtain from their home countries the information
about criminal records needed for protection of vulnerable group checks in the UK to obtain these jobs. That is
patently not the case for all asylum seekers: in another judicial review which I have considered recently an asylum
seeker was able to obtain employment as a carer (Bakushev v SSHD 2022 CSOH 67.
**The decision in respect of the petitioner**

[27]     Despite the extensive arguments before me criticising the SOL restriction in Rule 360, the actual decision
being challenged in this judicial review is not made under Rule 360. It is a decision made in exercise of the residual
discretion of the respondent to grant permission to work outwith Rule 360.

[28]     The respondent's guidance makes clear that the residual discretion may be exercised in exceptional
circumstances. What amounts to exceptional circumstances will vary depending on the particular facts of each
case. A grant of permission to work on a discretionary basis is expected to be rare and only in exceptional
circumstances.

[29]     In this case, petitioner wished the discretion to be exercised in his favour due to the effect that his
trafficking experience had on him.

[30]     The respondent was entitled to find that this did not distinguish him from any other asylum seeker who
asserts they are a victim of trafficking. The quotation in the Mental Health Foundation 2016 report in the decision
letter demonstrates that mental health issues were common in trafficked boys and girls. It would appear that the
inclusion of that particular paragraph may have an error by the respondent, as the petitioner was an adult. However
that error was not material, as the other paragraphs in the same page of the report from which the quotation is
taken make clear that mental health issues are common among asylum seekers. I do not accept the petitioner's
argument that the respondent erred in looking for exceptional circumstances in a cohort which was all the same. It
was not the respondent but the petitioner who fell into that error. The circumstances which the petitioner sought to
categorize as exceptional (ie mental health issues) were in fact not exceptional at all but were common. As mental
health issues are common, the respondent was entitled not to exercise the discretion which she had indicated
would only be used in rare and exceptional circumstances.

[31]     The decision letter went on to explain that the petitioner was permitted to do voluntary work, which,
according to the letter, allows the same benefits to mental health and helps with integration into society. Counsel for
the petitioner took issue with this and sought to draw a distinction between paid and unpaid work. I do not accept
the petitioner's proposition that work gives dignity and mental health benefits only if it is paid for. Useful work can be
of benefit to mental health whether or not it is paid. In any event, there was no evidence before the respondent
when the decision was made, nor before me, that the mental health of this particular petitioner would improve only if
he did work which was paid and not if he did work which was unpaid.

[32]     In my opinion, the petition does not disclose any error of law on the part of the respondent. She
considered all the circumstances presented by the petitioner in his application. She concluded, consistent with her
policy, that there were no exceptional circumstances such that she should grant him permission to work beyond that
i d i th I i ti R l hi h h h d l d t d t hi Th t tt f h di ti d


-----

was a conclusion that she was entitled to reach. She left nothing out of account in doing so. I shall dismiss the
petition.
**Order**

[33]     I shall uphold the respondent's third plea-in-law, repel the petitioner's plea-in-law and dismiss the petition.

**End of Document**


-----

