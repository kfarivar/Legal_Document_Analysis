# R v Michael Joyce [2020] EWCA Crim 1887

CA, CRIMINAL DIVISION

201904612 A4

Lindblom LJ, Hilliard J, HHJ Flewitt

Tuesday, 25 February 2020

25/02/2020

LORD JUSTICE LINDBLOM:

1 On 1 August 2019, in the Crown Court at Oxford before His Honour Judge Pringle Q.C., the appellant, Michael
Joyce, was convicted on two counts of requiring a person to perform forced or compulsory labour, contrary to
s.1(1)(B) of the **_Modern Slavery Act 2015, two counts of arranging or facilitating travel of another person with a_**
view to exploitation, contrary to s.2(1) of 2015 Act, and one count of carrying on a regulated activity when not an
authorised person, contrary to s.23(1) of the Financial Services and Markets Act 2000.

2 On 6 August 2019, the judge sentenced the appellant to a total of five years' imprisonment. The total period of
the appellant's remand in custody before he was sentenced, which we understand to have been 238 days,
automatically count towards his sentence. We are told that his earliest date of release is 5 June 2021.

3 The appellant's application for leave to appeal against sentence has been granted by the single judge. The only
issue raised in the appeal concerns the calculation of the appropriate credit for 185 days spent on qualifying curfew
under s.220A of the Criminal Justice Act 2003, a matter that can be rectified on the papers, under s.22(2)(a) of the
Criminal Appeals Act 1978. The single judge granted an extension of time of 105 days.

4 Section 240A of 2003 Act provides that the court must direct that the credit period is to count as time served as
part of the sentence. The credit period is the number of days on which the offender was subject to such conditions;
minus any days to which steps 2 or 3 apply, and, if the last day was spent partially in custody, that day; divided by
two; and rounded up to the nearest whole number.

5 In sentencing the appellant, the judge did not direct that the credit period was to count as part of his sentence.
Indeed, at the sentencing hearing no mention seems to have been made of the days spent on qualifying curfew.
The prosecution has confirmed in an email to the Criminal Appeal Office dated 15 January 2020 that it accepts that
the number of days spent by the appellant on qualifying curfew is 185 days. When halved, that number of days
gives a credit period of 93 days, which ought to have been credited.

6 Accordingly, we allow the appeal, and direct that the number of days under s.240A of the 2003 Act is 93 days.

_____________________

**End of Document**


-----

