(Admin)

# *R (on the application of Galdikas and others) v Secretary of State for the
 Home Department [2016] EWHC 942 (Admin)

Queen's Bench Division, Administrative Court (London)

Sir Stephen Silber

26 April 2016Judgment

**Martin Westgate QC and Catherine Meredith (instructed by Leigh Day) for the Claimants**

**David Blundell (instructed by Government Legal Department) for the Defendants**

**The Interested Parties took no part in the proceedings and were not represented at the hearing**

Hearing dates: 9th and 10th March 2016

Further Written Submissions 14th and 31st March 2016 and on 11th and 18th April 2016

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Sir Stephen Silber :**

**Introduction**

1. The United Kingdom Government considers that human trafficking is a form of **_modern slavery,_**
because the essence of it is that its victims are coerced or deceived into situations where they are
exploited. The United Kingdom has opted into the EU's Trafficking Directive 2011/36 (“the Directive”),
which requires the United Kingdom authorities to set up a regime for providing support for those who have
been recognised as victims of trafficking. The Home Office and the Ministry of Justice have jointly funded a
national support service for adult victims of trafficking in England and Wales under a victim care contract,
which provides vulnerable victims of trafficking with care and support. This case is not concerned with the
issue of whether particular individuals should be recognised as victims of trafficking, but instead it raises
questions concerning the support that such victims should continue to receive after a conclusive grounds
decision has been made that they are actually victims of trafficking.

2. The present application is principally concerned with the issue of whether there has been a failure by
the Secretary of State for the Home Department (“SSHD”)1 and by the Secretary of State for Work and
Pensions (“SSWP”)2 to put in place a comprehensive support regime for recognised victims of human
trafficking in accordance with the United Kingdom's obligations, in particular after the conclusion of the 45day recovery and reflection period in which those victims are entitled to assistance and support. The relief
sought is principally concerned with the nature and legality of the regime in force and more particularly if
the regime is compatible with EU law and public international law. The Claimants' case is brought with the
assistance of evidence from Ms Phillipa Roberts, who is the Legal Director of Hope for Justice (“HFJ”),
which is described as an “anti-trafficking charity” and which assists victims of trafficking. The Defendants'
case is supported by evidence from Ms Helen Sayeed of the Asylum, Strategy and Trafficking Team at the
Home Office


-----

(Admin)

**The Support Regime for Victims of Trafficking**

3. To understand the submissions, it is necessary to explain the support regime in place in the United
Kingdom for the victims of trafficking and which is explained in the SSHD's Victims of **_Modern Slavery:_**
Competent Authority Guidance (July 2015) (“the Guidance”). As this claim relates to those who are
conclusively found to be the victims of trafficking, I will only describe the four-stage procedure applicable to
those victims and I will not explain the procedure in relation to those who are not found to be the victims of
trafficking.

4. The first step under the support regime is the identification of potential victims of trafficking so that they
can then be referred to the National Referral Mechanism (“NRM”), which is a victim identification and
support process. The second stage of the NRM is to make what is called “a reasonable grounds decision”
which is a decision as to whether there are reasonable grounds for believing that the person referred may
be a victim of trafficking. If such a decision is arrived at in respect of that person, there is then the third
stage of the NRM is that the person concerned is given a minimum of a 45-day recovery and reflection
period3 whilst the appropriate body makes a substantive conclusive grounds decision on the trafficking
claim. As I will explain, support to meet the immediate and ongoing needs of the potential victim is provided
during that period and this usually comprises the provision of accommodation and cash payments. The
fourth stage of the NRM is the “conclusive grounds decision” which is a substantive decision that there is
sufficient information to find that the person concerned is a victim of trafficking. This decision should be
taken after a minimum of 45 calendar days, and if it is not made within that period of 45 days, then, as I will
explain, the support provided may be extended for a further period. The challenge in this case centres on
the nature of the duty to provide material support beyond the end of the 45-day period recovery and
reflection period.

5. The support provided is given by a national support service for adult victims of trafficking under a victim
care contract, which is jointly funded by the Home Office and the Ministry of Justice. The victim care
contract is delivered in England and Wales by the Salvation Army, which supports victims whilst they
remain in the NRM. Everybody who receives a positive conclusive grounds decision at the end of the
recovery and reflection period is then entitled under the contract with the Salvation Army to a further
support period of 14 days. The Defendants' case is that the Home Office considers on a case-by-case
basis whether to grant extensions of support to those periods for those with positive conclusive grounds
decisions, like the Claimants in this action.

6. The case for the Claimants is that the present system lacks the capacity to react appropriately to the
needs of victims with the result that gaps in the provision of necessary support are inherently likely and
they cannot be explained as mere aberrant decisions in individual cases. In particular it is contended that
there is no requirement in the Guidance or in the contract with the Salvation Army requiring routine
assessments of need in individual cases after the 45-day recovery and reflection period and no criteria as
to when support is to be provided pending a decision on an application for Discretionary Leave to Remain
(“DLR”) which is the way in which the United Kingdom gives support and assistance to trafficking victims in
accordance with its international obligations. The case for the Defendants is that there is discretionary
power to extend the 45-day period and to grant discretionary extensions of this period to support them.
The Claimants' case is that this is inadequate, as the discretionary power to extend the 45-day period is
subject to highly restrictive conditions and the discretionary extensions are based on an unstructured
discretion exercisable only on a request made by the Salvation Army. It is said that support often expires
before a solution is reached.

7. A person who is accepted as a victim of trafficking may be granted DLR, but he or she is not
automatically entitled to that leave as a direct result of conclusively being accepted as a victim of
trafficking. To obtain DLR, a victim of trafficking must meet certain specified criteria, such as that in their
cases there are particularly compelling circumstances which justify a grant of DLR. Nationals of the
European Economic Area (“EEA”) who are accepted as being victims of trafficking retain their ability to
exercise free movement rights in accordance with EU Regulations. There might be some circumstances in
which an EEA national who was a trafficking victim is unable to exercise their free movement rights and in


-----

(Admin)

those circumstances, the Home Office would consider any request for DLR in line with its published policy.
A person granted DLR is entitled to all mainstream benefits. There is evidence that the 14-day extra
support period is insufficient time for victims to apply for DLR and to receive a response to their
applications as such applications often take a very much longer period to process.

**The Claimants**

8. The background of each Claimant is not in dispute. They are all nationals of the EEA and they have all
been conclusively recognised as victims of trafficking. At the time when they were so recognised as
trafficking victims, the Claimants qualified for and were granted income-related Jobseeker's Allowance
(“JSA”), but their entitlement to this benefit ceased in 2014 following changes to the Immigration (EEA)
Regulations 2006 (SI/2006/1003) (“ the EEA regulations”) came into effect. This set a time limit on the right
of EEA nationals to reside in the United Kingdom as a job seeker unless they could show compelling
evidence of a genuine prospect of work (“the GPOW test”). Since 2014, EEA nationals will be unable to
obtain JSA until they have been in the country for 3 months.

9. The Claimants, Antanas Galdikas (“AG”) and Rimantas Tamosatis (“RT”) have applied for DLR in the
United Kingdom and if their applications were to be granted, they would become entitled to claim their
benefits. No decision has been made on RT's application, which was made on 3 July 2015. On 15
December 2015, the Home Office wrote to RT's representatives to request further information relating to
RT's circumstances and his case remains under active consideration.

10. AG's application, which was made on 20 July 2015, was rejected as “void” on 3 February 2016 by
United Kingdom Visas and Immigration because he is an EU National and therefore he does not need a
visa. The SSHD accepts that this was an error and, on 15 February 2016, the Home Office wrote to him
stating that it would reopen his application and it invited him to resubmit his application. This was duly
received on 23 February 2016 and I believe that it is still under active consideration. AG and RT are not
involved in a criminal investigation relating to those who trafficked them although there remains the
possibility of a new international investigation by Kent Police and the Lithuanian authorities or domestically
by or with the National Crime Agency.

11. The other Claimants are male twins called Edgaras Subatkis and Edvianas Subatkis, who had cooperated with the police. The SSHD's Guidance requires the investigating police force to make a request
for DLR for these Claimants and I will return in paragraphs 70 to 77 to consider the fairness and validity of
this requirement. On 18 November 2015, the Claimant's solicitors wrote to the police asking them to make
the request urgently, but the police replied that “this process was no longer required”. The Guidance states
that victims of trafficking and their legal representatives should not make applications directly to the Home
Office where the victim is helping the police with their enquiries. These Claimants were due to give
evidence in a criminal trial which took place on 11 January 2016, but they did not do so as the defendants
in that trial pleaded guilty. They fear reprisals from the contacts and family of their traffickers if they are
returned to Lithuania. Mrs Sayeed has explained that these Claimants have remained in the United
Kingdom receiving local authority support. The Home Office wrote to these Claimants on 2 March 2016 to
say that they could not find any record of any DLR application on their behalf. As criminal proceedings
have finished, the Claimants will have to apply for DLR on one of the other bases, either the need to be
present for a civil claim or their own personal circumstances. The letter of 2 March 2016 included a link to
an application form for leave on that basis. The evidence of Edgaras Subatkiss shows that they are highly
likely to pursue this application.

12. All the Claimants have therefore been unable to claim state benefits, even though they have no other
means of support. The Defendants contend that they are not obliged to offer any support to these particular
Claimants after the conclusion of the 45-day recovery and reflection period. So the Defendants have not
offered them any support. Pending the outcome of the present claims, the Claimants are all currently
receiving support from their local authorities, who are the Second and Third Interested Parties in these
claims, but they, like the other Interested Party, have taken no part in the proceedings.


-----

(Admin)

13. At present, there is a regime in which those who are recognised as victims of trafficking are entitled to
a 45-day reflection and recovery period. This application raises the issue of whether those victims are
entitled to assistance and support after that period and if so, in what circumstances. This issue entails
considering the inter-relationship, enforceability and the construction of:

(a)  The Council of Europe Convention on Action Against Trafficking in Human Beings (“ECAT”) which has
been ratified in the United Kingdom but which has not been incorporated into domestic law and in particular
Article 124 of it;

(b) The Directive and in particular Article 11(2)5 of it; and

(c) The Guidance, which sets out how the SSHD has sought to comply with any obligations she might
have under ECAT and the Directive.

14. There is a substantial dispute between the parties on the effect of the Directive and ECAT on the rights
of the victims of trafficking to relief after the 45-day recovery and reflection period has expired and whether
the Defendants have complied with their obligations under them. All counsel have stated that they do not
seek a reference of this dispute to the Luxembourg Court.

15. The Claimants' experiences are said to be examples of cases where recognised victims of trafficking
cannot obtain the support they need and to which they contend that they are entitled under Article 11 of the
Directive and under Article 12 of ECAT. They are said to form part of a more general class who cannot
obtain mainstream benefits as they do not qualify for them or have ceased to qualify for them by reference
to the EEA regulations, but who are still awaiting a decision as to whether or not to grant them DLR. If they
were to be granted DLR, they would then re-qualify for mainstream benefits. If these trafficking victims do
not continue to receive this support or support from the local authorities, they are liable to be destitute and
are said to be vulnerable to exploitation, including being re-trafficked.

**The Issues**

16. Mr. Martin Westgate QC, Counsel for the Claimants, contends that the Defendants are under a duty to
provide material support to recognised victims of trafficking beyond the 45-day reflection and recovery
period even where there are no criminal proceedings. This duty arises, according to Mr. Westgate, where,
after an individual assessment, it is necessary to do so in order to enable the victims, first, to exercise
effectively their rights under ECAT and the Directive (including the right to claim compensation); second, to
recover and to escape from the influence of their traffickers; and third, to support them pending their
applications for DLR and during criminal proceedings against those alleged to have been involved in
trafficking them.

17. Mr. Westgate stresses the need for the Defendants to provide such support where mainstream
benefits are unavailable, as otherwise there will be what he calls a “support gap” during which the victims
of trafficking are liable to be destitute and to be vulnerable to exploitation or to be re-trafficked. The
contents and duration of the duty in any case will depend on individual assessments carried out at
appropriate intervals of the needs of the person concerned. If the victim has recovered or does not need or
can obtain support elsewhere, then following an assessment it may be determined that the support duty
may no longer be owed.

18. In order to show the existence of such a duty to support, Mr. Westgate contends that the component
parts of Article 11 of the Directive, and in particular, Article 11(2), and Article 12 ECAT, impose a duty of
support on the Defendants to all victims (irrespective of whether they are involved in criminal proceedings)
referred to in Article 11(5) (content of measures) starting from a reasonable grounds finding and ending if
support is no longer necessary as a result of an individual needs assessment, which has to take place on
an informed and consensual basis. The Claimants' case is that the Defendants' present approach set out in
the Guidance does not comply with its requirements to provide support:

(a) after the 45-day recovery and reflection period and where criminal proceedings are pending;


-----

(Admin)

(b) (i) where despite the fact that there are no criminal proceedings or criminal proceedings have come to
an end, (ii) to enable the victim to claim compensation; and (iii) because of the personal needs and
circumstances (psychological, physical, social or safety needs);

(c) where applications for DLR are pending or cannot be made; or

(d) on the basis of an individual needs assessment.

19. Mr. Westgate contends that the Guidance is shown to be defective as it fails to recognise the duty
under Article 11(2) of the Directive and Article 12 ECAT to provide support following the 45-day recovery
and reflection period.

20. Mr. David Blundell, Counsel for the Defendants, submits that the support obligations on the
Defendants in Article 11 of the Directive are closely linked to and are dependent on the existence of
criminal proceedings, but that these obligations only continue for “an appropriate period after the
conclusion of criminal proceedings” where necessary. The case for the Defendants is that access to
support after the 45-day recovery and reflection period is actually provided as the SSHD can grant DLR
where a person has no other right to remain and that access to support can also be granted where
necessary pending a decision on DLR. Another feature of the Defendants' case is that the Directive does
not deal with the issue of rights of residence of trafficking victims and it is not concerned with establishing a
right of residence for trafficking victims.

21. The answer to these disputes entails resolving a fundamental dispute as to whether, as Mr. Westgate
contends is the position, Article 11(2) of the Directive6 imposes a separate and an additional duty to
provide support, which is separate from and additional to the duty in Article 11(1). Mr. Blundell submits that
Article 11(2) does not contain a separate or additional duty from Article 11(1), but that Article 11(2) merely
sets out the starting date for the operation of Article 11(1).

22. Another area of dispute is that Mr. Westgate also contends that the Claimants can rely on ECAT and
in particular on Article 127 of it, but the response of Mr. Blundell is that ECAT has not been incorporated in
English law and it cannot be relied on by the Claimants. Mr. Westgate's riposte is that it does not matter
that it has not been incorporated because the Court should still enforce the Defendants' obligations under
ECAT, even though it has not been incorporated into English law, for three reasons .

23. First, the Defendants seek to rely on an alleged concession made by Mr. James Eadie QC, counsel for
the Secretary of State in the case of R (Atamewan) v Secretary of State for the Home Department [2013]
_EWHC 2727 (Admin) [2014] 1 WLR 1959at paragraph 55 (“ the Atamewan concession”)8 ._

24. The second reason why Mr. Westgate contends that the Claimants can bring a claim based on ECAT
is that the English courts have assumed that ECAT (or at least Article 12) is part of English law. His final
reason is that the Secretary of State's policy in the Guidance is to adopt Article 12 of ECAT in relation to
the issues with which this application is concerned and so this policy should be enforced unless there are
good reasons (of which there are none) not to do so. The response of the Defendants is that the provisions
of ECAT as an unincorporated treaty are not enforceable because of what was said by Lord Oliver in JH
Rayner (Mincing Lane) Ltd v Department of Trade and Industry [1990] AC 4189and the Guidance does not
in any event implement it or incorporate it into English law as policy. Mr. Blundell also says that the
Atamewan concession does not bind this court, because it was not the subject of a decision by a court
even though it has been relied on in other cases without argument.

25. Foskett J granted permission. I am grateful for the admirable oral and written submissions in this case
from both legal teams in dealing with this wide-ranging application.

**Two Preliminary Points**

26. In order to resolve the outstanding matters, there are two important preliminary matters to stress. First,
the Defendants have discretion as to how the provisions in the Directive are to be implemented in order to
reach the result to be achieved. Article 288 of TFEU states that:


-----

(Admin)

“A directive shall be binding, as to the result to be achieved, upon each Member State to which it is
addressed, but shall leave to the national authorities the choice of form and methods.”

27. So my task when considering whether the Defendants have complied with the Directive is to determine
if the Defendants have achieved the result sought to be achieved and not to decide if the result could be
achieved by another preferable manner.

28. Second, as I have explained, the Claimants are seeking to challenge various aspects of the
Defendants' policy on the basis that it is vitiated by a justiciable public law error. The fall-back position of
the Claimants is that the support regime creates an unacceptable risk of unfairness and so should be
quashed. The threshold that has to be reached before making quashing orders was considered by the
Court of Appeal in R (Tabbakh) v Staffordshire Probation Trust [2014] 1 WLR 4620at paragraphs 38 and
45, when it observed that a policy could only be struck down if it was “inherently unfair”. That case also
established that if a policy is not in itself “inherently unfair”, then in the words of Richards LJ, giving the only
reasoned judgement of the Court of Appeal at paragraph 38, “the correct target of challenge is not the
guidance but any individual decisions alleged to have been made in breach of the requirements of
procedural fairness”. Lord Dyson M.R. followed this approach in Lord Chancellor v Detention Action [2015]
1 WLR 5341at paragraph 27, where he explained when giving the only reasoned judgement of the Court of
Appeal that:

“I would accept Mr. Eadie's summary of the general principles that can be derived from these authorities: (i)
in considering whether a system is fair, one must look at the full run of cases that go through the system;
(ii) a successful challenge to a system on grounds of unfairness must show more than the possibility of
aberrant decisions and unfairness in individual cases; (iii) a system will only be unlawful on grounds of
unfairness if the unfairness is inherent in the system itself; (iv) the threshold of showing unfairness is a high
one; (v) the core question is whether the system has the capacity to react appropriately to ensure fairness
(in particular where the challenge is directed to the tightness of time limits, whether there is sufficient
flexibility in the system to avoid unfairness); and (vi) whether the irreducible minimum of fairness is
respected by the system and therefore lawful is ultimately a matter for the courts. I would enter a note of
caution in relation to (iv). I accept that in most contexts the threshold of showing inherent unfairness is a
high one. But this should not be taken to dilute the importance of the principle that only the highest
standards of fairness will suffice in the context of asylum appeals.”

**The Issues**

29. The issues to be determined on this application are:

(a) Whether Article 11(2) of the Directive specifies an obligation on Member States which is additional to
and separate from the obligation in Article 11(1) and not linked to criminal proceedings as contended for by
the Claimants (“Issue 1: The Article 11(2) Issue)”;

(b) Whether the Claimants can rely on the provisions in ECAT and in particular Article 12 even though
ECAT has not been incorporated into English law (“Issue 2: The ECAT/Article 12 Issue)”;

(c) Whether the SSHD has misdirected herself as to the period for which the support duty continues and,
in particular, whether it extends to individuals who have been recognised as victims of trafficking for whom
such support is necessary (“Issue 3: The Period of Support Issue”);

(d) Whether the Defendants have failed to ensure the existence of a comprehensive or lawful system for
the provision of support for victims of trafficking (“Issue 4: The Post Recovery and Reflection System of
Support Issue”);

(e) Whether the Defendants have failed to carry out individual assessments in the Claimants' cases
(“Issue 5: The Claimants' Assessment Issue”); and

(f) Whether the SSWP can restrict access to benefits on the basis that the Claimant does not satisfy the
GPOW test and whether the GPOW test should be disapplied “Issue 6: The Access to Benefits Restriction
Issue”)


-----

(Admin)

**Issue 1: The Article 11(2) Issue**

_(i) Introduction_

30. This issue seeks to resolve the dispute of whether there is merely one obligation in Article 11, which is
set out in Article 11(1), or whether there is in addition to the obligation in Article 11(1) a separate obligation
in Article 11(2) of the Directive. Article 11 provides that:

“1. Member States shall take the necessary measures to ensure that assistance and support are provided
to victims before, during and for an appropriate period of time after the conclusion of criminal proceedings
in order to enable them to exercise the rights set out in Framework Decision 2001/220/JHA, and in this
Directive.

2. Member States shall take the necessary measures to ensure that a person is provided with assistance
and support as soon as the competent authorities have a reasonable-grounds indication for believing that
the person might have been subjected to any of the offences referred to in Articles 2 and 3.

3. Member States shall take the necessary measures to ensure that assistance and support for a victim
are not made conditional on the victim's willingness to cooperate in the criminal investigation, prosecution
or trial, without prejudice to Directive 2004/81/EC or similar national rules.

4. Member States shall take the necessary measures to establish appropriate mechanisms aimed at the
early identification of, assistance to and support for victims, in cooperation with relevant support
organizations.

5. The assistance and support measures referred to in paragraphs 1 and 2 shall be provided on a
consensual and informed basis, and shall include at least standards of living capable of ensuring victims'
subsistence through measures such as the provision of appropriate and safe accommodation and material
assistance, as well as necessary medical treatment including psychological assistance, counselling and
information, and translation and interpretation services where appropriate.

6. The information referred to in paragraph 5 shall cover, where relevant, information on a reflection and
recovery period pursuant to Directive 2004/81/EC, and information on the possibility of granting
international protection pursuant to Council Directive 2004/83/EC of 29 April 2004 on minimum standards
for the qualification and status of third country nationals or stateless persons as refugees or as persons
who otherwise need international protection and the content of the protection granted(1) and Council
Directive 2005/85/EC of 1 December 2005 on minimum standards on procedures in Member States for
granting and withdrawing refugee status (2) or pursuant to other international instruments or other similar
national rules.

7. Member States shall attend to victims with special needs, where those needs derive, in particular, from
whether they are pregnant, their health, a disability, a mental or psychological disorder they have, or a
serious form of psychological, physical or sexual violence they have suffered.”

_(ii) Submissions_

31. The case for the Claimants is that although the existence of criminal proceedings is required for a
claim under Article 11(1), there is no such requirement for the other provisions in Article 11 and in
particular Article 11(2), because it is a free-standing provision separate from Article 11(1).

32. Mr. Blundell explains that Article 11(2) does not impose a separate duty on the Defendants, but
instead it specifies when the obligation in Article 11(1) arises, namely “as soon as the competent
authorities have a reasonable-grounds indication for believing that the person might have been subjected
to any offences [concerning trafficking in human beings or inciting, aiding and abetting or attempting to
commit such an offence]”. He submits that this provision is necessary because Article 11(1) merely states
that the obligation to support arises “before” the criminal proceedings, but that it does not specify a starting
point and that explains the need for and the role of Article 11(2). In other words, the case for the
Defendants is that Articles 11(1) and (2) complement each other


-----

(Admin)

_(iii) Discussion_

33. The parties regard this dispute as being very important, although it seems that many of the actual
provisions in the Guidance are based on a wider duty being owed to trafficking victims than is set out in
Article 11(1).

34. I have come to the conclusion that I cannot accept the Defendants' analysis that Article 11(2) is not a
freestanding provision independent of Article 11(1) or that there is any requirement for there to be criminal
proceedings in order to trigger liability in Article 11(2), for seven reasons which individually and
cumulatively lead me to that conclusion. I will now set them out in no order of importance.

35. First, Articles 11(1) and 11(2) are in my opinion regarded in the Directive as containing separate duties
to support a trafficked victim, as is shown by the fact that Article 11(5) refers to “the assistance and support
measures referred to in paragraphs 1 and 2” (emphasis added).

36. The references to each of these provisions as separate “assistance and support measures” shows,
first, that they are regarded as being different and separate provisions and, second, that contrary to the
Defendants' case, Article 11(2) is not merely explanatory of Article 11(1). If Article 11(2) was to be
regarded solely as explanatory of the time when liability under Article 11(1) arises (as Mr. Blundell
contends is the case), there would then have been no need for Article 11(2) to be mentioned in Article
11(5).

37. Second, the heading of Article 11 (“Assistance and support for victims of trafficking in human beings”)
shows that it was not limited to those involved in criminal proceedings, not least because of the way in
which its heading contrasts with the heading of the following Article (Article 12), which is headed
“Assistance to victims of trafficking in criminal investigations and proceedings”. The heading to an Article in
the Directive has been held by the Court of Appeal to be a valuable aid to construing its scope in R
(Gudanaviciene) v The Director of Legal Aid Casework _[2014] EWCA Civ 1622; [2015] 1 WLR 2247at_
paragraph 103. In that case, the issue was whether Article 12(2) of the Directive created a right to legal aid
in relation to a NRM referral, i.e. before any reasonable grounds decision was made. The Court of Appeal
held that it did not for a number of reasons, including that the heading of the Article showed that it was
concerned essentially with criminal investigations and proceedings. By parity of reasoning, in this case, the
heading of Article 11 is supportive of the Claimants' case as it does not refer to any form of criminal
proceedings and so Article 11(2) should not be so limited.

38. Third, there are many obligations imposed on Member States in Article 11 but only one of them is
expressly linked to criminal proceedings, namely Article 11(1). There is no reason why the other provisions
should be so linked, especially as there is nothing expressly stating that they should be so connected and
there is no reason why such a connection should be implied. In other words, if the draftsman of the
Directive wanted to ensure that only the obligation in Article 11(1) and not the other obligation in Article 11
(such as that contained in Article 11(2)) was to be linked to criminal proceedings, he or she would have
used precisely the wording which he or she did actually use.

39. Fourth, in Gudanaviciene, when giving the judgment of the Court of Appeal, the Master of the Rolls
explained at paragraph 105 that he accepted an interpretation of the Directive which “accords with the
provision of [ECAT] to which the Directive is intended in part to give effect”. It is noteworthy that in ECAT,
there is no provision limiting the support obligation to criminal proceedings and this supports Mr.
Westgate's submissions.

40. Fifth, there are provisions in the Recitals to the Directive which show that the obligation of Member
States to give support and assistance should not be linked to criminal proceedings. As Mr. Blundell
explained, it is well established that a recital to a EU Directive “has no binding legal force and cannot be
relied on as a ground for derogating from the actual provisions of the act in question” (Case _C-162/97_
Nilsson [1998] ECR 1-7477 at paragraph 54). Nevertheless, the Court of Justice has explained in Case
215/88 Casa Fleischhandels-GmbH v Bundesanstalt fur landwirtshafliche Marktordnung [1989] ECR1-2789
at paragraph 13 that:


-----

(Admin)

“Whilst a recital in the preamble to a regulation may cast light on the interpretation to be given to a legal
rule, it cannot itself constitute such a rule.”

41. In this case, there are recitals stating that “assistance and support should be available to [victims of
trafficking in human beings] before, during and for an appropriate time after criminal proceedings” (Recital
18) which are supportive and explanatory of Article 11(1). There are also other provisions in the Recitals,
such as in Recital 21, which refer to the general obligation to provide support “on a consensual and
informed basis” without any express provision limiting this obligation to where there is a connection with
criminal proceedings. This to my mind casts light on the approach to Article 11(2) and is supportive of it
being regarded as a separate obligation imposed on Member States independent of Article 11(1).

42. Sixth, there is no logical reason why Article 11(2) should be linked to criminal proceedings, as it would
be as effective and useful as constituting an independent obligation to provide support irrespective of
whether there were or had been criminal proceedings in being or whether there were any in prospect.

43. Seventh, the background to the Directive shows that it was not intended that it would discriminate
between those victims of trafficking who had been connected with criminal proceedings, and those victims
of trafficking who had not been so connected. Article 4 ECHR contains the right to freedom from slavery
and forced labour. In Rantsev v Cyprus and Russia (2010) 51 EHRR 1, it was held that trafficking fell within
its scope and that it imposed a duty to protect victims. There is no suggestion that there should be different
benefits for those victims of trafficking involved in criminal proceedings and those victims who had not been
so involved. Frequently, it might be fortuitous or a coincidence if a victim of trafficking was or might be
involved in criminal proceedings; that might depend, for example, on whether the trafficker had fled or had
died. There is no logical or other reason why the absence of criminal proceedings could or should deprive
a trafficked person of relief or why those victims of trafficking should be deprived of benefits simply
because for some reason criminal proceedings could not take place.

44. I therefore conclude that Article 11(2) is a discrete obligation and when read with other parts of Article
11 (and in particular Article 11(4)), it means that in the post-45 day recovery and reflection period, the
United Kingdom is obliged to provide a trafficked person with assistance and support10 . I should add that I
have heard no submissions on when the Article 11(2) duty comes to an end and I make no findings in
relation to it. In addition, I should add that my view is that the Directive does not create any independent
right of residence; such a right is contained in the Trafficking Residence Directive, but the United Kingdom
has not opted into that Directive, which does not apply in this country. I will return to consider if the
Guidance and the policy of the Defendants fails to achieve the results required of Article 11(2) when
considering the Claimants' criticisms in paragraph 67ff below.

**Issue 2: The Article 12 ECAT Issue**

_(i) Introduction_

45. This issue raises the question of whether the Claimants can rely on the provisions of ECAT, and in
particular Article 12 of it, even though it has not been incorporated into English law. Article 12 provides
that:

“1. Each Party shall adopt such legislative or other measures as may be necessary to assist victims in
their physical, psychological and social recovery. Such assistance shall include at least:

a standard of living capable of ensuring their subsistence, through such measures as: appropriate and
secure accommodation, psychological and material assistance;

b access to emergency medical treatment;

c translation and interpretation services, when appropriate;

d counselling and information, in particular as regards their legal rights and the services available to them,
in a language that they can understand;


-----

(Admin)

e assistance to enable there rights and interests to be presented and considered at appropriate stages of
criminal proceedings against offenders;

f access to education for children.

2. Each Party shall take due account of the victim's safety and protection needs.

3. In addition, each Party shall provide necessary medical or other assistance to victims lawfully resident
within its territory who do not have adequate resources and need such help.

4. Each Party shall adopt the rules under which victims lawfully resident within its territory shall be
authorised to have access to the labour market, to vocational training and education.

5. Each Party shall take measures, where appropriate and under the conditions provided for by its internal
law, to co-operate with non-governmental organisations, other relevant organisations or other elements of
civil society engaged in assistance to victims.

6. Each Party shall adopt such legislative or other measures as may be necessary to ensure that
assistance to a victim is not made conditional on his or her willingness to act as a witness.

7. For the implementation of the provisions set out in this article, each Party shall ensure that services are
provided on a consensual and informed basis, taking due account of the special needs of persons in a
vulnerable position and the rights of children in terms of accommodation, education and appropriate health
care.”

_(ii) The Dispute_

46. Mr. Blundell contends that the Claimants cannot rely on any provision in ECAT because it has not
been incorporated into English law on the basis of statements in JH Rayner (Mincing Lane) Ltd v
Department of Trade and Industry[1990] AC 418 by Lord Oliver that:

“(a) (M)unicipal courts have not and cannot have the competence to adjudicate upon or to enforce the
rights arising out of transactions entered into by independent sovereign states between themselves on the
plane of international law;

(b) a treaty is not part of English law unless and until it has been incorporated into the law by legislation.
So far as individuals are concerned, it is res inter alios acta from which they cannot derive rights and by
which they cannot be deprived of rights or subjected to obligations.”

47. Mr. Westgate's response is that provisions in ECAT can be relied on, first, because of the Atamewan
concession; second, because the Courts in other cases have assumed that ECAT (or at least Article 12) is
part of English law; and third, because the statements in Rayner's case do not preclude the Claimants from
relying on the Guidance which adopts ECAT or parts of it, as in so doing “the court is not enforcing [ECAT]
but requiring the SSHD to abide by her current policy unless there are good reasons to depart from it.”11 I
will consider each of these points in turn.

_(iii) The Atamewan Concession_

48. While making submissions in the Divisional Court in Atemewan, Mr. James Eadie QC, Counsel for the
Secretary of State, submitted that:

“55…. in relation to the NRM decision that the key question was whether the policy set out in the Guidance
(particularly in relation to "historic" trafficking cases) was sufficient to comply with the UK's international
obligations under CAT. He accepted, at least in this court, that although CAT had not been transposed into
domestic law by legislation and so did not have "direct effect", insofar as the Guidance purported to give
effect to the terms of CAT and failed to do so, that would be a justiciable error of law.”

49. Mr. Westgate seeks to rely on the Atamewan concession, but Mr. Blundell contends, correctly in my
opinion, that the Court merely assumed the concession to be correct, with the consequence that this


-----

(Admin)

statement is not binding on me in the light of the decision of Sir Nicholas Browne-Wilkinson V-C in Re
Hetherington [1990] Ch 1when he explained (with emphasis added) at page 10g that:

“In my judgment the authorities therefore clearly establish that even where a decision of a point of law in a
particular case was essential to an earlier decision of a superior court, but that court merely assumed the
correctness of law on a particular issue, a judge in a later case is not bound to hold that the law is decided
in that sense.”

50. That approach echoes statements to the same effect in Barrs v Bethell [1982] Ch 294. 308 and in
Ashville Investments Limited v Elmer Contractors Ltd [1989] QB 488,494. I agree that this reasoning shows
that this Court is not bound by the Atamewan concession, as the Divisional Court certainly did not consider
if it was correct, let alone decide that it was. A second reason why I reach that conclusion that I am not
bound by the Atamewan concession is that Mr. Eadie's concession was stated to be “at least in this Court”,
which I understand to be a reference to the court hearing the Atemewan case. I should add that although I
was one of the judges hearing that case, I have no independent recollection of how the concession came
to be given more than two years ago. This means that I am not bound by the Atamewan concession.

51. Furthermore, the mere fact that the Atamewan concession was followed without argument in other
cases does not mean that those cases can be regarded as authority for a proposition that ECAT was part
of English law, essentially for the reasons explained in Re Hetherington and in the last paragraph.

52. Mr. Westgate seeks to obtain assistance for his contention that I am bound by the Atamewan
concession from the approach of Mr. Philip Mott QC, sitting as a Deputy High Court Judge, R (FM) v
Secretary of State[2015] EWHC 844 (Admin) at paragraph 11, which is based on the Atamewan
concession and which apparently assumed that ECAT was part of English law. That approach cannot be
regarded as authority for a proposition that ECAT was part of English law, essentially for the same reasons
which I have just explained and which have led me to the conclusion that I am not bound by the Atamewan
concession to hold that ECAT was part of English law.

_(iv) The other judgments said to show that the Defendants are obliged to comply with Article 12 of ECAT_

53. (A). The Claimants rely on a number of other cases to show that the Defendants were, and are,
obliged to comply with Article 12 of ECAT. They first rely on the decision of the Court of Appeal in R (AA)
Iraq) v Secretary of State for the Home Department [2012] EWCA Civ 23 in which there was a challenge to
the finding that there were no reasonable grounds for believing that AA was a victim of trafficking. The
Court set out the provisions of ECAT and explained at paragraph 40 that the “government policies for
complying with [ECAT] are found, at least in part, in the Guidance…”. It seems that this was the approach
of the Court, but it was not adopted by the Court after hearing opposing legal submissions.

(B). Instead the Court had merely assumed this approach to be correct as was explained by Mr. Philip
Mott QC, sitting as a Deputy High Court Judge, in R(Y) v Secretary of State for Home Department [2012]
EWCA 1075 (Admin) at paragraph 43, who observed that the AA case “proceeded on the assumption
(though in that case it seems not to have been challenged in argument) that the domestic Guidance had
adopted the Convention, and therefore the Court could look directly at the Convention in deciding whether
the Defendant had followed her published policy”. So AA does not constitute binding authority for the
proposition that the domestic Guidance had adopted ECAT for the reasons explained in Re Hetherington.
In addition, the Court of Appeal did not identify “the government policies for complying with [ECAT]” found
in the Guidance, but it would seem that they must have related to the process for identifying victims of
trafficking, which was the issue in that case, but which is not the issue on the present application.

54. The Claimants also seek to derive assistance from R (HAM) v Secretary of State for the Home
Department [2015] EWHC 1725 (Admin) in which the issue was also whether the claimant was a victim of
trafficking. It appears from paragraph 55 of the judgment in that case that it was common ground that it
would have been an error of law for the competent authority to depart from the Guidance and the claim
was based on a failure to follow the Guidance. The Deputy High Court Judge, Ms Helen Mountfield QC,
explained that had it proved necessary (which was not the case) that, in interpreting the Defendant's policy,


-----

(Admin)

she “would have been prepared to interpret it on an assumption that the [United Kingdom] intends to
comply wherever possible with its international commitments”. This was dictum which is not binding on me
as I, unlike the learned Deputy High Court Judge, have heard detailed submissions on this issue; in any
event ECAT was not incorporated into English law.

55. The next case on which the Claimants rely is the decision in R (Mutesi) v Secretary of State for the
Home Department _[2015] EWHC 2467 (Admin) in which Laing J assumed at paragraph 6, without_
argument, that the Secretary of State had given effect to ECAT through Guidance noted and that the
Directive existed. This statement does not bind me. In the case of Y (supra), Mr. Philip Mott QC, sitting as
a Deputy High Court Judge, accepted that “Everything in both the Guidance and the Supplementary
Guidance points to the Defendant adopting the Convention and purporting to apply it domestically”. This
was again a statement made without the benefit of argument.

56. Finally, the Claimants also sought to rely on R (FK) v Secretary of State for the Home Department

_[2016] EWHC 56 (Admin) in which it seemed to be assumed that ECAT was part of English law without it_
having been argued.

57. None of these cases provides support for the proposition that there is judicial authority for the
proposition that ECAT (and in particular Article 12) is now part of English law.

_(v) Has ECAT (and in particular Article 12) been adopted as being the SSHD's present policy in the_
_Guidance so that she should be bound to abide by it unless there are good reasons for departing from it?_

58. Mr. Blundell contends that the basic approach is that as ECAT has not been incorporated into English
law, the Claimants cannot rely on it in accordance with the approach explained in the Rayner case and that
his approach was adopted by the Supreme Court in R(JS) v Secretary of State for Work and Pensions

[2015] 1 WLR 1449by Lord Reed who explained that:

“90. It is firmly established that U.K. courts have no jurisdiction to interpret or apply unincorporated
international treaties. … As was made clear in … Corner House … it is therefore inappropriate for the
courts to purport to decide whether or not the executive has correctly understood an unincorporated treaty
obligation.”

Also Lord Carnwath observed that:

“115. It is of course trite law that, in this country at least, an international treaty has no direct effect unless
and until incorporated by statute, but that it may be taken into account as an aid to interpretation in cases
of ambiguity.”

59. (A). According to Mr. Blundell, the only exceptions to the Rayner principle (which is set out in
paragraph 46 above) arises where there is legislation adopting a treaty or where it is incorporated in a
contract of which Ecuador v Occidental Exploration and Production Co [2006] QB 432is an example. He
contends that an error by a Minister as to the effect and meaning of an unincorporated Treaty cannot give
rise to a successful challenge, as was explained in R (Corner House Research) v Serious Fraud Office

[2009] 1 AC 756and in R (JS) v Secretary of State [2015] 1 WLR 1449[90-91], [115] and [134]. I agree, and
before I was intending to circulate a draft of this judgment, I noted that Cranston J had reached a similar
decision in the very recent case of R (BG) v Secretary of State [2016] EWCA 786 (Admin) and I drew the
attention of Counsel to it and to the learned Judge's statement that:

“65. The Trafficking Convention is an international treaty which has not been incorporated by legislation
into UK law. Although an unincorporated treaty may assist in interpreting UK legal instruments, it imposes
no legal duties on the Executive nor does it confer rights on individuals: JH Rayner (Mincing Lane) Ltd v.
_Department of Trade and Industry [1990] 2 AC 418, 499–500; Ahmed v. Her Majesty's Treasury (Justice_
_intervening) Nos 1 and 2), [2010] 2AC 534[109]; R (Public Law Project) v. Lord Chancellor [2015] EWCA_
1193,[2016] 2 WLR 995[27]. The Trafficking Convention has been given effect through the Secretary of
State's policies but cannot be invoked as a source of free-standing rights and duties.”


-----

(Admin)

(B). I asked them if they wished to make any further submissions in the light of this case. Mr. Blundell said
that it supported the Defendants' case while Mr. Westgate says that this decision does not affect their
argument. I respectfully agree with Cranston J first, that ECAT, as an unincorporated treaty, imposes no
duties on the Executive nor does it confer rights on individuals, and second that ECAT can be given effect
through the SSHD's policies rather than as a source of freestanding rights and duties.

60. The Claimants also submit that they can rely on ECAT because the policy of the SSHD was that the
Guidance was intended to give effect to ECAT, or at least to Article 12 of it, in relation to the issues with
which this application is concerned, and in consequence the Defendants were obliged to abide by its policy
in the absence of good reasons to depart from it (see Mandalia v Secretary of State [2015] 1 WLR 4546,
4555-6 paragraph 29. Mr. Westgate contends that, expressed in this way, this claim does not offend the
principles set out in Rayner's case because the Claimants are not seeking to enforce ECAT, but instead
are requiring the SSHD to abide by her current policy unless there are good reasons to depart from it. He
also contended that this submission is consistent with and is supported by the approach of Lord Dyson
JSC in R (WL (Congo)) v Secretary of State for the Home Department [2012] 1 AC 245that:

“26…a decision-maker must follow his published policy (and not some different unpublished policy) unless
there are good reasons for not doing so…” and that

“ 35. The individual has a basic public law right to have his or her case considered under whatever policy
the executive sees fit to adopt provided that the adopted policy is a la26..wful exercise of the discretion
conferred by the statute….”

61. It is important to bear in mind that the policy, which it is said by the Claimants that the SSHD should
have followed, was derived from the Guidance which had in turn adopted aspects of ECAT. Assuming for a
moment that the Government adopts a policy based wholly or partially on an unimplemented treaty, I do
not see any good reason why this approach cannot apply just because the policy replicates what appears
in the unimplemented treaty. In other words, Lord Dyson's principle could apply to a policy which is
identical to that in an unimplemented treaty, which has a different source from the unimplemented treaty,
namely the practice which the Executive has propounded in, for example, formal Guidance. Indeed, this
approach is supported by the comments of Cranston J in R (BG) v Secretary of State set out in paragraph
59 A above. That raises the next question, which is whether the policy of SSHD has been to incorporate or
to adopt as its policy the entire ECAT or Article 12 of it and, if so, for what purposes. That is the issue to
which I now turn, and that entails considering the four matters on which the Claimants rely, starting with
two matters which it is suggested by the Claimants show that the SSHD would comply with the entire
ECAT.

62. First, it is said in the helpful “Summary of Principal Propositions relied on by the Claimants” that the
repeated reference to obligations arising under ECAT “gives the overall message that within the scope of
matters covered by the Guidance, [SSHD] will comply with [ECAT]”. I do not agree, as in the section of the
Guidance dealing with the Guidance's purposes, it is stated that “This guidance …is based on [ECAT]” and
it then proceeds to state (with emphasis added) that “as part of implementing the Convention, the
Government created the [NRM]”. Significantly, it did not state that the whole of ECAT was being
implemented or being accepted as policy.

63. Second, the Claimants attach particular significance to comments made by Ms Helen Sayeed, a Home
Office official, in a witness statement in which she states, at paragraph 26, that the United Kingdom has
implemented “key obligations of [ECAT]” (emphasis added), but crucially she does not state that _all_ the
obligations of ECAT have been implemented or accepted as their policy. Indeed, other parts of Mrs
Sayeed's witness statement refer to the United Kingdom having “implemented many of its Convention
obligations in NRM, through published guidance” (emphasis added). I cannot accept that these statements
show that all parts of ECAT have been implemented or accepted as policy by the SSHD.

64. Third, the Claimants attach importance to an earlier edition and other editions of the Guidance, which
are said to show that the Guidance was based on ECAT, but that does not show that the SSHD will comply
with every part of ECAT


-----

(Admin)

65. Fourth, Mr. Westgate contends that there is evidence that ECAT was being implemented or being
accepted as policy in the Guidance itself, which does refer to ECAT frequently. I have already just referred
to Section 3, which has the title “Purpose of Guidance” in which it is explained that the Guidance is “based
on the Convention” and it is stated (with emphasis added) that “as part of implementing the Convention,
the Government created the [NRM]”. This did not state that the whole of ECAT was being implemented or
accepted as policy. The other relevant provisions are set out in:

(i) Section 5, which has the title “Summary of key steps in the [NRM] process” and relates to how alleged
victims of trafficking should be treated and how their claims should be handled. There is a passage which
states that following a positive conclusive grounds decision in relevant cases, the Home Office will make a
further decision on whether an individual qualifies for a grant of DLR “in line with [ECAT] and the U.K.
Government's commitment to extend this provision to victim of slavery, servitude and forced and
compulsory labour across the U.K”. This shows that the policy of SSHD on the question of whether a victim
of trafficking is entitled to DLR, the ECAT principles apply;

(ii) Section 7.3, which has the title “Ensuring victims can access secure accommodation and support”.
There is a provision stating that “potential victims who are not housed in specialist accommodation
(including those housed by asylum support) must still be offered outreach support to make sure their
entitlements are met under Article 12 [of ECAT]. The support providers listed above can again advise on
these arrangements”. It is to be noted that this provision not only expressly refers to “potential victims” but
also it is to be found in Section 7, which has the heading “Referrals to the NRM”. It therefore deals with
claims before the trafficking claims have been resolved and not in the period with which this claim is
concerned, namely the period after the elapse of 45-day period after the trafficking claim has been
accepted;

(iii) Section 12, which has the title “The two stage NRM consideration process”. It is stated that ECAT
“stipulates a 2 stage process for identifying victims of trafficking”, but this deals with the pre-consideration
process which is concerned with a much earlier stage than the period with which this claim is concerned;

(iv) Section 13, which has the title “Actions for Home Office and UKHTC if the reasonable grounds
decision is positive”. It is provided that the Home Office must provide the potential victim with support if
they want it for a minimum of 45 days during a recovery and reflection period. It is then stated that this
period “triggers certain rights and measures under [the Convention] and in no circumstances should the
Competent Authority [i.e. the Home Office and the National Crime Agency] deny an identified victim these
rights where the victim indicates they want them”. This does not either incorporate or adopt as policy the
entire ECAT or the relevant provisions in Article 12;

(v) Section 19, which has the title “Next steps for the Competent Authority if the conclusive grounds
decision is positive”. There is a sub-section entitled “When is Discretionary Leave to Remain relevant?”
which deals with applications for DLR by those accepted as victims of trafficking who are not thereby
automatically entitled to DLR. It is stated that in respect of applications for DLR by those victims of
trafficking, “each case should be considered on its individual merits and in full compliance with UK's
obligation under [the Directive] and [ECAT]”. ECAT has been ratified by the United Kingdom and it has not
been argued or shown that this does not mean that Article 12 is not applicable. This shows that
Government policy is that ECAT applies to consideration of those applications;

(vi) Section 19, where there is also a sub-section entitled “Personal Circumstances” which provided that
“when the Home Office makes a positive conclusive grounds decision, it may be appropriate to grant a
**_modern slavery discretionary leave to remain in the UK if their personal circumstances are compelling in_**
line with Article 14 [of ECAT]. This must be considered in line with the discretionary leave policy”. In
addition, there is provision in that Section which refers to Article 15 of ECAT and it then states that “it may
be appropriate to grant [such a person DLR] if they need to stay in the UK on the grounds that they are
pursuing a claim for compensation against their traffickers”. This provision does not incorporate or adopt as
policy either the entire ECAT or Article 12; and


-----

(Admin)

(vii) The same Section, where there is a sub-section entitled “Victims who are helping police with their
enquiries”, in which it is stated that “In line with the [ECAT], the Home Office may grant a period of
discretionary leave where a victim of human trafficking or modern slavery has agreed to cooperate with
police enquiries”. Again, this does not show that the Convention or Article 12 has been incorporated into
English law, and in any event, it only deals with victims who are helping the police with their inquiries.

_Conclusions on Issue 2_

66.  I reject the contention that the Claimants can rely on ECAT, which has not been incorporated into
English law either because of the Atamewan concession or because the Courts in other cases have
assumed that ECAT (or at least Article 12) to be part of English law. The statements in Rayners' case do
not, however, preclude the Claimants from relying on the Guidance which specifically adopts ECAT or
parts of it where it has been accepted as the policy of the SSHD in the Guidance. I do not consider that the
material in paragraph 65, whether considered individually or cumulatively shows that the whole of ECAT or
of Article 12 has been incorporated for all purposes into English law as being the SSHD's policy.
Nevertheless, as I have explained in sub-paragraph 65 (i), (ii), (v) and (vii), the Guidance stated that the
SSHD would act in accordance with Article 12 of ECAT. In particular, I accept that the policy of SSHD was
that she would apply the approach in ECAT to deal with applications for DLR from those who had been
recognised as victims of trafficking in the matters set out in paragraph 65 (v) and to the limited extent
specified in paragraph 65(vi). Mrs Sayeed explains in her witness statement that if the competent
authorities have reasonable grounds to believe a person has been a victim of trafficking, they must take
various steps, including to ensure that the person receives the assistance provided for in Article 12(1) and
(2) of ECAT and this must continue through the period of recovery and reflection. This is policy which the
SSHD must follow unless there is good reason not to do so.12. I will now consider if this policy has been
followed in the light of the contentions of the Claimants.

**Issue 3: The Period of Support Issue and Issue 4: The Post Recovery and Reflection System of**
**Support Issue**

67. It is convenient to deal with these issues together. Issue 3 is whether the SSHD has misdirected
herself as to the period for which the support duty continues and whether it extends to individuals who
have been recognised as victims of trafficking for whom such support is necessary. Issue 4 is whether the
Defendants have failed to ensure the existence of a comprehensive or lawful system for the provision of
support for victims of trafficking not limited to the recovery and reflection period. As I have explained, the
case for the Claimants is that the Guidance is defective, as the SSHD has failed to recognise any duty to
provide support after the 45-day recovery and reflection period, while the case for the Defendants is that
the SSHD can, and does, grant DLR and discretionary extensions of NRM where necessary pending a
decision on the DLR application. The Directive does not require DLR but merely the provision of support,
which is provided in the United Kingdom by DLR, which enables the recipient to have access to
mainstream benefits.

68. Mr. Westgate has submitted that there are four areas in which the Defendants have failed to make
adequate provision in their Guidance for the appropriate level of support. A recurring theme of the
Claimants' submissions was in the words of their skeleton argument that “the Defendants have
misunderstood the extent of the support duty and/or they have failed to make adequate provision in the
Guidance” for those conclusively found to have been trafficked.

69.  In order to decide if this is correct or if the Defendants have complied with their support duty, it is
worthwhile bearing in mind six matters. First, the Guidance states in the section entitled “Actions for Home
Office and UKHTC if the conclusive grounds decision is positive” that “a person who is accepted as a
victim of trafficking will not be granted DLR solely as a result of that decision unless they meet the relevant
criteria.” Second, it is necessary to consider the Defendants' policy to decide what those criteria are as well
as if, and for how long, further support is to be given. Third, in order to resolve that issue, it is necessary to
consider not only the terms of the Guidance, but also the practices adopted by the Defendant as a failure
to take account of these practices would ignore the true workings of the regime Fourth the issue to be


-----

(Admin)

resolved on the Claimants' challenge to the regime is whether the Defendants' regime achieves the aim of
producing the results set out in Articles 11 of the Directive and 12 of ECAT as explained in Article 288 of
TFEU (see paragraph 26 above). Fifth, the mere fact that the Defendants' support regime has not or may
not have been correctly applied in, for example, the cases relied on by Ms Roberts, does not then mean
that the regime does not achieve the aim of producing the results set out in those Articles. Sixth, if the
support regime does achieve the aim of producing the results set out in those Articles and there are
aberrant decisions, the correct target of challenging such aberrant decisions is not the Guidance but
instead the individual aberrant decisions as Richards LJ explained in the passage quoted in paragraph 28
above.

(i) _Where support is needed after the 45-day recovery and reflection period and where criminal proceedings are_
_pending_

70. Mr. Westgate complains that although the Defendants appear to recognise a duty to provide support
where criminal proceedings are pending after the expiry of the 45-day recovery and reflection period, the
Guidance does not provide for it. Article 11(1) of the Directive requires the Member State “to ensure that
assistance and support are provided to victims before, during and for an appropriate period of time after
the conclusion of criminal proceedings”. As I have explained, Article 11(2) also requires the provision of
assistance and there are provisions in Article 11(3), which state that the obligations to take measures to
ensure assistance and support are “not made conditional on the victim's willingness to cooperate in the
criminal investigation, prosecution or trial”.

71. Mr. Westgate observes correctly in my opinion that criminal proceedings are likely to last longer than
the 45-day recovery and reflection period, while the Guidance only deals with the provision of assistance
by reference to the provisions relating to the grant of DLR where the victim is involved in criminal
proceedings. There are four significant features of the circumstances in which DLR can be granted. First, it
has to be requested by the police, as the Guidance states that where victims of trafficking or **_modern_**
**_slavery have agreed to cooperate with the police, the Home Office may grant DLR, but that:_**

“the police must make a request for them to be granted leave to remain .. this may be extended where
necessary, for example where a criminal prosecution takes longer than expected and the police have
confirmed or requested an extension.” (emphasis added)

72. Second, the Guidance states that the request for DLR “should be made by the investigating police
force rather than the victim or their legal representatives”. It proceeds to stipulate that the legal
representatives “should not make an application for leave to remain”. The Guidance states that these
provisions apply to EEA nationals who are unable to exercise free movement rights, but that there may
also be circumstances in which the victim is unable to exercise free movement rights, in which case any
request for DLR should be considered in line with the Guidance. Mrs Sayeed explains in her witness
statement that the reason why only the police can make the request is that “only those investigating crime
can give definitive information that the victim requires leave to assist the police with their enquiries”. Even
so, this does not explain why the victim or his or her representative cannot under any circumstances
instigate the process, especially as the police might not be aware of their power to make the request for
DLR, as I will explain.

73. Third, there is no obligation on the police to make a request for DLR for somebody assisting them. Mrs
Sayeed refers in her witness statement to the College of Policing's published Authorised Professional
Practice on **_Modern Slavery (National Guidance for the Police Service), which states (with emphasis_**
added) that:

“Where a person is found conclusively to be a victim and has agreed to assist the police with formal
enquiries in the UK, the police may make a formal request for them to be granted a period of [DLR] to
remain on this basis.”

74. Fourth, it seems not merely are the police not under an obligation to apply for DLR, but this important
power is not known to all or perhaps many of them. Mrs Sayeed has explained that she remains “firmly of


-----

(Admin)

the view that, in general, the police are aware of the ability to apply for [DLR] on behalf of victims who are
assisting them with their inquiries” (emphasis added). Significantly, she does not say that all police know or
are aware of the opportunity to apply for DLR or that even those who are aware of it appreciate their
obligation to do so.

75. There is, on the one hand, evidence that a number of police forces have made requests for DLR on
behalf of trafficking victims who have helped the police, and, on the other hand, there is evidence about
others who have helped the police, who have failed to request DLR. The Subatkis twins, who are the Third
and Fourth Claimants, assisted the police, who for reasons which I do not know did not request DLR on
their behalf. In consequence, they did not receive DLR or indeed any benefits from the Defendants.

76. My task is to ascertain whether this regime achieves the results which Article 11 of the Directive and
Article 12 of ECAT requires to be achieved. I have come to the conclusion that even after taking account of
the right of the Government to decide on “the choice of the form and method” to satisfy the provisions of
Article 11 of the Directive and Article 12 of ECAT as well as Mr. Blundell's submissions, the present policy
of not allowing the victims or their legal representatives to request DLR on the grounds of agreeing to
assist the police with their enquiries means that the desired result in Article 11 is not achieved in the light of
the four factors to which I have just referred.

77. I should also consider the fall-back position of the Claimants, which is that ithe support regime for
dealing with those who have been trafficked and who have helped the police is “inherently unfair”, as set
out in the Detention Action case Applying that approach in that case, there is more than a possibility that
the regime does not have, in the Master of the Rolls' words, “the capacity to react appropriately to ensure
fairness” in the) absence of a right on the part of the trafficked victim or his or her legal representatives to
apply for DLR. I have concluded that the Claimants' case on this aspect of the policy reaches the high
threshold of showing unfairness as well as failing to comply with the Article 11 and 12 requirements.

_(ii) Cases where support is required to enable the victim to claim compensation_

78. The Claimants contend that the Defendants have failed to make adequate provision in their Guidance
where support is required to enable trafficking victim to claim compensation. This submission fails to
appreciate two matters. First, Article 15 of ECAT (which is mentioned in the Guidance) provides for the
right of victims of **_modern slavery to compensation from traffickers. Second, the Guidance proceeds to_**
explain that it may be appropriate to grant victims of modern slavery, who have been trafficked, DLR to
stay in the United Kingdom on the grounds that they are pursuing a claim for compensation against the
traffickers. The Guidance states that:

“The fact that someone is seeking compensation through the civil courts does not in itself merit victim
status or a residence permit. When determining whether to grant a residence permit the Home Office must
consider:

-the type of compensation being sought

-the grounds of the claim

-how credible the claim is

-the likely length of the claim, and

-whether the person needs to be physically in the UK for the duration of their claim – in some instances it
may be more appropriate to facilitate return to the UK nearer to the hearing date or to arrange videos
conferencing facilities.”

79. I consider that where support is required to enable the victim to claim compensation, the regime
achieves the result which Article 11 requires to be achieved in providing appropriate support.


-----

(Admin)

_(iii) Cases where support is required (a) despite the fact that there are no criminal proceedings or criminal_
_proceedings have come to an end; (b) because of the personal needs and circumstances (psychological, physical,_
_social or safety needs; and (c) where an application for DLR is pending or cannot be made_

80. The case for the Claimants is that the SSHD was obliged to put in place a comprehensive framework
of protection for victims of trafficking by providing measures to provide assistance and support based on an
assessment of their needs which is not limited to the 45-day recovery and reflection period, but which
extends to providing victims of trafficking such support as is necessary. They rely on a large number of
objections.

81. Mr. Westgate contends that the Defendants have failed to make adequate provisions in their Guidance
for this group of victims of trafficking in the post-support NRM stage, because the circumstances in which
DLR might be granted are so limited, with the consequence that they do not provide the support required
under Article 12 of ECAT or under Article 11(2) of the Directive. Mr. Westgate also complains that the
Guidance fails to provide adequate support pending a decision after the trafficked victim has sought DLR
or other lawful residence under the Citizens Directive or any other basis. He contends that the support duty
is also not satisfied by the discretionary remedies in the form of the possibility of temporarily extending the
NRM or by providing an extension of support for 14 days. He submits that the present regime lacks “the
capacity to react appropriately to the needs of victims with the result that gaps in the provision of necessary
support are inherently likely and cannot be explained as aberrant decisions in individual cases”.

82. Ms Roberts makes many criticisms of the support regime and she also gives helpful examples of
cases studies in the exhibit to her witness statements where various victims of trafficking have not obtained
the support to which they were apparently entitled under the regime in force. Mrs Sayeed seeks to answer
these criticisms. It is important to appreciate that under the regime under challenge, the support provided
to victims of trafficking is, first, the extension of the 45-day recovery and reflection period; second, the
extension of the 14-day support period; third, DLR, which gives the recipient the right to remain in this
country. I will deal with them in that order.

_The extension of the 45-day recovery and reflection period_

83. As Mrs Sayeed explains, this period can be extended in the period after the time when a reasonable
grounds decision is made in his or her favour, and during this extended period, the trafficking victim is
entitled to full support. The Guidance provides that there is an obligation to review the progress of the
trafficking victim on day 30 of the 45-day recovery period in order to “monitor progress on the case [and]
check it is on target for a conclusive decision”. This duty has to be considered in the light of the duty of the
Competent Authority [i.e. the Home Office and the National Crime Agency] of “gathering information to
make the conclusive decision” from “the support provider, first responder [the Salvation Army],
investigating police force where relevant … and local authority (in the case of children)”. The purpose of
those inquiries is to decide if an extension of the 45-day recovery and reflection period “is warranted”. It is
explained that likely reasons will include “serious health issues, serious mental health or psychological
issues (including post traumatic stress disorder) requiring longer period of recovery and reflection and high
levels of victim intimidation”. This answers the complaint of the Claimants that inadequate support is
provided because of the personal needs and circumstances (psychological, physical, social or safety
needs) of the trafficking victim. Another reason why this period can be, and is, extended is, as Mrs Sayeed
explains, where DLR is being sought and a decision has not been made on the application in the 45-day
recovery and reflection period, which I suspect is a common occurrence.

_Extension of 14-day support period_

84. It must be remembered that those victims with positive reasonable grounds decisions are entitled to
support and it will be provided to those who request it. The Defendants' case is that after a person is
conclusively accepted as a victim of trafficking, he or she is entitled under the contract between the Home
Office and the Salvation Army, which provides victims with care and support, to an extra support period of
14 days during which they will be assisted to either return home or to receive mainstream support where


-----

(Admin)

they are entitled to stay in the United Kingdom. The Home Office does grant extensions to this 14-day
extra support period for those with a conclusive grounds decision based on individual circumstances, which
vary from case to case. Case sensitive decisions are made. Mrs Sayeed explains that common grounds for
granting an extension are to allow a victim to obtain identity documents, or while an application for DLR is
outstanding, or because they are waiting for suitable accommodation to move to. She explains that the
extension lengths are designed to encourage support providers to chase outstanding issues in a timely
manner and to ensure that the victims awaiting accommodation are not made homeless. Further
extensions can be, and are, granted.

85. Mrs Sayeed in her second witness statement has given examples of recent extension requests and
grants for EEA Nationals for second and third extensions. She notes that the Modern Slavery Unit have
confirmed that the majority of extensions are granted to EEA nationals. Mrs Sayeed explains that
extensions are granted to ensure that victims are not placed in difficulties while their transition out of NRM
is being managed. She does not accept that there is a “support gap”. She states that extensions of support
are considered and granted “precisely to ensure that, in appropriate cases, victims are not placed in
difficulties when their transition out of the NRM is managed; for example by providing support whilst
awaiting the result of an application for [DLR]”, or perhaps to allow a victim to obtain identity documents.
What is clear is that there is a system in place to deal with and to grant extension applications. The
Guidance refers to entitlements under Article 12 ECAT and Article 11 of the Directive being met, I stress
that it is stated in the Guidance in respect of applications for DLR that “each case should be considered “on
its individual merits and in full compliance with the UK's obligations under…the Directive” which would
include Article 11(2) and this would ensure that extensions of the support to trafficking victims would then
be granted.

86. Ms Roberts complains of a number of matters as she:
i)  Criticises the lack of support after the conclusive grounds decision has been made; she refers with
examples to the fact that the trafficking victims are only given 14 days to leave their accommodation and
that extensions are generally granted for 14 days or less. Mrs Sayeed's response is that in the six-month
period ending on 8 March 2016, 33 extensions were sought from the Modern Slavery Unit relating to DLR
purposes and 32 were granted.

ii)  Is concerned that many of the extensions granted of 14 days are too short, but Mrs Sayeed explains
that the Home Office remains of the view that granting short extensions is the most appropriate way of
achieving a swift resolution, particularly as the time-limited additional support means that all involved are
encouraged to move as quickly as possible to resolve outstanding issues. Mrs Sayeed also reports that the
**_Modern Slavery Unit has confirmed that short extensions “really do assist in resolving issues more swiftly_**
than might otherwise be the case”. I see no reason to doubt the sense of this or the evidence of Mrs
Sayeed that although extensions are usually for 14 days, extensions for different periods can be, and are,
granted.

iii) Is critical of the support after NRM, but Mrs Sayeed explains that organisations like the Salvation Army
are very experienced in working with victims and they know how to assist them in supporting the victims
and in applying for support. She adds that the reason why the Salvation Army was selected was because it
could provide such support.

iv) Is dissatisfied that the Guidance is “entirely silent as to any enquiry which needs to be made of
individual need for accommodation or support and how such individual need is to be assessed at the
conclusive grounds stage”. Mrs Sayeed explains that those bodies carrying out the assessments are well
aware as to how to assess them and also that it might be necessary to do so at the conclusive grounds
decision stage. She explains that in the six-month period to 2 March 2016, the **_Modern Slavery Unit_**
received 80 first time requests for an extension beyond the 14 days and of those requests, 33 of them
related to extensions for DLR purposes of which all but one was granted.

87.  I have no reason to doubt any of the evidence of Mrs Sayeed and it makes good sense. So I am
unable to accept Ms Roberts' complaints


-----

(Admin)

_DLR_

88. Mr. Westgate criticises the wholly unstructured way in which applications for DLR are dealt with and he
referred to the experiences of Ms Roberts, who has given examples of problems with these applications.
She explains that many of the victims with whom HFJ has been involved had never intended to claim from
the welfare state, but that even after the 45-day recovery and reflection period, many of them are not ready
for work because of their experience. It is also pointed out that in addition, the majority of them had and
have poor English language skills and that they need time to improve their language skills if they are not to
be forced to work illegally and to be subjected to further exploitation. As I have explained, the Defendants
provide support through the grant of DLR and the Guidance states in the section entitled “Actions for Home
Office and UKHTC if the conclusive grounds decision is positive” that “a person who is accepted as a
victim of trafficking will not be granted DLR solely as a result of that decision unless they meet the relevant
criteria. To obtain DLR, there must be compelling reasons to allow them to remain in the U.K. for a longer
period based on their individual circumstances where they do not qualify for other leave such as asylum or
humanitarian protection”. In addition there are also the provisions relating to the grant of DLR to which I
have referred, where he or she needs to stay in the United Kingdom to pursue a claim for compensation
against the traffickers and needs to assist the police with their enquiries.

89. The Guidance provides that as part of the reasonable grounds decision letter, potential victims of
trafficking will be asked if they would like to be considered for DLR in the event of a positive conclusive
grounds decision under the NRM. If they indicate that they would like to be considered, their applications
will then be considered under the criteria relating to their personal circumstances, helping police with
enquiries and pursuing compensation detailed in the Guidance, when a positive conclusive grounds
decision is issued. No forms would have to be completed or a fee paid for an initial application for DLR.
Furthermore, a person who has claimed asylum will automatically be considered for DLR if they are not
granted asylum or humanitarian protection. A person who has been conclusively identified as a victim of
trafficking will be considered for DLR in any case depending on its particular circumstances.

90. There is a further dispute between Ms Roberts and Mrs Sayeed as to how the victims of trafficking are
informed of the possibility of applying for DLR. As I have explained, the Guidance notes that potential
victims of trafficking are being asked, as part of the reasonable grounds decision, if they would like to be
considered for DLR in the event of a positive conclusive grounds decision. Ms Roberts says that she has
found no evidence of this happening in practice. This is disputed by Mrs Sayeed, who explains that the
U.K. Visas and Immigration Competent Authority in Leeds have confirmed to her that they have been
asking potential victims to request DLR in decision letters sent to them, but that in practice victims “have
not really engaged with this by making requests” for DLR. Mrs Sayeed has said that the Leeds Competent
Authority has proceeded to consider DLR automatically where it has made a conclusive grounds decision,
regardless of the lack of request for DLR. I must accept the account of Mrs Sayeed in accordance with the
approach of Woolf J (as he then was) in R v Oxfordshire Local Valuation Panel ex parte Oxford City
Council (1981) 79 LGR 432, 44013.

91. Ms Roberts is critical of the information provided to victims explaining their rights and the extent to
which victims are signposted for legal advice. There is another dispute about this, as Mrs Sayeed says that
the support providers give victims the support they need. She explains that the needs of the victims vary
and so a British victim would not need signposting to immigration advice. A further criticism made by Ms
Roberts is that the Guidance has been misunderstood, as DLR applications were refused from an EEA
national and she refers to the case of the Claimant AG. Mrs Sayeed accepts that his case was dealt with
incorrectly and that the Defendant's policy was not properly understood. She is satisfied that the process is
now understood by those who have to make the relevant decisions. Mrs Sayeed adds that what occurred
at the stakeholder meeting which she attended did not lead her to conclude that the organizations in this
field were confused. Ms Roberts complains about the fees payable but Mrs Sayeed has explained that new
fee regulations on this came into effect on 18 March 2015.

92. Ms Roberts contends that there is no right of appeal against a refusal of DLR under s82 of the
Nationality Immigration and Asylum Act 2002 and she relies on the decision in R(FM) v Secretary of State


-----

(Admin)

for Home Department _[2015] EWHC 844 (Admin). Mrs Sayeed points out that subsequently, on 6 April_
2015, a new provision amending s82 came into force and it gave a right of appeal listed with the refusal of
a protection claim, a human rights claim or the revocation of protection status. So if someone makes such
a claim as part of an application for DLR, there will be a right of appeal against its refusal. The Claimants
contend that this is very unlikely to apply to EEA nationals.

93. A further complaint of Ms Roberts is that the Guidance “prioritises” free movement rights over DLR but,
with respect, that is not correct. If a victim is an EEA national exercising free movement rights, DLR is not
needed, as the victim has an independent right to remain in the United Kingdom.

94. The Claimants contend that “the Directive and ECAT do not limit the provision of support to people
who have positively been granted leave to remain or enjoy some other right to reside”. Insofar as it appears
to be suggested that the applicants for DLR should have the right to remain in the UK, this case fails to
appreciate that the Directive does not create a right of residence for trafficking victims. That right of
residence is contained in the Trafficking Residence Directive, but the United Kingdom has not opted into
that Directive and so it does not apply in this country. If a victim of trafficking has no right to remain in the
United Kingdom, he is liable to removal and can be removed. In addition, it must not be forgotten that the
SSHD has a policy that entitles her to expect that those without a right to remain in the United Kingdom
should be expected to leave (R (Daley-Murdock) v Secretary of State for the Home Department _[2011]_
_EWCA Civ 161)._

_Conclusion_

95. Mr. Westgate complains that the support regime is defective as it fails to recognise any duty to provide
support after the 45-day recovery and reflection period because the provision of support after that period is
discretionary. Indeed as I have explained in paragraph 65(v) above, the Guidance when dealing with
applications for DLR states that “each case should be considered on its individual merits and in full
compliance with [the Directive]…”. The Directive includes Article 11(2). This shows the support regime
aims to comply with the duties envisaged by Article 11 of the Directive and this is recognition of the support
duty. Turning to the next issue which is whether the intended result of Article 11 is achieved, there is
nothing in the Guidance, which seeks to limit or eliminate the duty to support, but it provides assistance on
showing the ways that the duty can be satisfied. Consistent with that, the Defendants' policy seeks to
show if support is necessary, what support can be provided (for example by DLR or obtaining extensions)
and how it should be provided (for example by lengths of extensions). None of this indicates in any way
that the support duty in Article 11 of the Directive is undermined or that the Defendants will not achieve the
result sought to be achieved.

96. The next criticism of Mr. Westgate is that the Defendants consider that after the recovery and
reflection period, a right of support can only arise where a decision has been made that the victim is
lawfully present or they have been granted DLR. There is no reason why DLR cannot be applied for after
the recovery and reflection period at a time when the victim has no right of support and has no right to be in
the United Kingdom. Indeed, the Defendants have indicated that they will consider an application for DLR
from the Third and Fourth Claimants who have no right to remain in the United Kingdom. In addition, there
is much support that can be given even where the victim has not been granted DLR in the form of
extensions to the recovery and reflection periods and to the additional 14-day period. So I cannot accept
that criticism,

97. Mr. Westgate also contends that DLR fails to implement the duty to provide support after the NRM as it
is only “contemplated in the narrowest of discretionary circumstances”. He points out that it is said that
there must be “particularly compelling circumstances” or “compelling factors based on their individual
circumstances”. There is nothing in those words to dilute or to undermine the obligations in Article 11 of
the Directive or Article 12 of ECAT or to make it less likely that they will achieve the desired result of these
provisions. After all, nothing has been put forward to show that “particularly compelling circumstances” or
“compelling factors based on their individual circumstances” would not cover all the circumstances for
triggering the requirement of support under Article 11(2) of the Directive or Article 12 of ECAT. The same


-----

(Admin)

reasoning applies to the complaint that DLR is not automatically considered at the conclusive grounds
stage but only where “appropriate” “where an individual has requested leave”. Indeed, to my mind the fact
that a trafficking victim has no means of support or assistance in this country would in my opinion,
constitute “particularly compelling circumstances” or “compelling factors based on their individual
circumstances” for providing mainstream support. I have no reason to believe that all “particularly
compelling circumstances” or “compelling factors based on their individual circumstances” of a trafficking
victim would not in those circumstances trigger a duty on the part of the Defendants to give Article 11(2)
assistance and support.

98. Having considered all the Claimants' points as well as the evidence and the case studies of Ms
Roberts, I conclude that the power to grant DLR and time extensions to support means that the trafficking
victims receive the necessary assistance, and support achieves the results desired in Article 11 of the
Directive and Article 12 of ECAT in the three categories of cases which I am considering14. In respect of
the fallback position of the Claimant, there is nothing inherently unfair in the regime, and the regime has
the capacity to react appropriately to ensure fairness. Of course if the Defendants fail to apply the regime
correctly, the individual concerned would be entitled to bring a claim for judicial review against the
appropriate Defendant

_(iv) Individual Needs Assessment_

99. The case for the Claimants is that the Defendants did not accept any obligation to carry out individual
regular assessments or any assessments at the end of the recovery and assessment period, or after
criminal proceedings, to ascertain if further support is needed for the trafficking victim. Mr. Westgate
contends that the individual and regular assessments were necessary to determine what measures were
“necessary” to ascertain the needs of the trafficking victims in the light of the requirements in Article 11 that
“Member States shall take the necessary measure to ensure assistance and support”. Mr. Westgate points
out that there are only provisions in the arrangements made by the Home Office with the service provider,
the Salvation Army, that it shall first, conduct “an initial needs based assessment of the [purported
trafficked victim] within three hours of [that person's] referral to [the service provider]” and, second,
“conduct a Face-to-Face Detailed Needs Based Assessment of [the trafficked victim] within 48 hours of a
Positive [reasonable grounds] decision that there are such grounds that the person concerned has been
trafficked”.

100. Mr. Blundell points out correctly that there is no express provision in the Directive or in ECAT which
expressly requires a process of formalised assessment after the end of the 45-day recovery and reflection
period or at the end of criminal proceedings. Mrs Sayeed explains that it is not surprising that the means of
assessments at the conclusive grounds stage are not covered in the Guidance, as the Guidance is directed
to the Competent Authorities [i.e. the Home Office and the National Crime Agency] and not to the support
providers who would undertake the needs assessment. I note that the obligation in Recital 18 of the
Directive15 is merely for assessments to be carried out according to national procedure, without any
specific requirement for what is envisaged or what is needed.

101. There obviously have to be assessments on a number of occasions. First, when victims request DLR,
it is implicit that there would have to be an assessment in order to see if they are entitled to it because, for
example, there are compelling personal circumstances or other grounds for obtaining DLR. Second, there
has to be an assessment made before deciding if the 14-day post-conclusive decision period should be
extended. Third, there are provisions (see part 24.5 of the Guidance) which require the Competent
Authority when granting an extension to minute “a summary of progress of the victim since the last review
including reference to any mental health issues or compassionate circumstances”, “a brief action plan
setting out what steps will be taken in the next period to progress the claim” and “a recommendation clearly
setting out the argument for…extending the recovery and reflection period further”. Fourth, similarly, when
refusing an extension, the Competent Authority must, among other things, “send a letter to the
individual…explaining the reasons for the refusal”. These requirements show that what was implicit in the
decision-making concerning applications for extensions was the need for an assessment. Fifth, Mrs


-----

(Admin)

Sayeed explains that if the needs of victims change whilst in the NRM support, then the support provider
would be aware of it and would respond accordingly to provide the appropriate support provisions. I have
no reason not to accept this evidence.

102. Sixth, as I have explained, there are monitoring provisions in Part 24 of the Guidance, which provide
that there is an obligation to review the progress of the trafficking victim on day 30 of the 45-day recovery
period in order to “monitor progress on the case [and] check it is on target for a conclusive decision”. This
duty has to be considered in the light of the duty of the Competent Authority [i.e. the Home Office and the
National Crime Agency] of “gathering information to make the conclusive decision” from “the support
provider, first responder [the Salvation Army], investigating police force where relevant...and local authority
(in the case of children)”. The purpose of those inquiries is to decide if an extension of the 45-day recovery
and reflection period “is warranted”. These investigations would have required assessments especially as it
is explained that likely reasons will include “serious health issues, serious mental health or psychological
issues (including post traumatic stress disorder) requiring longer period of recovery and reflection and high
levels of victim intimidation”.

103. Ms Roberts contends that assessments are required as Article 11(7) of the Directive provides for
measures to be provided “based on an assessment of individual circumstances and need”. That is not
correct, as the only obligation is for Member States to “attend to victims with special needs”. In any event,
the matters set out in that Article would be considered in the monitoring and assessing processes to which
I have referred.

_Conclusion on Issues 3 and 4_

104. I have explained in paragraph 76 and 77 above my conclusions in respect of the situation where
support is needed after the 45-day recovery and reflection period and where criminal proceedings are
pending. With the exception of that issue, I have reached the conclusion that none of the other points made
by the Claimants, whether considered individually or cumulatively, shows that the practice adopted by the
Defendants fails to achieve the results required by Article 11 of the Directive and Article 12 of ECAT.

**Issue 5: The Claimants' Assessment Issue**

105. This issue overlaps with the last issue. Mr. Westgate contends that the Defendants have failed to
carry out individual assessments of the needs of the Claimants to determine whether or not they need
support and assistance, and if so, what. The Defendants point out that the Claimants did receive social
security benefits while the applications of AG and RT for DLR were under consideration. Mr. Westgate
contends that this response misses the point as the Defendants have failed to accept that they may have
been under a duty to provide support during the periods when victims could not access social security
benefits. He submits that the Defendants had a duty to assess the needs of each Claimant for support
once their entitlement to JSA and housing benefits had been terminated.

106. Mr. Westgate points out that AG and RT are both still suffering from the effects of being victims of
trafficking. He refers to the evidence that AG suffers from depression of “moderate severity”. Dr Chisholm
explains concerning AG in a report of 17 April 2015 that :

“as a result of his depressive disorder, he cannot concentrate at college. This means he cannot learn
English, which would help him gain employment”

107. RT suffers from “mild functional impairment …due to his adverse experience of working at
Houghtons”. Both RT and AG are claiming compensation. The Subatkis twins are said to be vulnerable and
they needed support to act effectively as witnesses at the trial in January 2016 and thereafter because of
their personal circumstances.

108. I have explained that all of the Claimants' cases are currently being assessed and hopefully they will
be completed speedily. In those circumstances, it is premature to grant the relief sought, which is a
mandatory injunction that the SSHD “assess the Claimants' needs for support and assistance as victims of
trafficking and to provide such support as is found to be necessary” especially as I have no reason to


-----

(Admin)

believe that they will not do so. Indeed, in the Order prepared by Counsel after the draft of this judgment
was circulated, neither side, correctly in my opinion, sought an Order dealing with this issue.

**Issue 6: The Access to Benefits Restriction Issue**

109. This issue concerns the questions of, first, whether the SSWP can restrict access to benefits to
victims of trafficking on the basis that the Claimants do not satisfy the GPOW test and, second, whether
the GPOW test should be disapplied in their cases. This important issue was the subject of short written
submissions in the respective skeleton arguments of the parties, but it was not developed in oral argument
by either party at the hearing. When I subsequently wrote to Counsel asking how I should deal with this
issue in the judgment to be handed down, the Defendants stated that I should give my decision on it. The
Claimants disagreed, as they explained that their position at the hearing was that this issue belonged more
to submissions relating to remedies and that it could only be addressed once substantive issues relating to
the scope of the duty have been resolved. I agree and I am very conscious that I would have been
assisted greatly by detailed oral submissions on this issue. In addition, might turn out to be academic if the
Claimants are not otherwise entitled to support. I therefore will not deal with it.

**The Order**

110. Counsel have made helpful written submissions on costs. They both agree that the Defendants
should be ordered to pay a proportion of the Claimant' costs, but there is a dispute about what proportion it
should be. The Claimants say that a fair and proportionate order for costs should be that the Defendant
should pay 60% of the Claimants' costs. The Defendants say that they should only have to pay 25% of the
Claimants' costs. I have considered with care the rival submissions and I have considered the extent to
which each party has succeeded. I have concluded that the Defendants should pay 50% of the Claimants'
costs.

111. In the draft Order produced after the draft of this judgment had been circulated but before the time
fixed for the hand down of this judgment, the Claimants and the Defendants each sought for the first time
an additional Order which had not been the subject of the application before me earlier and which therefore
had not been the subject of any submissions. Neither of these Orders was agreed to,

112. The Order, which was sought by the Defendants but which was only agreed to in part by the
Claimants, stated that:

“The support duty under Article 11(2) does not create any independent right of residence or independent
basis for the grant of DLR, and ceases to apply after expiry of the 45-day reflection and recovery period in
cases where a victim does not have a right of residence in the United Kingdom.”

113. The Claimants were content to agree that the support duty under Article 11(2) does not create any
independent right of residence, which is a view with which I agree. There is a dispute relating to the
correctness of the remainder of the Order, and this can only be resolved after oral submissions. The
Defendants have not sought an oral hearing for this and I will make no further order in relation to it.

114. The Order, which is sought by the Claimant but which is not agreed to by the Claimants, stated that:

“The Defendant shall, pursuant to Article 11(2) of the Trafficking Directive and pending determination of
any application for [DLR] made or to be made by the Claimants, provide support to the Claimants, namely
provision of their existing accommodation, subsistence of £65 per week and access to outlook. Such
support is to be paid from and under the NRM system.”

115. This Order is strongly opposed and it clearly requires oral submissions and a very speedy hearing for
which I will give directions.

**Conclusions**

116. I conclude in respect of the issues raised on this application that:

(1) Article 11 (2) of Directive 2011/36:


-----

(Admin)

i)  Sets out an obligation separate from Article 11(1) of the Trafficking Directive 2011/36 so as to provide a
free-standing duty of support which is not linked to criminal proceedings;

ii) Imposes an obligation on the UK to provide a trafficked person with assistance and support as defined
in Article 11(5) of the Directive, in the post 45-day reflection and recovery period; and

iii) Does not create an independent right of residence.

(2) The Victims of Modern Slavery: Competent Authority Guidance (v.2.0) under the heading Victims who
_are helping police with their enquiries at pps 67-68 (under Section 19.2) is unlawful in that it does not allow_
victims or their legal representatives to request Discretionary Leave to Remain (DLR) on the grounds of
agreeing to assist the police with their enquiries.

(3) Applications for DLR have to be considered in compliance with the Trafficking Directive 2011/36 and
Article 12 and other provisions of the European Convention on Against Trafficking in Human Beings.

(4) For the purposes of the preceding paragraph, consideration of an application for DLR in compliance
with the Trafficking Directive 2011/36 includes consideration of the duty to provide support under Article
11(2) of that Directive, including where necessary, support pending determination of an application for
DLR.

117. It is also appropriate to make orders that

(1) The anonymity Order is lifted in the Subatkis claim CO/5652/2015.

(2) The Claimants' claim for judicial review is allowed to the extent identified in the Paragraph 116 above.

(3) Pending any remedial action taken by the First Defendant to remedy the deficiency in the Guidance
identified at para 2 of the Declaration above, applications for DLR from victims of trafficking on the basis
that they are helping police with their enquiries be accepted from such victims and their representatives.

(4) The Defendants shall pay 50 % of the Claimants' costs.

(5) There shall be a detailed assessment of the Claimants' publicly funded costs pursuant to the provisions
of the Community Legal Services (Costs) Regulations.

(6) Adjourn the claim set out in paragraph 114 above for further consideration.

**End of Document**


-----

181 (Apr)

# *R (on the application of Galdikas and others) v Secretary of State for the
 Home Department [2016] All ER (D) 181 (Apr)

[2016] EWHC 942 (Admin)

Queen's Bench Division, Administrative Court (London)

EnglandandWales

Sir Stephen Silber

26 April 2016

**Immigration – Leave to remain – Victim of trafficking – Claimant victims of trafficking being unable to claim**
**state benefits – Claimants issuing judicial review proceedings – Whether European law requiring provision**
**of assistance and support – Whether European convention applying although not incorporated into English**
**law – Whether first defendant Secretary of State misdirecting self as to period support duty continuing –**
**European Parliament and Council Directive 2011/36, art 11 – Convention on Action against Trafficking in**
**Human Beings, art 12.**
Abstract

_Immigration – Leave to remain. The Administrative Court partially allowed the claim for judicial review by the_
_claimant victims of trafficking. It held that part of the first defendant Secretary of State's guidance 'Victims of_
**_Modern Slavery: Competent Authority Guidance (July 2015)' was unlawful, as it did not allow victims of trafficking_**
_or their legal representatives to request discretionary leave to remain on the grounds of agreeing to assist the police_
_with their enquiries._
Digest

The judgment is available at: [2016] EWHC 942 (Admin)

The claimant European Economic Area nationals had all been conclusively recognised as victims of trafficking. The
first and second claimants were not involved in a criminal investigation relating to those who had trafficked them,
although there remained the possibility of an investigation. The third and fourth claimants had co-operated with the
police and their solicitors had asked the police to urgently request discretionary leave to remain (DLR) for them,
pursuant to the first defendant Secretary of State's guidance 'Victims of **_Modern Slavery: Competent Authority_**
Guidance (July 2015)' (the guidance). The guidance provided that, where there were reasonable grounds for
believing that a person had been the victim of trafficking, they were given a minimum of a 45-day recovery and
reflection period whilst a substantive conclusive grounds decision on the trafficking claim was made. Support to
meet the immediate and ongoing needs of the potential victim was provided during that period and that usually
comprised the provision of accommodation and cash payments. However, the police replied that that process had
no longer been required and the claimants had not given evidence in a criminal trial, as the defendants had pleaded
guilty. The claimants had been unable to claim state benefits, even though they had no other means of support.
They issued judicial review proceedings.

The issues for determination included, first, whether art 11(2) of European Parliament and _[Council Directive](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9X13-GXFD-80CC-00000-00&context=1519360)_
_[2011/36 specified an obligation on member states which was additional to, and separate from, the obligation in art](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:61JH-9X13-GXFD-80CC-00000-00&context=1519360)_


-----

181 (Apr)

11(1) of the Directive and not linked to criminal proceedings. Second, whether the claimants could rely on the
provisions in the Convention on Action against Trafficking in Human Beings and, in particular, art 12, even though
the Convention had not been incorporated into English law. Third, whether the Secretary of State had misdirected
herself as to the period for which the support duty continued and, in particular, whether it extended to individuals
who had been recognised as victims of trafficking. Further, whether the defendants had failed to ensure the
existence of a comprehensive or lawful system for the provision of support for victims of trafficking.

The court ruled:

(1) Article 11(2) of the Directive was a discrete obligation and, when read with other parts of art 11, in particular art
11(4), it meant that, in the post-45 day recovery and reflection period, the United Kingdom was obliged to provide a
trafficked person with assistance and support. Accordingly, it imposed an obligation on the UK to provide a
trafficked person with assistance and support, as defined in art 11(5) of the Directive, in the post 45-day reflection
and recovery period. However, the Directive did not create any independent right of residence (see [44], [116] of the
judgment).

_G v Director of Legal Aid Casework (British Red Cross Society intervening)_ _[[2015] 3 All ER 827 considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5GNX-7641-DYBP-M1YX-00000-00&context=1519360)_

(2) The claimants could not rely on the Convention, which had not been incorporated into English law. However,
they were not precluded from relying on the guidance, which specifically adopted the Convention, or parts of it,
where it had been accepted as the Secretary of State's policy in the guidance. The whole of the Convention, or of
art 12, had not been incorporated for all purposes into English law as being the Secretary of State's policy.
However, the guidance stated that she would act in accordance with art 12 of the Convention. In particular, the
Secretary of State's policy was that she would apply the Convention approach to deal with applications for DLR
from those who had been recognised as the victims of trafficking in specified matters and to a limited extent. The
Secretary of State had to follow that policy, unless there was good reason not to do so. Accordingly, applications for
DLR had to be considered in compliance with the Directive, art 12 of the Convention and other provisions of the
Convention. That included consideration of the duty to provide support, under art 11(2) of the Directive, including
where necessary, support pending determination of an application for DLR (see [66], [116] of the judgment).

_Re Hetherington, Gibbs v McDonnell_ _[[1989] 2 All ER 129 considered; Maclaine Watson and Co Ltd v International](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-6151-00000-00&context=1519360)_
_Tin Council_ _[[1989] 3 All ER 523 considered;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-49G0-TWP1-60RX-00000-00&context=1519360)_ _R (on the application of Lumba) v Secretary of State for the Home_
_Department; R (on the application of Mighty) v same_ _[[2011] 4 All ER 1 considered;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:53VW-MDP1-DYBP-M4P2-00000-00&context=1519360)_ _R (on the application of_
_Atamewan) v Secretary of State for the Home Department_ _[[2013] All ER (D) 61 (Sep) considered;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:599S-X571-DYBP-N3C4-00000-00&context=1519360)_ _R (on the_
_application of SG and others (previously JS and others)) v Secretary of State for Work and Pensions_ _[[2015] 4 All](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HHT-9M41-DYBP-M3F7-00000-00&context=1519360)_
_[ER 939 considered; R (on the application of BG) v Secretary of State for the Home Department](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5HHT-9M41-DYBP-M3F7-00000-00&context=1519360)_ _[[2016] All ER (D) 74](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JHR-T581-DYBP-N21M-00000-00&context=1519360)_
_[(Apr) considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JHR-T581-DYBP-N21M-00000-00&context=1519360)_

(3) Even after having taken account of the right of the government to decide on the choice of form and method to
satisfy the provisions of art 11 of the Directive and art 12 of the Convention, as well as the defendants' submissions,
the policy of not allowing the victims or their legal representatives to request DLR on the grounds of agreeing to
assist the police with their inquires meant that the desired result in art 11 of the Directive was not achieved in the
light of four relevant factors: (i) DLR had to be requested by the police; (ii) the request had to be made by the
investigating police force, rather than the victim or their legal representatives; (iii) there was no obligation on the
police to make a request for DLR for somebody assisting them; and (iv) that important power was not known to all,
or perhaps many, of them. There was more than a possibility that the regime did not have the capacity to react
appropriately to ensure fairness in the absence of a right on the part of the trafficked victim or his legal
representatives to apply for DLR. The claimants' case on that aspect of the policy reached the high threshold of
having shown unfairness, as well as having failed to comply with the requirements of art 11 of the Directive and art
12 of the Convention. However, none of the other points made by the claimants, whether considered individually or
cumulatively, showed that the defendants' practice failed to achieve the results required by art 11 of the Directive
and art 12 of the Convention (see [71]-[74], [76], [77], [104], [116] of the judgment).


-----

181 (Apr)

_Detention Action v Lord Chancellor; Subnom R (on the application of Detention Action) v First-tier Tribunal_
_(Immigration and Asylum Chamber)_ _[[2015] All ER (D) 314 (Jul) applied.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5GJP-MGW1-DYBP-N3X0-00000-00&context=1519360)_

Martin Westgate QC and Catherine Meredith (instructed by Leigh Day) for the claimants.

David Blundell (instructed by the Government Legal Department) for the defendants.

The interested parties did not appear and were not represented.
Karina Weller Solicitor (NSW) (non-practising).

**End of Document**


-----

