# R (on the application of ZV) v Secretary of State for the Home Department

 [2018] EWHC 2725 (Admin)

Queen's Bench Division (Administrative Court)

Garnham J

18 October 2018Judgment

**Ms Samantha Knights QC & Zoe McCallum (instructed by Duncan Lewis) for the Claimant**

**Mr Tom Brown (instructed by Government Legal Department) for the Defendant**

Hearing dates: 2nd & 3rd July 2018

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Mr Justice Garnham:**

**Introduction**

1. ZV, a national of Lithuania, alleges that in 2009 she was “trafficked” into the UK by an abusive partner.
She says she was beaten, forcibly injected with heroin and forced into prostitution for some eight years.
She says, that during the period in which she was controlled by her trafficker, she committed a “string of
petty shoplifting offences at his direction” for which she received convictions.

2. The man whom the Claimant says trafficked her was deported to Lithuania in early 2017. On 20 June
2017, the Claimant was served with a Notice of Liability to Deportation by the Secretary of State for the
Home Department (“the Secretary of State”), on the basis that she was a persistent offender. On 23 June
2017, she was taken into immigration detention.

3. By these judicial review proceedings, ZV challenges her treatment by the Secretary of State. In
particular, she challenges his decision to deport her and to declare inadmissible her asylum claim. She
further alleges that her detention between 24 June 2017 and 30 October 2017 was unlawful, that the
Secretary of State failed to discharge his obligations to her under the EU Trafficking Directive and that he
committed breaches of his policy in relation to potential victims of torture. The Defendant resists all these
claims.

4. I heard argument in this case on 2 & 3 July 2018 from Ms Samantha Knights QC and Zoe McCallum on
behalf of the Claimant and from Mr Tom Brown for the Defendant. On the evening of the first day of the
hearing in this case, the Claimant received notification from the “Competent Authority”, a department of the
Home Office, that they had concluded that she was indeed a victim of trafficking. I gave the Secretary of
State time to consider the consequences of that decision and the parties, the opportunity to make written
submissions in response to any decisions the Secretary of State might make in the light of that decision.

5. On 10 October, as I was completing the drafting of this judgment, Mr Brown sent me a note about the
decision of Nicol J in H v SSHD _[2018] EWHC 2191 (Admin) a case in which Ms Knights had represented_
the Claimant and in which judgment was handed down in August 2018. I allowed both parties to make
additional submissions on the significance of that decision for this case.


-----

6. I am grateful to counsel for their clear and helpful submissions, both orally at the hearing and
subsequently in writing.

**The History**

7. I set out here the essential outline chronology of events relevant to this case. I will return to particular
aspects of the chronology in more detail at the appropriate points during the course of this judgment.

8. The Claimant was born on 8 July 1984. Her parents divorced when she was four and between the ages
of 18 and 21 she suffered multiple bereavements including the loss of her mother in 2006. Shortly after her
mother's death, she began a relationship with a man I shall call DE. In 2008, her stepfather died.

9. The Claimant says that as her relationship with DE progressed, he became physically abusive and
demanded money from her. She says that in November 2009, he drugged her and brought her to the UK.
On arrival, DE kept the Claimant locked in a house and demanded that she work for him as a prostitute.
When she resisted he beat her and forcibly injected her with Heroin. She was forced into prostitution and
raped repeatedly by different men. She said that after a year DE allowed her to leave the house, but only
to shoplift for him.

10. Between 8 July 2010 and 27 June 2012, the Claimant was convicted of theft on five occasions. She
was sentenced to 42 days imprisonment in March 2012 and 28 days in June 2012. She says that on
release from prison in April 2012 she discovered that DE was in prison. She then began a relationship with
a female friend she had made at HMP Holloway. The two women then relocated together to Lithuania
believing that DE was in the UK.

11. The Claimant reports, however, that they were spotted by family or friends of DE and subsequently
kidnapped, taken to woods and gang-raped. She says that DE appeared at the site of the rape. The
Claimant alleges that he threatened them with death if the Claimant did not return to him. The Claimant
was shortly thereafter brought back to the UK to resume captivity and forced prostitution for a further four
years until, in 2017, DE was deported. During this period the Claimant was again convicted of theft or
attempted theft.

12. The Claimant says that after DE was deported she began working as a gardener and cleaner. On 17
June 2017, she was convicted of possession of cannabis and of other offences and a suspended sentence
was activated. She was taken into custody at HMP Bronzefield.

13. On 20 June 2017, the Claimant was served with a Notice of Liability to Deportation. The following day
she was served with a notice that she was liable to deportation in accordance with the Immigration
(European Economic Area) Regulations 2016 (“the 2016 Regulations”) and given the opportunity to submit
any reasons as to why she should not be deported. On 23 June 2017 she was detained under immigration
powers at the same establishment.

14. On 18 July 2017, whilst in detention, the Claimant prepared a detailed handwritten statement (“the 18
July Letter”) on her circumstances, setting out why she said she should not be deported. That described
the abuse she had suffered at the hands of DE and the reasons why she feared return to Lithuania. I
return to the detail of that letter below.

15. The Home Office conducted its first detention review on 21 July 2017 and decided to maintain
detention. On 28 July 2017, the Defendant made a deportation order against the Claimant and certified it,
pursuant to Regulation 33 of the 2016 Regulations. The same day she was transferred to Yarl's Wood
IRC.

16. On 8 August 2017, the Claimant completed a form for potential adult victims of modern slavery for the
National Referral Mechanism (“NRM”). That was sent to the NRM's Competent Authority.

17. The Defendant conducted a second detention review on 23 August 2017 and decided to maintain
detention. On 25 August 2017, the Claimant's solicitors made representations regarding temporary
release, the Regulation 33 certification and the delay in reaching what is called “the Reasonable Grounds
Decision” under the NRM. On 31 August 2017, the Defendant refused the Claimant's temporary release.


-----

18. On 19 September 2017, a general practitioner, Dr Mahmood, carried out an examination at Yarl's
Wood IRC, pursuant to Rule 35 of the Detention Centre Rules 2001. On 22 September 2017, the
Defendant conducted a third detention review in response to the Rule 35 report and decided to maintain
detention.

19. The Home Office wrote to the Claimant on 26 September 2017, noting that she had applied for asylum
under the Refugee Convention on the basis that she had a well-founded fear of persecution in Lithuania.
Referring to paragraph 326E and 326F of the Immigration Rules, the Home Office declared her asylum
claim inadmissible.

20. On 4 October 2017, the Competent Authority wrote to the Claimant at Yarl's Wood IRC, indicating that
there were reasonable grounds for believing that the Claimant had been a victim of **_modern slavery_**
(human trafficking), a decision which is referred to hereafter as “a positive Reasonable Grounds Decision”.

21. On 10 October 2017, the Home Office emailed the Salvation Army, a charitable organisation that
provides accommodation for potential victims of trafficking, referring the matter for them, with a view to
their providing appropriate accommodation for the Claimant.

22. On 12 October 2017, the Defendant conducted a fourth detention review which supported release. On
13 October, the Claimant's release referral was approved.

23. On 24 October 2017, the Home Office confirmed that the certification was maintained and a release
referral had been made. On 27 November 2017, Mrs Justice Yip ordered the Claimant's release from
detention to suitable accommodation, which release was to take place by no later than 30 November 2017.
She ordered the Defendant to ensure that the Claimant received appropriate psychological therapy and
counselling treatment within ten days of release. On 30 November 2017, the Claimant was released from
detention to a safe house. She was then assigned a key worker, was registered with a GP and was
provided with eight sessions of counselling, anti-depressants and medication to treat her drug dependence.

24. As noted above, the Competent Authority made a positive conclusive grounds decision on 29 June
2018, which it communicated to the Claimant on 2 July 2018.  On 12 July, the Defendant withdrew the
Regulation 33 certification and indicated he had decided to maintain the Deportation Order.

**The 18 July 2017 letter**

25. The 18 July letter features large in this case and it is convenient to set out here the detail it contained.
The handwriting is good and, although at times the English is less than perfect, its meaning is tolerably
clear. The letter contains the following assertions:

    - On previous occasions, the Claimant says, she had reported that her partner was abusing her. She says
that he was “beating me up”. She says that she opened up about both his physical abuse and his sexual
abuse after her partner was deported. She was really scared about the prospect of being deported to the
same place where she had been ten years previously.

    - Her uncle died when she was 17. Her mother was badly depressed. Her grandfather passed away
when she was 19 and her mother was “lost in herself”. When she was 20, her best friend was killed, and
when she was 21, her partner killed himself. When she was 22, her mother died from lung and stomach
cancer. The following day her aunt died. She explained how the effect of these bereavements meant she
could not continue with her personnel management course at university and she tried to kill herself “a
couple of times”.

     - Initially, DE provided her with considerable support. But then he got her to try drugs and she “liked them”
because for a little while she could forget her life. She says that her mother left her a lot of money but she
spent it all in two years. That, she said, was related to her relationship with DE. She acknowledges it was
“my fault as well because I was using drugs and loved him”.

    - Her stepfather and godmother died, and shortly thereafter DE changed. He moved in with her and
started to beat her up. She said he persuaded her to sell the house and as a result the last of her money
was gone. She intended to escape from him and go to Spain but he discovered her plan. He “took me to a


-----

minibus” on which people were travelling to England and gave her tablets. As a result, she slept all the
way. She says he put a bottle of alcohol between her legs so that when she woke up and started to ask
where she was he would laugh at her and conclude that she was drunk.

    - Referring to the occasion when she arrived in England, nearly eight years previously, she said that DE
had locked her in a room and told her that because she “had the habit” she would have to go out and make
money. She said that he told her that she could work as a prostitute and he began to send men to her.
When there were no customers for a couple of hours, she said, DE would send her out to shoplift. If she
made less than £50 he would beat her up and deprive her of drugs. She said that her “customers” were
raping her even when she was sick. She said that she lived like that for eight years.

    - She was imprisoned on four occasions but when she was released he was always waiting for her
outside. She said that during this period, she “always liked girls; I hate men”. On the one occasion when
she left prison when DE was not waiting for her outside, she left with another female prisoner.

     - She said that she and her girlfriend then decided to run away together. The implication is that she and
her girlfriend then returned to her home country, Lithuania. She says that in her country “they hate gays”.

    - When DE left prison in England, his parents contacted him and told him that “everyone was laughing”
because she was gay. Friends of DE beat her up and then put her into the boot of a car and took her to a
forest. There she said “they raped us for two days”. Then DE came to her saying he was saving her and
that “it's disgusting who I became – a gay”. She said she believed she would never see her friend again
because he said he was going to shoot them both. She said he told them to dig a grave for themselves.
For four hours they were digging and begging not to be killed. She then promised to go back to England to
continue life with him. She was doing everything he said, so as to avoid being beaten. He let her girlfriend
go.

     - He allowed her to go onto a script of methadone and she remained “clean for two years”. After that, she
began to think about how to escape. She was arrested for an offence and had to go to court. Whilst
preparing for that appearance she asked her solicitor to speak to the probation service because she was
ready to tell them what had been going on.

     - She told everything to her friend, but her friend was sleeping with DE and she reported the matter to him.
As a result, he again locked her in the house. However a friend visited and released her.

    - She said that before her next appointment with the probation service DE beat her so badly that she was
not able to attend.

**The Grounds**

26. The Claimant advances 5 grounds of challenge. They are as follows:

**“Ground 1: The decision to certify under Regulation 33 of the 2016 Regulations is unlawful because (a)**
evidence before the Defendant at the time of the decision indicated a real risk that the Claimant's removal
pending appeal would breach Articles 3 and 8 ECHR and would therefore be unlawful under section 6 of
the Human Rights Act 1998 (“HRA”), (b) notwithstanding this evidence, the Defendant conducted
insufficient inquiries into the circumstances of the Claimant's case and consequently failed to discharge his
duty to satisfy himself on adequate information that certification would not breach section 6; and (c) in any
event, judged as at the date of the hearing on the evidence now before the court, the evidence that
certification would breach section 6 is now overwhelming.

**Ground 2:** The decision of 26 September 2017 to declare the Claimant's asylum claim inadmissible
without further investigation is unlawful because (a) it was made prior to final determination of the
Claimant's VOT status and was therefore in breach of the Defendant's published policy; (b) it was a blanket
decision taken without reference to any of the underlying facts and as such, created an unacceptable risk
of breach of Article 3 ECHR and the Refugee Convention; and (c) it was contrary to Paragraph 326F of the
Immigration Rules.


-----

**Ground 3:** The Claimant's immigration detention was unlawful from soon after 24 June 2017, to 30
October 2017 when she was released into safe accommodation. This is based upon the failure to identify
her as a potential victim of trafficking at the outset as should have been clear had adequate or any medical
assessments been carried out; delays in referring her to the NRM and delays within the NRM which would
have led to a reasonable grounds decision having been made soon after her detention commenced;
failures in conducting an adequate Rule 35/Rule 21 procedure which would also have identified her an
unsuitable for detention; and Hardial Singh principles.

**Ground 4:** The Defendant unlawfully failed to discharge his obligation to provide the Claimant with
assistance and support on receipt of a Reasonable Grounds decision under Articles 11(2) and (5) Directive
2011/36/EU and his published policy. That is so because (a) the Claimant's medical and welfare needs
_required her release from detention and yet Defendant unlawfully failed to discharge her, (b) the_
psychological support the Claimant required was not provided to her in detention; (c) the Defendant made
no adequate assessment of the Claimant's medical and welfare needs until her release from detention on
30 November 2017; and (d) the Claimant did not receive adequate mental health treatment whilst in
detention.

**Ground 5: The Defendant committed further breaches of its policy in relation to the Claimant as a potential**
victim of torture by (a) failing to refer the Claimant to the NRM even once the trafficking background was
very obvious; (b) seriously and unreasonably delaying in taking the Reasonable and Conclusive Grounds
decision and (c) unlawfully prioritising her removal over and above his responsibilities to identify and
protect her as a prospective VOT. Such breaches are of wider concern as they are symptomatic of a wider
problem and not isolated events.”

27. I deal with each ground in turn. But first, I set out the relevant legal framework in respect of modern
**_slavery._**

**_Modern Slavery - The Legal Framework_**

28. Article 4 of the European Convention on Human Rights (ECHR) provides that no one should be held in
slavery or servitude and no one should be required to perform forced or compulsory labour.

29. That provision has been supplemented by a Council of Europe Convention on Action against
Trafficking in Human Beings, signed on 16 May 2005 (“the Trafficking Convention” or “ECAT”). That
Convention was ratified by the UK on 17 December 2008 and came into force on 1 April 2009. The preamble to the Trafficking Convention recognises that protection of victims is one of its paramount objectives
and Article 1(b) identifies as a particular purpose in the Convention the design of “a comprehensive
framework for the protection and assistance of victims”. Article 10 of the Trafficking Convention deals with
the identification of victims of trafficking.  Article 12 provides for the assistance to victims and Article 13
provides for recovery and reflection periods.

30. The Trafficking Convention came into force in the UK on 1 April 2009 whereupon the UK established a
National Referral Mechanism. That mechanism tasked “Competent Authorities” with determining whether
those who claimed to have been trafficked for the purpose of exploitation, had in fact been trafficked.

31. On 14 October 2011, EU Directive 2011/36 on preventing and combating trafficking of human beings
and protecting its victims (“the Trafficking Directive”) came into force in the UK. The directive has direct
effect (see _Hounga v Allen [2014] 1 WLR 2889, paragraph 61). Article 8 of the Convention makes_
provision for non-prosecution or non-application of penalties to the victims of trafficking. Article 11 makes
provision for assistance and support for victims of trafficking.

32. On 31 July 2015, the Victims of Modern Slavery (“VMS”) Guidance came into force. Its purpose was
to implement the relevant provisions of the Trafficking Convention in domestic law. The guidance is
directed towards staff in Competent Authorities to help them to decide whether a person referred under the
NRM is a victim of trafficking. The guidance sets out the status of the NRM process. Specified public
authorities and frontline staff are required to refer potential victims of trafficking to the NRM as soon as
practicable. The Competent Authority should then make “a Reasonable Grounds Decision” within 5


-----

working days of referral. The Competent Authority will then make a Reasonable Grounds Decision as to
whether, on available information, there are reasonable grounds to believe a person has been a victim of
trafficking.

33. In PK (Ghana) v Secretary of State for the Home Department [2018] EWCA Civ 98 at [94], the Court of
Appeal held that the Secretary of State's policy guidance was intended to give effect to the Trafficking
Convention and that in so far as it failed to do so that would be a justiciable error of law.

34. If a Reasonable Grounds Decision is made, the policy provides for a series of actions to be taken by
the Competent Authority. Action 1 is to “provide the potential victim with support if they want it for a
minimum of 45 days during a recovery and reflection period.” Action 7 directs there to be consideration
“whether a potential victim can be released from detention”. The guidance goes on “if the potential victim
of trafficking…is in immigration detention they will normally need to be released on temporary admission or
temporary release by the Home Office unless in the particular circumstances their detention can be
justified on grounds of public order.” Action 8 directs that there be liaison “with asylum decision makers to
ensure that any negative asylum decision is not made until after the Conclusive Grounds Decision has
been taken.”

35. The guidance also sets out actions to be taken by the Competent Authority if a Conclusive Grounds
decision is positive, in other words if the Home Office decides conclusively that the person concerned is a
victim of trafficking. In those circumstances, Action 5 requires that a decision is made “on any outstanding
asylum claim”. Action 6 directs consideration as to “whether the victim is eligible for discretionary leave”.

36. The guidance also notes that:

“if a potential victim of modern slavery has an existing immigration case which concludes that they cannot
remain in the UK, no removal action will be taken by the Home Office before a Conclusive Grounds
Decision has been made on their human trafficking and slavery case within the NRM process and they will
not be detained save in limited circumstances i.e. where their detention is necessary on grounds of public
policy.”

[37. On 31 July 2015, the Modern Slavery Act 2015 came into force. Section 45 provided a defence to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
victims of trafficking who had been compelled by their traffickers to do an act which constitutes an offence.
That Act did not have retrospective effect. However, trafficking victims may appeal their convictions on the
basis that the courts should have stayed their prosecution as an abuse of process (see R v Joseph (Anti_Slavery International Intervening)_ _[2017] EWCA Crim 36._

**Ground 1 – Unlawful Certification of Deportation Appeal**

38. By this ground, the Claimant alleges that the decision to certify under Regulation 33 of the 2016
Regulations was unlawful.

39. Regulation 23(6)(b) of the 2016 Regulations provides that an EEA national may be removed from the
UK if “the Secretary of State has decided that the person's removal is justified on grounds of public policy...
in accordance with Regulation 27”. Regulations 2 and 36 provide a right of appeal against removal under
Regulation 23(6) to the First Tier Tribunal.

40. Regulation 32(3) provides:

“Where a decision is taken to remove a person under regulation 23(6)(b), the person is to be treated as if
the person were a person to whom section 3(5)(a) of the 1971 Act…applies…”

41. Regulation 33 provides as follows:

“Human rights considerations and interim orders to suspend removal

(1) This regulation applies where the Secretary of State intends to give directions for the removal of a
person (“P”) to whom regulation 32(3) applies, in circumstances where—


-----

(a) P has not appealed against the EEA decision to which regulation 32(3) applies, but would be entitled,
and remains within time, to do so from within the United Kingdom (ignoring any possibility of an appeal out
of time with permission); or

(b) P has so appealed but the appeal has not been finally determined.

(2) The Secretary of State may only give directions for P's removal if the Secretary of State certifies that,
despite the appeals process not having been begun or not having been finally determined, removal of P to
the country or territory to which P is proposed to be removed, pending the outcome of P's appeal, would
not be unlawful under section 6 of the _[Human Rights Act 1998 (public authority not to act contrary to](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
Human Rights Convention).

(3) The grounds upon which the Secretary of State may certify a removal under paragraph (2) include (in
particular) that P would not, before the appeal is finally determined, face a real risk of serious irreversible
harm if removed to the country or territory to which P is proposed to be removed.”

42. Ms Knights argues that the decision to certify under Regulation 33 was taken with insufficient enquiry
into the circumstances of the Claimant's case. She says that the letter of 18 July 2017 was powerful
evidence that the Claimant had been trafficked and faced a risk of re-trafficking. As such, she says, it was
incumbent on the Defendant not to certify unless and until he had satisfied himself on adequate information
that there would be no breach of Section 6 HRA. She said that the decision to make a deportation order
and certify the case was contrary to the Defendant's policy and the opposite of what his international
obligations demanded.

43. Second, she argues that the evidence before the Defendant when he certified the case demonstrated
that deportation pending appeal created a real risk of breach of Articles 3 and 8. As regard Article 3, she
said that the Claimant had raised a case that she was a victim of trafficking and torture and had sustained
abuse over eight years, that her trafficker had re-trafficked her from Lithuania and that she was terrified of
removal. In certifying her claim, Ms Knights argued, the Defendant disregarded the risk of trafficking and
deterioration in her mental health pending an appeal against deportation.

44. As regards Article 8, Ms Knights contends that the public order justification for certification was
extremely weak. She said that it was wrong to rely on her previous criminal convictions because they were
a product of the trafficking abuse she had suffered. She said that the error in the approach of the
Defendant was obvious from his decision letter which asserted that the Claimant had “provided no reasons
as to why you should not be removed before your appeal is heard.” She said that the reasons were
obvious from the Claimant's letter, namely that removing her to Lithuania would expose her to a significant
risk of being re-trafficked.

45. On these bases, Ms Knight sought a declaration that the certification of the Claimant's “protection and
human rights claim” is unlawful. In fact only the latter is in issue; a protection claim is a claim for asylum or
[humanitarian protection (see s82 (Nationality, Immigration and Asylum Act 2002)) and, as is implicitly](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61J0-TWPY-Y1K3-00000-00&context=1519360)
acknowledged by Ms Knights, given the focus of her arguments under this ground, the certification here
related to the Claimant's human rights.

46. However, as noted above, on 12 July the Defendant withdrew the Regulation 33 certification. Ms
Knights has therefore achieved more than she sought. She has obtained not just a declaration that the
certificate was unlawful but its actual withdrawal. In my judgment, the effect of that is to make this ground
academic.

47. Ms Knights resists that conclusion, arguing that the withdrawal of the certificate strengthens her claim.
It may well be that, in a general sense, it does. But that does not make the challenge in these proceedings
any less academic now the decision under challenge has been withdrawn.

48. Ms Knights points to existing vulnerabilities in the Claimant's position. She says the Claimant still
faces the prospect of removal. That may be right. But that too does not alter the fact that the decision
under challenge was the certificate, and the relief sought was a declaration that the certificate was
unlawful. Its withdrawal means there is nothing left to challenge. If there are indeed vulnerabilities in the


-----

claimant's position and these are not addressed in the remainder of this challenge, then, should those
vulnerabilities lead to adverse decisions in the future, the Claimant will have to consider further challenges.

49. This court does not act in the abstract; it does not hold a standing brief to supervise the Secretary of
State in the performance of his statutory duties either in individual cases, or generally. Instead it resolves
particular challenges on particular facts. The challenge under Ground 1 no longer requires resolution.

**Ground 2 – The Asylum Claim**

50. By this ground of challenge, the Claimant attacks the Secretary of State's decision of 26 September
2017, to declare inadmissible her asylum claim.

51. Mr Knights relies on the terms of the VMS guidance and in particular, Actions 8 and 5. Action 8
requires the Competent Authority to “liaise with asylum decision makers to ensure any negative asylum
decision is not made until after the Conclusive Grounds Decision has been taken”. Ground 5 requires that
the “Home Office should not make a negative decision on an asylum claim whilst a person is being
considered under the NRM process”. Ms Knights acknowledges that the Home Office's 'Asylum Policy
Instruction EU/EA Asylum Claims' states at paragraph 5.4 and 5.5:

“5.4 Victims of Modern Slavery/Trafficking

EU nationals must still be referred to the National Referral Mechanism where there are indicators that the
individual has been a victim of **_modern slavery or trafficking. The asylum claim must still be declared_**
inadmissible because victims could seek redress from the authorities in their country of origin, they may
nevertheless qualify for leave to remain in the UK under the Discretionary Leave policy. Caseworkers can
refer to guidance on Modern Slavery and the Discretionary Leave instruction for further information.

5.5 Exceptional circumstances

EU Member States are required to abide by the ECHR and under the Spanish Protocol it is considered that
the level of protection afforded to individuals' fundamental rights and freedoms in EU Member States
means that they are deemed to be safe countries of origin. As such, there is no risk of persecution for
individuals entitled to reside in EU countries that would give rise to a need for international protection. It is
expected that there will be very few claims that are not declared inadmissible and are instead admitted to
the asylum process for full consideration and even fewer, if any, who qualify for international protectionbased leave in the UK.

An asylum claim from an EU national will only be admissible if the claimant sets out exceptional
circumstances which require the claim to be fully considered in accordance with paragraph 326F.”

52. The Spanish Protocol referred to, is part of the Treaty of Amsterdam. The Protocol provides:

“Given the level of protection of fundamental rights and freedoms by the Member States of the European
Union, Member States shall be regarded as constituting safe countries of origin in respect of each other for
all legal and practical purposes in relation to asylum matters. Accordingly, any application for asylum made
by a national of a Member State may be taken into consideration or declared admissible for processing by
another Member State only in the following cases:

if the Member State of which the applicant is a national proceeds, availing itself of the provisions of Article
15 of the European Convention for the Protection of Human Rights and Fundamental Freedoms, to take
measures derogating from its obligations under that Convention;

if the procedure referred to in Article I-59(1) or (2) of the Constitution has been initiated and until the
Council, or where appropriate, the European Council, adopts a European decision in respect thereof with
regard to the Member State of which the applicant is a national;

if the Council has adopted a European decision in accordance with Article I-59(1) of the Constitution in
respect of the Member State of which the applicant is a national or if the European Council has adopted a
European decision in accordance with Article I-59(2) of the Constitution in respect of the Member State of
which the applicant is a national;


-----

if a Member State should so decide unilaterally in respect of the application of a national of another
Member State; in that case, the Council shall be immediately informed; the application shall be dealt with
on the basis of presumption that it is manifestly unfounded without affecting in any way, whatever the case
may be, the decision-making power of the Member State.”

53. Ms Knights argues that the Spanish Protocol preserves a broad discretion for member states to
decline to apply the presumption that claims from EEA nationals are not admissible, that Section 2 of the
Asylum, Immigration and Appeals Act 1993 requires that nothing in the immigration rules may lay down
any practice which would be contrary to the Refugee Convention, and that where a trafficking risk is raised
in an asylum claim, it is a principle of law that the claim cannot be adequately considered without
investigation of the pattern of trafficking in the country of origin and the individuals particular
circumstances.

54. She says the declaration of inadmissibility here, was made after referral to the NRM and so conflicted
with the VMS guidance. She says that the inadmissibility decision was a “blanket decision taken without
reference to the Claimant's individual circumstances.” She says that the inadmissibility decision was
contrary to paragraph 326F of the Immigration Rules and that the Claimant had raised exceptional
circumstances.

55. Ms Knights further argues that her case on Ground 2 is strengthened by the Secretary of State's
decision to withdraw the Reg 33 certificate.

56. In my judgment, these arguments are misconceived. The Spanish Protocol is clear. In the light of the
level of protection available, member states are to be regarded as safe. Asylum claims by members of
national states are only to be declared admissible in the very unusual circumstances identified in the
Protocol. The final paragraph of that Protocol needs to be read in the light of the nature of the other
categories. The fact that the Council is to be informed if a member state ever decides unilaterally to
consider an application of a national of another member state, and that even in those circumstances, that
application has to be dealt with on the basis of a presumption that it is manifestly unfounded, underlines
the truly exceptional nature of the circumstance contemplated by the Protocol.

57. In my judgment, the asylum claim in the present case does not come close to falling into such a
category of exceptionality.

58. It is right that, at first blush, there appears to be a conflict between the VMS guidance and Actions 8
and 5 on the one hand, and the Home Office asylum policy instruction. But in my view, it is clear that the
VMS guidance applies to trafficking cases from around the world, whereas the policy instruction is specific
to EA cases. In my judgment, the VMS guidance applies only to properly admissible asylum claims and
not to asylum claims declared inadmissible.

59. In any event, the Spanish Protocol reflects a principle of English domestic law, that a claim for asylum
can only succeed where the claimant shows a real risk that the country of origin would be unable or
unwilling to discharge its duty to establish an operating system for the protection against persecution of its
own nationals (see Horvath v SSHD [2001] 1 AC 489 at 495). As Mr Brown submits, State parties are not
required to guarantee the safety of their citizens. Here, the home country is a member of the EU and a
party to the Anti-Trafficking Convention and Directive. Lithuania is also a member of the Council of Europe
and a signatory to the European Convention on Human Rights. There is no evidence before me to suggest
that Lithuania does not provide an adequate system of criminal law enforcement in respect of trafficking or
does not operate that system properly.

60. For all those reasons, the Secretary of State was, in my judgment, entitled to declare ZV's asylum
claim inadmissible.

61. The withdrawal of the certificate does not change that position. As Mr Brown further submits, since
ZV's claim was not even admissible, it was not an asylum claim which remained outstanding at the time her
case was referred to the NRM. There was no decision to await the outcome of the NRM process.


-----

62. Furthermore, there was nothing, in my judgment, inconsistent with Section 2 of the 1993 Act in the
Secretary of State's compliance with the Spanish Protocol. Paragraph 326F of the Immigration Rules does
not offend the Geneva Convention by recognising the safety of other member states.

**Ground 3 – Detention**

63. By this ground, the Claimant challenges the lawfulness of her detention from 24 June 2017, the day
after she was taken into immigration detention, to 30 November 2017 when she was finally released.

_The Legal Principles and Policy_

64. The legal foundation for this claim is common ground.

65. Paragraph 2(3) of Schedule 3 to the Immigration Act 1971, empowers the Secretary of State to detain
a person against whom there is a deportation order in force, pending her removal from the UK. That power
to detain is subject to limits imposed by the common law. Those limits were first described in R v Governor
_of Durham Prison ex parte Hardial Singh [1984] 1 WLR 704, and subsequently considered by Dyson LJ (as_
he then was), in R(I) v SSHD _[2002] EWCA Civ 888 at paragraph 46;_

“i) The Secretary of State must intend to deport the person and can only use the power to detain for that
purpose;

ii) The deportee may only be detained for a period that is reasonable in all the circumstances;

iii) If, before the expiry of the reasonable period, it becomes apparent that the Secretary of State will not be
able to effect deportation within that reasonable period, he should not seek to exercise the power of
detention;

iv) The Secretary of State should act with the reasonable diligence and expedition to effect removal.”

66. That formulation of the principles was approved in R (Lumba) v SSHD _[2011] UKSC 12._

67. Central to this claim, in addition, are the Detention Centre Rules 2001 and the 'Adults at Risk' (or
“AAR”) policy.

68. The Detention Centre Rules impose further obligations on the Secretary of State. By Rule 34:

“(1) Every detained person shall be given a physical and mental examination by the medical practitioner (or
another registered medical practitioner in accordance with rules 33(7) or (10)) within 24 hours of his
admission to the detention centre.

(2) Nothing in paragraph (1) shall allow an examination to be given in any case where the detained person
does not consent to it.

(3) If a detained person does not consent to an examination under paragraph (1), he shall be entitled to the
examination at any subsequent time upon request”.

69. Rule 35 provides:

“(1) The medical practitioner shall report to the manager on the case of any detained person whose health
is likely to be injuriously affected by continued detention or any conditions of detention.

(2) The medical practitioner shall report to the manager on the case of any detained person he suspects of
having suicidal intentions, and the detained person shall be placed under special observation for so long as
those suspicions remain, and a record of his treatment and condition shall be kept throughout that time in a
manner to be determined by the Secretary of State.

(3) The medical practitioner shall report to the manager on the case of any detained person who he is
concerned may have been the victim of torture.

(4) The manager shall send a copy of any report under paragraphs (1), (2) or (3) to the Secretary of State
without delay.


-----

(5) The medical practitioner shall pay special attention to any detained person whose mental condition
appears to require it, and make any special arrangements (including counselling arrangements) which
appear necessary for his supervision or care.”

70. From September 2016, a Home Office policy, the AAR applied “in all cases in which considerations
been given” to detaining an adult in order to remove her. It is common ground that the Secretary of State
is obliged to follow that policy unless there are good reasons to depart from it. The AAR policy provides
that any decision affecting any potential victims of trafficking should be made on the basis of the VMS
guidance. That provides, that, if the potential victim is in immigration detention she will normally need to be
released on temporary admission or temporary release unless their detention can be justified on grounds
of public order. As the Claimant submits, that principle was held in _R (XYL) v SSHD_ _[[2017] EWHC 73](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MS6-RB31-F0JY-C0WJ-00000-00&context=1519360)_
_[(Admin) to be a “statement of policy which bears on the legality of detention in the sense explained in R](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5MS6-RB31-F0JY-C0WJ-00000-00&context=1519360)_
_(Lumba)…”_

71. The policy provides that once an individual has been identified as at risk “consideration should be
given to the level of evidence” which supports that assessment. Level 1 applies to a self-declaration of
being an adult at risk. Level 2 refers to professional evidence or official documentary evidence which
indicates that the individual is (or may be) an adult at risk. Level 3 refers to professional evidence stating
that the individual is at risk. Where a person in detention is subject to a Rule 35 report with concerns about
torture that will normally amount to Level 2 evidence. Such a person should only be considered for
detention if one of the following applies:

“(i) the date of removal is fixed or can be fixed quickly, and is within a reasonable timescale and the
individual has failed to comply with reasonable voluntary return opportunities, or if the individual is being
detained at the border pending removal having been refused entry to the UK;

(ii) they present a level of public protection concerns that would justify detention – for example, if they meet
[the criteria of foreign criminal as defined in the Immigration Act 2014 or there is a relevant national security](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5C96-HDY1-DYCN-C2PH-00000-00&context=1519360)
or other public protection concern;

(iii) there are negative indicators of non-compliance which suggest that the individual is highly likely not to
be removable unless detained.”

72. A person in respect of whom there is Level 3 evidence should only be considered for detention if :

“(i) removal has been set for a date in the immediate future, there are no barriers to removal and escorts
and other appropriate arrangements are in place to ensure the safe management of the individual's return
or

(ii) the individual presents a significant public protection concern.”

It is stated to be very unlikely that compliance issues on their own would warrant detention of individual
falling into this category.

_Submissions and Discussion_

73. The Claimant submits that her immigration detention was unlawful for five months and 6 days from
soon after 24 June 2017, the day after she was taken into immigration detention whilst at HMP Bronzefield,
to 30 November 2017 when she was released from Yarl's Wood IRC.

74. The Defendant concedes that her detention was “technically unlawful” between 28 June 2017 when
the NRM referral was underway and 16 August 2017 because there was a failure during that period to
carry out a Rule 34 examination. But, save for that period, he maintains that the detention of the Claimant
throughout was lawful.

75. It is convenient to consider the justification for the Claimant's detention during the six periods identified
by Ms Knights.

76. First, she says that once the Claimant entered immigration detention whilst at HMP Bronzefield on 23
June, the Defendant was obliged to conduct a medical assessment within 24 hours. Had they done so,


-----

that should have led to a report under Rule 21 of the Prison Rules 1999. That in turn should have led to
evidence of torture and trafficking being identified which then should have led to her release in accordance
with the AAR policy and the VMS guidance.

77. I reject that argument. The Claimant status at HMP Bronzefield changed on 23 June 2017 when she
entered immigration detention. But her medical care continued and continued to be appropriate. She was
seen by a GP on 17 June 2017 and no concerns were raised. She was seen by a nurse on 30 June 2017
and again no concerns were raised to the effect that she had been trafficked. In fact, none of the medical
records from HMP Bronzefield suggest concern about trafficking or sexual abuse or violence. In those
circumstances, in my judgment, it cannot be said that if a medical assessment had been conducted as
required by PSO3050 it would have led to a report under Rule 21 of the Prison Rules 1999 which would
have led to evidence of torture and trafficking being identified such that the Claimant would have been
released in accordance with the AAR policy.

78. Second, on 18 July 2017, the Claimant provided the detailed handwritten statement to which I have
referred. Ms Knight contends that, if her claim in respect of the period in detention since 23 June 2017
fails, then her detention became unlawful from soon after 18 July. She alleges that, in that letter, the
Claimant claimed asylum and disclosed that she was a victim of trafficking. Ms Knights contends that from
that date the Defendant ought, in accordance with the VMS policy, to have referred the Claimant to the
NRM. She says that given the existence of an asylum claim it should then have been apparent that the
deportation could not be effective in a reasonable period. Accordingly, applying _Hardial Singh her_
detention became unlawful. Ms Knights contends that the 18 July 2017 Letter disclosed evidence of
trafficking which should have led the Secretary of State to recognise the weakness of the public order
justification for the Claimant's detention. She says that disclosure cast doubt upon the safety of the
Claimant's conviction and the entire basis for the deportation. She submits that factor was not recognised
in any of the detention reviews carried out by the Defendant.

79. It is right to observe that in the detention review of 21 July 2017, three days after the letter, the
Defendant's staff record that “the Claimant had not at this stage lodged any representations against the
deportation”. In the light of the letter, it is said that that was an error and that that error led to the
conclusion that “no evidence was identified to suggest detention would have a deleterious effect on the
Claimant pursuant to the Adults at Risk policy”.

80. In response, Mr Brown submits that the 18 July letter did not give rise to a duty to release from
detention. He says that ZV had been in custody since 17 June 2017 and only advanced an argument that
she had been trafficked in response to notification of the intention to deport. He said it was not apparent
from the letter that ZV was making an asylum claim. He says that the existence of the letter did not mean
that ZV's deportation could not take place within a reasonable period. He says there is no basis on which
to assert that detention becomes unlawful as soon as a person becomes a subject of an NRM referral and
that therefore logically it cannot become unlawful before such a referral is made.

81. In my judgment, properly understood, the letter of 18 July 2017 did not constitute a valid claim for
asylum. But it did give an account of trafficking. However, receipt of such an account does not, of itself,
make continued detention unlawful, if that detention is lawful applying Hardial Singh.

82. In R (XYL) v SSHD [2017] EWHC 773, Jonathan Swift QC, sitting as he then was as a deputy judge of
the High Court, held that there is no requirement to release a person from immigration detention as soon
as they became subject to the National Referral Mechanism procedure. I respectfully agree. As he
observed at paragraph 19 “Potential victims of trafficking are only identified for distinct treatment, so far as
concerns detention if they are the subject of a positive reasonable grounds decision”. Mr Swift went on, at

[25]

“I can see nothing in the various guidance documents to the effect that immigration detention must or ought
usually to, come to an end if the person concerned is the subject of an NRM referral. Moreover, there is no
inherent inconsistency between lawful immigration detention – lawful in accordance with the well-known
Hardial Singh principles – and a situation in which a person who is so detained is also the subject of an
NRM referral Put another way the fact that there has been an NRM referral does not mean that detention


-----

ceases to be for purposes permitted under 1971 Act powers (regardless of what the position might be if at
some point thereafter there is a conclusive grounds decision in respect of the person detained). Nor does
the fact of a referral mean that it is inevitable that the detention will be for a period beyond that reasonably
necessary. This point is underlined by the requirement that a reasonable grounds decision may be
expected in a short period of time – i.e. "as soon as possible" in situations where the person is in
immigration detention.”

83. In my judgment, it cannot be said on the facts of the present case, that removal in a reasonable period
was not possible on 18 July or immediately afterwards. Accordingly, the second Hardial Singh principle did
not mean that release was required then. Furthermore, given that, as explained above, the asylum claim
was properly declared inadmissible when the issue was addressed in September 2017, it cannot be said
that its existence in July meant that it should have been apparent that the Secretary of State would not be
able to effect deportation within a reasonable period. Accordingly, the third Hardial Singh principle did not
operate to make detention unlawful in July. Accordingly, I reject the claim that detention became unlawful
from that time.

84. Third, Ms Knights says that, if she is wrong about the two previous periods, then by no later than 29
July the Claimant's detention had become unlawful. She points out that the Claimant had been transferred
to Yarl's Wood IRC on 28 July 2017 and the Defendant was required to conduct a Rule 34 compliant
examination within 24 hours of that transfer.

85. In response, Mr Brown contends that by 28 July 2017 an NRM referral was in train and a Rule 34
assessment would not have made any difference. The Secretary of State accepts that there was a failure
to carry out a Rule 34 examination and that renders ZV's detention technically unlawful until 16 August
2017 when ZV had opportunity for Rule 35 assessment. But it is denied that a Rule 35 assessment would
have led to a Rule 35 report which would have led to ZV's earlier release

86. In this regard, I reject the Defendant's argument. The Secretary of State accepts there was a failure to
carry out a Rule 34 examination in the period from 29 July to 13 August 2017 and that that failure rendered
the detention unlawful. In my judgment, the suggestion that damages for that period need not be more
than simply nominal is unfounded. One of the reasons why no Reasonable Grounds Decision was taken
during that period is said to be the 'absence of the Competent Authority on annual leave'. That must be a
reference to the official within the competent Authority with responsibility for the Claimant's case. In my
judgment, that cannot possibly be a good excuse. The obligation on the Defendant is to ensure the
Competent Authority conducts its duties consistently and properly. Failing to have in place arrangements
which mean the Competent Authority continues to perform its functions whilst individual officers are away,
cannot justify such a failure.

87. Those failures by the Secretary of State, to ensure a Rule 34 examination took place and to maintain
adequate staffing at the Competent Authority, rendered the Claimant's detention unlawful during that period
and, in my judgment, must have delayed her eventual release. If that time had not been wasted the date of
her eventual release would have been brought forward by a comparable period. The proper approach to
awarding damages for that unlawful detention in my judgment is to add 15 to the total number of days of
unlawful detention I conclude took place at the end of the present exercise of considering Ms Knights' six
periods.

88. Fourth, as regards the period after 14 August 2017, Ms Knights argues that five days after her referral
to the NRM, the Claimant would have received a positive reasonable grounds decision had there not been
that delay.

89. The “5 working day” requirement is found in the VMS guidance. That is plainly a target at which those
responsible for managing trafficking allegations should aim. But it is not rule of law non-compliance with
which will necessarily entitle a claimant to relief. The document is properly described as “guidance” and is
couched in terms of what 'should' be done rather than what 'must' be done. (See also in this context the
judgment of Karon Monaghan QC, sitting as a deputy judge of this court, in _R (on the application of CP_
_(Vietnam)) v Secretary of State for the Home Department_ _[2018] EWHC 2122 (admin) at [90])._


-----

90. Mr Brown argues that ZV's detention did not become unlawful as a result of the time taken to secure a
reasonable grounds decision. He says that the risk of absconding and re-offending constituted substantial
public order grounds which justified continued detention, notwithstanding the delay in the reasonable
grounds decision and after that decision had been received. I accept that argument. The passage of five
days did not make continued detention unlawful.

91. Fifth, Ms Knight argues that, if her preceding arguments are wrong, that the Claimant's detention was
unlawful soon after 19 September 2017 because she says the Rule 35 report, obtained that day, was
inadequate and the response to it was inadequate. She says that the report failed adequately to assess
the Claimant's mental state and whether detention was likely to affect her adversely. She says the
response thereafter was flawed, in that, although it accepted that the Claimant was a victim of torture it
none the less asserted there were no major concerns about her health.

92. Mr Brown responds that the Secretary of State was entitled to rely on the independent opinion of Dr
Mahmood, and that doctor's mental health assessment of the Claimant does not provide a basis for
concluding that continued detention was injurious to the Claimant. The doctor said that there were no major
concerns about the Claimant's health. In my judgment Mr Brown is right. The attack advanced by Ms
Knights on the adequacy of the doctor's examination and conclusions does not undermine the Secretary of
State's entitlement to rely on it.

93. **Finally, Ms Knight contends that detention was unlawful after the positive Reasonable Grounds**
Decision of 4 October 2017. She observes the Defendant then accepted a need for relief in accordance
with the VMS guidance.

94. Mr Brown points out that there was no NRM reasonable grounds decision until 4 October and
thereafter the Secretary of State was entitled to seek appropriate accommodation for ZV. It was not until
30 November 2017 that ZV was released.

95. In assessing the lawfulness of detention after 4 October, it is necessary to have regard to all the
preceding history. I have concluded that for all but a period of 15 days, detention was justified. But,
nonetheless, there had been a prolonged period of administrative detention of an individual in respect of
whom, on 4 October 2017, there were found to be reasonable grounds for believing she was a victim of
trafficking. Action 7 in the VMS guidance directs early release at this point “unless in the particular
circumstances their detention can be justified on grounds of public order.” On 12 October 2017, the
detention review supported release. The following day the Claimant's release referral was approved. Yet
she was still not released.

96. In the light of the history of this case, there was an obligation on the Secretary of State, in my
judgment, urgently to take the steps necessary to effect her release. I can detect no such urgency. On the
contrary, the impression with which I am left is of a marked reluctance to complete the necessary process.
I can see no public order justification for further detention. Making the arrangements necessary to effect
release should have begun as soon as the reasonable grounds decision was taken. As Ms Knights fairly
points out, it is revealing that once a court ordered release, the process was completed promptly.

97. In my view, given the history, the Claimant should have been released by no later than 14 October
2017.

98. It follows that the Defendant is liable to the Claimant for 45 days unlawful detention (being 15 days
from 29 July and 30 days from 14 October 2017).

**Ground 4 – Failure to discharge the obligation to provide assistance and support**

99. By Ground 4, the Claimant attacks what she asserts was the Secretary of State's failure to meet his
obligations under Articles 11(2) and (5) of the 2011 Trafficking Directive and his published policy adopting
the Trafficking Convention. She says he should have released her because that's what her medical and
welfare needs required. She says that, whilst she was in detention, he did not provide her with the
psychological support and mental health treatment she needed, and that he failed adequately to assess
her medical and welfare needs until her release from detention on 30 November 2017.


-----

_The Directive and the Trafficking Convention_

100. Article 11 of the Trafficking Directive is entitled “Assistance and support for victims of trafficking in
human beings”. It provides as is material:

“1. Member States shall take the necessary measures to ensure that assistance and support are provided
to victims before, during and for an appropriate period of time after the conclusion of criminal proceedings
in order to enable them to exercise the rights set out in Framework Decision 2001/220/JHA, and in this
Directive.

2. Member States shall take the necessary measures to ensure that a person is provided with assistance
and support as soon as the competent authorities have a reasonable-grounds indication for believing that
the person might have been subjected to any of the offences referred to in Articles 2 and 3…

5. The assistance and support measures referred to in paragraphs 1 and 2 shall be provided on a
consensual and informed basis, and shall include at least standards of living capable of ensuring victims'
subsistence through measures such as the provision of appropriate and safe accommodation and material
assistance, as well as necessary medical treatment including psychological assistance, counselling and
information, and translation and interpretation services where appropriate…” (emphasis added)

101. Article 12 of the Trafficking Convention provides for assistance to victims;

“1. Each Party shall adopt such legislative or other measures as may be necessary to assist victims in their
physical, psychological and social recovery. Such assistance shall include at least:

a standard of living capable of ensuring their subsistence, through such measures as: appropriate and
secure accommodation, psychological and material assistance;

b access to emergency medical treatment;

c translation and interpretation services, when appropriate;

d counselling and information, in particular as regards their legal rights and the services available to them,
in a language that they can understand;

e assistance to enable their rights and interests to be presented and considered at appropriate stages of
criminal proceedings against offenders;

f access to education for children.

2 Each Party shall take due account of the victim's safety and protection needs.

3 In addition, each Party shall provide necessary medical or other assistance to victims lawfully resident
within its territory who do not have adequate resources and need such help.

…

7 For the implementation of the provisions set out in this article, each Party shall ensure that services are
provided on a consensual and informed basis, taking due account of the special needs of persons in a
vulnerable position and the rights of children in terms of accommodation, education and appropriate health
care” (emphasis added).

102. Article 13 provides for a recovery and reflection period

“1 Each Party shall provide in its internal law a recovery and reflection period of at least 30 days, when
there are reasonable grounds to believe that the person concerned is a victim. Such a period shall be
sufficient for the person concerned to recover and escape the influence of traffickers and/or to take an
informed decision on cooperating with the competent authorities. During this period it shall not be possible
to enforce any expulsion order against him or her. This provision is without prejudice to the activities
carried out by the competent authorities in all phases of the relevant national proceedings, and in particular
when investigating and prosecuting the offences concerned. During this period, the Parties shall authorise
the persons concerned to stay in their territory.


-----

2 During this period, the persons referred to in paragraph 1 of this Article shall be entitled to the measures
contained in Article 12, paragraphs 1 and 2.

3 The Parties are not bound to observe this period if grounds of public order prevent it or if it is found that
victim status is being claimed improperly.”

103. The provisions of the Trafficking Directive, the Trafficking Convention and the Home Office policy,
which aims to implement them have been considered in three recent decisions by the courts to each of
which I was referred by the parties.

104. In R (Galdikas) v Secretary of State for the Home Department [2016] 1 WLR 4031Sir Stephen Silber,
sitting as a deputy judge of the High Court, held that the Home Office guidance stated that the SSHD
would act in accordance with Article 12 of ECAT. The policy of SSHD was that she would apply the
approach in the Trafficking Convention to deal with applications for Discretionary Leave to Remain from
those who had been recognised as victims of trafficking. If the competent authorities have reasonable
grounds to believe a person has been a victim of trafficking, they must take various steps, including to
ensure that the person receives the assistance provided for in Article 12(1) and (2) of ECAT and this must
continue through the period of recovery and reflection. This is policy, he held, which the SSHD must follow
unless there is good reason not to do so.

105. He concluded, at [116] that “(1) Article 11 (2) of Directive 2011/36 provides a free-standing duty of
support and imposes an obligation on the UK to provide a trafficked person with assistance and support as
defined in Article 11(5) of the Directive, in the post 45-day reflection and recovery period”.

106. In _R (TDT) v Secretary of State for the Home Department [2018] EWCA Civ 1395,_ the Court of
Appeal was concerned with the case of a Vietnamese national who had been discovered in a lorry with 15
others. His solicitors challenged a finding that the claimant was over 18 and sought his temporary
admission into the UK. Subsequently, they made a formal reference to the UK Human Trafficking Centre,
stating that there was reason to believe the claimant was a victim of trafficking. A pre-action protocol letter
was issued, seeking the claimant's release, but not before stringent safeguarding measures were in place.
A week later, judicial review proceedings were issued. The claimant was released on the same day,
despite email correspondence, to the Secretary of State and the Government Legal Department, stating
that he should not be released without notice, to enable an emergency injunction to be sought. The
claimant disappeared and had not been traced since. The claimant alleged a breach of ECHR art 4 and
ECAT by failing to take reasonable steps to protect the claimant in circumstances where the Secretary of
State knew, or ought to have known, that there was a credible suspicion that he was a trafficking victim.

107. The Court held that the Secretary of State had breached ECHR art.4 and ECAT by releasing the
claimant from administrative detention without having put in place adequate measures to protect him from
being re-trafficked. There had been sufficient evidence to give rise to a credible suspicion that he was a
trafficking victim and there was a real and imminent risk of re-trafficking if released.

108. In _R (EM) v Secretary of State for the Home Department [2018] EWCA Civ 1070 at [31], Peter_
Jackson LJ summarised the duty to provide support as follows:

“….[T]he core obligation defining the support duty arises from Arts 11(2) and (5) of the Directive,
which….mandate that assistance and support must be provided to PVoTs (potential victims of torture) on a
consensual and informed basis, and shall include at least standards of living capable of ensuring victims'
subsistence through measures such as the provision of appropriate and safe accommodation and material
assistance, as well as necessary medical treatment including psychological assistance, counselling and
information, and translation and interpretation services where appropriate”.

_The Competing Arguments_

109. Ms Knights contends that the trigger for the provision of support and treatment should have been the
Reasonable Grounds Decision of 4 October 2017. What was then required was “an individualised
assessment” of the Claimant's needs as a potential victim of torture and then treatment and support to
address that need.  But that, she argues, did not happen. She refers to the report of Dr Obuaya who, she


-----

says, recommended one to one counselling or cognitive behavioural treatment and advised that the
Claimant needed to be released.

110. Relying on TDT, Ms Knights argues that Article 4 ECHR imposes a duty to protect victims of torture
and to provide support, and that breach of Article 4 can justify an award of damages. Relying on EM she
says that the medical treatment provided must respond to the victims “objectively assessed” need.

111. In her skeleton argument, Ms Knights relied extensively in support of those arguments on the report
of a consultant clinical psychologist. However, no permission from the court had been obtained to rely on
that report and the Defendant objected to its admission. Furthermore, I read the report de bene esse and
there seemed to me a number of grounds of possible objection to its deployment in these proceedings. I
itemised those potential difficulties to Ms Knights and she reflected on the issue overnight. On the morning
of day two of the hearing, she indicated she would not be pursuing her application to be permitted to rely
on the report.

112. Instead, she fell back on an earlier report, dated 23 October 2017, obtained by those instructing her,
from a psychiatrist Dr Chiedu Obuaya. It was Dr Obuaya's opinion that the Claimant suffered from “Mental
and Behavioural Disorders due toe Multiple Psychoactive Substance Use - Dependence Syndrome” and
“Mixed Anxiety and Depressive Disorder”. He said there had been a number of adverse life events that
precipitated that latter episode. She said the Claimant was not suffering from PTSD but her symptoms
were “in keeping with the traumatic experiences she has described”.

113. As to treatment, Dr Obuaya noted that the Claimant was already in receipt of antidepressants in line
with NICE recommendations. He said that “once she has had a successful detoxification” the Claimant's
care plan should focus on psychosocial interventions to support her to remain abstinent of opioids. “In the
longer term”, after she was released from detention, she would need community based support. He
recommended a course of psychotherapy such as cognitive behavioural therapy and interpersonal therapy.

114. He was not able to say whether her mental state had deteriorated during her detention. But He
expressed concern that “detention could exacerbate her mental health problems”. He said it was not likely
that her health needs can be adequately be met in detention; for psychological therapy to be effective she
should be in a psychologically safe environment which she does not consider detention to be.

115. Relying on EM, Mr Brown argued that the test under the Directive was whether the mechanisms in
place offered at least a subsistence standard of living through the provision of appropriate and safe
accommodation, material assistance, necessary medical treatment including psychological assistance,
counselling and information, and translation and interpretation services. He said the treatment offered did
not need to be focused on needs arising from trafficking and that the court should look at all the support
provided to date.

116. He says there is nothing in law that requires the Secretary of State to spell out in guidance how she
complies with the Art. 11(2) duty in respect of those in immigration detention. The 2011 Directive only
imposes an obligation as to the result to be achieved. He argued that the requirement to provide
assistance and support was met in the Claimant's case.

117. Mr Brown contends that I should have regard to all the support and treatment the Claimant received
throughout the relevant period, both before and after the reasonable grounds decision. He says the
treatment the Claimant received was entirely appropriate. He lists the following elements of that support
and treatment:

118. He says she was seen by a nurse on 28 July 2017, her need for methadone was addressed on 28
July; she was offered but did not attend a GP appointment on 31 July 2017; she attended a mental health
assessment on 2 August 2017 and a triage later that day; she was invited to attend a wellbeing services
Kaleidoscope following a referral from healthcare; she saw a doctor on 8 August 2017, she was offered but
did not attend appointments on 14, 16 and 17 August 2018; she was offered but did not attend an
appointment with the substance misuse team on 21 August 2017; she saw a GP on 24 August 2017; she
was offered but did not attend an appointment on 30 August 2017; she had an appointment with the GP on
4 September 2017 ; on 5 September 2017 she was booked for CBT; on 6 September 2017 she had a


-----

psychological wellbeing assessment; on 7 September 2017, she had a mental health assessment; she saw
a doctor on 21 September 2017; on 28 September 2017, she had a psychological wellbeing assessment;
on 29 September 2017, she had a mental health review; she saw a GP on 5 October 2017 and 12 October
201; a primary mental health care plan was created on 16 October 2017; a psychological wellbeing
assessment was carried out on 18 October 2017; she saw a GP on 19 October 2017 and 26 October 2017;
and after her release, she had access to, and attended, counselling sessions. He referred me to
documents supporting each of these events.

_Discussion_

119. In my judgment, in the light of the authorities referred to above, the Defendant's arguments on this
ground are to be preferred. I say that for fourreasons:

120. **First, it is necessary to identify the scope of the relevant obligations on the Defendant and, in**
particular, the duties owed at the particular stage in the process of recognising and supporting victims of
trafficking with which we are concerned. _TDT_ focused on the duty to protect, when the victim is first
encountered and emphasised the obligation on the state to take care before releasing a potential victim of
trafficking from detention if there is a risk of re-trafficking. Here the threat to the Claimant ceased when her
former partner was deported.  Accordingly, TDT does not greatly assist the analysis in the present case.

121. EM focused on the duty owed to recognised victims of trafficking and, in particular, to such victims
after the 45 days of reflection for which art 13 of ECAT makes provision. But the Claimant here was not, at
the relevant time, a recognised victim. She was properly to be regarded as a “potential” victim of
trafficking. That follows from the fact that the trigger event was the Reasonable Grounds Decision; it was
not until July 2018 that the Conclusive Grounds decision was reached and the Claimant's complaint falls to
be tested against her status at the time of the decision under challenge.

122. It follows that the operative provisions were Article 11 of the Directive and Article 12 of ECAT by
which the Claimant was entitled to modest levels of assistance; to measures, for example, capable of
ensuring her subsistence and to emergency medical support, rather than to the more sophisticated support
treatment for which Ms Knights contends.

123. As Jackson LJ held in EM (at [65]):

“65. The general duty on the State under Arts. 11(2) and (5) of the Directive is to provide assistance and
support to a PVoT by mechanisms that at least offer a subsistence standard of living through the provision
of appropriate and safe accommodation, material assistance, necessary medical treatment including
psychological assistance, counselling and information, and translation and interpretation services
(emphasis added).

124. Second, Mr Brown is right to point out that in assessing the adequacy of the treatment and support it
is necessary to consider the assistance and support provided throughout the relevant period. Returning to
Jackson LJ's judgment in EM:

“68 I also consider that, when considering whether the support duty has been discharged, it is appropriate
to look at the level of assistance and support that has been provided to the PVoT at all stages in the
process, and not just at support provided during the 45-day reflection period.”

125. Third, the support and treatment the Claimant in fact received in detention, as itemised by Mr Brown,
met the minimum requirements imposed by the Directive and ECAT. That support and treatment
responded to the need that had been recognised and assessed by those who had the Claimant in their
care in detention. In my judgment, the support and treatment provided in detention provided more than a
“subsistence standard of living” in each of those respects.

126. Jackson LJ held in EM:

“66 As to that element of the duty that requires the provision of necessary medical treatment including
psychological assistance, counselling and information, the treatment provided must respond to the welfare
needs of the individual, objectively assessed in each case. The obligations arising under the Directive and


-----

Guidance, read alongside the Convention, do not extend to a requirement that the assessment or
treatment must be provided by specialists in trafficking, or that it be targeted towards one aspect of an
individual's needs (the consequences of trafficking) as opposed to his or her overall psychological needs.
The support duty calls for the provision of support, not the accomplishment of physical, psychological or
social recovery. ….

67 Nor do the Claimant's submissions gain strength from a comparison between services that are provided
in the community and those provided in IRCs. The position of a PVoT who is detained is different from the
position of one who is not, and it is lawful for the State to decide to provide support in different ways. A
PVoT living in the community may well not have access to any of the four forms of support mentioned at
paragraph 65 above, while all four will automatically be available to a detained PVoT. The way in which
psychological treatment is provided may take account of the inherent uncertainty about the length of
detention, and the ready availability of on-site medical care for a person who is in any case under close
observation. The evidence filed on behalf of the Claimant is in my view more effective in demonstrating the
way in which the support duty is satisfactorily discharged in the community than in establishing any breach
of legal duty towards detained PVoTs. The fact that different, or better, provision might be made for those
not in detention does not of itself equate to a breach of duty.”

127. The Trafficking Directive and the Guidance do not prescribe the manner in which assistance and
support are to be provided in different circumstances. The Trafficking Convention applies to all 47 states of
the Council of Europe and the Directive to the 28 states of the European Union. Individual states must
design systems to achieve the required result. The obligation to provide support does not translate into an
obligation to secure psychological recovery and the obligation does not have to be met in identical ways
inside and outside detention.

128. Fourth, and in any event, the expert on whom the Claimant relies, Dr Obuaya, recognised that it was
necessary first to treat the Claimant's drug dependency before psychosocial treatment could be introduced
effectively. That treatment continued throughout her detention.

129. In those circumstances this ground must fail.

**Ground 5**

130. By Ground 5, the Claimant seeks to make systemic criticism of the Defendant's arrangements for
managing trafficking allegations. She focuses, first, on delays in referrals to the NRM and in the making of
reasonable grounds decisions. Second, she criticises the prioritisation of removal over identifying and
protecting victims of trafficking.

131. This ground attracted very little attention in the course of Ms Knight's oral submissions. She pointed
to a report by Detention Action in 2007 entitled “Trafficked into Detention: How victims of trafficking are
_missed in detention” and a report of the House of Commons Public Accounts Committee called “Reducing_
**_Modern Slavery”. But although I was shown these reports in passing, I had no detailed submissions on_**
their methodology, sources or conclusions. Commenting on these and similar reports in H v SSHD, Nicol J
said:

“The role of the Court is to adjudicate on specific legal disputes. Bodies such as the Public Accounts
Committee and the Anti-Slavery Commissioner have a wider remit. They can survey the performance of
the Home Office more generally in discharging its anti-trafficking functions and make recommendations.
That is not the function of the Court.”

132. I respectfully agree. The reports I was shown raise important issues, but their focus is not that
required by this court. Furthermore, reaching a conclusion on their strength, validity and relevance
requires much greater analysis than they received before me.

133. I have already addressed the significance of the delays in the Claimant's case, in dealing with Ground
3. The evidence I have seen and the argument I have heard in support of Ground 5 is simply insufficient to
enable me to form any overall conclusion on whether there is a wider pattern of delay which demonstrate a
systematic problem.


-----

134. Similarly, I do not have the material to address the question whether there has been an improper
prioritization of one objective over another. That question will necessitate, for example, consideration of
whether the Competent Authority is genuinely independent of the Home Office; I have not been shown any
evidence going to that topic.

135. I understand that there are other proceeding afoot where these and related matters are raised headon, with proper evidence and analysis in support and in response. In my view resolution of those matters,
if they are suitable for resolution by a court at all, are better left to those proceedings.

**Conclusions**

136. In those circumstances, Grounds 1, 2, 4 and 5 must fail. Ground 3 succeeds to the extent that to
hold that the Claimant was unlawfully detained for 45 days. I will hear counsel on the terms of the
appropriate order.

**End of Document**


-----

