# R v Y [2019] EWCA Crim 278

CA, CRIMINAL DIVISION

201800083

Knowles LJ, Davis LJ, Yip J

24 January 2019

24/01/2019

Thursday 24[th] January 2019

**LORD JUSTICE DAVIS:  I shall ask Mr Justice Knowles to give the judgment of the court.**

MR JUSTICE ROBIN KNOWLES:

1. This is a renewed application for an extension of time (of approximately three years and six months) in which to
apply for leave to appeal against conviction following refusal by the single judge.

2. On 5[th] June 2014, in the Crown Court at Snaresbrook, the applicant pleaded guilty to one count of producing a
controlled drug of Class B, namely cannabis. On 4[th] July 2014, he was sentenced to nine months' imprisonment.

3. Since the date of those proceedings, a conclusion has been reached by the appropriate authority that the
applicant is a victim of modern slavery. It is in that context that this application is advanced.

4. The age of the applicant is said by his counsel, Mr Molloy, to be in his thirties. There is an indication in the
papers that he may have reached the age of 40. He was represented in the course of the prosecution leading to his
plea of guilty and his sentence.

5. The circumstances of the case, taken briefly from the Prosecution Case Summary, included the attendance of
the police at an address in Romford, a two storey maisonette above a parade of shops. At that time the premises
were in darkness and the electricity supply had been bypassed. The police there found in a number of rooms 281
cannabis plants in various states of maturity. They also recovered cultivation equipment. A living area and bed
were in the kitchen of the premises. They found the applicant hiding in what would have been the living room.
Having been challenged by officers, the applicant jumped from the first floor window and was apprehended in the
street. After arrest, he was transferred to hospital, having incurred an injury to his back.

6. He was interviewed in February 2014. He gave an account to the effect that he had been told that if he came to
the United Kingdom he could find paid work in a restaurant. He had been lied to. The applicant did not speak
English and had no papers. He had been taken to the property and told to water and tend the plants.

7. Shortly before the day on which the applicant pleaded guilty, he submitted a basis of plea. There are, in fact,
two such documents within the papers that we have seen, although one is marked as not accepted by the
prosecution. It is, however, the second and longer basis of plea, which is supported by a statement from the
applicant indicating his acceptance of it, that we have taken as the relevant basis of plea. Mr Molloy has confirmed
that that is the correct approach.


-----

8. Mr Molloy describes the case as one of "debt bondage". When he was arrested, the applicant was found to
have no money. He had been in the country a short period before his arrest. Mr Molloy submits that he was faced
with no true choices.

9. The basis of plea includes these passages:

"1. I was brought to the UK illegally by a human trafficker whom I paid 500 million Vietnamese dong to for my
passage. I was promised work in a restaurant.

2. About five to six days after arriving in the UK, I was taken to a property and told I had to stay there and look after
the plants. I said to them I did not want to do this as I suspected they were illegal plants. I was scared. I was told
that I had to do this and they threatened my life if I didn't do this.

3. I was locked in the property. I had no keys. I was left with instructions as to what to do with the plants.
Someone would come once a week to check the plants and leave food for me.

4. I accept that I had access to a mobile phone and a laptop. I accept that I had contact with my girlfriend, but this
was only after being at the property for one month. I did not feel I could ask my girlfriend or contact anyone else to
ask for help due to the threats that had been made. I feared that if I were rescued they would find me and my life
would still be in danger.

5. I continually asked to be allowed to leave. After being there for two months, they said I could leave in two
weeks. At this point I stayed and willingly continued to look after the plants as they had said I could leave.

6. I was told that I would be paid £800 per month that I was there and that this money would be paid to me when I
left the property. The payment was only agreed when I was promised that I could leave in two weeks. I did not
actually receive any payment. …"

10. We have also seen the interview with the appropriate authorities given by the applicant.

11. Following the conviction and sentence, a deportation order was served on the applicant on 15[th] July 2014, and
a decision to deport was made on 20[th] August 2014. An appeal by the applicant against that decision was
dismissed by the First Tier Tribunal on 20[th] January 2015.

12. In due course, the applicant attended a screening interview in the course of asylum proceedings. On 29[th] May
2015, the Home Office wrote to confirm that the competent authority had concluded that the applicant had been
trafficked.

13. The applicant's claim for asylum, however, was ultimately refused on 26[th] November 2015. It was followed by
an appeal hearing on 17[th] August 2016, which had the result of the matter being referred back for further
consideration of the risk to the applicant's human rights. As we understand it, having had the benefit of
submissions from Mr Molloy, the matter remains unconcluded.

14. The authorities to which we have had regard include the recent decision or R v S(G) [2018] EWCA Crim 1824;

[2019] 1 Cr App R 7. That decision in turn draws, understandably, on the earlier decision of _R v Joseph_ _[2017]_
_EWCA Crim 36; [2017] 1 Cr App R 33.  In giving the judgment of the court in R v S(G), at [1] Gross LJ indicated:_

"... as repeatedly made clear, where crimes have been committed by [victims of trafficking], even arising from their
own trafficking, there is no blanket immunity [from prosecution]. Decisions are necessarily fact sensitive, taking into
account the public interest both in prosecuting alleged offenders and in protecting [victims of trafficking]. ..."

We have regard, without setting it out, to the summary of principles at [76] of the judgment.

15. Mr Molloy accepts that cases are very fact specific. The burden of his submission advanced on behalf of the
applicant is that someone should have taken charge of the situation at the time of prosecution and deliberately


-----

addressed the question of the implications of the allegation, since confirmed, of people trafficking and should have
done so in the context of the criminal offence at hand.

16. The central plank of Mr Molloy's challenge in that regard is on the question whether there should have been a
prosecution. Of second order, the question is whether the legal representatives at the time should have done more
in relation to the possibility of advancing a defence of duress.

17. We have examined the matter carefully, as did the single judge. We have reached the same view as did the
single judge for largely the same reasons as she recorded. Fundamentally, the safety of the applicant's conviction
is not in doubt. When one looks at the question of the prosecutor's discretion to proceed, it cannot, in our judgment
be said to be arguable in the present case that the nexus between the crime committed and the trafficking is
sufficiently close. It cannot, in our judgment, be seen as arguable that the levels of compulsion in the present case
were such that it was not in the public interest for the prosecution to proceed. This is not a case in which it is
arguable that there were no reasonable alternatives available to the applicant.

18. Indeed, there is sufficient material, including that set out in the Respondent's Notice, to indicate that these
questions, at least in overall terms, were amongst those that were considered at the time. Further, it is to be said
that even if the matter is capable of closer argument at the point at which the offending began, this is a case, as the
basis of plea on the applicant's own account reveals, in which the matter becomes unarguable at the latest when
one considers the decision to continue with the offending after circumstances had changed and his freedom of
action was greater.

19. So far as the question of duress is concerned, it is to be noted that the applicant confirmed his wish to plead
guilty, having received advice from his representatives at the time on the question of duress. In that circumstance,
it is not surprising, taking this case very much on its own facts, to find that Mr Molloy puts that point as of second
order. Again, it cannot be said in the present case that it is arguable that the public interest pointed towards the
suitability of a stay, particularly, as the decision in _R v S(G) indicates, when one examines that question with_
consideration of the force of compulsion, which was not arguably strong in the present case in particular if one looks
at the case at the point of the applicant's decision to continue to water the cannabis plants.

20. In those circumstances, and in agreement with the single judge, the renewed application is refused.

_____________________________________

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part**
thereof.

165 Fleet Street, London EC4A 2DY

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

____________________________________

**End of Document**


-----

