# R v BTT [2021] EWCA Crim 4

Court of Appeal, Criminal Division

Flaux LJ, Cheema-Grubb and Murray JJ

7 January 2021Judgment

**Daniel Bunting (instructed by Birds Solicitors) for the Applicant**

**Andrew Johnson (instructed by The Crown Prosecution Service) for the Respondent**

Hearing date: 18 December 2020

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Lord Justice Flaux:**

Introduction

1. At the conclusion of the hearing of this application for leave to appeal against conviction on 18
December 2020, we indicated that the application would be refused and that we would provide written
reasons in due course. These are those reasons.

2. On 22 April 2016, following a trial at the Crown Court at Bolton before HHJ Clayson and a jury, this
applicant was convicted of an offence of producing a Class B drug, cannabis and was sentenced to 3 years
imprisonment. By grounds of appeal dated 1 May 2020, the applicant seeks to appeal against conviction
and an extension of time of nearly four years. The applicant also seeks leave to adduce fresh evidence. He
contends that he was the victim of human trafficking and that, in the light of fresh evidence, a defence
under section 45 of the **_Modern Slavery Act 2015 was available to him which it was likely would have_**
succeeded, so that his conviction was unsafe. His applications have been referred to the Full Court by the
Registrar.

3. At a directions hearing on 18 November 2020, the Court ordered the application for leave to appeal to
be heard as soon as reasonably practicable, with the appeal to be heard immediately after if leave were
granted. It was also ordered that the fresh evidence be admitted _de bene esse and that the applicant_
attend the hearing to give evidence and to be cross-examined. It was ordered that his evidence, and any
cross-examination should be limited to events in the period after he came to the UK, but should cover the
evidence he gave to the Crown Court, the reasons why that account is not accurate and the evidence upon
which he wishes to rely for the purpose of the appeal.

The facts of the offending

4. The relevant facts are as follows. On 13th October 2014, the Applicant entered the United
Kingdom. He was arrested, but subsequently released on immigration bail. He did not report to the
UK Border Agency as directed. On 6th November 2015, police executed a search warrant at 75
Royal Court Drive, Bolton. The applicant was found inside. The loft area had been converted for the
purpose of growing cannabis with ventilation fans and lighting. 223 plants were recovered. The
possible yield was between 5 ½ and 11 kilograms


-----

5. Later that day, the applicant was interviewed under caution. He stated that a friend had offered him a
job. He travelled from London and was collected from the train station. He was allowed to stay at the
premises free of charge. He was promised a 50% share of any revenue raised from working on the
plants. He spent around a month at the premises, following instructions to feed and water the
plants, and operate the lights. He had maintained the plants alone and saw no one else whilst he was
doing so. He was able to leave the premises whilst residing there and did so. Whilst he accepted
maintaining and growing the plants, he had no knowledge that they were cannabis, or otherwise
illegal. Neither he nor his family had been threatened by anyone.

6. The Prosecution case was that the applicant was involved in the cultivation of those plants which he
knew to be cannabis and illegal. The prosecution relied on (i) the secretive way in which access to the loft
was gained; via a hole cut into the ceiling inside a built in wardrobe, (ii) that it was an expensive and
sophisticated exercise (iii) that the applicant was benefitting from free accommodation, food, £300 and a
share of the profits, (iv) that he was an adult and (v) the strong and distinctive smell negating any
suggestion that the applicant did not know that it was cannabis.

Events pre-conviction

7. In his Defence Statement, which he signed on 3 March 2016, the applicant stated that he did not
know that the plants being produced were cannabis. He had travelled to the United Kingdom in October
2014 to look for work. Whilst in London he was made aware of work available in the north of England by
an acquittance he knew as 'Linh'. Linh purchased a train ticket for the Appellant to travel to
Manchester, where he met a man he knew as 'Nam'. Nam took the Appellant to a house in Bolton, gave
him £300, and told him to take care of the plants in the house by watering them and by turning on lights as
necessary. In other words that was essentially the same account has he had given in interview.

8. Thereafter the applicant's solicitor requested further information from the CPS as to the applicant's
potential exploitation and trafficking into the UK. It appears that this request was at the behest of Adam
Lodge, the applicant's then counsel, since, in commenting on the grounds of appeal on 14 April 2020, he
stated that the Applicant was 'adamant through our discussions that he had not been the victim of
trafficking', but that he considered this 'unconvincing'. He therefore 'raised with prosecution counsel prior
to the commencement of the trial whether any proper assessment had been conducted to
determine whether the defendant had potentially been trafficked. It appears that any such
investigation that was conducted was lacking in detail and as such there was no material to support
any suggestion of trafficking. Notwithstanding the client's account this was a matter aired at trial'.

9. The prosecution response was that there had been no request for disclosure regarding trafficking;
that nowhere did the defence statement allege that the Appellant had been trafficked into the country;
that there was no evidence to suggest that he was trafficked; and that on his own account he had
willingly taken part in an enterprise in the belief that to do so was legal. At the conclusion of the prosecution
case, apparently after the issue was raised by the judge, legal argument took place regarding an alleged
failure properly to comply with guidance regarding the prosecution of potentially trafficked individuals. The
judge gave a ruling saying, inter alia, that the CPS has an obligation to consider whether there is a
realistic possibility that a person might be the victim of trafficking; that the obligation is 'not an easy
exercise nor must it be performed superficially'; and is not one which can be discharged purely by
asking the person concerned whether they are a victim of trafficking. There had been no consideration of
the issue so it was incumbent on the judge to raise it.

10. The judge referred to the evidence that the Applicant was seen with eight other individuals
getting out of the rear of a lorry on the M2 in Kent; police were called; and he was arrested shortly
thereafter. Appointments were made for him to report to immigration officers but he failed to do
so. He never made any application for asylum and at no stage suggested that he was in the United
Kingdom under pressure. Whilst what the defendant said was not determinative, the judge could assess it.
What the defendant had said to the police indicated that he could 'freely speak to the police about his
personal circumstances' and that 'even adopting a most cautious approach to what he has said to the
police in this case it does seem to me that in its essential tenants what he said to the police about his


-----

circumstances appears, strongly appears, to be true'. The judge concluded that the way the applicant was
encountered entering the country – having been 'simply released from [a] lorry in Kent' – is
'inconsistent with trafficking'. There was and is no appeal against that ruling.

11. The applicant then gave evidence at the trial. The written submissions for the applicant by Mr Bunting
quote extensively from the transcript of evidence including his evidence as to how he came into the UK, but
what matters for present purposes is his evidence as to the circumstances in which he came to be working
at the premises in Bolton. In summary, he stated that he had been offered a job by a friend which would
enable him to send money back to his family. He was allowed to stay at the address free of charge in
return for tending the plants – watering, feeding and operating the lights. He did not know that the plants
were cannabis and illegal. He relied on his poor background in Vietnam and denied that he had seen
plants like that before. He was told they were vegetable plants that were too tender to be grown outside.
He needed the money which was why he agreed to tend to them but denied being told, or aware, that they
were cannabis., Neither he, nor his family, had been threatened. In other words, his evidence at trial
essentially reiterated what he had told the police when interviewed. It is striking that, although there had
been discussion between the judge and counsel about whether the applicant was the victim of trafficking,
of which the applicant must surely have been aware, there was no suggestion in the applicant's evidence
that he had been trafficked whilst in the UK or that he had been compelled to work in a cannabis factory.

12.  During the course of his summing up but in the absence of the jury, the judge said to counsel:

“I had meant to say this morning that I would keep under review the decision that I explained. It
seems to me that is something one ought to do in that type of situation and having heard the defendant's
evidence I entirely confirm what I said by way of a decision on the merits in fact of this case at that
earlier stage. So I thought I should add that, that I have done that exercise and this is the outcome”.

The judge thereby confirmed the conclusion in his earlier ruling. There was no evidence, even from the
applicant himself, that the applicant was the victim of trafficking

Events post-conviction

13. After the applicant's conviction, on 13 May 2016, the Home Office gave notice of intention to deport the
applicant and on 24 May 2016, he claimed asylum. On 4 July 2016, a screening interview took place at
which the applicant claimed for the first time that he had been trafficked, saying: “in the UK I was forced to
grow cannabis plants, I was under control and unable to speak out, by the people who trafficked me to do
what I did”

14. The applicant was referred to the National Referral Mechanism and on 3 October 2016, the Home
Office as the Competent Authority made a conclusive grounds decision that the applicant was a victim of
human trafficking from Vietnam to the UK and whilst in Russia for the purposes of forced labour.
However, given that the account now given by the applicant of being forced to grow the cannabis plants
was inconsistent with the evidence he had given at the criminal trial, it was concluded that he did not meet
the criteria for forced criminality within the United Kingdom. Accordingly, the Competent Authority
declined to grant the applicant leave to remain in the United Kingdom.

15. His asylum claim was refused on 21 July 2017 and an appeal was lodged. On 6 October 2017, he was
seen by Susan Pagella, a psychotherapist. He told her that he had worked in the cannabis factory due to
being blackmailed and that he had not received any money. She concluded that he appeared to be
suffering from PTSD.

16. The applicant signed a witness statement dated 25 October 2017. In relation to the offending he said
as follows. After arriving in the United Kingdom and being arrested, he was released. He followed
the people who he had arrived in the country with, who took him to see friends. He moved from
place to place, staying with anyone who could offer him either employment or accommodation. He
did not understand that he was under an obligation to report to the immigration authorities. Whilst staying
with a man called Mr Son, he was visited by Mr Linh. He asked Mr Linh to let him know if he had any
jobs available. In summer 2015, Mr Linh told the Applicant that he knew of someone who could
arrange work for him Mr Linh took the Applicant to Manchester to meet an agent who were nice to him


-----

They took details of his family members in Vietnam. He was subsequently taken to a house, where he
was forced to grow cannabis. He had keys to the house and was free to leave to buy food. He knew
that the work was illegal. He was forced to do it. He could not contact the police, because he was scared of
the people forcing him to do the work, as they had the details of his family. He was told that his wife and
daughter had been kidnapped.

17. In a further witness statement dated 24 April 2018, the Applicant stated that when he arrived
at the house where he was arrested, he was told 'that they had already kidnapped my wife and children in
Vietnam. I realised this operation was linked to my traffickers. I am not sure how they initially found me
again'. He was permitted to leave the house but was told that he would be killed if he told anyone
what he was doing or contacted the police. He stated: 'During the original trial, what I told my original
lawyers and in court was incorrect information. I was told by my traffickers if I was arrested to
say I was splitting the profits. I did think the plants were vegetables at first, this is what I was told. I now
feel able to make disclosures that I didn't during my original criminal (sic) as I know that my daughter is
safe, I have spoken to other family members back home. I do not know about my wife or if she has
escaped. I am not aware that my trial solicitors raised trafficking, although my new solicitors Birds have
informed me that it was raised prior trial'.

The decision of the Upper Tribunal

18. The asylum appeal was eventually determined in his favour by Upper Tribunal Judge (“UTJ”) Coker. In
an Error of Law Decision dated 29 July 2019, she set aside the Decision of the First-tier Tribunal to be
remade by the Upper Tribunal at a resumed hearing. However, in that Decision she held that the finding of
the First-tier Tribunal (based in part on the report of Ms Pagella) that the applicant was a vulnerable person
with mental health problems should stand. The applicant did not give evidence before the First-tier Tribunal
allegedly because of his vulnerability. He also did not give evidence before the Upper Tribunal, although
the judge had his witness statements. She noted that they had not been tested by cross-examination and
that merely because he was vulnerable did not mean that his evidence was to be taken at face value.

19. The Upper Tribunal had the benefit of the detailed expert report from Mr Bernard Gravett, an expert in
human trafficking, upon which the applicant also seeks to rely on this application. At [17] of her Decision
UTJ Coker recorded that his report had not been challenged by the Secretary of state. She continued:

“In a detailed analysis he concludes that the journey and work details provided by the appellant are
supportive of a finding that the appellant has been trafficked not only between Thailand and Russia but
also to and within the UK. This has, he concludes also led to debt bondage, even though the appellant may
not personally be aware of this. The appellant's witness statement about the kidnapping of his wife and
child and threats to his parents are, he concludes supportive of the appellant' trafficking account. He gives
the firm opinion that the information provided by the appellant is the profile of trafficking by sophisticated
criminal groups operating transnationally.

…

He concludes that the appellant was trafficked to the UK with the intention to exploit him, but that
immediate intention was disrupted by the intervention of the police and immigration authorities. He is very
firmly of the opinion that the appellant's account matches the information known of trafficking mechanisms
and routes with the accompanying threats and violence.”

20. In the Conclusions section of her Decision, UTJ Coker says this at [38]-[39] in a passage upon which
the applicant particularly relied on this application:

“38. Mr Melvin [for the Secretary of State] submits that the appellant was not trafficked in the UK. I do not
agree. The CA report refers to trafficking to the UK and whatever the shortcomings of the CA report (which
were not the subject of consideration in the Error of Law hearing) the report by Mr Gravett, which has not
been challenged, is highly credible. The appellant's evidence in the context of the undoubted expertise of
Mr Gravett can only result in a finding that the appellant has been trafficked by organised criminal gangs
that are linked transnationally.


-----

39.1 am satisfied the appellant gave details of his parents and legal wife and child to the 'employer' in the
UK. This information was, I am satisfied, utilised by them as a continuing hold and threat over him during
his criminal trial, conviction and sentencing. Although the appellant has provided no further evidence of
continuing threats to his family, and his daughter has escaped, I am satisfied that the 'employers' in the UK
utilised the information about him and his family to improperly prevent him from disclosing his account at
an earlier stage. The timing of the threats and the extent of the threats is corroborative of that in the context
of the report by Mr Gravett. I make this finding even though I have doubts as to the existence of his
'common-law wife as described by him.”

The fresh evidence

21. The applicant seeks to rely upon an extensive amount of material as fresh evidence, much of which
we have already referred to: the Decision of UTJ Coker, the Conclusive Grounds decision of the
Competent Authority, the applicant's witness statements, the transcripts from the trial, the report of Susan
Pagella, the Country Report of Dr Tran, the report of Mr Gravett, the report from Lisa Davies a
psychologist, prison medical records, detention review documents, letters from Joanne McAlpine, the
defence file from the applicant's previous solicitors and a _Gogana_ affidavit from the applicant's current
solicitor.

22. It was submitted by Mr Bunting who now acts for the applicant that apart from the transcripts of the
previous trial which are not fresh evidence as such but clearly relevant, the other materials were not
available at the time of the trial and much of it is independent evidence which is capable of belief and so
satisfies the criteria under section 23 of the Criminal Appeal Act 1968. In any event as already indicated we
admitted all the material de bene esse and we have considered it carefully.

23. The criteria for allowing fresh evidence are well-known and are set out in section 23(2) of the Criminal
Appeal Act 1968:

“(2) The Court of Appeal shall, in considering whether to receive any evidence, have regard in particular
to—

(a) whether the evidence appears to the Court to be capable of belief;

(b) whether it appears to the Court that the evidence may afford any ground for allowing the appeal;

(c) whether the evidence would have been admissible in the proceedings from which the appeal lies on an
issue which is the subject of the appeal; and

(d) whether there is a reasonable explanation for the failure to adduce the evidence in those proceedings.”

24. So far as the decisions of the Competent Authority and the Upper Tribunal are concerned, we have no
hesitation in admitting those in evidence pursuant to section 23 of the 1968 Act essentially for the same
reasons as this Court gave for admitting in evidence similar material in GS [2018] EWCA Crim 1824; [2019]
1 Cr App R 7 at [67] to [69]. However, like the Court in that case, we are not to be taken as determining
that the decisions of the Competent Authority or the Upper Tribunal would be admissible at any trial,
although in practical terms as Gross LJ said at [69] any admissibility difficulties would be likely to be
resolved by admissions. We were also referred by Mr Bunting to the very recent decision of the Divisional
[Court in DPP v M [2020] EWHC 3422 (Admin) which goes further and finds at [53]-[54] that the decision of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:61HR-GVX3-GXFD-8184-00000-00&context=1519360)
the Competent Authority would be admissible at trial. In the light of our conclusion that this application for
leave to appeal is refused, we do not need to determine whether that decision by the Divisional Court is
correct.

25. In relation to the applicant's witness statements, Mr Bunting accepted that a bare assertion, even if
supported by a statement of truth, that the applicant's original account was false would be unlikely to found
a successful appeal, but he submitted that the applicant had support for his account from various
independent sources including the psychiatric evidence, the other expert evidence before the Upper
Tribunal and the decision of the Upper Tribunal itself.

The applicant's evidence


-----

26. We have of course now seen and heard the applicant give evidence and provide his explanation for
why his account has changed. In summary, his evidence was as follows. When asked in his evidence in
chief how he had come to be in the cannabis factory, he said he had been lied to and taken there by a
group of people. The organiser was Vietnamese. They had lied to him and said he would be given food
and lodging. He had been left alone at the house after a few days. When asked why he had stayed there,
he said it was because he was controlled by those people and was not allowed to leave. He had become
aware the group had kidnapped his wife and daughter in Vietnam. He had left the house to buy essentials.
He said it would have been easy to go to the police but the group had kidnapped his wife and daughter and
controlled him.

27. When he was arrested and interviewed at the police station, he had told the police what his human
traffickers had told him to say when they took him to the house. If he had said anything wrong, they would
have killed his wife and child. He gave the same account at trial but it was not correct. What he was saying
now was the truth. He could not tell the truth in his evidence at the trial because he had to give the account
the traffickers had told him to give. He was able to tell the truth now because, after he was convicted and
sentenced, he had telephoned his parents in Vietnam and learnt that the group had been arrested by the
Vietnamese police.

28. In cross-examination he agreed that he had had two different barristers and a solicitor when the case
went to court who were there to help him. He had wanted to tell the truth but he was afraid, he wanted to
protect his wife and child and if he spoke the truth the group would have killed him. What then emerged in
questioning from Mr Johnson was that the applicant had only learnt that his wife and daughter had been
kidnapped when he telephoned his parents from prison after he was convicted. When asked the obvious
question how he could have been controlled by the group by his wife and daughter being kidnapped, if he
had not even known until after his conviction that they had been kidnapped, he was unable to provide any
explanation other than that he was a person of very little knowledge, that the traffickers had lied to him and
promised him money and food for tending the cannabis plants. He had been forced to lie in his evidence at
trial because he was being controlled by the traffickers who told him what to say. Mr Johnson asked how
the traffickers would have known what evidence he gave the jury as they were not in court at the trial, but
he simply reiterated that the group had told him what to say, that he was being controlled and that they had
kidnapped his wife and child.

29. He repeated that he had found out that the kidnappers had been arrested when he phoned his parents
from prison after his conviction. He found out his daughter had escaped but his wife had not been in
contact since she was kidnapped. When asked why he was suddenly comfortable telling what he now said
was the truth when he did not know what had happened to his wife, he said his conscience wanted him to
speak the truth because he had suffered injustice for many years. Mr Johnson put to him that it was not his
conscience but seeking to quash his conviction, but he repeated that he should speak the truth according
to his conscience. At the very end of the cross-examination the applicant answered yes to the question
whether if had wanted not to cultivate cannabis he could have walked away from the house.

30. In re-examination, the applicant confirmed, after some initial confusion, that the telephone call with his
parents when he learnt that his wife and daughter had been kidnapped had taken place when he went to
prison after his conviction and that that was the first time that he had heard that they had been kidnapped.
Mr Bunting went back to the answer he had given at the end of the cross-examination. The applicant
repeated that if he had wanted to stop cultivating cannabis he could have done. When asked why he had
carried on cultivating it, he said that at the time he was controlled by the traffickers. When they brought him
to the cannabis factory, they said nice things to him, promised him a job and accommodation but they lied
to him. He had given them his home address and details of his family. They had forced him to do what they
wanted. When asked how they had forced him, he said they made him water the plants, they brought him
all the instructions on how to do the work. Instructions were given on the phone and in writing. He said the
group had secretly captured his wife and child so he had to do what they wanted.

Relevant legal principles

31 Section 45 of the Modern Slavery Act 2015 provides:


-----

"Defence for slavery or trafficking victims who commit an offence

(1) A person is not guilty of an offence if –

(a) The person is aged 18 or over when the person does the act which constitutes the offence;

(b) The person does that act because the person is compelled to do it;

(c) The compulsion is attributable to slavery or to relevant exploitation, and

(d) A reasonable person in the same situation as the person and having the person's relevant
characteristics would have no realistic alternative to doing that act.

(2) A person may be compelled to do something by another person or by the person's circumstances.

(3) Compulsion is attributable to slavery or to relevant exploitation only if 
(a) It is, or is part of, conduct which constitutes an offence under section 1 or conduct which constitutes
relevant exploitation, or

(b) It is a direct consequence of a person being, or having been, a victim of slavery or a victim of relevant
exploitation.

(4) A person is not guilty of an offence if

(a) The person is under the age of 18 when the person does the act which constitutes the offence;

(b) The person does that act as a direct consequence of the person being, or having been, a victim of
slavery or a victim of relevant exploitation; and

(c) A reasonable person in the same situation as the person and having the person's relevant
characteristics would do that act.

(5) For the purposes of this section –

"Relevant characteristics" means age, sex and any physical or mental illness or disability

"Relevant exploitation" is exploitation (within the meaning of section 3) that is attributable to the exploited
person being, or having been, a victim of human trafficking.

(6) In this section references to an act include an omission.

(7) Subsections (1) and (4) do not apply to an offence listed in Schedule 4.

(8) The Secretary of State may by regulations amend Schedule 4."

32. Once a defendant has raised evidence of one or more of the elements set out in section 1(1) or 4(1)
so as to discharge the evidential burden, it is for the prosecution to disprove those elements to the
criminal standard: MK _[2018] EWCA Crim 667._

33. As this Court has made clear in a number of authorities, most recently in A [2020] EWCA Crim 1611,
positive decisions of the Competent Authority under the National Referral Mechanism are not conclusive of
an issue in criminal proceedings. The correct approach to such decisions was set out at [40] of N [2019]
_EWCA Crim 984:_

“It is important to appreciate a court will bear the Competent Authority's conclusion very much in
mind but will examine the cogency of the evidence on which the Competent Authority relied and
subject the evidence to forensic examination. It does not follow from the fact that an individual 'fits
the profile' of a victim of trafficking that they are necessarily the victim of trafficking. A careful
analysis of the facts is required including close examination of the individual's account and proper
focus on the evidence on the nexus between the trafficking and the offence with which they are charged.”

34. This Court has indicated that expert evidence from psychiatrists or experts in trafficking is of limited
assistance in determining whether the decision to prosecute is correct or in determining the credibility of an


-----

applicant's account. Assessing the credibility of the account is the function of the jury, not of such experts:
see GS and HHD [2018] EWCA Crim 2995.

35. A number of cases have considered the limited circumstances in which an appeal will be allowed to
enable a defendant to advance a case based upon a different version of events to that advanced at the
original trial. The principle was forcefully stated by Lord Bingham CJ giving the judgment of this Court in
_Campbell [1997] 1 Cr App R 199 at 2004:_

“This Court has repeatedly underlined the need for defendants in criminal trials to advance their full
defence before the jury and call any necessary evidence at that stage. It is not permissible to
advance one defence before the jury and, when that has failed, to devise a new defence, perhaps
many years later, and then seek to raise that defence on appeal”.

36. It is only in the most exceptional cases that the defendant will be permitted to advance a completely
different account or defence to that put forward at the original trial on an appeal against conviction. This is
[demonstrated by the cases upon which the applicant relied. In Solomon [2007] EWCA Crim 2633, the fresh](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VGC1-DYBP-P1FC-00000-00&context=1519360)
evidence was a video recording showing that the appellant was completely innocent of the offences of
which he had been convicted at the original trial. In Blackman [2017] EWCA Crim 190, the fresh evidence
demonstrated that the appellant had an undiagnosed adjustment disorder and that the defence of
diminished responsibility was made out.

37. The position is no different in trafficking cases as Lord Judge CJ made clear in giving the judgment of
the Court in N and L _[2012] EWCA Crim 189; [2013] QB 379 at [86(d)]_

“It has been made plain in numerous decisions of this court, that a defendant is provided with
one opportunity to give his or her instructions to his legal advisors. His defence is then considered
and advanced and he is advised about his plea in the light of those instructions. It is only in the most
exceptional cases that the court would consider it appropriate to allow a defendant to advance what
in effect would amount to fresh instructions about the facts for the purposes of an appeal against
conviction. There is no special category of exceptionality which arises in the context of Article 26.”

The parties' submissions

38. We are grateful to both counsel for their cogent and succinct submissions both in writing and orally.

39. On behalf of the applicant Mr Bunting accepted that it is only in the most exceptional case that this
Court will countenance an applicant who has been convicted on the basis of a particular account seeking
to appeal on the basis of a different account. He recognised in his written submissions that the Court would
be unlikely to allow the application or the appeal unless it considered that the applicant's account from the
witness box was a credible one. He also recognised in his oral submissions that the applicant's account
from the witness box was at best inconsistent. He sought to explain that by reference to the expert report of
Dr Davies, who spoke of the significant trauma the applicant had suffered in his life and how that could
inhibit his ability to provide a coherent chronological account, particularly in a formal court environment.

40. He submitted that the account he gave in his evidence in chief was capable of being accepted. It
tallied with the account in the applicant's witness statements which were before the Upper Tribunal where
the judge had made a careful assessment of the  applicant's account in his witness statements as
contrasted with his evidence at trial and concluded that his account was supported by the expert evidence
which was before her. Mr Bunting also relied upon that expert evidence, specifically from Ms Pagella Ms
McAlpine and Dr Davies who concluded that the applicant was under the coercive control of his traffickers
at the time of the offence and explained why he may have given a different account at the trial.

41. Accordingly, he submitted that this was one of those exceptional cases in which the applicant should
be entitled to advance a different account from the one he had put forward at trial. The new account was a
credible one and it followed that the conviction was unsafe.

42. On behalf of the prosecution, Mr Andrew Johnson pointed out a number of striking aspects of this
case: (i) unlike the majority of cases where this Court has considered out of time appeals by alleged
i ti f t ffi ki thi li t i t d ft t i l th th ft ilt l (ii) th i


-----

question of his being a victim of trafficking having been overlooked by his legal representatives. The issue
was raised but the applicant was adamant that he was not a victim of trafficking; (iii) he had given evidence
on oath at the trial without any suggestion that he was threatened or exposed to violence by those who
recruited him. On the contrary, his account was that he shared in the profits but did not know what he was
doing was illegal; (iv) even though he made no suggestion that he had been the victim of trafficking, the
issue was actively considered by the judge at the trial; (v) the Competent Authority and the Upper Tribunal
had reached different decisions. Whilst the Competent Authority found that the applicant was the victim of
trafficking, it did not accept that the applicant had been forced to commit criminal offences in the United
Kingdom. The Upper Tribunal found that the applicant had been forced to offend in the United Kingdom but
it had done so without seeing him give evidence and be cross-examined. This Court had the advantage of
having seen the applicant give evidence and be cross-examined. The Decision of the Upper Tribunal was
of limited assistance in the circumstances of the present case.

43.  Mr Johnson submitted that the evidence which the applicant had given satisfied neither the criteria for
fresh evidence in section 23(2) of the 1968 Act, set out above, nor the evidential burden which is on the
applicant under section 45 of the **_Modern Slavery Act 2015. The answer the applicant had given at the_**
end of cross-examination was consistent with the explanation he had given to the jury, that he was
committing the offences because he had been promised money. In his evidence to this Court he had kept
saying that he had been promised things and had been lied to but that was not compulsion within the
meaning of the section nor could it be said that a reasonable person in the same situation as the applicant
would have no choice but to commit the offence. The applicant had accepted that he had a realistic
alternative of walking away.

44. He submitted that even if the applicant's evidence were credible, which it was not, it came nowhere
demonstrating a defence under section 45 which has a real prospect of success. This case did not come
close to establishing that the conviction was unsafe

Discussion

45. As we have said, it is accepted on behalf of the applicant that it is only in the most exceptional case
that this Court will countenance an appeal based on an account which is different from the account which
the applicant put forward at trial. Although it is not possible to be prescriptive as to what will constitute
“exceptional circumstances”, since that is an issue which is fact specific, it seems to us that where there is
a change of account, the Court will not allow an application for leave to appeal where there has been a
change of account unless the account now put forward is credible and demonstrates a defence which
would quite probably have succeeded. One aspect of whether the new account is credible is whether there
is a cogent and convincing explanation for the change of account. The requirement that the new account
gives rise to a defence which would quite probably have succeeded if advanced at trial is clear from what
was said by this Court in R v Boal [1992] QB 591cited in R v A [2020] EWCA Crim 1611 at [19]:

“This decision must not be taken as a licence to appeal by anyone who discovers that following conviction
(still less where there has been a plea of guilty) some possible line of defence has been overlooked. Only
most exceptionally will this court be prepared to intervene in such a situation. Only, in short, where it
believes the defence would quite probably have succeeded and concludes, therefore, that a clear injustice
has been done. That is this case. It will not happen often.”

46. Boal and A were cases where a defence had been overlooked. That is not so here. However, the test
applicable here cannot conceivably be less stringent than that set out in Boal and Mr Bunting was not able
to advance any reason why it should be.

47. In any event however stringent the test, we consider this applicant cannot satisfy it for a number of
reasons. First, the account that he put forward to the Competent Authority and for the purpose of his
asylum appeal and which he sought to repeat in his evidence in chief, that he was compelled to commit the
offences because his wife and child had been kidnapped in Vietnam by the group who were controlling and
trafficking him, effectively disintegrated in cross-examination and re-examination. It emerged that, even if
they were kidnapped (which we doubt), he did not learn of that kidnap until long after he had committed the


-----

offences, when he was in prison, from which it follows that that he cannot have been compelled to commit
the offences because his wife and child had been kidnapped.

48. Second, his explanation for the change of account, whether it is that the traffickers had been arrested
or a sudden onset of “conscience” is unconvincing. The reality is that the issue of whether he had been the
victim of trafficking was raised on his behalf by his counsel and the judge at the trial. If, as he now says, he
was being compelled to commit the offences, even if he was in fear of the people he worked for, he could
and should have raised the issue with his counsel who could have raised it with the judge, in which case
special measures such as hearing his evidence in camera could have been put in place.

49. Third, whilst making every allowance for the trauma the applicant has undoubtedly suffered and the
concern of Dr Davies that he would be unable to provide a coherent account in a formal court environment,
we consider that the applicant's evidence in relation to being compelled to commit the offences was not
credible and thus does not satisfy the criterion in section 23(2)(a) of the 1968 Act. What he said in his oral
evidence does not even correspond with what he said in the witness statements which were before the
Upper Tribunal. For example, his evidence that it was not until he was in prison that he learnt that his wife
and child had been kidnapped is completely inconsistent with the evidence in the second witness
statement that he learnt of the kidnap when he arrived at the cannabis factory. In the circumstances, in so
far as the application to admit fresh evidence concerns the applicant's evidence either in statements or in
his oral evidence, the application is refused as the material does not satisfy the criterion in section 23(2)(a)
of the 1968 Act.

50. Fourth, we agree with Mr Johnson that what really emerged from the applicant's oral evidence was an
account which bore some resemblance to what he told the jury. He worked at the house tending the
cannabis plants because he was promised money, food and accommodation for doing so. His repeated
references to the group having lied to him suggests some complaint that they had not given him everything
they promised and does not demonstrate any element of compulsion sufficient to satisfy the evidential
burden under section 45 of the Modern Slavery Act. Furthermore the fact that he accepted he could have
walked away is fatal to any defence under that section having any prospect of success.

51. Having heard and seen the applicant give evidence, this Court is not really assisted by the decision of
the Upper Tribunal which was dependent upon witness statements untested by cross-examination which
put forward an account which cannot stand with what the applicant said in the witness box. Likewise, the
expert evidence cannot lend credibility to the account which the applicant has now put forward.

52. In all the circumstances, this case comes nowhere near being an exceptional one where this Court
might allow a change of account to be put forward at a fresh trial and there is no basis for any conclusion
other than that the conviction was safe. The applications for an extension of time and for leave to appeal
are dismissed.

**End of Document**


-----

