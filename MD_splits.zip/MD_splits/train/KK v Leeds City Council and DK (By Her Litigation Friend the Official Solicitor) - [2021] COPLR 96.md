# KK v Leeds City Council and DK (By Her Litigation Friend the Official
 Solicitor) [2021] COPLR 96

[2020] EWCOP 64

Court of Protection

Cobb J

14 December 2020

**Practice and procedure — Procedure — Test for restriction of disclosure of documents**

A local authority issued proceedings in the Court of Protection in respect of a highly vulnerable young woman with
global learning difficulties and autistic spectrum disorder. The local authority asserted the young woman lacked
capacity to make decisions about her residence, contact with others and use of social media. The young woman's
aunt, who had been her main carer for almost all of her childhood, made an application to be joined as a party to
the proceedings. At the hearing of the application, the local authority and the Official Solicitor presented, and sought
to rely upon, information which, although acknowledged to be relevant to the issue before the court, they wished to
keep confidential from the young woman's aunt. The judge received this confidential material and read it but neither
the aunt nor her lawyers were given access. In refusing the aunt's application, the judge handed down two
judgments; the first an open judgment and the second a supplementary judgment setting out his conclusions in
relation to the confidential material. The supplementary judgment was not disclosed to the aunt nor her lawyers.
The aunt appealed on the grounds of serious procedural irregularity.

**Held – dismissing the appeal –**

(1) There was nothing in the _[Mental Capacity Act 2005 ('MCA 2005') nor in the Court of Protection Rules 2017](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)_
which specifically governed the correct approach to managing sensitive material which was the subject of an
application for non-disclosure. The judge was right therefore to proceed in accordance with established principles
set out in the common law. The general obligation of open justice applied in the Court of Protection as in other
jurisdictions. As a general principle, every party had a right to know the full case against him, and the right to test
and challenge that case fully. However, there were properly recognised exceptions to this (see paras [32], [35],

[41](i)).

(2) A judge faced with a request to withhold relevant but sensitive information/evidence from an aspirant for party
status, must satisfy himself that the request was validly made. Further, any decision to withhold information from an
aspirant for party status could only be justified on the grounds of necessity (see paras [35]–[37], [41](ii), [41](vi)).

[(3) It must be remembered that the whole purpose of the welfare jurisdiction under the MCA 2005 was to protect](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)
and promote the best interests of P. Accordingly, the best interests of P should occupy a central place in any
decision to provide or withhold sensitive information/evidence to an applicant; the greater the risk of harm or
adverse consequences to P (and/or the legal process, and specifically P's participation in that process) by
disclosure of the sensitive information, the stronger the imperative for withholding the same (see paras [39]–[40],

[41](iii)).


-----

(4) While the principles of natural justice were always engaged, the obligation to give full disclosure of all
information (including sensitive information) to someone who was not a party was unlikely to be as great as it would
be to an existing party (see paras [28](iv), [37], [41](v)).

**Per curiam:** The judge should always consider whether a step could be taken to acquaint the aspirant with the
essence of the sensitive/withheld material, possibly by

**[*97]**

providing a 'gist' of the material, or disclosing it to the applicant's lawyers. A closed material hearing would rarely be
appropriate in these circumstances (see para [41](viii)).
**Statutory provisions considered**

_[Family Law Act 1996](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61P0-TWPY-Y1F8-00000-00&context=1519360)_

_[Mental Capacity Act 2005, s 4(4), (7)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61P0-TWPY-Y1KM-00000-00&context=1519360)_

_[Forced Marriage (Civil Protection) Act 2007](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC60-TWPY-Y0KY-00000-00&context=1519360)_

[Court of Protection Rules 2017 (SI 2017/1035), rr 1.1, 9.13, 9.15, 20.4(2)(b), 20.6(2)(b), (5), 20.8(1)(b), 20.14](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5PVM-2371-F16W-C3JF-00000-00&context=1519360)

European Convention for the Protection of Human Rights and Fundamental Freedoms 1950, Arts 6, 8
**Cases referred to in judgment**

_A (A Child) (Family Proceedings: Disclosure of Information), Re [2012] UKSC 60, [2013] 2 AC 66, [2012] 3 WLR_
[1484, sub nom Re A (Sexual Abuse: Disclosure) [2013] 1 FLR 948, SC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G3TJ-00000-00&context=1519360)

_[Al Rawi v Security Service [2011] UKSC 34, [2012] AC 531, [2011] 3 WLR 388, [2012] 1 All ER 1, SC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:54GT-HF61-DYBP-M2SK-00000-00&context=1519360)_

_B (Disclosure to Other Parties), Re [2001] 2 FLR 1017, FD_

_[Bank Mellat v Her Majesty's Treasury (No 2) [2013] UKSC 39, [2014] AC 700, [2013] 3 WLR 179, [2013] 4 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59PW-4PN1-DYBP-M3R8-00000-00&context=1519360)_
_[533, SC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59PW-4PN1-DYBP-M3R8-00000-00&context=1519360)_

_Chief Constable and Another v YK, RB, ZS, SI, AK and MH [2010] EWHC 2438 (Fam), [2012] Fam 102, [2011] 2_
[WLR 1027, [2011] 1 FLR 1493, FD](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMD1-DY9F-G04S-00000-00&context=1519360)

_Official Solicitor to the Supreme Court v K and Another [1965] AC 201, [1963] 3 WLR 408, (1963) FLR Rep 520,_

_[[1963] 3 All ER 191, HL; reversing [1963] Ch 381, [1962] 3 WLR 752, [1962] 3 All ER 178, ChD](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PPB0-TWP1-61H9-00000-00&context=1519360)_

_[RC v CC and X Local Authority [2013] EWHC 1424 (COP), [2013] COPLR 431, CP](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T87-55N1-DYBP-V19X-00000-00&context=1519360)_

_Scott v Scott [1913] AC 417, HL_

_[SK (By his Litigation Friend, the Official Solicitor), Re [2012] EWHC 1990 (COP), [2012] COPLR 712, CP](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T87-55N1-DYBP-V07R-00000-00&context=1519360)_

_Ben McCormack (instructed by Henry Hyams) for the applicant_

_Sophie Allan (instructed by a local authority solicitor) for the first respondent_

_Joseph O'Brien (instructed by Switalskis on behalf of the Official Solicitor) for the second respondent_

_Judgment was reserved._

**COBB J:**
**Introduction**


-----

**[1] DK is a 19-year-old highly vulnerable young woman with global learning disabilities, an autistic spectrum**
disorder, and associated profound needs. She is the subject of, and currently the only respondent to, Court of
Protection proceedings; she has been found to lack litigation capacity and is represented by the Official Solicitor as
her Litigation Friend. The proceedings have been brought by Leeds City Council ('the Local Authority' or 'LCC'), in
whose area DK currently lives. The Local Authority asserts that DK lacks capacity to make decisions about her
residence, contact with others, and use of social media; it seeks declarations and welfare orders in these respects.

**[2] KK is DK's maternal aunt, but has been, for almost all of DK's childhood, her main carer. DK's mother died when**
DK was 4 months old. DK refers to

**[*98]**

KK as her 'mum' and to NK (KK's husband) as 'dad'. DK last lived with KK 3 years ago, and they currently have
contact with each other.

**[3] KK wishes to be joined to the proceedings concerning DK, and earlier this year she made an application for**
party status. This application was listed before His Honour Judge Hayes QC ('the Judge') on 16 June 2020. By
judgment dated 23 June 2020, the Judge refused KK's application for party status; on 2 July 2020 he refused
permission to KK to appeal.

**[4] KK renewed her application for permission to appeal, which was placed before me for determination (r**
20.4(2)(b) and 20.6(2)(b)/(5) Court of Protection Rules 2017 ('COPR 2017'). I directed that permission to appeal
should be considered at an oral hearing, with appeal to follow if permission was granted. I heard that 'rolled up'
application on 30 November 2020.

**[5] By this judgment, I set out my reasons for granting permission to appeal but dismissing the appeal. While I am**
satisfied that the appeal raises an important issue of procedure and practice (r 20.8(1)(b) COPR 2017) (see para

[42] below), I nonetheless conclude that the Judge was not wrong to proceed to determine KK's application as he
did, nor do I consider that his conclusion could be faulted (see in particular paras [43]–[47] below).
**Hearing before HHJ Hayes QC**

**[6] KK's case for joinder and party status was set out in a detailed application supported by two witness statements;**
she was represented at the hearing before the Judge, as she has been at this appeal, by Mr Ben McCormack. For
the reasons more fully rehearsed below (see [16]–[17]), the Local Authority and the Official Solicitor on DK's behalf
opposed the application; they too were represented then, as now, by Miss Allan and Mr O'Brien respectively. At the
hearing before the Judge, the Local Authority and the Official Solicitor presented, and sought to rely upon,
information which, although acknowledged to be relevant to the issue before the court, they wished to keep
confidential from KK ('the confidential material'). The Judge received this documentary confidential material, and
read it. Neither KK nor her lawyers were given access to this material. The Judge gave a separate shorter judgment
(which I shall refer to as the 'supplementary judgment') in which he expressed his view about this confidential
material, and its significance to the decision.

**[7] A preliminary issue arose at this hearing as to whether I too should read this confidential material. No party**
argued that I should not, but Mr McCormack drew my attention to the speech of Lord Neuberger in Bank Mellat v
_Her Majesty's Treasury (No 2) [2013] UKSC 39, [2014] AC 700, [2013] 3 WLR 179('Bank Mellat'), in which he_
offered the following guidance at [70]:

'On an appeal against an open and closed judgment, an appellate court should, of course, only be asked to
conduct a closed hearing if it is strictly necessary for fairly determining the appeal. So … any party who is
proposing to invite the appellate court to take such a course should consider very carefully whether it really is
necessary to go outside the open material in order for the appeal to be fairly heard. If the advocate for one of
the parties invites an appellate court to look at the closed judgment on the ground that it may be relevant to the
appeal, it is very

**[*99]**


-----

difficult for the court to reject the application, at least without looking at the closed judgment, which involves the
initiation of a closed material procedure, which should be avoided if at all possible' (emphasis by underlining
added).

At the hearing of the appeal, Miss Allan (supported in this regard by Mr O'Brien) argued that it was indeed
necessary for me to consider the confidential material. I did not of course conduct a 'closed hearing' as such. I
confirm that I have read the confidential material in the unredacted bundle, together with the supplementary
judgment prepared by the Judge.
**HHJ Hayes QC's judgment**

**[8] The Judge gave a detailed reserved judgment (ie a judgment also available to KK) setting out his reasons for**
refusing KK party status.

**[9] The opening paragraphs of the judgment outline DK's troubled history, the Judge recording that DK had spent**
the greater part of her childhood in the primary care of KK, at her home which is in another part of the country; it
was believed (indeed I believe that KK accepts) that in her teens DK became a victim of Child Sexual Exploitation.
At the age of 16, DK was received into the care of relevant local authority. She made allegations against KK's
husband and son of sexual abuse; these were investigated by the police over a period of 18 months (during which
time KK and DK had no contact) before the police decided to take no further action. Given her troubled
presentation, DK experienced a range of placements, sadly but predictably in different locations around the country.
DK's ongoing exposure to sexual exploitation and trafficking led to involvement by the National Referral Mechanism
(the framework for identifying and referring potential victims of **_modern slavery, ensuring that they receive the_**
appropriate support). In October 2019 DK moved placement once more, this time to Leeds, after she disclosed an
imminent plan to marry an older man whom she barely knew. An urgent application was made to the Court of
Protection when DK later announced that she wished to return to KK's home for Christmas 2019; at an urgently
convened court hearing, DJ Gardner determined on an interim basis that DK lacked capacity in respect of that
decision. Shortly thereafter, KK applied to be joined to the process.

**[10] In his judgment, the Judge then recorded the legal test in relation to joinder thus:**

'[14] Rule 9.15(1) of the Court of Protection Rules 2017 (“COP Rules 2017”) provides that “Any person with
sufficient interest may apply to the court to be joined as a party to the proceedings”.

[15] That rule only founds the right to apply. It does not automatically follow that the person who can show
“sufficient interest” must be joined as a party. Rather, that question falls to be determined by the court applying
rule 9.13(2) (quoted below).

[16] Rule 9.15(1) operates to screen out applications which cannot meet the “sufficient interest” test. If the court
is not satisfied that the person who makes an application (or purports to do so) has “sufficient interest” then that
is the end of the matter. To give an obvious example, someone

**[*100]**

unknown to P (or with only fleeting/trivial involvement in P's life) would not satisfy the “sufficient interest” test.
They would have no right to make an application and would accordingly fall at that “first hurdle”.

[17] If a person overcomes this first hurdle of “sufficient interest”, the application is properly made. But it does
not follow that the applicant must be joined. The court then must apply a further test when deciding if to join
that person as a party. That test is found in rule 9.13(2) of the COP Rules 2017 which provides:

“The Court may order a person to be joined as a party if it considers that it is desirable to do so for the purpose
of dealing with the application” (underlining added) (in original).

[18] The language used in rule 9.13(2) conveys that the court has a broad discretion when determining if a
person should be joined to the proceedings. As Mr McCormack properly conceded during oral submissions,


-----

even if that person can show a close relationship with P, this does not give rise to an “entitlement” or “right” to
be joined or any “presumption” that joinder should happen.' (emphasis by underlining added).

**[11] The Judge next considered (at paras [19]–[20] of his judgment) the 'overriding objective' contained in r 1.1**
COPR 2017, namely the objective 'to deal with a case justly … having regard to the principles contained in the

[[Mental Capacity Act 2005]' (the 'MCA 2005'). He quoted r 1.1(3) in full, which includes (a point he later](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)
emphasised) the requirement on the court to ensure that 'P's interests and position are properly considered' (r
1.1(3)(b) COPR 2017). It is notable that the list of relevant factors also includes a duty to ensure 'that the parties are
on an equal footing'. He reminded himself that:

'… when I interpret and apply the rules for joinder, I must keep the above factors in mind and seek to give
effect to the overriding objective when doing so'.

He reflected the argument of the Local Authority and the Official Solicitor that if joining KK would be contrary to the
'interests and position' of DK (per r 1.1(3)(b) above), then the application must be refused.

**[12] On the application of r 9.13(2) COPR 2017, the Judge cited the decision of Bodey J in Re SK (By his Litigation**
_[Friend, the Official Solicitor) [2012] EWHC 1990 (COP), [2012] COPLR 712 ('Re SK') (a case in fact decided under](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T87-55N1-DYBP-V07R-00000-00&context=1519360)_
the previous rules, but there being no material difference in this respect from the current rules). He quoted from
Bodey J's judgment thus:

'… the court may join a new party if it considers that it is “… desirable to do so for the purpose of dealing with
the application.” The clear import of the wording … is that the joinder of such an applicant would be to enable
the court to better deal with the substantive application (for example, by its being able take into account and
test the views of a close relative who knew the incapacitated person and was familiar with his wishes, feelings
and preferences before he became incapacitated).' (para [42]).

**[*101]**

'The word “desirable” necessarily imports a judicial decision as regards balancing the pros and cons of the
particular joinder sought in the particular circumstances of the case.' (para [43]).

**[13] In drawing together his introductory remarks, the Judge reflected the particular complications presented by this**
case:

'[22] I observe now that if ever there was a case which illustrates the need to balance competing factors when
deciding this issue, this is it. … It has proved to be a challenging task in balancing the factors which pull in
opposite directions. To complicate matters further, in opposing the joinder application, LCC and the Official
Solicitor rely upon written evidence which has not been disclosed to KK. That evidence is material to the
balancing exercise which informs the court's decision. But it cannot be disclosed to KK because, to do so
would – of itself – be to act contrary to DK's best interests. This means that KK (and those who act for her) are
unaware of what that written evidence contains and why it is said to weigh against her joinder application. This
has necessitated this Court preparing a Supplemental Judgment (not to be seen by KK or her legal
representatives) which addresses that evidence. This is an unusual course but one that was proposed to the
Court as the best way of ensuring that DK's interests are protected.'

**[14] The Judge then turned to this specific application. He understandably found that KK had 'sufficient interest' in**
DK and in the process (r 9.15 COPR 2017) in order to make the application. He then turned to the 'desirability' test,
in observing:

'[25] … When I apply the desirability test in rule 9.13(2), I must bring into account the reasons why it is that KK
has “sufficient interest” to make her application'.

He recorded that:


-----

'[26] … She [KK] voices concern about past placement breakdowns and expresses the wish to participate in
the assessment process leading to best interest decisions. From KK's perspective, DK has the wish to return to
live with her and the younger “siblings”.

[27] Such matters not only establish that KK has “sufficient interest” to make her application; they are material
also to the question whether it is desirable that she should be joined as a party to these proceedings and I
weigh them carefully in the balance when considering her application. In many cases, such matters would
combine to satisfy the desirability test, in the absence of strong reasons weighing heavily on the other side of
the balance.'

**[15] The Judge then reviewed the competing arguments of the parties. I distil the Judge's discussion of KK's**
arguments to the following points:

**[*102]**

(i)   KK occupied an important position in DK's life as her primary carer; KK disputed that she exerted any
improper degree of influence over DK;

(ii)   KK wished to take any step necessary to assist in the determination of the facts by the Court of
Protection. If the Local Authority were to advance a case which involves the determination of facts
ultimately to determine welfare issues, then the only proper way to deal with this is/was by joining KK as a
party, enabling her to see the evidence relied on and giving her the opportunity to present her case in
response;

(iii)   The court could exercise its case management powers to control what KK could or could not see as
a party; this was (per Mr McCormack's submission, set out at [39] of the judgment) the way of striking, 'the
proper balance between the (claimed) need to protect DK by preventing KK from seeing particular aspects
of the case, and the need for the court to hear from a close family member as to the issues at the heart of
this case';

(iv)   KK should be able to participate 'sitting in the theatre, not sitting in the wings';

(v)   To ensure that the case is dealt with fairly and to ensure that the parties are on an equal footing, the
court should join KK as a party to enable her to be involved in the process.

**[16] The Judge appropriately rehearsed the arguments advanced by counsel for the parties in this case who**
opposed the application, including the following (in summary):

(i)   It was accepted that it would usually be the case that a parent of a young person who is the subject of
proceedings in the Court of Protection would have party status; by analogy, in Family Proceedings, a
person with parental responsibility would have automatic party status;

(ii)   However, the position is somewhat different when proceedings involve a vulnerable adult in the Court
of Protection, particularly where it is not either a proposed or realistic option for P to reside with or be cared
for by the applicant/prospective party;

(iii)   Any orders for disclosure to KK of the documents filed will impinge on DK's privacy;

(iv)   Where the Art 6 and Art 8 ECHR rights of DK and KK are in play, it must be DK's interests which
prevail ([55] judgment);

(v)   At present, it was/is in DK's best interests for contact with her family to be supervised;

(vi)   KK is currently consulted in respect of best interests decisions for DK, including placement options;
this will continue and can be done without affording to KK party status in the proceedings.

**[17] Specifically, he referenced the fact that DK had made allegations against family members and their associates,**
including NK (KK's husband), and MK (NK's eldest son); he referred to the fact that the Local Authority considered
that KK's relationship with DK exhibits elements of control and their further contention 'that KK having party status
would perpetuate and facilitate this control' ([28] judgment). He referred to the Local Authority's concern that


-----

**[*103]**

KK had behaved, and could continue to behave, in ways which are harmful to DK. He cited the (disputed) evidence
that:

'[28](v) … DK recently attempted to take an overdose of medication and a support worker at DK's placement
overheard part of a telephone conversation between DK and KK shortly afterwards where KK appeared to
encourage DK to end her life.'

The Judge referred to the Local Authority's 'grave' concern that KK's party status:

'[28](vi) … may inhibit DK from making disclosures and expressing her wishes and feelings both in respect of
these proceedings and outwith the proceedings'.

**[18] The Judge (at [41] judgment) described the difficulty for the court in being presented with evidence which it was**
argued could not, or should not, be disclosed to KK:

'[41] … The complexity is added to by the fact that LCC and the Official Solicitor rely upon written evidence
filed in the substantive proceedings the content of which cannot be revealed to KK as, they submit, to do so
would be wholly contrary to DK's best interests. They submit that that evidence (placed within the wider context
of DK circumstances and vulnerabilities) weigh heavily on the other side of the balance as the effect of joining
KK will lead to consequences which cannot be DK's best interests. Further, to take any step of revealing that
evidence to KK would be contrary to DK's best interests. This is not remedied, they submit, through the court
joining KK as a party and then exercising its powers to redact or limit disclosure of information to KK.

[42] I have set out that written evidence and considered the implications of it in a Supplementary Judgment. I
realise that, for KK, this means that I have considered and weighed in the balance evidence about which she is
unaware. But I cannot decide whether it is “desirable” to join KK as a party without asking myself the question
whether to take that step would be to act in accordance with or contrary to DK's best interests. And I cannot
answer that question without having regard to the evidence which has been drawn to my attention.'

**[19] There then follows the crucial paragraph of the judgment ([43]) in which the Judge set out his essential**
reasoning for refusing KK's application:

'[43] Without revealing what that evidence is, I should state my key conclusions having considered and
analysed what it says:

(a) I am satisfied that the reasons for not revealing the written evidence to KK are valid and that the necessity
for redaction is rooted in DK's best interests.

**[*104]**

(b) If I reveal to KK what that written evidence is, DK is likely to disengage from her engagement both with
professionals and with these proceedings.

(c) Similarly, if I join KK to these proceedings, notwithstanding that written evidence, those same
consequences will be likely to result.

(d) I accept the case of LCC (… as supported by the Official Solicitor), that this will inhibit DK expressing her
true wishes and feelings and undermine the process of ensuring her effective participation in these
proceedings.

(e) Accordingly, the weight to be given to that evidence is significant as the effects of joinder, if allowed, would
be to bring about consequences adverse to DK's welfare.

(f) This is not resolved by joining KK as a party and then exercising the Court's power to limit or redact
disclosure The effect of joinder in itself will bring about these adverse consequences for DK '


-----

**[20] In his conclusion, the Judge reflected that KK had advanced reasons on the application which, in nearly all**
cases, would weigh in favour of granting such an application; however, the disadvantages for DK summarised in

[43] of his judgment (set out in the paragraph above) 'weigh very heavily on the other side of the balance'. He
added:

'[48] When I weigh these competing factors, I remind myself that the very purpose of these proceedings is to
ensure the protection of DK and that decisions are made in her best interests. The Court will fail to fulfil that
role by making a decision which runs counter to her best interests.

[49] Making decisions that are in the best interests of DK is crucial if the Court of Protection is to remain true to
its name. Placing DK's best interests at the heart of all decisions is vital. To be able fully to understand DK's
wishes and feelings, professionals working with her need to be able to do so over a period of time and to
maintain her trust and confidence. A proper structure to enable this to happen is essential for DK. As LCC and
the Official Solicitor rightly submit, it cannot be in DK's best interests to make a decision which undermines the
ability to do this.

[[50] If I join KK as a party, I will precipitate circumstances which run counter to both s 4 of the MCA 2005 and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61P0-TWPY-Y1KM-00000-00&context=1519360)
the overriding objective in rule 1.1 of the COP Rules 2017'.

**[21] In considering the competing ECHR rights of the parties, the Judge observed at [55] that:**

'… to join KK as a party would be to interfere with DK's right to respect for her private life. I remind myself that it
is established law in the family jurisdiction that where there is a conflict between the interests of the child and
those of the parent(s) which can only be resolved to the disadvantage of one of them, the interests of the child
must prevail under Article 8(2); Yousef -v- The Netherlands [2003] FLR

**[*105]**

210, ECHR. I find that this same principle applies in these court of protection proceedings such that DK's
interests must prevail over those of KK.'

**[22] The Judge therefore concluded that it was not 'desirable' to join KK to the proceedings, and that the factors in**
support of her case were outweighed by the 'very significant disadvantages' which would result from joinder.
**Grounds of appeal**

**[23] Mr McCormack raises three points of complaint in the Grounds of Appeal on behalf of KK:**

(i)   That the procedure adopted by the court was one which led not simply to there being evidential
material that was not disclosed to the appellant, but where submissions were accepted which were not
made in her presence, and a 'closed' judgment handed down to which she has no access. He made the
point that KK may have been able to provide a counterpoint (ie detailed responses) to the evidence filed.
This offends the open justice principle, robbed the Judge of the potential to make proper determinations,
and thus rendered the proceedings unfair;

(ii)   The judge erred in adopting such a procedure where there might have been alternative methods for
dealing with the proceedings which would have nonetheless properly protected DK's interests. The lack of
information provided to the Applicant prevented her from contributing properly to the design of such
alternative methods;

(iii)   An appeal would in any event raise an important issue of procedure and practice. There is no
reported case law on how the court ought to exercise its discretion under r 9.13 COPR 2017 in
circumstances such as this (where the existing parties resist joinder of an applicant, but for reasons which
are not openly stated). In other contexts, the courts have held that the kind of 'closed material' procedure
such as that adopted in this case can only be imposed where permitted specifically by statutory provision;
(see Al Rawi v Security Service [2011] UKSC 34, [2012] AC 531, [2011] 3 WLR 388('Al Rawi') at [69]). This


-----

case provides a means for this court to review whether that principle applies in the context of proceedings
before it.

**The argument of the applicant**

**[24] Mr McCormack raised no challenge to the Judge's description, analysis, or application, of the COPR 2017 on**
party status and joinder. As to that Mr McCormack conceded that he was unable to argue that the Judge was
necessarily 'wrong' (r 20.14(3)(a) COPR 2017) to reach the conclusion he did in refusing KK party status, but he
argues that it was potentially so, given that the route by which he reached his decision was procedurally irregular
and therefore 'unjust' to the Applicant.

**[25] Mr McCormack has usefully placed the key authorities in this area before the court, highlighting the general**
and well-established principles of open

**[*106]**

justice. However, he properly accepted that within those authorities there exist some common law exceptions, and
that such exceptions exist in cases involving children, and in cases concerning persons with a mental disorder
and/or those lacking the mental capacity to make decisions for themselves. He further conceded that there is no
'bright line' rule that if a judge receives evidence which is kept confidential from another party, this always leads to
an injustice or unfairness; however, he argued that when the principle of open justice is breached, there is a greater
risk of a breach of natural justice. He argued that the occasions when a closed material procedure can properly be
adopted in civil law are few and far between (citing national security as one recognised exemption: see _Al Rawi_
above), and that there was no good reason for the Judge to adopt this course in this case.

**[26] He further argued that having decided to receive confidential material, the Judge could or should have taken**
one of a number of courses (which Mr McCormack termed 'procedural mitigations') which would have allowed KK
and her lawyers some access to the information or the gist of it. In this regard, he alluded to the possibility of:

(i)   Appointing a special advocate and holding a closed material hearing;

(ii)   Consideration of whether the material could be released to the party's lawyers, if not KK herself, on
the undertaking of the lawyers not to share it with their client;

(iii)   Considering whether the 'gist' of the information could be revealed to KK and the lawyers (although
he acknowledged that the Judge appeared to have considered and discounted this approach); he referred
me to Lord Neuberger's judgment in Bank Mellat at [72]:

'… the parties should try and agree a way of avoiding, or minimising the extent of, a closed hearing. This would
also involve the legal representatives to the parties to any such appeal advising their clients accordingly, and, if
a closed hearing is needed, doing their best to agree a gist of any relevant closed document (including any
closed judgment below)';

(iv)   Allowing KK's application and regulating the disclosure of documentation / information to KK within
the proceedings;

(v)   Allowing KK's application but circumscribing the contact between KK and DK so as to prevent topics
being discussed.

**[27] Mr McCormack finally argued that it was an 'arresting proposition' for the Court of Protection to hear matters in**
a 'closed material' way, and that this represented a significant incursion into 'the ordinary way of doing things'.
**The arguments of the respondents**

**[28] The Local Authority and the Official Solicitor made common cause, and I therefore address their submissions**
together. Their principal arguments were as follows:

(i)   It is wrong to equate 'open' justice with 'natural' justice; there is an overlap between the two, but just
because a procedure is not


-----

**[*107]**

entirely 'open' does not render it fundamentally unjust. Miss Allan submitted that 'there is nothing about an
ostensible infringement into the open justice principle per se which would render a decision unjust';

(ii)   Specifically, and in any event (as Mr McCormack had conceded), there are proper exceptions to the
general principle of open justice, and it has long been held that cases involving children and those who
lack mental capacity may be such exceptions if 'necessary';

(iii)   They relied on the judgment of Lord Devlin in Official Solicitor to the Supreme Court v K and Another

[1965] AC 201, [1963] 3 WLR 408, (1963) FLR Rep 520 (at 237–238), where 'the ordinary principles of a
judicial inquiry' were under scrutiny. Lord Devlin observed that these included the rules that:

'… all justice shall be done openly and that it shall be done only after a fair hearing; and also the rule that is in
point here, namely, that judgment shall be given only upon evidence that is made known to all parties. Some of
these principles are so fundamental that they must be observed by everyone who is acting judicially, whether
he is sitting in a court of law or not; and these are called the principles of natural justice.'

But Miss Allan and Mr O'Brien emphasised the passage which followed in Lord Devlin's judgment:

' … a principle of judicial inquiry, whether fundamental or not, is only a means to an end. If it can be shown in
any particular class of case that the observance of a principle of this sort does not serve the ends of justice, it
must be dismissed: otherwise it would become the master instead of the servant of justice.'

They say that the disclosure of confidential material to KK would not serve the 'ends of justice' for DK. In
this regard, they further rely on the judgment of Sir James Munby P in _RC v CC and X Local Authority_

_[2013] EWHC 1424 (COP),_ _[[2013] COPLR 431 ('C v C') in which he confirmed (at [13]) that the well-](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T87-55N1-DYBP-V19X-00000-00&context=1519360)_
established (albeit exceptional) jurisdiction to refuse disclosure of materials to the parties in children cases
is of equal application in the Court of Protection (at [20]);

(iv)   The case-law referred to, and relied on, by KK involve issues of disclosure between existing parties
to proceedings rather than disclosure to a non-party. They argued that lesser obligations of openness arise
in relation to disclosure as between parties and non-parties, compared with the obligations between
existing parties;

(v)   Context is key, and much depends on what is at stake in the substantive proceedings. Here the
welfare of DK is 'at stake', and no step can/should therefore be taken in the manner in which the
proceedings are conducted which would impact

**[*108]**

adversely on DK. The Judge was 'alive' to this point (see [50] of his judgment, quoted at para [20] above),
in indicating his concern that DK should have the ability to participate as fully as possible in the
proceedings;

(vi)   Analogy was drawn with Chief Constable and Another v YK, RB, ZS, SI, AK and MH [2010] EWHC
_[2438 (Fam), [2012] Fam 102, [2011] 2 WLR 1027, [2011] 1 FLR 1493 ('YK') in which Sir Nicholas Wall P](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMD1-DY9F-G04S-00000-00&context=1519360)_
considered at [91] that:

'… since protection is the primary purpose of the Act that, in my judgment, is sufficient to justify the invocation
of PII or non-disclosure under the ECHR'.

And at [102], that:

'… the right to a fair trial manifestly does not entitle a party either to see all the documents in the case or to
have all the information in the possession of the court'.

Whilst there is no specific provision in the _[Forced Marriage (Civil Protection) Act 2007 (making](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC60-TWPY-Y0KY-00000-00&context=1519360)_
[amendments to the Family Law Act 1996) to authorise non-disclosure, the Judge in YK considered himself](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61P0-TWPY-Y1F8-00000-00&context=1519360)
empowered to make robust decisions on the basis of 'closed' evidence, with a view to safeguarding A's


-----

wellbeing. It was submitted by Miss Allan and Mr O'Brien that the Court of Protection is similarly
[empowered with a view to ensuring that P's best interests are protected in MCA 2005 proceedings;](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)

(vii)   The 'closed procedure' adopted by the learned judge was the only practical way in which to ensure
that the risks identified by the court caused by disclosure did not materialise.

**[29] Dealing specifically with Ground 2 of the Grounds of Appeal, it was argued on behalf of the Respondents that:**

(i)   None of the proposed avenues were explicitly proposed by KK or her lawyers at the hearing before
the Judge;

(ii)   The possibility of 'gisting' the material was considered, inferentially, by the Judge at [43](f) and
rejected;

(iii)   Lawyer-only disclosure was not canvassed by KK's representatives; disclosure to lawyers alone
cannot take place without the consent of the lawyers, and that such consent cannot be given unless the
lawyers are satisfied that they can do so without damage to their client's interests: (see C v C at [22]);

(iv)   The fact that some of the proposed avenues were not explicitly considered by the Judge in the
judgment does not render the decision itself 'unjust'.

**Discussion**

**[30] The application for permission to appeal, and appeal, has been very ably argued on all sides, and I am most**
grateful to counsel. Tracts of important and long-established case law, including the classic statements of principle

**[*109]**

contained in the speeches in Scott v Scott _[[1913] AC 417and other authorities to which reference is made above](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDH0-TWXJ-21JT-00000-00&context=1519360)_
and below, have been highlighted and discussed.

**[31] I am wholly satisfied, indeed there has been no issue taken, that the Judge correctly identified and applied the**
relevant test on joinder and party status, as they are set out in rr 9.13 and 9.15 of the COPR 2017 (see para [10]
above wherein I quote the relevant extract from the judgment). I endorse his approach (reflected at [25] and [27] of
the judgment: para [14] above) that in considering the 'desirability' test in r 9.13(2), the 'sufficient interest' of the
applicant for party status is likely to be relevant. The real dispute in this appeal focuses on the Judge's
management and deployment of the confidential material and its impact on his decision.

**[32] There is an appropriately accepted premise by all counsel in this case that it is contrary to the principle of open**
justice for a judge to read or hear evidence, or receive argument, in private; they rightly and unanimously accept
that open justice is fundamental to the dispensation of justice in a modern, democratic society (per Lord Neuberger
in Bank Mellat at [2]/[3]). It follows that generally, every party has a right to know the full case against him, and the
right to test and challenge that case fully. I say 'generally' because there are, as counsel in this case properly
recognised, exceptions to this. Such exceptions were contemplated by the court in Scott v Scott itself (in relation to
wards and, what in 1913 were still referred to as, 'lunatics'), per Viscount Haldane at p 437:

'In the two cases of wards of Court and of lunatics the Court is really sitting primarily to guard the interests of
the ward or the lunatic. Its jurisdiction is in this respect parental and administrative, and the disposal of
controverted questions is an incident only in the jurisdiction. It may often be necessary, in order to attain its
primary object, that the Court should exclude the public. The broad principle which ordinarily governs it
therefore yields to the paramount duty, which is the care of the ward or the lunatic' (emphasis by underlining
added).

It is convenient that I should cite further here (I turn to this point below at para [36]) what Viscount Haldane had
gone on to say at p 438:

'… the burden lies on those seeking to displace its application in the particular case to make out that the
ordinary rule must as of necessity be superseded by this paramount consideration. The question is by no
hi h i t tl ith th i it f j i d b d lt ith b th j d ti i


-----

his mere discretion as to what is expedient. The latter must treat it as one of principle, and as turning, not on
convenience, but on necessity'.

**[33] In the much more recent decision of the Supreme Court of Re A (A Child) (Family Proceedings: Disclosure of**
_Information) [2012] UKSC 60, [2013] 2 AC 66, [2012] 3 WLR 1484, sub nom Re A (Sexual Abuse: Disclosure)_

_[[2013] 1 FLR 948 ('Re A'), Baroness Hale contemplated a similar situation at [18] thus:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G3TJ-00000-00&context=1519360)_

**[*110]**

'The whole purpose of such cases [concerning the care and upbringing of children] is to protect and promote
the welfare of any child or children involved. So there are circumstances in which it is possible for the decisionmaker to take into account material which has not been disclosed to the parties'.

She cited the passage from the speech of Lord Devlin in Official Solicitor to the Supreme Court v K (para [28](iii)
above) and then cited further Lord Devlin's approval of the words of Ungoed-Thomas J at first instance in that case
[([1962] 3 All ER 178 at 180, [1963] Ch 381 at 387):](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CRN-PP90-TWP1-603F-00000-00&context=1519360)

'Where, however, the paramount purpose is the welfare of the infant, the procedure and rules of evidence
should serve and certainly not thwart that purpose … In general, publicity is vital to the administration of justice.
Disclosure to parties not only enables them to present their case fully but it provides in some degree the
advantages of publicity; and it further ensures that the court has the assistance of those parties in arriving at
the right decision. So when full disclosure is not made, it should be limited only to the extent essential to
achieve the object of the jurisdiction and no further.' (emphasis by underlining added).

**[34] Baroness Hale observed (at [34]) that although a closed material procedure was possible in children cases**
where the child's welfare is the court's paramount concern, the arguments against 'making such an inroad into the
normal principles of a fair trial remain very powerful'.

**[[35] It is accepted that there is nothing in the MCA 2005 nor in the COPR 2017 which specifically govern the correct](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)**
approach to managing sensitive material which is the subject of an application for non-disclosure. The Judge
therefore proceeded in accordance with established principles set out in the common law. He was, in my judgment,
right as a first step to satisfy himself that the claim to confidentiality was validly made. He concluded that it was. Of
course, a judge could in other circumstances and on other facts, have concluded that the claim for confidentiality
was not validly made, and therefore have ordered disclosure. Parties in circumstances such as these must be
entitled to assume that a judge will be able to manage the sensitive/confidential information responsibly, scrutinise
the material anxiously, and consider conscientiously whether the request to withhold information is validly made.
The judicial examination of the confidential material in itself offers some safeguard against capricious or
unreasoned objection to disclosure.

**[36] The Judge next considered whether it was** _necessary to withhold the material from the Applicant. Again, he_
concluded that it was. As Munby J said in Re B (Disclosure to Other Parties) _[[2001] 2 FLR 1017 ('Re B') at [89]:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMC1-DY9F-G4V6-00000-00&context=1519360)_

'Only if the case for non-disclosure is convincingly and compellingly demonstrated will an order be made. No
such order should be made unless the situation imperatively demands it. No such order should extend any
further than is necessary. The test, at the end of the day, is one of strict necessity. In most cases the needs of
a fair trial will demand that there be no restrictions on disclosure. Even if a case for restrictions

**[*111]**

is made out, the restrictions must go no further than is strictly necessary' (emphasis by underlining added).

Several years later, Sir James Munby P in C v C returned to this point (at [20]), applying these principles specifically
[to proceedings under the MCA 2005, and citing the comments of Viscount Haldane at p 438 cited above:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)


-----

'Thus far, as will be appreciated, the authorities to which I have referred have mainly related to children. Do the
same principles apply in cases in the Court of Protection relating to adults? To that question there can, in my
judgment, be only one sensible answer: they do. One really needs look no further than Scott v Scott _[[1913] AC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDH0-TWXJ-21JT-00000-00&context=1519360)_
_[417to see that the same fundamental principles underlie both jurisdictions.'](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDH0-TWXJ-21JT-00000-00&context=1519360)_

**[37] This test of necessity ensures that the procedure adopted in circumstances such as these operates as a clear**
exception rather than the rule. It corresponds with the fact that KK had no absolute right to access to the
confidential material. Miss Allan and Mr O'Brien were right to point out that Art 6 ECHR would not endow her with
that right even if she were a party – a point illustrated by Munby J (as he then was) in Re B, in which he said:

'R is entitled under article 6 [of the Convention for the Protection of Human Rights and Fundamental Freedoms]
to a fair trial, and although his right to a fair trial is absolute and cannot be qualified by either the mother's or
the children's or, indeed, anyone else's rights under article 8, that does not mean that he necessarily has an
absolute and unqualified right to see all the documents'.

I accept the argument of Miss Allan and Mr O'Brien that as a _non-party, KK's right of access to the sensitive_
evidence/information was arguably less compelling than if she had been a party. After all, and for obvious reasons,
she did not even have a access to the court bundle at this stage. I further firmly endorse the Judge's view ([55] of
his judgment, para [21] above) that where there is a conflict between the ECHR rights of P and those who aspire for
party status which can only be resolved to the disadvantage of one of them, the interests of P must prevail.

**[38] It seems to me that a judge may well find, indeed would be highly likely to find, that it is necessary to withhold**
sensitive evidence/information from a third party applicant for party status in Court of Protection proceedings where
disclosure would be likely directly to harm P, or otherwise indirectly harm or adversely affect P, such as by inhibiting
P in his/her active participation in proceedings. It must be remembered that the whole purpose of the welfare
[jurisdiction under the MCA 2005 is to protect and promote the best interests of P (see by analogy with the child, Re](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)
_A at [18]); the proceedings must not become an instrument of harm to P (again see Re A at [21])._

**[39] The Judge's rationale for non-disclosure appears to have been firmly and appropriately rooted in his objective**
of protecting and promoting the best interests of DK. In my view, his approach is unimpeachable. What, after all, is
the purpose of the proceedings if it is not to protect DK and enhance her welfare interests? Mr O'Brien made the
compelling point that DK did not

**[*112]**

_choose to bring these proceedings; this is all the more reason why she should not now be put in a position whereby_
her rights and her privacy are challenged/compromised by the process which is designed to protect her. The
protection of DK and the advancement of her best interests rendered as a necessity the withholding of the
confidential material from KK; had the Judge disclosed the material, and/or acceded to KK's application for joinder,
he would have defeated the object of the exercise.

**[40] If there was one crucial judicial finding at the centre of the decision in the case it was that '[t]he effect of joinder,**
in itself, will bring about these adverse consequences for DK' (§43(f)). It seems to me that this finding strikes at the
[very heart of the exercise of the MCA 2005 jurisdiction, where the court is obligated to act in ways which promote](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)
DK's best interests and her 'position'.

**[41] Reflecting on these arguments, it seems to me that a judge faced with the situation faced by HHJ Hayes QC at**
the hearing of the application for party status should consider the following points:

(i)   The general obligation of open justice applies in the Court of Protection as in other jurisdictions (see
para [32] above);

(ii)   A judge faced with a request to withhold relevant but sensitive information/evidence from an aspirant
for party status, must satisfy him/herself that the request is validly made (see para [35] above);


-----

(iii)   The best interests of P, alternatively the 'interests and position' of P, should occupy a central place in
[any decision to provide or withhold sensitive information/evidence to an applicant (s 4 MCA 2005 when](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61P0-TWPY-Y1KM-00000-00&context=1519360)
read with r 1.1(3)(b) COPR 2017); the greater the risk of harm or adverse consequences to P (and/or the
legal process, and specifically P's participation in that process) by disclosure of the sensitive information,
the stronger the imperative for withholding the same (see paras [39]/[40] above);

(iv)   The expectation of an 'equal footing' (r 1.1(3)(d) COPR 2017) for the parties should be considered as
one of the factors (see para [11] above);

(v)   While the principles of natural justice are always engaged, the obligation to give full disclosure of all
information (including sensitive information) to someone who is not a party is unlikely to be as great as it
would be to an existing party (see paras [28](iv) and [37] above);

(vi)   Any decision to withhold information from an aspirant for party status can only be justified on the
grounds of necessity (see paras [36] and [37] above);

(vii)   In such a situation the Art 6 and Art 8 rights of P and the aspirant for party status are engaged;
where they conflict, the rights of P must prevail (see para [37] above);

(viii)   The judge should always consider whether a step can be taken (one of the 'procedural mitigations'
referred to at para [26] above) to acquaint the aspirant with the essence of sensitive/withheld material; by
providing a 'gist' of the material, or disclosing it to the applicant's lawyers; I suggest that a closed material
hearing would rarely be appropriate in these circumstances.

**[*113]**
**Conclusion**

**[42] Having conducted the review of the Judge's decision on this appeal (r 20.14 COPR 2017), I have resolved to**
grant KK permission to appeal. I accept Mr McCormack's submission that the Judge's adoption of a process which
effectively denied the Applicant access to core, relevant, material in determining her application raises a sufficiently
significant issue of principle and practice to justify a consideration of the full merits. What follows, therefore, is my
reasoning for dismissing the appeal itself.

**[43] I have cited the Judge's judgment extensively above because I am satisfied that he diligently and accurately**
identified and applied the relevant law when determining this application for joinder. He rightly, in my judgement,
referred to the 'broad discretion' available to him (see [18] of his judgment quoted at para [10] above) in making a
decision of this kind and rightly prioritised DK's 'interests and position' (per r 1.1(3)(b) COPR 2017) over all else
(see para [11] above). It is apparent that he carefully weighed the relevant issues in play on both sides of the
argument on the issue of disclosure of the confidential material before reaching the conclusion, set out in [49] of his
judgment, that if the Court of Protection is to remain true to its name, all decisions need to be made in the best
interests of P (in this case DK).

**[44] I am satisfied that the Judge rightly prioritised (so far as was reasonably practicable), the need to permit and**
encourage DK to participate in the proceedings which concern her, and/or to improve her ability to participate, as
[fully as possible in any act done for her and any decision affecting her (MCA 2005, s 4(4)). Having regard to the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61P0-TWPY-Y1KM-00000-00&context=1519360)
matters set out in his judgment, which he clearly and sufficiently articulated in [43] (which I cited above) I consider
that the Judge was not wrong to conclude that to join KK to the process 'would be to strike at the heart of this
statutory scheme designed for DK's participation in the legal process', and that this would adversely affect DK's
ability to exercise her Art 6 rights.

**[45] On all that I have read, I am satisfied that the Judge was right to conclude that the act of joinder of KK would, in**
itself, bring about adverse consequences for DK (see especially [43](d), [43](e), [43](f) quoted above) and defeat
the very purpose of the proceedings in which she is a party. I am satisfied that, although unusual, the process by
which the Judge reached this conclusion was not fundamentally 'unjust' (see r 20.14(3)(b) COPR 2017); in short,
having approached the issue by reference to the principles which I have adumbrated at para [41] above, I could
detect no serious procedural irregularity in the way he conducted the proceedings.


-----

**[46] It is evident that the Judge was acutely conscious that KK had been unable to know, let alone respond to,**
some of the evidence relevant to the determination of her application ([42] cited at para [18] above). In my
judgment, he deftly managed that information as between the parties, and, while providing a succinct
supplementary judgment, he provided a much more substantive and detailed judgment which in my judgment gave
more than sufficient reasoning to KK and the parties for his decision. This was not a case, I am satisfied, in which it
would have been possible to gist the material to KK and her lawyers, and no other 'procedural mitigations' (see para

[26] above) – which, I may add, may well be suitable in certain other cases – were apparently suggested to him. In
this regard, his approach followed that advocated by Lord Neuberger in Bank Mellat at [69]:

**[*114]**

'… a judge who has relied on closed material in a closed judgment, should say in the open judgment as much
as can properly be said about the closed material which he has relied on. Any party who has been excluded
from the closed hearing should know as much as possible about the court's reasoning, and the evidence and
arguments it received.'

I should add that, in my conclusion, the Judge was right to prepare a short supplementary judgment setting out his
conclusions relevant to the confidential material. If for no other reason, it has been possible for me sitting in an
appellate capacity, to assess the extent to which, if at all, the confidential material has had a bearing on the overall
outcome.

**[47] Unsurprisingly, the Judge found this to be a difficult decision which warranted a reserved judgment; more than**
once (at paras [22] and [40]) he alluded to the 'challenging task' in the case, and the fact that the issues have
'weighed heavily' with him in the decision which he was required to make.

**[48] Before concluding, I would like to make two short points:**

(i)   It will, I suspect, be relatively uncommon for someone in the position of KK – a former primary carer of
[P (particularly where P is still a young adult) who wishes party status in proceedings under the MCA 2005](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)
– to be denied joinder to the proceedings, and be denied the chance to contribute to the decision-making in
this welfare-based jurisdiction. That said, and adopting Bodey J's comments from Re SK (para [12] above)
for this case, it will always be necessary to balance 'the pros and cons of the particular joinder sought in
the particular circumstances of the case';

(ii)   The Judge's decision, and the dismissal of this appeal, does not detract from the obligation on the
[Local Authority to consult with KK (s 4(7) MCA 2005) as practicable and appropriate on welfare-based](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61P0-TWPY-Y1KM-00000-00&context=1519360)
issues concerning DK.

**[49] For the reasons set out above, I therefore dismiss the appeal.**

**[50] That is my judgment.**

Order accordingly.

MARTHA GRAY Barrister

**End of Document**


-----

