# R v Bariana [2021] EWCA Crim 967

CA, CRIMINAL DIVISION

201802676 C1

Mr Justice Edis, Mr Justice Dove, Her Honour Judge Molyneux

Thursday, 10 June 2021

10/06/2021

LORD JUSTICE EDIS:

1 This is a renewed application for leave to appeal against conviction with an associated application to adjourn that
application, and an appeal against sentence. Hargit Singh Bariana is now 48 years old. On 16 May 2018 in the
Crown Court at Newcastle upon Tyne he was convicted of three counts of requiring another person to perform
forced or compulsory labour, contrary to section 71 of the _[Coroners and Justice Act 2009,(counts 2, 3 and 6), of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7X5W-95G0-Y97X-70VH-00000-00&context=1519360)_
three further counts of requiring a person to perform forced or compulsory labour, contrary to section 1(1)(b) of the
**_[Modern Slavery Act 2015,(counts 4, 7 and 8), and one count of being concerned in supplying a controlled drug of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
[class C, Diazapam, to another, contrary to section 4(1) of the Misuse of Drugs Act 1971,(count 10). Counts 1, 5](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XT0-TWPY-Y0K9-00000-00&context=1519360)
and 9 resulted in acquittals, and it is not necessary to say anything further about them. The forced labour offences
relate to four separate victims, and pairs of counts were laid in respect of two of those victims under the two
different offence creating provisions because of the dates of the offences. The minor differences between the
offences created by the 2009 Act and the 2015 Act are immaterial to the issues before us and it is unnecessary to
deal with them. One matter which is relevant to the sentence appeal is the increase in the maximum penalty which
Parliament brought about in the new Act.

2 On 18 June 2018 a sentence of seven years was imposed for count 4, and shorter, concurrent sentences for the
other forced labour offences were imposed in addition, making a total sentence of seven years in respect of those
six offences against four different victims. A consecutive sentence of 18 months was imposed in relation to the
Diazapam offence. A Slavery and Trafficking Prevention Order was imposed for an indefinite period, about which it
is not necessary for us to say anything.

3 We will deal first with the matters related to conviction. The appellant has applied for an extension of time of
approximately 13 months to renew his application for an extension of time of 18 days to apply for leave to appeal
conviction after refusal by the single judge. His original application for leave to appeal against his conviction was
out of time by 18 days, apparently because counsel made an error as to the time period within which such an
application has to be lodged. He apparently thought that time ran from the date of sentence, whereas in fact it runs
from the date of conviction. It appears that at or about the same time, relationships between the applicant and his
legal team were breaking down which caused further delay and difficulty. In these circumstances we would not
have any difficulty in extending that time, were the merits of the case otherwise to require it. More substantially,
however, there has been a delay of about 13 months between the notification to the applicant of the single judge's
decision and his application for renewal of that application before the full court. This is said to have occurred
because of difficulty which the applicant has experienced in identifying and instructing solicitors to help him. He
says that he has had difficulty in communicating with lawyers and he has written on a number of occasions to this
court setting out those problems.


-----

4 The conviction, it will be recalled, is now a little over three years old. What the applicant says in his documents
about that period of time is to some extent confirmed by information which has been passed to this court recently by
a firm of solicitors called Instalaw. Instalaw are exploring the possibility of judicial review proceedings against the
governor of the prison where the applicant has been held, alleging unlawful denial of his rights to communicate by
mail and by telephone to people outside the prison, including potential legal advisers. We accept for our purposes
what Instalaw say about that. However, the position is that the communication interruption which they describe and
which the applicant complains of has been intermittent. The applicant has not been held incommunicado for the
last three years so that he has been unable throughout that period to communicate with anybody. His letters have
been delayed for the most part, rather than simply disposed of. There are exceptions to that general position which
he complains of, but broadly speaking, it is true. Therefore, the position is that although we accept that he has had
difficulty in communicating with people outside the prison during this last three years, his difficulties in advancing
what he says is his full application for leave to appeal against conviction, are not solely attributable to those
difficulties.

5 We invited Mr Bariana to make oral submissions to us about the nature of the material which he hoped to be able
to deploy if the application were adjourned. He told us that if that were to happen, records would become available
which would show that the business which he operated, allegedly with the assistance of forced labour, did not open
seven days a week but only opened six days a week. He made a number of additional points of a similar kind
which he said would so fundamentally undermine the credibility of the four complainants that his conviction could be
shown to be unsafe. He says that this material was available, most of it, at the time of trial and the reason it was
not deployed or properly deployed was the failure of his legal team both to find out what his case was and then
adequately to present it. Those complaints, which form part of his application to adjourn this application, also form
part of its substance and it is convenient then to move on to review the grounds of appeal which he now seeks to
renew.

6 In relation to conviction, the single judge considered in essence a single point. Towards the end of the trial which
had overrun, the judge became concerned that it may be necessary to discharge the whole jury because insufficient
numbers of them would be able to continue unless it came to a conclusion as quickly as it might reasonably do.
She therefore decided that it was necessary to impose a time limit on defence counsel in making his closing
speech. That time limit was an hour and a half. The judge gave counsel adequate notice of that decision so that he
would be able to hone his submissions and marshal them within the time that she had provided for them. The trial,
although it had overrun, was only overrunning into its third week. It was not therefore a long, complicated trial of the
kind which allegations of this kind sometimes require, but rather a short issue in which four complainants gave their
accounts, and a number of other witnesses gave their accounts, including in particular a Mrs Wiffen, to whom we

will refer shortly. The defendant, as he then was, then gave his evidence, and a co‑defendant, who was also

indicted on count 10, the drugs count, also gave evidence. They were between them describing events which took
place over the period of a few months in 2015 and into 2016. The trial was not therefore one of those lengthy,
document heavy cases which might require counsel properly to address the jury in closing for a period of hours or
even perhaps a day of court time. In our judgment, this kind of case and this particular case can and should
properly be dealt with by defence counsel in making closing submissions to the jury within a period of about an hour
and a half, and there is, in our judgment, nothing in the imposition of that time limit which rendered the ensuing
conviction unsafe or arguably so, and for those reasons we agree with the single judge that that ground should not
be given leave.

7 Since that decision by the single judge, some further grounds have been settled which raise the issues to which
we have already referred in outlining the application to adjourn this application. It is said, in essence, that the case

was badly prepared, that the cross‑examination was inappropriate and failed to make the defence case clear, the

documents which should have been produced were not produced and that there were defence witnesses who
should have been called and which were not. These grounds have been responded to by defence counsel who
conducted the trial, who denies that he failed to deal with the case properly. In respect of one witness, he says that
he was clearly of the view that the witness ought not to be called because to do so would generate a suspicion in
the mind of the jury that what was actually being revealed by that witness, namely a video recording of a
conversation between one of the victims and the applicant, amounted to conduct by the applicant tending and


-----

intended to pervert the course of justice. Another similar video was actually put in evidence. In relation to other
witnesses, the response of defence counsel is that as far as he can recall he was never asked to call those
witnesses and he was certainly never provided with any witness statement on the basis of which he might do so.

8 Reviewing those complaints generally, it is necessary to focus on the actual nature of the issue which the jury
had to decide. They had four accounts from four victims which were capable of supporting each other, and the

judge in due course gave an appropriate cross‑admissibility direction. There was some supporting evidence from a

neighbour, Mrs Wiffen, who described the events next door, described overhearing threats of physical violence
towards the people and described their generally submissive conduct in the presence of the applicant over a period
of time. The applicant's case at trial involved a substantial attack on the police and their good faith. That case was
made clear during the course of the trial and the applicant was directed to serve a defence statement which set it
out, the earlier defence statement having entirely failed to do so. That resulted in a direction to the jury in due
course about the apparent failure to serve a proper defence statement in the first place. In addition, the jury was
directed that the applicant had relied upon matters at trial which he might reasonably have been expected to
mention when interviewed and that if they so found, then subject to the usual caveats, they could hold that against
him. Finally, because of the nature of his case, his previous convictions were adduced before the jury and an
appropriate direction given about them.

9 In all of those circumstances, this could only be described as a strong case. The summing‑up, which we have

reviewed in its entirety was fair and clear. Matters of which the applicant now complains would only ever have been
peripheral to the jury's consideration of the case. In those circumstances, we are in no doubt but that the

convictions were safe and we add into that mix, the observation that the evidence of his co‑defendant was

extremely unhelpful to him as well. Her defence to her involvement in the Diazapam offending was to say that
effectively she had been coerced into it by him as well, so that she was in the same position as the four victims.
The jury in due course acquitted her, presumably accepting that that was the truth of the position.

10 In all of these circumstances, we consider that there is no merit in the application for leave to appeal against
conviction and in those circumstances we do not extend time for it to be advanced, and we consider that no
purpose would be served by adjourning it. For all those reasons, the applications and all of them in relation to the
convictions are refused.

11 We now move on to the appeal against sentence which is brought with leave of the single judge. We have
already explained the structure of the sentence which was imposed which amounted to eight and a half years in
totality, being seven years for the forced labour offences and eighteen months, consecutive, for count 10, the
Diazapam offence.

12 The factual basis on which the applicant was sentenced was set out by the judge in the sentencing remarks. In
view of the fact that this was a sentence imposed after a trial, it is appropriate for this court to have regard to those
findings of fact made by the judge. It is not suggested that they were not properly open to her on the evidence
which had been advanced before the jury and which the jury had relied upon in convicting the appellant. He was
convicted of running a business over a substantial period of time using young, vulnerable, homeless men to work
for him within it. They were threatened with violence and sometimes subjected to violence. Behaviour of this kind

is very calculating. It depends on the belief that the individuals will be too frightened to complain and that no‑one

will believe them if they do. In the unlikely event that anyone ever did complain, the appellant calculated that he
would be able simply to deny what they said. That is in due course what he did.

13 Associated with that business was his selling of class C drugs, Diazapam, which became count 10. Part of his
supplying of that drug included supplying it to the victims from time to time as part of his process by which he
secured their compliance. There is some factual dispute between the parties on the papers about the basis of
sentence, but it is clear from the sentencing remarks what the factual basis adopted by the judge was. The judge
gave particular prominence to the evidence of Deborah Wiffen, who said that she had witnessed and overheard
things which led her to conclude that if any of these victims had ever complained, they would be endangering their
lives. The judge said this:

-----

"So that is a summary of the offences. As far as the guidelines are concerned, it is conceded that this is a category
3 offence in which you played a leading role with a starting point of 18 months. Increasing the seriousness of that
offence in my view is the fact that you were using the supply of drugs on occasions to make it easier to commit
other offences. Those individuals who were supplied with drugs were in my view targeted and you encouraged
them to take drugs even though you knew that they were vulnerable to become addicted to drugs as well as alcohol
and I have dealt with the evidence that covers that area. I am invited to consider that the drugs aspect should be
treated as separate and discrete. To some extent I do, do that.

As far as the slavery offences are concerned, I bear in mind the importance of passing deterrent sentences for
offences like this. There were four separate individuals concerned and the total period covered by the offending
against them is a significant period of time. This was, in my view, commercial exploitation. Your business model
was largely predicated on free labour and the most minimal of expenditure into your business to exploit the
maximum of profit. You were also taking money from some of them on top of benefits for things like electricity and
there was, in my view, a significant degree of planning and organisation. The main aggravating feature, though, in
relation to the slavery is the use of and the witnessing of violence and the attitude witnessed by Mrs Wiffen. The
violence described, it is conceded, included slaps and causing a person to fall down the stairs. There were, in my
view, threats, coercion, what has been described by Mr Finch as "bad bullying", control, where necessary a
restriction of their movement and excessive working hours. The second most important feature, in my view, was
that you were exploiting their vulnerability by way of addiction. You fed and encouraged their addiction to alcohol
and on occasions, as I have described, drugs. We saw your behaviour towards Andrew Sterling on the video
recording that was adduced in evidence and it was clear from that that you were manipulating and seeking to
control that vulnerable individual.

Decreasing the seriousness, I bear account of the fact that these offences against each individual were committed
over weeks or months rather than over years for each of them, that direct violence was only used on limited
occasions and not against everybody, they were not physically locked in and they were not in a foreign country. On
your behalf I am reminded that you have never served a term of imprisonment before and that I should not
sentence on the basis that you caused serious injury. I do not sentence on the basis that you caused that broken
jaw. This case is to be distinguished, I am encouraged to conclude, from some of the others that my attention has
been drawn to from the fact that the housing conditions in those were poor, whereas here they were adequate and
there was less control in that they were not physically prevented from leaving. However, it was clear from all of the
witnesses that they felt that they had nowhere else to go. I am invited to conclude that you took advantage of a
position that you found yourself in and that you did not target people who came to Bondicar Terrace because there
were others there who were happy there. Some were forced to work for only a more limited period of time, and I
am also asked to consider that there was not a high degree of planning, organisation or sophistication, that you
were not motivated by greed and commercial gain. Well, I think I have already dealt with that. The Proceeds of
Crime Act timetable has been set, albeit I understand that you have not completed the statement that was due by
now."

14 That series of findings of fact, in our judgment, illustrates a significant level of serious criminal activity, done for
financial gain on the basis of a calculation that it would produce a profit. At the time of sentencing the appellant was
46 years old. He had 16 previous convictions for 25 offences between 1992 and January 2017. He had multiple
convictions for offences of dishonesty, a conviction for assault occasioning actual bodily harm, an offence of
attempting to obtain property by deception, possessing an offensive weapon in a public place, and other similar
offences.

15 There was a Pre‑sentence Report which the judge had obtained which set out the aggravating factors of the

conduct on which the appellant had been convicted and gave an assessment of his likely risk of reoffending. It
observed that he denied all of his offending, both recent and historic, and had no motivation to make any changes.
The author of the document said that the appellant posed a medium risk of serious harm, particularly to those who
were in a vulnerable position within society who might be susceptible to his promises of helping them to achieve
better.


-----

16 In the grounds of appeal, which were settled by previous counsel and which have been largely adopted by Mr
Sergent, who has represented the appellant on the sentence appeal before us today, a number of criticisms are
made. Some of those criticisms not adopted by Mr Sergent in his oral submissions before us relate to the factual
basis on which sentence was passed. We adopt the factual basis as explained by the judge.

17 The submissions also draw our attention to decisions of this court in cases which may be thought to be broadly
similar and contend that the facts of this case are somewhat less serious than some of those in the reported cases
which resulted in sentences of less than or equal to the sentences in the present case.

18 Finally, it is submitted that the imposition of the sentence in relation to the Diazapam on count 10 consecutively
to the sentences on the forced labour offences had insufficient regard to totality and was, in any event wrong, in
principle because the Diazapam and its abuse was closely connected to the forced labour offences for which a
substantial sentence of imprisonment had already been imposed. It was therefore, it is submitted, wrong in
principle, to impose that sentence consecutively without any adjustment to reflect totality.

19 So far as the sentences for the forced labour offences are concerned, we, unlike the judge, have the advantage
of the decision of this court in _R v Rooney_ _[[2019] EWCA Crim 681 and its careful and illuminating review of](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8V93-K162-D6MY-P1NH-00000-00&context=1519360)_
authority at paragraphs 66 to 72. It is unnecessary for us to repeat any of that. The principal point which we draw
from it, is that this type of offending is always very serious crime. It involves treating other vulnerable human beings
as slaves, in the words used in the title of the Act. That is serious crime, particularly when conducted, as it was in
this case, on a commercial basis and for the simple motive of profit. Sentences in the vicinity of seven or eight
years are in the appropriate bracket, even where, as here, the most serious forms of violent conduct are absent.
We draw attention to the judge's finding in respect of the broken jaw, which she sets out in her sentencing remarks
quoted above. That was the single most serious injury caused to any of these victims during the course of their
exploitation. However, there were other injuries, there were other acts of violence and there was a constant state of
fear. In all of those circumstances, the sentence of seven years imposed in relation to the forced labour offences
was quite clearly warranted.

20 Where we have paused to consider the overall sentence is as a result of the imposition of a consecutive
sentence in relation to count 10 at the level of 18 months, which is the guideline starting point for such offences
standing on their own. As we have said, the Diazapam was an inherent part of the very serious criminal offending
which had resulted in the seven-year term imposed in relation to forced labour offences. In our judgment, it was
wrong in principle in those circumstances to impose a sentence simply based on the guideline starting point
consecutively to that seven-year term. It was necessary at that stage for the judge to step back and to make an
adjustment to reflect the fact that some element of punishment in the predominant sentence of seven years was
designed to reflect the abuse of Diazapam as a means of controlling the four vulnerable victims. Had she done so,
then in our judgment, she would have been driven to make a reduction to her consecutive sentence in relation to
count 10 to give effect to that important sentencing principle.

21 For that reason, we consider it appropriate to allow the appeal to this extent only. We quash the sentence of
eighteen months on count 10, and impose in its place a sentence of six months' imprisonment, which will run
consecutively to the total term of seven years imposed in relation to the other six counts on which the appellant was
convicted, making a total sentence in this case of seven and a half years' imprisonment in place of the eight and a
half years which was imposed by the sentencing judge. To that extent only this appeal is allowed.

__________

**End of Document**


-----

