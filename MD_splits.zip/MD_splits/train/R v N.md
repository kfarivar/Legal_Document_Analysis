# R v N

_[[2019] EWCA Crim 984, [2019] All ER (D) 24 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8VXK-8CH2-8T41-D307-00000-00&context=1519360)_

**Court: Court of Appeal, Criminal Division**
**Judgment Date: 07/06/2019**

# Catchwords & Digest

**CRIMINAL LAW - VICTIM OF TRAFFICKING – UNSAFE CONVICTION**

A fair decision based on the facts of a conclusive grounds decision which should have been made and the evidence
[upon which it would have been based would be that a defence pursuant to s 45](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)
would probably succeed. Accordingly, the Court of Appeal, Criminal Division, allowed the defendant's appeal
against conviction for production of a Class B drug (cannabis) and quashed the conviction.

# Cases considered by this case

R v GS

_[[2018] EWCA Crim 1824, [2018] 4 WLR 167, [2019] 1 Cr App Rep 84, [2018] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T28-JYB1-DYBP-N2GW-00000-00&context=1519360)_
_[(D) 90 (Aug)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5T28-JYB1-DYBP-N2GW-00000-00&context=1519360)_
Considered

**End of Document**


31/07/2018

CACrimD


-----

