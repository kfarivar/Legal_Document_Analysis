# AA (Sudan) v Secretary of State for the Home Department [2021] EWHC 1869
 (Admin)

Queen's Bench Division, Administrative Court (London)

Wall J

6 July 2021Judgment

**Mr Chris Buttler QC leading Mr Ali Bandegani** (instructed by Duncan Lewis Solicitors) for the
**Claimant**

**Mr Jack Holborn (instructed by the Government Legal Department) for the Defendant**

Hearing date: 1st July 2021

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Mr Justice Wall:**

1. This is an application for interim relief. The Claimant is seeking permission for judicial review following a
decision by the Defendant to remove the Claimant to France under the Dublin III regulations. The interim
relief sought is that the Defendant should use her best endeavours to return the Claimant to the United
Kingdom pending the outcome of the litigation.

Background

2. The Claimant is a non-Arab Darfuri from Sudan. He claims to have feared persecution in his own
country and fled to Europe. He travelled to France via Libya. He asserts that in Libya he was sold into
slavery and tortured. On arrival in France he made an asylum claim. That claim was rejected whereupon
he travelled to this country. Here, he made a further asylum claim. The Defendant conducted a screening
interview. The screening interview did not identify the Claimant as a potential victim of **_modern slavery._**
This resulted in his being returned to France under the terms of Dublin III, France being the appropriate
jurisdiction to determine his asylum claim.

3. The UK approach to modern slavery and people trafficking is as follows. This country has international
obligations: we are signatories of ECAT, Article 10(2) of which requires the United Kingdom to “adopt such
_legislative or other measures as may be necessary to identify victims as appropriate in collaboration with_
_other parties and relevant support organisations”. Prior to leaving the European Union the Trafficking_
Directive: 2011/36/EU provided in Article 11.4 that “Member States shall take the necessary measures to
_establish appropriate mechanisms aimed at the early identification of, assistance to and support for victims,_
_in cooperation with relevant support organisations”. Further, Article 4 of the European Convention on_
Human Rights, to which the UK is a signatory, forbids slavery. These international duties are recognised in
[English Law in the Modern Slavery Act 2015. The scheme for implementation devised under that Act is](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
that First Responders, such as immigration officers, must take steps to identify potential victims of modern
**_slavery and refer them on to the National Referral Mechanism which organisation will make a speedy_**
reasonable grounds decision and, if that is positive, thereafter a conclusive grounds determination. The
immigration officers discharge their duty by conducting a screening interview which includes questions


-----

designed to elicit information upon which such a referral might be based. The test for referral is a low one –
any case in which there is “any suspicion” of slavery or human trafficking must be referred on.

The Competing Cases

4. The Claimant's case is that the screening interview conducted with him was unlawful. The Defendant
has a published policy which sets out the questions which should be asked in the course of such an
interview. They include the following: “why have you come to the United Kingdom?” and “please outline
_your journey to the United Kingdom”. It is clear that those questions are designed to elicit information which_
might suggest that someone has been the subject of **_modern slavery. They provide an opportunity to_**
explore with a Claimant the route taken to get to this country, those involved in getting him here and
whether he came through states in which **_modern slavery is particularly prevalent. It is the Claimant's_**
case that at the time of his interview the Defendant also had an unpublished policy. That unpublished
policy was at odds with the published policy in that the two questions referred to were not to be asked. It is
the Claimant's case that this unlawfully curtailed the opportunity for the Defendant to gather material which
would have led her to conclude that the Claimant was a victim of modern slavery and act accordingly.

5. Why does the Claimant assert that this is significant? Had the Claimant been identified as a potential
victim of modern slavery, he could not have been removed from the United Kingdom until the process of
investigating that issue was complete. He would also have been entitled to assistance and support while in
this country. Had a conclusive determination that he was a victim of **_modern slavery been made_**
thereafter, he would have been eligible to apply for leave to remain in this jurisdiction. However, the failure
to refer him led to a removal of the Claimant to France. It ended this country's responsibility for him. The
position of the Claimant in France is less advantageous than would have been his position in the United
Kingdom. France, he asserts, unlike the United Kingdom, will not investigate whether he was a victim of
**_modern slavery in circumstances where the acts of slavery allegedly happened to a foreign national_**
abroad and were not committed by a French citizen. The Claimant's asylum claim has already been
determined against him in France. He is now liable for removal at any time and in the meantime is not
entitled to support from the French Government. If he is removed it is likely to be to Sudan where there is a
real risk that he will suffer physical or psychological harm on account of his ethnicity.

6. His claim is supported by evidence. It can be summarised briefly:

a) A report from Dr McQuade dated 12th June 2021. He is a Director of Anti-Slavery International and has
been investigating the issue of slavery since 2006. He considered the statement of the Claimant and found
that he exhibited nine of the eleven features that are recognised indicators that someone has been
trafficked. He was also of the view that the description given by the Claimant of the way in which he was
enslaved in Libya is typical of the way in which modern slavers in that country behave.

b) A report from Dr Allinson dated 10th June 2021. Dr Allinson is a General Practitioner with particular
experience in interpreting scars and psychological consequences of ill-treatment. She has worked for
Medical Justice for two years and was this year appointed as a clinical trainer for that charity. She
conducted a video interview with the Claimant. She concluded that the diagnostic criteria for PTSD and
depression were met in his symptoms. She wrote that the Claimant told her that he suffered from
musculoskeletal discomfort which is, in her opinion, typically found in people who have been tortured. She
also saw images of scarring on the Claimant's body which scarring she said would have been picked up
had the Claimant been medically examined before his removal to France.

c) A Sudan Country Report by Peter Verney dated 21st June 2021. Following a lengthy interview with the
Claimant, the conclusions reached by Mr Verney were that the Claimant was certainly a non-Arab Dafuri
and that he would be at real risk of harm if he returned to Sudan. He also reported that there was no safe
place in Sudan to where he could relocate if returned.

d) A report from Christophe Pouly, a French lawyer who specialises in immigration and asylum law in
France. His concluded view is that the French authorities would not investigate whether the Claimant was a
victim of modern slavery given where the acts of slavery took place and by whom they were said to have


-----

been perpetrated. Further, he confirmed that the Claimant's asylum claim in France had been determined
against him and that there was no basis in French law for it to be re-opened.

e) A witness statement from Clare Moseley of Care4Calais who details the lack of state housing or
financial support in France for people in the Claimant's position and the limited medical support made
available to them. There is charitable assistance but it is limited. The COVID crisis apparently resulted in
the shutting down of many NGOs set up to help people such as the Claimant.

f) A witness statement from Nikolai Posner who works for Utopia 56, a charity in France which seeks to
support homeless people. He allowed the Claimant the use of his flat for a few days while he was away
from it but could not accommodate him on a more permanent basis. It is his belief that the Claimant was
street homeless other than for this short period.

g) More generic material (referred to as “objective evidence”) relating to the conditions in France and
trafficking in Libya. This material essentially supports the contents of the reports I have already referred to.

7. The Defendant accepts that she had a published policy in place at the time of the Claimant's interview
which provided for the asking of the two questions referred to above. She also accepts that there was a
policy decision taken not to ask those two questions at this time. It is her case that this new policy was
adopted in order to streamline the screening interview process with a view to reducing contact time
between asylum seekers and others at the time of COVID-19 and to ensure that all cases were dealt with
as expeditiously as possible. However, she asserts that asking the questions would not have resulted in
the Claimant giving information amounting to evidence of modern slavery which would have resulted in a
referral for further investigation. She relies in particular upon the following:

a) The Claimant had an asylum interview with the French authorities and apparently did not provide
evidence of trafficking in that interview or at the subsequent court hearing in France.

b) He was asked the following direct question about exploitation in the course of the screening interview:
“By exploitation we mean things like being forced into prostitution or other forms of sexual exploitation,
_being forced to carry out work, or forced to commit a crime. Have you ever been exploited or reason to_
_believe you were going to be exploited?”, to which he replied “no”._

c) He was asked on 31st July 2020 in the course of his reception interview at Brook House Immigration
Centre where he was held before removal: “In your country of origin, on the way to the UK, or in the UK
_have you ever been subject to exploitation, for example being forced into prostitution, forced labour, or did_
_you have reason to believe that you were going to be exploited?”, to which he replied “no”. During the_
course of the same interview he was asked “have you ever been a victim of torture and/or sexual or
_gender-based violence?” to which he replied “yes”. Having answered that question in this way, he was_
referred to health care for a medical assessment. He did not approach them for a number of days. When
he did approach them and was offered an appointment, it was for a time after his removal was to take
place and did not draw anyone's attention to that fact.

d) The Claimant was given a form headed “Preliminary Information Questionnaire” at his screening
interview (the PIQ form). This form asks among other things whether anything happened to him en route to
the UK and how did he travel here from his home country. He did not fill in the form.

All of this, it is said, is evidence that he would not have made disclosure in interview whatever questions
were asked of him.

The Extension of Time

8. The application for judicial review is made out of time. It is agreed by both parties that I can consider
granting interim relief without determining whether time should be extended. However, both parties have
addressed me at length on the issue. It is agreed that if I did not consider that an extension should be
granted, I should not grant interim relief. Neither side has indicated that there are further arguments they
wish to employ in relation to this issue. Therefore, I have decided that as part of this hearing I will make a
decision as to whether time should be extended. If I decide that it should not, that will be determinative not
only of this application but the application for judicial review generally If I extend time I will go on to


-----

consider whether to grant interim relief. Making a decision now will in any event reduce the number of
issues that will require consideration at the permission stage. (The case is not listed for permission today.
Neither side has urged me to consider it. The Defendant stresses that she has not yet put in a defence and
has had little time to collate evidence that might be relevant. I shall leave permission to be dealt with in the
usual way).

9. The chronology is as follows. The screening interview was conducted on 4th June 2020. The removal
decision was made on 3rd August 2020 and the removal to France occurred on 12th August 2020. The
applications for Judicial Review and interim relief were lodged on 23rd June 2021. On that day an order
was made by Mr Justice Lavender that the application for interim relief should be heard between 28th June
and 2nd July.

10. The law. The time limit for making an application for judicial review is set by CPR 54.5: “The claim form
_must be filed promptly and in any event not later than 3 months after the grounds to make the claim first_
_arose”. That time period can be extended under CPR 3.1: “Except where these Rules provide otherwise_
_the court may extend or shorten the time for compliance with any rule … even if an application for_
_extension is made after the time for compliance has expired”. The test is whether there is a good reason_
for extending time rather than a narrower test of whether there is good reason for the delay - see Lord
Lloyd-Jones in Maharaj -v- National Energy Corporation of Trinidad and Tobago [2019] UKPC 5:

“[38] Here it is important to emphasise that the statutory test is not one of good reason for delay but the
broader test of good reason for extending time. This will be likely to bring in many considerations beyond
those relevant to an objectively good reason for the delay, including the importance of the issues, the
prospect of success, the presence or absence of prejudice or detriment to good administration, and the
public interest.

…

[47] while prejudice or detriment will normally be important considerations in deciding whether to extend
time, there will undoubtedly be circumstances in which leave may properly be refused despite their
absence. One example might be where a long delay was wholly lacking in excuse and the claim was a very
poor and inconsequential one on the merits, such that there was no good reason to grant an extension. ”.

11. I am going to consider the issue of delay in three distinct time periods: firstly, from 3rd June 2020 (the
time at which the screening interview took place) until October 2020 (when the existence of the hidden
policy became known); secondly, from October 2020 until May 2021 (when the Claimant instructed his
current solicitors); and thirdly, from May 2021 until the issue of the claim.

12. The first period. It is accepted that the date from which time runs is 3rd June 2020. That was the date
of the screening interview. The Defendant asserts that the Claimant knew from that date (or very soon after
it) that his asylum claim was not going to be accepted in this country and that he had not been referred for
investigation as to whether he had been the victim of modern slavery. He did not seek to challenge these
decisions then and should not be allowed to challenge them now. The Claimant's case is that he might
have known the outcome at that stage but not that the outcome was arguably reached as a result of a
public law error being made. He could not then have known that these decisions had been taken as a
result of the secret policy not to ask questions designed to elicit answers that might have revealed him to
be a victim of **_modern slavery. The policy was not published. It was at odds with the published policy_**
which was to ask those questions. Additionally the Defendant was publicly denying that this unpublished
policy existed. In a letter written by the Defendant to the Immigration Law Practitioners Association as late
as October 2020 she wrote, “there is no expedited process in place. All individual cases are assessed and
_processed in line with the public guidance”. This was incorrect. I do not attribute bad faith to the Defendant_
when she wrote that letter but the effect of her public stance was that the basis for a successful public law
challenge would not have been apparent at that stage to a lawyer let alone a potential litigant. Further, I
have seen the form completed during the screening interview of the Claimant. Although there was in place
a policy not to ask the two questions to which I have referred, the boxes on the printed form into which the
answers to those questions are normally inserted have been filled in. Against the question “why have you
_come to the UK?” is printed “to claim asylum” and against the question “please outline your journey to the_


-----

_UK” is printed “arrived in the UK by RHIB on 3/6/2020”. I have been shown forms in other cases completed_
in a similar way. It is accepted by the Defendant that these entries do not necessarily record answers
actually given by interviewees but were at times completed by immigration officers from other information
in their possession. It is, to say the least, an unfortunate way to record this information. The document as a
whole reads as a record of interview, setting out the questions asked and the answers given. Anyone
looking at the form would be driven to conclude that the two contentious questions were both asked and
answered in the course of the interview. There is nothing on the form to suggest that some of the
“answers” are in fact being filled in by an immigration officer from other information he or she had to hand.
This would mean that anyone looking at the form at any time prior to the unpublished policy coming to light
would not have been able to ascertain from it that an error of public law might have been made. Again, I do
not ascribe bad faith to the immigration officer who completed the form or anyone who sanctioned the form
being completed in this way. However, in my judgment, it does not lie in the mouth of the Defendant to
criticise the Claimant for not pursuing a case based on a public law error when she is denying the base
facts which might found such a claim and her officials are filling in forms in a way which might properly be
described as concealing the error. It is true that there is limited evidence of the Claimant actively seeking to
challenge the process or obtaining legal assistance in this period but overall there is good reason why the
claim was not brought in this period. Any attempt at a challenge in this period was almost certain to fail
because the alleged illegality was to all intents and purposes undiscoverable.

13. I move to the second period. In October 2020 a report from Her Majesty's Inspector of Prisons alerted
the public to the possibility that there was in place a policy not to ask all of the questions usually asked in
the course of a screening interview. It is accepted by the Claimant that from that date onwards it would
have been open to him to have mounted a public law challenge along the lines of that now commenced. I
have to consider why he did not instruct a solicitor to do so until May 2021. He had already been removed
from the UK. He was street homeless in France. He had no on-going contact with an English lawyer. He
had no resources. He had been told by the Defendant that France was the proper venue for deciding his
claims. He only became aware that he had a potential cause of action in this country after he was
contacted by a British journalist, Aaron Walawalker (from whom I have a witness statement), on 15th
March 2021 in connection with an investigation he was making into the fate of those who were removed to
France on flights including that on which the Claimant was removed. The journalist on 10th May 2021 put
him in touch with his current solicitors who took up the case. Again I conclude that there is good reason
why he did not commence the claim in this period. The options open to a man in his dire financial positon
to challenge this decision from abroad were limited to the extent of being practically non-existent.

14. Finally, the third period. It was part of the Defendant's case that the Claimant's current solicitors did not
act with due alacrity once they were instructed. This was not pushed hard in oral argument by Mr Holborn,
who represented her today. The complaints were that there was no need for a country report on Sudan to
be prepared before issuing proceedings and that Dr Pouly, the expert in French law, should have reported
in less time than the three weeks he took in a case of relative urgency such as this. I reject entirely those
submissions. The current solicitors were engaged on or about 10th May 2021. The claim was issued on
23rd June 2021, a pre-action protocol letter (which was not responded to) having been sent two weeks
earlier. Their client was in France all of that time and street homeless for most of it. The reports were, in my
judgment, all necessary and prepared with adequate haste. This is a case which has been diligently
prepared; any delay in issuing is entirely justified.

15. Having carefully considered each period of delay, I am satisfied that there was good reason for it. I
now consider other relevant matters such as those set out by Lord Lloyd-Jones in _Maharaj -v- National_
_Energy Corporation of Trinidad and Tobago:_

i)  The issues in this case are important. If the Claimant has a valid trafficking claim, it is of the utmost
importance that it is considered and any necessary protection given.

ii) This is not a frivolous claim. The prospects of success (which I deal with below in a different context and
therefore do not set out here) are high.


-----

iii) While the delay is a lengthy one in the context of a normally short window of opportunity to challenge a
decision, there is no discernible prejudice to the Defendant in the case being brought so far out of time.
She is in as good a position to deal with it now as she would have been had it been brought shortly after
the screening interview took place. It does not rely on the potentially fading memories of witnesses. The
documentation has not been lost or destroyed.

iv) There is limited prejudice to good administration by reason of the delay. The Defendant's case is that
this undisclosed policy has now been abandoned. The alleged illegality of it has already been the subject
of litigation which litigation was settled some time ago: DA -v- Secretary of State for the Home Department

_[2020] EWHC 3080 (Admin). I accept for the purposes of this judgment that this amounts to some prejudice_
to good administration.

v) There is a strong public interest in this case being allowed to proceed. This country has international
duties to protect those who are subjected to slavery. We have recognised those duties in our domestic law.
People who have been trafficked and then rely on this country to protect them are entitled to feel confident
that their claims will, where possible, be decided on the merits. There is also a strong public interest in the
court considering a case in which it is being argued that a Government department was applying an illegal
and secret policy.

vi) The effect of refusing the application to extend time appears to be that the Claimant will have no
opportunity to argue his case that he was the victim of modern slavery. He will not be able to do it in this
country because he will be time barred; the evidence before me suggests that he will not be able to do it in
France because they will not consider his position at all (although this is not accepted by the Defendant as
necessarily being the true position). The result of this might well be that his life is imperilled.

Weighing up the reasons for the delay and all of the factors relevant to my decision I am firmly of the view
that there is good reason to extend time in this case and I do so.

Interim Relief – the Approach

16. I turn now to the application for interim relief. I must first consider whether there is an arguable case
and then, if there is, whether the balance of convenience favours granting the relief sought.

Interim Relief - Arguability

17. I have concluded that there is an arguable case. It is a general tenet of public law that a secret policy
must not be followed where it is inconsistent with a published policy. In Lumba -v- Secreatry of State for the
_Home Department [2012] 1 AC 245, having recorded with approval that it was accepted as a matter of_
public law that an unpublished policy must not be inconsistent with a published policy, Lord Dyson said
this:

“[26] As regards the second proposition accepted by Mr Beloff, a decision maker must follow his published
policy (and not some different unpublished policy) unless there are good reasons for not doing so. The
principle that policy must be consistently applied is not in doubt: see Wade & Forsyth, Administrative Law,
10th ed (2009), p316. As it is put in De Smith's Judicial Review, 6th ed (2007), para 12-039: “there is an
independent duty of consistent application of policies, which is based on the principle of equal
implementation of laws, non-discrimination and the lack of arbitrariness.” The decision of the Court of
Appeal in R (Nadarajah) -v- Secretary of State for the Home Department [2004] INLR 139 is a good
illustration of the principle. At para 68, Lord Phillips MR, giving the judgement of the court, said that the
Secretary of State could not rely on an aspect of his unpublished policy to render lawful that which was at
odds with his published policy.”

18. A similar issue to that which arises in this case arose in DA & Ors -v- The Secretary of State for the
_Home Department [2020] EWHC 3080. Three foreign nationals who claimed that they had been trafficked_
while in Libya relied on the same arguments advanced by the Claimant in this case; that is, that the
Defendant applied this unlawful and secret policy which resulted in evidence in support of a trafficking
claim not being elicited from them in the course of their screening interviews. Fordham J found that the


-----

Defendant had in place a secret and arguably unlawful policy between 30th March 2020 and the date of his
judgment (13th November 2020). He then said this:

“[9] there is a strong prima facie case, in particular, that the omission in that interview of two questions ...
which are explicitly identified in the published policy guidance as relevant to the identification at an early
stage of potential victims of trafficking, is contrary to law. In my judgement these arguments are strongly
arguable on the basis that this is a departure without good reason from the Secretary of State's published
policy guidance. In my judgement they are also strongly arguable on the basis that there is in any event no
good reason for that curtailed practise sufficient to be able to uphold it as lawful... More than that though,
there is in my judgement on the face of it the serious risk that individuals who would be picked up as
potential victims of trafficking will go unnoticed through the absence of these questions being asked, with
the prospect of their having their protection claims speedily certified and their being removed... The whole
point of the screening process which I will come on to describe, on the Secretary of State's own evidence,
is this: it processes people in order to put them (unless they are released) into detention with a view to a
proposed decision to remove them”.

19. In that case Fordham J further found that there was “evidence of a particular risk to migrants being
_forced into modern slavery whilst in Libya (para 2(2))”. This conclusion is supported by letters I have been_
shown from the Helen Bamber Foundation and Medicins Sans Frontieres.

20. Fordham J went on to record that the reason presented to him for the Defendant reducing the number
of questions to be asked during a screening interview was that they were being conducted over the
telephone during the time of the COVID crisis as there was a need to reduce contact time between asylum
seekers and others. While accepting this, he said:

“[9] I am quite satisfied that the real and substantial change that the asking of these two additional
questions will mean is a real and substantial protective change that is needed … in the interests of justice.
It is relevant to recognise that at the moment many, though certainly not all, screening interviews are being
conducted by telephone during the pandemic. I accept for the purposes of this application for interim relief
… that screening interviews are running on the truncated basis at around 15 to 18 minutes long. I also
accept that were I to make the order that Mr Butler is seeking today, that is, that the entirety of the
screening interview as set out in the Secretary of State's published guidance must be followed, that …
would be likely to double the length of the interview. As is obvious, the imposition of two questions,
questions which are already fully familiar to everyone involved in this process and indeed which appear on
the very form that they currently use within the process, will involve additional time in the interview. I accept
that there will be a knock on effect from that additional time. In my judgement that burden is necessary and
fully justified. Indeed, the fact that it is a substantial change in my judgement is the whole point because it
is an area of inquiry which is of importance in the context of recognising potential victims of trafficking”.

21. I am quite satisfied that there is a proper argument to be made to the effect that it is unlawful for the
Defendant to have had in place a secret policy which went directly against the terms of her published policy
and which directly impeded her in her duty to consider whether asylum seekers have been trafficked en
route to this country. After the interim relief hearing in _DA -v- SSHD conducted by Fordham J, the_
Defendant made a formal admission that her conduct had been unlawful. She later applied to withdraw that
concession. The issue was never adjudicated upon because the parties reached settlement before that
could happen. However, it is conceded in the Defendant's skeleton argument in this case that there is an
arguable case that this was an unlawful policy.

22. It is further arguable that the Claimant has fallen foul of the Defendant's alleged illegality and that the
failure to ask these questions was material in that there is a real possibility that the outcome for the
Claimant would have been different had they been asked. His case was decided when this secret policy
was in place. There is evidence that he came through Libya on his way to France and thereafter the United
Kingdom and that his professed experiences in Libya are consistent with those seen in others who were
subjected to modern slavery in that country. On its face, the case has real strength.

23. I deal with the argument advanced by the Defendant that there is no evidence that the application of
the allegedly unlawful policy resulted in an unlawful decision in this case because there is no evidence that


-----

the asking of the question to this Claimant at this time would have elicited any information which might
have triggered a referral. I do not accept that argument. There is objective evidence that the Claimant was
trafficked. He had injuries consistent with his having been tortured. The medical evidence supports his
claim. An expert has concluded that his account of being trafficked is consistent with the way in which
people are trafficked through Libya. Libya, as identified by Fordham J in _DA, is a country in which such_
things are prevalent. There is no obvious reason why he would not have opened up about it if properly
engaged in conversation about it. That conversation would likely be triggered by the asking of the omitted
questions. I accept the argument of the Claimant that once he was asked properly about his experiences
by Dr McQuaid he gave a full and, in the opinion of the expert Dr McQuaid, credible account of what had
happened to him. There is no reason to think that he would have sought to hide these experiences from
UK officials if given a suitable opportunity to make disclosure about them.

24. The reliance placed by the Defendant on the fact that the Claimant did not reveal his experiences
when asked the direct exploitation question at the screening interview and later at the detention centre is
flawed. I have seen a letter from the Helen Bamber Foundation which sets out a plethora of reasons why
someone in the Claimant's position might be reluctant to make a stark disclosure about what had
happened to them. Were it to be safe to conclude from a failure to disclose evidence of trafficking in
response to a direct question that someone had not been trafficked, the extra indirect question about the
details of the journey would be wholly otiose. The whole interview process is predicated on the basis that
many of those who have been trafficked respond more openly to indirect questions which give them the
opportunity for discourse than to a question which seems to demand an accusatorial answer from them.
(Although it is not the basis of this claim, I am troubled by the fact that in the course of his interview at the
Detention Centre the Claimant made disclosure that he had been the victim of torture. It is surprising that
the simple answer “yes” to that question was not followed up by further enquiries being made of him. Had
that been done, more detail would likely have been given and a referral have been made. Simply advising
him to seek an appointment with health care, while laudable in itself, might be said to have fallen short of
conducting a proper enquiry of the Claimant with a view to protecting him).

25. Nor do I find that the failure of the Claimant to complete the PIQ form is of relevance. It is a 21 page
form. It is in English and will only be accepted if completed in English. The Claimant does not apparently
read English. It has a large number of questions in it. An explanation as to the nature of the form was
apparently given to the Claimant in Arabic, his native language, at the commencement of his screening
interview. That explanation formed a small part of a much lengthier explanation apparently given to him on
how his case was to be handled generally. That oral explanation was not backed up by handing him
anything in writing in his native Arabic to remind him of the purpose of this form. The form has printed on it
a telephone number to be called to speak to someone about it in Arabic. The instructions as to what to do
however are only printed in English. For all these reasons I do not accept that the PIQ form corrects the
defect in the procedure brought about by failing to ask the questions. Nor is the failure to complete it a sign
that the Claimant would not have responded to similar questions being asked in interview. Completion of
that form by him would have required a considerable effort.

26. The failure to disclose to the French authorities can carry little weight. It is apparent from the
Claimant's description of the process in France that he found it bewildering. He appears to have had little
time with his lawyer. There were time pressures on him when he was interviewed. There were
comprehension problems at other times. In any event, if Dr Pouly is correct, the French authorities would
not have acted on any trafficking disclosures and therefore might reasonably be supposed to have had little
interest in providing the Claimant with an opportunity to expand on this aspect of his case.

Interim Relief – the Balance

27. I now consider where the balance of convenience is to be found. To do so, I consider firstly the
consequences to the Claimant were I to refuse interim relief but he succeeded at trial, and then secondly,
the consequences to the Defendant were I to grant relief and the Claimant's case fail at trial.

28. The decision not to grant interim relief would result in the Claimant being left in France. There he
would continue to be homeless and destitute. Although the French authorities have responsibility for those


-----

within their jurisdiction, the Claimant is only in their jurisdiction because of the arguably unlawful acts of the
Defendant. It is no answer for her to say that the effects of her potential illegality should be ameliorated by
the French Government and not by her. The position while he is in France is that there is no pathway to
him obtaining housing through the state or privately. He would receive some but limited support from
charitable institutions. He would be subject to the right of the French Government to remove him at any
time. It is true that I have no evidence of when or if the French authorities intend to remove him but his
position is precarious as he has no right to be in France. Were he to be removed, it would be to Sudan.
There he would run the real risk of being harmed physically or psychologically. The current Home Office
policy is that non-Arab Darfuris cannot safely be returned to Sudan (a policy not apparently applied by the
French authorities). There is a tangible risk that, were this court to refuse interim relief but to grant his
judicial review in the fullness of time, he would be unable to benefit from it. There is a real risk that in this
way justice might be thwarted.

29. The decision to grant interim relief would involve the Defendant using time and effort in bringing the
Claimant back to the United Kingdom and possibly thereafter supporting him. Were the Defendant to
succeed in resisting the judicial review, this money and time would have been unnecessarily spent and
realistically could never be recouped. It is essentially a financial disadvantage that she would suffer. The
Defendant also relies on the fact that if the Claimant is returned to this country, he could not later be
returned to France as we have left the European Union and Dublin III is no longer applicable. I am urged to
say that this means that this is a case in which a grant of interim relief would serve as final relief. I do not
accept that argument. The situation in Sudan is, according to the Defendant in argument, constantly
changing. There is no indication that the Claimant will not be removable in the future were he to be
returned to this country at the present time. Even I am wrong about that therefore I am under a duty to
scrutinise this application with more care, it would not affect my decision as to where the balance was to be
found.

30. In my judgment the balance to be struck between on the one hand a relatively modest financial loss
and on the other a serious risk of permanent injustice and damage to health comes down heavily in favour
of granting the relief sought.

31. I need to address two further matters.

32. The Defendant urged me to say that the balance of convenience should result in my leaving the
Claimant where he is because the French have the same international obligations as does the UK in so far
as people trafficking is concerned. If, as Dr Pouly suggests, the French are not investigating people
trafficking claims such as that of the Claimant, he should be seeking to challenge that policy in France and
not seeking to return to the UK. That is not, in my judgment, a suitable alternative remedy. Its chances of
success are speculative as against there being a good chance of success in this country. There is no
evidence of his having sufficient access to French lawyers to mount such a challenge. The Claimant is
only in France because his trafficking claim was not picked up on while he was in this country.

33. Secondly, the Defendant submits that I should not grant relief at this stage in any event. I was urged
that, were I to reach the conclusions I have done, I should order that this application be adjourned to allow
for it to be heard at the same time as the permission hearing by which time the Defendant could have
served a fuller defence. I am not attracted by that submission. I have a 74 paragraph skeleton argument
from the Defendant. She is most ably represented by counsel who appeared in DA and to whom the issues
are clear. There has been a full hearing conducted in front of me today. The arguments and areas of
dispute are clear. To adjourn would, in the vernacular, be an exercise in kicking the ball into the long grass.
I should do so if I considered that the case could be better presented in the future and the quality of justice
improved thereby but I can see no justification for it on the facts of this case.

The Order

34. I cannot order that the Defendant brings the Claimant back from France. That is not in her gift. What I
can and do order is that she uses her best endeavours to do so. I have been addressed as to the timescale
within which this could be done. The Defendant says that a month is realistic and three weeks is the bare
minimum required The Claimant has referred me to a case in which a far shorter time period was given


-----

over the Christmas period. I have no evidence as to the particular difficulties that this case might involve.
However, having made the decision that interim relief is appropriate, it must be achieved as swiftly as
possible. To ensure that happens I shall order that if within fourteen days of this judgment being published
the Claimant is not back in this country, the Defendant is to file with the court and serve on the Claimant a
statement setting out the efforts made by the Defendant to comply with this order and why his return has
not been achieved. If the Claimant wishes to argue that the efforts made have not been sufficient and seek
further orders or directions, he has liberty to apply to the court on 2 days' notice thereafter. It is then to be
listed as an urgent matter.

35. The parties are to agree the order consequent on this judgment as soon as possible and submit it to
me for approval.

**End of Document**


-----

