# R v MK (also known as D); R v Gega (also known as Maione)

## [2018] EWCA Crim 667, [2019] QB 86, [2018] 3 All ER 566, [2018] 3 WLR 895, [2018] 2 Cr App Rep 210, [2018]
 Crim LR 922, [2018] All ER (D) 10 (Apr)

 Court: Court of Appeal, Criminal Division Judgment Date: 28/03/2018

# Catchwords & Digest

## CRIMINAL LAW - DEFENCES – DEFENCE FOR SLAVERY OR TRAFFICKING VICTIMS WHO COMMIT AN OFFENCE

 Criminal law – Defences. Section 45 of the Modern Slavery Act 2015 did not implicitly require the defendant to bear the legal or persuasive burden of proof of any element of the defence. The Court of Appeal, Criminal Division, held that the burden on a defendant was evidential; it was for the defendant to raise evidence of each of the elements and for the prosecution to disprove one or more of them to the criminal standard in the usual way.

# Cases referring to this case


R v BRP

_[[2023] EWCA Crim 40](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67DB-27J3-RRJW-500Y-00000-00&context=1519360)_
Considered

R v AFU

_[[2023] EWCA Crim 23](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67C3-3093-CGX8-01PV-00000-00&context=1519360)_
Considered

R v AGM

_[[2022] EWCA Crim 920, [2022] All ER (D) 23 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:65W9-2RG3-GXF6-827R-00000-00&context=1519360)_
Considered

R v Brecani

_[[2021] EWCA Crim 731, [2021] 1 WLR 5851, [2021] All ER (D) 62 (May)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:62R7-7X53-GXFD-802D-00000-00&context=1519360)_
Applied


25/01/2023

CACrimD

20/01/2023

CACrimD

05/07/2022

CACrimD

19/05/2021

CACrimD


-----

# Cases considered by this case

R v Makuwa

_[2006] EWCA Crim 175, [2006] 1 WLR 2755, [2006] 2 Cr App Rep 184, (2006) Times,_
[28 April, [2006] All ER (D) 324 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JT01-DYBP-N2J5-00000-00&context=1519360)
Considered

R v Lambert

_[[2001] UKHL 37, [2002] 2 AC 545, [2001] 3 All ER 577, [2001] 3 WLR 206, [2002] 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4HV7-56D0-TWP1-60CD-00000-00&context=1519360)_
_[LRC 584, [2001] 2 Cr App Rep 511, (2001) Times, 6 July, [2001] All ER (D) 69 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5KK4-K7P1-DYJ0-83VP-00000-00&context=1519360)_
Considered

R v DPP, ex p Kebilene

[[2000] 2 AC 326, [1999] 4 All ER 801, [1999] 3 WLR 972, [2000] 1 Cr App Rep 275,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DD5-S260-TWP1-60MP-00000-00&context=1519360)

_[[1999] All ER (D) 1170](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DXH-MH00-TWP1-70RV-00000-00&context=1519360)_
Considered

R v Hunt

[[1987] AC 352, [1987] 1 All ER 1, [1986] 3 WLR 1115, [1987] LRC (Crim) 523](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4S32-G3C0-TWP1-61MM-00000-00&context=1519360)
Considered

R v Edwards

[[1975] QB 27, [1974] 2 All ER 1085, [1974] 3 WLR 285](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KP0-TWP1-618W-00000-00&context=1519360)
Distinguished

Woolmington v DPP

_[[1935] AC 462, [1935] All ER Rep 1, 153 LT 232](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4FPP-FDJ0-TWXJ-20DC-00000-00&context=1519360)_
Applied

**End of Document**


23/02/2006

CACrimD

05/07/2001

HL

28/10/1999

HL

04/12/1986

HL

21/05/1974

CACrimD

23/05/1935

HL


-----

