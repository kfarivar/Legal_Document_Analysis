# R (on the application of EXC) v The Secretary of State for the Home
 Department

_[[2024] EWHC 935 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6BXD-WKM3-RXWN-S4X1-00000-00&context=1519360)_

**Court: Queen's Bench Division (Administrative Court)**
**Judgment Date: 30/04/2024**

# Catchwords & Digest

**_MODERN SLAVERY - SUPPORT SERVICE – TERMINATION OF SUPPORT_**

The Administrative Court granted the claimant permission to challenge a decision taken by the Single
Competent Authority (SCA), on behalf of the defendant, to refuse to allow the claimant to re-enter the
**_Slavery Victim Care Contract (MSVCC) support service following the withdrawal of support while the claimant was_**
in immigration detention. The court was satisfied that the claimant had a good arguable case that he was unlawfully
denied the benefit of support under the MSVCC scheme and that the balance of convenience favoured making an
order that the claimant be reinstated to the scheme, and receive its attendant benefits, pending the resolution of the
case. There was nothing in the statutory guidance issued by the defendant, which suggested that MSVCC support
could be terminated by the SCA solely because a person who had been victim of modern slavery found himself in
immigration detention. On the issue of interim relief, the balance of convenience favoured granting the claimant
continuing support as the benefits of reinstating support outweighed the risks.

# Cases considered by this case


R (on the application of TDT, by his litigation friend Topteagarden) v Secretary of State
for the Home Department (Equality and Human Rights Commission intervening)

_[[2018] EWCA Civ 1395, [2018] 1 WLR 4922, [2018] All ER (D) 38 (Jul)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SRY-G871-DYBP-N073-00000-00&context=1519360)_
Considered

**End of Document**


19/06/2018

CACivD


-----

