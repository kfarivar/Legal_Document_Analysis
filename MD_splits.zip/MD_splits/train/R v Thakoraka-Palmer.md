# R v Thakoraka-Palmer [2023] EWCA Crim 491

Court of Appeal, Criminal Division

Macur LJ, Farbey and Collins Rice JJ

16 May 2023Judgment

**Felicity Gerry KC (instructed by Southwell and Partners) for the Appellant**

**Benjamin Douglas-Jones KC (instructed by the Crown Prosecution Service) for the Respondent**

Hearing date: 20 April 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.30am on 16 May 2023 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

.............................

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

**Lady Justice Macur:**

Introduction:

1. The Registrar of Criminal Appeals refers these applications for an extension of time in which to seek
permission to appeal against the applicant's conviction on 25 May 2017 of being involved in a “ conspiracy
to conceal, disguise, convert or transfer criminal property”, contrary to section 1 of the Criminal Law Act
1977, and to receive 'fresh' evidence of the applicant's status as a victim of trafficking (“VOT”) pursuant to
[section 23 (1)(c) of the Criminal Appeal Act 1968,on the following terms:](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-GVS0-TWPY-Y1P8-00000-00&context=1519360)

“The Prosecution accepts that the applicant should have been identified as a possible credible victim of
human trafficking. The offences predate s45 MSA and the issue is whether, had his status as a VOT been
recognised at the time, a decision would have been taken to prosecute and if so whether such a
prosecution would have been an abuse of process.

The prosecution accepts that he was a VOT and does not object to the Court receiving evidence of the
conclusive grounds decision de bene esse; it does not seek to challenge the applicant's fresh evidence but
maintains that this is not a situation where a prosecution would not or might not have been brought, given
that this was a mature man who had options for avoiding involvement in an offence which took place over a
considerable period of time The dominant force of comp lsion from the trafficking did not e ting ish or


-----

reduce the Applicant's “criminality” or “culpability” to a point at or below which prosecution was not in the
public interest.

[Consequently] the Court should consider whether the nexus between his status as a VOT and the offence
is insufficient[sic] to extinguish his culpability.”

2. Dr Felicity Gerry KC represented the applicant. She seeks to widen the ambit of the Registrar's
reference in terms:

“The single ground of appeal is that Mr Thakor's conviction is unsafe because his conduct was compelled
as a victim of human trafficking and his status as a victim of such exploitation at the time should have been
identified and by not doing so his rights under Article 4 of the Anti-Trafficking Convention were
extinguished and can be recognised by quashing his conviction.”

3.  Further, if we reject the application for permission to appeal conviction, she seeks extension of time for
permission to appeal against sentence already served to a term below that which renders the applicant
liable for automatic consideration for deportation.

4. Mr Benjamin Douglas-Jones KC appeared for the respondent. We note at the outset that although the
prosecution acknowledge that the applicant should have been identified as a possible credible victim of
human trafficking ('VOT') the respondent does challenge many of the applicant's assertions of fact which
form the foundation of the documentary 'fresh' evidence.

5. Neither Counsel appeared in the criminal trial.

The Trial:

6. The applicant was charged with nine others in relation to money laundering. Two of his co-accused,
Bhadresh SHAH (BS) and Abhishek SHAH(AS) absconded on the fifth day of trial. They both remain at
large. The prosecution described them as the heads of a professional money laundering team, which was
run under the guise of a sham money transfer business. The applicant now accuses them of being his
'controllers'.

7. The applicant was represented by leading and junior counsel. He gave evidence. His case was that he
first met BS in 2010; he went to live at BS's home address and was treated like a son. Subsequently he
worked for BS as courier. He knew that some of the parcels contained money, but he did not think that he
was doing anything illegal. He trusted BS. He was of previous good character.

8. He was convicted, nevertheless, as were BS and AS and two others.  Five of the co-accused were
acquitted.

The facts in summary:

9. In excess of £80 million passed through three money transfer businesses, namely ANZ Global Ltd,
Oaklands Courier Ltd and Durga Enterprises Ltd, which operated in Northwest London during the period 1
September 2011 to 22 April 2014. Many transactions were bogus. The Prosecution case was that the
money was primarily linked to the sale of drugs.

10. Large sums of money were found in the attic or under the floorboards of addresses which included the
SHAHs' home address at Flat 87 and Flat 87A Swinderby Road, where the applicant lived during the
relevant time, and property belonging to Bhanuben PATEL in Harrow Road and an address at 51 Union
Road.

11. In addition, the applicant was directly involved in the collection of two large sums of cash from
unknown individuals in Merseyside and Windsor. On 17 March 2014 the applicant was a passenger in a
vehicle driven by AS from  London to Merseyside. The police stopped the car and found £78,000 and
128,000 Indian rupiah. The applicant had three mobile phones and the bag containing the cash had the
applicant's DNA on it. He was arrested and interviewed. The applicant denied any knowledge of what was
happening and said that he was paid £20 to accompany his co-accused. On 11 April 2014 the applicant


-----

was driven to Windsor. He met an unknown man who passed him a bag which was found to contain
£100,110 cash.

12. On 7 April the applicant was seen to move money with BS between Swinderby Road and the
Chandani Bazaar. On 10 April 2014 the applicant was seen to move money with another co-accused
between Union Road and the Chandani Bazaar.

13. In addition, the applicant had 'witnessed' the tenancy agreement relating to Harrow Road and his
fingerprints were on a set of scales found at Union Road, where drugs had also been found. Police also
found 'letters of authority' entitling him to do business on behalf of two of the 'front' companies.

14. The applicant was described by the Prosecution as a trusted 'lieutenant' based at the centre of the
operations at the Chandi Bazaar on an almost daily basis. He took bags of cash to and from the locked
Unit 10 and delivered cash to the safe houses used by the gang.

Sentence:

15. The trial judge described the amount of money laundered as “quite staggering”. The offences had
been committed over a sustained period across international borders. He reminded himself that "Money
laundering is an integral component of much serious criminality” (Sentencing Council Guideline p 36) and
was satisfied that the money was predominantly associated with the sale of drugs.

16. BS was identified as in a leading role who “involved others through pressure and influence”, taking
advantage of their “gullibility”. The pressure he exerted was not only as head of the family, but as a widely
respected member of the community.

17. AS was also identified as being in a leading role, although less culpable than his father. He had been
the prime mover in the March Merseyside trip which involved the applicant, and also another co-accused
who was acquitted by the jury.

18. The applicant had been at the top of the conspiracy for a relatively short time. Counsel for the
applicant submitted that the applicant's vulnerability was exploited, but the judge was “not sure that that is
entirely correct to say, because the reality is that he lived at 87, Swinderby Road for a while. He knew what
was going on. He was treated as one of the family, and so I am satisfied that from a fairly early stage, not
only did he know what was going on, but he was trusted as part of the conspiracy. … He and [AS] were
regarded as trusted assistants ... …I accept that to some extent; he has been exploited. … In one sense,
his culpability is slightly greater than that of [another convicted co-accused], … they are both men of
previous good character. … I think that to make the sentence on [the applicant] too close to that of the
sentence on [AS] would not reflect my view as to the proper level of culpability between them. That said,
this was serious offending, and it must be met by an appropriate sentence. Making the sentence in his
case as lenient as I possibly can, the sentence will be one of five years' imprisonment.”

Victim of trafficking:

19. On 16 December 2017, following conviction and sentence, the applicant was served with a notice of
deportation. On 9 January 2018 the Home Office received the applicant's response stating a fear of
persecution if he returned to India because of his debt and change of religion (from Hindu to Muslim).

20. The applicant was interviewed on two occasions in August 2018 whilst serving his sentence. On 4
September 2018 he was served with a “section 72” letter inviting him to rebut the presumption that he had
been convicted of a serious crime and constituted a danger to society. The applicant responded on 7
September 2018 stating, “I did not have the skills, means, network or knowledge to organize and facilitate
this crime on my own nor was I aware of the true nature of the job until after my arrest”. The applicant
made a “protection and human rights claim”.

21. On 24 October 2018, the applicant was referred as a potential adult victim of trafficking via the
National Referral Mechanism (“NRM”). On 9 November 2018, the Competent Authority (“CA”) found there
were reasonable grounds to believe that the applicant had been the victim of **_modern slavery (human_**


-----

trafficking), confirmed in a conclusive grounds decision on 15 January 2019 but he was not granted leave
to remain on that basis.

22.  On 21 May 2019, the Applicant's application for asylum was refused and a deportation order made on
2 June 2019. On 22 November 2019 he was detained under immigration powers.

23. On 23 January 2020, the applicant was assessed by immigration removal centre medical practitioner,
Dr Iman Sayed who reported concerns that he may have been the victim of torture. The applicant said that
he had been attacked in Ahmedabad, India by people to whom his father owed money. His thighs were
burned with iron rods. The doctor observed “scars which may be due to the history given” and that the
applicant was suffering from depression, anxiety, flashbacks, paranoia, and insomnia. His condition had
worsened since being in detention.

24.  On 27 January 2020, a Rule 35 Response found that “the negative factors outweigh the risks” in the
applicant's circumstances and his detention was maintained.

25. On 12 March 2020 the applicant instructed his present solicitors, who then sought relevant documents
and legal aid funding.

26. On 3 March 2022 his solicitor, Ms Southwell, filed a 'Gogana' statement in support of the application to
rely on fresh evidence, namely the applicant's witness statement and exhibits, “trafficking documents”
which included a positive conclusive grounds decision from the CA, “immigration papers” and “medical
documents”.

27.  Application for permission to appeal was lodged on 7 March 2022.

The applications:

28. On 23 November 2022 the full Court gave directions setting down the applications for hearing
including that the 'McCook procedure' should be followed. Responses have been received from leading
counsel and trial solicitors, including the applicant's proof of evidence and explanation of a signed 'waiver'
in which the applicant concedes that his allegation, when giving evidence before the jury, that his legal
representatives had misrepresented his instructions in his 'defence statement' was inaccurate. Neither
counsel nor solicitor have been required to attend the hearing for the purpose of cross examination by the
applicant.

29. Subsequently, and it appears prompted by a judicial comment made during the directions hearing, the
applicant has submitted a further witness statement upon which he seeks to rely.

30. The respondent seeks to rely on fresh evidence from the officer in the case, DS Gunn, exhibiting
surveillance photographs taken during the investigation, custody records, HMRC records and extracts of
evidence led during the criminal trial.

31. We considered the 'fresh' evidence filed on behalf of the applicant and the respondent de benne esse.

32. We regarded the documentary evidence upon which the applicant sought to rely to be unsatisfactory in
several regards. The decisions, diagnoses, and basis of immigration applications revealed in the
conclusive grounds' decision, the medical reports and immigration files are dependent upon the applicant's
unchallenged self-reporting. They contain significant inconsistencies and omissions which could not
objectively and realistically be described as naturally arising in a trafficked victim's evolving story as they
gain confidence in the safety of their surroundings. The applicant's account of his living conditions after
arrival in the UK is contradicted by contemporaneous documentation including HMRC tax records, utility
and mobile phone bills, bank statements, tenancy agreements, a car registration document, photographs
taken during the police investigation, surveillance information and 'agreed facts' made during trial. The
scant medical evidence of the physical scarring above his knees apart, the applicant's contemporaneous
accounts of his low mood and insomnia leading to diagnoses of depression and PTSD post-date his
incarceration. Consequently, we regarded it to be necessary for the applicant to give evidence in
accordance with the directions of the full Court.


-----

33. We unhesitatingly rejected Dr Gerry's written submission that “cross examination of this Applicant is an
additional cruelty” and that “no adversarial system of questioning in less than a day should be allowed to
undermine the credible evidence that the Applicant is and was a trafficked person _suffering long term_
_traumatic effects of the conduct of Shah and his family”. There is no evidential basis for either submission._

34. The applicant and DS Gunn gave live evidence. The hearing was held in camera.

Submissions:

35. Dr Gerry argues that the applicant was failed by police, prosecutor, defence solicitors and counsel and
the trial judge. The applicant was clearly a VOT acting under the direction of BS at the time of the
offending. There was credible evidence of the applicant's relevant exploitation prior to his referral to the
NRM; “the police saw his living conditions and must have been aware of his vulnerability.” The
investigating officer, DS Gunn, had rebuffed the applicant's e mail contact prior to trial and also failed to
inform the applicant's legal team of the communication which would have prompted a referral to the NRM.
It is clear from the mitigation advanced that the applicant's solicitor and counsel knew of his vulnerability,
although it is also asserted that the applicant was subject to “duress and efforts to pervert the course of
justice by [BS]. He was frightened that if he told his situation to his solicitors and counsel his complaint
would leak to [BS] and he and his family would be in serious danger.” The trial judge accepted that the
applicant was vulnerable but did not adjourn sentence for a referral to take place to the NRM. The decision
to uphold the decision to charge and prosecute the applicant runs counter to CPS policy. Upon a
retrospective examination of the evidence, and in the context of the subsequent conclusive grounds'
decision and medical evidence, it is clear that the evidential burden and/or public interest burden are not
met. The applicant's rights pursuant to Article 4 of the Anti-Trafficking Convention were “extinguished” by
the failure to recognise him as a VOT and the breach may only be remedied by the quashing of his
conviction.

36. Further, and in any event, there is no requirement within international Treaty Conventions that he was
acting under “compulsion”.

37. Mr Douglas-Jones acknowledges that the applicant should have been identified as a possible credible
victim of human trafficking ('VOT') but submits that there are clear reasons why the Court should depart
from the CA's conclusive grounds decision. The CPS guidance recognises that “trafficking” does not
require movement of people and that the means by which a person may find themselves in a 'position of
vulnerability' and subject to exploitation of criminal activities is not closed. "Compulsion" includes all the
means of trafficking defined by the United Nations Protocol on Trafficking (The United Nations Convention
against Transnational Organised Crime 2000 supplemented by the Protocol to Prevent, Suppress and
Punish Trafficking in Persons): which includes inducement, abuse of power or of a position of vulnerability,
or use of debt bondage. In considering whether a trafficking/slavery victim has been compelled to commit a
crime, a prosecutor must consider whether any of these means has been employed so that the victim has
effectively lost the ability to consent or to act with free will. It does not require physical force or constraint.

38.  Regardless of the applicant's VOT status, this is not a case which the CPS “would or might well have
not prosecuted” the applicant; there was no credible evidence of duress or reasonable basis to assess that
the applicant's criminality/culpability was extinguished or significantly diminished to the point that a
prosecution would not be in the public interest. There was no abuse of process in maintaining the
prosecution. This was a serious, enduring, course of offending in the context of a serious offence. The
applicant was a mature man who had options to avoid and remove himself from the criminal activity.

Findings and Discussion:

39. The relevant principles of law which arise in applications concerning convictions pre-July 2015 are well
settled by previous authorities and conveniently summarised in R v S(G) [2019] 1 Cr. App. R 7 at [76] and
see R v AAD (& others) [2022] 1 Cr. App. R 19 at [142]. We need not repeat them here.

40. We reject Dr Gerry's suggestion that the authorities were wrongly decided in that they fail to recognise
that “compulsion” is not identified in International Treaties concerned with the protection of VOT from


-----

criminal prosecution. This is tantamount to suggesting that there is a blanket immunity from prosecution for
VOT's and simply ignores Article 8 of the European Union Directive 2011/36 on preventing and combatting
trafficking in human beings which provides that:

"Non-prosecution or non-application of penalties to the victim

Member States shall, in accordance with the basic principles of their legal systems, take the necessary
measures to ensure that competent national authorities are entitled not to prosecute or impose penalties
on victims of trafficking in human beings for their involvement in criminal activities which they have been
_compelled to commit as a direct consequence of being subjected to any of the acts referred to in Article 2."_
(emphasis provided)

Articles 2, (which identifies “a position of vulnerability”), and 8 were, at the material time, incorporated
within the CPS Guidance on non-prosecution of the victims of slavery or trafficking.

41. We find Dr Gerry's submission on the 'restoration' of the applicant's Article 4 'rights' to be
misconceived. (See also LM & Ors _[2010] EWCA Crim 2327 at [32].) The focus of this Court is upon the_
safety of the applicant's conviction. Consequently, we are required to review the respondent's decision to
oppose the extant application for permission to appeal on the basis of its retrospective review of the
evidence and assessment of the public interest in prosecution of the applicant whom they accept to be a
VOT.

42. The relevant CPS Guidance calls for a three-stage approach to the prosecution decision in addition to
applying the Full Code Test:

1. is there a reason to believe that the person is a victim of trafficking or slavery? if so,

2. if there is clear evidence of a credible common law defence of duress, the case should be discontinued
on evidential grounds; but

3. even where there is no clear evidence of duress, but the offence may have been committed as a result
of compulsion arising from the person's trafficking or slavery situation, prosecutors should consider
whether the public interest lies in proceeding to prosecute or not.

…

In considering whether a [VOT] has been compelled to commit a crime, prosecutors should consider
whether [by means of threats, use of force, fraud and deception, inducement, abuse of power or of a
position of vulnerability, or use of debt bondage, not necessarily requiring physical force or constraint] the
victim has effectively lost the ability to consent to his / her actions or to act with free will.

…

In assessing whether the victim was compelled to commit the offence, prosecutors should consider
whether: the offence committed was a direct consequence of, or in the course of trafficking/slavery and
whether the criminality is significantly diminished or effectively extinguished because no realistic alternative
was available but to comply with the dominant force of another.

Where a victim has been compelled to commit the offence, but not to a degree where duress is made out,
it will generally not be in the public interest to prosecute unless the offence is serious or there are other
aggravating factors.

43. It is unnecessary to admit the fresh evidence for the purpose of establishing the applicant's status as a
VOT. The prosecution has proceeded to review its decision on the basis that the applicant is a VOT.

44. Duress is available as a defence if the offence has been committed as the direct result of a threat of
death or serious injury aimed at the defendant or someone sufficiently close to him. But the defence is not
established if there was evasive action which the defendant could reasonably be expected to take,
including report to the authorities, and nor can it be established if the defendant has voluntarily associated
with people in circumstances which amount to laying himself open to the compulsion to commit offences.


-----

45. We note the reference in the medical records in June 2018 to the applicant's report that his family had
received death threats in the past and more recently a letter containing death threats had been pushed
through his parents' door, but the applicant considered and hoped it may have been “a sick joke”. Further,
he stated that the threats had been reported to the police. These entries do not support any realistic claim
of duress.

46. Further, we reject the applicant's accounts which deny his voluntary association with the Shah family
as implausible. We found the applicant to be an unreliable historian and his evidence implausible in almost
all respects. In summary we note:

(i) There are utility bills in relation to addresses where the applicant undoubtedly has resided and mobile
telephones which he possessed, and bank accounts in his name into which modest amounts were
deposited and withdrawn. We note that the applicant was employed legitimately upon his first arrival in the
UK; he obtained work through an employment agency, was assigned a National Insurance number and
paid income tax. The applicant's explanations to account for the existence of these documents as the result
of identity theft by his 'controllers' is unbelievable.

(ii) The applicant appears in surveillance photographs as well- dressed, well-groomed, and well-equipped
with expensive electronic equipment, in circumstances inherently contradictory of being a virtual prisoner
and under constant surveillance, isolated from others who may offer him aid and the subject of physical
and emotional abuse in deprivation of food and adequate sleeping arrangements. The applicant's
explanation that his outward and kempt appearance was part of an elaborate 'front' erected by the Shah
family is unbelievable.

(iii) The applicant claims that BS actively encouraged and facilitated the application to legitimise his, the
applicant's, residence in the UK. It would be unlikely that he would do so if he wished to maintain 'control'
over the applicant. The applicant's evidence on this issue is unbelievable.

(iv) In e mails dated 29 November 2016 and 1 December 2016 to DS Gunn, the applicant offered to give
“important information” to help strengthen the police case, and to meet with DS Gunn or the team “any day
or time and any place”. The e mails were sent from the account of Jinali Shah, the daughter of BS. The
applicant's explanation of why Jinali Shah, whom he maintained he had met on only two occasions when
she brought food to his room, would assist him to potentially inculpate her mother and father bordered on
the farcical.

(v) The applicant accepts that BS would refer to the applicant as the partner of Jinali. Her name was
added to the prisoner visitor list by applicant.

These facts corroborate the applicant's evidence at trial that he came to know the Shah family in 2010 and
was treated as a member of the family. (See [7] above). We are satisfied that the defence of duress was
not realistically open to the applicant.

47. These same considerations would also be pertinent to the prosecution's consideration of the evidence
regarding the applicant's claim of compulsion falling short of duress and his reduced culpability. We have
regard to the medical evidence regarding the scarring above the applicant's knees, and the diagnosis of
PTSD, but we are not satisfied that this undermines the thrust of the evidence which we list above. Taking
the most generous view of the evidence that the applicant seeks to rely upon, we are satisfied that the
prosecution would be entitled to regard there to be no, or no sufficient, nexus between the trafficking of the
applicant and the commission of the offence to indicate that a prosecution would not be in the public
interest.

48. We accept the trial judge's description of the offence as “serious criminality” in “staggering amounts”
and committed over international borders. The jury rejected the applicant's evidence that he was an
unknowing participant in the conspiracy. The judge adjudicated him to be in a significant role albeit
vulnerable to the influence of BS. There is no reliable fresh evidence which gives a reason to invalidate this
assessment. It cannot be realistically argued that there could be no public interest in prosecuting the
applicant for such an offence.


-----

49. In conclusion, we do not regard it to be necessary or expedient in the interests of justice to admit the
fresh evidence. We are satisfied that the prosecution has conscientiously reviewed the decision to
prosecute the applicant in the light of the available and reliable evidence regarding his trafficked status.
There is no abuse of process in their opposition to these applications. There is no other reason to
challenge the safety of the applicant's conviction. We refuse permission.

50. The application for permission to appeal sentence is also refused. The judge appropriately reduced the
sentence to reflect the applicant's 'vulnerability'. The adverse consequences of the length of his sentence
as regards immigration proceedings is not a proper consideration for the criminal court.

Postscript

51. The hearing of these applications was listed in camera and anonymously pending outcome of the
hearing. We invited written submissions on the question of anonymity after distribution of the draft
judgment. The applicant maintains his submission that he and his family are at risk from his traffickers who
are 'at large'.

52. We are sceptical of this claim for the reasons we give in this judgment.

53. We are satisfied that anonymity is not “strictly necessary” and that the principle of open justice
prevails. (See R v ADD _[[2022] EWCA Crim 106 [3] and [4].) This case should therefore be listed under the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_
applicant's name and revoke the previous reporting restrictions.

**End of Document**


-----

