# R (on the application of AC (Algeria)) v Secretary of State for the Home
 Department [2019] EWHC 188 (Admin)

Queen's Bench Division, Administrative Court (London)

Johnson QC, (Sitting as a Deputy Judge of the High Court)

6 February 2019Judgment

**John Walsh (instructed by Turpin & Miller LLP) for the Claimant**

**Jennifer Gray (instructed by Government Legal Department) for the Defendant**

JUDGMENT APPROVED BY THE COURT FOR HANDING DOWN (SUBJECT TO EDITORIAL CORRECTIONS)

I DIRECT THAT PURSUANT TO CPR PD 39A PARA 6.1 NO OFFICIAL SHORTHAND NOTE SHALL BE
TAKEN OF THIS JUDGMENT AND THAT COPIES OF THIS VERSION AS HANDED DOWN MAY BE TREATED
AS AUTHENTIC.

JOHNSON QC:

6. The Claimant was further interviewed in October and November 2016. He maintained his account that he was
Syrian. By this point it had been established that the Claimant had claimed asylum in Switzerland and had been
recorded as an Algerian national. Arrangements were made to interview the Claimant in order to determine his
nationality. This was done in February 2017. An assessment was made that the Claimant was not Syrian and was
more likely to be Tunisian or Algerian. Nothing of substance was then done in relation to the asylum claim until late
2017.

7. In December 2017 the Claimant was further interviewed in order to establish whether he might be at risk due to
his sexuality. On 21 December 2017 a language analysis interview was conducted in order to determine the
Claimant's nationality. He failed to engage with that interview.

8. On 31 January 2018 the Claimant was interviewed about his identity. By this time he was being detained under
immigration powers. He now accepted that he had given a false name and had lied about his nationality. He did not,
however, cooperate with further questioning and the interview was suspended. He instructed solicitors. On 12
February 2018 they wrote to the Secretary of State to say that the Claimant was willing to cooperate, that he was an
Algerian national, and asking that his asylum claim be progressed. The Claimant was then interviewed further in
May 2018. He admitted that he had previously lied about being Syrian. He said that he was Algerian, that he had
been sexually abused from an early age, and that he had been held as a captive sex slave for six years.

9. The Claimant's account raised a question as to whether he was a victim of modern slavery. A further interview
was arranged so that his account could be clarified with a view to deciding whether to refer him to the NRM. This
further interview took place on 13 June 2018.

10. In the light of the account given by the Claimant in this interview (which included an allegation that he had been
sold for sex over a period of years but that he was not usually physically restrained) the Secretary of State decided
that a further interview was required to assess what were said to be discrepancies in the Claimant's account, and to
decide whether to make a NRM referral. This interview took place on 24 July 2018. The Claimant again said that he
had been sold for sex He said that he stood by his previous accounts He added:


-----

“I was being used as a prostitute, I was never paid. The money went to [name given], to him and to his
gangs.”

11. Following this interview it was decided that there was insufficient information to refer the Claimant's case to the
NRM.

12. On 2 October 2018 the Secretary of State refused the Claimant's asylum claim and made a deportation order.
He certified the applicability of the presumptions under s72(2) Nationality, Immigration and Asylum Act 2002,
namely that the Claimant had been convicted by a final judgment of a particularly serious crime and that he
constituted a danger to the community of the United Kingdom.

13. The Claimant appealed against this decision to the First Tier Tribunal. On 26 November 2018 the appeal was
dismissed. The Judge held that the presumptions under s72(2) of the 2002 Act had not been rebutted:

“I consider that the offences for which he was convicted, although they happened in effect in a single
incident, were very serious indeed as the sentencing remarks of HH Judge Johnson show.”

14. The Judge also rejected the Claimant's factual account that he would be at risk if he were returned to Algeria:

“I assessed this Appellant as being a person who is incapable of telling the truth or giving a consistent
account. His credibility is severely undermined in all material particulars… His account is full of
inconsistencies, which cannot be explained by the change of nationality or age alone.”

15. The Claimant did not bring a further appeal to the Upper Tribunal within the permitted time. He had therefore
exhausted his rights of appeal and there was no statutory bar on his removal from the United Kingdom. He has
subsequently sought to bring an out of time appeal. This application has yet to be determined.

_Detention_

16. On 25 December 2017 the Claimant was due to be released on licence from his custodial sentence. He
continued to be detained under immigration powers.

17. The Claimant's detention has been reviewed at roughly 4-weekly intervals in written “Detention & Case
Progression reviews” (“DCPRs”). At each review continued detention has been authorised, having regard to the risk
of absconding, the risk of re-offending and the prospect of removal. More recently, however, it has been
acknowledged that the Claimant could and should be released to appropriate accommodation.

18. DCPR1 took place on 18 January 2018. Continued detention was authorised for 28 days. It was assessed that
the Claimant was a high risk of absconding:

“[The Claimant] currently has no valid leave to remain in the UK. On entering the UK he made no attempt
to regularise his stay here but instead went on to offend. It was only when he came to the attention of the
Home Office that he claimed asylum. In addition he went on to claim to be a Syrian national to further
prolong his stay here but has made no attempt to comply with the interview process in order to confirm his
nationality. He is aware that the Home Office will consider his deportation from the UK in the event that his
asylum claim is refused and as such there would be no incentive for him to remain in one place and comply
with any reporting restrictions that may be placed on him if he is released.”

19. It was also assessed that he posed a high risk of re-offending and causing harm:

“…consideration has to be given to the fact that he was convicted of a sexual offence and sentenced to a
total sentence of 4 years… He has submitted no evidence to show that he has been rehabilitated by taking
part in any self-help groups or courses to prepare him to be released into the community with members of
the public. He has shown that he is not adverse to using force and intimidation against members of the
public and as such he is considered to pose a serious risk of harm, if the opportunity should arise…

His offender manager has stated…: “[The Claimant] is posing a serious risk of harm and there are multiple
concerns relating to this.”


-----

[The Claimant] has been assessed as a Category 1 / Level 1 MAPPA.”

20. It was noted that the Claimant had an outstanding asylum claim which barred removal, but that he would be
interviewed on 23 January 2018. It was pointed out that a travel document could not be sought until the Claimant's
nationality had been determined. It was considered that there were “no current reasons to suggest that – with
compliance, … removal cannot be effected within a reasonable time.” The reviewing officer decided that the
Claimant should be detained “as the possibility of him absconding is considered to be high and the risk of reoffending outweighs the presumption of release/liberty.”

21. DCPR2 took place on 19 February 2018. This review did not take place within the period of detention authorised
at DCPR1. It therefore appears that there was a period of days when the Claimant's detention had not been
authorised, albeit no point is taken about this by the Claimant. The Claimant's nationality had now been established
enabling work to commence to obtain a travel document:

“…when do we expect an Emergency Travel Document… to be issued.

Now that his nationality has been determined a request for a travel document will be put in progress.”

22. No prognosis was given as to the length of time that it would take to secure a travel document or to effect the
Claimant's removal. As appears below (see paragraph 40) the Secretary of State's expectation is that it takes up to
12 months to secure a travel document for Algeria (meaning, if work started immediately following DCPR2, a travel
document could have been expected by late February 2019). Detention was authorised for a further 28 days.
Notwithstanding the assertion that steps would be put in progress to request a travel document, nothing was done
in that respect for 6 months.

23. On 19 March 2018 a report was written under r35(3) Detention Centre Rules 2001 by the medical practitioner at
IRC Campsfield House (where the Claimant was detained). It referred to the account given by the Claimant and to
visible scarring on his body. It concluded that he may have been a victim of torture. The Secretary of State
considered the report and, on 21 March 2018, decided that the Claimant met Level 2 of his “Adult at Risk” policy but
that it was appropriate to maintain the Claimant's detention having regard to the risk of absconding and reoffending, and the likely timescale for removal. It was said that removal was to be expected “within the next 5
months”. At this point, therefore, the Secretary of State was anticipating that removal would take place by late
August 2018.

24. DCPRs 3, 4, 5 and 6 took place on 19 March 2018, 16 April 2018, 11 May 2017 and 8 June 2018 respectively.
They followed much the same pattern as DCPR 2. It continued to be asserted that removal could be effected within
a reasonable timescale, without any forecast as to when that might be. It continued to be said that a request for a
travel document would be put in progress, without this being done.

25. On 30 July 2018 the notes record the outcome of a case progression panel:

“After considering the evidence from all the information presented on the day, the panel consider that there
are factors which suggest that removal within a reasonable time frame, in the particular circumstance of
this case, may not be possible.

…

Factors in favour of maintain Detention: 4 years for sexual assault, high harm risk

Factors in favour of release: Outstanding asylum claim from 22 June 2016…. No ETD application
submitted, 8-12 months timescale for ETD

Reason for Balance: The panel have recommended a release in this case as there is no prospect of
imminent removal. There are barriers in place which frustrate imminent removal. The barriers are the
Asylum claim raised on 22 June 2016 and no ETD, due to the timescales of this the panel have
recommended a release. To mitigate any risk upon release the panel have recommended appropriate
measures be in place to restrict the risk factors, such as reporting, curfews, approved accommodation or
tagging. As at current there is no prospect of removal the panel have recommended a release


-----

…

Mandated actions: Submit release referral to Strategic Director”

26. DCPR7 took place on 7 July 2018, albeit detention was not authorised until 3 August 2018 (so there appears to
be another, lengthier, period of unauthorised detention).

27. By this point a number of bail applications had been made and either withdrawn or refused, albeit with
indications that if the matter was not progressed then the balance would tilt in favour of a grant of bail. At a bail
hearing on 23 May 2018 the Judge had said:

“…the Respondent must understand that the balance may change if there is further unexplained delay on
his part and he must deal with this matter promptly.”

28. At a bail hearing on 3 July 2018 the Judge said:

“The previous Judge commented on delays and I too am concerned about the speed of progress. I request
the representative to ask the caseworker to review the timescale detailed and see if the process can be
expedited. If the matter is not resolved a decision made in the next 6 weeks full and detailed consideration
would be required by the next Judge with causes for any delay given.”

29. On 3 August 2018 a response to the release recommendation was provided by the Strategic Director:

“This is a difficult case but on balance and given the robust licence conditions I am content to agree with
the recommendation to release under the [suggested] conditions. His removal is not imminent and he has
already been detained for eight months.”

30. In authorising further detention on the same day the authorising officer wrote:

“Since the last review release has been agreed, however we are waiting on Schedule 10 accommodation
before he can go into the public domain. Please keep monitoring the progress of this accommodation. In
the meantime I am satisfied that detention remains proportionate and detention is maintained for an
approved address to be identified. Detention maintained.”

31. On 15 August 2018 an Immigration Judge made an order that the Claimant be released on bail, subject to
provision of schedule 10 support. On the same day the Claimant's solicitors sought an update. On 16 August 2018
the following was recorded:

“My team CCAT will continue best efforts to secure a [suitable] property. However it must be noted that this
is a Level 3 and it will not be easy to provide a suitable property. We cannot guarantee that a property will
be sourced by the deadline given by the IJ. Therefore you need to contact the Reps and respond to this
explaining that we will do our best to source but as the Bail condition states if this does not happen the Bail
will lapse and they will need to reapply. This is due to an extreme lack of suitable properties. We will
continue our best and will document our efforts to source a property urgently. Please respond to the Rep
accordingly.”

The Claimant's solicitor was informed of the position.

32. On 30 August 2018 steps were taken to arrange an interview of the Claimant for the purpose of enabling a
travel document to be obtained. The Claimant completed and returned questionnaires relating to his “bio data”. The
interview did not take place until 3 January 2019.

33. DCPR8 took place on 6 September 2018. The reviewing officer wrote:

“I propose that [the Claimant] remains detained until schedule 10 accommodation has been sourced, as
the risk of him absconding and the risk of re-offending outweighs the presumption of release/liberty.”

34. The authorising officer wrote:


-----

“Accommodation remains the prevention of his release… In the meantime I am satisfied that the above
risks remain current and genuine and relevant progress is being made.”

35. A further case progression meeting took place on 11 September 2018. This time the recommendation was that
the Claimant should continue to be detained. The reasons given were:

“The panel have recommended to maintain detention with mandated actions as there is a prospect of
removal. The asylum decision to be prioritised and served asap. Once concluded dependent on the
outcome of the travel documentation process should be commenced and if obtained removal can take
place.”

36. There was no explicit reference to the previous decision to recommend release, which had been approved by
the Strategic Director.

37. DCPR9 took place on 3 October 2018. It was now said that a travel document had been requested. The
reviewing officer wrote:

“Although his referral for release has been accepted and bail has been agreed in principle[, w]e are unable
to release [the Claimant] as schedule 10 accommodation, to date have not been able to secure a suitable
accommodation. “

38. The authorising officer wrote:

“I am content that steps are being taken to establish an address. In the meantime I authorise detention for
28 days.”

39. DCPR10 took place on 31 October 2018 and the review is in similar terms to DCPR9, save that the asylum
claim had now been rejected so that the only obstacle to removal was the absence of a travel document. The
authorising officer was more senior than had been the case for previous reviews, now an Acting Assistant Director
who wrote, in what Ms Gray recognised as a “tonal difference”:

“This is a highly dangerous individual who has come to the UK and attempted to claim asylum under false
pretences. Our unenviable position is that we have had to investigate his more current claim to have a fear
of return to Algeria, from whence he has latterly claimed to originate, after his claim to be from Syria was
identified as spurious. Well, due process has been done and now we must release because he has been
granted bail by the IAC. I assume that that bail grant remains intact and that we are still attempting to meet
the provisos attached to it in respect of obtaining an address. Please continue to work with CCAT in that
regard…”

40. DCPR11 took place on 7 December 2018. Detention was authorised on 14 December by a Deputy Director.
She accurately observed that the barrier to removal was the absence of a travel document. She said that the
Claimant's lie as to his nationality and identity had “set back the documentation process.” She added:

“It is important that we pin down his nationality and identity and secure evidence sufficient to document him
with the Algerian authorities. This process can take up to 12 months but the timescale will be reduced if we
have strong evidence and if [the Claimant] lobbies the Algerian authorities. … The case progression in this
case needs to accelerate. I authorise a further 28 days detention during this period we need to progress
both the address and documentation issue.”

41. DCPR12 took place on 4 January 2019. The Director of Criminal Casework authorised “continued detention for
a further 28 days pending further work on documentation and an assessment of timescales to removal.”

_Provision of accommodation_

42. Since 3 August 2018 the Secretary of State has been willing to release the Claimant once appropriate
accommodation has been secured.


-----

43. In May 2018 the Claimant had sought accommodation pursuant to paragraph 9 of schedule 10 to the
Immigration Act 2016 (“schedule 10 accommodation”). A form was sent by the caseworker to the probation officer
for completion with a request that it be returned as soon as possible.

44. Following the July 2018 bail hearing it was noted that the schedule 10 accommodation form was still
outstanding, and that the probation officer:

“has stated on a number of occasions that he should not be released so it is likely that she is stalling the
process.”

45. Thereafter the form was returned and on 25 July 2018 authorisation was given to provide the Claimant with
schedule 10 accommodation.

46. A request for accommodation was made to Serco (one of the Secretary of State's accommodation providers) on
the same day. The property requested was a “Level 3” shared room. Serco responded on 1 August 2018 and said
that there was no timescale for the provision of accommodation. On 23 August 2018 it requested a 28 day
extension. On 28 September 2018 the Secretary of State chased up the matter with Serco “as an urgent priority.”

47. On 1 October 2018 the Secretary of State made a further request for accommodation to another third party
property provider. A potential property was identified and the details were sent to the Claimant's probation officer on
8 October 2018. There were extensive delays (and a change to the proposed property) before the probation service
eventually responded on 2 January 2019 (so almost 3 months later) that the property was not suitable. The
Secretary of State then requested a further property. No further property had been identified by the time of the
hearing.

**The legal and policy framework**

_Immigration detention_

48. Paragraph 2(2) of schedule 3 to the Immigration Act 1971 provides a statutory power to detain pending the
making of a deportation order:

“Where notice has been given to a person…. of a decision to make a deportation order against him… he
may be detained under the authority of the Secretary of State pending the making of the deportation order.”

49. Paragraph 2(3) of schedule 3 to the 1971 Act provides a statutory power to detain pending removal after a
deportation order has been made:

“Where a deportation order is in force against any person, he may be detained under the authority of the
Secretary of State pending his removal or departure from the United Kingdom (and if already detained by
virtue of sub-paragraph (1) or (2) above when the order is made, shall continue to be detained unless he is
released on immigration bail under Schedule 10 to the Immigration Act 2016).”

50. The exercise of the power to detain must comply with well established legal rules. These include the “Hardial
_Singh principles” derived from R (Hardial Singh) v Governor of Durham Prison [1984] 1 WLR 704and re-stated by_
Lord Dyson JSC in R (Lumba) v Secretary of State for the Home Department _[2011] UKSC 12; [2012] 1 AC 245 at_

[22]:

HS1: The Secretary of State must intend to deport the person and can only use the power to detain for that
purpose.

HS2: The deportee may only be detained for a period that is reasonable in all the circumstances.

HS3: If, before the expiry of the reasonable period, it becomes apparent that the Secretary of State will not
be able to effect deportation within a reasonable period, he should not seek to exercise the power of
detention.

HS4: The Secretary of State should act with reasonable diligence and expedition to effect removal.


-----

51. The _Hardial Singh rules reflect the requirement that a statutory power must be exercised for the purpose for_
which it is granted, and the fundamental constitutional principle that a person must not be subject to arbitrary
detention. The Court must decide for itself (including by reference to the Hardial Singh rules) whether detention is
lawful, on the basis of the circumstances that pertained at the relevant time and without the benefit of hindsight.

52. The question of what amounts to a “reasonable period” for the purposes of HS2 and HS3 is highly fact sensitive.
In order to apply HS3 it is not necessary to identify a precise time at which, or a precise period within which,
removal will occur, so long as there is a realistic prospect of removal (within a reasonable period of time) – see MH
_v Secretary of State for the Home Department_ _[2010] EWCA Civ 112_ _per Richards LJ at [65] and_ _R (Lumba) v_
_Secretary of State for the Home Department [2012] 1 AC 245per Lord Dyson JSC at [103]._

53. A material public law error (including an unjustified departure from published policy) which bears on and is
relevant to a decision to detain vitiates that decision such that detention based on that decision is unlawful – see
_Lumba at [68]._

54. The Home Office's published policy on immigration detention is set out in Chapter 55 of its Enforcement
Instructions and Guidance (“the detention policy”). This states:

“55.1.1: … there is a presumption in favour of immigration bail and, wherever possible, alternatives to
detention are used…

…

55.1.3: General: Detention must be used sparingly, and for the shortest period necessary…

Criminal casework cases: ….due to the clear imperative to protect the public from harm, the risk of reoffending or absconding should be weighed against the presumption in favour of immigration bail in cases
where the deportation criteria are met. In criminal casework cases concerning foreign national offenders
(FNOs), if detention is indicated, because of the higher likelihood of risk of absconding and harm to the
public on release, it will normally be appropriate to detain as long as there is still a realistic prospect of
removal within a reasonable timescale.

If detention is appropriate, an FNO will be detained until either deportation occurs, the FNO wins their
appeal against deportation…, bail is granted by the Immigration and Asylum Chamber, or it is considered
that Secretary of State immigration bail is appropriate because there are relevant factors which mean
further detention would be unlawful…

…Substantial weight should be given to the risk of further offending or harm to the public indicated by the
subject's criminality. Both the likelihood of the person re-offending, and the seriousness of the harm if the
person does reoffend, must be considered. Where the offence which has triggered deportation is more
serious, the weight which should be given to the risk of further offending or harm to the public is particularly
substantial when balanced against other factors in favour of granting immigration bail.

In cases involving these serious offences, therefore, a decision to grant immigration bail is likely to be the
proper conclusion only when the factors in favour of release are particularly compelling. In practice,
immigration bail is likely to be appropriate only in exceptional cases because of the seriousness of violent,
sexual, drug-related and similar offences. Where a serious offender has dependent children in the UK,
careful consideration must be given not only to the needs such children may have for contact with the
deportee but also to the risk that granting immigration bail might represent to the family and the public. …

… 55.14 Detention for the purpose of removal: In cases where a person is being detained because their
removal is imminent, the lodging of a suspensive appeal, or other legal proceedings that need to be
resolved before removal can proceed, will need to be taken into account in deciding whether continued
detention is appropriate.”

55. The Home Office has also published policy guidance on the approach to be taken to adults at risk in immigration
detention (“the AAR policy”). It has application where a person claims to be a victim of torture such that they might
be vulnerable to harm if they remained in detention. Level 1 applies in the case of a self-declaration of such a risk.


-----

Level 2 is appropriate where there is supporting professional evidence indicating a risk. Level 3 is reserved for
cases where there is supporting professional evidence indicating that detention would be likely to cause harm. The
policy guidance states:

“13. The presumption will be that, once an individual is regarded as being at risk in the terms of this
guidance, they should not be detained. However, any risk factors identified and evidence in support, will
then need to be balanced against any immigration control factors in deciding whether they should be
detained.

14. The immigration factors that will be taken into account are:

    - Length of time in detention – there must be a realistic prospect of removal within a reasonable period.
What is a “reasonable period” will vary according to the type of case but, in all cases, every effort should be
made to ensure that the length of time for which an individual is detained is as short as possible. In any
given case it should be possible to estimate the likely duration of detention required to effect removal. This
will assist in determining the risk of harm to the individual. Because of their normally inherently short
turnaround time, individuals who arrive at the border with no right to enter the UK are likely to be detainable
notwithstanding the other elements of this guidance

     - Public protection issues – consideration will be given to whether the individual raises public protection
concerns by virtue of, for example, criminal history, security risk, decision to deport for the public good

    - Compliance issues - an assessment will be made of the individual's risk of abscond, based on the
previous compliance record.

15. An individual should be detained only if the immigration factors outweigh the risk factors such as to
displace the presumption that individuals at risk should not be detained. This will be a highly case specific
consideration.

16. Consideration must be given to whether there are alternative measures, such as residence or reporting
restrictions, which could be taken to ensure an individual's compliance whilst removal is being planned or
arranged and to reduce to the minimum any period of detention that may be necessary to support that
removal.”

56. By s6(1) Human Rights Act 1998 it is unlawful for the Secretary of State to act in a way which is incompatible
with the right to liberty under Article 5 of the Convention for the Protection of Human Rights and Fundamental
(“ECHR”). That states:

“Everyone has the right to liberty… No one shall be deprived of his liberty save in the following cases and
in accordance with a procedure prescribed by law:

…

(f) the lawful… detention… of a person against whom action is being taken with a view to deportation…”

_Bail and provision of accommodation_

57. Both the Secretary of State and the First-tier Tribunal have power to grant a person bail if that person is being
detained under paragraph 2 of schedule 3 to the Immigration Act 1971 – see paragraphs 1(1) and 1(3) of schedule
10 to the Immigration Act 2016. A person may be granted and may remain on such bail even if that person can no
longer be detained – see paragraph 1(5) of schedule 10 to the 2016 Act.

58. The Secretary of State has power to provide accommodation to those who are granted immigration bail subject
to a condition of residence – see paragraph 9 of schedule 10 to the 2016 Act:

“9 Powers of Secretary of State to enable person to meet bail conditions

(1) Sub-paragraph (2) applies where—

(a) a person is on immigration bail subject to a condition requiring the person to reside at an address
specified in the condition and


-----

(b) the person would not be able to support himself or herself at the address unless the power in subparagraph (2) were exercised.

(2) The Secretary of State may provide, or arrange for the provision of, facilities for the accommodation of
that person at that address.

(3) But the power in sub-paragraph (2) applies only to the extent that the Secretary of State thinks that
there are exceptional circumstances which justify the exercise of the power.

…”

59. The Secretary of State is not under a general duty to provide accommodation under schedule 10 – see (in
respect of the legislative provisions that were replaced by schedule 10) R (Sathanantham) v Home Secretary [2016]
4 WLR 128per Edis J at [70]. However, he must act lawfully when exercising his power under schedule 10. That
involves an obligation to determine applications fairly and rationally. Where the Secretary of State has decided to
provide accommodation under schedule 10, the obligation to determine applications fairly and rationally is, in
practice, materially equivalent to a duty to make reasonable efforts to provide the accommodation – see
_Sathanantham at [69]._

60. The Secretary of State has promulgated policy on “Immigration bail” (“the bail policy”). This states:

“[Foreign national offenders] granted bail whilst still under prison licence will need to have their proposed
bail address approved by HMPPS… The agreed timeframe for HMPPS to consider an address is
approximately 9 weeks. The police and other related partners may also have an interest in approving
addresses for those who are not under licence.

Types of bail accommodation:

There are 3 different levels of bail accommodation as follows:

    - level 1 – initial accommodation – high, multiple-occupancy accommodation…

    - level 2 – standard dispersal accommodation, mostly high multiple-occupancy accommodation…

    - level 3 – complex bail dispersal accommodation, increased liaison with local authorities in sourcing
appropriate accommodation, accommodation provider's staff have specialist training and increased risk
awareness, the authority can request specific location or specify how far the service user should be from
local amenities, schools and so on, lone adult males do not share accommodation with families or lone
females”

_Asylum decision_

61. An application for asylum must be determined within a reasonable period of time – see _R (S) v Secretary of_
_State for the Home Department_ _[2007] EWCA Civ 546_ _per Carnwath LJ at [51] and R (FH and others) v Secretary_
_of State for the Home Department [2007] EWHC 1571 per Collins J at [7]. That does not mean that an application_
must be decided within any particular period of time. The assessment of what is a reasonable length of time will
depend on all the circumstances. That may include any applicable policy, other calls on the Secretary of State's
resources, the extent to which the Claimant is compliant with the decision making process, the complexity of the
claim, the information needed to determine the claim and how readily it can be secured and the extent to which the
Claimant is prejudiced by delay in the determination of his claim (including, for example, whether the delay has the
effect of prolonging detention).

_Protection of potential victims of human trafficking_

62. The Anti-Trafficking Convention (which has been ratified by the United Kingdom) imposes obligations on State
parties to identify and assist victims of human trafficking, meaning (see article 4):

“…the recruitment, transportation, transfer, harbouring or receipt of persons, by means of the threat or use
of force or other forms of coercion, of abduction, of fraud, of deception, of the abuse of power or of a
position of vulnerability or of the giving or receiving of payments or benefits to achieve the consent of a


-----

person having control over another person, for the purpose of exploitation. Exploitation shall include, at a
minimum, the exploitation of the prostitution of others or other forms of sexual exploitation, forced labour or
services, slavery or practices similar to slavery, servitude or the removal of organs”.

63. The Convention does not itself directly give rise to enforceable rights in the domestic courts.

64. In order to discharge the United Kingdom's obligations under the Anti-Trafficking Convention, the Secretary of
State has promulgated policy guidance: “Victims of Modern Slavery – Competent Authority Guidance (2016)” and
“Victims of Modern Slavery – Frontline Staff Guidance (2016).”

65. This guidance requires “first responders” (including the Home Office) to refer anyone identified as “a potential
victim of trafficking” to a “competent authority” which is then responsible, in the first instance, for making an
assessment of whether there are reasonable grounds to believe that the person is a victim of trafficking – the
“reasonable grounds” decision. A decision that there are such reasonable grounds then gives rise to further steps
including an assessment of whether the person is, in fact, a victim of trafficking.

66. The threshold for referral of a person as a “potential victim” is very low. That is clear both from the language of
“potential victim” and from the fact that the decision that falls to be made on referral is whether there are reasonable
grounds to believe that the person is a victim of trafficking, itself a low threshold. In Secretary of State for the Home
_Department v H_ _[[2016] EWCA Civ 565 at [36] Burnett LJ referred to the threshold for referral as “in reality, any](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5K28-G3W1-F0JY-C53G-00000-00&context=1519360)_
suspicion or any claim”.

67. An unjustified failure to comply with the obligation to refer a case for assessment may be challenged by way of
judicial review – see _R (TDT (Vietnam)) v Secretary of State for the Home Department_ _[2018] EWCA Civ 1395_

[2018] 1 WLR 4922per Underhill LJ at [25].

68. The fact that a person has been referred for a “reasonable grounds” decision does not preclude continued
detention. That is clear from the relevant policy documentation in relation to detention and referral to the NRM, and
see XLY v Secretary of State for the Home Department _[2017] EWHC 773 (Admin)_ _per Jonathan Swift QC (sitting_
as a Deputy Judge) at [25].

**Ground 1: Detention**

_Submissions_

69. Mr Walsh, for the Claimant, adopting a helpful skeleton argument prepared by Ranjiv Khubber, argues that the
Claimant's detention has been unlawful since 3 July 2018 (when concern was expressed about progress) or 15
August 2018 (when bail “in principle” was granted) and that it continues to be unlawful. He relies on HS2, HS3,
HS4, breach of the Secretary of State's published policy, and breach of Article 5 ECHR. He says that it ought to
have been appreciated that deportation could not be effected within a reasonable period of time having regard to
the lengthy and unexplained delays in resolving the asylum claim (themselves reflecting a failure to exercise
diligence), the prohibition of removal whilst the asylum claim (and any appeal) was outstanding, and the concerns
expressed by the Tribunal as to the ongoing delay culminating in the grant of bail “in principle”. He accepts that the
risks of absconding and re-offending are relevant matters, but contends that the latter is of “limited relevance”
because it would not in itself inhibit deportation. Once a decision was made to release to appropriate
accommodation Mr Walsh says that the Secretary of State was entitled to a “grace period” to effect release, but this
was short rather than lengthy or indefinite and that reliance on the lack of accommodation reflected a breach of HS2
and HS3.

70. The Claimant also contends that there has been a breach of the Secretary of State's detention policy only to
use detention sparingly and in a way that gives proper respect to the presumption against detention and takes
account of barriers to removal (see paragraphs 55.1.1, 55.1.3 and 55.14 of the detention policy).

71. Ms Gray, for the Secretary of State, submits that the Claimant has been lawfully detained throughout. His
detention was justified under paragraph 2(2) (and then 2(3)) of schedule 3 to the Immigration Act 1971. Having


-----

regard to the Claimant's high risk of absconding and re-offending, there has been a sufficient prospect of removal
within a reasonable time and his detention has at all times been compatible with the Hardial Singh principles, the
detention and AAR policies, and Article 5 ECHR.

_Discussion_

72. Risk posed by the Claimant: The risks of absconding and re-offending are of “paramount importance” when
considering whether detention is justified – see Lumba at [121] per Lord Dyson JSC.

73. The Claimant's underlying offence does not, in itself, justify continued detention under immigration powers:
there is no general power of preventative detention under the 1971 Act. It is, however, relevant to the risk posed by
the Claimant of absconding and to the risk of him committing further offences. These risks inform an assessment of
whether the Secretary of State's policy presumptions in favour of liberty are sufficiently outweighed so as to justify
detention pending deportation. They also inform an assessment of when, if at all, the period of time for which the
Claimant has been detained has become unreasonably long, and also the conditions under which it might be
appropriate to release on bail.

74. The Claimant committed a serious and sustained sexual assault against a woman who was a stranger to him.
There is no evidence that the risk he poses has reduced since he committed this offence. An OASys Assessment
records that:

“[The Claimant] poses a risk of serious harm to members of the general public; lone, vulnerable women…

…

The nature of risk posed to lone vulnerable females is sexual assault and sexual penetration causing both
physical, emotional and psychological harm. …

…

[The Claimant's] risk is likely to be greatest if he were to be housed in close proximity to clubs and bars, or
places where young female adults are likely to frequent.

…”

75. It assessed that there was a medium risk of serious harm, meaning:

“there are identifiable indicators of risk of serious harm. The offender has the potential to cause serious
harm but is unlikely to do so unless there is a change in circumstances, for example failure to take
medication, loss of accommodation, relationship breakdown, drug or alcohol misuse.”

76. Mr Walsh contrasts the Secretary of State's assessment that the Claimant is a high risk, with the OASsys
assessment that he poses a medium risk. I do not detect any material inconsistency. The Secretary of State was
assessing the risk of harm generally, whereas the OAsys assessment was considering the risk of serious harm. An
assessment of a high risk of harm seems to me to be entirely consistent with an assessment of a medium risk of
serious harm. In the latter case the level of risk depends on the likelihood of serious harm. In the former case the
level of risk encapsulates both the likelihood of harm materialising and the nature of that harm. It is that second
factor which pushes the risk from medium to high.

77. More important than the precise calibration of the level of risk for different purposes by different public officials
and no doubt according to different criteria is the Court's factual assessment, in the light of the material available to
the Secretary of State, as to what would be likely to occur if the Claimant were not detained.

78. The Claimant arrived in the United Kingdom unlawfully, having previously claimed asylum in Switzerland. He did
not claim asylum on arrival in the United Kingdom. Nor did he do so in the period between his arrival in 2013 and
June 2016. He only claimed asylum when served with notice of a decision to make a deportation order, a response
understandably castigated as “opportunistic” by Ms Gray. He gave a dishonest account as to his identity and
nationality (which was fundamental to his asylum claim) and maintained his attempted deception over a number of
th l t b d it h it l th t hi t ld t b t d


-----

79. Mr Walsh argues that the risk posed by the Claimant of absconding and re-offending is reduced by the fact that
it was in his interests to comply with the process so as to secure a favourable decision on his asylum application.
There are cases where there is force in such a submission. This is not one of them. The Claimant's own conduct
shows that he poses a significant risk both of absconding and re-offending.

80. Mr Walsh argues that the risk of re-offending is of limited relevance. He relies on the following observations of
Jay J in AXD v Home Office [2016] EWHC 113 at [180]- [181]:

“180 At this stage, it is convenient to consider the saliency of the absconding and reoffending risk, because
it has generated differences of emphasis at Court of Appeal level. If there is simply no prospect of removal
within a reasonable time, it seems to me that these risks are irrelevant. However, many cases occupy a
grey area, and to my mind the concept of “sufficient prospect” must to some extent be a flexible one,
accommodating all the circumstances of the case, including the absconding risk. …these cases are all
heavily fact-sensitive, and in due course it will be necessary to quantify the risks and to weigh them in the
balance against everything else.

181. The absconding risk is important because a former detainee who absconds will be frustrating the
public interest in favour of his deportation. The risk of reoffending is relevant but it must be less important,
because the purpose of immigration detention is not to provide indirect facilitation to the separate policies
and objects of the criminal law.”

81. I do not consider that these observations support Mr Walsh's submission. Jay J was there considering the
relative importance of the risks of absconding and re-offending, rather than their qualitative relevance. He was
doing so in the particular context of what might amount to a sufficient prospect of removal for the purpose of HS3. In
particular, he was addressing whether risks of absconding/re-offending are relevant when assessing the “grey”
question of the sufficiency of a prospect of removal. He was not making a general observation that the risk of
offending had limited relevance to the question of whether detention could be justified. That would be inconsistent
with the conclusion of Lord Dyson JSC in _Lumba (at [121]) that the risk of re-offending is of “paramount_
importance”. Jay J had cited the relevant extract from Lumba immediately before his observations at [180]-[181].

82. I do not therefore accept the submission that the risk of re-offending is of limited relevance to the question of
whether detention can be justified. Re-offending thwarts the very purpose that underpins deportation (broadly, in
this context, public protection). It also potentially delays deportation whilst the criminal justice process takes its
course.

83. In the particular circumstances of this case, for the reasons I have given, the Claimant posed a significant risk of
absconding and re-offending.

84. June 2016 – December 2017: During this period the Claimant was serving his sentence of imprisonment. No
question of unlawful detention arises. It is, however, relevant that the Secretary of State began consideration of the
Claimant's case, serving notice of a decision to make a deportation order, 18 months before his release date. The
Claimant failed to cooperate. He responded by making a claim for asylum based on a dishonest account as to his
nationality. If he had cooperated and given a truthful account from the outset then that would have significantly
reduced the amount of time required to determine his asylum claim and to obtain a travel document. Much, possibly
all, of the work to determine any asylum claim, and to secure a travel document, could have been done during the
operative part of the Claimant's custodial sentence.

85. December 2017 – February 2018: The Claimant's detention was authorised in advance of the date for his
release from custody (25 December 2017). The decision to detain was lawful. The Secretary of State had decided
to deport the Claimant (and that decision has subsequently been upheld by the Tribunal). The Claimant posed a
significant risk of absconding and a significant risk of re-offending, thereby impeding his deportation and thwarting
the interests of public protection which underlie the decision to deport him. Those risks were such as to justify the
decision to detain. The Claimant was detained for the purpose of deporting him. There was no permanent obstacle
to the Claimant's removal. The outstanding asylum claim presented an immediate barrier, but that was capable of
being addressed within a reasonable period of time (the length of which would depend on, amongst other matters,


-----

the extent to which the Claimant cooperated). It could not therefore be said that there was no prospect of removing
the Claimant within a reasonable time. The Secretary of State had commenced the process in good time before the
Claimant's release date and was acting with reasonable diligence and expedition to effect the Claimant's removal.
The delays were primarily attributable to the Claimant's untruthful account as to his nationality. The Hardial Singh
conditions were therefore satisfied.

86. The initial decision to detain, and the subsequent decisions to maintain detention at each review, were
consistent with the detention policy. They showed the application of a presumption against detention. That is
because each detention review started from the presumption that the Claimant should be released, and detention
was only justified (and the presumption outweighed) because of the risk of absconding and re-offending. They also
showed a commitment to ensuring that detention was only for the shortest period necessary (in that detention was
imposed only for the purpose of deportation and for no longer than was necessary to achieve that purpose). I do not
consider that paragraph 55.14 of the Secretary of State's policy directly applies to the present case. The Claimant
was not being detained on the grounds that his removal was imminent. He was being detained because of the risk
of absconding and re-offending. That is consistent with the policy. The decision-making showed close adherence to
the guidance at paragraph 55.1.3 of the policy.

87. February 2018 – August 2018: In February 2018 the Claimant, through his solicitors, gave a truthful account as
to his nationality. It was only at that point that the Secretary of State could begin meaningfully to examine the
asylum claim and to obtain a travel document to enable the Claimant's removal.

88. Those authorising detention did not always clearly and expressly address the amount of time that it would take
before the Claimant could be removed. The evidence as to the time taken to obtain a travel document, and when
steps can be taken to initiate that process, is unsatisfactory. I have no witness or documentary evidence on the
point and have to work on the basis of brief entries in the notes. These suggest that the process might take up to 12
months (see paragraphs 22 and 40 above, albeit I appreciate that the forecast given on 21 March 2018 that
removal might take place within 5 months suggests a shorter timetable may be possible). There is no reliable
evidence to show that the process of obtaining a travel document cannot start well before an asylum application has
been determined (albeit it would be redundant if an asylum claim succeeded). It has not, for example, been shown
that a travel document must specify the date of travel, or that it is only valid for a short window of time, such that it
would be difficult to secure the document when there are outstanding obstacles to removal. The references in the
early detention reviews to a request for a travel document being “put in progress” strongly suggest that there was
no need to await the outcome of the asylum application. Moreover, the process was in fact initiated before the
asylum claim had been determined (although only a few weeks before). There is a reference in the Secretary of
State's pre-action letter of response to a travel document being pursued “in the event that any appeal rights become
exhausted”, but it is not suggested that it could not be sought earlier and nor is any justification given for waiting
until appeals rights are exhausted before starting the process of applying for a travel document.

89. Where (as here) it is likely that it will take many months to obtain a travel document, the sooner the process is
started the better, particularly where the subject is in detention.

90. If the process had started within 2 weeks of receipt of the Claimant's solicitor's letter stating that he was an
Algerian national, it might be expected that a travel document would be obtained by the end of February 2019. It
could also reasonably have been expected that the Claimant's asylum claim would be determined, and any appeals
resolved, within the same time period. That meant that as from February 2018 the further period of detention that
was in prospect was up to around 12 months. That is a very lengthy period of administrative incarceration.
However, in the light of the risks posed by the Claimant, and his failure to cooperate before February 2018,
detention for that period of time for the purpose of his deportation was, in principle, reasonable.

91. The Secretary of State did not, during this period, start the process of obtaining a travel document for the
Claimant, notwithstanding what might have been expected from the detention reviews. This potentially impacted on
the time that it would take to secure the Claimant's removal. It also potentially impacted on the legality of future
detention. If a point were reached where the only barrier to the Claimant's removal was the absence of a travel


-----

document, and if that absence were attributable to a failure on the part of the Secretary of State to act diligently,
then further detention would, from that point, be likely to be in breach of HS4.

92. That said, I do not consider that detention became unlawful during this period. The Secretary of State was
taking steps to resolve the Claimant's asylum claim (as to which see ground 3 below). He had not been detained for
an unreasonable period of time. There remained a sufficient prospect that it would be possible to remove the
Claimant within a reasonable period of time.

93. As before, the decisions to maintain detention were consistent with the Secretary of State's detention policy.
They were also consistent with the AAR policy (which became relevant once the Claimant was assessed as being a
Level 2 Adult at Risk on 21 March 2018).

94. The fact that in July 2018 an Immigration Judge was expressing concern about the speed of progress does not
mean that the detention was unlawful or that there was any material breach of the Hardial Singh principles.

95. August 2018 – December 2018: The Claimant had not, at any point during this period, been detained for an
unreasonably long period of time. It was always likely to be the case that it would take a number of months to
secure the Claimant's removal – up to around late February 2019. For the reasons I have given above that was not,
in this context, an unreasonable period.

96. By August 2018 it should have been apparent that the claimant's asylum claim was likely to be determined
within a matter of weeks. Thereafter there would (subject to any appeal) be no legal barrier to his removal.
However, a travel document had not been obtained. The early detention reviews had indicated that steps would be
taken to obtain a travel document but this had not been done. Assuming that the process of obtaining a travel
document would take 12 months this meant that the Claimant might now not be removed until around August 2019.
This is 6 months beyond that which might reasonably have been expected in February 2018. Substantial
responsibility for the delay is due to the Secretary of State's failure to start the process promptly. Instead of
adopting parallel processing for the asylum claim and the travel documentation, the Secretary of State
unnecessarily took a linear approach of determining the asylum claim before turning attention to the question of
travel documentation. This is not indicative of the expedition and diligence required when exercising powers of
detention.

97. By the end of August 2018 at the latest (so 6 months after the date on which the process of obtaining a travel
document could have started) I consider that it could no longer be said that the Secretary of State was acting with
all reasonable diligence and expedition. At this point that failure was not prolonging the Claimant's detention.
However, it was now becoming less likely that the Claimant would be removed by the end of February 2019. It was
now possible (assuming the 12 months to obtain a travel document) that removal would not take place until August
2019. This meant that a further 12 months of detention was in prospect, in circumstances where the Claimant had
already spent 8 months in immigration detention.

98. This does not mean that there was no prospect of removal within a reasonable period of time. It was always
possible that a travel document might be secured within an earlier period – the 12 months being an indicative
maximum period rather than a precise forecast. I am satisfied that detention continued to be compatible with HS3.

99. The fact is, however, that by this point it was becoming less likely that the Claimant would be removed by
February 2019, which I have held to be a reasonable period of time in the circumstances of this particular case. In
that event there would, at that point, be a likely breach of HS2, HS3 and HS4 if the Claimant remained in detention.

100. Moreover, the Claimant's detention (paragraph 55.1.1) and AAR (see paragraph 15) policies both require that
the need for detention continues to be balanced against the possibility of alternative mechanisms to ensure
compliance pending removal.

101. The Claimant is subject to rigorous licence conditions (including a 16 hour daytime curfew). He is also subject
to the notification requirements imposed by Part 2 Sex Offenders Act 2003. Appropriate accommodation, located in
an area which minimises the Claimant's risk of offending, would further reduce the risks. By the end of August 2018


-----

the Claimant had already been in immigration detention for 8 months. The prospects of him being removed within a
reasonable time period were receding. It was, in my judgment, necessary by this point to reassess the question of
alternatives to detention.

102. I am fortified in that conclusion by the views expressed by Immigration Judges and the Secretary of State's
own officials at around this time. As to the former, concern had been expressed at the delays that were taking
place, and “in principle” grants of bail had been made. As to the latter, the officials had themselves concluded that
the Claimant should be released on stringent bail conditions. They did not express that conclusion by reference to
HS3. They referred to removal not being “imminent” (an altogether stricter test than HS3). There is one reference in
the notes to there being “factors which suggest” removal “may not be possible” within a reasonable time frame.
However, there was no concluded view that there was no prospect of removal within a reasonable time. In any
event, the final assessment is for the Court. I have concluded that the prospects were receding, but there remained
a sufficient prospect of removal within a reasonable period of time: the asylum claim could be concluded within a
matter of weeks, and a travel document might have been secured more quickly than the most gloomy forecast.

103. I am therefore satisfied that detention remained consistent with policy and the Hardial Singh conditions.

104. Nevertheless, the Secretary of State had, by this point, recognised that it was necessary to reconsider
alternatives to detention, given that the time until deportation was likely to be longer than might previously have
been anticipated. Release on bail was rightly subject to the provision of appropriate accommodation so as to control
the risks. The obligations in respect of the provision of that accommodation, and the impact on the continued
legality of detention, are best addressed in the context of ground 2 below. Subject to ground 2 I do not consider that
the period of time for which the claimant might lawfully remain in detention pending release on bail into appropriate
accommodation is limited to a “short period of grace”. The fact is that detention during this period remains
consistent with the Hardial Singh conditions and that the balance continued to fall in favour of detention unless or
until appropriate accommodation had been secured. Subject to ground 2, the Claimant's detention remained lawful
during this period.

105. As before, the decisions to maintain detention were consistent with the detention and AAR policies. When it
became apparent that it might not be possible to remove the Claimant within a reasonable period of time a decision
was made to secure appropriate accommodation and to release the Claimant to that accommodation. Again, that
was entirely consistent with the policies and shows the Secretary of State reacting appropriately as the period of
detention increased.

106. January 2019: The only barrier to removal remains that of a travel document. I was told at the hearing that an
interview with the Claimant had taken place on 3 January 2019. It remains the case that a request to the Algerian
embassy has still (as at the date of the hearing) not been made. It seems to me that there is now no real prospect
that the Claimant will be removed within a reasonable period of time (which I take to be by the end of February
2019, for the reasons I have given). Continued detention is therefore not compatible with HS3. It will also soon (at
the end of February 2019) be incompatible with HS2 and HS4.

107. On a strict and literal application of HS3 it might be said that maintaining detention is now unlawful. The
_Hardial Singh principles reflect the common law's jealous protection of liberty and its abhorrence of arbitrary_
detention, matters of fundamental constitutional importance. They fall to be applied with the high constitutional
importance of the right to liberty well in mind. They must be interpreted in a manner that is consistent with their
underlying purpose and rationale. The principles are not, however, hard edged. They are not statutory rules which
ineluctably give rise to illegality at the moment of breach – see _R (Krasniqi) v Secretary of State for the Home_
_Department_ _[2011] EWCA Civ 1549 at [12]:_

“The Hardial Singh principles, though approved as such by the Supreme Court, are not the equivalent of
statutory rules, a breach of which is enough to found a claim in damages. As I understand them, they are
no more than applications of two elementary propositions of English law: first, that compulsory detention
must be properly justified, and, secondly, that statutory powers must be used for the purposes for which
they are given. To found a claim in damages for wrongful detention, it is not enough that, in retrospect,
some part of the statutory process is shown to have taken longer than it should have done There is a


-----

dividing-line between mere administrative failing and unreasonableness amounting to illegality. Even if that
line has been crossed, it is necessary for the claimant to show a specific period during which, but for the
failure, he would no longer have been detained.”

108. They are thus not to be applied rigidly or mechanically (see _Lumba at [115]) and it is necessary to take_
account of the way in which the Home Office functions – see HXA v The Home Office [2010] EWHC 1177 QB at

[71].

109. If the Defendant had intended to continue to detain the Claimant until he could be deported then that would, in
all the circumstances of this case, be unlawful. However, the Hardial Singh principles are sufficiently flexible in their
application to permit continued detention for the purpose of arranging appropriate bail conditions, once continued
detention is no longer compatible with HS3. In other words, if it becomes apparent that it will not be possible to
remove a person within a reasonable period of time, continued detention for a short period whilst arrangements are
made for release on bail may be justified.

110. That is so here. The period for which the Claimant has thus far been detained has not yet exceeded a
reasonable period of time having regard to the circumstances of this particular case, though it will shortly do so. The
Claimant continues to pose a significant risk of absconding and re-offending which can only be satisfactorily
addressed by rigorous bail conditions. Detention pending release on bail is, in principle, lawful, even though it is
now clear that removal will not take place within a reasonable period of time. That is because the Secretary of State
no longer intends to detain pending removal, but only until appropriate accommodation can be secured.

111. Here I do agree with Mr Walsh's submission that any further period of detention must be short. HS3 is now
engaged, and HS2 and HS4 will be engaged from the end of February 2019. Any detention thereafter is highly likely
to be unlawful whether or not appropriate accommodation can be secured.

112. Article 5 ECHR: The claim under Article 5 ECHR adds nothing of substance to the remaining grounds of claim.
Action was and is being taken against the Claimant with a view to deportation. I have found that the Claimant's
detention was in accordance with the statutory power to detain, the Secretary of State's policies, and the Hardial
_Singh principles. It follows that it was in accordance with a procedure prescribed by law. The Claimant's detention_
was and is therefore justified under Article 5(1)(f) ECHR.

**Ground 2: Provision of accommodation**

_Submissions_

113. Mr Walsh argues that the ongoing delay in securing appropriate accommodation is unlawful as being in breach
of a duty to act fairly and rationally, and because it frustrates the legislative purpose that underpins paragraph 9 of
schedule 10 to the 1971 Act. He relies on the lengthy period of detention and the fact that decisions have been
made “in principle” to grant bail, such that the delay in securing accommodation is prolonging the Claimant's
already lengthy detention.

114. Ms Gray responds that the Secretary of State has been taking active steps to secure appropriate
accommodation and is continuing to do so. The difficulty is attributable to an extreme lack of suitable
accommodation, rather than to any delay on the part of the Secretary of State who has acted rationally and fairly.

_Discussion_

115. The Claimant's profile (and in particular the nature of his previous offence) is such that the Secretary of State
is entitled to conclude that release on bail should be subject to the provision of appropriate accommodation that
minimise the risk he poses to the public. That is a view that is shared by the Immigration Judges that have
considered applications for bail.

116. The Secretary of State has taken reasonable steps to secure such accommodation, making requests of two
separate accommodation providers and chasing these up when they failed to identify suitable accommodation. The
Secretary of State has not acted unfairly or irrationally in his approach The delay has been due to the inability of his


-----

accommodation providers to identify sufficient suitable accommodation and the assessment of the Claimant's
probation officer that such accommodation as has been identified is not suitable (and, possibly, an unhelpful and
inappropriate attitude on the part of the Claimant's probation officer – see paragraph 44 above). Those causes of
delay are not directly the fault or responsibility of the Secretary of State.

117. This does not, however, mean that the Secretary of State is forever immunised against a finding of liability.
The duty to act fairly and rationally is fact sensitive. Where, as here, the system has not been able to provide what
is required after a lengthy period, the time must come where either the Secretary of State must, as Mr Walsh put it,
take matters into his own hands or where some other “least worst” option (see Sathanantham at [30] and [86]) must
be adopted. That time has now arrived. There are two principal reasons for that.

118. First, the existing processes involve the Secretary of State asking contractors to provide suitable
accommodation and then asking the Claimant's probation officer to review any accommodation that is put forward.
Those processes have been shown, at least in this case, not to work. It is not possible, or necessary, to determine
whether that is because the Claimant's probation officer is “stalling” (see paragraph 44 above) or whether it is
because the accommodation that has been identified is inherently unsuitable. What is clear is that there is no
ground for optimism that the process will result in suitable accommodation being provided within any reasonable
time period. It is neither fair nor rational to continue simply to ask contractors and the Claimant's probation officer to
resolve this issue, in the knowledge that they probably will not do so.

119. Second, by the end of February 2019, the Claimant will have been in detention for over 12 months since he
gave a truthful account as to his nationality. That represents the expiry of the reasonable period within which the
Claimant's removal ought to have been secured in the circumstances of this case. Continued detention thereafter is
likely to be unlawful.

120. Moreover, had it not been for the fact that the Claimant is subject to deportation (so if, for example, he had
been a British citizen) the fact is that he would have been released many months ago without the controls available
under immigration bail. The Claimant will, in any event, be subject to his continuing licence conditions and
notification requirements. The former include confinement from 6am to 10pm each day to an address approved by
the Claimant's supervising officer. Breach of the Claimant's licence conditions will render him liable for recall to
prison until the expiry of his sentence on 25 December 2019. Breach of the notification requirements is a criminal
offence – see s91 of the Sexual Offences Act 2003.

121. Accordingly, this ground of claim fails, albeit the Claimant will soon have to be released whether or not the
most appropriate accommodation can be secured.

**Ground 3: Determination of asylum claim**

_Submissions_

122. Mr Walsh submits that the delay in making a decision on his asylum claim was unlawful, that a decision should
have been made by early July 2018, that if this had been done the Claimant would have been able to pursue his
appeal and should have been released at that time because of a breach of HS4. Ms Gray responds that there has
been no actionable delay and that in any event any lack of expedition has not prolonged the Claimant's detention.

_Discussion_

123. The Claimant made his asylum claim on 21st June 2016. It was determined on 3rd October 2018. That is a
period of 2 years and 3½ months. On the face of it this is a very long period of time which calls for an explanation. It
is, however, necessary to identify what was happening at each point in time in order to assess whether the
Defendant acted unlawfully and, if so, whether this impacted on the Claimant's detention.

124. June 2016 to February 2018: Throughout this period of time the Claimant was untruthfully claiming to be a
Syrian national. The Defendant cannot be criticised for seeking to establish the Claimant's true nationality or for not
establishing his nationality with any certainty prior to February 2018. The Claimant complains about delays on the


-----

Secretary of State's part during this period, but any such delays are of limited significance in the light of the
Claimant's mendacity as to his nationality, which was fundamental to his asylum claim. Any assessment of his claim
would either have been undertaken on a false basis (namely that the Claimant was Syrian) or an uncertain
contingent basis (namely that he was Algerian or Moroccan or Tunisian).

125. February 2018 to May 2018: The Claimant complains about delay between the date on which his solicitors
notified the Secretary of State as to his nationality (letter received on 13 February 2018) and the date of his
interview on 3 May 2018. No doubt an interview could or even should have been arranged earlier, but the delay
does not amount to illegality. There is no suggestion that he unlawfully prioritised other cases above the Claimant's
case, or that he failed to allocate an appropriate proportion of the available resources to the Claimant's case. There
is nothing in the documentation to suggest that efforts were not being made to determine the Claimant's case. The
opposite is the case. On the very same day that the solicitor's letter arrived, a request was made that the claimant
be re-interviewed. There were difficulties securing an Arabic interpreter. The Claimant was transferred and a further
request was made. An interview was scheduled for 24 April but did not go ahead, and it was rebooked for 3 May
2018. The administrative frustrations that caused delay are not indicative of illegality on the part of the Secretary of
State.

126. May 2018 to October 2018: A further interview took place on 13 June 2018. A third interview was then
arranged because of differences in the accounts given in the May and June interviews. The Claimant is critical of
this re-interviewing, pointing out that there can be many explanations for inconsistencies and that the Claimant's
core account had been consistent. That is all correct. It may well have been open to the Secretary of State to
determine the asylum claim on the basis of the account given in the May interview, or to do so on the basis of both
the May and June interviews. However, it was for the Secretary of State to decide (within the bounds of rationality)
what information was required to determine the asylum claim and how best to secure it. It was not unreasonable, far
less irrational, to seek to re-interview the Claimant. Even if the multiple interviews could properly be attributed to
one or more of the earlier interviews not being sufficiently rigorous, that itself does not amount to illegality.

127. I have therefore concluded that, notwithstanding the very long period of time that was taken to determine the
Claimant's asylum claim, the Defendant did not, at any stage, act unlawfully. At all material times the Defendant
was seeking to progress the resolution of the claim and was taking reasonable and rational steps to do so. He might
have taken different steps (such as not giving the Claimant so many opportunities to state and clarify his accounts)
which might have brought the matter to a conclusion earlier. That does not, however, render his approach unlawful.

128. In any event, any delay in the determination of the asylum claim did not impact on the Claimant's detention. As
matters turned out the Claimant was not granted asylum and released from detention. So an earlier decision would
not directly have resulted in his release by that route. It would (all other matters being equal) have meant that there
would be no statutory bar to removal at an earlier point in time. However, the Claimant could not and would not
have been removed. There would still have been the need to secure a travel document. The practical reality is that
the Claimant would have remained in detention. The delay in making an asylum decision was not material to the
Claimant's continued detention.

129. It follows that this ground of claim is dismissed.

**Ground 4: Failure to refer to NRM**

_Submissions_

130. Mr Walsh contends that the threshold requiring referral for a “reasonable grounds” decision was met from the
time of the Claimant's asylum claim in June 2016 and that, at the very latest, a referral should have been made at
the time of his interview in June 2018. He says the failure to make a referral was relevant to the decision on the
asylum claim because if a referral had been made this would have assisted in speeding up the asylum decision.
This was therefore a material error which also impacted on the Claimant's detention.

131. Ms Gray responds that it was reasonable and rational not to identify the Claimant as a victim of trafficking,
Alternatively, she argues that he could and would have been detained in any event.


-----

_Discussion_

132. The Claimant's account amounted to a claim that he was the victim of trafficking. There were strong grounds
for impugning the Claimant's credibility. That is, however, largely beside the point. Notwithstanding the fact that his
accounts were inconsistent and in some respects demonstrably untrue (not, in itself, inconsistent with being a victim
of trafficking), the Claimant continued, throughout, to maintain his basic account. That account amounted to a claim
that he had been the victim of trafficking. The very low threshold required for referral was met.

133. The Secretary of State has given differing reasons for not referring the case to the NRM. The
contemporaneous notes suggest that it was thought that there were “insufficient indicators”. That, however, appears
to assume that there was an obligation to assess the strength of the claim, rather than simply assessing whether a
claim within the ambit of the policy had been made. The summary grounds state that the Claimant did not raise any
claim that he had been held in slavery in the United Kingdom or that he had been trafficked to or within the United
Kingdom. That is correct, but it does not take the case outside the ambit of the guidance: the policy requirement for
referral to the NRM does not depend on there being a link between the trafficking and the United Kingdom. In her
detailed grounds and oral submissions Ms Gray did not pursue the point taken in the Summary Grounds, and rightly
recognised that the threshold for referral is low. Her remaining submission was that it was rational not to identify the
Claimant as a potential victim of trafficking. I do not agree. The accounts given by the claimant, on any rational
view, fell within the ambit of the definition of trafficking.

134. That said, I do not consider that the failure to refer was unlawful from the outset. The guidance does not have
legislative force. It is permissible to depart from guidance for good reason. It does not, in any event, prescribe any
precise time limit for referral. The Claimant's initial accounts were not entirely clear and it may have been
reasonable to explore his accounts further before making a decision as to whether he was indeed claiming to be a
victim of trafficking.

135. However, following his interview on 13 June 2018 it was clear that he was maintaining an account that
amounted to a claim to have been a victim of trafficking.

136. The failure to refer the Claimant as a potential victim of trafficking following his interview on 13 June 2018 was
an unjustified departure from policy and was thereby unlawful.

137. I do, however, accept Ms Gray's alternative submission (see paragraph 131 above). That failure to refer the
Claimant to the NRM did not bear on and was not relevant to the continued detention of the Claimant. It is likely that
the “reasonable grounds” decision would have been adverse to the Claimant (the best indicator of this being the
conclusion of the First Tier Tribunal on the Claimant's appeal). There is no reason to consider that a referral to the
NRM would have resulted in the release of the Claimant. He would continue to have been detained in any event.

138. Nor has it had any material impact on the asylum claim. I do not accept that a referral would have “speeded
up” an asylum decision. There is no evidence to support that assertion, and it does not logically and necessarily
follow that this would have been the consequence. It is equally possible that a referral would have caused some
delay in the determination of the asylum claim if, for example, the relevant decision makers for the asylum claim
had awaited the outcome of the trafficking referral before progressing the asylum claim.

**Outcome**

139. The Claimant's detention has not, at any stage, been unlawful. Since August 2018 the prospects of removal
within a reasonable period of time have receded but detention pending the arrangement of appropriate
accommodation for release on bail has been justified. The point has now been reached where there is no real
prospect of removal within a reasonable period of time, and where the period of detention will shortly become
unreasonable. Continued detention for a very short further period of time to secure appropriate accommodation is
justified. However, the point is fast approaching (and is likely to be reached at the end of February 2019) where
continued detention will be unlawful and the Claimant must be released even if the most suitable accommodation
has not been secured.


-----

140. There was no unlawful delay in the determination of the Claimant's asylum claim and, in any event, the period
of time taken to resolve his claim was not material to his continued detention.

141. The Claimant has established an unlawful failure to refer his case for a “reasonable grounds” decision, but this
failure has not had any material impact either on his asylum claim or on his detention.

**End of Document**


-----

