# Secretary of State for Justice v C and Others [2022] COPLR 227

[2021] EWCA Civ 1527

Court of Appeal

Lord Burnett CJ, King and Baker LJJ

22 October 2021

**Mental capacity — Sexual offences — Whether care workers would commit criminal offences supporting a**
**man to access a sex worker**

A man with cognitive impairments expressed a desire to have a girlfriend but considered his prospects of finding
one to be very limited. He had tried conventional methods of meeting people but to no avail. Proceedings were
brought by the applicant local authority to determine whether his care workers would commit a criminal offence
[under s 39 of the Sexual Offences Act 2003 ('the 2003 Act') (ie causing or inciting sexual activity by a person with a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y0Y1-00000-00&context=1519360)
mental disorder) if they made practical arrangements for the man to visit a sex worker in circumstances where he
[had capacity within the meaning of the Mental Capacity Act 2005 to consent to sexual relations but could not make](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)
the arrangements himself. The court at first instance made a declaration that they would not. The Secretary of State
for Justice appealed against the decision of the judge. There were three grounds of appeal. The first was that the
judge had misinterpreted s 39 of the 2003 Act. The second (raised by way of a proposed amendment to the
grounds of appeal) was that to sanction the use of a sex worker was contrary to public policy. The third was that the
judge had erred in concluding that Arts 8 and 14 of the European Convention for the Protection of Human Rights
and Fundamental Freedoms 1950 ('the European Convention') required his favoured interpretation.

**Held – allowing the appeal –**

(1) The proceedings in the Court of Protection had been unusual. The judge had not been invited to make a best
interests decision but was invited to express a view on the application of s 39 of the 2003 Act to a hypothetical set
of facts. Given all the circumstances of this case it was doubtful that it had been appropriate to entertain the
application and determine it. It was nonetheless necessary to deal with the substance of the matter not least
because in coming to his decision, the judge took a different view of the law from Keehan J in Lincolnshire CC v AB

_[[2019] EWCOP 43 (see paras [17], [23]–[30]).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5X64-95C3-GXFD-84V4-00000-00&context=1519360)_

(2) It was necessary to consider the effect of s 53A of the 2003 Act, a provision which created a strict liability
offence for anyone who made or promised payment to a prostitute who had in fact been exploited in the way
described by the section. Based on the arrangements contemplated there would necessarily be a risk that both the
man and his carers might commit an offence under s 53A (see paras [33]–[35]).

(3) The starting point in interpreting any statute was the language itself. The litmus test for causation was that
identified in the authorities: did the acts in question create the circumstances in which something might happen, or
did they cause it in a legal sense? Applying that approach, by making practical arrangements, the case workers
would clearly be at risk of committing a criminal offence contrary to s 39 of the 2003 Act (R v Hughes _[2013] UKSC_
_56, [2013] 1 WLR 2461applied) (see paras [42]–[49])._


-----

(4) It was therefore necessary to consider whether the European Convention and the _[Human Rights Act 1998](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
required a different outcome using _[s 3 of the Human Rights Act 1998. An argument based upon Art 8 of the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y0RX-00000-00&context=1519360)_
European Convention entailed the underlying proposition that there was a positive obligation on the state to allow
care workers to make arrangements for sexual contact with prostitutes for those in its care over the age of consent
who were unable to make the arrangements themselves. It

**[*228]**

was unlikely in the highest degree that the Strasbourg Court would recognise such a positive obligation. Section 39
of the 2003 Act did not entail an interference with rights guaranteed by Art 8, but, in any event, it would satisfy Art
8(2) were it necessary to do so. With regard to Art 14, it was common ground that a person with a mental disability
fell within the concept of 'other status' for the purposes of that Article. Section 39 was concerned with sensitive
moral and ethical issues in the field of penal policy. To the extent that the provision discriminated against people in
C's position by comparison with others in the care of the state (or more broadly) it represented the considered view
of Parliament striking balances in these difficult areas. Such a view should ordinarily be respected. The
discriminatory effect of s 39 could not be stigmatised as being manifestly without reasonable foundation. The
statutory provision was clearly justified (R (SC and Others) v Secretary of State for Work and Pensions and Others

_[2021] UKSC 26, [2021] 3 WLR 428applied) (see paras [50]–[55], [58]–[66])._

(5) In view of the court's conclusion on the interpretation of s 39 of the 2003 Act it was unnecessary to consider the
wider argument which the Secretary of State sought to advance in his amended grounds of appeal, namely that any
involvement by care workers in facilitating C's use of a prostitute would be contrary to public policy and on that
basis should never be sanctioned by a court. The point was not, in any event, argued fully before the judge. In
these circumstances the court would refuse permission to amend the grounds of appeal (see para [67]).

(6) The appeal would be allowed on the basis that the arrangements envisaged for securing the services of a sex
worker would place the care workers concerned in peril of committing an offence contrary to s 39 of the 2003 Act
(see paras [68], [69], [72]).

**Per curiam (Baker and King LJJ): The court was only concerned with the judge's decision in the instant case,**
concerning a visit to a sex worker. There were other situations where care workers were asked to assist people who
have the capacity to consent to or engage in sexual relations but lack capacity in other respects, for example to
make decisions about their care, treatment or contact with other people, for instance facilitating contact. It might be
appropriate in those circumstances for the Court of Protection to endorse a care plan under which care workers
facilitate or support such contact and to make a declaration under _[s 15 of the Mental Capacity Act 2005 that the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1T0-TWPY-Y1KJ-00000-00&context=1519360)_
care plan was both lawful and in P's best interests. However: (1) the merits of making such a declaration would turn
on a thorough analysis of the specific facts of the individual case; (2) in making such a declaration, the court might
have to consider carefully whether the steps proposed under the care plan had the potential to amount to a criminal
offence under s 39 of the 2003 Act; and (3) the declaration would not be binding on the prosecuting authorities,
although no doubt it would be taken into consideration in the event of any subsequent criminal investigation (see
paras [71], [75]).
**Statutory provisions considered**

_[Mental Health Act 1983, s 1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6100-TWPY-Y042-00000-00&context=1519360)_

_[Road Traffic Act 1988, s 3ZB](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y1CJ-00000-00&context=1519360)_

_[Human Rights Act 1998, ss 3, 4](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y0RX-00000-00&context=1519360)_

_[Sexual Offences Act 2003, ss 8, 10, 16–19, 23–29, 34–44, 52, 53A, 79, Part 1](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60S0-TWPY-Y1N2-00000-00&context=1519360)_

_[Mental Capacity Act 2005, s 15](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-C1T0-TWPY-Y1KJ-00000-00&context=1519360)_

_[Policing and Crime Act 2009](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7X4Y-TT20-Y97X-732H-00000-00&context=1519360)_


-----

Criminal Law (Sexual Offences) Act 2017, Part 4

European Convention for the Protection of Human Rights and Fundamental Freedoms 1950, Arts 8, 14

**[*229]**
**Cases referred to in judgment**

_A Local Authority v JB [2020] EWCA Civ 735, [2021] Fam 37, [2020] 3 WLR 1014, sub nom_ _Re JB (Capacity:_
_[Sexual Relations) [2020] COPLR 550, [2021] 1 FLR 264, CA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6129-32D3-CGXG-02M4-00000-00&context=1519360)_

_[Airedale NHS Trust v Bland [1993] AC 789, [1993] 2 WLR 316, [1993] 1 FLR 1026, (1993) 12 BMLR 64, HL](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMD1-DY9F-G009-00000-00&context=1519360)_

_Attorney-General v Able and Others [1984] QB 795, QBD_

_[Imperial Tobacco Ltd and Another v Attorney-General [1981] AC 718, [1980] 2 WLR 466, [1980] 1 All ER 866, HL](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KV0-TWP1-60C1-00000-00&context=1519360)_

_Lincolnshire County Council v AB_ _[[2019] EWCOP 43, CP](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5X64-95C3-GXFD-84V4-00000-00&context=1519360)_

_R (AB) v Secretary of State for Justice_ _[[2021] UKSC 28, [2021] 3 WLR 494, [2021] 4 All ER 777, SC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:642G-WRH3-GXF6-854R-00000-00&context=1519360)_

_R (Al-Skeini) v Secretary of State for Defence (The Redress Trust Intervening) [2007] UKHL 26, [2008] 1 AC 153,_

[[2007] 3 WLR 33, [2007] 3 All ER 685, HL](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4PDJ-CV20-TWP1-60ND-00000-00&context=1519360)

_[R (Bus and Coach Association Ltd) v Secretary of State for Transport [2019] EWHC 3319 (Admin), [2019] All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5XPD-6033-GXFD-81HF-00000-00&context=1519360)_
_[(D) 37 (Dec), QBD](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5XPD-6033-GXFD-81HF-00000-00&context=1519360)_

_R (Hampstead Heath Winter Swimming Club and Another) v Corporation of London and Another [2005] EWHC 713_
_(Admin), [2005] 1 WLR 2930, QDB_

_[R (Rusbridger) v Attorney-General [2003] UKHL 38, [2004] 1 AC 357, [2003] 3 WLR 232, [2003] 3 All ER 784, HL](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-7PB0-TWP1-6174-00000-00&context=1519360)_

_R (SB) v Governors of Denbigh High School [2006] UKHL 15, [2007] 1 AC 100, [2006] 2 WLR 719, sub nom_ _R_
_[(Begum) v Headteacher and Governors of Denbigh High School [2006] ELR 273, [2006] 2 All ER 487, HL](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4JVS-BPY0-TWP1-617D-00000-00&context=1519360)_

_R (SC and Others) v Secretary of State for Work and Pensions and Others [2021] UKSC 26, [2021] 3 WLR 428, SC_

_R (Ullah) v Special Adjudicator; Do v Secretary of State for the Home Department [2004] UKHL 26, [2004] 2 AC_
[323, [2004] 3 WLR 23, [2004] INLR 381, [2004] 3 All ER 785, HL](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DDW-G4B0-TWP1-60B4-00000-00&context=1519360)

_R v Barnes_ _[[2008] EWCA Crim 2726, CA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFY1-DYBP-P46X-00000-00&context=1519360)_

_R v Director of Public Prosecutions, Ex p Camelot plc (1997) 10 Admin LR 93, DC_

_[R v Hennigan [1971] 55 Cr App R 262, [1971] 3 All ER 133, CA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KN0-TWP1-6136-00000-00&context=1519360)_

_R v Hughes_ _[[2013] UKSC 56, [2013] 1 WLR 2461, [2013] 4 All ER 613, SC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59SJ-D011-DYBP-M337-00000-00&context=1519360)_

_R v L_ _[[2009] EWCA Crim 1249, CA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7W11-PMG0-YBF6-71JR-00000-00&context=1519360)_

_R v Skelton [1995] Crim LR 635, CA_

_Royal College of Nursing of the UK v Department of Health and Social Security [1981] AC 800, [1981] 2 WLR 279,_

_[[1981] 1 All ER 545, HL](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4DD9-0DS0-TWP1-61M6-00000-00&context=1519360)_

_Smith v Ministry of Defence; Ellis v Ministry of Defence; Allbutt v Ministry of Defence [2013] UKSC 41, [2014] AC_
[52 [2013] 4 All ER 794 [2013] 3 WLR 69 [2014] 1 LRC 663 SC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59WH-T011-JBWM-X1PS-00000-00&context=1519360)


-----

_T (A Child), Re_ _[[2021] UKSC 35, [2021] 3 WLR 643, [2021] 2 FLR 1041, [2021] 4 All ER 665, SC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63V9-3CM3-CGX8-01XS-00000-00&context=1519360)_

_Sir James Eadie QC, Sarah Hannett QC and Fiona Paterson (instructed by the Treasury Solicitor) for the appellant_

_Parishil Patel QC and Neil Allen (instructed by a local authority) for the first respondent_

_Victoria Butler-Cole QC and Ben McCormack (instructed by Odonnells Solicitors) for the second respondent_

_Sam Karim QC and Aisling Campbell (instructed by Hill Dickinson LLP) for the third respondent_

_Gerard Martin QC and Matthew Stockwell (instructed by Irwin Mitchell LLP) for the first intervener_

**[*230]**

_Anthony Metzer QC and Charlotte Proudman (instructed by The Centre for Women's Justice) for the second joint_
_interveners_

_Judgment was reserved._

**LORD BURNETT CJ:**

**[1] Hayden J, sitting in the Court of Protection, decided that care workers would not commit a criminal offence**
[under s 39 of the Sexual Offences Act 2003 ('the 2003 Act') were they to make the practical arrangements for a 27-](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y0Y1-00000-00&context=1519360)
[year-old man ('C') to visit a sex worker in circumstances where he has capacity (within the meaning of the Mental](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)
_[Capacity Act 2005 ('the 2005 Act')) to consent to sexual relations and decide to have contact with a sex worker but](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)_
not to make the arrangements himself.

**[2] Section 39 provides:**

**'39. Care workers: causing or inciting sexual activity**

(1) A person (A) commits an offence if—

(a) he intentionally causes or incites another person (B) to engage in an activity,

(b) the activity is sexual,

(c) B has a mental disorder,

(d) A knows or could reasonably be expected to know that B has a mental disorder, and

(e) A is involved in B's care in a way that falls within section 42.

(2) Where in proceedings for an offence under this section it is proved that the other person had a mental
disorder, it is to be taken that the defendant knew or could reasonably have been expected to know that that
person had a mental disorder unless sufficient evidence is adduced to raise an issue as to whether he knew or
could reasonably have been expected to know it.

(3) A person guilty of an offence under this section, if the activity caused or incited involved—

(a) penetration of B's anus or vagina,

(b) penetration of B's mouth with a person's penis,

(c) penetration of a person's anus or vagina with a part of B's body or by B with anything else, or

(d) penetration of a person's mouth with B's penis,

is liable, on conviction on indictment, to imprisonment for a term not exceeding 14 years.


-----

(4) Unless subsection (3) applies, a person guilty of an offence under this section is liable—

(a) on summary conviction, to imprisonment for a term not exceeding 6 months or a fine not exceeding the
statutory maximum or both;

(b) on conviction on indictment, to imprisonment for a term not exceeding 10 years.'

**[*231]**

**[3] The practical arrangements envisaged would involve care workers booking the sex worker, making the**
necessary arrangements for C to visit her and paying her. The circumstances would not engage the concept of
incitement, because they would be acting to make C's wishes come to fruition, but rather the issue was whether by
making all the arrangements the care workers would 'cause' C to engage in sexual activity. The judge concluded
they would not.

**[4] C does not have capacity to conduct these proceedings; to decide where to live; to decide upon his care and**
treatment; to manage his financial affairs or to decide to use the internet or social media. Hayden J dealt with the
question concerning s 39 as a preliminary issue in advance of considering a care plan but made no order under the
2005 Act and made no declaration. Nonetheless, it is common ground before us that he made a 'decision' which is
the proper subject of an appeal by the Secretary of State for Justice who had been added as a respondent below.
We proceed on that basis.

**[5] The Secretary of State advances three grounds of appeal. First, that the judge misinterpreted s 39 of the 2003**
Act. Secondly, that to sanction the use of a sex worker is contrary to public policy; and thirdly that the judge erred in
concluding that Arts 8 and 14 of the European Convention on Human Rights ('the Convention') required his
favoured interpretation. The second ground has been raised by way of a proposed amendment to the grounds of
appeal. The amendment is opposed; and the third is conditional, in the sense that the judge reached his conclusion
[on statutory interpretation without recourse to s 3 of the Human Rights Act 1998 ('the 1998 Act').](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y0RX-00000-00&context=1519360)

**[6] C has been diagnosed with Klinefelter Syndrome ('XXY syndrome'). That is a genetic disorder where a male has**
an additional X chromosome. In C's case, the disorder has resulted in developmental delays and other social
communication difficulties. C needs significant assistance with independent living which requires the deprivation of
his liberty. The Court of Protection has authorised his deprivation of liberty since 2017. In August 2018 C expressed
a desire to have a girlfriend but considered his prospects of finding one to be very limited. He had unsuccessfully
tried conventional methods of meeting people but to no avail. C told his Care Act advocate that he wanted to have
sex and wished to know whether he could have contact with a prostitute. C's Care Act advocate raised the matter
with his social worker, and in due course, proceedings were commenced by the Local Authority to address the
lawfulness of such contact.

**[7] It is unnecessary to go into great detail about the difficulties faced by C save to note that for a period of three**
[years up to October 2017 he was detained under s 3 of the Mental Health Act 1983 due to the risk he presented of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60X0-TWPY-Y1C0-00000-00&context=1519360)
sexual and physical violence to others. Since that time C has been subject to a deprivation of liberty order, made in
part because of the risk of sexual and violent deviancy he presents when he suffers from intrusive thoughts. Given
some of the behaviour he has exhibited, there is a serious question mark over whether he could safely be left alone
with a sex worker. No doubt a duty of care would be owed to such a sex worker by those who commissioned her
services and extensive disclosure of C's previous behaviour would be required. Alternatively, if C objected or there
were overriding privacy concerns the project might anyway flounder. The judge recognised this when he said that
there would have to be a careful risk assessment at a later stage and a further best interests hearing if s 39 of the
2003 Act was not an

**[*232]**

impediment: para [15]. Whether in the light of the disclosure that would be required it is realistic to contemplate a
prostitute willingly becoming involved is a moot point; so too is whether public bodies, through the commissioning of
care workers, could responsibly expose such a person to risk. As the parties before us recognised, even if the judge


-----

were to conclude at a later hearing that it was in the best interests of C to be provided with the services of a sex
worker it would not necessarily happen. Indeed, the position of the Clinical Commissioning Group is that the risks to
C and the sex worker may be too great for this potential scheme to be implemented whatever the correct approach
to the 2003 Act may be.

**[8] The judge received detailed evidence about the hypothetical practical steps that could be taken were C's wishes**
translated into reality through a care plan. It was envisaged that the services of a sex worker would be engaged
with assistance from a charity known as The Outsiders Trust, a social charity providing support for disabled people.
Many disabled people (whether or not they lack capacity to make particular decisions) find difficulty in forming
intimate relationships. The charity vets sex workers before allowing them to advertise their services on its website.
Anyone may then contact a sex worker to book a service. The judge observed ' “vetting” really implies nothing
more, or indeed less, than ascertaining that the sex worker is both respectful to and understanding of the needs and
challenges faced by those with disabilities'.

**[The Sexual Offences Act 2003](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-BNB0-TWPY-Y0W3-00000-00&context=1519360)**

**[9] The 2003 Act brought about a complete revision of the criminal law relating to sexual offending. Sections 38 to**
41 are concerned with offences by care workers for persons with a mental disorder. Section 79 adopts the definition
[of 'mental disorder' found in s 1 of the Mental Health Act 1983.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6100-TWPY-Y042-00000-00&context=1519360)

**[10] A suite of offences was also created between ss 30 and 33 entitled 'offences against persons with a mental**
disorder impeding choice' (sexual activity with a person with a mental disorder impeding choice, causing or inciting
sexual activity by such a person, engaging in sexual activity in the presence of such a person, and causing such a
person to watch a sexual act). It is not suggested that C's condition is such that the concept of 'impeding choice'
applies to him, namely that the person 'is unable to refuse because of or for a reason related to a mental disorder'.
The concept of 'impeding choice' and capacity under the 2005 Act are not the same.

**[11] Sections 34–37 create offences of inducing persons with a mental disorder to engage in or watch sexual**
activity. The offences relating to inducing a person with a mental disorder to do something sexual require the
agreement of the person concerned to have been obtained by means of 'an inducement offered or given, a threat
made or a deception practised by [the accused] for [that] purpose'.

**[12] Section 38 criminalises sexual activity between a care worker and a person with a mental disorder in his care:**

**'38. Care workers: sexual activity with a person with a mental disorder**

(1) A person (A) commits an offence if—

(a) he intentionally touches another person (B),

(b) the touching is sexual,

(c) B has a mental disorder,

**[*233]**

(d) A knows or could reasonably be expected to know that B has a mental disorder, and

(e) A is involved in B's care in a way that falls within section 42.

(2) Where in proceedings for an offence under this section it is proved that the other person had a mental
disorder, it is to be taken that the defendant knew or could reasonably have been expected to know that that
person had a mental disorder unless sufficient evidence is adduced to raise an issue as to whether he knew or
could reasonably have been expected to know it.

(3) A person guilty of an offence under this section, if the touching involved—


-----

(a) penetration of B's anus or vagina with a part of A's body or anything else,

(b) penetration of B's mouth with A's penis,

(c) penetration of A's anus or vagina with a part of B's body, or

(d) penetration of A's mouth with B's penis,

is liable, on conviction on indictment, to imprisonment for a term not exceeding 14 years.

(4) Unless subsection (3) applies, a person guilty of an offence under this section is liable—

(a) on summary conviction, to imprisonment for a term not exceeding 6 months or a fine not exceeding the
statutory maximum or both;

(b) on conviction on indictment, to imprisonment for a term not exceeding 10 years.'

**[13] I have already set out s 39.**

**[14] Section 40 is entitled 'Care workers: sexual activity in the presence of a person with a mental disorder':**

**'40. Care workers: sexual activity in the presence of a person with a mental disorder**

(1) A person (A) commits an offence if—

(a) he intentionally engages in an activity,

(b) the activity is sexual,

(c) for the purpose of obtaining sexual gratification, he engages in it—

(i) when another person (B) is present or is in a place from which A can be observed, and

(ii) knowing or believing that B is aware, or intending that B should be aware, that he is engaging in it,

(d) B has a mental disorder,

(e) A knows or could reasonably be expected to know that B has a mental disorder, and

(f) A is involved in B's care in a way that falls within section 42.

**[*234]**

(2) Where in proceedings for an offence under this section it is proved that the other person had a mental
disorder, it is to be taken that the defendant knew or could reasonably have been expected to know that that
person had a mental disorder unless sufficient evidence is adduced to raise an issue as to whether he knew or
could reasonably have been expected to know it.

(3) A person guilty of an offence under this section is liable—

(a) on summary conviction, to imprisonment for a term not exceeding 6 months or a fine not exceeding the
statutory maximum or both;

(b) on conviction on indictment, to imprisonment for a term not exceeding 7 years.'

**[15] Section 41 concerns 'Care workers: causing a person with a mental disorder to watch a sexual act':**

**'41. Care workers: causing a person with a mental disorder to watch a sexual act**


-----

(1) A person (A) commits an offence if—

(a) for the purpose of obtaining sexual gratification, he intentionally causes another person (B) to watch a third
person engaging in an activity, or to look at an image of any person engaging in an activity,

(b) the activity is sexual,

(c) B has a mental disorder,

(d) A knows or could reasonably be expected to know that B has a mental disorder, and

(e) A is involved in B's care in a way that falls within section 42.

(2) Where in proceedings for an offence under this section it is proved that the other person had a mental
disorder, it is to be taken that the defendant knew or could reasonably have been expected to know that that
person had a mental disorder unless sufficient evidence is adduced to raise an issue as to whether he knew or
could reasonably have been expected to know it.

(3) A person guilty of an offence under this section is liable—

(a) on summary conviction, to imprisonment for a term not exceeding 6 months or a fine not exceeding the
statutory maximum or both;

(b) on conviction on indictment, to imprisonment for a term not exceeding 7 years.'

**[16] Care workers are defined in s 42:**

**'42. Care workers: interpretation**

(1) For the purposes of sections 38 to 41, a person (A) is involved in the care of another person (B) in a way
that falls within this section if any of subsections (2) to (4) applies.

(2) This subsection applies if—

**[*235]**

(a) B is accommodated and cared for in a care home, community home, voluntary home children's home, or
premises in Wales at which a secure accommodation service is provided, and

(b) A has functions to perform in the course of employment in the home or the premises which have brought
him or are likely to bring him into regular face to face contact with B.

(3) This subsection applies if B is a patient for whom services are provided—

(a) by a National Health Service body or an independent medical agency;

(b) in an independent hospital; or

(c) in Wales, in an independent clinic,

and A has functions to perform for the body or agency or in the hospital or clinic in the course of employment
which have brought A or are likely to bring A into regular face to face contact with B.

(4) This subsection applies if A—

(a) is, whether or not in the course of employment, a provider of care, assistance or services to B in
connection with B's mental disorder, and


-----

(b) as such, has had or is likely to have regular face to face contact with B.

(5) …'

It is s 42(4) that is engaged in the circumstances of this case.

**[17] The provisions of the 2003 Act fashioned to protect those with mental disorders replicate the statutory scheme**
to protect those under 18 from abuse by adults in a position of trust over them. A person aged 18 or older in a
position of trust may not engage in sexual activity with a child, including a child aged 16 or 17 (s 16); cause or incite
such a child to engage in sexual activity (s 17); engage in sexual activity in the presence of such a child (s 18) or
cause such a child to watch a sexual act (s 19). Section 17 and s 39 of the 2003 Act are in materially the same
terms. Very similar provisions cover familial child sex offences (ss 25–27). All have what is described as a 'marriage
exception' (see ss 23, 28 and 43) so that no offence is committed if the parties are married, in circumstances which
otherwise would be criminal. If the sexual relationship pre-dated the assumption of a position of trust (s 24),
predated the familial relationship (s 29) or predated the care relationship (s 44) there is no criminality.

**[18] The term 'causes or incites' appears throughout the 2003 Act (as does the term 'causes') beyond the three**
groups of sections to which I have referred. For example, it is an offence to cause or incite a child under 13 to
engage in sexual activity (s 8), to cause or incite another person to engage in sexual activity with a child (s 10) and
to cause or incite someone to become a prostitute for gain (s 52).

**[*236]**
**The judge's conclusions on section 39 of the 2003 Act**

**[19] The judge accepted the submission that making all the arrangements for C to visit and have sex with a**
prostitute would not amount to 'causing' C to engage in sexual activity. It was common ground that C has a mental
disorder and that the hypothetical conduct of the care worker would be 'intentional'. He also accepted as 'axiomatic'
that 'it is imperative any package of care is lawful so as not to place any carers liable to criminal prosecution' (para

[37]). He set out his conclusions from para [86]. The judge noted that he was not considering a plan for C to visit a
sex worker and repeated the need for a future risk assessment given C's condition and characteristics. At [89] he
identified 'the central philosophy' of the 2003 Act as being to 'protect those where the relationship itself elevates
vulnerability'. The legislation did not constrict the life opportunities of those with mental disorders and sought 'to
empower, liberate and promote the autonomy of those with mental disorders'. At [90] he recognised that the 2003
Act brings professionals within the ambit of the criminal law:

'if they abuse the power bestowed on them by the unequal nature of their relationships with vulnerable adults
or children. As such the [2003 Act] is both promoting free and independent decision-taking by adults with
mental disabilities, whilst protecting them from harm in relationships where independent choices are occluded
by an imbalance of power. It is tailored to promoting the right to enjoy a private life, it is not structured in a way
that is intended to curtail it … in effect striking a balance between protecting those with mental disorders whilst
enabling independent choices, in this most important sphere of human interaction. It follows, of course, that
such choices are not confined to those which might be characterised as good or virtuous but extend to those
which may be regarded, by some, as morally distasteful or dubious. Protection from discrimination facilitates
informed decision taking. Those decisions may be bad ones as well as good. This is the essence of autonomy.'

**[20] The judge continued at para [92] by noting that while s 39 criminalises care workers who cause or incite sexual**
activity, the activity contemplated here was desired by C who had capacity to decide whether or not to have sex but
not to organise it with a sex worker. His core reasoning is at para [93]:

'The mischief of Section 39 … as elsewhere in the legislation, is exploitation of the vulnerable. The provision is
perhaps not drafted with pellucid clarity, but its objectives are identifiable. It is intended to signal unambiguous
disapprobation of people employed in caring roles (i.e. care workers) who cause or incite sexual activity by a
person for whom they are professionally responsible. The legislative objective is to criminalise a serious breach
of trust and, as I have commented, attracts a significant custodial sentence. The words of the statute need to
be given their natural and obvious meaning. They are intending to criminalise those in a position of authority


-----

and trust whose actions are calculated to repress the autonomy of those with a mental disorder, in the sphere
of sexual relations. Section 39 is structured to protect vulnerable adults

**[*237]**

from others, not from themselves. It is concerned to reduce the risk of sexual exploitation, not to repress
autonomous sexual expression. The language of the section is not apt to criminalise carers motivated to
facilitate such expression. …'

**[21] The underlined sentence encapsulates the essence of the judge's interpretation of s 39 of the 2003 Act. A care**
worker who made all the arrangements for someone with a mental disorder in his care to have sex with a prostitute,
in the way envisaged, would not have 'caused' that person to engage in sexual activity because the actions would
have been calculated to give voice to his autonomy in the sphere of sexual relations. There would have been no
abuse by the care worker who had facilitated the person's independent choice.

**[22] The judge's conclusion on the interpretation of s 39 meant that it was unnecessary for him to consider s 3 of**
the Human Rights Act. That provision gives the court a power to interpret statutory provisions to avoid
incompatibility with the Convention. He added that 'it is important to record … that had I been required to have
recourse to s 3, I would have had little hesitation in concluding that the Convention required the construction that I
had already arrived at' (para [95]).
**Civil courts and declarations of the meaning of criminal statutes**

**[23] The proceedings in the Court of Protection were unusual. Hayden J was not invited to make a best interests**
decision but was invited to express a view on the application of s 39 of the 2003 Act to a hypothetical set of facts.
That view depended upon assumed facts of which there was detailed evidence. After giving judgment, the judge
was invited to make a declaration but declined to do so. In the result, there is no 'order' which is the subject of an
appeal. The proceedings below were seen by all as a steppingstone. A further hearing considering a fully worked
up care plan was envisaged. The judge himself recognised at more than one point in the judgment that the whole
debate had a further hypothetical air. The characteristics of C raised a serious question about whether it would be
appropriate to expose a sex worker to the risks of spending time alone with him.

**[24] It is well recognised that a civil court may grant a declaration clarifying the meaning of a criminal statutory**
provision or, if rarely, that future conduct would not be unlawful and, more rarely still, that future conduct would
amount to a criminal offence. The circumstances in which a civil court should involve itself in these matters were
discussed in the House of Lords in R (Rusbridger) v Attorney-General [2003] UKHL 38, [2004] 1 AC 357, [2003] 3
WLR 232. The first question before the Appellate Committee was: what are the principles that determine whether a
civil court should entertain a claim for declaratory relief on a question of criminal law?

**[25] In answering the question Lord Steyn at para [16] explained that the general principle was that 'save in**
exceptional circumstances, it is not appropriate for a member of the public to bring proceedings against the Crown
for a declaration that certain proposed conduct is lawful and name the Attorney General as the formal defendant to
the claim'. He referred to Imperial Tobacco Ltd and Another v Attorney-General [1981] AC 718, [1980]

**[*238]**

2 WLR 466which concerned an attempt to obtain a declaration in the face of pending criminal proceedings and
continued:

'All that need be said about the actual decision of the House in Imperial Tobacco is that it was based on the
paradigm for the application of the restrictive principle. Viscount Dilhorne did, however, express himself more
generally. He observed (742C-D):

“My Lords, it is not necessary in this case to decide whether a declaration as to the criminality or otherwise of
future conduct can ever properly be made by a civil court. In my opinion it would be a very exceptional case in
which it would be right to do so.” '


-----

**[26] Lord Steyn recognised that since 1951 it had become well established that there is jurisdiction for a civil court**
to make such a declaration. He referred to Zamir and Woolf: The Declaratory Judgment (3rd edn, 2002), para 4.201
and R v Director of Public Prosecutions, Ex p Camelot plc (1997) 10 Admin LR 93. He added, '[b]ut the exceptional
nature of such a declaration by a civil court has on a number of occasions been emphasised'. At para [19] Lord
Steyn concluded:

'… Normally, the seeking of a declaration in a civil case about the lawfulness of future conduct will not be
permitted. But in truly exceptional cases the court may allow such a claim to proceed.'

**[27] In examining the criteria which should be applied in deciding whether a case was truly exceptional Lord Steyn**
observed at para [21] that '[t]he starting point must be that the relief claimed may as a matter of jurisdiction be
granted'. He noted at para [23] that whether a case was fact sensitive or not was:

'a factor of great importance and most claims for a declaration that particular conduct is unlawful will founder on
this ground … [I]t has always been recognised that a question of pure law may more readily be made the
subject-matter of a declaration: see Munnich v. Godstone Rural District Council [1966] 1 WLR 427, cited with
approval by Lord Lane (with whom Lord Edmund-Davies and Lord Scarman agreed) in _Imperial Tobacco v_
_Attorney General, at 751F–752A. …'_

**[28] At para [24] Lord Steyn accepted that there must be a cogent public or individual interest which could be**
advanced by the grant of a declaration. He cited Airedale NHS Trust v Bland [1993] AC 789, [1993] 2 WLR 316,

_[[1993] 1 FLR 1026, (1993) 12 BMLR 64 as an example of an overwhelming interest of an individual in the grant of a](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMD1-DY9F-G009-00000-00&context=1519360)_
declaration that the cessation of life-sustaining medical support was lawful but recognised that the jurisdiction was
not limited to life and death issues: Royal College of Nursing of the UK v Department of Health and Social Security

[1981] AC 800, [1981] 2 WLR 279.

**[29] The need for a cogent reason to grant a declaration that future conduct would or would not be criminal was**
explained further by Leggatt LJ in _R (Bus and Coach Association Ltd) v Secretary of State for Transport [2019]_
_EWHC 3319 (Admin) at para [47] on the basis that 'questions of criminal law are_

**[*239]**

most appropriately decided by criminal courts in cases where the question whether a criminal offence has been
committed has actually arisen'. Woolf J had referred to the danger of usurping the jurisdiction of the criminal courts
in Attorney-General v Able and Others [1984] QB 795 at 807–808 dealing with an application for a declaration that
certain conduct was criminal. More recently in _R (Hampstead Heath Winter Swimming Club and Another) v_
_Corporation of London and Another [2005] EWHC 713 (Admin), [2005] 1 WLR 2930at para [23] Stanley Burnton J_
warned:

'… The Court must exercise caution whenever it is asked to decide whether hypothetical acts may infringe the
criminal law. Even greater caution is appropriate where the decision is to be made without the benefit of the
representation of the body responsible for enforcing that law, in the present case the [Health and Safety
Executive]. The Court must be particularly astute … as to collusive litigation, but caution will be appropriate
whenever there is a real possibility that not all relevant points have been argued or that relevant material is not
before it.'

**[30] By virtue of s 15 of the 2005 Act, the Court of Protection appears to have power to make declarations about the**
lawfulness of specific provisions in a care plan. The use of that power to declare lawful conduct which has the
potential to be criminal should be confined to cases where the circumstances are exceptional and the reasons
cogent. But the Court of Protection did not make a declaration in this case. Nonetheless, the principles I have
summarised apply with equal force in circumstances where the court made a decision reflected in its judgment that
certain hypothetical conduct would not amount to a criminal offence. Given all the circumstances of this case it is
doubtful that it was appropriate to entertain this application and determine it. It is nonetheless necessary to deal
with the substance of the matter not least because in coming to his decision, the judge took a different view of the
[law from Keehan J in Lincolnshire County Council v AB [2019] EWCOP 43 He had concluded that involvement by](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5X64-95C3-GXFD-84V4-00000-00&context=1519360)


-----

care workers of the sort envisaged in this case would probably fall foul of s 39 of the 2003 Act. He decided that, in
those circumstances, it would be contrary to AB's best interests 'to have sexual relations with prostitutes [or for] this
court to sanction the same'.
**The interpretation of the 2003 Act**

**[31] The Secretary of State for Justice has advanced arguments which might otherwise have been for the Director**
of Public Prosecutions ('DPP'). The Secretary of State is involved because of the way the issues developed before
the Court of Protection. The original application was brought by the Local Authority, with C and the Clinical
Commissioning Group as respondents. Even though the interpretation of a criminal statute was at the heart of the
application, the DPP was originally neither served nor joined. The matter proceeded towards a hearing but then
those representing C indicated that if their favoured interpretation of s 39 of the 2003 Act were rejected, they would
seek a declaration of incompatibility with arts 8 and 14 of the Convention, pursuant to s 4 of the 1998 Act. It was in
those circumstances that the Crown

**[*240]**

was notified in accordance with the rules and the Secretary of State for Justice was joined as a respondent. In
November 2020 the DPP was notified of the proceedings but declined to be joined.

**[32] Section 53A of the 2003 Act was also discussed below:**

**'53A Paying for sexual services of a prostitute subjected to force etc.**

(1) A person (A) commits an offence if—

(a) A makes or promises payment for the sexual services of a prostitute (B),

(b) a third person (C) has engaged in exploitative conduct of a kind likely to induce or encourage B to provide
the sexual services for which A has made or promised payment, and

(c) C engaged in that conduct for or in the expectation of gain for C or another person (apart from A or B).

(2) The following are irrelevant—

(a) where in the world the sexual services are to be provided and whether those services are provided,

(b) whether A is, or ought to be, aware that C has engaged in exploitative conduct.

(3) C engages in exploitative conduct if—

(a) C uses force, threats (whether or not relating to violence) or any other form of coercion, or

(b) C practises any form of deception.

(4) A person guilty of an offence under this section is liable on summary conviction to a fine not exceeding
level 3 on the standard scale.'

**[33] This provision was inserted into the 2003 Act by the** _[Policing and Crime Act 2009. It creates a strict liability](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7X4Y-TT20-Y97X-732H-00000-00&context=1519360)_
offence for anyone who makes or promises payment to a prostitute who has in fact been exploited in the way
described by the section. It followed a Home Office Report entitled 'Tackling the demand for prostitution: a review' in
November 2008 which explained the rationale:

'Under the new offence it will be irrelevant whether the sex buyer knew that the prostitute was controlled or not.
It is argued that those who pay for sex will know that they could be paying for sex with a person who is
controlled, and therefore they will think twice about what they are doing and their attitude towards those selling
sex. This will also help to achieve the goal of reducing the size of the “sex market” by sending a clear message
that those who pay for sex should consider the potential implications of their actions.' (p 15)


-----

**[34] It is an undoubted fact that many of those working as prostitutes have been exploited, for example as victims of**
**_modern slavery or trafficked to the United Kingdom. It is the regular experience of the courts to come across such_**
cases in both the criminal and immigration contexts. Interveners before this court (charities called Nia and
women@thewell) attest to its prevalence. It is

**[*241]**

irrelevant to liability under this section whether a defendant knew or had reason to believe that the prostitute in
question had been exploited. The section was the subject of debate in these proceedings because although checks
made before engaging the services of a sex worker might reduce the risk of committing the offence, they can rarely
eradicate them altogether. Based on the arrangements contemplated there would necessarily be a risk that both C
and his carers might commit an offence under s 53A.

**[35] Before returning to the terms of s 39 of the 2003 Act, I should note a recent decision of the Supreme Court, Re**
_T (A Child)_ _[2021] UKSC 35, [2021] 3 WLR 643,_ _[[2021] 2 FLR 1041. It concerned a child whose characteristics](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:63V9-3CM3-CGX8-01XS-00000-00&context=1519360)_
required confinement in secure accommodation, but none was available. One question in the appeal concerned the
use of the inherent jurisdiction of the High Court to authorise a local authority to deprive a child of his or her liberty
in a restrictive placement other than in an approved secure children's home. Regulations provide that a children's
home must only be used as secure accommodation if it has been approved for that purpose by the Secretary of
State for Education (in England) or by the Welsh Ministers (in Wales); and that children's homes must be registered
with Ofsted (in England) and Care Inspectorate Wales (in Wales). A person who carries on or manages a children's
home without being registered commits an offence. At paras [145]–[147] Lady Black considered the question
whether the inherent jurisdiction should ever be used to sanction a placement which would involve the commission
of a criminal offence. She considered that doing so would be the least bad option but emphasised that it should only
ever happen if there were no alternative and immediate steps were taken to register the home. Lord Stephens dealt
with this question at para [166] and following with his detailed consideration in the factual context of that case at

[168] and [169]. He agreed with Lady Black and added at [173]:

'The judgment of Lady Black is confined to the permissible use of the inherent jurisdiction in the context of the
[commission of an offence under section 11 of the Care Standards Act 2000. On that basis the decision in this](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-D4J0-TWPY-Y1H9-00000-00&context=1519360)
case should not be taken as a wider-ranging precedent for the use of the inherent jurisdiction notwithstanding
that the court is aware that some other criminal offence may be committed.'

**[36] Although that case was concerned with the inherent jurisdiction relating to children the same approach applies**
in the context of 'best interests' decisions made in the Court of Protection. The judge recognised as much in para

[37] of his judgment quoted above at [19].

**[37] The starting point in interpreting any statute is the language itself. Causation is a common ingredient of a**
criminal offence. Moreover, a word or phrase that appears on more than one occasion in a statute will be given a
consistent meaning unless the context dictates otherwise.

**[38] Causation is often an issue in homicide cases. It has been the subject of much judicial consideration in that**
context and in connection with driving offences (causing death by dangerous or careless driving). There may be
concurrent causes of an event or outcome. A defendant's action need not be the sole or even dominant cause of
the event but must have been more than negligible or minimal. It follows that the defendant may be held to have

**[*242]**

caused a result even if his conduct was not the sole cause or could not by itself have brought about the result.
Where there are multiple causes including where, for example, the deceased has contributed to the result, a
defendant will remain liable if his act is a continuing and operative cause.

**[39] In R v L** _[[2009] EWCA Crim 1249 (a case of causing death by careless driving) Toulson LJ, summarised the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:7W11-PMG0-YBF6-71JR-00000-00&context=1519360)_
state of the law of causation by reference to _R v Hennigan [1971] 55 Cr App R 262,_ _[[1971] 3 All ER 133,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4CSP-3KN0-TWP1-6136-00000-00&context=1519360)_ _R v_
_[Skelton [1995] Crim LR 635 and R v Barnes [2008] EWCA Crim 2726 at para [9]:](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VFY1-DYBP-P46X-00000-00&context=1519360)_


-----

'Those authorities establish or recognise these principles: First, the defendant's driving must have played a part
not simply in creating the occasion for the fatal accident, i.e. causation in the “but for” sense, but in bringing it
about; secondly, no particular degree of contribution is required beyond a negligible one; thirdly, there may be
cases in which the judge should rule that the driving is too remote from the later event to have been the cause
of it, and should accordingly withdraw the case from the jury.'

**[40] Then at para [16], having drawn the critical distinction between creating the circumstances in which something**
occurred and causing it in a legal sense, he continued at para [16]:

'In short, it is ultimately for the jury to decide whether, considering all the evidence, they are sure that the
defendant should fairly be regarded as having brought about the death of the victim by his careless driving.
That is a question of fact for them. As in so many areas, this part of the criminal law depends on the collective
good sense and fairness of the jury.'

**[41] Causation was considered in an unusual context in** _R v Hughes_ _[2013] UKSC 56, [2013] 1 WLR 2461. The_
[case concerned the offence under s 3ZB of the Road Traffic Act 1988 of '[causing] the death of another person by](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-6170-TWPY-Y1CJ-00000-00&context=1519360)
driving a motor vehicle on a road' without a valid licence, while disqualified or uninsured. The defendant did not
have a full driving licence and was uninsured. He was driving normally when an oncoming vehicle veered across
the road and collided with his vehicle. The driver of the oncoming vehicle was killed. The defendant was prosecuted
and convicted. Beyond being the driver of a vehicle on the road the defendant did nothing to cause the accident or
death. The Supreme Court (Lord Hughes and Lord Toulson giving the only judgment) referred to the distinction
between a cause 'in the sense of a sine qua non' and a legally effective cause: para [23]. This echoed what Lord
Toulson has said in R v L. They concluded that the driving of Mr Hughes created the opportunity for his car to be
run into by the oncoming driver (para [25]) but that for the offence to be made out the defendant 'must be shown to
have done something other than simply putting his vehicle on the road so that it was there to be struck' (para [28]).
They had earlier (para [19]) explained that Parliament could have used much clearer language if its intention had
been to fix criminal liability on a simple 'but for' or 'sine qua non' basis.

**[*243]**

**[42] It cannot be suggested that the many offences in the 2003 Act which import the ingredient of causation are**
concerned only with a 'but for' test. The 2003 Act requires the conduct of the defendant to be an operative cause of
the prohibited activity.

**[43] In my judgment the language of the 2003 Act, when it speaks of causation, is at first blush using the term in its**
ordinarily understood meaning in the criminal law. The question, then, is whether the extensive reading of language
into the word 'causes' in s 39 undertaken by the judge (see para [19] and [20] above) to restrict its ordinary meaning
was correct. I am unable to agree that it was.

**[44] The legislative technique of the 2003 Act is to draw bright lines to reduce the risk of the abuse of those who are**
vulnerable and elsewhere to draw bright lines because it is necessary for certainty. An example of the latter is the
age of consent itself. A line must be drawn which in one sense is arbitrary because it does not concern itself with
harm or possible exploitation in the individual case or with an individual's physical or psychological maturity. Yet it
provides certainty and reflects Parliament's view of the correct balance to strike in a sensitive matter of morality as
well as reduction of risk to young people.

**[45] Examples of the former abound in the 2003 Act.**

**[46] It is an offence under s 38 for a care worker to engage in sexual activity with a mentally disordered person in**
his or her care. That is so even if the person has capacity, is keen to engage in sexual activity and consents. The
care worker and person cared for may have developed a deep emotional relationship that both wish to become
sexually fulfilled but the law forbids it. It would be no defence for the care worker to argue that the person had
capacity and had consented. Parliament has chosen this legislative technique to reduce risk to a group of
vulnerable people. In doing so it has restricted the freedom of some who otherwise would be at liberty to have a
sexual relationship, but it has done so in the wider interest of protecting the group. The same can be said of s 40 in


-----

the case of care workers engaging in sexual activity in the presence of a mentally disordered person (see para [14]
above). The full agreement of the cared for person would not be a defence. Nor would it be for the purposes of s 25
concerning sexual activity with a child family member. That criminalises sexual activity with a consenting 16 or 17
year old child by a range of people within the relationships set out in s 27. It is possible to envisage in all these
cases that there might be genuine, indeed considered and enthusiastic consent and that the potential defendant
was acting at the bidding of the 'victim'. To paraphrase the judge, the actions would neither repress the autonomous
sexual expression of that person nor involve a breach of trust, an abuse of power or exploitation. Yet exploration of
such matters with a resulting burden of proof on the prosecution form no part of the ingredients of these offences. If
the judge's interpretation of s 39 is correct it is difficult to see why it should not have a much wider application
across a range of offences created by the 2003 Act which criminalise activity between people who would be free to
engage in that sexual conduct but for the existence of the relevant relationship.

**[47] I have referred to the offences created by ss 16–19 of the 2003 Act relating to abuse of positions of trust: see**
para [17] above. It is difficult to conceive that it would be a defence to a charge under s 16 (sexual activity with a
child) for the adult in a relevant position of trust to say that a 16 or 17

**[*244]**

year old child was a consenting participant in the sexual activity who actively desired the sexual contact. Once
more, Parliament has chosen to protect a group of people who are vulnerable by drawing bright lines which reduce
risk to the cohort generally. There have been many instances of teachers and pupils falling in love, running away
together and the like. It is immaterial that if the adult were not in a position of trust no offence would be committed.

**[48] Section 17 is the precise analogue of s 39. A person over 18 in a position of trust commits an offence if he**
intentionally causes or incites a child to engage in sexual activity. That is so even where the child is over the age of
consent. Would a teacher who engaged a sex worker at the request of one of his 17 year old students, made all the
arrangements including for payment and transport be able to avoid a conviction on the basis that there was no
breach of trust and that he was not repressing the student's autonomous sexual expression but advancing it?
Unless the word 'causes' means different things in ss 17 and 39 that line of defence would be open to him on the
judge's interpretation. No argument was advanced to the effect that the words 'causes or incites' should mean
different things in different places in Part 1 of the 2003 Act.

**[49] It follows that in my opinion the words 'causes or incites' found in s 39 of the 2003 Act carry their ordinary**
meaning and do not import the qualifications identified by the judge which led him to conclude that the
arrangements contemplated for C to engage with a sex worker would necessarily not result in criminal liability under
s 39 of the 2003 Act. The litmus test for causation is that identified in the authorities. Do the acts in question create
the circumstances in which something might happen, or do they cause it in a legal sense? Applying the approach of
the Supreme Court in Hughes the care workers would clearly be at risk of committing a criminal offence contrary to
s 39 of the 2003 Act. By contrast care workers who arrange contact between a mentally disordered person and
spouse or partner aware that sexual activity may take place would more naturally be creating the circumstances for
that activity rather than causing it in a legal sense.
**The Convention and the 1998 Act**

**[50] It therefore becomes necessary to consider whether the Convention and 1998 Act require a different outcome**
using s 3 of that Act.

**[51] The argument advanced by the Local Authority and by C is that s 39 of the 2003 Act interferes with C's private**
life under Art 8 of the Convention. It interferes because he is unable to make the arrangements with a sex worker
himself and, although individuals not within the definition of 'care worker' in s 42 might make the arrangements for
him, the scope for his achieving his sexual desires is much reduced if his care workers cannot make them. The
argument under Art 14 proceeds on two bases: first, that C will be treated differently from a person without a mental
disability who can make his own arrangements; or secondly that C suffers discrimination by reason of his mental
disability by comparison with those without. A care worker could make these arrangements for someone in his care
not suffering from a mental disorder.


-----

**[52] Article 8 provides:**

**[*245]**

'(1) Everyone has the right to respect for his private and family life, his home and his correspondence.

(2) There shall be no interference by a public authority with the exercise of this right except such as is in
accordance with the law and is necessary in a democratic society in the interests of national security, public
safety or the economic well-being of the country, for the prevention of disorder or crime, for the protection of
health or morals, or for the protection of the rights and freedoms of others.'

**[53] The argument advanced under Art 8 with reference to s 39 entails the underlying proposition that there is a**
positive obligation on the state to allow care workers to make arrangements for sexual contact with prostitutes for
those in its care over the age of consent (or at least over 18) who are unable to make the arrangements
themselves, at least in circumstances where contact with prostitutes is not generally prohibited. There is no sign of
such a positive obligation having been recognised by the Strasbourg Court, nor of that court having recognised that
Art 8 entails a positive obligation on the state to allow the purchase of sex without fear of criminal sanction.

**[54] The Supreme Court has recently restated the correct approach where arguments under the Convention invite**
the domestic courts to march ahead of the Strasbourg Court: R (AB) v Secretary of State for Justice _[2021] UKSC_
_28, [2021] 3 WLR 494._

**[55] Lord Reed, with whom all members of the court agreed, discussed the principles between paras [54] and [59]**
of his judgment. He restated the general approach first enunciated by Lord Bingham of Cornhill in _R (Ullah) v_
_Special Adjudicator; Do v Secretary of State for the Home Department [2004] UKHL 26, [2004] 2 AC 323, [2004] 3_
WLR 23, [2004] INLR 381 at para [20] expressing the unanimous view of the House that domestic courts were
required 'to keep pace with the Strasbourg jurisprudence as it evolves over time: no more, but certainly no less'. In
_R (SB) v Governors of Denbigh High School [2006] UKHL 15, [2007] 1 AC 100, [2006] 2 WLR 719, sub nom_ _R_
_(Begum) v Headteacher and Governors of Denbigh High School [2006] ELR 273, para [29] Lord Bingham observed_
[that 'the purpose of the Human Rights Act 1998 was not to enlarge the rights or remedies of those in the United](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
Kingdom whose Convention rights have been violated but to enable those rights and remedies to be asserted and
enforced by the domestic courts and not only by recourse to Strasbourg'. An additional rationale was identified by
Lord Brown of Eaton-under-Heywood in _R (Al-Skeini) v Secretary of State for Defence (The Redress Trust_
_Intervening) [2007] UKHL 26, [2008] 1 AC 153, [2007] 3 WLR 33at para [106] who referred to Lord Bingham's_
statement that domestic courts should keep pace with the Strasbourg jurisprudence, 'no more, but certainly no less'.
He commented:

'I would respectfully suggest that last sentence could as well have ended: “no less, but certainly no more”.
There seems to me, indeed, a greater danger in the national court construing the Convention too generously in
favour of an applicant than in construing it too narrowly. In the former event the mistake will necessarily stand:
the member state cannot itself go to Strasbourg to have it corrected; in the latter event,

**[*246]**

however, where Convention rights have been denied by too narrow a construction, the aggrieved individual can
have the decision corrected in Strasbourg. …'

**[56] Lord Reed explained that**

'… If domestic courts take a conservative approach, it is always open to the person concerned to make an
application to the European court. If it is persuaded to modify its existing approach, then the individual will
obtain a remedy, and the domestic courts are likely to follow the new approach when the issue next comes
before them. But if domestic courts go further than they can be fully confident that the European court would
go, and the European court would not in fact go so far, then the public authority involved has no right to apply
to Strasbourg, and the error made by the domestic courts will remain uncorrected.'


-----

He also referred to _Smith v Ministry of Defence; Ellis v Ministry of Defence; Allbutt v Ministry of Defence [2013]_
_[UKSC 41, [2014] AC 52, [2013] 4 All ER 794, [2013] 3 WLR 69, [2014] 1 LRC 663, in which Lord Hope, with whom](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59WH-T011-JBWM-X1PS-00000-00&context=1519360)_
Lord Walker, Lady Hale and Lord Kerr agreed, summarised the position at para [43]:

['Lord Bingham's point [in Ullah, para [20]] was that Parliament never intended by enacting the Human Rights](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)
_[Act 1998 to give the courts of this country the power to give a more generous scope to the Convention rights](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
than that which was to be found in the jurisprudence of the Strasbourg court. To do so would have the effect of
changing them from Convention rights, based on the Treaty obligation, into free-standing rights of the court's
own creation.'

**[57] At para [59] Lord Reed concluded:**

'It follows from these authorities that it is not the function of our domestic courts to establish new principles of
Convention law. But that is not to say that they are unable to develop the law in relation to Convention rights
beyond the limits of the Strasbourg case law. In situations which have not yet come before the European court,
they can and should aim to anticipate, where possible, how the European court might be expected to decide
the case, on the basis of the principles established in its case law. Indeed, that is the exercise which the High
Court and the Court of Appeal undertook in the present case. The application of the Convention by our
domestic courts, in such circumstances, will be based on the principles established by the European court. …'

**[58] It is far from surprising that no case of the Strasbourg Court has been cited to us that recognises a human right**
to purchase the services of the prostitute or to be provided with such services by the state. The approach to
prostitution across the Council of Europe states varies considerably. It ranges from closely regulated prostitution
with neither prostitute nor client

**[*247]**

committing a criminal offence to outright illegality. Almost all Council of Europe states criminalise some aspects of
the sex trade. The approach of both Sweden and Norway is notable. Prostitution is not an offence. An individual
selling sexual services commits no offence but a person who purchases such services does. Similarly, since 2017
in Ireland it has been an offence to purchase sex: see Part 4 of the Criminal Law (Sexual Offences) Act 2017
amending earlier legislation.

**[59] The regulation, including criminalisation, of various aspects of the sex trade is a paradigm example of a sphere**
of activity redolent with complex and controversial moral judgments. It calls for generic risk assessments with the
need for legislatures to strike difficult balances. The Strasbourg Court would allow a wide margin of appreciation to
the parties to the Convention in this area. There is no sign in the Strasbourg case law of a recognition of positive
obligations of the sort which underpin the argument that s 39, interpreted according to ordinary canons of statutory
construction, would give rise to a violation of C's rights under Art 8. That is sufficient to support the conclusion that
Art 8 of the Convention does not require these sections to be interpreted differently if that were possible using s 3 of
the 1998 Act. Nonetheless the context of this argument is such that it must be regarded as unlikely in the highest
degree that the Strasbourg Court would recognise a positive obligation of the type contended for in these
proceedings.

**[60] Section 39 of the 2003 Act does not entail an interference with rights guaranteed by Art 8 of the Convention**
but, in any event, it would satisfy Art 8(2) were it necessary to do so.

**[61] Article 14 of the Convention provides:**

**'Prohibition of Discrimination**

The enjoyment of the rights and freedoms set forth in this Convention shall be secured without discrimination
on any ground such as sex, race, colour, language, religion, political or other opinion, national or social origin,
association with a national minority, property, birth or other status.'


-----

**[62] It is common ground that a person with a mental disability falls within the concept of 'other status' for the**
purposes of Art 14. It is also clear that the effect of s 39 of the 2003 Act places C in a different position from others
being looked after by care workers because of his mental disorder. Someone whose physical disability prevented
him from making the practical arrangements to secure the services of a prostitute could enlist the assistance of a
care worker without the potential of falling foul of s 39. In my view that is the appropriate comparator although for
the purposes of Art 14 in this case the decisive issue is that of justification.

**[63] The Supreme Court has recently reviewed the applicable principles when considering a challenge under Art 14**
of the Convention to social welfare provisions: R (SC and Others) v Secretary of State for Work and Pensions and
_Others [2021] UKSC 26, [2021] 3 WLR 428. Lord Reed gave the sole judgment. He discussed Art 14 between_
paras [157] and [162]. A low intensity of review was generally appropriate in cases which concerned judgements on

**[*248]**

social and economic policy, including welfare benefits. The judgement of the legislature or executive would be
accepted unless it was manifestly unreasonable. At para [160] he said:

'It may also be helpful to observe that the phrase “manifestly without reasonable foundation”, as used by the
European court, is merely a way of describing a wide margin of appreciation. A wide margin has also been
recognised by the European court in numerous other areas where that phrase has not been used, such as
national security, penal policy and matters raising sensitive moral or ethical issues.'

**[64] Section 39 of the 2003 Act is concerned with sensitive moral and ethical issues in the field of penal policy. One**
of its purposes is to throw a general cloak of protection around a large number of vulnerable people in society with a
view to reducing the risk of harm to them. To the extent that the provision discriminates against people in C's
position by comparison with others in the care of the state (or more broadly) it represents the considered view of
Parliament striking balances in these difficult areas. Such a view should ordinarily be respected. In my judgment,
the discriminatory effect of s 39 cannot be stigmatised as being manifestly without reasonable foundation. The
statutory provision is clearly justified.

**[65] There is no basis for concluding that compliance with the Convention requires the interpretation of s 39 of the**
2003 Act to be read down by using s 3 of the 1998 Act.

**[66] It follows that the arrangements for securing the services of a sex worker envisaged in the evidence before the**
judge would place the care workers in peril of committing an offence contrary to s 39.

**[67] In view of that conclusion on the interpretation of s 39 of the 2003 Act it is unnecessary to consider the wider**
argument which the Secretary of State seeks to advance in his amended grounds of appeal, namely that any
involvement by care workers in facilitating C's use of a prostitute would be contrary to public policy and on that
basis should never be sanctioned by a court. The point was not, in any event, argued fully before the judge. In
these circumstances I would refuse permission to amend the grounds of appeal.
**Conclusion**

**[68] For the reasons I have given I would allow the appeal on the basis that the arrangements envisaged for**
securing the services of a sex worker would place the care workers concerned in peril of committing an offence
[contrary to s 39 of the Sexual Offences Act 2003. C's care plan cannot proceed based on such arrangements for](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y0Y1-00000-00&context=1519360)
the reason identified by the judge, namely 'it is imperative any package of care is lawful so as not to place any
carers liable to criminal prosecution'.

**KING LJ:**

**[69] I would allow the appeal for the reasons given by the Lord Chief Justice.**


-----

**[[70] As Baker LJ explains, achieving autonomy for an incapacitated adult lies at the heart of the Mental Capacity](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)**
_[Act 2005. It is not however the role of the Court of Protection to endorse an act which would be unlawful. Under the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)_
2003 Act, the motive of the care worker, no matter how laudable, and the

**[*249]**

consent of the person with a mental disorder who wishes to engage in sexual activity are each irrelevant. In those
circumstances, I cannot see how on any plain reading of the statute, the extensive arrangements necessary in
order for C to engage in sexual relations with a sex worker, and without which sexual activity with a third party
would be impossible for him, can be held to be outside the terms of s 39(1) of the 2003 Act.

**[71] There are, however, many less extreme and benign situations which day in and day out touch on the lives of**
people up and down the country; Baker LJ gives the example of a care worker arranging private time for a long
married couple which she knows is likely to include sexual activity in those circumstances. Such a case is wholly
different from that of C and the question of whether it is appropriate to make a declaration under s 15 of the 2005
Act in such cases is something to be left open for argument in the appropriate case.

**BAKER LJ:**

**[72] I agree that the appeal must be allowed for the reasons given by the Lord Chief Justice. The powers invested**
[in the Court of Protection under the Mental Capacity Act 2005 do not include the power to 'decide' whether or not a](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)
proposed course of action is criminal and a declaration under s 15 of that Act that the course of action proposed in
this case was lawful would be contrary to established authority and wrong in law. As the cases cited by my Lord
demonstrate, the circumstances in which such a declaration would be justified must be exceptional and the reasons
for making the declaration cogent. In this case I see no cogent reasons for making such a declaration and indeed
every reason to refrain from doing so. The course of action proposed in this case would not only place the care
[workers at jeopardy of prosecution under s 39 of the Sexual Offences Act 2003 but would also expose C to the risk](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-60T0-TWPY-Y0Y1-00000-00&context=1519360)
of prosecution under s 53A.

**[73] Underpinning Hayden J's judgment was what he described (at para [59]) as the 'evolved and evolving**
understanding of the importance of respecting the autonomy of adults with learning disabilities'. The principle of
autonomy is indeed part of the bedrock of the Mental Capacity Act. But it is not the only principle guiding decisions
of the Court of Protection. In A Local Authority v JB [2020] EWCA Civ 735, [2021] Fam 37, [2020] 3 WLR 1014, sub
[nom Re JB (Capacity: Sexual Relations) [2020] COPLR 550, [2021] 1 FLR 264, this court was required to consider](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6129-32D3-CGXG-02M4-00000-00&context=1519360)
the question whether a person, in order to have capacity to consent to or engage in sexual relations, must
understand that the other person must consent. Answering the question required the court to balance what I
described as 'three fundamental principles':

['[4] The first is the principle of autonomy. This principle lies the heart of the Mental Capacity Act 2005 and the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61N0-TWPY-Y1DJ-00000-00&context=1519360)
case law under that Act. It underpins the purpose of the UN Convention on the Rights of Persons with
Disabilities 2006, as defined in article 1:

“to promote, protect and ensure the full and equal enjoyment of all human rights and fundamental freedoms by
all persons with disabilities, and to promote respect for their inherent dignity.”

**[*250]**

[5] The second is the principle that vulnerable people in society must be protected. As this court observed in B
_v A Local Authority_ _[2019] EWCA Civ 913 (at para 35):_

'… there is a need to protect individuals and safeguard their interests where their individual qualities or
situation place them in a particularly vulnerable situation.'


-----

Striking a balance between the first and second principles is often the most important aspect of decisionmaking in the Court of Protection. The Mental Capacity Act Code of Practice expresses this in simple terms (at
para 2.4):

'It is important to balance people's right to make a decision with their right to safety and protection when they
can't make decisions to protect themselves.'

[6] There is, however, a third principle that arises in this case. The Mental Capacity Act and the Court of
Protection do not exist in a vacuum. They are part of a wider system of law and justice. Sexual relations
between two people can only take place with the full and ongoing consent of both parties. This principle has
acquired greater recognition in recent years within society at large and within the justice system. The greater
recognition has occurred principally in the criminal and family courts, but it must extend across the whole
justice system. The Court of Protection is concerned first and foremost with the individual who is the subject of
proceedings, “P”. But as part of the wider system for the administration of justice, it must adhere to general
principles of law …'

**[74] The same three principles apply in the present case. The Court of Protection strives to promote the autonomy**
of incapacitated adults to enable them as far as possible to live with the same degree of freedom enjoyed by those
who have capacity whilst having regard to their need for safety and protection. I agree with Hayden J that
understanding about the importance of respecting the autonomy of adults with learning disabilities has evolved and
is still evolving. But as part of the wider system for the administration of justice, the Court has to adhere to general
principles of law. Alongside the growing awareness of the autonomy of people with learning disabilities there has
been an evolution of thinking about the treatment of people who sell sexual services. Where Parliament has
expressly decided that certain conduct should be a criminal offence, it is no part of the Court of Protection's role to
declare that it is lawful.

**[75] I stress, however, that we are only concerned with the judge's decision in this case, namely that care workers**
would not commit a criminal offence under s 39 by making practical arrangements for C, a man with a mental
disorder, to visit a sex worker. I recognise that there are other situations where care workers are asked to assist
people who have the capacity to consent to or engage in sexual relations but lack capacity in other respects, for
example to make decisions about their care, treatment or contact with other people. One example is where a
person with dementia living in a care home wishes to spend time with his or her partner at the family home. Another
example is

**[*251]**

where a young person wishes to meet people of their own age and make friends. In both cases, one consequence
may be that the incapacitated adult engages in sexual relations. I envisage that it might be appropriate in those
circumstances for the Court of Protection to endorse a care plan under which care workers facilitate or support such
contact and to make a declaration under s 15 of the Mental Capacity Act that the care plan is both lawful and in P's
best interests. But in making these observations I emphasise three important points. First, the merits of making
such a declaration will turn on a thorough analysis of the specific facts of the individual case. Secondly, in making
such a declaration, the court may have to consider carefully whether the steps proposed under the care plan have
the potential to amount to a criminal offence under s 39. Thirdly, as set out in the cases cited above, any declaration
would not be binding on the prosecuting authorities, although no doubt it would be taken into consideration in the
event of any subsequent criminal investigation.

Order accordingly.

ALEXANDER RUCK KEENE Barrister

**End of Document**


-----

