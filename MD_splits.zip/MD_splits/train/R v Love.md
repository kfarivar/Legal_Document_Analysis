# R v Love [2024] EWCA Crim 80

Court of Appeal, Criminal Division

Popplewell LJ, Choudhury J, HHJ Angela Rafferty KC

16 January 2024Judgment

The Applicant was not represented, did not attend.

The Crown were not represented.

_________

If this Transcript is to be reported or published, there is a requirement to ensure that no reporting restriction will be
breached. This is particularly important in relation to any case involving a sexual offence, where the victim is
[guaranteed lifetime anonymity (Sexual Offences (Amendment) Act 1992), or where an order has been made in](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-FJ90-TWPY-Y169-00000-00&context=1519360)
relation to a young person.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**JUDGMENT**

MR JUSTICE CHOUDHURY:

1 On 26 April 2023 in the Crown Court at Woolwich, before Mr Recorder Turner, the applicant (then aged

19) pleaded guilty upon re‑arraignment to two counts of possession of a class A drug with intent and one

count of having a bladed knife. There was a basis of plea which was not accepted by the prosecution.

2 On 7 June 2023, before His Honour Judge Gumpert KC, the applicant and his co‑defendant Jack

Thompson were sentenced. The applicant's sentence was two years and eight months in a young
offenders' institution on each of the drugs counts to run concurrently, and seven months for the bladed
article offence to run consecutively. The total sentence was, therefore, three years and three months.

3 The applicant seeks to renew his application for leave to appeal against sentence, leave having been
refused by the single judge.

The Facts

4 At around 4 in the afternoon on 19 January 2023, police officers stopped a motor vehicle driven by
Thompson. The applicant was in the front passenger seat. The applicant was found in possession of £760
in cash, an iPhone and a lock knife concealed in his trousers by his ankle. Thompson was in possession
of an iPhone and £1,889.64. Both the applicant and Thompson were searched at the police station and
had a quantity of class A drugs secreted in their person or in their underwear. In total there were 60 wraps
of crack cocaine (114 milligrams) and 60 wraps of diamorphine (116 milligrams). Thompson was in
possession of one set of the drugs and the applicant the other.

5 A search of the applicant's home uncovered drugs paraphernalia. There was evidence of drug dealing
found on both their mobile phones.


-----

6 In sentencing the applicant, the judge assessed the applicant's role as falling just below the midpoint of a
significant role for category 3 street dealing. That resulted in a starting point of four years and three
months. Aggravating factors, including previous relevant convictions, led to an uplift to four years and nine
months. The judge then applied a substantial discount on account of the applicant's youth and mental
health difficulties which took the sentence down to three years and six months. A further reduction of 15
per cent for guilty plea resulted in a sentence of two years and 11 months for each of the drug's offences.
The judge considered that a consecutive sentence for the bladed article offence of seven months was
appropriate. Applying totality, the judge reduced the sentences on counts 1 and 2 to two years and eight
months.

7 The applicant's self‑drafted grounds of appeal raises three principal grounds: (i) that the applicant should

have been sentenced on the basis of a lesser role as set out in his basis of plea which suggests that he
was forced to sell drugs;(ii) that he should have received greater credit for plea, in particular because he
had had to look into a **_modern slavery defence before pleading; and (iii) there was a lack of parity_**
between his sentence and that of Thompson even though Thompson was older.

8 In refusing leave, the single judge said:

"You entered a basis of plea which was not accepted by the prosecution although not challenged; you did
not ask for a _Newton hearing to test the basis of plea ... and the prosecution made it clear that they_
suggested top end lesser role or bottom end significant role ... The basis of plea was that you offended
when you were a young person with ASD whose vulnerabilities were exploited when you accrued a drug
debt, and you were forced to sell drugs on another's behalf in order to prevent yourself from being harmed.
The basis of plea also said that you performed a limited function under direction, being driven around by

your co‑defendant, and that the benefit you received was small quantities of cannabis for your own habit

and reduction of your drug debt.

...

...

The Judge placed you 'just below the midpoint of a significant role for category 3 street dealing' ... and
began with a sentence of 4 years 3 months. Although he did not say so, this was justified by you having
some awareness of understanding of the scale of the operation ... and expecting significant financial
advantage from the reduction of your drug debt; and was to that extent consistent with your basis of plea
(which had not been accepted and which had not been tested by a Newton hearing). This was below the
Drugs Guideline starting point of 4 years 6 months. You are wrong to think that he sentenced you under
'higher significant role' or that his starting point was '4 years 9 months'.

You had relevant previous convictions, noted by the Judge. The offences were also committed at a time

when you were already subject to a 12‑month Detention and Training Order imposed for failing to comply

with the requirements of a Youth Rehabilitation Order imposed for a robbery offence.

It is not arguable that the Judge's starting point of 4 years 3 months was inappropriate.

The Judge had a Pre‑Sentence Report which referred to your immaturity and vulnerability to manipulation

and exploitation. The Judge had an Autism Assessment Report which included a full history and supported
a diagnosis of Autism Spectrum Disorder and ADHD.

The Judge made 'a significant reduction' for your youth and your mental health difficulties ...

It is not arguable that your sentence was manifestly excessive.

Your change of plea was a month or two after the PTPH, too late to justify credit of 25% and, although you
investigated defences, you clearly decided not to pursue them. An 18% credit for plea was well within the
range open to the Judge and, indeed, he rounded it up to 18% from 15%.


-----

Your co‑defendant's sentence was fully explained in the sentencing remarks (read with the prosecution

facts) and there is no arguable appeal on the basis of disparity. Your culpability was similar, and this was
joint possession with intent to supply. His antecedents were not as bad or as relevant as yours although
he was older. He was not charged with the knife offence for which you received a consecutive sentence.

I therefore refuse leave to appeal, not because you submitted the papers a little late (I understand the
reasons you give for that) but because the appeal is not arguable."

9 Having considered the matter afresh, we are entirely in agreement with the single judge for the reasons
he gives. There is no arguable ground of appeal.

10 We note that for the purposes of this hearing the applicant has produced a letter from his solicitor dated
29 April 2023 summarising his appearance at the plea hearing a few days earlier. That letter, so far as
relevant, provides:

" A basis of plea was served alongside the plea. The Prosecution confirmed that they would not be seeking
a newton (sic) hearing. That means that you will be sentenced on the basis of a lesser role”.

11 However, the summary in that letter is at odds with the Recorder's notes which state unequivocally that
the basis of plea was not accepted. Those notes state:

“Love's BOP not accepted by P (in that they have no knowledge of matters raised in it). P will suggest top
end lesser role/3 or bottom sig/3 for Sentencing purposes -accepting there is an inevitable chain. D will
contend for lesser role/3. On Ct4 Love accepts cash found will be forfeited. On this basis Newton not
required.”

12 The letter appears to relate to the applicant's first ground of appeal which is that he should have been
sentenced in accordance with the lesser role set out in his basis of plea. In our judgment, the letter does
not assist the applicant. Whatever the applicant's understanding might have been after plea, the
prosecution's refusal to accept the basis of plea would have been quite clear to him and his advisers by or
at the sentencing hearing. However, he chose not to have a Newton hearing to establish the basis of plea.
He cannot now complain that he was sentenced on a different basis. It was for the judge to determine the
role played by the applicant. The judge's assessment that the applicant's role fell just below the midpoint
for a significant role was entirely justified on the facts. As stated by the single judge, it is not arguable that
the judge's starting point of four years and three months is inappropriate.

13 For these reasons, leave to appeal is refused.

__________

**CERTIFICATE        Opus 2 International Limited hereby certifies that the above is an**
accurate and complete record of the Judgment or part thereof.Transcribed by Opus 2 International LimitedOfficial
_Court Reporters and Audio Transcribers5 New Street Square, London, EC4A 3BFTel: 020 7831 5627   Fax:_
**_020 7831 7737CACD.ACO@opus2.digitalThis transcript has been approved by the Judge._**

**CERTIFICATE**

Opus 2 International Limited hereby certifies that the above is an accurate and complete record of the
Judgment or part thereof.

_Transcribed by Opus 2 International Limited_

_Official Court Reporters and Audio Transcribers_

**_5 New Street Square, London, EC4A 3BF_** **_Tel: 020 7831 5627_**
**_Fax: 020 7831 7737_**

**_CACD.ACO@opus2.digital_**

This transcript has been appro ed b the J dge


-----

**End of Document**


-----

