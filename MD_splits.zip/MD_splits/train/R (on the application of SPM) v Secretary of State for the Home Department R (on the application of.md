for Refugee Women) v Secretary of State for the Home D....

# R (on the application of SPM) v Secretary of State for the Home Department
 R (on the application of Women for Refugee Women) v Secretary of State for
 the Home Department [2022] EWHC 2007 (Admin)

Queen's Bench Division, Administrative Court (London)

Lang J

28 July 2022Judgment

**Alex Goodman and Miranda Butler (instructed by Duncan Lewis Solicitors Ltd) for the Claimants**

**Thomas Roe QC and Simon P G Murray (instructed by the** **Government Legal Department) for the**
**Defendant**

Hearing dates: 28 & 29 June 2022,

followed by written submissions dated 7 & 8 July 2022

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Mrs Justice Lang :**

1. In these two linked claims, the Claimants apply for judicial review of the arrangements made by the
Defendant for the provision of legal advice to detainees at Derwentside Immigration Removal Centre
(“IRC”), Consett, County Durham DH8 6QY (hereinafter “Derwentside”).

2. The Claimant in claim CO/606/2022 (hereinafter “SPM”) is a South African national, who has made an
unsuccessful claim for asylum in the United Kingdom (“UK”), and was detained by the Defendant at
Derwentside. She has now been released on bail.

3. The Claimant in claim CO/609/2022 (hereinafter “WRW”) is a charitable incorporated organisation which
specialises in supporting refugee women through advocacy, research and education.

4. Derwentside opened in November 2021, and the first detainees were moved there on 28 December
2021. It is a female-only IRC which has replaced Yarl's Wood IRC as the main IRC for detained women.
The Claimants contend that the Defendant's detention of women at Derwentside is unlawful because of the
inadequate provision of in-person legal advice, through a Detained Duty Advice Scheme (“DDAS”), and/or
legal aid for advice and representation. The relief sought includes an order prohibiting the detention of
women at Derwentside.

5. On 31 March 2022, permission to apply for judicial review was granted by Bourne J. on the papers, on
Grounds 1 to 3 in both claims, and Ground 5 in SPM's claim. Permission was refused on Ground 4 in
SPM's claim, and SPM's renewed application for permission on Ground 4 has been listed to be heard at
the substantive hearing.

**Grounds of challenge**


-----

for Refugee Women) v Secretary of State for the Home D....

6. SPM and WRW both rely upon Grounds 1 to 3, as follows.

**Ground 1**

7. A detainee's right to effective access to justice encompasses an unimpeded right to in-person legal
advice. This has not been available at Derwentside, thus creating a real risk that detainees do not have
effective access to justice. Therefore, in the absence of any express statutory authority for depriving
women of that right, the detention of women at Derwentside is ultra vires.

**Ground 2**

8. The absence of adequate in-person provision of legal advice at the main women's IRC at Derwentside
is discriminatory, on grounds of sex, as male IRCs all make provision for in-person legal advice. By section
[26(9) of the Equality Act 2010 (“EA 2010”), a person must not, in the exercise of a public function that is](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)
not the provision of a service to the public, do anything that constitutes discrimination. The Claimants
contend that the differential provision is either directly discriminatory, contrary to section 13 EA 2010 or
indirectly discriminatory, contrary to section 19 EA 2010.

**Ground 3**

9. The Defendant has not shown due regard to the public sector equality duty under section 149(1) EA
2010 in making the decision to detain women at Derwentside without adequate access to in-person legal
advice, and/or to continue to do so when initial proposals for DDAS surgeries were not implemented.

10. SPM also relies upon Grounds 4 and 5, as follows.

**Ground 4**

11. SPM's detention without access to in-person legal advice discriminated against her on the grounds of
sex in that she enjoyed substantially inferior access to legal advice than men who were detained. This was
contrary to Article 14 of the European Convention on Human Rights (“ECHR”), read together with Articles
2, 3, 4, 5, 6 or 8 ECHR. She claims damages pursuant to section 7 and 8 of the Human Rights Act 1998.

**Ground 5**

12. SPM's detention was unlawful, and constituted false imprisonment.

**Facts**

**SPM**

13. SPM, whose date of birth is 28 December 1974, came from South Africa to the UK on 5 December
2018, on a visitor's visa which was valid until 6 May 2019. SPM's native language is Zulu; she has a
limited knowledge of English. She claimed asylum on 22 February 2019. Her claim was refused by the
Defendant on 29 February 2020. Her appeal to the First-Tier Tribunal (“FTT”) was dismissed on 9
November 2021. She became appeal rights exhausted on 24 November 2021.

14. According to SPM, she was the victim of physical and mental abuse at the hands of her stepmother,
and forced to work from the age of 12 years. She was raped by her uncle. At the age of 14 or 16, she
entered into an arranged marriage with a man called Joshua, who forced her to work as a prostitute, and
act as a servant to his other wives. She escaped from this forced marriage and met a man called Samuel
who was the leader of a criminal gang. He and members of his gang subjected her to physical, mental and
sexual abuse. In 2014, SPM was stabbed by Samuel in the abdomen and has scarring as a result. In 2015
SPM was shot in the head by Samuel, which caused her to suffer from epilepsy and hearing impairment.
She now requires hearing aids and struggles to hear on the telephone. After the shooting, she went into
hiding, but she was followed and threatened by Samuel and his men.

15. In the FTT appeal, SPM was represented by Fountain Solicitors and Mr H. Dieu of counsel. FTT
Judge Lebasci concluded that SPM was not a credible witness and the evidence did not support a finding


-----

for Refugee Women) v Secretary of State for the Home D....

that SPM had been a victim of forced labour, forced marriage and violence. He dismissed her asylum and
human rights appeals. In the course of his decision, the FTT Judge said:

“47.9 It is the Appellant's evidence Samuel stabbed her with a knife in 2014 and she was admitted to
hospital for two months. She claims to have provided medical evidence and says she is unable to provide
anything else. At the hearing, the Appellant produced a photograph of the scar which she says she has
been left with as a result of this injury. The medical evidence provided …. appears to relate to a gunshot
injury in 2015 and therefore does not assist me in relation to the alleged incident in 2014. No evidence from
a health care professional in the UK has been provided regarding the existence of any scar which the
Appellant has or its likely cause.”

16. On 24 January 2022, SPM was detained when reporting in accordance with her reporting conditions,
and she was served with liability to removal papers (form RED.0001). According to SPM, her solicitors had
not informed her of the outcome of her appeal, despite her frequent attempts to contact them. Removal
directions were set for 7 February 2022.

17. On 27 January 2022, SPM was transferred to Derwentside. She claims she called Fountain Solicitors
but she could not reach them. After her arrival SPM was given a pamphlet which explained that she could
ask for legal advice. She claims she rang the legal advice telephone number in the pamphlet but did not
receive any response. She claims she asked the officers at Derwentside to assist her in finding a solicitor
but they did not do so. On 29 January 2022, SPM asked her partner to bring her medication and batteries
for her hearing aids. When he arrived at the detention centre he was refused entry. This led to SPM feeling
suicidal and being placed on an open Assessment Care in Detention and Teamwork (“ACDT”) plan (for
detained individuals at risk of suicide or self harm).

18. On 31 January 2022, still without any legal assistance, the Claimant wrote to the Defendant asking her
to reconsider her case. She explained that she was having difficulty finding a solicitor.

19. On 2 February 2022 a report under Rule 35 of the Detention Centre Rules 2001 (“a Rule 35 report”)
was drawn up by a member of the Derwentside healthcare team. It reported her concern that SPM was a
victim of domestic abuse and torture. On examination, SPM had a number of significant scars which were
consistent with her account. The report summarised her mental and physical health issues.

20. On 4 February 2022, the Defendant maintained SPM's detention in response to the Rule 35 report.
Also, on 4 February 2022 the Defendant wrote to SPM maintaining her decision to remove the Claimant to
South Africa. SPM was served with the IS151D Removal Papers and Immigration Factual Summary.

21. On 4 February 2022, SPM was referred to Duncan Lewis Solicitors by a member of WRW who had
spoken to her on the phone. Ms Lily Parrott, a solicitor at Duncan Lewis, immediately contacted SPM by
telephone. However, SPM and Ms Parrott had difficulty communicating because of SPM's hearing
impairment and limited English (no Zulu interpreter was available). As a result, Ms Parrott was unable to
obtain full instructions. At Ms Parrott's request, a member of IRC staff printed out the authority and legal
help forms and helped SPM scan and send the signed documents to Ms Parrott, along with the notice of
liability to removal and the Rule 35 report. Once Ms Parrott realised that SPM had a hearing impairment,
she was able to take further instructions from SPM on the telephone more effectively on several occasions
by speaking loudly directly into the telephone microphone which increased SPM's comprehension. Ms
Parrot also requested and received further relevant documents from the Home Office.

22. On 6 February 2022, Ms Parrott sent an urgent pre-action letter to the Defendant which (among other
matters) identified clear trafficking indicators which they submitted required investigation and referral into
the National Referral Mechanism (“NRM”).

23. On 6 February 2022 the Defendant maintained the removal directions and moved SPM to Colnbrook
IRC (near Heathrow airport), in preparation for her departure on 7 February 2022. On 7 February 2022, in
response to the pre-action correspondence from Ms Parrott, the Defendant cancelled the removal
directions for that day.


-----

for Refugee Women) v Secretary of State for the Home D....

24. Ms Parrott made an appointment to see SPM in person on 11 February 2022 at Colnbrook. However,
the appointment was cancelled as SPM was moved back to Derwentside by the Defendant on 10 February
2022 without prior notice. A medico-legal visit by an expert to document her scarring also had to be
cancelled because there was no expert available who could travel to Derwentside.

25. On 10 February 2022, SPM was referred into the NRM for identification as a victim of trafficking. On 16
February 2022 the Defendant made a positive Reasonable Grounds decision in relation to SPM, identifying
her as a potential victim of modern slavery. Her Conclusive Grounds decision is still awaited.

26. On 25 February 2022, SPM was released on immigration bail.

**Derwentside IRC**

27. Currently, there are IRCs at Brook House (Gatwick), Tinsley House (Gatwick), Colnbrook (Heathrow),
Harmondsworth (Heathrow), Yarl's Wood (Bedford), Derwentside (Co. Durham), and Dungavel
(Lanarkshire, Scotland). There is also a short term holding facility at Manchester. The only IRC which is
exclusively for females is Derwentside.

28. Previously Yarl's Wood was a female-only IRC but it was converted to a male-only IRC in 2021, so as
to provide additional capacity for male detainees, following the closure of Morton Hall IRC. On 23
November 2021, Derwentside was opened. The first detainees were moved to Derwentside on 28
December 2021.

29. The Defendant announced her intention to open Derwentside IRC on 1 March 2021.

30. An Equality Impact Assessment (“EIA”) was undertaken and published on 23 November 2021. It
explained that the closure of Morton Hall IRC, which had to be returned to the Ministry of Justice, removed
almost 400 male detention beds. Yarl's Wood, which has 372 beds, had low occupancy rates, and was
under-used. Changing Yarl's Wood to a male IRC would use the estate to its full potential and compensate
for the loss of beds at Morton Hall. The Defendant had procured a small specialised site with 84 beds at
Derwentside. One of the considerations for choosing that site was that it had previously been a Secure
Training Centre, rather than a prison or an IRC, “meaning that it could be easily developed to provide an
open and relaxed regime through which the needs of detained women could be met”. Implications of the
location of the new IRC were considered at pages 10 to 12.

31. At a Detention Sub-Group meeting organised by the Defendant on 29 June 2021, practitioner
representatives emphasised the need for in-person legal advice. Ms Frances Hardy, the Defendant's
representative for operational policy with Detention and Escorting Service, confirmed that procurement for
DDAS at Derwentside would be for in-person advice, which was a priority. However, provision would also
be made for full video-conferencing facilities for use when needed.

32. On 22 July 2021, the Legal Aid Agency (“LAA”) published an invitation to tender for DDAS services at
Derwentside from 1 January 2022. This included a requirement for 3 providers on the rota. Only 4 bids
were received. On 16 November 2021, the LAA announced that the procurement process for the DDAS at
Derwentside had been cancelled because insufficient compliant tenders had been received.

33. Also on 16 November 2021, the LAA announced that, from 1 January 2022, the LAA would continue
its existing contingency arrangements until June 2022. The contingency arrangements were that existing
providers at Yarl's Wood IRC (which included Duncan Lewis) were invited to express interest in providing
an additional 6 months provision at Derwentside. Two DDAS surgeries per week operated. Consistently
with the practice at other IRCs at that time, the default arrangement was to conduct the surgery by
telephone. Video-conferencing facilities were also available. In-person appointments could be requested
by detainees, but there was no requirement for providers to meet this request and in practice providers did
not do so.

34. On 24 March 2022, the LAA commenced a second tender process for DDAS advice at Derwentside.
To reduce the risk of receiving insufficient compliant bids, the previously increased requirement for a Law


-----

for Refugee Women) v Secretary of State for the Home D....

Society level 3 accredited caseworker was returned to the requirement for a level 2 caseworker. Also, the
requirement for a minimum of 3 compliant bids was removed.

35. On 23 June 2022, in response to a written parliamentary question, the Defendant stated that at
Derwentside, from 1 January 2022 to date, there had been 44 DDAS surgeries and 109 appointments had
taken place by phone and 63 by video-conferencing platforms.

36. The second tender process was completed in June 2022. There were three bidders who met the LAA's
requirements and have been awarded contracts. They are Proctor & Hobbs, based in Bradford; Clifton
Law, based in Coventry; and Shawstone Associates based in Hounslow.  The estimated car travel times to
Derwentside from these solicitors' offices are as follows: Bradford - 2 hours 13 minutes; Coventry - 3 hours
28 minutes; Hounslow - 5 hours 28 minutes.

37. Under the new contracts for Derwentside, which replaced the interim contingency arrangements with
effect from 1 July 2022, providers must “agree that they will deliver DDAS work at Derwentside IRC on a
face to face basis” (paragraph 2.8 of the “Information for Applicants” document). There are two surgeries
each week which the providers service on a rota basis.

38. In all IRCs, prior to the COVID-19 pandemic, DDAS surgeries were provided in-person. However,
when COVID-19 restrictions were introduced in March 2020, the LAA informed providers that DDAS
surgeries would be conducted over the telephone by default until further notice. Providers were advised
that they could attend the IRC in person in exceptional circumstances, by arrangement with the IRC. In
practice, providers rarely attended in-person for DDAS surgeries. Ms Druker, Senior Development
Manager of the LAA, was only aware of two providers conducting in-person surgeries as at 17 May 2022
(the date of her first witness statement).

39. As COVID-19 restrictions eased in 2022, providers were advised by email (e.g. in January and June
2022 at Brook House IRC) that, although surgeries were still being conducted over the telephone by
default, providers could now choose to conduct surgeries in person, by arrangement with the IRC. This did
not prevent individual providers arranging in-person appointments with detainees outside of a surgery
session, if they wished to do so.

40. On 23 May 2022, providers were advised by email by the LAA that, from 13 June 2022, detainees
would book a specific time to talk to a provider remotely, by telephone or video-conference. The email
advised “[t]his will bring remote conduct of surgeries more in accordance with the nature of face to face
appointments, which you can still choose to conduct”.

41. On 13 June 2022, in response to a written parliamentary question, the Defendant confirmed the
number of in-person legal advice visits that took place in all IRCs between 1 January to 13 June 2022,
which were as follows:

Brook House: DDAS visits: 4. Other legal visits: 112.

Colnbrook: DDAS visits: 0. Other legal visits: 80.

Derwentside: DDAS visits: 0. Other legal visits: 5 (or 6, according to one written answer).

Dungavel: DDAS visits: N/A. Other legal visits: 3.

Harmondsworth: DDAS visits: 0. Other legal visits: 145.

Tinsley House: DDS visits: 0. Other legal visits: 0.

Yarl's Wood: DDAS visits: 17. Other legal visits: 64.

**The Claimants' evidence on provision of legal services at Derwentside**

42. The Claimants contend that the three providers who have been awarded contracts for Derwentside
have insufficient immigration lawyers (estimated at no more than eight) to be able to meet the likely
demand at Derwentside, especially in respect of urgent applications. The LAA has tendered for two DDAS


-----

for Refugee Women) v Secretary of State for the Home D....

surgeries per week each seeing no more than ten women. Applying the LAA's estimate of a 20-25%
conversion rate into Controlled Work matter starts, this would lead to a potential annual client base of 208
– 260 clients. The DDAS providers will face lengthy journey times, making in-person appointments
impractical and uneconomic.

43. The Claimants' solicitors, Duncan Lewis, is the largest provider of legal aid in the UK, and has offices
across the country. It holds contracts with the Legal Aid Agency to provide advice and representation, and
initial DDAS advice, at all IRCs in England, except Derwentside, where it did not bid because of the
location. Unfortunately, it closed its office in Newcastle upon Tyne, which is only about 15 miles from
Derwentside, in 2021.

44. Dr Jo Wilding, a researcher on immigration and asylum instructed by the Claimants, has identified 12
legal aid offices within the area around Derwentside (Co Durham, Teesside, Tyne and Wear and
Gateshead). In the year 2020/21 those firms (plus Duncan Lewis in Newcastle upon Tyne which has since
closed) reported 1,705 matter starts. However, there were some 3,779 people receiving asylum support in
that area, as well as 94 people referred into the NRM. She infers that the providers have not been meeting
existing demand and therefore it is unlikely that they have potential additional capacity to undertake new
detention centre work. In her view, the regional shortage of legal aid capacity reflects the position for
England and Wales as a whole.

45. Dr Wilding has interviewed solicitors providing services remotely who have reported that it is more
difficult to obtain a client's paperwork when working remotely and that it is important to meet in person at
the outset, in order to be build a relationship of trust with the client.

46. Dr Juliet Cohen, an independent forensic physician instructed by the Claimants, is of the opinion that
in-person legal visits are essential for the detainees detained at Derwentside who are vulnerable women,
likely to be survivors of trafficking, sexual exploitation, domestic violence and gender-based violence. This
cohort of women will have difficulty in disclosing past experiences. In-person visits will facilitate better
trust, rapport, communication and disclosure, as well as providing support to manage distress, flashbacks
and potential crises.  A sensitive interviewer who can perceive and respond to non-verbal cues by offering
empathy and support, and reframing questions, will obtain more disclosure.

47. Dr Cohen is also of the opinion that, if a person has a disability due to hearing difficulties, learning
difficulty, learning disability or other cognitive impairment, she may be further disadvantaged if she is
unable to have an in-person assessment.

48. These assessments of the benefits of in-person legal advice are supported by Ms Shalini Patel,
Supervising Solicitor at Duncan Lewis, by reference to her own experience as a practitioner.

49. Similar evidence was given by Ms Gemma Lousley, Policy and Research Coordinator at WRW, based
on experience of working with women in immigration detention. Specifically, she has spoken to 16
detainees at Derwentside who were given legal advice over the telephone via the DDAS, and they were
not made aware that in-person appointments were a possibility. One detainee asked staff for an in-person
appointment, and was told to speak to the provider first on the telephone, who informed her that they could
only assist with a bail application. WRW found another solicitor to assist her with her asylum claim and she
has since been released (without an in-person visit). Two women were not aware of their right to legal
advice whilst detained, because of the lack of an interpreter, and one was removed from the UK without
accessing any legal assistance.

50. Ms Theresa Schleicher, a Casework Manager for Medical Justice, identified some systemic flaws in
assessment and safeguarding within IRCs, under the Rule 35 and Adults at Risk policy, including at
Derwentside.

**Legal aid provision in IRCs**

51. The statutory framework for legal aid is set out in the Legal Aid Sentencing and Punishment of
Offenders Act 2012 (“LASPO”), and regulations made thereunder.


-----

for Refugee Women) v Secretary of State for the Home D....

52. Section 1 of LASPO provides:

“1. Lord Chancellor's functions

(1) The Lord Chancellor must secure that legal aid is made available in accordance with this Part.

(2) In this Part “legal aid” means—

(a) civil legal services required to be made available under section 9 … (civil legal aid) …

……

(4) The Lord Chancellor may do anything which is calculated to facilitate, or is incidental or conducive to,
the carrying out of the Lord Chancellor's functions under this Part.”

53. By section 2 of LASPO, the Lord Chancellor may make such arrangements as he considers
appropriate for the purposes of carrying out the Lord Chancellor's functions under this Part, in particular by
establishing a body to provide legal services. The LAA is an executive agency of the Ministry of Justice.
Under section 4(2) of LASPO, it carries out functions on behalf of the Lord Chancellor and the Director of
Legal Aid Casework, appointed by the Lord Chancellor under section 4(1) of LASPO.

54. Section 27 of LASPO sets out general provisions in respect of the Lord Chancellor's duty under
section 1(1):

“27 Choice of provider of services etc.

(1) The Lord Chancellor's duty under section 1(1) does not include a duty to secure that, where services
are made available to an individual under this Part, they are made available by the means selected by the
individual.

(2) The Lord Chancellor may discharge that duty, in particular, by arranging for services to be provided by
telephone or by other electronic means.

…….”

55. Section 8(1) of LASPO defines the term “legal services”:

“8. Civil legal services

(1) In this Part “legal services” means the following type of services –

(a) providing advice as to how the law applies in particular circumstances,

(b) providing advice and assistance in relation to legal proceedings,

……”

56. Section 9 of LASPO describes the type of civil legal services which are generally available:

“9. General cases

(1) Civil legal services are to be available to an individual under this Part if—

(a) they are civil legal services described in Part 1 of Schedule 1, and

(b) the Director has determined that the individual qualifies for the services in accordance with this Part
(and has not withdrawn the determination).”

57. Part 1 of Schedule 1 to LASPO includes _inter alia_ civil legal services in relation to judicial review
(paragraph 19); detention under immigration powers (paragraph 25); immigration bail (paragraphs 26 –
27A); immigration in relation to rights to enter and remain in the UK (paragraph 30); immigration:
accommodation for asylum seekers (paragraph 31); and victims of slavery, servitude or forced or
compulsory labour (paragraph 32A).


-----

for Refugee Women) v Secretary of State for the Home D....

58. Even where civil legal services do not fall within Part 1 of Schedule 1, there may be exceptional case
funding available under section 10 of LASPO, where a failure to make the services available would be a
breach of the individual's Convention rights or retained enforceable EU rights.

59. Provision of legal aid is generally subject to a means test and a merits test: see sections 11 and 21 of
LASPO.

60. There are two categories of civil legal aid work – controlled work and licensed work, as set out in the
Civil Legal Aid (Procedure) Regulations 2012.

61. Controlled work primarily consists of Legal Help which, in broad terms, involves advice and assistance
outside of court or tribunal proceedings, as well as “Controlled Legal Representation” for bail applications
and statutory appeals in the FTT. Providers are given delegated authority to start controlled work without
having to apply to the LAA. Providers can decide whether the means and merits tests are satisfied and
grant funding accordingly. Where a provider opens a controlled work case, it is described as a Matter
Start.

62. Licensed work typically involves representation in litigation, including claims for judicial review, appeals
to the Upper Tribunal and other work in the Senior Courts. Licensed work requires authorisation from the
LAA. An application has to be made for a legal aid certificate to undertake such work.

63. According to Ms Druker (first witness statement, paragraph 17), the DDAS was put in place to ensure
that all detainees in an IRC have access to a legal adviser. Detainees may instead retain their own legal
adviser if they wish. Detainees may seek advice under the DDAS on multiple occasions, and may switch
between different providers, if they wish to do so.

64. Since 2018, DDAS services have been provided under the Standard Civil Contract 2018, as part of the
Immigration and Asylum Specification (Part E, paragraphs 8.109 - 8.117). According to Ms Druker, 77
providers were awarded schedules in 2018 to provide DDAS services. There are currently about 40
providers. Providers authorised to participate must be willing to undertake the full range of licensed and
controlled work (paragraph 8.110) and ensure that they have sufficient numbers of Caseworkers to meet
their rota obligations (paragraph 8.111).

65. Rotas are drawn up by the relevant teams at the LAA, and adjusted to take account of the fluctuations
in demand, for example, an increase in demand for legal advice when a chartered removal flight is
imminent. Appointments are arranged by the IRC. According to Ms Druker, should a detainee notify a
member of IRC staff that they have been unable to secure legal advice within 5 days of their removal date,
staff should contact the LAA to arrange an emergency appointment.

66. Paragraphs 8.117 to 8.122 of the Immigration and Asylum Specification provide as follows:

“8.117 You may provide a maximum of 30 minutes advice to a Client at a Detained Duty Advice Surgery
without reference to the Client's financial eligibility.

8.118 The purpose of the advice session is to ascertain the basic facts of the Matter and to make a
decision as to whether the Matter requires further investigation or whether further action can be taken.

…..

8.120 On the conclusion of the Client's 30 minute advice session you must make a determination as to
whether the Client qualifies for civil legal services … to ascertain whether you are able to continue to
advise the Client under Controlled Work…

8.121 You must record the time spent with each Client at a Detained Duty Advice Surgery on the Contract
Report Form specified by us.

8.122 You must ensure the client is given adequate information in a written format at the end of the
Detained Duty Advice Surgery whether or not the matter requires further investigation. This information
should sufficiently address the outcome of the Detained Duty Advice Surgery with details of the name of
the Case orker ho has ad ised the client ”


-----

for Refugee Women) v Secretary of State for the Home D....

67. Remuneration of providers is governed by the Civil Legal Aid (Remuneration Regulations) 2013 (“the
Remuneration Regulations”) and the Immigration and Asylum Specification in the 2018 Standard Civil
Contract.

68. For DDAS providers, the Remuneration Regulations provide that £360 is the standard fee for advising
5 or more clients and £180 is the standard fee for advising fewer than 5 clients (Table 4(d), paragraph 3,
Part 1 of Schedule 1).  Providers are not remunerated for travel or waiting time incurred when attending a
DDAS. But disbursements, including travel expenses, and interpreter expenses, are recoverable
(paragraph 8.47 of the Immigration and Asylum Specification).

69. About 20 to 25 percent of detainees seen at a DDAS surgery result in a controlled work Matter Start.
In such cases, the additional remuneration is determined under Controlled Work rules. Travel time and
travel expenses are paid provided that they are “reasonable” (paragraph 8.46 of the Immigration and
Asylum Specification). Guidance from the LAA indicates that, whilst there is no upper limit on travel time,
round trips of more than 5 hours will not be considered reasonable unless clearly justified.

70. Mr Hossain, Director of Public Law and Immigration at Duncan Lewis, describes the financial
pressures on legal aid solicitors, and the concerns about remuneration for travel time and expenses
incurred when visiting Derwentside.

**Ground 1**

**Submissions**

71. The Claimants submit that a detainee's right to effective access to justice encompasses an unimpeded
right to in-person legal advice. In practice, that is unavailable at Derwentside because the IRC is located
too far away from the relatively small pool of solicitors who provide legal aid advice and representation in
immigration and asylum.

72. The principle of legality means that any hindrance or impediment to the right of access to a lawyer
requires clear authorisation by Parliament. Access to justice must be effective in a real, not merely
theoretical, sense. Advice provided solely over the telephone or by video-conference is not effective in the
real world, as required by law. It is particularly unsuitable for detainees with disabilities (such as deafness
in the case of SPM), and those women who are mentally vulnerable who have difficulty in disclosing their
experiences of trafficking, sexual exploitation, domestic violence and gender-based violence. The
Defendant's safeguarding mechanisms are not directed at securing access to justice and, in any event,
those mechanisms have many shortcomings.

73. The Defendant submits that she made a lawful policy decision to open Derwentside as an IRC, for the
reasons set out in the EIA. She submits that there could be no valid objection to the decision not to locate
it near London. Its location – within 15 miles of the major cities of Newcastle upon Tyne and Durham – is
not “remote” as the Claimants allege.

74. The Defendant argues that the principle of legality does not apply as there is no fundamental common
law right to be provided with legal aid. The nature and extent of the provision of legal aid is a matter for
Parliament and the Lord Chancellor. Subsection 27(1) of LASPO provides that, where legal aid is granted
to an individual, the Lord Chancellor is not obliged to make services available by the means selected by
that individual. Subsection 27(2) gives the Lord Chancellor power to provide services by telephone or other
electronic means. Thus, provision of legal aid services by telephone and via video-conference is plainly
lawful.

75. It is significant that the Claimants have not joined the Lord Chancellor as a party, nor challenged the
provision of legal aid at Derwentside as being in breach of the Lord Chancellor's duties under LASPO.

76. Arrangements for the provision of legal services at Derwentside are not such as to give rise to a real
risk of a denial of access to justice. Whilst in-person visits may be preferable in certain circumstances,
there is insufficient evidence to justify a finding that its absence gives rise generally to a denial of access to
justice


-----

for Refugee Women) v Secretary of State for the Home D....

**Conclusions**

77. The Defendant has extensive statutory powers to detain people for immigration purposes. Schedule 2,
paragraph 16 to the Immigration Act 1971 confers a power on an immigration officer to detain a person
pending his examination; pending a decision to give or refuse him leave to enter; pending a decision to
give removal directions and pending removal in pursuance of such directions. Section 62 of the Nationality
Immigration and Asylum Act 2002 provides a further supplementary power to detain pending administrative
removal. Schedule 3, paragraph 2 of IA 1971 provides for the detention of individuals liable to deportation.
Section 36 of the UK Borders Act 2007 makes further provision as to the detention of foreign nationals
convicted of offences.

[78. Section 153 of the Immigration and Asylum Act 1999 (“IAA 1999”) provides for the management of](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-HC70-TWPY-Y18P-00000-00&context=1519360)
IRCs. Further provision is made in the _[Nationality, Immigration and Asylum Act 2002 for reception,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61J0-TWPY-Y1K3-00000-00&context=1519360)_
accommodation and removal centres. The Detention Centre Rules 2001 provide as follows:

“26. Outside contacts

(2) A detained person shall be entitled to establish and maintain, as far as are possible, such relations with
persons and agencies outside the detention centre as he may wish, save to the extent that such relations
prejudice interests of security or safety.”

“30. Legal advisers and representatives

The legal adviser or representative of any detained person in any legal proceedings shall be afforded
reasonable facilities for interviewing him in confidence, save that any such interview may be in the sight of
an officer.”

79. The Defendant accepts that none of these statutory provisions authorises hindrance or impediment to
a detainee's access to legal advice, whether in-person or remote. Indeed, the Detention Centre Rules
expressly identify a right for detainees to enjoy relationships with agencies outside the detention centre and
receive confidential legal visits.

80. The Defendant also has statutory power to designate the place of detention, in this case, Derwentside.
Paragraph 18 of Schedule 2 to the Immigration Act 1971 provides:

“(1) Persons may be detained under paragraph 16 above in such places as the Secretary of State may
direct (when not detained in accordance with paragraph 16 on board a ship or aircraft).”

81. The Defendant accepts that when Parliament authorised her to detain relevant persons under
paragraph 18 of Schedule 2 to the Immigration Act 1971, it did not intend to authorise her to detain them in
a place to which lawyers had no access.

82. The Claimants have not joined the Lord Chancellor to this claim, and confirmed in their reply that they
do not allege any breach of duty by the Lord Chancellor in the provision of legal aid. Thus, it is not in
dispute that the Lord Chancellor has discharged his duty, under section 1 of LASPO to “secure that legal
aid is made available” at Derwentside under section 1 of LASPO.

83. The Lord Chancellor has broad discretionary powers on how to discharge his duties and functions.
Section 1(4) of LASPO provides:

“The Lord Chancellor may do anything which is calculated to facilitate, or is incidental or conducive to, the
carrying out of the Lord Chancellor's functions under this Part.”

84. Section 27 of LASPO permits the Lord Chancellor to decide how best to discharge his duty to provide
services, which may include provision of services by video-conferencing and telephone.

“27 Choice of provider of services etc.

(1) The Lord Chancellor's duty under section 1(1) does not include a duty to secure that, where services
are made available to an individual under this Part, they are made available by the means selected by the
individual


-----

for Refugee Women) v Secretary of State for the Home D....

(2) The Lord Chancellor may discharge that duty, in particular, by arranging for services to be provided by
telephone or by other electronic means.

…….”

85. I was referred to a considerable body of case law by the parties, which I have considered. In R (Project
_for the Registration of Children as British Citizens) v Secretary of State for the Home Department [2022]_
_UKSC 3, [2022] 2 WLR 343, Lord Hodge considered the principle of legality at [33], but held it was not_
engaged in that case.

86. In _R (Unison) v Lord Chancellor [2017] UKSC 51, [2020] AC 869, the Supreme Court held that the_
Employment Tribunal and Employment Fees Tribunal Order 2013, effectively prevented access to justice
and was therefore unlawful at common law. After considering the general right of access to the courts,
Lord Reed reviewed the authorities on impediments to access at [78] to [82]:

“78. Most of the cases so far mentioned were concerned with barriers to the bringing of proceedings. But
impediments to the right of access to the courts can constitute a serious hindrance even if they do not
make access completely impossible. More recent authorities make it clear that any hindrance or
impediment by the executive requires clear authorisation by Parliament. Examples include _Raymond v_
_Honey_ [1983] 1 AC 1, where prison rules requiring a prison governor to delay forwarding a prisoner's
application to the courts, until the matter complained of had been the subject of an internal investigation,
were held to be ultra vires; and R v Secretary of State for the Home Department, Ex p Anderson [1984] QB
778, where rules which prevented a prisoner from obtaining legal advice in connection with proceedings
that he wished to undertake, until he had raised his complaint internally, were also held to be ultra vires.

79. The court's approach in these cases was to ask itself whether the impediment or hindrance in question
had been clearly authorised by primary legislation. In _Raymond v Honey, for example, Lord Wilberforce_
stated at p 13 that the statutory power relied on (a power to make rules for the management of prisons)
was “quite insufficient to authorise hindrance or interference with so basic a right” as the right to have
unimpeded access to a court. Lord Bridge of Harwich added at p 14 that “a citizen's right to unimpeded
access to the courts can only be taken away by express enactment.”

80. Even where a statutory power authorises an intrusion upon the right of access to the courts, it is
interpreted as authorising only such a degree of intrusion as is reasonably necessary to fulfil the objective
of the provision in question. This principle was developed in a series of cases concerned with prisoners.
The first was _R v Secretary of State for the Home Department, Ex p Leech_ [1994] QB 198, which
concerned a prison rule under which letters between a prisoner and a solicitor could be read, and stopped
if they were of inordinate length or otherwise objectionable. The rule did not apply where the letter related
to proceedings already commenced, but the Court of Appeal accepted that it nevertheless created an
impediment to the exercise of the right of access to justice in so far as it applied to prisoners who were
seeking legal advice in connection with possible future proceedings. The question was whether the rule
was authorised by a statutory power to make rules for the regulation of prisons. That depended on whether
an objective need for such a rule, in the interests of the regulation of prisons, could be demonstrated. As
Steyn LJ, giving the judgment of the court, stated at p 212:

“The question is whether there is a self-evident and pressing need for an unrestricted power to read letters
between a prisoner and a solicitor and a power to stop such letters on the ground of prolixity and
objectionability.”

The evidence established merely a need to check that the correspondence was bona fide legal
correspondence. Steyn LJ concluded:

“By way of summary, we accept that [the statutory provision] by necessary implication authorises some
screening of correspondence passing between a prisoner and a solicitor. The authorised intrusion must,
however, be the minimum necessary to ensure that the correspondence is in truth bona fide legal
correspondence.” (p 217)


-----

for Refugee Women) v Secretary of State for the Home D....

81. The decision in Leech was endorsed and approved by the House of Lords in R v Secretary of State for
_the Home Department, Ex p Simms [2000] 2 AC 115, which arose from a prohibition on visits to serving_
prisoners by journalists seeking to investigate whether the prisoners had, as they claimed, been wrongly
convicted, except on terms which precluded the journalists from making professional use of the material
obtained during such visits. The House considered whether the Home Secretary's evidence showed a
pressing need for a measure which restricted prisoners' attempts to gain access to justice, and found none.

82. A similar approach was adopted in _R (Daly) v Secretary of State for the Home Department [2001]_
_UKHL 26; [2001] 2 AC 532, which concerned a policy that prisoners must be absent from their cells when_
legal correspondence kept there was examined. Lord Bingham of Cornhill, with whose speech the other
members of the House agreed, summarised the effect of the earlier authorities concerning prisoners,
including Raymond v Honey, Ex p Anderson, and Ex p Leech:

“Among the rights which, in part at least, survive [imprisonment] are three important rights, closely related
but free standing, each of them calling for appropriate legal protection: the right of access to a court; the
right of access to legal advice; and the right to communicate confidentially with a legal adviser under the
seal of legal professional privilege. Such rights may be curtailed only by clear and express words, and then
only to the extent reasonably necessary to meet the ends which justify the curtailment.” (pp 537-538)

After an examination of the evidence, Lord Bingham concluded that “the policy provides for a degree of
intrusion into the privileged legal correspondence of prisoners which is greater than is justified by the
objectives the policy is intended to serve, and so violates the common law rights of prisoners” (para 21).
Since that degree of intrusion was not expressly authorised by the relevant statutory provision, it followed
that the Secretary of State had no power to lay down the policy.”

87. Applying those principles to the Fees Order, he concluded as follows:

“87. The Lord Chancellor cannot, however, lawfully impose whatever fees he chooses in order to achieve
those purposes. It follows from the authorities cited that the Fees Order will be ultra vires if there is a real
risk that persons will effectively be prevented from having access to justice. That will be so because
section 42 of the 2007 Act contains no words authorising the prevention of access to the relevant tribunals.
That is indeed accepted by the Lord Chancellor.

…

93. … The question whether fees effectively prevent access to justice must be decided according to the
likely impact of the fees on behaviour in the real world. Fees must therefore be affordable not in a
theoretical sense, but in the sense that they can reasonably be afforded. Where households on low to
middle incomes can only afford fees by sacrificing the ordinary and reasonable expenditure required to
maintain what would generally be regarded as an acceptable standard of living, the fees cannot be
regarded as affordable.”

88. The principles in Unison were applied by the Court of Appeal in R (FB (Afghanistan)) v Secretary of
_State for the Home Department [2020] EWCA Civ 1338, [2021] 2 WLR 839, when it held that the_
Defendant's removals policy exposed migrants to an immediate risk of removal, without an opportunity to
challenge the removal before a court, and thus interfered with the fundamental right to effective access to
justice in real world conditions, including the right to be afforded sufficient time to take and act upon legal
advice. Hickinbottom LJ reviewed the authorities at [91] – [95]:

“91. The importance of the rule of law, and the role of access to justice in maintaining the rule of law, was
recently considered by Lord Reed JSC (with whom the rest of the Supreme Court agreed) in R (UNISON) v
_Lord Chancellor [2017] UKSC 51; [2017] 3 WLR 409 at [68]:_

“At the heart of the concept of the rule of law is the idea that society is governed by law. Parliament exists
primarily in order to make laws for society in this country. Democratic procedures exist primarily in order to
ensure that the Parliament which makes those laws includes Members of Parliament who are chosen by
the people of this country and are accountable to them. Courts exist in order to ensure that the laws made


-----

for Refugee Women) v Secretary of State for the Home D....

by Parliament, and the common law created by the courts themselves, are applied and enforced. That role
includes ensuring that the executive branch of government carries out its functions in accordance with the
law. In order for the courts to perform that role, people must in principle have unimpeded access to them.
Without such access, laws are liable to become a dead letter, the work done by Parliament may be
rendered nugatory, and the democratic election of Members of Parliament may become a meaningless
charade…”.

Thus, the right to access to justice is an inevitable consequence of the rule of law: as such, it is a
fundamental principle in any democratic society which more general rights of procedural fairness are to a
large extent designed to support and protect (see, e.g., _R (CPRE Kent) v Dover District Council [2017]_
_UKSC 79: [2018] 1 WLR 108 at [54] per Lord Carnwath of Notting Hill JSC, and_ _R (Citizens UK) v_
_Secretary of State for the Home Department [2018] EWCA Civ 1812; [2018] 4 WLR 123 at [83-[84] per_
Singh LJ).

92. The right of access to justice means, of course, not merely theoretical but effective access in the real
world (UNISON at [85] and [93]): it has thus been said that “the accessibility of a remedy in practice is
decisive when assessing its effectiveness” (MSS v Belgium and Greece (2011) 53 EHRR 2 (European
Court of Human Rights (“ECtHR”) Application No 30696/09) at [318], emphasis added). This means that a
person must not only have the right to access the court in the direct sense, but also the right to access
legal advice if, without such advice, access to justice would be compromised (R (Daly) v Secretary of State
_for the Home Department [2001] UKHL 26; [2001] 2 AC 532 at [5] per Lord Bingham of Cornhill; and MSS_
at [319]). For these rights to be effective, as the common law requires them to be, an individual must be
allowed sufficient time to take and act on legal advice.

93. So, where tribunal rules set a “timetable for the conduct of.. appeals [that was] so tight that it [was]
inevitable that a significant number of appellants [would] be denied a fair opportunity to present their
cases…”, those rules were held to be unlawful (The Lord Chancellor v R (Detention Action) [2015] EWCA
_Civ 840; [2015] 1 WLR 5341, the quotation being from [38] per Lord Dyson MR)._

94. Even closer to this case, in the 2010 Medical Justice case at [43], Silber J said that effective legal
advice and assistance requires sufficient time to be given between service of notice of a decision by the
Secretary of State which puts the individual at risk of removal (in that case, notice of removal directions)
and removal itself:

“… to find and instruct a lawyer who:

(i) is _ready to provide legal advice in the limited time available prior to removal, which might also entail_
ensuring that the provider of the advice would be paid;

(ii) _is willing and able to provide legal advice under the seal of professional privilege in the limited time_
available prior to removal which might also entail being able to find and locate all relevant documents; and

(iii) (if appropriate) would after providing the relevant advice be ready, willing and able in the limited time
available prior to removal to challenge the removal directions.” (emphasis in the original)

On appeal, upholding Silber J, Sullivan LJ said (the 2010 Medical Justice case (CA) at [19]):

“I refer to 'effective' legal advice and assistance because the mere availability of legal advice and
assistance is of no practical value if the time scale for removal is so short that it does not enable a lawyer
to take instructions from the person who is to be removed and, if appropriate, to challenge the lawfulness
of the removal directions before they take effect.”

95. In that case, the challenge to the part of the Secretary of State's policy which allowed for removal less
than 72 hours after notification of removal directions was a systemic challenge, i.e. it contended that the
risk to the right of access to justice was inherent in the policy itself and it was not dependent upon the
claimant showing that particular irregular migrants who fell within the scope of this part of the policy had in
fact been denied access to a court. As Sullivan LJ put it (at [21]):


-----

for Refugee Women) v Secretary of State for the Home D....

“On the assumption that legal advice would be available Silber J was concerned with the practicalities of
obtaining that advice in sufficient time for it to be effective. Would there be a sufficient time between the
service of the removal directions and the removal itself to enable a legal adviser to challenge the
lawfulness of the removal directions? If the answer to that question was no, time would not be sufficient,
then the… policy abrogates the right of access to the courts to challenge the lawfulness of the removal
directions.””

89. The Supreme Court recently endorsed the approach adopted in Unison and FB (Afghanistan) in R(A) v
_Secretary of State for the Home Department [2021] UKSC 37, [2021] 1 WLR 3931where Lord Sales and_
Lord Burnett held:

“80. …… In UNISON this court held that there is a fundamental right under the common law of access to
justice, meaning effective access to courts and tribunals to seek to vindicate legal rights, which means that
the executive is under a legal obligation not to introduce legal impediments in the way of such access save
on the basis of clear legal authority: see the discussion by Lord Reed in _UNISON at paras 66-98. The_
decision was concerned with the introduction of an order imposing fees to bring claims in an employment
tribunal, but the principles stated are of general application. The test applied was whether the making of
the order created “a real risk that persons will effectively be prevented from having access to justice” (para
[87; see also para 85, where R (Hillingdon Borough Council) v Lord Chancellor [2008] EWHC 2683; [2009]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G3GN-00000-00&context=1519360)
_[1 FLR 39 is referred to as authority for such a test). As Lord Reed observed (para 91), it is sufficient if a](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5SNJ-KMB1-DY9F-G3GN-00000-00&context=1519360)_
real risk of prevention of access to justice is demonstrated. This means that, in order to test the lawfulness
of a measure on this basis, it is legitimate to have regard to evidence regarding its likely impact and the
court has to make an overall evaluative assessment whether this legal standard is met or not (and statistics
might have a part to play in making such an assessment). In UNISON, this court held that the fees order
was unlawful on this basis.

81. This is also, in effect, the question which the court asked itself in Director of Legal Aid Casework in
relation to the application form, when it assessed whether the form created an unacceptable risk of
unfairness in the form of preventing access to legal aid (and hence preventing access to the courts) in
cases where there was an obligation to provide legal aid. With the benefit of the statement of the relevant
principle in UNISON, no doubt the issue would now be formulated with more precision.

82. Similar issues arose in _R (Medical Justice) v Secretary of State for the Home Department [2011]_
_EWCA Civ 1710, in relation to measures (which happened to be set out in a policy document) limiting the_
time available to an immigrant to obtain legal advice and assistance to challenge removal directions, and in
_R (Howard League for Penal Reform) v Lord Chancellor_ _[2017] EWCA Civ 244; [2017] 4 WLR 92, in_
relation to the lawfulness of removal of legal aid from certain categories of legal claims affecting prisoners.
In both cases, as in Director of Legal Aid Casework, the court referred to Refugee Legal Centre and
framed the question for itself in terms of whether the system was inherently unfair; but in both cases the
substance of the analysis was whether there had been an unlawful infringement of the constitutional right
of access to a court or tribunal. In our view, the formulation of the test in Refugee Legal Centre is not a
helpful way of approaching that issue. In future, the framework of analysis in UNISON should be applied
instead.

83. This is indeed what occurred in R (FB (Afghanistan)) v Secretary of State for the Home Department

_[2020] EWCA Civ 1338; [2021] 2 WLR 839. The case concerned a challenge to the lawfulness of another_
scheme to limit the time for immigrants to challenge decisions to remove them before they were
implemented. The Court of Appeal upheld the challenge on the ground that the scheme created an
excessive impediment in the way of immigrants gaining access to a court to challenge the lawfulness of
such decisions in their cases, ie by reference to the principle in _UNISON: see, in particular, paras 142_
(Hickinbottom LJ), 170 (Coulson LJ) and 185 and 196 (Lord Burnett of Maldon CJ). The more general
approach in Refugee Legal Centre, Medical Justice, Tabbakh and Detention Action was referred to, but its
effect in those cases was explained in terms of the access to justice principle examined in UNISON (see, in
particular, paras 120-126, per Hickinbottom LJ, and para 177, per Lord Burnett CJ). In our view, on a
proper understanding of the legal principles discussed above the wider formulation of a test of systemic


-----

for Refugee Women) v Secretary of State for the Home D....

inherent unfairness in relation to a legal scheme which has been taken to be laid down in the line of cases
stemming from Refugee Legal Centre will in most, if not all, circumstances dissolve into the Gillick principle
and the UNISON principle, each with its own precise focus.”

90. The Defendant drew a distinction between the fundamental common law right of access to the courts,
and the statutory right to civil legal aid under LASPO, which confers a broad discretion on the Lord
Chancellor and the LAA, and may be restricted without infringing fundamental common law rights.

91. The Defendant relied on the case of R v The Lord Chancellor ex p Witham [1998] QB 575, in which the
court quashed a decision to abolish fee remission on court fees for the needy. Laws J. said, at 586D-E:

“[Counsel for the Lord Chancellor] submitted that it was for the Lord Chancellor's discretion to decide what
litigation should be supported by tax payers' money and what should not. As regards the expenses of legal
representation, I am sure that is right. Payment out of legal aid of lawyer's fees to conduct litigation is a
subsidy by the state which is in general well within the power of the executive, subject to the relevant main
legislation, to regulate. But the impost of court fees, is, to my mind, subject to wholly different
considerations. They are the cost of going to the court at all, lawyers or no lawyers. They are not at the
choice of the litigant, who may by contrast choose how much to spend on his lawyers.”

92. The Defendant also referred to the case of _R. v Legal Aid Board ex p Duncan CO/4807/00, [2000]_
C.O.D. 159. There the Divisional Court rejected a complaint that a scheme for legal representation on legal
aid in mental health tribunals, which was said to have various defects liable to lead to injustice, infringed
the common law right of access to a court. Brooke LJ cited the judgment of Laws J. in Witham and held:

“460. ……There is no fundamental right to choose a legal representative whom the potential client cannot
afford to pay, because there is no duty on the lawyer to give his/her services free of charge or at a fee at a
level the potential client can afford. Still less is there any general duty on the tax payer to supplement the
means of the potential client so that the potential client is able to meet the fees of the legal representative
that he/she would wish to choose.

……

468. In our judgment, in so far as the applicants' case on the illegality of the new regime is based on the
infringement of a fundamental common law right of those eligible for legal aid, it fails because there is no
common law right to choose one's legal representative of the kind which the applicant would have to
establish in order for this part of their case to succeed.”

93. In response, the Claimant relied upon the case of _R (Howard League for Penal Reform v Lord_
_Chancellor [2017] EWCA Civ 244, [2017] 4 WLR 92, in which the Court of Appeal held that a decision to_
remove legal aid from certain categories of prisoners was unlawful. Beatson LJ said:

“(f) Access to legal advice and representation:

42. Bearing in mind what fairness is likely to require where the issue is factually or legally complex or the
consequences for the individual are serious, the common law rules of fairness will generally entitle a
person to have access to legal advice and to be able to communicate confidentially with a legal adviser as
part of the fundamental right of access to justice and to the courts: see R v Secretary of State for the Home
_Department, ex p Anderson_ [1984] QB 778, at 790; _R (Daly) v Secretary of State for Home Department_

_[2001] UKHL 26, [2001] 2 AC 532 at [5] and [30] (Lord Bingham and Lord Cooke of Thorndon); and_ _R_
_(Medical Justice) v Ministry of Justice [2010] EWHC 1925 (Admin) at [43] – [45] (Silber J). The importance_
of legal advice was referred to in R (Gudanaviciene and others) v Director of Legal Aid Casework and Lord
_Chancellor [2014] EWCA Civ. 1622, [2015] 1 WLR 2247which we consider below. In its discussion of the_
potential of an inquisitorial approach by the decision-making body to ensure that a person has effective
access to justice, the court, in a judgment handed down by Lord Dyson, stated at [185], that “in some
circumstances, legal advice to the litigant in person may be more important than legal representation at the
hearing for ensuring effective access to justice”.

…


-----

for Refugee Women) v Secretary of State for the Home D....

(g) Access to legal aid:

44. The decision in R (Gudanaviciene and others) v Director of Legal Aid Casework and Lord Chancellor
shows that the factors to which we have referred are also in play in the determination of whether, and, if so
when, fairness requires the provision of legal aid. Before considering Gudanaviciene's case, however, we
refer to the position under the ECHR.

45. In Airey v Ireland (1979-80) 2 EHRR 305, the ECtHR, dealing with proceedings for judicial separation
in the Irish High Court, stated at [24] and [26] that where a person is unable to “present her case properly
and satisfactorily” and “effectively conduct” it and cannot afford to pay for a legal representative, the state
is under an obligation to provide legal aid for legal representation. The ECtHR emphasised that this is not
so in all cases and that “in certain eventualities” the possibility of appearing without a lawyer's assistance
will meet the requirements of Article 6 and secure adequate access, even to the High Court. It referred to
similar factors to those considered in the decisions of appellate courts in this jurisdiction, such as the
complexity of the law, the procedure, or the case, and the ability of the individual to test the evidence, and
also to the fact that the requirements of Article 6 can be met by other means, for example the simplification
of procedure. This chimes with the statement of Lord Reed in Osborn's case (at [55]) that one of the ways
in which the detailed provisions of domestic law guarantee the right to a fair trial under Article 6 ECHR is
"the law relating to legal aid", but, as in _Airey's_ case, recognising that this can and is also done in other
ways, including the law of evidence and procedure and the principles of administrative law.

46. The ECtHR recognised that the availability and scope of legal aid was a question of social and
economic rights and depended in part on the financial situation in the State in question. It considered that
this was not a decisive factor against the provision of legal aid because of the need “to safeguard the
individual in a real and practical way as regards those areas” with which the ECHR deals. Other
Strasbourg cases have had some regard to the fact that limited resources mean that a machinery is
needed to select cases that are to be funded: see the authorities referred to by Laws LJ in Director of Legal
_Aid Casework v IS [2016] EWCA Civ 464, [2016] 1 WLR 4733 at [55] and [61] – [64]. Those authorities,_
however, also refer to the need for the system of selection to be "reasoned and proportionate" and thus to
provide protection from arbitrariness: see _Eckardt v Germany_ (2007) 45 EHRR SE7 cited by Laws LJ at

[64].”

94. Howard was considered by the Supreme Court in A (see above) where Lord Sales and Lord Burnett
held, at [82], that the substance of the analysis was whether there had been an unlawful infringement of
the constitutional right of access to a court or tribunal, and the Unison principle was to be adopted rather
than a test of inherent unfairness.

95. In the light of the judgments in Howard and A, I consider that the law has evolved since Witham and
that a lack of legal aid provision can, in certain circumstances (for example, where a person is held in
detention), constitute an obstacle to the fundamental common law right of access to justice.

96. Applying these principles to the facts of this case. I will consider in turn: (1) the Defendant's decision
to open a female-only IRC at Derwentside in place of Yarl's Wood IRC and the proposals for legal aid
services in 2021; (2) the interim contingency arrangements from January to June 2022; and (3) the
permanent arrangements from July 2022 onwards.

_(1) The Defendant's decision to open a female-only IRC at Derwentside in place of Yarl's Wood IRC and_
_the proposals for legal aid services in 2021_

97. The Claimants do not mount a direct challenge to the Defendant's decision to transfer women
detainees from Yarl's Wood to Derwentside in this claim. However, the decision is challenged indirectly, by
a sustained attack on the unsuitability of Derwentside because of its location in the north-east of England.
It is significant that the relief that the Claimants seek in this case includes an order to prohibit the
continuing use of Derwentside as an IRC for all women detainees.

98. The Defendant has a broad statutory power to determine where persons should be detained, under
paragraph 18 of Schedule 2 to the Immigration Act 1971 Morton Hall IRC had to be returned to the


-----

for Refugee Women) v Secretary of State for the Home D....

Ministry of Justice, with the loss of almost 400 male detention beds. Yarl's Wood (previously a female-only
IRC) has 372 beds. It had low occupancy rates, and was under-used. Changing Yarl's Wood to a male
IRC enabled the space to be used to its full potential and it compensated for the loss of beds at Morton
Hall. The Defendant procured a small specialised site with 84 beds at Derwentside. One of the
considerations for choosing that site was that it had previously been a Secure Training Centre, rather than
a prison or an IRC, and so was more suitable for female detainees. Other sites were considered but were
discounted due to the current standard or use of the accommodation.

99. Derwentside was deemed the most appropriate option because it was already government-owned and
of the requisite standard, which made it the best option given the short timescales, cost-effectiveness and
the standard of accommodation required. The advantages of the site were considered to outweigh any
disadvantages that might arise from its location in the north-east. In the light of these considerations, I
consider that the Defendant's decision to transfer women detainees from Yarl's Wood IRC to Derwentside
was a lawful exercise of her discretion under her statutory powers.

100. From the outset, it was the stated intention of the Defendant and the LAA to provide the same legal
services at Derwentside as existed at Yarl's Wood IRC and the other IRCs. DDAS surgeries would operate
regularly, providing free legal advice to detainees. Thereafter, providers would be able to offer further legal
services under the controlled work and licensed work schemes, as appropriate. At a Detention Sub-Group
meeting on 29 June 2021, the Defendant's representative confirmed that procurement at Derwentside
would be for in-person advice, with video-conferencing facilities also available.

101. The LAA's first tendering process for contracts to provide the DDAS surgeries at Derwentside, from 1
January 2022, only attracted 4 bids, none of which were compliant. The criteria in the tender were agreed
with stakeholders. Although according to Jo Wilding's research, there are some 12 firms of solicitors with
legal aid contracts in the area around Derwentside, none of them made a bid, or a compliant bid, for the
DDAS contract at Derwentside, indicating a lack of interest or capacity to undertake the work. The LAA
cancelled the procurement process on 16 November 2021.

102. At the same time, the LAA announced that it intended to implement its contingency arrangements so
as to provide access to DDAS services at Derwentside from 1 January 2022

_(2) The interim contingency arrangements from January to June 2022_

103. To ensure access to DDAS services at Derwentside, while another tendering process was set in
train, interim contingency arrangements operated between January and June 2022. Existing DDAS
providers at Yarl's Wood IRC were invited to hold DDAS surgeries at Derwentside. Consistently with the
practice at other IRCs at that time, because of the COVID-19 pandemic, the default arrangement was to
conduct the surgery by telephone. Video-conferencing facilities were also available. In-person
appointments could be requested by detainees, but there was no requirement for providers to meet this
request.

104. On 23 June 2022, in response to a written parliamentary question, the Defendant stated that at
Derwentside, from 1 January 2022 to June 2022, there had been 44 DDAS surgeries. 109 appointments
had taken place by phone and 63 by video-conferencing platforms. There were no DDAS surgeries held inperson at Derwentside during this period.  There were either 5 or 6 legal visits (other than DDAS
surgeries) to Derwentside during this period.

105. In considering the lawfulness of the provision of legal services at Derwentside during this period, I
take into account that, at all times, detainees were permitted to receive legal advice from a privately paid or
legal aid solicitors, whether in-person, by telephone or via video conference. The Defendant also
facilitated free DDAS surgeries. Throughout this period, the LAA provided publicly funded legal advice to
detainees via DDAS surgeries, and legal aid was available for controlled or licensed work, where
appropriate.

106. In my judgment, the provision of legal advice via telephone or video-conference instead of in-person,
for a limited 6 month period delivered by existing experienced providers from Yarl's Wood did not amount


-----

for Refugee Women) v Secretary of State for the Home D....

to a denial of effective access to justice “in real world conditions”. Whilst I accept that some users have a
strong preference for in-person meetings, which should be accommodated where possible, the quality and
convenience of modern video-conference facilities is very good, and comparable to an in-person meeting.
The video-conference facilities, with high speed wi-fi, were newly installed at Derwentside. Alternatively,
the telephone is an adequate means of communication for most people, though I accept it may be less
effective for those with disabilities and mental health issues, and where a detainee has limited knowledge
of English. I take into account the criticisms made in the Claimants' evidence of unhelpful members of IRC
staff and solicitor providers, but I consider that these are management issues for the Defendant and the
LAA to address, rather than this Court.

107. Therefore, I reject the Claimants' submission that there was a hindrance or impediment to the right of
access to a lawyer which interfered with detainees' fundamental common law rights at Derwentside.

108. It follows from these conclusions that I do not consider that the Defendant's decision to go ahead with
moving detainees to Derwentside, from the end of December 2021, was unlawful. The Defendant was
committed to the provision of the same in-person legal services at Derwentside, as had been provided at
Yarl's Wood IRC. This was evidenced by the Detention Sub-Group meeting on 29 June 2021, and the
invitation to tender issued on 22 July 2021 which required providers to offer advice in-person, as well as by
electronic means.

109. However, the Defendant was faced with exceptional circumstances. During the COVID-19 pandemic,
in-person DDAS surgeries at all IRCs had been largely replaced by electronic means of communication, for
the health and safety of detainees and providers, and to comply with Government advice and legal
restrictions. The invitation to tender for DDAS services issued in July 2021 had unexpectedly failed
because insufficient compliant tenders had been received. The LAA intended to issue a revised invitation
to tender, but the process would inevitably take some months to conclude.

110. The Defendant made the decision to move detainees to Derwentside in the knowledge that the Lord
Chancellor, acting through the LAA, could and would implement lawful interim contingency arrangements
for 6 months until a second tender process for permanent contracts was concluded. In my judgment, those
arrangements were a lawful discharge of the Lord Chancellor's duties and powers to deliver legal services
under LASPO, including using electronic means where necessary.

_(3) The permanent arrangements from July 2022 onwards_

111. The second tendering process was successful and resulted in an award of DDAS contracts to three
providers. Under the current contracts, which came into effect on 1 July 2022, providers were required to
agree that they would deliver DDAS work on an in-person basis. There are two surgeries each week, which
are serviced by providers on a rota basis. Where appropriate, providers will then continue to provide legal
services to the detainees they have advised at the surgery, by way of controlled work, and possibly
licensed work.

112. The solicitors who have successfully bid for the DDAS contract are based some distance away, in
Bradford, Coventry and Hounslow. The Claimants have expressed concern about their capacity to fulfil the
contractual requirements, and to provide an adequate service to detainees. However, these concerns are
inevitably speculative, and are not shared by the LAA or the new providers. In my view, there is insufficient
reliable evidence to establish that the contractual services will not be met. The LAA has sufficient power to
monitor the service provided by these providers and to ensure that they do fulfil the contractual
requirements in future. The extensive monitoring, enforcement and sanctioning powers of the LAA are
[helpfully set out in the judgment of Calver J. in R (Detention Action) v Lord Chancellor [2022] EWHC 18](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64HR-5643-GXF6-82RC-00000-00&context=1519360)
_[(Admin).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64HR-5643-GXF6-82RC-00000-00&context=1519360)_

113. If in future the contractual requirements are persistently not met, and adequate services are not
provided, then the LAA and the Defendant will have to identify the reasons for the failure, and take the
necessary steps to resolve the difficulty. This may require a revision of the terms of the contract, perhaps
by offering financial incentives to overcome the disadvantages of lengthy travel times to Derwentside from


-----

for Refugee Women) v Secretary of State for the Home D....

other parts of the country, or to address the reasons why local legal aid firms are not bidding for the
contract, which, in my view, may well relate to the unfavourable terms and conditions of the work. If at any
time there is a breakdown in provision of legally aided services, whether for DDAS or other legal aid work,
emergency provision should be commissioned.

114. For the reasons set out above, Ground 1 does not succeed.

**Grounds 2 and 3**

115. It is convenient to deal with Grounds 2 and 3 together, because of the overlap between them.

**Submissions**

116. Under Ground 2, the Claimants submit that the provision of legal services at Derwentside was and is
inferior to the provision at male IRCs, because of the absence of in-person visits. This constitutes direct
discrimination, contrary to sections 16 and 29(6) EA 2010. Alternatively it constitutes indirect
discrimination, contrary to sections 19 and 29(6) EA 2010, based upon a “provision, criterion or practice” of
detaining men and women, which places female detainees at a particular disadvantage which cannot be
justified.

117. In paragraph 12 of their reply (which was submitted in writing after the end of the hearing due to lack
of court time), the Claimants impermissibly sought to widen the scope of their claim under Ground 2,
beyond the case pleaded in the Statements of Facts and Grounds, to include a range of other alleged
detriments experienced by women at Derwentside. In my view, that was improper. The Claimants may
only rely on the pleaded grounds.

118. Under Ground 3, the Claimants submit that the Defendant acted in breach of the public sector
equality duty (“PSED”) as she failed to have due regard to the statutory purposes set out in section 149(1)
EA 2010. Although the EIA purported to give effect to her obligation, she has not implemented the plan
that was the subject of assessment, and she has not discharged the continuing duty by reviewing the
equalities implications of the revised arrangements.

119. Under Ground 2, the Defendant submits that, on the evidence, she does not, by detaining women at
Derwentside, treat them less favourably than she treats the men detained in male IRCs, in the provision of
legal services.

120. Alternatively, if and insofar as the legal services at Derwentside are less favourable than elsewhere,
the defence in paragraph 26 of Schedule 3 to the EA 2010 applies. The parties agree that routinely mixing
male and female detainees in the same IRCs would be less effective than maintaining separate facilities for
men and women. The Defendant relies upon the evaluation and conclusions in the EIA to the effect that
opening Derwentside was a proportionate means of achieving a legitimate aim.

121. Under Ground 3, the Defendant submits that the decision to open Derwentside was carefully
evaluated and was the subject of a detailed EIA. The intention was to provide legal services in the same
way as at Yarl's Wood and the male IRCs. The changes which had to be implemented between January
and June 2022, under the interim contingency arrangements, were not such as to require a revised
evaluation. In any event, any failure to pay due regard under section 149 EA 2010 ought not to lead to the
conclusion that the detention of women at Derwentside has been unlawful.

**_[EA 2010](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)_**

122. Section 13 EA 2010 prohibits direct discrimination. Direct discrimination is defined as follows:

“(1) A person (A) discriminates against another (B) if, because of a protected characteristic, A treats B less
favourably than A treats or would treat others.”

123. Section 19 EA 2010 prohibits unjustified indirect discrimination, described as follows:

“(1) A person (A) discriminates against another (B) if A applies to B a provision, criterion or practice which
is discriminatory in relation to a relevant protected characteristic of B's


-----

for Refugee Women) v Secretary of State for the Home D....

(2) For the purposes of subsection (1), a provision, criterion of practice is discriminatory in relation to a
relevant protected characteristic of B's if
(a) A applies, or would apply, it to persons with whom B does not share the characteristic,

(b) it puts, or would put, persons with whom B shares the characteristic at a particular disadvantage when
compared with persons with whom B does not share it,

(c) it puts, or would put, B at that disadvantage, and

(d) A cannot show it to be a proportionate means of achieving a legitimate aim.”

124. Section 29(6) EA 2010 provides:

“A person must not, in the exercise of a public function that is not the provision of a service to the public or
a section of the public, do anything that constitutes discrimination, harassment or victimisation.”

125. Paragraph 26 of Schedule 3 to EA 2010 contains a qualification to the prohibition of direct
discrimination on the basis of sex, as follows:

“(1) A person does not contravene section 29, so far as relating to sex discrimination, by providing
separate services for persons of each sex if—

(a) a joint service for persons of both sexes would be less effective, and

(b) the limited provision is a proportionate means of achieving a legitimate aim.

(2) A person does not contravene section 29, so far as relating to sex discrimination, by providing separate
services differently for persons of each sex if—

(a) a joint service for persons of both sexes would be less effective,

(b) the extent to which the service is required by one sex makes it not reasonably practicable to provide the
service otherwise than as a separate service provided differently for each sex, and

(c) the limited provision is a proportionate means of achieving a legitimate aim.”

126. Section 149 EA 2010 sets out the PSED. It provides materially as follows:

“(1) A public authority must, in the exercise of its functions, have due regard to the need to-
(a) Eliminate discrimination, harassment victimisation and any other conduct that is prohibited by or under
this Act;

(b) Advance equality of opportunity between persons who share a relevant protected characteristic and
persons who do not share it;

(c) Foster good relations between persons who share a relevant protected characteristic and persons who
do not share it.

…

(3) Having due regard to the need to advance equality of opportunity between persons who share a
relevant protected characteristic and persons who do not share it involves having due regard, in particular,
to the need to
(a) remove or minimise disadvantages suffered by persons who share a relevant protected characteristic
that are connected to that characteristic;

(b) take steps to meet the needs of persons who share a relevant protected characteristic that are different
from the needs of persons who do not share it;

(c) encourage persons who share a relevant protected characteristic to participate in public life or in any
other activity in which participation by such persons is disproportionately low.”


-----

for Refugee Women) v Secretary of State for the Home D....

The relevant protected characteristics include age, disability, race, and sex.

**EIA**

127. The Defendant's EIA, published on 23 November 2021, is relevant to both Grounds 2 and 3. The key
relevant extracts are set out below.

“1. The impact of opening a new immigration removal centre, Derwentside IRC.

An effective immigration detention system, as part of a fair and humane approach to immigration
enforcement, is a Government requirement and an expectation of the public. To achieve this, we must
provide a detention estate with enough resilience to ensure that it can absorb fluctuations in demand, such
as a change in in-flow of timeserved FNOs and short-term operational pressures, such as contagious
illness or disturbance. This has been especially prevalent during the Covid-19 pandemic.

The Home Office currently operates six immigration removal centres (IRCs) throughout the UK (five in
England and one in Scotland) and two residential short term holding facilities (RSTHFs) (one in Northern
Ireland and one in England), following the closure of Morton Hall IRC in July 2021. Yarl's Wood IRC has
historically been run as a dedicated female only facility.

The return of Morton Hall IRC to MoJ removed almost 400 male detention beds (20% of the total male
capacity, in an estate already 40% smaller than in 2015) and leaves no male IRCs between Glasgow and
Heathrow/Gatwick. This loss of capacity comes at a time where flexibility and resilience in the detention
estate are most needed. A response to the loss and an immediate restructure of the existing estate is
necessary. Immigration Enforcement (IE) must find alternatives to mitigate the loss of male capacity at
Morton Hall. This must happen concurrent to the closure of the IRC, leaving no gap in service. To absorb
the loss in male beds at Morton Hall we will:

**Re-role Yarl's Wood as, primarily, a male IRC. This change provides 372 new male beds in an IRC that**
has been historically underutilised as an all-female site (between 25% and 30% occupancy rates precovid). This change provides a starting point for the existing estate to be used to its full potential.

**Procure a small specialised site (84 bed) to detain women – Derwentside IRC. This site will replicate**
the conditions that currently exist at Yarl's Wood, focusing on the healthcare, welfare and activities services
provided. The detention facility for women will now be in County Durham. The Home Office is committed to
designing and operating the new IRC in a way that reflects and responds to the characteristics and needs
of the population who will be detained there.

IE are seeking to ensure that the immigration detention estate has the right amount of capacity, is fit for
purpose and flexible, and serves the whole of the UK whilst minimising the cost to the public purse where
possible and appropriate. Our aim is to implement the change in a way which promotes and enhances
equality of opportunity, respects diversity and takes into account the needs of people with protected
characteristics. Where there may be a negative impact, we explain how this is justifiable and proportionate
in accordance with our obligations under the _[Equality Act 2010 and explain the mitigating action being](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7R-3430-Y97X-72X1-00000-00&context=1519360)_
taken.

**2. Summary of the evidence considered in demonstrating due regard to the Public Sector Equality**
**Duty.**

**Public sector equality duty and detention as part of immigration control**

The need for significant long-term capacity with a wider national footprint reflects IE's strategy of
modernising and rationalising the immigration removal estate. Five centres have been closed in recent
years creating a reduction in operational detention capacity. For financial reasons, the number of Foreign
National Offender (FNO) beds used for immigration purposes in the prison estate has substantially
decreased. Further reduction would present a risk to future capability to remove those with no legal basis
to remain in the UK. This emphasises the importance of repurposing Yarl's Wood to cover the loss of beds
at Morton Hall and the procurement of a new site for women.


-----

for Refugee Women) v Secretary of State for the Home D....

…..

**3A. Consideration of limb 1 of the duty: Eliminate unlawful discrimination, harassment,**
**victimisation and any other conduct prohibited by the Equality Act**

**Sex**

Home Office policy does not exclude individuals from detention by virtue of their gender. Men and women
are equally likely to be detained provided that one of the statutory powers of detention apply and their
detention would be in line with published Home Office detention policy. However, victims of gender-based
violence, who are more likely to be women, fall explicitly within the adults at risk policy: they will be
detained only where immigration control considerations outweigh vulnerability considerations.

**Direct discrimination**

By opening a woman only facility at this location, we have considered the risk that the policy constitutes
direct discrimination on the grounds of sex. The gender specific facilities available at Derwentside IRC will
not be available to men who are being detained under the same detention powers.

Paragraph 26 of Schedule 3 to the Equality Act 2010 contains an exemption from the prohibition of direct
discrimination on the basis of sex:

_[text of paragraph 26]_

We consider that failing to segregate the sexes would make the detention arrangements considerably less
effective for both men and women.

The detention estate has long operated sex-segregated IRCs. This is due to the significant evidence (and
widely accepted principle) that female residents have needs that are different to and often more complex
than men and so a gender specific approach is required to manage detained environments in a way that
meets the needs of its population, particularly around issues of safeguarding and vulnerability.

**Security and freedom of movement within IRCs**

Different IRCs operate with different levels of security and openness within the centres according to the
layouts of centres and the level of risk that the average population within each centre tends to pose.

Security statistics demonstrate that between 2015 and present there were no women who have escaped or
attempted to escape from an IRC in comparison to 20 attempts by the men. There are also less high harm
female FNOs in prisons and subsequently less FNOs coming into IRCs than men. Thus, the risk posed
from women in detention is diminished, and so all women centres have historically operated a more open
and less regimented environment.

By opening a women only centre, we will be providing a facility designed and operated for women who
historically require lower levels of security. One of the considerations for choosing the Derwentside site
was because it had been a Secure Training Centre, rather than a prison or IRC, meaning it could be easily
developed to provide an open and relaxed regime through which the needs of detained women could be
met. Levels of security will be commensurate to the lower level of risk posed by women in terms of both
security (such as escape attempts) and violence, allowing greater freedom of movement within the centre
and shorter periods during which residents will be required to remain in their rooms. Making this a suitable
site for the detention of women has been and remains a key factor throughout the planning and delivery of
the renovations.

The workforce requirements will reflect the lessons learned from detaining women at Yarl's Wood IRC and
will include a ratio of female to male custodial staff that is appropriate for the specific needs of women in
detention. The training requirements for staff will be equivalent to those for Yarl's Wood IRC. All staff
working with women must receive appropriate gender specific training (such as the protocol for entry to
bedrooms), in addition to any generic training they receive when they undergo initial training. Appropriate
refresher training should be undertaken, to include equality and diversity, human trafficking and **_modern_**
**_slavery_**


-----

for Refugee Women) v Secretary of State for the Home D....

A full range of recreational and healthcare facilities tailored to women will mirror those currently operated at
Yarl's Wood and will include a cultural kitchen, hair and beauty salon, the ability to purchase items from a
shop, access to a computer suite, education, well-being services, welfare and access to legal services.
Multi faith/prayer rooms will also be available to residents.

Visits will be facilitated in line with those in other centres, with visitors to the nearest main train station
transported to the centre to support and encourage visiting arrangements.

We therefore consider that failing to segregate by sex would render this IRC less effective in managing the
detention of women in a manner commensurate with the risk they pose, and in accordance with the
purpose of the centres to operate 'a relaxed regime with as much freedom of movement and association as
possible consistent with maintaining a safe and secure environment' (Detention Centre Rules 2001).

We are satisfied that this approach is a proportionate means of achieving the legitimate aim of ensuring
that the detention estate is operated as a secure environment so far as is necessary to ensure the safety
and security of detained persons and staff, tailored to the circumstances of each centre with no more
restrictions than are necessary.

**Location**

The new IRC will be located in the North East of England, and is not co-located with an airport or within a
town or city. The majority of centres are located in the South/South East of England. We have considered
whether the fact that the new IRC in the North East will house women, whereas all male centres are more
heavily concentrated in the South, will result in direct discrimination on the basis of gender. This is because
in practice there may be potential difficulties with receiving visits from family and friends that would
disproportionately impact detained women, the majority of whom will likely be detained in the new IRC (as
discussed above, there will still be capacity to detain women at other sites in the UK).

There is no policy that individuals should be detained in a location as close to family as possible. The DSO
3/2016 “Detainee Placement” sets out that detained persons can request transfers to other IRCs on
personal grounds and the Home Office will consider such requests on the basis of available space
elsewhere in the detention estate and the reasons provided.

Other sites were considered, including Campsfield House, but were discounted due to the current standard
or use of the accommodation. Derwentside was deemed the most appropriate option because it was
already government-owned and of the requisite standard, which made it the best option given the short
timescales, cost-effectiveness and the standard of accommodation required. By maintaining some
detention space for women at Yarl's Wood, Dungavel and Colnbrook and by expanding the geographical
footprint of the detention estate we will, however, be better placed to take account of individual
circumstances in deciding the most appropriate detention facility on a case by case basis.

We will provide modern communication links for the women at Derwentside with uninhibited access to
Internet and Skype during core hours to ensure they can maintain the same level of communications,
including with family, as other sites. In addition, all visitors to the nearest main train station will be
transported to the centre to support and encourage visiting arrangements.

We also bear in mind that, as mentioned above, detention periods are generally lower for women than for
men, which has some mitigating effect on the impact of detention.

It is therefore considered that the proposals are a proportionate means of achieving a legitimate aim:
seeking to ensure that the immigration detention estate has the right amount of capacity, is fit for purpose
and flexible, and serves the whole of the UK whilst minimising the cost to the public purse where possible.

**Staffing and facilities**

The IRC will cater to the specific needs of women in detention and staffing will include a ratio of female to
male custodial staff that is appropriate for the specifics needs of women in detention. For example, (DSO


-----

for Refugee Women) v Secretary of State for the Home D....

09/2012 Searching Policy, paragraph 31) below instructs that where possible the two DCOs carrying out a
room search should be female.

…..

In determining the types of facilities to be provided, we will take account of learning from Yarl's Wood IRC
and relevant recommendations from external inspection and scrutiny bodies. We will provide facilities
tailored to women, based on those currently available at Yarl's Wood, including a cultural kitchen,
appropriately stocked shop, computer suite, dedicated hair salon and nail clinic, and a cafeteria for the
women to engage with visitors from the local community including Hibiscus NGO, a charity that works
primarily with women.

We have recognised that women in detention have frequently been victims of abuse, sexual trafficking,
trauma and are therefore more likely to have severe complex needs in comparison to the male cohort. The
NHS provider will be offering gender informed trauma-based practice therapy for women and will be a
conducting continual needs analysis for care of the women. We will welcome further engagement with
NGOs both nationally and locally in the coming months.

We consider that there is a strong justification for providing these tailored facilities. Equivalent facilities are
available at all male IRCs to account for the particular needs of male populations (eg barbers and gym
facilities).

**Indirect discrimination**

We have considered whether this policy position could result in indirect discrimination as the policy of
segregating by sex in IRCs means that one gender is always likely to be disproportionately impacted by the
characteristics of a particular regime or location of a given centre. If this policy were to result in indirect
discrimination, it is considered that the proposals are a proportionate means of achieving a legitimate aim
for the same reasons as set out above: seeking to ensure that the immigration detention estate is tailored
to the needs of women and men as appropriate, has the right amount of capacity, is fit for purpose and
flexible, and serves the whole of the UK whilst minimising the cost to the public purse where possible.

**Race**

…….

**Direct discrimination**

We do not consider that this policy will result in direct discrimination in respect of this protected
characteristic”

**Indirect discrimination**

For individuals who do not have a fluent command of English and are seeking advice regarding their
detention and/or removal from UK, the potential loss of access to organisations offering advocacy services
who are working with women detained at other IRCs could place such detained persons at a disadvantage,
potentially resulting in indirect discrimination. For some people detained it may be easier to receive such
advice face-face from a speaker of their first language, rather than over the telephone or internet. The
Legal Aid Agency (LAA) will set up a Detained Duty Advice scheme on the same basis as in other IRCs,
and the LAA is tendering for a service comparable with that currently available at Yarl's Wood. Residents
and legal providers will have access to purpose designed interview suites and high speed wifi.

Where individuals in detention consider they are experiencing discrimination, or other negative treatment
as a result of their race, nationality or ethnic origins they will continue to be able to request transfers to
another IRC in the estate, in line with arrangements set out in DSO 3/2016 “Detainee Placement”. By
expanding the detention estate footprint (and by also retaining some detention space for women at
Dungavel, Yarl's Wood and Colnbrook), we are providing more flexibility and scope to meet such requests.

We have also recently reviewed the provision of interpretation services across the IRC estate, looking at
both eq ipment and ser ice q alit Follo ing that re ie e are introd cing ne eq ipment pre booking


-----

for Refugee Women) v Secretary of State for the Home D....

interpreters in certain circumstances and ensuring, in particular, improvements to interpretation during
induction. In addition, work is underway to develop a DSO on interpretation services.

In light of these mitigations we consider that, in the event that there were to be any disproportionate impact
on persons of a particular race, the decision to open this IRC in the North East is justified as a
proportionate means of achieving the legitimate aim of developing the detention estate in an appropriate
manner across the UK, as set out above.”

……

**Disability**

Home Office detention policy does not operate with absolute exclusions in relation to specific groups, such
as those with either mental or physical disabilities or impairments. Under this policy an individual
considered to be “at risk” will be detained only when the immigration control factors outweigh the evidence
of vulnerability presented in their case. Having a serious mental or physical disability, including suffering
from post-traumatic stress disorder, are specified as indicators of risk under the policy.

The Adults at Risk (AAR) policy sets out considerations for individuals with a “serious physical disability”
whereby it states “where an individual may be suffering from a serious disability it may inhibit their ability to
cope within a detention environment and should be factored into any consideration of detention and,
indeed, into consideration of their general management through the immigration process”. Mental illness is
covered in the AAR policy and states that such conditions may inhibit an individual's ability to cope within a
detention environment and should be factored into any consideration of detention and, into consideration of
their general management through the immigration process.

Detention Services Order 4/2020 “Mental vulnerability and immigration detention- non clinical guidance”
provides guidance on provision of support to those with mental vulnerabilities in detention.

**Direct discrimination**

A person with disabilities may be held at any IRC that can accommodate their needs. There is disabled
access across the majority of the estate for those who are able to move independently and are capable of
participating in the regime with minor assistance from others. Similar provision will be put in place at the
new IRC and we do not consider that opening a women only IRC will pose direct discrimination issues in
respect of disability.

**Indirect discrimination**

Following publication of DSO 08/2016 'Management of adults at risk in the detention estate' a consistent
approach is taken by all Home Office, supplier and healthcare staff working with those in detention to
identify and record changes to the physical or mental health of a person in detention, or a change in the
nature/severity of any previously identified vulnerability, alongside the current IS91RA risk assessment
process. Any vulnerability that may impact on the safety and wellbeing of an individual must be addressed
and reasonable adjustments be put in place, which must be documented in the care plan.

The Detention Engagement Team in the IRC aim to conduct an induction for all people entering detention
within 48 hours of arrival as well as regularly engaging with each individual throughout their detention.
Their one-to-one interactions support the wellbeing of people in detention, particularly in identifying any
signs of vulnerability and / or signs of deterioration in physical or mental health.

The new IRC will be able to accommodate people with disabilities in line with the rest of the estate with the
majority of the rooms on the ground floor with en-suite facilities.”

**Ground 3**

128. As Ground 3 is a challenge to the Defendant's decision to open and operate Derwentside, it logically
comes first.


-----

for Refugee Women) v Secretary of State for the Home D....

129. The parties referred to the leading case of _Bracking v Secretary of State for Work and Pensions_

_[2013] EWCA Civ 1345, in which McCombe LJ set out the principles from the case law, at [26]. The duty_
under section 149(1) EA 2010 is to have “due regard”; not to reach a particular result.

130. In my judgment, the Defendant discharged the PSED and had due regard to the factors in section
149(1) EA 2010. In reaching her decision to open and operate Derwentside, she had the benefit of a
detailed evaluation in the EIA, which considered the relevant issues, within the statutory framework.

131. Among other matters, the disadvantages of the location were considered, and how they might be
mitigated. The EIA considered that “the proposals are a proportionate means of achieving a legitimate
aim: seeking to ensure that the immigration detention estate has the right amount of capacity, is fit for
purpose and flexible, and serves the whole of the UK whilst minimising the cost to the public purse where
possible.”

132. The EIA correctly proceeded on the basis that the Derwentside would have a  DDAS set up on the
same basis as in other IRCs, and that the LAA was tendering for a service comparable with that currently
available at Yarl's Wood. It noted that detainees and legal providers will have “access to purpose designed
interview suites and high speed wifi”. It was recognised, in the context of assessing race discrimination,
that for “some people detained it may be easier to receive such advice face-face from a speaker of their
first language, rather than over the telephone or internet”.

133. The invitation to tender for DDAS services issued in July 2021 unexpectedly failed because
insufficient compliant tenders were received. The LAA intended to issue a revised invitation to tender, but
the process inevitably took some months to conclude. The Defendant made the decision to move
detainees to Derwentside in the knowledge that the Lord Chancellor, acting through the LAA, could and
would implement interim contingency arrangements for 6 months until a second tender process for
permanent contracts was concluded. I have already found that the provision of legal services by videoconference and telephone was lawful, and that, with modern technology, meeting by video-conference is
now comparable to an in-person meeting. Furthermore, because of the COVID-19 pandemic, in-person
DDAS surgeries at male IRCs had also been largely replaced by electronic means of communication, for
the health and safety of detainees and providers. Therefore the disparity in treatment at that time between
female and male detainees was insignificant, at least as far as the DDAS was concerned. Outside the
DDAS, legal visits were permitted at all IRCs. In these circumstances, in my judgment, the Defendant did
not act unlawfully by proceeding to move detainees to Derwentside without first commissioning a further
EIA and undertaking another PSED evaluation.

**Ground 2**

134. The parties referred to the case of R (Coll) v Secretary of State for Justice [2017] UKSC 40, [2017] 1
WLR 2093in which the Supreme Court held that the defendant directly discriminated against women
released on licence and required to live at approved premises, since the risk of being located far from
home was much greater for women than for men. Baroness Hale held that it was not necessary to show
that all women would be disadvantaged in this way. She considered the operation of paragraph 26 of
Schedule 3 EA 2010 as a defence to a direct discrimination claim, and held that, under sub-paragraph 26
(2), it was not reasonably practicable for the defendant to provide approved premises other than as a
separate service provided differently for each sex because of the much smaller number of female
offenders. However, she went on to hold that the defendant had not addressed its mind to the alternative
options that could be adopted, and therefore had not justified the differential treatment as a proportionate
means of achieving a legitimate aim.

135. The Claimants also drew my attention to Interim Executive Board of X School v HM Chief Inspector of
_Education [2016] EWHC 2813 (Admin) and R (Adath Yisroel Burial Society) v Inner North London Senior_
_Coroner [2018] EWHC 969 (Admin)._

**Direct discrimination**


-----

for Refugee Women) v Secretary of State for the Home D....

136. For the reasons I have given under Ground 3, I do not consider that the Defendant has been, or is
now, treating female detainees less favourably than male detainees in respect of legal advice services.
The Defendant, with the LAA, has at all times intended to provide the same legal advice services at
Derwentside as at male IRCs. Unfortunately, because of the failed tender process, the contracts which
required providers to attend DDAS surgeries in person were not signed and implemented until 1 July 2022.
In the meantime, existing providers from Yarl's Wood continued to provide DDAS surgeries at Derwentside,
but they did so remotely – they were not required to attend in-person, but could do so if requested to do by
the detainee and they agreed to the request. I have already found that the provision of legal services by
video-conference and telephone was lawful, and that, with modern technology, meeting by videoconference is now comparable to an in-person meeting. Furthermore, because of the COVID-19
pandemic, in-person DDAS surgeries at male IRCs had also been largely replaced by electronic means of
communication, for the health and safety of detainees and providers. Therefore the disparity in treatment
at that time between female and male detainees was insignificant, at least as far as the DDAS was
concerned, as can be seen from the data. The Claimants refer to the noticeably higher numbers of legal
visits in male IRCs which were not part of the DDAS, but neither the Defendant nor the LAA prevented inperson visits outside the DDAS by a privately paid or legal aid solicitor at Derwentside between January
and June 2022. It was not their responsibility to arrange them.

137. Alternatively, if there was less favourable treatment, it was justified under paragraph 26 of Schedule 3
EA 2010. It was common ground that a joint service for male and female detainees would be less effective
and women detainees ought to be accommodated in an all-female IRC. The existing all-female IRC at
Yarl's Wood was unsuitable, because there were insufficient female detainees to make use of its capacity,
and so a smaller IRC site had to be found for female detainees. As the EIA concluded, the choice of
Derwentside was “a proportionate means of achieving a legitimate aim: seeking to ensure that the
immigration detention estate has the right amount of capacity, is fit for purpose and flexible, and serves the
whole of the UK whilst minimising the cost to the public purse where possible”.

138. However, setting up a new IRC in a new location meant that the LAA had to tender for new contracts
for DDAS services. The first tendering process failed and so new contracts were not in place at the point
where detainees were due to move into Derwentside in December 2021/January 2022. Therefore DDAS
services were provided under interim contingency arrangements, without any requirement for in-person
visits, until a new tender was concluded and contracts awarded. No such interim contingency
arrangements had to be made for male detainees because they were not moving to a brand new IRC
without any existing contracts for DDAS services.  To the extent that the legal services were provided
differently for female detainees between January and July 2022, the interim contingency arrangements
were a proportionate means of achieving a legitimate aim, namely, the move to Derwentside.

139. As from 1 July 2022, the new permanent contracts for DDAS services were implemented with new
providers who were required to provide in-person legal services. Thereafter, there was no difference in the
legal services available to male and female detainees, and so female detainees were not treated less
favourably. As I held under Ground 1, the Claimants' concern about the capacity of the new providers to
fulfil the contractual requirements and provide an adequate service to detainees is speculative. It is not
shared by the new providers or the LAA. The LAA has monitoring and enforcement powers. In my view,
there is insufficient reliable evidence to establish that the contractual services will not be met, for the basis
of a discrimination claim.

**Indirect discrimination**

140. The Claimant contends, in the alternative, that the Defendant is applying a provision, criterion or
practice, namely detention in an IRC, which places female detainees at a disadvantage, because of the
inferior legal services provided at Derwentside, compared with male IRC's.

141. For the reasons I have set out at paragraphs 136 and 139 above, I do not consider that the detainees
at Derwentwside have been provided with inferior legal services, compared with male detainees.


-----

for Refugee Women) v Secretary of State for the Home D....

142. Alternatively, any inferior legal services can be justified as a proportionate means of achieving a
legitimate aim, for the reasons set out in paragraphs 137 and 138 above.

143. For these reasons, Grounds 2 and 3 do not succeed.

**Ground 4**

**Submissions**

144. SPM submits that her detention without access to in-person legal advice discriminated against her on
the grounds of sex in that she enjoyed substantially inferior access to legal advice than men who were
detained. This meant that she could not gain legal assistance to enforce her Convention rights, in
particular, under Articles 2 and 3 ECHR (removal to a country where she faces a real risk of being killed,
tortured, or subjected to inhuman or degrading treatment); Article 4 ECHR (as a victim of trafficking); Article
5 ECHR (to challenge her detention); Article 6 (effective access to a court); and Article 8 (interference with
her private and family life by removal from the UK). This was contrary to Article 14 ECHR, read with
Articles 2 and 3, 4, 5, 6 or 8 ECHR.

145. The Defendant does not concede that the circumstances fell within the ambit of the Convention rights
identified but does not actively oppose this part of SPM's case. However, the Defendant contends that
there was no material difference of treatment on grounds of sex. Alternatively, that there was an objective
[justification for any difference in treatment, namely the reasons relied upon under the EA 2010.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:7Y7B-PJN0-Y97X-705G-00000-00&context=1519360)

**Conclusions**

146. Article 14 ECHR provides:

“The enjoyment of the rights and freedoms set forth in this Convention shall be secured without
discrimination on any ground such as sex, race, colour, language, religion, political or other opinion,
national or social origin, association with a national minority, property, birth or other status.”

147. In Re McLaughlin [2018] 1 WLR 4250, at [15], Baroness Hale identified four questions which arise in
an Article 14 claim:

“As is now well known, this raises four questions, although these are not rigidly compartmentalised:

(1) Do the circumstances fall within the ambit of one or more of the Convention rights?

(2) Has there been a difference of treatment between two persons who are in an analogous situation?

(3) Is that difference of treatment on the ground of one of the characteristics listed or other status?

(4) Is there an objective justification for that difference in treatment?”

148. Bourne J. refused permission on Ground 4 on the basis that the claim did not explain how a
substantive ECHR right was engaged.  Mr Goodman helpfully clarified that aspect of SPM's claim in his
renewal application.

149. In order to establish that a matter falls within the ambit of a substantive Convention right, for the
purposes of Article 14, it is not necessary to demonstrate that any substantive right is breached. Article 14
is engaged whenever the subject matter of the disadvantage comprises one of the ways a state gives
effect to a Convention right: see M v Secretary of State for Work and Pensions _[2006] UKHL 11, [2006] 2_
AC 91, at [16].

150. In R (SM) v Lord Chancellor [2021] EWHC 418 (Admin), which concerned the lack of a DDAS service
for immigration detainees in prisons, Swift J. said:

“11. The Claimant's claim is that the lack of an equivalent to the DDAS for immigration detainees like him
who are held in prison is in breach of his rights under ECHR article 14 not to suffer discrimination in the
enjoyment of Convention rights on grounds of “other status”. The Claimant's Statement of Facts and
Grounds relied on ECHR articles 2 and 3 (on the basis that access to legal advice affected the ability to


-----

for Refugee Women) v Secretary of State for the Home D....

advance claims for protection as a refugee or that a person should not be removed from the United
Kingdom by reason of a serious risk of treatment contrary to those Convention rights); ECHR articles 5 and
6 (because of the impact on his ability to challenge the legality of his detention, or apply for bail); and
ECHR article 8 (because of the adverse impact on his ability to apply for leave to remain in the United
Kingdom by reason of interference with rights guaranteed under that article). In his Detailed Grounds of
Defence, the Lord Chancellor accepted that the Claimant's complaint about the availability of access to
publicly funded legal services falls within the ambit of both EHCR article 5 and article 8. In her Skeleton
Argument for this hearing, Miss Dobson conceded that the complaint also fell within the ambit of ECHR
articles 2 and 3. Neither party made any detailed submissions on any of these matters. The wide-ranging
basis on which the claim is put and defended covers any and all benefit that could accrue from the DDAS
(and conversely any disadvantage arising from lack of access to an equivalent provision).”

151. In the light of this passage in SM and the concessions made, I accept that the circumstances do fall
within the ambit of one or more of the Convention rights.

152. However, I do not accept SPM's submission that she was detained without access to in-person legal
advice and so could not enforce her Convention rights, and she was thereby discriminated against on the
grounds of sex, in that she enjoyed substantially inferior access to legal advice than men who were
detained in IRCs.

153. SPM's FTT appeal against refusal of asylum was dismissed on 9 November 2021. In anticipation of
her removal from the UK, she was detained on 24 January 2022 and transferred to Derwentside on 27
January 2022.

154. At all times, detainees at Derwentside were permitted to receive legal advice from a privately paid or
legal aid solicitor, whether in-person, by telephone or via video-conference. It was not the Defendant's
responsibility to arrange these appointments. The Defendant also facilitated free DDAS surgeries.
Throughout this period, the LAA provided publicly funded legal advice to detainees via DDAS surgeries,
and legal aid was available for controlled or licensed work, where appropriate.

155. SPM states that she was not able to access legal advice organised by Derwentside, although she
was provided with a pamphlet with information about legal advice.

156. SPM was referred to Duncan Lewis by a member of WRW. Ms Parrott immediately telephoned her
and took instructions from her, and obtained copies of relevant documents with the help of IRC staff. I set
out the details of Ms Parrott's work for SPM at paragraphs 21 to 24 above. On 6 February 2022, Ms Parrott
sent an urgent pre-action letter to the Defendant asking for investigation into trafficking and referral into the
NRM. Ms Parrott's work was funded by legal aid (Legal Help).

157. In response, on 6 February 2022, the Defendant cancelled the removal directions for 7 February. On
10 February 2022, SPM was referred into the NRM for identification as a victim of trafficking. On 16
February 2022 the Defendant made a positive Reasonable Grounds decision in relation to SPM, identifying
her as a potential victim of modern slavery. Her Conclusive Grounds decision is still awaited.

158. On 25 February 2022, SPM was released on immigration bail.

159. Thus, while at Derwentside, SPM was able to enforce her Convention rights to challenge her removal
from the UK (Articles 2 and 3); to be assessed as a victim of trafficking (Article 4); and to obtain release
from detention (Article 5). I expect that if the Defendant had not cancelled the removal directions or had not
released her on bail, Ms Parrott would have made applications to the appropriate court or tribunal, thus
exercising her Article 6 rights. Once released she was able to return to her partner and friends, to enjoy
her Article 8 rights.

160. The Defendant, with the LAA, has at all times intended to provide the same legal advice services at
Derwentside as at male IRCs. Unfortunately, because of the failed tender process, the contracts which
required providers to attend DDAS surgeries in person were not signed and implemented until 1 July 2022.
So between January and June 2022, existing providers from Yarl's Wood continued to provide DDAS


-----

for Refugee Women) v Secretary of State for the Home D....

surgeries at Derwentside, but they did so remotely – they were not required to attend in-person, but could
do so if requested to do by the detainee and they agreed to the request.

161. In my judgment, the provision of legal advice via telephone or video-conference instead of in-person,
for a limited 6 month period, delivered by existing experienced providers from Yarl's Wood, did not prevent
or impede her from enforcing her Convention rights. The quality and convenience of modern videoconference facilities is very good, and comparable to an in-person meeting. The video-conference facilities,
with high speed wi-fi, were newly installed at Derwentside. Alternatively, the telephone is an adequate
means of communication for most people, though I accept that it was difficult for SPM as she is hearingimpaired and has limited knowledge of English.  Nonetheless Ms Parrott was able to obtain sufficient
(though not full) instructions from SPM, which together with the documents provided to her by the
Defendant and the IRC staff, enabled her to write her effective letter before claim.

162. Furthermore, because of the COVID-19 pandemic, in-person DDAS surgeries at male IRCs had also
been largely replaced by electronic means of communication, for the health and safety of detainees and
providers. Therefore the disparity in treatment at that time between female and male detainees was
insignificant, at least as far as the DDAS was concerned, as can be seen from the data. The Claimants
refer to the higher numbers of legal visits in male IRCs which were not part of the DDAS, but neither the
Defendant nor the LAA prevented in-person visits outside the DDAS by a privately paid or legal aid solicitor
at Derwentside between January and June 2022.

163. Alternatively, if there was less favourable treatment, there was objective justification for it. There
were clear benefits for women detainees to be accommodated in an all-female IRC, as described in the
EIA. The existing all-female IRC at Yarl's Wood was unsuitable, because there were insufficient female
detainees to make use of its capacity, and so a smaller IRC site had to be found for female detainees. As
the EIA concluded, the choice of Derwentside was “a proportionate means of achieving a legitimate aim:
seeking to ensure that the immigration detention estate has the right amount of capacity, is fit for purpose
and flexible, and serves the whole of the UK whilst minimising the cost to the public purse where possible”.

164. However, setting up a new IRC in a new location meant that the LAA had to tender for new contracts
for DDAS services. The first tendering process failed and so new contracts were not in place at the point
where detainees were due to move into Derwentside in December 2021/January 2022. Therefore DDAS
services were provided under interim contingency arrangements, without any requirement for in-person
visits, until a new tender was concluded and contracts awarded. No such interim contingency
arrangements had to be made for male detainees because they were not moving to a brand new IRC
without any existing contracts for DDAS services.  To the extent that the legal services were provided
differently for female detainees between January and July 2022, the interim contingency arrangements
were a proportionate means of achieving a legitimate aim, namely, the move to Derwentside.

165. Therefore, although I grant permission on Ground 4, the substantive claim for judicial review on
Ground 4 does not succeed.

**Ground 5**

166. SPM claims that she was unlawfully detained for the following reasons:

i) Pursuant to Ground 1, her detention was ultra vires because of the lack of in-person legal advice, and
effective access to justice.

ii) Alternatively, on the facts of SPM's case, the lack of arrangements for in-person legal advice materially
inhibited her ability to give instructions and obtain legal advice, thus prolonging her detention
unnecessarily.

iii) She was unlawfully detained as a victim of trafficking at risk whom the Defendant failed to identify and
refer into the National Referral Mechanism.


-----

for Refugee Women) v Secretary of State for the Home D....

167. In the light of my findings on Ground 1, sub-paragraph (i) cannot succeed. The remaining grounds
are adjourned, for case management directions to be given. Ground 5 will be listed before me for hearing
in due course, if not settled or withdrawn.

**Final conclusions**

168. SPM is granted permission to apply for judicial review on Ground 4, but her claim for judicial review is
dismissed on Grounds 1, 2, 3, 4 and 5(i). The remaining issues in Ground 5 have been adjourned to a
further hearing. WRW's claim for judicial review is dismissed on Grounds 1, 2 and 3.

**End of Document**


-----

