# Siliadin v France (2005) 20 BHRC 654

(App no 73316/01)

EUROPEAN COURT OF HUMAN RIGHTS (SECOND SECTION)

JUDGES CABRAL BARRETO (PRESIDENT), COSTA, TURMEN, JUNGWIERT, BUTKEVYCH, MULARONI AND
FURA-SANDSTROM

3 MAY, 26 JULY 2005

**Forced or compulsory labour — Domestic servitude — Applicant minor brought to France from Togo and**
**compelled to work as domestic servant for Mr and Mrs B — Criminal proceedings against Mr and Mrs B**
**leading to payment of damages to applicant — Whether criminal law provisions applicable in France**
**affording applicant sufficient and effective protection against servitude or at least against forced and**
**compulsory labour — Convention for the Protection of Human Rights and Fundamental Freedoms 1950, art**
**4.**

**Victim — Convention violation — Forced or compulsory labour — Domestic servitude — Applicant minor**
**brought to France from Togo and compelled to work as domestic servant for Mr and Mrs B — Criminal**
**proceedings against Mr and Mrs B leading to payment of damages to applicant and industrial tribunal**
**making awards to applicant in respect of unpaid wages — Whether making of decisions or measures**
**favourable to applicant sufficient to deprive her of victim status — Convention for the Protection of Human**
**Rights and Fundamental Freedoms 1950, art 34.**

The applicant arrived in France from Togo at the age of 15 years and 7 months with D, who had agreed with the
applicant's father that the applicant would work until her air ticket had been reimbursed, that her immigration status
would be regularised and that she would be sent to school. In reality, the applicant's passport was taken from her
and she worked for D for a few months before being 'lent' to Mr and Mrs B. She worked in their house without
respite for about 15 hours per day, with no day off, for several years, without ever receiving wages or being sent to
school, without identity papers and without her immigration status being regularised. She was accommodated in
their home and slept in the children's bedroom. She confided in a neighbour, who alerted the Committee against
**_Modern Slavery, which in turn filed a complaint with the prosecutor's office about the applicant's case. The police_**
raided the home of Mr and Mrs B and they were prosecuted under arts 225-13 and 225-14 (set out at para 46,
below) of the Criminal Code, which made it an offence, respectively, to exploit an individual's labour and to submit
her to working or living conditions that were incompatible with human dignity. The Paris tribunal de grande instance
found Mr and Mrs B guilty of the offence defined in art 225-13 of the Criminal Code. Conversely, it found that the
offence set out in art 225-14 had not been substantiated. Mr and Mrs B were sentenced to 12 months'
imprisonment, 7 of which were suspended, and ordered to pay a fine of FRF 100,000 each and to pay, jointly and
severally, FRF 100,000 to the applicant in damages. On an appeal by Mr and Mrs B, the Paris Court of Appeal
quashed the judgment at first instance and acquitted the defendants. No appeal was lodged by the principal public
prosecutor's office. On an appeal on points of law by the applicant, the Court of Cassation overturned the Court of
Appeal's judgment, but only in respect of its civil aspects, and the case was remitted to the Versailles Court of
Appeal. That court gave a judgment upholding the findings of the court at first instance and awarded the applicant
damages. Subsequently the Paris industrial tribunal made awards in respect of unpaid wages and benefits. Relying
on art 4 (set out at para 52 below) of the Convention for the Protection of Human Rights and Fundamental


-----

Freedoms 1950 (the convention), which prohibited slavery or servitude and forced or compulsory labour, the
applicant complained to the European Court of Human Rights that the criminal law provisions applicable in France
did not afford her sufficient and effective protection against the servitude in which she had been held, or at the very
least against the forced and compulsory labour which she had been required to perform. The government
contended by way of primary submission that the applicant could no longer claim to be the victim of a violation of
the convention within the meaning of art 34 (set out, so far as material, at para 60, below) because, inter alia, the
sanction imposed by the Versailles Court of Appeal and the awards made by the industrial tribunal were favourable
to her and afforded redress for the alleged breach of the convention. The applicant did not dispute that certain
measures and decisions had been taken which were favourable to her but stressed that the national authorities had
never acknowledged, expressly or in substance, her complaint that the state had failed to comply with its positive
obligation to secure tangible and effective protection against the practices prohibited by art 4 of the convention and
to which she had been subjected by Mr and Mrs B.

**[*655]**

**Held – (1) The government's argument alleging that the applicant had lost her status as a victim raised questions**
about the French criminal law's provisions on slavery, servitude and forced or compulsory labour and the manner in
which those provisions were interpreted by the domestic courts. Those questions were closely linked to the merits
of the applicant's complaint. Consequently they would be examined under the substantive provision of the
convention relied on by the applicant (see para 63, below).

(2) Article 4 of the convention enshrined one of the fundamental values of democratic societies. There was no
provision for exceptions and no derogation from it was permissible. In those circumstances, in accordance with
contemporary norms and trends, the member states' positive obligations under art 4 required the penalisation and
effective prosecution of any act aimed at maintaining a person in a situation of slavery or servitude. Although the
applicant was, in the instant case, clearly deprived of her personal autonomy, the evidence did not suggest that she
was held in slavery in the proper sense, in other words that Mr and Mrs B exercised a genuine right of legal
ownership over her, thus reducing her to the status of an 'object'. The applicant was, at the least, subjected to
forced labour within the meaning of art 4. Moreover, she was required to perform such forced labour for almost 15
hours a day, 7 days per week. She had not chosen to work for Mr and Mrs B and, as a minor, she had no
resources, was vulnerable and isolated, and had no means of subsistence other than in the home of Mr and Mrs B.
She was entirely at Mr and Mrs B's mercy, since her papers had been confiscated and she had been promised that
her immigration status would be regularised, which had never occurred. In addition, the applicant, who was
unlawfully present in French territory and in fear of arrest by the police, had no freedom of movement and no free
time. As she had not been sent to school, despite the promises made to her father, the applicant could not hope
that her situation would improve and was completely dependent on Mr and Mrs B. In those circumstances, the
applicant, a minor at the relevant time, was held in servitude within the meaning of art 4. Slavery and servitude were
not as such classified as offences under French criminal law. Articles 225-13 and 225-14 of the Criminal Code did
not deal specifically with the rights guaranteed under art 4 of the convention, but concerned, in a much more
restrictive way, exploitation through labour and subjection to working and living conditions that were incompatible
with human dignity. Consequently the applicant was not able to see those responsible for holding her in servitude
convicted under the criminal law. As the principal public prosecutor did not appeal on points of law against the Court
of Appeal's judgment, the appeal to the Court of Cassation concerned only the civil aspect of the case and Mr and
Mrs B's acquittal thus became final. Accordingly the criminal law legislation in force at the material time did not
afford the applicant practical and effective protection against the actions of which she was a victim. The increasingly
high standard being required in the area of the protection of human rights and fundamental liberties correspondingly
and inevitably required greater firmness in assessing breaches of the fundamental values of democratic societies. It
followed that there had been a violation of the respondent state's positive obligations under art 4 of the convention
(see 112, 120, 122, 126–129, 141, 142, 145–149, below); X and Y v Netherlands _[[1985] ECHR 8978/80, Stubbings](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1PN-00000-00&context=1519360)_
_v UK_ _[(1996) 1 BHRC 316, A v UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3MK-00000-00&context=1519360)_ _[(1998) 5 BHRC 137, Seguin v France (App no 42400/98) (admissibility decision,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W32Y-00000-00&context=1519360)_
7 March 2000), Van der Mussele v Belgium _[[1983] ECHR 8919/80, MC v Bulgaria (2003) 15 BHRC 627, Z v UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0D2-00000-00&context=1519360)_
_[(2001) 10 BHRC 384 and E v UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W41D-00000-00&context=1519360)_ _[[2002] ECHR 33218/96 considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X2SB-00000-00&context=1519360)_
**[*656] Cases cited**


-----

_A v UK_ _[(1998) 5 BHRC 137, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W32Y-00000-00&context=1519360)_

_Airey v Ireland_ _[[1979] ECHR 6289/73, (1979) 2 EHRR 305, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0KR-00000-00&context=1519360)_

_Amuur v France_ _[[1996] ECHR 19776/92, (1996) 22 EHRR 53, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X1HG-00000-00&context=1519360)_

_Association Ekin v France [2001] ECHR 39288/98, 17 July 2001, ECt HR._

_August v UK (App no 36505/02) (admissibility decision, 21 January 2003), ECt HR._

_[Brumarescu v Romania [1999] ECHR 28342/95, (1999) 33 EHRR 862, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X149-00000-00&context=1519360)_

_Calvelli v Italy_ _[[2002] ECHR 32967/96, 17 January 2002, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X362-00000-00&context=1519360)_

_Chahal v UK_ _[(1996) 1 BHRC 405, ECt HR,](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3X3-00000-00&context=1519360)_

_E v UK_ _[[2002] ECHR 33218/96, 26 November 2002, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X2SB-00000-00&context=1519360)_

_GG v Italy (App no 34574/97) (admissibility decision, 10 October 2002), ECt HR._

_Gnahore v France [2000] ECHR 40031/98, 19 September 2000, ECt HR._

_Ireland v UK_ _[[1978] ECHR 5310/71, (1978) 2 EHRR 25, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X27J-00000-00&context=1519360)_

_Isayeva v Russia_ _[[2005] ECHR 57950/00, 24 February 2005, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3W5-00000-00&context=1519360)_

_Karahalios v Greece (App no 62503/00) ( judgment, 11 December 2003), ECt HR._

_[MC v Bulgaria (2003) 15 BHRC 627, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W51W-00000-00&context=1519360)_

_Malama v Greece (App no ECHR 43622/98) (admissibility decision, 25 November 1999), ECt HR._

_Marckx v Belgium_ _[[1979] ECHR 6833/74, (1979) 2 EHRR 330, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1VJ-00000-00&context=1519360)_

_Seguin v France (App no 42400/98) (admissibility decision, 7 March 2000), ECt HR._

_Selmouni v France_ _[(1999) 7 BHRC 1, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W4R9-00000-00&context=1519360)_

_Soering v UK_ _[[1989] ECHR 14038/88, (1989) 11 EHRR 439, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X31X-00000-00&context=1519360)_

_Stubbings v UK_ _[(1996) 1 BHRC 316, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3MK-00000-00&context=1519360)_

_Van der Mussele v Belgium_ _[[1983] ECHR 8919/80, (1983) 6 EHRR 163, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0D2-00000-00&context=1519360)_
**[*657]**

_Van Droogenbroeck v Belgium (App no 7906/77) (admissibility decision) (1979) 17 DR 59, E Com HR;_ _[[1982]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X12N-00000-00&context=1519360)_
_[ECHR 7906/77, (1982) 4 EHRR 443, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X12N-00000-00&context=1519360)_

_X and Y v Netherlands_ _[[1985] ECHR 8978/80, (1985) 8 EHRR 235, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1PN-00000-00&context=1519360)_

_X v Netherlands (App no 9327/81) (1983) 32 DR 180, E Com HR._

_[Z v UK (2001) 10 BHRC 384, ECt HR.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W41D-00000-00&context=1519360)_
**Application**


-----

In an application (no 73316/01) to the European Court of Human Rights on 17 April 2001, relying on art 4 of the
Convention for the Protection of Human Rights and Fundamental Freedoms 1950, Siwa-Akofa Siliadin complained
that the criminal law provisions applicable in France did not afford her sufficient and effective protection against the
'servitude' in which she had been held, or at the very least against the 'forced and compulsory' labour which she
had been required to perform. The application was allocated to the Second Section of the court which, by a decision
of 1 February 2005, declared the application admissible. The facts are set out in the judgment of the court.

26 July 2005. The EUROPEAN COURT OF HUMAN RIGHTS (SECOND SECTION) delivered the following
judgment.
**PROCEDURE**

1. The case originated in an application (no 73316/01) against the French Republic lodged with the court under art
34 of the Convention for the Protection of Human Rights and Fundamental Freedoms 1950 (the convention) (Rome,
4 November 1950; TS 71 (1953); Cmnd 8969) by a Togolese national, Ms Siwa-Akofa Siliadin (the applicant), on 17
April 2001.

2. The applicant, who had been granted legal aid, was represented by Ms H Clement, of the Paris Bar. The French
government (the government) were represented by their agent, Mrs Edwige Belliard, Head of the Department of
Legal Affairs at the Ministry of Foreign Affairs.

3. Relying on art 4 of the convention, the applicant alleged that the criminal-law provisions applicable in France did
not afford her sufficient and effective protection against the 'servitude' in which she had been held, or at the very
least against the 'forced and compulsory' labour which she had been required to perform.

4. The application was allocated to the Second Section of the court (r 52(1) of the Rules of Court). Within that
Section, the Chamber that would consider the case (art 27(1) of the convention) was constituted as provided in r
26(1).

5. On 1 November 2004 the court changed the composition of its Sections (r 25(1)). This case was assigned to the
newly composed Second Section (r 52(1)).

6. By a decision of 1 February 2005, the court declared the application admissible.

7. The applicant and the government each filed observations on the merits (r 59(1)).

8. A hearing took place in public in the Human Rights Building, Strasbourg, on 3 May 2005 (r 59(3)).

There appeared before the court: (a) for the government Mrs E Belliard, Head of the Legal Affairs Department,
Ministry of Foreign Affairs, (agent), Mr G Dutertre, magistrat on secondment to the Human Rights Division, Legal
Affairs Department, Ministry of Foreign Affairs, Mrs J Vailhe, Drafting Secretary, Department of European and
International Affairs, Ministry of Justice, Mrs E Puren, from the Department of Criminal Affairs and Pardons, Ministry
of Justice, (counsel); (b) for the applicant Mrs H Clement, of the Paris Bar, (counsel), assisted by Ms B Bourgeois,
lawyer for the Committee against Modern Slavery.
**[*658]**

The court heard addresses by Mrs Belliard and Mrs Clement.
**THE FACTSI. The circumstances of the case**

9. The applicant was born in 1978 and lives in Paris.

10. She arrived in France on 26 January 1994, aged 15 years and 7 months, with Mrs D, a French national of
Togolese origin. She had a passport and a tourist visa.

11. It had been agreed that she would work at Mrs D's home until the cost of her air ticket had been reimbursed and
that Mrs D would attend to her immigration status and find her a place at school. In reality, the applicant became an
unpaid housemaid for Mr and Mrs D and her passport was taken from her.


-----

12. In the second half of 1994 Mrs D 'lent' the applicant to Mr and Mrs B, who had two small children, so that she
could assist the pregnant Mrs B with household work. Mrs B also had another daughter from a first marriage who
stayed with her during the holidays and at weekends. The applicant lived at Mr and Mrs B's home, her father having
given his consent.

13. On her return from the maternity hospital, Mrs B told the applicant that she had decided to keep her.

14. The applicant subsequently became a general housemaid for Mr and Mrs B. She worked seven days a week,
without a day off, and was occasionally and exceptionally authorised to go out on Sundays to attend mass. Her
working day began at 7.30 a m, when she had to get up and prepare breakfast, dress the children, take them to
nursery school or their recreational activities, look after the baby, do the housework and wash and iron clothes.

In the evening she prepared dinner, looked after the older children, did the washing up and went to bed at about
10.30 pm. In addition, she had to clean a studio flat, in the same building, which Mr B had made into an office.

The applicant slept on a mattress on the floor in the baby's room; she had to look after him if he woke up.

15. She was never paid, except by Mrs B senior, who gave her one or two 500 franc notes.

16. In December 1995 the applicant was able to escape with the help of a Haitian national who took her in for five or
six months. She looked after the latter's two children, was given appropriate accommodation and food, and
received 2,500 French francs (FRF) per month.

17. Subsequently, in obedience to her paternal uncle, who had been in contact with Mr and Mrs B, she returned to
the couple, who had undertaken to put her immigration status in order. However, the situation remained unchanged:
the applicant continued to carry out household tasks and look after the couple's children. She slept on a mattress
on the floor of the children's bedroom, then on a folding bed, and wore second-hand clothes. Her immigration status
had still not been regularised, she was not paid and did not attend school.

18. On an unspecified date, the applicant managed to recover her passport, which she entrusted to an
acquaintance of Mr and Mrs B. She also confided in a neighbour, who alerted the Committee against **_Modern_**
**_Slavery, which in turn filed a complaint with the prosecutor's office about the applicant's case._**
**[*659]**

19. On 28 July 1998 the police raided Mr and Mrs B's home.

20. The couple were prosecuted on charges of having obtained from July 1995 to July 1998 the performance of
services without payment or in exchange for payment that was manifestly disproportionate to the work carried out,
by taking advantage of that person's vulnerability or state of dependence; with having subjected an individual to
working and living conditions that were incompatible with human dignity by taking advantage of her vulnerability or
state of dependence; and with having employed and maintained in their service an alien who was not in possession
of a work permit.

21. On 10 June 1999 the Paris tribunal de grande instance delivered its judgment.

22. It found that the applicant's vulnerability and dependence in her relationship with Mr and Mrs B was proved by
the fact that she was unlawfully resident in France, was aware of that fact and feared arrest, that Mr and Mrs B
nurtured that fear while promising to secure her leave to remain – a claim that was confirmed by her uncle and her
father—and by the fact that she had no resources, no friends and almost no family to help her.

23. As to the failure to provide any or adequate remuneration, the court noted that it had been established that the
young woman had remained with Mr and Mrs B for several years, was not a member of their family, could not be
regarded as a foreign au pair who had to be registered and given free time in order to improve her language skills,
was kept busy all day with housework, did not go to school and was not training for a profession and that, had she
not been in their service, Mr and Mrs B would have been obliged to employ another person, given the amount of
work created by the presence of four children in the home.


-----

It therefore concluded that the offence set out in art 225-13 of the Criminal Code (see para 46, below) was
substantiated.

24. The court also found it established that Mr and Mrs B were employing an alien who was not in possession of a
work permit.

25. The court noted that the parties had submitted differing accounts concerning the allegations that the working
and living conditions were incompatible with human dignity.

It found that the applicant clearly worked long hours and did not enjoy a day off as such, although she was given
permission to attend mass. It noted that a person who remained at home with four children necessarily began his or
her work early in the morning and finished late at night, but had moments of respite during the day; however, the
scale of Mrs B's involvement in this work had not been established.

26. The court concluded that, while it seemed established that employment regulations had not been observed in
respect of working hours and rest time, this did not suffice to consider that the working conditions were incompatible
with human dignity, which would have implied, for example, an infernal rhythm, frequent insults and harassment,
the need for particular physical strength that was disproportionate to the employee's constitution and having to work
in unhealthy premises, which had not been the case in this instance.

27. As to the applicant's accommodation, the court noted that Mr and Mrs B, who were well-off, had not seen fit to
set aside an area for the applicant's personal use and that, although this situation was regrettable and indicated
their lack of consideration for her, her living conditions could not be held to infringe human dignity, given that a
number of people, especially in the Paris region, did not have their own rooms. Accommodation which infringed
human dignity implied an unhygienic, unheated room, with no possibility of looking after one's basic hygiene, or
premises which were so far below the applicable norms that occupation would be dangerous.
**[*660]**

28. Accordingly, the court found that the offence set out in art 225-14 of the Criminal Code had not been
substantiated.

None the less, the judges concluded that the offences of which Mr and Mrs B were convicted were incontestably
serious and were to be severely punished, particularly as the couple considered that they had treated the applicant
quite properly.

Accordingly, they sentenced them to twelve months' imprisonment each, of which seven months were suspended,
imposed a fine of FRF 100,000 and ordered them to pay, jointly and severally, FRF 100,000 to the applicant in
damages. In addition, Mr and Mrs B forfeited their civic, civil and family rights for three years.

29. Mr and Mrs B appealed against this decision.

30. On 20 April 2000 the Paris Court of Appeal gave an interlocutory judgment ordering further investigations.

31. On 19 October 2000 it delivered its judgment on the merits.

32. The Court of Appeal found that the additional investigation had made it possible to confirm that the applicant
had arrived in France aged 15 years and seven months, in possession of a passport and a three-month tourist visa.
During the period that she lived with Mrs D, from January to October 1994, she had been employed by the latter,
firstly, to do housework, cook and look after her child, and, secondly, in the latter's clothing business, where she
also did the cleaning and returned to the rails clothes that customers had tried on, without remuneration.

33. In or about October 1994 the applicant had spent a few days at Mr and Mrs B's home, shortly before Mrs B
gave birth to her third child. She travelled by underground to Mr and Mrs B's home every day and returned to Mrs
D's house in the evening to sleep.


-----

34. In July–August 1995 she was 'lent' to Mr and Mrs B, and stayed in their home until December 1995, when she
left for Mrs G's home, where she was remunerated for her work and given accommodation. She had returned to Mr
and Mrs B in May-June 1996 on her uncle's advice.

35. The appeal court noted that it had been established that the applicant was an illegal immigrant and had not
received any real remuneration.

Further, it noted that it appeared that the applicant was proficient in French, which she had learnt in her own
country.

In addition, she had learnt to find her way around Paris in order, initially, to go from Mrs D's home to the latter's
business premises, and later to travel to Maisons-Alfort, where Mrs G lived, and finally to return to Mr and Mrs B's
home.

36. She had a degree of independence, since she took the children to the locations where their educational and
sports activities were held, and subsequently collected them. She was also able to attend a Catholic service in a
church near Mr and Mrs B's home. In addition, she left the house to go shopping, since it was on one of those
occasions that she had met Mrs G and agreed with her to go to the latter's home.

37. The Court of Appeal further noted that the applicant had had an opportunity to contact her uncle by telephone
outside the G's home and to pay for calls from a telephone box. She had met her father and her uncle and had
never complained about her situation.
**[*661]**

38. Furthermore, Mrs B's mother confirmed that the applicant spoke good French and that she was in the habit of
giving her small sums of money for family celebrations. She had frequently had the applicant and her grandchildren
to stay in her country house and had never heard her complain of ill-treatment or contempt, although she had been
free to express her views.

39. The applicant's uncle stated that she was free, among other things, to leave the house and call him from a
telephone box, that she was appropriately dressed, in good health and always had some money, which could not
have come from anyone but Mr and Mrs B. He had offered to give her money, but she had never asked for any. He
added that he had raised this question with Mrs B, who had told him that a certain amount was set aside every
month in order to build up a nest egg for the applicant, which would be given to her when she left, and that the girl
was aware of this arrangement.

He stated that, on the basis of what he had been able to observe and conclude from his conversations with the
applicant and with Mrs B, the girl had not been kept as a slave in the home in which she lived.

40. The Court of Appeal ruled that the additional investigations and hearings had shown that, while it did appear
that the applicant had not been paid or that the payment was clearly disproportionate to the amount of work carried
out (although the defendants' intention to create a nest egg that would be handed over to her on departure had not
been seriously disputed), in contrast, the existence of working or living conditions that were incompatible with
human dignity had not been established.

It also considered that it had not been established that the applicant was in a state of vulnerability or dependence
since, by taking advantage of her ability to come and go at will, contacting her family at any time, leaving Mr and
Mrs B's home for a considerable period and returning without coercion, the girl had, in spite of her youth, shown an
undeniable form of independence, and vulnerability could not be established merely on the basis that she was an
alien.

Accordingly, the Court of Appeal acquitted the defendants of all the charges against them.

41. The applicant appealed on points of law against that judgment. No appeal was lodged by the principal public
prosecutor's office.


-----

42. In a letter of 27 October 2000 to the Chair of the Committee against **_Modern Slavery, the public prosecutor_**
attached to the Paris Court of Appeal wrote:

'In your letter of 23 October 2000 you asked me to inform you whether the public prosecution office under my
direction has lodged an appeal on points of law against the judgment delivered on 19 October 2000 by the 12th
Division of the court which heard the appeal in the criminal proceedings against Mr and Mrs B.

The Court of Appeal's decision to acquit the defendants of the two offences of insufficiently remunerating a
person in a vulnerable position and subjecting a person in a vulnerable or dependent state to demeaning
working conditions was based on an assessment of elements of pure fact.

Since the Court of Cassation considers that such assessments come within the unfettered discretion of the trial
courts, an appeal on points of law could not be effectively argued.

That is why I have not made use of that remedy.'

**[*662]**

43. The Court of Cassation delivered its judgment on 11 December 2001. It ruled as follows:

'All judgments must contain reasons justifying the decision reached; giving inadequate or contradictory reasons
is tantamount to giving no reasons;

After an investigation into the situation of [the applicant], a young Togolese national whom they had employed
and lodged in their home since she was 16, V and AB were directly summoned before the criminal court for,
firstly, taking advantage of a person's vulnerability or dependent state, to obtain services without payment or
any adequate payment, contrary to art 225-13 of the Criminal Code and, secondly, for subjecting that person to
working or living conditions incompatible with human dignity, contrary to art 225-14 of the same Code;

In acquitting the defendants of the two above-mentioned offences and dismissing the civil party's claims in
connection therewith, the appeal court, after having noted that [the applicant] was a foreign minor, without a
residence or work permit and without resources, none the less stated that her state of vulnerability and
dependence, a common constituent element of the alleged offences, had not been established, given that the
girl enjoyed a certain freedom of movement and that vulnerability could not be established merely on the basis
that she was an alien;

Furthermore, in finding the offence set out in art 225-13 of the Criminal Code unsubstantiated, the courts added
that “ it did appear that the applicant had not been paid or that the payment was clearly disproportionate to the
amount of work carried out[”] (although the defendants' intention to create a nest egg that would be handed
over to her on departure had not been seriously disputed);

Finally, in acquitting the defendants of the offence set out in art 225-14 of the Criminal Code, the courts found
that subjection to working or living conditions incompatible with human dignity “had not been established”;

However, in ruling in this way, with reasons that were inadequate and ineffective with regard to the victim's
state of vulnerability and dependence and contradictory with regard to her remuneration, and without specifying
the factual elements which established that her working conditions were compatible with human dignity, the
Court of Appeal failed to draw from its findings the legal conclusions which were required in the light of art 22513 of the Criminal Code and did not justify its decision in the light of art 225-14 of that Code;

The judgment must therefore be quashed

For these reasons;

[The Court of Cassation] quashes the above-mentioned judgment of the Paris Court of Appeal dated 19
October 2000 but only in respect of the provisions dismissing the civil party's requests for compensation in
respect of the offences provided for in arts 225-13 and 225-14 of the Criminal Code, all other provisions being


-----

expressly maintained, and instructs that the case be remitted, in accordance with the law, for a rehearing of the
matters in respect of which this appeal has been allowed '

44. The Versailles Court of Appeal, to which the case was subsequently referred, delivered its judgment on 15 May
2003. It ruled, inter alia, as follows:
**[*663]**

'As was correctly noted at first instance, the evidence shows that (the applicant), an alien who arrived in France
at the age of 16, worked for several years for Mr and Mrs B, carrying out household tasks and looking after
their three, and subsequently four, children for seven days a week, from 7 a m to 10 p m, without receiving any
remuneration whatsoever; contrary to the defendants' claims, she was not considered a family friend, since she
was obliged to follow Mrs B's instructions regarding her working hours and the work to be done, and was not
free to come and go as she pleased;

In addition, there is no evidence to show that a nest egg has been established for her, since the list of
payments allegedly made by the defendants is in Mrs B's name;

It was only at the hearing before the tribunal de grande instance that the defendants gave the victim the sum of
50,000 francs;

Finally, far from showing that [the applicant] was happy to return to Mr and Mrs B's home, the conditions in
which she did so after an absence of several months are, on the contrary, indicative of the pressure she had
been subjected to by her family and of her state of resignation and emotional disarray;

With regard to the victim's state of dependence and vulnerability during the period under examination, it should
be noted that this young girl was a minor, of Togolese nationality, an illegal immigrant in France, without a
passport, more often than not without money, and that she was able to move about only under Mrs B's
supervision for the purposes of the children's educational and sports activities;

Accordingly, it was on appropriate grounds, to which this court subscribes, that the court at first instance found
that the constituent elements of the offence punishable under art 225-13 of the Criminal Code were
substantiated in respect of the defendants;

With regard to the offence of subjecting a person in a vulnerable or dependent position to working or living
conditions that are incompatible with human dignity:

As the court of first instance correctly noted, carrying out household tasks and looking after children throughout
the day could not by themselves constitute working conditions incompatible with human dignity, this being the
lot of many mothers; in addition, the civil party's allegations of humiliating treatment or harassment have not
been proved;

Equally, the fact that [the applicant] did not have an area reserved for her personal use does not mean that the
accommodation was incompatible with human dignity, given that Mr and Mrs B's own children shared the same
room, which was not in the least unhygienic;

Accordingly, the constituent elements of this second offence have not been established in respect of Mr and
Mrs B;

Independently of the sums due to [the applicant] in wages and the payment of 50,000 francs in a belated
gesture of partial remuneration, Mr B, whose intellectual and cultural level was such as to enable him to grasp
fully the unlawfulness of his conduct, but who allowed the situation to continue, probably through cowardice,
has, together with Mrs B, caused [the applicant], considerable psychological trauma, for which should be
awarded 15,245 euros in compensation, as assessed by the court of first instance.'

**[*664]**


-----

45. On 3 October 2003 the Paris industrial tribunal delivered judgment following an application submitted by the
applicant. It awarded her 31,238 euros in respect of arrears of salary, 1,647 euros in respect of the notice period
and 164 euros in respect of holiday leave.
_II. Relevant law_

46.

A. Criminal Code as worded at the material time
**Article 225-13**

'It shall be an offence punishable by two years' imprisonment and a fine of 500,000 francs to obtain from an
individual the performance of services without payment or in exchange for payment that is manifestly
disproportionate to the amount of work carried out, by taking advantage of that person's vulnerability or state of
dependence.'

**Article 225-14**

It shall be an offence punishable by two years' imprisonment and a fine of 500,000 francs to subject an
individual to working or living conditions which are incompatible with human dignity by taking advantage of that
individual's vulnerability or state of dependence.'

47.

B. Criminal Code as amended by the Law of 18 March 2003
**Article 225-13**

'It shall be an offence punishable by five years' imprisonment and a fine of 150,000 euros to obtain from an
individual whose vulnerability or state of dependence is apparent or of which the offender is aware the
performance of services without payment or in exchange for payment which is manifestly disproportionate to
the amount of work carried out.'

**Article 225-14**

'It shall be an offence punishable by five years' imprisonment and a fine of 150,000 euros to subject an
individual whose vulnerability or state of dependence is apparent or of which the offender is aware to working
or living conditions which are incompatible with human dignity.'

**Article 225-15**

'The offences set out in arts 225-13 and 225-14 shall be punishable by seven years' imprisonment and a fine of
200,000 euros if they are committed against more than one person.

If they are committed against a minor, they shall be punishable by seven years' imprisonment and a fine of
200,000 euros.

If they are committed against more than one person, including one or more minors, they shall be punishable by
ten years' imprisonment and a fine of 300,000 euros.'

**[*665]**

48.

C. Information report by the French National Assembly's joint fact-finding taskforce on the various forms of modern
**_slavery, tabled on 12 December 2001 (extracts):_**

'The situation of minors, who are more vulnerable and ought to receive special protection on account of their
age, strikes the taskforce as highly worrying: children doomed to work as domestic servants or in illegal
workshops represent easy prey for traffickers of all kinds


-----

What solutions can be proposed in view of the growth in these forms of slavery? Some already exist, of course.
We have available a not inconsiderable arsenal of punitive measures. However, these are not always used in
full and are proving an insufficient deterrent when put to the test. The police and the justice system are
obtaining only limited results

The determination of the drafters of the new Criminal Code to produce a text imbued with the concept of
human rights is particularly clear from the provisions of arts 225-13 and 225-14 of the Code, which created new
offences making it unlawful to impose working and living conditions that are contrary to human dignity. As
demonstrated by the explanatory memorandum to the initial 1996 bill, the purpose of those provisions was
primarily to combat 'slum landlords' or other unscrupulous entrepreneurs who shamelessly exploit foreign
workers who are in the country illegally

The concept, found in both arts 225-13 and 225-14 of the Criminal Code, of the abuse of an individual's
vulnerability or state of dependence contains ambiguities that could be prejudicial to their application

Thus, by failing on the one hand to specify the possible categories of individuals defined as vulnerable and,
further, by failing to require that the vulnerability be of a “particular” nature, the legislature has conferred on arts
225-13 and 225-14 an extremely wide, or even vague, scope, one that is likely to cover circumstances of
vulnerability or dependence that are “social or cultural in nature”

The current wording of the Criminal Code, especially that of art 225-14, is highly ambiguous, since it requires,
on the one hand, that the victim has been subjected to working or living conditions that are incompatible with
human dignity and, on the other, that those conditions have been imposed through the “abuse” of his or her
vulnerability or state of dependency.

It may therefore logically be concluded, as Mr Guy Meyer, deputy public prosecutor at the Paris public
prosecutor's office, stated before the Taskforce, that, “by converse implication provided one has not taken
advantage of [an individual's] vulnerability, it is alright to undermine human dignity Undermining human dignity
ought to be an offence in itself and, possibly, abuse of [an individual's] vulnerability or status as a minor an
aggravating factor”.

That said, and since the law is silent, it is up to the court to determine where the scope of those provisions
ends. In this connection, analysis of the case law reveals differences in evaluation that impede the uniform
application of the law throughout France, since, as Ms Francoise Favaro rightly noted when addressing the
Taskforce: “We are in a sort of ephemeral haze in which everything is left to the judge's assessment”

**[*666]**

Even more surprisingly, on 19 October 2000 the same Court of Appeal refused in another case to apply the
provisions of arts 225-13 and 225-14 in favour of a young woman, a domestic slave, despite the fact that she
was a minor at the relevant time. In its judgment, the court noted, inter alia: “It had not been established that
the applicant was in a position of vulnerability or dependence as, by taking advantage of the possibility of
coming and going at will, contacting her family at any time, leaving Mr and Mrs X's home for a considerable
period and returning without coercion, the girl had, in spite of her youth, shown an undeniable form of
independence, and vulnerability could not be established merely on the basis that she was an alien”

It is therefore apparent that, in the absence of legal criteria enabling the courts to determine whether there has
been abuse of [an individual's] vulnerability or state of dependence, the provisions of arts 225-13 and 225-14 of
the Criminal Code are open to interpretation in different ways, some more restrictive than others

Whether with regard to actual or potential sentences, the shortcomings of the provisions are clearly visible, in
view of the seriousness of the factual elements characteristic of modern slavery

Bearing in mind, on the one hand, the constitutional status of the values protected by arts 225-13 and 225-14
of the Criminal Code and, on the other, the seriousness of the offences in such cases, the inconsequential


-----

nature of the penalties faced by those guilty of them is surprising, and raises questions about the priorities of
the French criminal-justice system

The minors whose cases the taskforce has had to examine are minors caught up or at risk of being caught up
in slavery, whether for the provision of sex or labour. More often than not they are illegal immigrants.'

49.

D. Documents of the Parliamentary Assembly of the Council of Europe
**Report by the Committee on Equal Opportunities for Women and Men, dated 17 May 2001(extract)**

'In France, since its foundation in 1994 the Committee against **_Modern Slavery (CCEM) has taken up the_**
cases of over 200 domestic slavery victims, mostly originating from West Africa (Ivory Coast, Togo, Benin) but
also from Madagascar, Morocco, India, Sri Lanka and the Philippines. The majority of victims were women
(95%). One-third arrived in France before they came of age and most of them suffered physical violence or
sexual abuse.

The employers mostly came from West Africa or the Middle East. 20% are French nationals. 20% enjoyed
immunity from prosecution, among them one diplomat from Italy and five French diplomats in post abroad.
Victims working for diplomats mainly come from India, Indonesia, the Philippines and Sri Lanka. It has been
estimated that there are several thousand victims of domestic slavery in France.'

**Recommendation 1523 (2001), adopted on 26 June 2001**

'1. In the last few years a new form of slavery has appeared in Europe, namely domestic slavery. It has been
established that over 4 m women are sold each year in the world.

**[*667]**

2. In this connection the Assembly recalls and reaffirms art 4(1) of the Convention for the Protection of Human
Rights and Fundamental Freedoms (ECHR), which prohibits slavery and servitude, and also the definition of
slavery derived from the opinions and judgments of the European Commission of Human Rights and the
European Court of Human Rights.

3. The Assembly also recalls art 3 of the ECHR, which provides that no one shall be subjected to torture or to
inhuman or degrading treatment or punishment, and art 6, which proclaims the right of access to a court in civil
and criminal matters, including cases where the employer enjoys immunity from jurisdiction

5. It notes that the victims' passports are systematically confiscated, leaving them in a situation of total
vulnerability with regard to their employers, and sometimes in a situation bordering on imprisonment, where
they are subjected to physical and/or sexual violence.

6. Most of the victims of this new form of slavery are in an illegal situation, having been recruited by agencies
and having borrowed money to pay for their journey.

7. The physical and emotional isolation in which the victims find themselves, coupled with fear of the outside
world, causes psychological problems which persist after their release and leave them completely disoriented

9. It regrets that none of the Council of Europe member states expressly make domestic slavery an offence in
their criminal codes.

10. It accordingly recommends that the Committee of Ministers ask the governments of member states to:

i. make slavery and trafficking in human beings, and also forced marriage, offences in their criminal codes;

ii. strengthen border controls and harmonise policies for police co-operation, especially with respect to minors

vi. protect the rights of victims of domestic slavery by:


-----

a. generalising the issuing of temporary and renewable residence permits on humanitarian grounds;

b. taking steps to provide them with protection and with social, administrative and legal assistance;

c. taking steps for their rehabilitation and their reintegration, including the creation of centres to assist, among
others, victims of domestic slavery;

d. developing specific programmes for their protection;

e. increasing victims' time limits for bringing proceedings for offences of slavery;

f. establishing compensation funds for the victims of slavery '

**Recommendation 1663 (2004), adopted on 22 June 2004**

'1. The Parliamentary Assembly is dismayed that slavery continues to exist in Europe in the twenty-first
century. Although, officially, slavery was abolished over 150 years ago, thousands of people are still held as
slaves in Europe, treated as objects, humiliated and abused. Modern slaves, like their counterparts of old, are
forced to work (through mental or physical threat) with no or little financial reward. They are physically
constrained or have other limits placed on their freedom of movement and are treated in a degrading and
inhumane manner.

**[*668]**

2. Today's slaves are predominantly female and usually work in private households, starting out as migrant
domestic workers, au pairs or “mail-order brides”. Most have come voluntarily, seeking to improve their
situation or escaping poverty and hardship, but some have been deceived by their employers, agencies or
other intermediaries, have been debt-bonded and even trafficked. Once working (or married to a “consumer
husband”), however, they are vulnerable and isolated. This creates ample opportunity for abusive employers or
husbands to force them into domestic slavery

5. The Council of Europe must have zero tolerance for slavery. As an international organisation defending
human rights, it is the Council of Europe's duty to lead the fight against all forms of slavery and trafficking in
human beings. The organisation and its member states must promote and protect the human rights of the
victim and ensure that the perpetrators of the crime of domestic slavery are brought to justice so that slavery
can finally be eliminated from Europe.

6. The Assembly thus recommends that the Committee of Ministers:

i. in general:

_a. bring the negotiations on the Council of Europe draft convention on action against trafficking in human_
beings to a rapid conclusion;

_b. encourage member states to combat domestic slavery in all its forms as a matter of urgency, ensuring that_
holding a person in any form of slavery is a criminal offence in all member states;

_c. ensure that the relevant authorities in the member states thoroughly, promptly and impartially investigate all_
allegations of any form of slavery and prosecute those responsible;

ii. as concerns domestic servitude:

a. elaborate a charter of rights for domestic workers, as already recommended in Recommendation 1523
(2001) on domestic slavery. Such a charter, which could take the form of a Committee of Ministers'
recommendation or even of a convention, should guarantee at least the following rights to domestic workers:


-----

—the recognition of domestic work in private households as “real work”, that is, to which full employment rights
and social protection apply, including the minimum wage (where it exists), sickness and maternity pay as well
as pension rights;

—the right to a legally enforceable contract of employment setting out minimum wages, maximum hours and
responsibilities;

—the right to health insurance;

—the right to family life, including health, education and social rights for the children of domestic workers;

—the right to leisure and personal time;

—the right for migrant domestic workers to an immigration status independent of any employer, the right to
change employer and to travel within the host country and between all countries of the European Union and the
right to the recognition of qualifications, training and experience obtained in the home country '

50. Council of Europe Convention on Action against Trafficking in Human Beings (Warsaw, 16 May 2005; COE TS
197), opened for signature on 16 May 2005
**[*669] 'Preamble**

Considering that trafficking in human beings may result in slavery for victims;

Considering that respect for victims' rights, protection of victims and action to combat trafficking in human
beings must be the paramount objectives;

Considering that all actions or initiatives against trafficking in human beings must be non-discriminatory, take
gender equality into account as well as a child-rights approach

Bearing in mind the following recommendations of the Parliamentary Assembly of the Council of Europe 1663
(2004) Domestic slavery: servitude, au pairs and mail-order brides

**Article 1—Purposes of the Convention**

(1) The purposes of this Convention are:

a to prevent and combat trafficking in human beings, while guaranteeing gender equality;

b to protect the human rights of the victims of trafficking, design a comprehensive framework for the protection
and assistance of victims and witnesses, while guaranteeing gender equality, as well as to ensure effective
investigation and prosecution

**Article 4—Definitions**

For the purposes of this Convention:

a “Trafficking in human beings” shall mean the recruitment, transportation, transfer, harbouring or receipt of
persons, by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of deception,
of the abuse of power or of a position of vulnerability or of the giving or receiving of payments or benefits to
achieve the consent of a person having control over another person, for the purpose of exploitation.
Exploitation shall include, at a minimum, the exploitation of the prostitution of others or other forms of sexual
exploitation, forced labour or services, slavery or practices similar to slavery, servitude or the removal of
organs;

b The consent of a victim of “trafficking in human beings” to the intended exploitation set forth in subparagraph
(a) of this article shall be irrelevant where any of the means set forth in subparagraph (a) have been used;


-----

c The recruitment, transportation, transfer, harbouring or receipt of a child for the purpose of exploitation shall
be considered “trafficking in human beings” even if this does not involve any of the means set forth in
subparagraph (a) of this article;

d “Child” shall mean any person under eighteen years of age;

e “Victim” shall mean any natural person who is subject to trafficking in human beings as defined in this article

**Article 19—Criminalisation of the use of services of a victim**

Each Party shall consider adopting such legislative and other measures as may be necessary to establish as
criminal offences under its internal law, the use of services which are the object of exploitation as referred to in
Article 4 paragraph a of this Convention, with the knowledge that the person is a victim of trafficking in human
beings.'

**[*670]**

51.

E. Other international conventions
**Forced Labour Convention, adopted on 28 June 1930 by the General Conference of the International Labour**
**Organisation (ratified by France on 24 June 1937)'Article 2**

(1) For the purposes of this Convention the term forced or compulsory labour shall mean all work or service
which is exacted from any person under the menace of any penalty and for which the said person has not
offered himself voluntarily.

(2) Nevertheless, for the purposes of this Convention the term forced or compulsory labour shall not include:

(a) any work or service exacted in virtue of compulsory military service laws for work of a purely military
character;

(b) any work or service which forms part of the normal civic obligations of the citizens of a fully self-governing
country;

(c) any work or service exacted from any person as a consequence of a conviction in a court of law, provided
that the said work or service is carried out under the supervision and control of a public authority and that the
said person is not hired to or placed at the disposal of private individuals, companies or associations;

(d) any work or service exacted in cases of emergency, that is to say, in the event of war or of a calamity or
threatened calamity, such as fire, flood, famine, earthquake, violent epidemic or epizootic diseases, invasion by
animal, insect or vegetable pests, and in general any circumstance that would endanger the existence or the
well-being of the whole or part of the population;

(e) minor communal services of a kind which, being performed by the members of the community in the direct
interest of the said community, can therefore be considered as normal civic obligations incumbent upon the
members of the community, provided that the members of the community or their direct representatives shall
have the right to be consulted in regard to the need for such services.

**Article 3**

For the purposes of this Convention the term competent authority shall mean either an authority of the
metropolitan country or the highest central authority in the territory concerned.

**Article 4**

(1) The competent authority shall not impose or permit the imposition of forced or compulsory labour for the
benefit of private individuals, companies or associations.


-----

(2) Where such forced or compulsory labour for the benefit of private individuals, companies or associations
exists at the date on which a Member's ratification of this Convention is registered by the Director-General of
the International Labour Office, the Member shall completely suppress such forced or compulsory labour from
the date on which this Convention comes into force for that Member.'

**[*671] Slavery Convention, signed in Geneva on 25 September 1926, which entered into force on 9 March**
**1927, in accordance with the provisions of art 12'Article 1**

For the purpose of the present Convention, the following definitions are agreed upon:

(1) Slavery is the status or condition of a person over whom any or all of the powers attaching to the right of
ownership are exercised.

(2) The slave trade includes all acts involved in the capture, acquisition or disposal of a person with intent to
reduce him to slavery; all acts involved in the acquisition of a slave with a view to selling or exchanging him; all
acts of disposal by sale or exchange of a slave acquired with a view to being sold or exchanged, and, in
general, every act of trade or transport in slaves

**Article 4**

The High Contracting Parties shall give to one another every assistance with the object of securing the
abolition of slavery and the slave trade.

**Article 5**

The High Contracting Parties recognise that recourse to compulsory or forced labour may have grave
consequences and undertake, each in respect of the territories placed under its sovereignty, jurisdiction,
protection, suzerainty or tutelage, to take all necessary measures to prevent compulsory or forced labour from
developing into conditions analogous to slavery.

It is agreed that:

(1) Subject to the transitional provisions laid down in paragraph (2) below, compulsory or forced labour may
only be exacted for public purposes;

(2) In territories in which compulsory or forced labour for other than public purposes still survives, the High
Contracting Parties shall endeavour progressively and as soon as possible to put an end to the practice. So
long as such forced or compulsory labour exists, this labour shall invariably be of an exceptional character,
shall always receive adequate remuneration, and shall not involve the removal of the labourers from their usual
place of residence;

(3) In all cases, the responsibility for any recourse to compulsory or forced labour shall rest with the competent
central authorities of the territory concerned.'

**[*672] Supplementary Convention on the Abolition of Slavery, the Slave Trade, and Institutions and**
**Practices Similar to Slavery, adopted on 30 April 1956 and which entered into force in respect of France on**
**26 May 1964'Section I. Institutions and Practices Similar to SlaveryArticle I**

Each of the States Parties to this Convention shall take all practicable and necessary legislative and other
measures to bring about progressively and as soon as possible the complete abolition or abandonment of the
following institutions and practices, where they still exist and whether or not they are covered by the definition
of slavery contained in Article 1 of the Slavery Convention signed at Geneva on 25 September, 1926:

(a) debt bondage, that is to say, the status or condition arising from a pledge by a debtor of his personal
services or of those of a person under his control as security for a debt, if the value of those services as
reasonably assessed is not applied towards the liquidation of the debt or the length and nature of those
services are not respectively limited and defined;


-----

(b) serfdom, that is to say, the condition or status of a tenant who is by law, custom or agreement bound to live
and labour on land belonging to another person and to render some determinate service to such other person,
whether for reward or not, and is not free to change his status

(d) any institution or practice whereby a child or young person under the age of eighteen years, is delivered by
either or both of his natural parents or by his guardian to another person, whether for reward or not, with a view
to the exploitation of the child or young person or of his labour.'

**International Convention on the Rights of the Child, dated 20 November 1989 (entered into force in respect**
**of France on 6 September 1990)'Article 19**

(1) States Parties shall take all appropriate legislative, administrative, social and educational measures to
protect the child from all forms of physical or mental violence, injury or abuse, neglect or negligent treatment,
maltreatment or exploitation, including sexual abuse, while in the care of parent(s), legal guardian(s) or any
other person who has the care of the child.

(2) Such protective measures should, as appropriate, include effective procedures for the establishment of
social programmes to provide necessary support for the child and for those who have the care of the child, as
well as for other forms of prevention and for identification, reporting, referral, investigation, treatment and
follow-up of instances of child maltreatment described heretofore, and, as appropriate, for judicial involvement

**Article 32**

(1) States Parties recognize the right of the child to be protected from economic exploitation and from
performing any work that is likely to be hazardous or to interfere with the child's education, or to be harmful to
the child's health or physical, mental, spiritual, moral or social development.

**[*673]**

(2) States Parties shall take legislative, administrative, social and educational measures to ensure the
implementation of the present article. To this end, and having regard to the relevant provisions of other
international instruments, States Parties shall in particular:

(a) Provide for a minimum age or minimum ages for admission to employment;

(b) Provide for appropriate regulation of the hours and conditions of employment;

(c) Provide for appropriate penalties or other sanctions to ensure the effective enforcement of the present
article

**Article 36**

States Parties shall protect the child against all other forms of exploitation prejudicial to any aspects of the
child's welfare.'

**THE LAWI. Alleged violation of art 4 of the convention**

52. The applicant complained that there had been a violation of art 4 of the convention. This provision states:

'(1) No one shall be held in slavery or servitude.

(2) No one shall be required to perform forced or compulsory labour.'

A. Whether the applicant had 'victim' status

53. The government contended by way of primary submission that the applicant could no longer claim to be the
victim of a violation of the convention within the meaning of art 34.

They stated at the outset that they did not contest that the applicant had been the victim of particularly
reprehensible conduct on the part of the couple who had taken her in, or that the Paris Court of Appeal's judgment
of 19 October 2000 had failed to acknowledge the reality of that situation as a matter of law. However, they noted


-----

that the applicant had not appealed against the first-instance judgment which had convicted her 'employers' solely
on the basis of art 225-13 of the Criminal Code and that it should be concluded from this that she had accepted
their conviction under that article alone.

Accordingly, the applicant could not use the absence of a conviction under art 225-14 of the Criminal Code to argue
that she still had victim status.

54. Furthermore, the government noted that the applicant's appeal on points of law had still been pending when her
application was lodged with the court. None the less, following the Court of Cassation's judgment quashing the
ruling by the Paris Court of Appeal, the court of appeal to which the case was subsequently remitted had
recognised the applicant's state of dependence and vulnerability within the meaning of art 225-13 of the Criminal
Code, as well as the exploitation to which she had been subjected, although it had been required only to examine
the civil claims. They emphasised that, in line with the case law, a decision or measure favourable to an applicant
was sufficient to deprive him or her of 'victim' status, provided that the national authorities had acknowledged, either
expressly or in substance, and then afforded redress for, the breach of the convention.
**[*674]**

55. The government concluded that the sanction imposed by the Versailles Court of Appeal was to be considered
as having afforded redress for the violation alleged by the applicant before the court, especially as she had not
appealed on points of law against its judgment. In addition, they pointed out that the Paris industrial tribunal had
made awards in respect of unpaid wages and benefits.

56. Finally, the applicant's immigration status had been regularised and she had received a residence permit
enabling her to reside in France lawfully and to pursue her studies. In conclusion, the government considered that
the applicant could no longer claim to be the victim of a violation of the convention within the meaning of art 34.

57. The applicant did not dispute that certain measures and decisions had been taken which were favourable to
her.

58. However, she stressed that the national authorities had never acknowledged, expressly or in substance, her
complaint that the state had failed to comply with its positive obligation, inherent in art 4, to secure tangible and
effective protection against the practices prohibited by this article and to which she had been subjected by Mr and
Mrs B. Only a civil remedy had been provided.

59. She alleged that arts 225-13 and 225-14 of the Criminal Code, as worded at the material time, were too open
and elusive, and in such divergence with the European and international criteria for defining servitude and forced or
mandatory labour that she had not been secured effective and sufficient protection against the practices to which
she had been subjected.

60. Article 34 of the convention provides:

'The Court may receive applications from any person claiming to be the victim of a violation by one of the High
Contracting Parties of the rights set forth in the Convention or the protocols thereto '

61. The court reiterates that it falls first to the national authorities to redress any alleged violation of the convention.
In this regard, the question whether an applicant can claim to be the victim of the violation alleged is relevant at all
stages of the proceedings under the convention (see Karahalios v Greece (App no 62503/00) ( judgment, 11
December 2003) at para 21; and Malama v Greece (App no ECHR 43622/98) (admissibility decision, 25 November
1999)).

62. It is the settled case law of the court that the word 'victim' in the context of art 34 of the convention denotes the
person directly affected by the act or omission in issue, the existence of a violation of the convention being
conceivable even in the absence of prejudice; prejudice is relevant only in the context of art 41. Consequently, a
decision or measure favourable to an applicant is not in principle sufficient to deprive him of his status as a 'victim'
unless the national authorities have acknowledged, either expressly or in substance, and then afforded redress for,


-----

the breach of the convention (see, among other authorities, _Amuur v France_ _[[1996] ECHR 19776/92 at para 36;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7S1-DYBP-X1HG-00000-00&context=1519360)_
_[Brumarescu v Romania [1999] ECHR 28342/95 at para 50; and Association Ekin v France [2001] ECHR 39288/98).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F891-DYBP-X149-00000-00&context=1519360)_

63. The court considers that the government's argument alleging that the applicant had lost her status as a victim
raises questions about the French criminal law's provisions on slavery, servitude and forced or compulsory labour
and the manner in which those provisions are interpreted by the domestic courts. Those questions are closely
linked to the merits of the applicant's complaint. The court consequently considers that they should be examined
under the substantive provision of the convention relied on by the applicant (see, in particular, the following
judgments: _Airey v Ireland_ _[[1979] ECHR 6289/73; Gnahore v France [2000] ECHR 40031/98 at para 26; and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0KR-00000-00&context=1519360)_
_Isayeva v Russia_ _[[2005] ECHR 57950/00 at para 161).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X3W5-00000-00&context=1519360)_
**[*675]**

B. The merits
**_1. Applicability of art 4 and the positive obligations_**

64. The court notes that the government do not dispute that art 4 is applicable in the instant case.

65. The applicant considered that the exploitation to which she had been subjected while a minor amounted to a
failure by the state to comply with its positive obligation under arts 1 and 4 of the convention, taken together, to put
in place adequate criminal law provisions to prevent and effectively punish the perpetrators of those acts.

66. In the absence of rulings on this matter in respect of art 4, she referred in detail to the court's case law on
states' positive obligations with regard to arts 3 and 8 (see the judgments in: X and Y v Netherlands _[[1985] ECHR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1PN-00000-00&context=1519360)_
_[8978/80; A v UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1PN-00000-00&context=1519360)_ _[(1998) 5 BHRC 137; and MC v Bulgaria (2003) 15 BHRC 627).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W32Y-00000-00&context=1519360)_

67. She added that, in the various cases in question, the respondent states had been held to be responsible on
account of their failure, in application of art 1 of the convention, to set up a system of criminal prosecution and
punishment that would ensure tangible and effective protection of the rights guaranteed by arts 3 and/or 8 against
the actions of private individuals.

68. She emphasised that this obligation covered situations where the state authorities were criticised for not having
taken adequate measures to prevent the existence of the impugned situation or to limit its effects. In addition, the
scope of the state's positive obligation to protect could vary on account of shortcomings in its legal system,
depending on factors such as the aspect of law in issue, the seriousness of the offence committed by the private
individual concerned or particular vulnerability on the part of the victim. This was precisely the subject of her
application, in the specific context of protection of a minor's rights under art 4.

69. The applicant added that, in the absence of any appropriate criminal law machinery to prevent and punish the
direct perpetrators of alleged ill-treatment, it could not be maintained that civil proceedings to afford reparation of
the damage suffered was sufficient to provide her with adequate protection against possible assaults on her
integrity.

70. She considered that the right not to be held in servitude laid down in art 4(1) of the convention was an absolute
right, permitting of no exception in any circumstances. She noted that the practices prohibited under art 4 of the
convention were also the subject of specific international conventions which applied to both children and adults.

71. Accordingly, the applicant considered that the states had a positive obligation, inherent in art 4 of the
convention, to adopt tangible criminal law provisions that would deter such offences, backed up by law-enforcement
machinery for the prevention, detection and punishment of breaches of such provisions.

72. She further observed that, as the public prosecutor's office had not considered it necessary to appeal on points
of law on the grounds of public interest, the acquittal of Mr and Mrs B of the offences set out in arts 225-13 and 22514 of the Criminal Code had become final. Consequently, the court of appeal to which the case had been remitted
after the initial judgment was quashed could not return a guilty verdict nor, a fortiori, impose a sentence, but could
only decide whether to award civil damages. She considered that a mere finding that the constituent elements of


-----

the offence set out in art 225-13 of the Criminal Code had been substantiated and the imposition of a fine and
damages could not be regarded as an acknowledgment, whether express or in substance, of a breach of art 4 of
the convention.
**[*676]**

73. With regard to possible positive obligations, the government conceded that, if the line taken by the European
[Commission of Human Rights in X and Y v Netherlands [1985] ECHR 8978/80 were to be applied to the present](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1PN-00000-00&context=1519360)
case, then it appeared that they did indeed exist. They pointed out, however, that states had a certain margin of
appreciation when it came to intervening in the sphere of relations between individuals.

74. In this respect, they referred to the court's case law, and especially the judgments in _Calvelli v Italy_ _[[2002]](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X362-00000-00&context=1519360)_
_[ECHR 32967/96, A v UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X362-00000-00&context=1519360)_ _[(1998) 5 BHRC 137, and Z v UK (2001) 10 BHRC 384 at para 109, as well as the decision](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W32Y-00000-00&context=1519360)_
in the case of GG v Italy (App no 34574/97) (admissibility decision, 10 October 2002) in which the court had noted
in connection with art 3 that—

'criminal proceedings did not represent the only effective remedy in cases of this kind, but civil proceedings,
making it possible to obtain redress for the damage suffered must in principle be open to children who have
been subjected to ill-treatment.'

75. On that basis, the government argued that, in the instant case, the proceedings before the criminal courts which
led to the payment of damages were sufficient under art 4 in order to comply with any positive obligation arising
from the convention.

76. In the alternative, the government considered that in any event French criminal law fulfilled any positive
obligations arising under art 4. They submitted that the wording of arts 225-13 and 225-14 of the Criminal Code
made it possible to fight against all forms of exploitation through labour for the purposes of art 4 of the convention.
They stressed that these criminal law provisions had, at the time of the events complained of by the applicant,
already resulted in several criminal court rulings, thus establishing a case law, and that, since then, they had given
rise to various other decisions to the same effect.

77. The court points out that it has already been established that, with regard to certain convention provisions, the
fact that a state refrains from infringing the guaranteed rights does not suffice to conclude that it has complied with
its obligations under art 1 of the convention.

78. Thus, with regard to art 8 of the convention, it held as long ago as 1979:

'Nevertheless it does not merely compel the State to abstain from such interference: in addition to this primarily
negative undertaking, there may be positive obligations inherent in an effective “respect” for family life.

This means, among other things, that when the State determines in its domestic legal system the regime
applicable to certain family ties such as those between an unmarried mother and her child, it must act in a
manner calculated to allow those concerned to lead a normal family life. As envisaged by Article 8, respect for
family life implies in particular, in the Court's view, the existence in domestic law of legal safeguards that render
possible as from the moment of birth the child's integration in his family. In this connection, the State has a
choice of various means, but a law that fails to satisfy this requirement violates paragraph 1 of Article 8 without
there being any call to examine it under paragraph 2.' (Marckx v Belgium _[[1979] ECHR 6833/74 at para 31.)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1VJ-00000-00&context=1519360)_

**[*677]**

79. It subsequently clarified this concept:

'Positive obligations on the state are inherent, in the right to effective respect for private life under art 8; these
obligations may involve the adoption of measures even in the sphere of the relations of individuals between
themselves. While the choice of the means to secure compliance with art 8 in the sphere of protection against
acts of individuals is in principle within the state's margin of appreciation, effective deterrence against grave
acts such as rape, where fundamental values and essential aspects of private life are at stake, requires


-----

efficient criminal law provisions. Children and other vulnerable individuals, in particular, are entitled to effective
protection (see X v Netherlands _[[1985] ECHR 8978/80 at paras 23, 24 and 27; and August v UK (App no](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1PN-00000-00&context=1519360)_
[36505/02) (admissibility decision, 21 January 2003)).' (See MC v Bulgaria (2003) 15 BHRC 627 at para 150.)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W51W-00000-00&context=1519360)

80. As regards art 3 of the convention, the court has found on numerous occasions that:

'The obligation on high contracting parties under art 1 of the convention to secure to everyone within their
jurisdiction the rights and freedoms defined in the convention, taken together with art 3, requires states to take
measures designed to ensure that individuals within their jurisdiction are not subjected to torture or inhuman or
degrading treatment or punishment, including such ill-treatment administered by private individuals ' (See the
[following judgments: A v UK (1998) 5 BHRC 137 at para 22; Z v UK (2001) 10 BHRC 384 at paras 73–75; E v](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W32Y-00000-00&context=1519360)
[UK [2002] ECHR 33218/96; and MC v Bulgaria (2003) 15 BHRC 627 at para 149.)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7V1-DYBP-X2SB-00000-00&context=1519360)

81. It has also found that:

'Children and other vulnerable individuals, in particular, are entitled to state protection, in the form of effective
deterrence, against such serious breaches of personal integrity ' (See, mutatis mutandis, the judgments in X
[and Y v Netherlands [1985] ECHR 8978/80 at paras 21–27; Stubbings v UK (1996) 1 BHRC 316 at paras 62–](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1PN-00000-00&context=1519360)
[64; and A v UK (1998) 5 BHRC 137 at para 22, as well as the United Nations Convention on the Rights of the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W32Y-00000-00&context=1519360)
Child, arts 19 and 37.)

82. The court considers that, together with arts 2 and 3, art 4 of the convention enshrines one of the basic values of
the democratic societies making up the Council of Europe.

83. It notes that the Commission had proposed in 1983 that it could be argued that a government's responsibility
was engaged to the extent that it was their duty to ensure that the rules adopted by a private association did not run
contrary to the provisions of the convention, in particular where the domestic courts had jurisdiction to examine their
application (X v Netherlands (App no 9327/81) (1983) 32 DR 180).
**[*678]**

84. The court notes that, in referring to the above-mentioned case, the government accepted at the hearing that
positive obligations did appear to exist in respect of art 4.

85. In this connection, it notes that the art 4 of the Forced Labour Convention, adopted by the International Labour
Organisation on 28 June 1930 and ratified by France on 24 June 1937, provides:

'(1) The competent authority shall not impose or permit the imposition of forced or compulsory labour for the
benefit of private individuals, companies or associations.'

86. Furthermore, art 1 of the Supplementary Convention on the Abolition of Slavery, the Slave Trade, and
Institutions and Practices Similar to Slavery, adopted on 30 April 1956, which entered into force in respect of France
on 26 May 1964, states:

'Each of the States Parties to this Convention shall take all practicable and necessary legislative and other
measures to bring about progressively and as soon as possible the complete abolition or abandonment of the
following institutions and practices, where they still exist and whether or not they are covered by the definition
of slavery contained in Article 1 of the Slavery Convention signed at Geneva on 25 September, 1926: debt
bondage any institution or practice whereby a child or young person under the age of eighteen years, is
delivered by either or both of his natural parents or by his guardian to another person, whether for reward or
not, with a view to the exploitation of the child or young person or of his labour.'

87. In addition, with particular regard to children, art 19 of the International Convention on the Rights of the Child of
20 November 1989, which entered into force in respect of France on 6 September 1990, provides:


-----

'(1) States Parties shall take all appropriate legislative, administrative, social and educational measures to
protect the child from all forms of physical or mental violence, injury or abuse, maltreatment or exploitation,
including sexual abuse, while in the care of parent(s), legal guardian(s) or any other person who has the care
of the child.'

Article 32 provides:

'(1) States Parties recognize the right of the child to be protected from economic exploitation and from
performing any work that is likely to be hazardous or to interfere with the child's education, or to be harmful to
the child's health or physical, mental, spiritual, moral or social development.

(2) States Parties shall take legislative, administrative, social and educational measures to ensure the
implementation of the present article. To this end, and having regard to the relevant provisions of other
international instruments, States Parties shall in particular:

(a) Provide for a minimum age or minimum ages for admission to employment;

(b) Provide for appropriate regulation of the hours and conditions of employment;

**[*679]**

(c) Provide for appropriate penalties or other sanctions to ensure the effective enforcement of the present
article.'

88. Finally, the court notes that it appears from the Parliamentary Assembly's findings (see 'Relevant law' above)
that 'today's slaves are predominantly female and usually work in private households, starting out as migrant
domestic workers'.

89. In those circumstances, the court considers that limiting compliance with art 4 of the convention only to direct
action by the state authorities would be inconsistent with the international instruments specifically concerned with
this issue and would amount to rendering it ineffective. Accordingly, it necessarily follows from this provision that
governments have positive obligations, in the same way as under art 3 for example, to adopt criminal law provisions
[which penalise the practices referred to in art 4 and to apply them in practice (see MC v Bulgaria (2003) 15 BHRC](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W51W-00000-00&context=1519360)
_[627 at para 153).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W51W-00000-00&context=1519360)_
**_2. Alleged violation of art 4 of the convention_**

90. With regard to the violation of art 4 of the convention, the applicant noted from the outset that the right not to be
held in servitude laid down in this provision was an absolute one, in the same way as the right not to be compelled
to perform forced or compulsory labour.

91. She said that, although the convention did not define the terms servitude or 'forced or compulsory labour',
reference should be made to the relevant international conventions in this field to determine the meaning of these
concepts while importance had to be attached in the instant case to the criteria laid down by both the United
Nations and the Council of Europe for identifying modern forms of slavery and servitude, which were closely linked
to trafficking in human beings, and to the internationally recognised necessity of affording children special protection
on account of their age and vulnerability.

92. She pointed out that her situation had corresponded to three of the four servile institutions or practices referred
to in art 1 of the Supplementary Geneva Convention of 30 April 1956, namely debt bondage, the delivery of a child
or adolescent to a third person, whether for reward or not, with a view to the exploitation of his or her labour, and
serfdom. She noted that she had not come to France in order to work as a domestic servant but had been obliged
to do so as a result of the trafficking to which she had been subjected by Mrs B, who had obtained her parents'
agreement through false promises.


-----

She concluded that such 'delivery' of a child by her father, with a view to the exploitation of her labour, was similar
to the practice, analogous to slavery, referred to in art 1(d) of the United Nations Supplementary Convention of
1956.

93. The applicant also referred to the documentation published by the Council of Europe on domestic slavery and
pointed out that the criteria used included confiscation of the (individual's) passport, the absence of remuneration or
remuneration that was disproportionate to the services provided, deprivation of liberty or self-imposed
imprisonment, and cultural, physical and emotional isolation.

94. She added that it was clear from the facts that her situation was not temporary or occasional in nature, as was
normally the case with 'forced or compulsory labour'. Her freedom to come and go had been limited, her passport
had been taken away from her, her immigration status had been precarious before becoming illegal, and she had
also been kept by Mr and Mrs B in a state of fear that she would be arrested and expelled. She considered that this
was equivalent to the concept of self-imposed imprisonment described above.
**[*680]**

95. Referring to her working and living conditions at Mr and Mrs B's home, she concluded her exploitation at their
hands had compromised her education and social integration, as well as the development and free expression of
her personality. Her identity as a whole had been involved, which was a characteristic of servitude but not, in
general, of forced or compulsory labour.

96. She added that in addition to the unremunerated exploitation of another's work, the characteristic feature of
**_modern slavery was a change in the individual's state or condition, on account of the level of constraint or control_**
to which his or her person, life, personal effects, right to come and go at will or to take decisions was subjected.

She explained that, although she had not described her situation as 'forced labour' in the proceedings before the
Versailles Appeal Court, the civil party had claimed in its submissions that—

'the exploitation to which Ms Siliadin was subjected had, at the very least, the characteristics of “forced labour”
within the meaning of art 4(2) of the Convention in reality, she was a domestic slave who had been recruited in
Africa.'

97. As to the definition of 'forced or obligatory labour', the applicant drew attention to the case law of the
Commission and the court, and emphasised that developments in international law favoured granting special
protection to children.

98. She noted that French criminal law did not contain specific offences of slavery, servitude or forced or
compulsory labour, still less a definition of those three concepts that was sufficiently specific and flexible to be
adapted to the forms those practices now took. In addition, prior to the enactment of the law of 18 March 2003,
there had been no legislation that directly made it an offence to traffic in human beings.

99. Accordingly, the offences to which she had been subjected fell within the provisions of arts 225-13 and 225-14
of the Criminal Code as worded at the material time. These were non-specific texts of a more general nature, which
both required that the victim be in a state of vulnerability or dependence. Those concepts were as vague as that of
the offender's 'taking advantage', which was also part of the definition of the two offences. In this connection, she
emphasised that both legal commentators and the National Assembly's taskforce on the various forms of modern
**_slavery had highlighted the lack of legal criteria enabling the courts to determine whether such a situation obtained,_**
which had led in practice to unduly restrictive interpretations.

100. Thus, art 225-13 of the Criminal Code made it an offence to obtain another person's labour by taking
advantage of him or her. In assessing whether the victim was vulnerable or in a state of dependence, the courts
were entitled to take into account, among other circumstances, certain signs of constraint or control of the
individual. However, those were relevant only as the prerequisites for a finding of exploitation, not as constituent
elements of the particular form of the offence that was modern slavery. In addition, this article made no distinction


-----

between employers who took advantage of the illegal position of immigrant workers who were already in France
and those who deliberately placed them in such a position by resorting to trafficking in human beings.
**[*681]**

101. She added that, contrary to art 225-13, art 225-14 required, and continued to require, an infringement of
human dignity for the offence to be substantiated. That was a particularly vague concept, and one subject to
random interpretation. It was for this reason that neither her working nor living conditions had been found by the
court to be incompatible with human dignity.

102. The applicant said in conclusion that the criminal-law provisions in force at the material time had not afforded
her adequate protection from servitude or from forced or compulsory labour in their contemporary forms, which
were contrary to art 4 of the convention. As to the fact that the criminal proceedings had resulted in an award of
compensation, she considered that this could not suffice to absolve the state of its obligation to establish a criminal
law machinery which penalised effectively those guilty of such conduct and deterred others.

103. With regard to the alleged violation of art 4 of the convention, the government first observed that the
convention did not define the term 'servitude'. They submitted that, according to the case law, 'servitude' was close
to 'slavery', which was at the extreme end of the scale. However, servitude reflected a situation of exploitation which
did not require that the victim be objectified to the point of becoming merely another's property.

104. As to the difference between 'servitude' and 'forced or compulsory labour', they concluded from the case law of
the Commission and the court that servitude appeared to characterise situations in which denial of the individual's
freedom was not limited to the compulsory provision of labour, but also extended to his or her living conditions, and
that there was no potential for improvement, an element which was absent from the concept of 'forced or
compulsory labour'.

105. With regard to the difference between 'forced labour' and 'compulsory labour', the government noted that,
while the case law's definition of 'forced labour' as labour performed under the influence of 'physical or
psychological force' seemed relatively clear, the situation was less so with regard to 'compulsory labour'.

106. The government did not deny that the applicant's situation fell within art 4 of the convention and emphasised
that she herself had specifically described her situation as 'forced labour' within the meaning of art 4 of the
convention.

107. However, they submitted that the domestic judicial authorities had undisputedly remedied the violation of the
convention by ruling that the elements constituting the offence set out in art 225-13 of the Criminal Code had been
substantiated.

108. Finally, the government pointed out that the wording of arts 225-13 and 225-14 of the Criminal Code made it
possible to combat all forms of exploitation of an individual through labour falling within art 4 of the convention.

109. The court notes that the applicant arrived in France from Togo at the age of 15 years and 7 months with a
person who had agreed with her father that she would work until her air ticket had been reimbursed, that her
immigration status would be regularised and that she would be sent to school.

110. In reality, the applicant worked for this person for a few months before being 'lent' to Mr and Mrs B. It appears
from the evidence that she worked in their house without respite for about 15 hours per day, with no day off, for
several years, without ever receiving wages or being sent to school, without identity papers and without her
immigration status being regularised. She was accommodated in their home and slept in the children's bedroom.
**[*682]**

111. The court also notes that, in addition to the convention, numerous international conventions have as their
objective the protection of human beings from slavery, servitude and forced or compulsory labour (see 'Relevant
law'). As the Parliamentary Assembly of the Council of Europe has pointed out, although slavery was officially


-----

abolished more than 150 years ago, 'domestic slavery' persists in Europe and concerns thousands of people, the
majority of whom are women.

112. The court reiterated that art 4 enshrines one of the fundamental values of democratic societies. Unlike most of
the substantive clauses of the convention and of Protocols Nos 1 and 4, art 4 makes no provision for exceptions
and no derogation from it is permissible under art 15(2) even in the event of a public emergency threatening the life
of the nation (see, with regard to art 3, the following judgments: Ireland v UK _[[1978] ECHR 5310/71 at para 163;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X27J-00000-00&context=1519360)_
_Soering v UK_ _[[1989] ECHR 14038/88 at para 88;](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X31X-00000-00&context=1519360)_ _Chahal v UK_ _[(1996) 1 BHRC 405 at para 79; and Selmouni v](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3X3-00000-00&context=1519360)_
_France_ _[(1999) 7 BHRC 1 at para 79).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W4R9-00000-00&context=1519360)_

In those circumstances, the court considers that, in accordance with contemporary norms and trends in this field,
the member states' positive obligations under art 4 of the convention must be seen as requiring the penalisation
and effective prosecution of any act aimed at maintaining a person in such a situation (see, mutatis mutandis, MC v
_[Bulgaria (2003) 15 BHRC 627 at para 166).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W51W-00000-00&context=1519360)_

113. Accordingly, the court must determine whether the applicant's situation falls within art 4 of the convention.

114. It is not disputed that she worked for years for Mr and Mrs B, without respite and against her will.

It has also been established that the applicant has received no remuneration from Mr and Mrs B for her work.

115. In interpreting art 4 of the European convention, the court has in a previous case already taken into account
the ILO conventions, which are binding on almost all of the Council of Europe's member states, including France,
and especially the 1930 Forced Labour Convention (see Van der Mussele v Belgium _[[1983] ECHR 8919/80 at para](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0D2-00000-00&context=1519360)_
_[32).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0D2-00000-00&context=1519360)_

116. It considers that there is in fact a striking similarity, which is not accidental, between para 3 of art 4 of the
European convention and para 2 of art 2 of Convention No 29. Paragraph 1 of the last-mentioned article provides
that 'for the purposes' of the latter convention, the term 'forced or compulsory labour' shall mean 'all work or service
which is exacted from any person under the menace of any penalty and for which the said person has not offered
himself voluntarily'.

117. It remains to be ascertained whether there was 'forced or compulsory' labour. This brings to mind the idea of
physical or mental constraint. What there has to be is work 'exacted under the menace of any penalty' and also
performed against the will of the person concerned, that is work for which he 'has not offered himself voluntarily'
(see Van der Mussele v Belgium _[[1983] ECHR 8919/80 at para 34).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0D2-00000-00&context=1519360)_

118. The court notes that, in the instant case, although the applicant was not threatened by a 'penalty', the fact
remains that she was in an equivalent situation in terms of the perceived seriousness of the threat.

She was an adolescent girl in a foreign land, unlawfully present in French territory and in fear of arrest by the police.
Indeed, Mr and Mrs B nurtured that fear and led her to believe that her status would be regularised (see para 22,
above).
**[*683]**

Accordingly, the court considers that the first criterion was met, especially since the applicant was a minor at the
relevant time, a point which the court emphasises.

119. As to whether she performed this work of her own free will, it is clear from the facts of the case that it cannot
seriously be maintained that she did. On the contrary, it is evident that she was not given any choice.

120. In these circumstances, the court considers that the applicant was, at the least, subjected to forced labour
within the meaning of art 4 of the convention at a time when she was a minor.

121. It remains for the court to determine whether the applicant was also held in servitude or slavery.


-----

Sight should not be lost of the convention's special features or of the fact that it is a living instrument which must be
interpreted in the light of present-day conditions, and that the increasingly high standard being required in the area
of the protection of human rights and fundamental liberties correspondingly and inevitably requires greater firmness
in assessing breaches of the fundamental values of democratic societies (see, among many other authorities,
_Selmouni v France_ _[(1999) 7 BHRC 1 at para 101).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W4R9-00000-00&context=1519360)_

122. The court notes at the outset that, according to the 1927 Slavery Convention—

'slavery is the status or condition of a person over whom any or all of the powers attaching to the right of
ownership are exercised.'

It notes that this definition corresponds to the 'classic' meaning of slavery as it was practised for centuries. Although
the applicant was, in the instant case, clearly deprived of her personal autonomy, the evidence does not suggest
that she was held in slavery in the proper sense, in other words that Mr and Mrs B exercised a genuine right of legal
ownership over her, thus reducing her to the status of an 'object'.

123. With regard to the concept of 'servitude', it 'prohibits a particularly serious form of denial of freedom' (see the
Commission's report in the case of Van Droogenbroeck v Belgium at paras 78–80). It includes:

' in addition to the obligation to provide certain services to another the obligation on the “serf ” to live on the
other's property and the impossibility of changing his status.'

In this connection, in examining a complaint under this paragraph of art 4, the Commission paid particular attention
to the Convention on the Abolition of Slavery (see also the decision in _Van Droogenbroeck v Belgium (App no_
7906/77) (1979) 17 DR 59).

124. It follows in the light of the case law on this issue that for convention purposes 'servitude' means an obligation
to provide one's services that is imposed by the use of coercion, and is to be linked with the concept of 'slavery'
described above (see Seguin v France (App no 42400/98) (admissibility decision, 7 March 2000)).

125. Furthermore, under the Supplementary Convention on the Abolition of Slavery, the Slave Trade, and
Institutions and Practices Similar to Slavery, each of the states parties to the convention must take all practicable
and necessary legislative and other measures to bring about the complete abolition or abandonment of the
following institutions and practices:
**[*684]**

'(d) any institution or practice whereby a child or young person under the age of eighteen years, is delivered by
either or both of his natural parents or by his guardian to another person, whether for reward or not, with a view
to the exploitation of the child or young person or of his labour.'

126. In addition to the fact that the applicant was required to perform forced labour, the court notes that this labour
lasted almost 15 hours a day, 7 days per week.

Brought to France by a relative of her father's, she had not chosen to work for Mr and Mrs B.

As a minor, she had no resources and was vulnerable and isolated, and had no means of subsistence other than in
the home of Mr and Mrs B, where she shared the children's bedroom as no other accommodation had been
provided. She was entirely at Mr and Mrs B's mercy, since her papers had been confiscated and she had been
promised that her immigration status would be regularised, which had never occurred.

127. In addition, the applicant, who was afraid of being arrested by the police, was not in any event permitted to
leave the house, except to take the children to their classes and various activities. Thus, she had no freedom of
movement and no free time.

128. As she had not been sent to school, despite the promises made to her father, the applicant could not hope that
her situation would improve and was completely dependent on Mr and Mrs B.


-----

129. In those circumstances, the court concludes that the applicant, a minor at the relevant time, was held in
servitude within the meaning of art 4 of the convention.

130. Having regard to its conclusions with regard to the positive obligations under art 4, it now falls to the court to
examine whether the impugned legislation and its application in the case in hand had such significant flaws as to
amount to a breach of art 4 by the respondent state.

131. According to the applicant, the provisions of French criminal law had not afforded her sufficient protection
against the situation and had not made it possible for the culprits to be punished.

132. The government, for their part, submitted that arts 225-13 and 225-14 of the Criminal Code made it possible to
combat the exploitation through labour of an individual for the purposes of art 4 of the convention.

133. The court notes that the Parliamentary Assembly of the Council of Europe, in its Recommendation
1523(2001), '[regretted] that none of the Council of Europe member states expressly [made] domestic slavery an
offence in their criminal codes'.

134. It notes with interest the conclusions reached by the French National Assembly's joint taskforce on the various
forms of modern slavery (see 'Relevant law').

More specifically, with regard to arts 225-13 and 225-14 as worded as the material time, the taskforce found, in
particular:

'We have available a not inconsiderable arsenal of punitive measures. However, these are not always used in
full and are proving an insufficient deterrent when put to the test

**[*685]**

The concept, found in both arts 225-13 and 225-14 of the Criminal Code, of the abuse of an individual's
vulnerability or state of dependence contains ambiguities that could be prejudicial to their application

That said, and since the law is silent, it is up to the court to determine where the scope of those provisions
ends. In this connection, analysis of the case law reveals differences in evaluation that impede the uniform
application of the law throughout France

Whether with regard to actual or potential sentences, the shortcomings of the provisions are clearly visible, in
view of the seriousness of the factual elements characteristic of modern slavery

Bearing in mind, on the one hand, the constitutional status of the values protected by arts 225-13 and 225-14
of the Criminal Code and, on the other, the seriousness of the offences in such cases, the inconsequential
nature of the penalties faced by those guilty of them is surprising, and raises questions about the priorities of
the French criminal-justice system '

135. The court notes that, in the present case, the applicant's 'employers' were prosecuted under arts 225-13 and
225-14 of the Criminal Code, which make it an offence, respectively, to exploit an individual's labour and to submit
him or her to working or living conditions that are incompatible with human dignity.

136. In the judgment delivered on 10 June 1999, the Paris tribunal de grande instance found Mr and Mrs B guilty of
the offence defined in art 225-13 of the Criminal Code. Conversely, it found that the offence set out in art 225-14
had not been substantiated.

137. The defendants were sentenced to 12 months' imprisonment, 7 of which were suspended, and ordered to pay
a fine of FRF 100,000 each and to pay, jointly and severally, FRF 100,000 to the applicant in damages.

138. On an appeal by Mr and Mrs B, the Paris Court of Appeal delivered a judgment on 19 October 2000 in which it
quashed the judgment at first instance and acquitted the defendants.


-----

139. On an appeal on points of law by the applicant alone, the Court of Cassation overturned the Court of Appeal's
judgment, but only in respect of its civil aspects, and the case was remitted to another court of appeal.

140. On 15 May 2003 that court gave a judgment upholding the findings of the tribunal de premiere instance and
awarded the applicant damages.

141. The court notes that slavery and servitude are not as such classified as offences under French criminal law.

142. The government referred to arts 225-13 and 225-14 of the Criminal Code.

The court notes, however, that those provisions do not deal specifically with the rights guaranteed under art 4 of the
convention, but concern, in a much more restrictive way, exploitation through labour and subjection to working and
living conditions that are incompatible with human dignity.

It therefore needs to be determined whether, in the instant case, those articles provided effective penalties for the
conduct to which the applicant had been subjected.

143. The court has previously stated that children and other vulnerable individuals, in particular, are entitled to state
protection, in the form of effective deterrence, against such serious breaches of personal integrity (see, mutatis
mutandis, the judgments in X and Y v Netherlands _[[1985] ECHR 8978/80 at paras 21–27; Stubbings v UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1PN-00000-00&context=1519360)_ _[(1996) 1](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3MK-00000-00&context=1519360)_
_[BHRC 316 at paras 62–64; and A v UK](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W3MK-00000-00&context=1519360)_ _[(1998) 5 BHRC 137 at para 22; and also the United Nations Convention on](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5J9J-STT1-DYBP-W32Y-00000-00&context=1519360)_
the Rights of the Child, arts 19 and 37).
**[*686]**

144. Further, the court has held in a case concerning rape that—

'the protection afforded by the civil law in the case of wrongdoing of the kind inflicted on Miss Y is insufficient. This
is a case where fundamental values and essential aspects of private life are at stake. Effective deterrence is
indispensable in this area and it can be achieved only by criminal-law provisions; indeed, it is by such provisions
that the matter is normally regulated.' (See X and Y v Netherlands _[[1985] ECHR 8978/80 at para 27.)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X1PN-00000-00&context=1519360)_

145. The court observes that, in the instant case, the applicant, who was subjected to treatment contrary to art 4
and held in servitude, was not able to see those responsible for the wrongdoing convicted under the criminal law.

146. In this connection, it notes that, as the principal public prosecutor did not appeal on points of law against the
Court of Appeal's judgment of 19 October 2000, the appeal to the Court of Cassation concerned only the civil
aspect of the case and Mr and Mrs B's acquittal thus became final.

147. In addition, according to the report of 12 December 2001 by the French National Assembly's joint taskforce on
the various forms of modern slavery, arts 225-13 and 225-14 of the Criminal Code, as worded at the material time,
were open to very differing interpretations from one court to the next, as demonstrated by this case, which, indeed,
was referred to by the taskforce as an example of a case in which a court of appeal had unexpectedly declined to
apply arts 225-13 and 225-14.

148. In those circumstances, the court considers that the criminal-law legislation in force at the material time did not
afford the applicant, a minor, practical and effective protection against the actions of which she was a victim.

It notes that the legislation has been changed but the amendments, which were made subsequently, were not
applicable to the applicant's situation.

It emphasises that the increasingly high standard being required in the area of the protection of human rights and
fundamental liberties correspondingly and inevitably requires greater firmness in assessing breaches of the
fundamental values of democratic societies (see para 121, above).

149. The court thus finds that in the present case there has been a violation of the respondent state's positive
obligations under art 4 of the convention.


-----

_II. Application of art 41 of the convention_

150. Under art 41 of the convention:

'If the Court finds that there has been a violation of the Convention or the Protocols thereto, and if the internal
law of the High Contracting Party concerned allows only partial reparation to be made, the Court shall, if
necessary, afford just satisfaction to the injured party.'

A. Damage

151. The applicant did not make a claim in respect of damage.

B. Costs and expenses

152. The applicant sought 26,209 69 euros for the costs of legal representation, from which the sums received by
way of legal aid were to be deducted.
**[*687]**

153. The government first observed that the applicant had not produced any evidence that she had paid this sum.

They also considered that the amount sought was excessive and should be reduced to a more reasonable level.

154. The court considers that the applicant's representative has undoubtedly done a considerable amount of work
in order to submit and argue this application, which concerns an area in which there is very little case law to date.

In those circumstances, the court, ruling on an equitable basis, awards the applicant the entire amount claimed in
costs.

C. Default interest

155. The court considers it appropriate that the default interest should be based on an annual rate equal to the
marginal lending rate of the European Central Bank, to which should be added three percentage points.
**FOR THESE REASONS, THE COURT UNANIMOUSLY,**

1. Dismisses the government's preliminary objection based on the applicant's loss of victim status;

2. Holds that there has been a violation of art 4 of the convention;

3. _Holds: (a) that the respondent state is to pay the applicant, within three months from the date on which the_
judgment becomes final according to art 44(2) of the convention, 26,209 69 euros in respect of costs and expenses,
plus any tax that may be chargeable; (b) that the sums received by way of legal aid are to be deducted from that
amount; (c) that from the expiry of the above-mentioned three months until settlement simple interest shall be
payable on the above amount at a rate equal to the marginal lending rate of the European Central Bank during the
default period to which shall be added three percentage points.

**End of Document**


-----

