# Limbu and others v Dyson Technology Ltd and other companies [2023]
 EWHC 2592 (KB)

King's Bench Division

Clive Sheldon KC (sitting as a deputy judge of the High Court)

19 October 2023Judgment

**Charles Gibson KC**

**Adam Heppinstall KC**

**Freya Foster**

(instructed by Baker & McKenzie LLP) for the Applicant/Defendants

**Richard Hermer KC**

**Edward Craven**

(instructed by Leigh Day) for the Claimants/Respondent

Hearing dates: 18-20 July 2023

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 10.30am on 19 October 2023 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

.............................

CLIVE SHELDON KC

**Clive Sheldon KC:**

1. Dhan Kumar Limbu is a Nepalese national. He was a migrant worker, employed at factory facilities in
Malaysia which manufactured products and components for Dyson-branded products. Mr. Limbu, along
with 22 other migrant workers from Nepal and Bangladesh, and the personal representative of the estate of
a deceased migrant worker from Nepal (collectively, “the Claimants”), have issued proceedings in England
and Wales (shortened for convenience in this judgment to “England”) against three Defendants who are
part of the Dyson group of companies (“the Dyson Group”): (1) Dyson Technology Limited (D1), (2) Dyson
Limited (D2), and (3) Dyson Manufacturing SDN BHD (D3) (collectively, “the Dyson Defendants”). D1 and
D2 are domiciled in England. D3 is domiciled in Malaysia.

2. At a hearing before me on 18-20 July 2023, I was asked to consider whether the trial of the Claimants'
action should take place in England. D1 and D2 seek a stay of these proceedings on the basis that the
proper forum is Malaysia. D3 seeks to set aside the order granted without notice by Master Gidden on 3
October 2023 serving them with these proceedings


-----

I. The Proceedings

3. On 27 May 2022, the Claimants lodged proceedings against the Dyson Defendants. The claim form was
amended on 13 September 2022, and Particulars of Claim were filed on 26 September 2022.

4. In the Amended Claim Form, the Claimants claim that (i) the Dyson Defendants are liable to the
Claimants for negligence; (ii) the Dyson Defendants are jointly liable (with the primary tortfeasors) for the
commission of the torts of false imprisonment, intimidation, assault and battery; and (iii) the Dyson
Defendants have been unjustly enriched at the expense of the Claimants. The primary tortfeasors, who are
not sued by the Claimants, are identified as ATA Industrial (M) Sdn Bhd (“ATA”) and Jabco Filter System
Sdn Bhd (collectively, “ATA/J”), and the Malaysian Police.

5. The Claimants' claims are set out in detail in the Particulars of Claim. In summary, the Claimants allege
that for a substantial period of time (collectively their periods of employment range from 2011 to 2022) they
were subjected to forced labour and highly exploitative and abusive working and living conditions while
working for ATA/J at a factory in Johor Bahru, a city at the southern end of the Malaysian Peninsular, which
manufactured products and components for Dyson-branded products.

6. It is alleged that D1's principal activities concern the invention, development and sale and service of
Dyson products, as well as the provision of a range of support services to other companies within the
Dyson Group, including services relating to finance, human resources, IT and property management. It is
alleged that D2's principal activities are the sale and service of Dyson-branded products. It is alleged that
D3's principal activities are the manufacture, sale and distribution of Dyson products, the management of
contracting services, as well as the direct oversight of the relationship between the Dyson Group and the
owners and management of the factory facilities within the Dyson supply chain, including in relation to
worker recruitment and conditions of work at those facilities.

7. It is alleged that each of the Claimants was recruited to work at the factory facilities by recruitment
brokers or agents working for ATA/J. When working for ATA/J, it is alleged that the Claimants were forced
to work substantial overtime, above their 12 hour shifts, in breach of section 60 of the Malaysian
Employment Act 1955 (“the 1955 Act”); they were refused annual leave, contrary to sections 60D and 60E
of the 1955 Act; they were not paid the legal minimum wage, contrary to various Minimum Wage Orders;
and they were subjected to onerous production targets, and placed under considerable pressure to meet
those targets and frequently punished if they failed to do so, including by way of intimidation and physical
violence; and they suffered unlawful deduction of wages contrary to section 20 of the 1955 Act.

8. It is alleged that the Claimants were required to live at ATA/J accommodation, and that the
accommodation was invariably insanitary, overcrowded and degrading; and that they were not able to
leave the accommodation at will, and were forced to hand over their passports to ATA/J personnel. It is
alleged that although ATA/J assured the Claimants that their visas would be renewed, two of the Claimants
were arrested and detained on the grounds that they did not have a permit. It is also alleged that Mr.
Limbu, who sought to expose the abusive working and living conditions to an assistant of Mr. Andy Hall, a
British specialist in human and migrant rights, was arrested and assaulted by the Malaysian police when
his provision of evidence came to light. It is alleged that this was facilitated by representatives of ATA/J,
and that a representative of ATA/J threatened and intimidated Mr. Limbu into signing a statement saying
that he had received a large sum of money from Mr. Hall for providing his information. It is alleged that
another Claimant (Mr. Hossain), who had taken photographs of the factory and living conditions was also
arrested and interrogated by police, having been taken there by ATA/J personnel. Overall, the treatment of
the Claimants is alleged to constitute unlawful forced labour.

9. The Dyson Defendants are alleged to exert a high degree of control over the manufacturing operations
and working conditions at ATA/J's factory facilities. They are also alleged to have promulgated mandatory
policies and standards concerning the working and living conditions of workers in the Dyson Group's
supply chain, including at ATA/J. This includes the Dyson Ethical and Environmental Code of Conduct (“the
Code of Conduct”) which refers to “No Forced Labour”, and requires suppliers to observe the conditions of
the Code of Conduct. In addition, there is the Dyson **_Modern Slavery and Human Trafficking Statement_**
2020 which refers to the conducting of risk assessments of the supply chain and audits to assess


-----

compliance, and sets out remediation mechanisms for non-compliance. D1 and D2 are also alleged to
have promulgated a Supply Chain Foreign Migrant Worker Recruitment and Employment Policy, which
sets out minimum requirements for the recruitment and treatment of migrant workers by Dyson suppliers:
this includes freedom of movement (including regulating the holding of passports) and no forced labour. D1
and D2 are alleged to have promulgated a Dyson Supplier Accommodation Standard. It is alleged that D1
and D2 employed various employees with specific responsibility for the creation, management and
implementation of these policies.

10. D3 is also alleged to be responsible for the promulgation and/or implementation and enforcement of
the aforementioned policies and standards. D3 is alleged to be responsible for setting the standards for
worker welfare in supply chains in South East Asia, and for running a comprehensive programme of
regular audits across manufacturers, including ATA. In addition, reference is made to various job roles
relating to these policies at D3.

11. The Claimants allege that the Dyson Defendants knew of the high risk of forced labour in the
Malaysian operations from a variety of sources: public sources, as well as from their own audits, and more
specifically from the various notifications provided by Mr. Hall between August 2019 and September 2021
with respect to ATA/J's practices.

12. Appended to the Particulars of Claim are summaries of the specific facts pertaining to each of the
Claimants.

13. With respect to remedies, the Claimants claim damages, including aggravated and exemplary
damages; as well as personal and/or proprietary restitution of the Dyson Defendants' unjust enrichment.

14. The Amended Claim form was served on D1 and D2 on 26 September 2022. On 29 September 2022,
an application was made for service of the Amended Claim Form and Particulars of Claim out of the
jurisdiction on D3 pursuant to CPR rule 6.36. Master Gidden made the order to serve D3 on 3 October
2022. Service was effected on D3 on 7 October 2022.

15. On 10 October 2022, D1 and D2 filed an acknowledgment of service indicating their intention to
contest jurisdiction, and D3 did likewise on 28 October 2022. On 14 November 2022, the Dyson
Defendants made an application pursuant to CPR rule 11.1 and rule 11.6(a) for a declaration that the Court
should not exercise its jurisdiction over D1 and D2, and for a declaration that the Court has no jurisdiction
over D3 and shall not exercise jurisdiction, and that the service of the Claim Form and Particulars of Claim
should be set aside.

16. The Dyson Defendants have given a number of undertakings to the Court as to how they would
conduct the proceedings if their application succeeded and the claim was brought in Malaysia. The
undertakings were summarised in an annex to the witness statement of Francesca Richmond, a partner at
Baker & McKenzie LLP, solicitors for the Dyson Defendants:

(i) D1 and D2 will submit to the jurisdiction of the Malaysian courts if they are sued there;

(ii) The Dyson Defendants will not seek security for costs or an adverse costs order against the Claimants
if and to the extent such costs would not be recoverable under the Qualified One Way Cost Shifting regime
in England;

(iii) The Dyson Defendants will pay the reasonable costs necessary to enable the Claimants to give
evidence in Malaysian proceedings including (if necessary) affidavit affirmation fees and other costs
necessary for the Claimants to give remote evidence including travel and accommodation costs, costs
associated with the provision/set-up of suitable videoconferencing technology and other costs associated
with the logistics of giving evidence remotely;

(iv) The Dyson Defendants will not oppose an application by the Claimants for remote attendance at a
hearing/the trial in Malaysian proceedings;


-----

(v) The Dyson Defendants will pay for the Claimants' share of the following disbursements to the extent
reasonably incurred and necessary: (a) Court interpretation fees, (b) Transcription fees, and (c) Joint
expert evidence; and

(vi) The Dyson Defendants will not seek to challenge the lawfulness of any success fee arrangement
entered into between the Claimants and their Malaysian lawyers.

A further undertaking was given in the course of the hearing before me: that the Dyson Defendants would
not oppose an application for a split trial.

17. The parties submitted extensive evidence on the application: substantially more than 10,000 pages.
The evidence before the Court consisted of:

(a) The expert reports of (i) Tun Arifin Bin Zakaria, former Chief Justice of Malaysia between September
2011 and March 2017; (ii) Dato' Mah Weng Kwai, a former judge of the Malaysian Court of Appeal (2012 to
2015, having served as a High Court Judge since 2010), and former President of the Malaysian Bar and
member of the Malaysian Bar Council's (Bar Council) Disciplinary Board; (iii) Tun Richard Malanjum,
former Chief Justice of Malaysia between July 2018 and April 2019; and (iv) Dato' Malik Imtiaz Sarwar, a
senior Malaysian lawyer.

(b) Witness statements from (i) Mr Chandrasegaran A/L Rajandran, a Malaysian lawyer with considerable
experience acting for groups of Malaysian workers in Malaysia; (ii) Mr Tony Woon Yeow Thong, a
Malaysian lawyer and former Chairperson of the Malaysian Bar Council's Ad Hoc Committee on
Contingency Fees Rules; (iii) Ms Chew Kherk Ying, a Malaysian lawyer; (iv) Mr John Leadley, a partner at
Baker & McKenzie LLP, representing the Dyson Defendants; (v) Ms Francesca Richmond, a partner at
Baker & McKenzie LLP; (vi) Mr Adrian Pereira, Executive Director and Founder of the North-South Initiative
(NSI), a Malaysian NGO; (vii) Ms Glorene Amala Das, Executive Director of Tenaganita Sdn Bhd
(Tenaganita), a Malaysian NGO; (viii) Ms Liva Sreedharan, an independent labour rights specialist based
in Malaysia; (ix) Mr Surenda Ananth, a Malaysian lawyer in a Group Law Practice with Messrs Malik Imtiaz
Sarwar; (x) Ms Renuka T. Balasubramaniam, a former Malaysian lawyer and academic; (xi) Mr Shakirul
Islam, Chairperson of Ovibashi Karmi Unnayan Program, a Bangladeshi NGO; (xii) Mr Shom Prasad Luitel,
a practising Nepalese lawyer and former chairperson of People Forum, an NGO in Nepal; (xiii) four of the
Claimants: Mr Dhan Kumar Limbu, Mr Md Didar Hossain, Mr Mohammad Abu Taher, and Ms Sonu
Tamang; and (xiv) Mr Oliver Holland, a partner at Leigh Day, representing the Claimants.

18. The Dyson Defendants have not made an application to strike out the claim, nor have they made an
application for summary judgment. I assume, therefore, when considering the application before me, that
the claim is arguable and has a reasonable prospect of success. Both parties acknowledge, however, that
the claims involve novel points of law (whether under English or Malaysian law): whether the unjust benefit
in a claim for unjust enrichment has to flow directly from the claimant to the defendant; and whether a party
can be liable in negligence for the treatment by a third party -- a supplier -- of that third party's employees.

II. The defamation proceedings

19. On 10 February 2022, Channel Four News broadcast an item relating to allegations as to what had
taken place at a company in Malaysia that manufactured Dyson products: ATA. It was stated that workers
claimed that they had been abused and mistreated, and one ex-employee of ATA claimed that he had
suffered torture. It was said that links with ATA had been severed, and that wrongdoing was denied by
“Dyson”, but the broadcast questioned “how could work conditions have got so bad, and why wasn't it
picked up?”

20. On 25 February 2022, a claim form was issued by Sir James Dyson the eponymous founder of the
Dyson Group, and D1 and D2, seeking damages, including aggravated damages, an injunction, and orders
under sections 12 and/or 13 of the _[Defamation Act 2013 against Channel 4 Television Corp and](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:589D-C9M1-DYCN-C0FG-00000-00&context=1519360)_
Independent Television News Ltd, for the Channel 4 broadcast. Particulars of Claim, subsequently
amended on two occasions, have been provided. Sir James Dyson is no longer a claimant to the
defamation proceedings. D1 and D2 remain claimants.


-----

21. In the draft re-re-amended Particulars of Claim in the defamation proceedings, D1 and D2 explain that
they are “the Dyson operating companies in the UK. Dyson's products are manufactured by suppliers who
agree with the Dyson companies who place orders with them to adhere to an ethical and environmental
code of conduct that covers a range of subjects, including working hours, freedom of association,
environmental monitoring, and fair disciplinary practices” (paragraph 2A). They explained that in May 2021
they had published the “Dyson Modern Slavery and Human Trafficking Statement 2020” pursuant to the
[provisions of the Modern Slavery Act 2015,and that this “dealt with the contractual steps taken to ensure](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
that slavery and human trafficking was not taking place in any of their supply chains” (paragraph 7A.7).

22. In the defamation proceedings, D1 and D2 attribute the following natural and ordinary meaning to the
broadcast by Channel 4 that:

(i) they were complicit in the systemic abuse and exploitation of workers at ATA, one of their suppliers
located in Malaysia;

(ii) they were also complicit in the persecution and torture of a worker who blew the whistle on the working
practices at ATA; and

(iii) they, or alternatively D1, claim to act in a responsible and ethical way but when serious abuses of
workers were brought to their attention these abuses were not properly investigated but were ignored and
tolerated for a prolonged period of time while they tried to cover them up and shut down public criticism.

23. It is an essential ingredient of a claim for defamation that the publication referred to must refer to or
identify the claimant. A hearing took place before Nicklin J. to consider whether the broadcast, in its natural
and ordinary meaning, referred to D1 and D2. In a judgment given on 31 October 2022, Nicklin J. held that,
without consideration of extrinsic evidence, the broadcast did not refer to the second and third claimants:

_[2022] EWHC 2718 (KB). An appeal has recently been heard by the Court of Appeal. Judgment was_
handed down after the hearing before me on the question of jurisdiction: [2023] EWCA Civ 884, and further
submissions have been made by the parties as to the impact of this judgment. The Court of Appeal
reversed Nicklin J's decision, holding that a hypothetical reasonable viewer, acquainted with D1 and D2,
would identify these Dyson entities as being referred to in the broadcast.

24. No Defence has yet been issued by the broadcaster. In a response to a letter before claim, solicitors
for the broadcaster stated that they had a complete defence: that they “will demonstrate that the
imputations conveyed by the statements complained of by your clients are true or substantially true”. This
included a number of assertions, including how D1 and D2 were “on notice of allegations relating to serious
issues in its Malaysian supply chain, including at factories owned by ATA IMS and ATA Industrial in
particular, since at least 2019” based, among other things, on allegations made by Mr. Andy Hall; and that,
before Mr Hall raised his concerns, D1 and D2 had failed properly to monitor working conditions at ATA,
and there was evidence that forced labour issues were prevalent at ATA for many years. Further, it was
asserted that D1 and D2 had “accepted Mr Limbu's account regarding poor working conditions and
allegations of ATA corruption. Mr Limbu has told your clients about how he was persecuted and tortured by
the Malaysian police after blowing the whistle on working practices at ATA”.

25. Reference was also made to audits of ATA which, according to D1 and D2 apparently “found no
significant irregularities in respect of accommodation, recruitment fees, wages, overtime, retention of
personal documents or irregular workers”, and that it was D1 and D2's position that it was not until an audit
conducted and shared with them in October 2021, that any “key findings” on forced labour regarding ATA
were made. The broadcaster's solicitors stated that “Your clients have refused to make these audits public.
This refusal in itself is a ground for suspecting that your clients have something to hide regarding the
contents of those reports. Especially in light of Mr Limbu's account, which your clients do not contest, there
are plainly serious doubts over the credibility and adequacy of the previous audits of ATA conducted by or
on behalf of your clients. Your clients were on notice of serious allegations within its supply chain yet failed
to properly investigate these issues and implement necessary changes”.


-----

26. The solicitors for the broadcaster also referred to the public interest defence: that the statements
complained of by D1 and D2 were or formed part of a statement on a matter of public interest, and the
broadcaster reasonably believed that publishing the statements complained of was in the public interest.

III. The Law as to Jurisdiction

27. There is no dispute between the parties as to the relevant law that the Court needs to apply with
respect to this application. Following the EU UK Withdrawal Agreement, the Brussels (Recast) Regulations
no longer apply to fresh claims against parties domiciled in England. Rather, the principles set out by the
House of Lords in Spiliada Maritime Corporation v. Cansulex Ltd. [1987] 1 AC 460(“Spiliada”) apply both to
D1 and D2 (they are defendants domiciled in England, where service is of right: “service in” cases) and D3
(a defendant in respect of whom permission to serve abroad has been obtained: “service out” cases). In
both types of case, the question for the Court is “to identify the forum in which the case can be suitably
tried for the interests of all the parties and for the ends of justice”: Spiliada at p480G.

28. With respect to “service in” cases, the burden of proof rests on the defendant to show that England is
not the natural or appropriate forum and that there is another available forum which is clearly and distinctly
more appropriate: Stage 1. If so, then the burden shifts to the claimant to show that there are special
circumstances such that justice requires the trial to take place in England: Stage 2.

29. With respect to “service out” cases, the burden of proof is on the claimant at Stage 1 to show that
England is the appropriate forum for the trial of the action, and that it is “the proper place in which to bring
the claim” (CPR rule 6.37(3)). According to Lord Goff in Spiliada at p481D the claimant must show that this
is “clearly so”. If the claimant fails to establish that England is the proper forum, then Stage 2 will apply.

30. The instant case involves a mix of both “service in” (D1 and D2) and “service out” (D3) cases. In these
circumstances, “the court is looking for a single jurisdiction in which the claims against all the defendants
may most suitably be tried”: per Lord Briggs JSC in Lungowe v. Vedanta Resources plc. [2020] AC
1045(“Vedanta”) at §68. A jurisdiction in which a claim against some of the multiple defendants could not
be tried can still qualify as a proper place. In Vedanta at §69, Lord Briggs JSC explained that the inability to
try a claim against some of the multiple defendants is “only one factor, albeit a very important factor
indeed, in the evaluative tasks of identifying the proper place”. A trial involving only some of the defendants
“would risk multiplicity of proceedings about the same issues, and inconsistent judgments”.

31. In Tugashev v. Orlov _[2019] EWHC 645 (Comm), Carr J observed at §261 that the courts will often_
take into account the desirability of all related claims being tried together, and that may be a powerful factor
outweighing factors connecting the claim to another jurisdiction. In her review of the case law, Carr J. noted
that in JSC BTA Bank v. Granton Trade Ltd. _[2010] EWHC 2577 (Comm), Christopher Clarke J had_
considered that a distinction should be drawn between major and minor players in the litigation stating that
“a decision as to appropriate forum must necessarily take account of the relative importance in the case of
different defendants”. In Vedanta at first instance, Coulson J. referred to the concept of the tail not wagging
the dog: see [2016] EWHC 975 (TCC) at §168.

32. The two stages envisaged by Spiliada should not be regarded as totally rigid. It has been held that the
line dividing these two stages is “neither completely impermeable nor drawn in such a way that there are
no factors which do not appear on both sides of it”: Municipio De Mariana v BHP Group (UK) Ltd. [2022] 1
WLR 4691.

33. The exercise to be carried out by the Court is not the exercise of a discretion but an evaluative or a
balancing exercise: see Lords Wilson and Neuberger in VTB Capital Plc. v. Nuritek International Corp

[2013] 2 AC 337(“VTB”) at §§96, 156.

34. In carrying out this exercise, the Court “must start by seeing what are likely to be the issues between
the parties in the proposed action”: per Lord Diplock at p66 in Amid Rasheed Shipping Corp. v Kuwait
Insurance Co. [1984] AC 50; and Lord Clarke in VTB at §192-3.

35. At Stage 1, the Court examines the connecting factors between the case and one or more jurisdictions
in which it could be litigated. Lord Goff in Spiliada described this at p478A as being the forum “with which


-----

the action had the most real and substantial connection”. In assessing this, Lord Briggs JSC observed in
_Vedanta at §66 that:_

“Those include matters of practical convenience such as accessibility to courts for parties and witnesses
and the availability of a common language so as to minimise the expense and potential for distortion
involved in translation of evidence. Although they are important, they are not necessarily conclusive.
Connecting factors also include matters such as the system of law which will be applied to decide the
issues, the place where the wrongful act or omission occurred and the place where the harm occurred.”

36. The place of commission of a tort is a relevant starting point when considering the appropriate forum
for a tort claim. Viewed by itself, and in isolation, “the place of commission will normally establish a prima
facie basis for treating that place as the appropriate jurisdiction. . . . The significance attaching to the place
of commission may be dwarfed by other countervailing factors”: see VTB at §51, per Lord Mance (in a case
concerning an international commercial transaction).

37. Where defendants domiciled in England (commonly known as “anchor defendants”) have agreed to
submit to a foreign jurisdiction, but the claimant has made a deliberate choice to sue in this forum and has
thereby engendered the risk of irreconcilable judgments, it “would offend the common sense of all
reasonable observers to think that the proper place for this litigation to be conducted was England”: see
Lord Briggs in Vedanta at §87.

38. Where (as in the instant case) foreign law applies, it has been said that “if the competing fora have
domestic laws which are substantially similar, the governing law will be a factor of little significance”:
[Navigators Insurance Company and Ors v Atlantic Methanol Production Company LLC [2003] EWHC 1706](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JTV1-DYBP-N2XH-00000-00&context=1519360)
_[(Comm) at §48 (citing Dicey, Morris & Collins, The Conflict of Laws (13[th] Edition) (now 16[th] Edition at §12-](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JTV1-DYBP-N2XH-00000-00&context=1519360)_
033)).

39. In VTB, Lord Mance explained at §46 that:

“The governing law, which is here English, is in general terms a positive factor in favour of trial in England,
because it is generally preferable, other things being equal, that a case should be tried in the country
whose law applies. However, that factor is of particular force if issues of law are likely to be important and if
there is evidence of relevant differences in the legal principles or rules applicable to such issues in the two
countries in contention as the appropriate forum.”

40. At Stage 2, having concluded that a foreign jurisdiction is the proper place in which the case will be
tried, the Court will look to see if there are “circumstances by reason of which justice requires that a stay
should nevertheless not be granted”, and “all the circumstances of the case” will be considered: per Lord
Goff in Spiliada at p478D-E. One relevant factor may be if “there is a real risk that substantial justice will
not be obtainable in that foreign jurisdiction”: per Lord Briggs JSC in _Vedanta_ at §88. That will require
“cogent evidence”, but “Cogent evidence does not mean unchallenged evidence”: per Lord Briggs in
_Vedanta at §96._

41. In assessing whether there is a “real risk” that substantial justice will not be obtainable, the Court is not
conducting a trial and, although there must be evidence that the risk exists, the Court does not need to be
satisfied on the balance of probabilities that facts have been established or that the risks will eventuate:
see Cherney v Deripaska [2009] 2 CLC 408, per Waller LJ at §29.

42. “Substantial justice” will not be available if there is a real risk that the claimants will be denied access
to justice in the foreign jurisdiction. This may be because of the lack of independence or competence of the
relevant judiciary or, in the context of large group claims, the lack of a fair civil procedure suitable for
handling large group claims. It may also be because of the practicable impossibility of funding such group
claims, or the absence of “sufficiently substantial and suitably experienced legal teams to enable litigation
of this size and complexity to be prosecuted effectively, in particular against a defendant . . . with a track
record which suggested that it would prove an obdurate opponent”: per Lord Briggs JSC, describing at §89
the analysis of Coulson J at first instance in Vedanta (see [2016] EWHC 975 (TCC)).


-----

43. Caution should be applied when considering whether “substantial justice” can be obtained in the
foreign jurisdiction for a number of reasons. First, it has been observed that there have been “judicial
warnings of undoubted authority that the English court should not in this context conclude, other than in
exceptional cases, that the absence of a means of funding litigation in the foreign jurisdiction, where such
means are available in England, will lead to a real risk of the non-availability of substantial justice”: see
Lord Briggs JSC in _Vedanta_ at §93 referring to Connelly v RTZ Corpn plc (No 2) [1998] AC
854(“Connelly”), 873 per Lord Goff, and Lubbe and Others v Cape Plc [2000] 1 WLR 1545(“Lubbe”), 1555
per Lord Bingham.

44. Second, as Lord Goff noted in Connelly at p874D, “seeking to take advantage of financial assistance
available here to obtain a Rolls Royce presentation of his case, as opposed to a more rudimentary
presentation in the appropriate forum” would not be sufficient to justify such a refusal.

45. Third, and more generally, Lord Briggs warned in Vedanta at §11 that the “conclusion that a foreign
jurisdiction would not provide substantial justice risks offending international comity. Such a finding
requires cogent evidence, which may properly be subjected to anxious scrutiny”.

46. I have been referred by the parties to a multitude of authorities. There are a number of cases in which
the English courts have found that there was a real risk that claimants would not obtain substantial justice
in foreign jurisdictions. It is useful to set out the reasoning in the particular cases, as there are alleged
similarities with the facts of this case.

47. Connelly concerned a claim for damages for negligence brought by an individual who had worked in
Namibia at a uranium mine operated by the Namibian subsidiary of an English company. The plaintiff
alleged that he had contracted cancer as a result of the failure to provide a reasonably safe system of work
affording protection from the effects of uranium ore dust while he worked in the mine. The plaintiff was
impecunious, and would be unable to obtain legal aid in Namibia, but legal aid would be available to him in
England. It was accepted by the plaintiff that Namibia was the jurisdiction with which the action had the
closest connection. The House of Lords held, however, that the Namibian forum was not one in which the
case can be tried more suitably for the interests of all the parties and the ends of justice. Lord Goff stated
p.873E-874E that:

“I therefore start from the position that, at least as a general rule, the court will not refuse to grant a stay
simply because the plaintiff has shown that no financial assistance, for example in the form of legal aid, will
be available to him in the appropriate forum, whereas such financial assistance will be available to him in
England. Many smaller jurisdictions cannot afford a system of legal aid.

. . .

Even so, the availability of financial assistance in this country, coupled with its non-availability in the
appropriate forum, may exceptionally be a relevant factor in this context. The question, however, remains
whether the plaintiff can establish that substantial justice will not in the particular circumstances of the case
be done if the plaintiff has to proceed in the appropriate forum where no financial assistance is available.

This is in effect what was urged upon your Lordships in the present case. It is clear that the nature and
complexity of the case is such that it cannot be tried at all without the benefit of financial assistance. There
are two reasons for this. The first is that . . . there is no practical possibility of the issues which arise in the
case being tried without the plaintiff having the benefit of professional legal assistance; and the second is
that his case cannot be developed before a court without evidence from expert scientific witnesses. It is not
in dispute that in these circumstances the case cannot be tried in Namibia; whereas, on the evidence . . . it
appears that if the case is fought in this country the plaintiff will either obtain assistance in the form of legal
aid or, failing that, receive the benefit of a conditional fee agreement with his solicitor. . . . I am satisfied
that this is a case in which, having regard to the nature of the litigation, substantial justice cannot be done
in the appropriate forum, but can be done in this jurisdiction where the resources are available.

If the position had been, for example, that the plaintiff was seeking to take advantage of financial
assistance available here to obtain a Rolls Royce presentation of his case, as opposed to a more
rudimentary presentation in the appropriate forum it might well have been necessary to take a different


-----

view. But this is not the present case. There is every reason to believe that this case calls for highly
professional representation, by both lawyers and scientific experts, for the achievement of substantial
justice, and that such representation cannot be achieved in Namibia. In these circumstances, to revert to
the underlying principle, the Namibian forum is not one in which the case can be tried more suitably for the
interests of all the parties and for the ends of justice.”

48. _Lubbe concerned actions brought by several thousand plaintiffs for personal injury arising from the_
mining and processing of asbestos in South Africa. At 1559D-G, Lord Bingham concluded that:

“The clear, strong and unchallenged view of the attorneys who provided statements to the plaintiffs was
that no firm of South African attorneys with expertise in this field had the means or would undertake the risk
of conducting these proceedings on a contingency fee basis. The defendant suggested that financial
support and professional assistance might be given to the plaintiffs by the Legal Resources Centre, but this
suggestion was authoritatively contradicted. In a recent affidavit the possibility was raised that assistance
might be forthcoming from the European Union Foundation for Human Rights in South Africa, but the
evidence did not support the possibility of assistance on the scale necessary to fund this litigation.

If these proceedings were stayed in favour of the more appropriate forum in South Africa the probability is
that the plaintiffs would have no means of obtaining the professional representation and the expert
evidence which would be essential if these claims were to be justly decided. This would amount to a denial
of justice. In the special and unusual circumstances of these proceedings, lack of the means, in South
Africa, to prosecute these claims to a conclusion provides a compelling ground, at the second stage of the
_Spiliada test, for refusing to stay the proceedings here.”_

[49. Pike v. The Indian Hotels Company Limited [2013] EWHC 4096 (QB) was a claim brought against the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B69-GBY1-F0JY-C438-00000-00&context=1519360)
proprietor of the Taj Mahal Palace hotel in Mumbai, India, arising out of the terrorist attack in that city on 26
November 2008. Stewart J. held that requiring the claimants to commence proceedings in India would
amount to a denial of justice. The 15 to 20 year delay in the case coming to trial would not be proper
access to justice. Further, Stewart J. held that the claimants would be unable to litigate the case in any
event due to lack of funding: the claimants could not self-finance the case, and public funding, conditional
and contingency fee arrangements are absent in India and there is no funding for the costs of experts. To
run the litigation properly, the claimants would need experienced lawyers and reliance on expert evidence,
not just on quantum but also on liability.

50.  AAA & Ors v Unilever Plc & Anor [2017] EWHC 371 (QB) was a case brought by a group of Kenyan
nationals who were employed on a tea plantation by a Kenyan company, which was the subsidiary of a
company registered in the United Kingdom. The claimants were victims of ethnic violence carried out by
armed criminals at the plantation following the presidential election in 2007. It was alleged that the risk of
such violence was foreseeable and the claimants were owed a duty of care to protect them from the
violence. Elisabeth Laing J. considered, among other things, the question of forum. It was accepted that
conditional fee arrangements were unlawful in Kenya, even though there was evidence that they were rife
(see §160). At §167, Elisabeth Laing J. accepted that

“these claims could in theory be litigated in Kenya in the sense that procedures exist for litigating group
actions, and that there is sufficient local expertise to enable the OLA (K) claim against D2 to be brought,
and to enable suitable medical experts to advise on Cs' injuries. I accept that no local firm is big enough to
litigate this claim on its own, and that it would therefore be necessary for Cs to be represented by a
consortium of firms. This would not be ideal, but it would not deprive Cs of substantial justice.”

However, with respect to funding, Elisabeth Laing J. held at §171 that:

“while it is likely some corners could be cut, the claims will be expensive and complex to prepare. I
consider that, on the evidence, there is a real risk that Cs would not be able to afford to bring these claims
in Kenya. I do not consider that they should be required to make unlawful arrangements for conditional fee
agreements. There is no functioning legal aid system. There is no evidence which satisfies me that money
could be found to enable Cs to bring and prosecute these claims even as far as a trial on liability of a small
number of test cases”.


-----

51. Vedanta was a claim brought by Zambian citizens living in Zambia against a Zambian employer and its
United Kingdom parent company for negligence arising from pollution and environmental damage caused
by discharges from a Zambian copper mine. Coulson J. found that there was a probability that substantial
justice would be unavailable in Zambia, as a result of

“first, the practicable impossibility of funding large group claims where the claimants were all in extreme
poverty; and secondly, the absence within Zambia of sufficiently substantial and suitably experienced legal
teams to enable litigation of this size and complexity to be prosecuted effectively, in particular against a
defendant with a track record which suggested it would prove an obdurate opponent”

(as described by Lord Briggs in the Supreme Court at §89). Coulson J's judgment was upheld by the
Supreme Court. Lord Briggs noted that, with respect to the issue of funding, Coulson J. had found that
most forms of funding were unavailable, and that the one which was available -- “for the lawyers to take on
the claimants as their clients on the payment of a small up-front fee; to pay for all of the disbursements,
including expert evidence, out of their own pockets; and then to recover their costs when the claims were
successful” (Coulson J. at §182) -- would not attract a legal team which (per Lord Briggs at §93) “was
both prepared to act, and able do so with the requisite resources and experience” (see also Lord Briggs at
§91). Coulson J. had concluded at §185 that:

“Considering the evidence as a whole, I conclude that it is fanciful to suggest that the ad-hoc method of
funding could work in this case. This is complex and expensive litigation involving over 1,800 claims.
Detailed evidence is going to be necessary in respect of personal injuries, land ownership and damage to
land; and expert evidence as to pollution, causation and medical consequences. On the evidence before
the court, it is quite unrealistic to suppose that the lawyers would fund such large and potentially complex
claims, essentially out of their own pockets, for the many years that litigation might take to resolve”.

52. Mr. Hermer KC, acting for the Claimants, sought to impress on me that, from an access to justice
perspective, where the English Court was seized of jurisdiction, and knows that a fair trial is possible here,
it should not lightly relinquish that jurisdiction.

III. The Parties' Submissions

53. The Defendants produced a 69 page skeleton argument, and oral submissions were made by Charles
Gibson KC and Adam Heppinstall KC (dealing primarily with the defamation litigation). The Claimants
produced an 85 page skeleton argument, and oral submissions were made by Richard Hermer KC.

54. I summarise the respective submissions as follows:

(a) The Dyson Defendants' Submissions

55. In essence, the Dyson Defendants submit that Malaysia is clearly and distinctly the proper forum. They
say that Malaysia is the only forum where the totality of the dispute can be heard, thereby avoiding the risk
of irreconcilable judgments and the multiplicity of proceedings. Further, they submit that legal
representation and funding for these claims is available in Malaysia.

56. As preliminary matters, the Dyson Defendants explained to the Court that they had notified ATA/J of
the intention to join them to these proceedings, and that ATA/J had indicated that they were unwilling to
submit to the jurisdiction of the English Court because Malaysia is the proper place for claims to be
determined. As for the Malaysian police, it was explained that they could only be joined to proceedings in
Malaysia and, at the hearing before me, it was explained that the Dyson Defendants did intend to bring
third party proceedings against the police. The Court was also informed that D1 and D2 (the English
“anchor defendants”) will submit to the Malaysian Courts.

57. In their written submissions, the Dyson Defendants contended that with respect to Spiliada Stage 1,
both the primary and third party claims have a real and substantial connection with Malaysia:

(a) Malaysia was the location of the alleged tortious wrongdoing: Malaysia was where the conduct of
ATA/J and the Malaysian police took place; where the Claimants were living and working when the


-----

breaches of Malaysian statutory law took place; and where any allegedly defective or negligent policies of
the Dyson Defendants were implemented;

(b) five of the Claimants are in Malaysia, and none of the Claimants are in or have any connection with
England. D3 is in Malaysia; and the relevant third parties (ATA/J and the Malaysian police) are in Malaysia;

(c) the applicable law governing the claims is Malaysian, and this differs from English law in material
respects; in particular, the unjust enrichment claim brought by the Claimants is novel (in both jurisdictions),
and the Malaysian courts have already diverged in one respect from the approach adopted by the English
Courts with respect to unjust enrichment (applying the “absence of basis” approach in Dream Property Sdn
Bhd v Atlas Housing Sdn Bhd [2015] 2 AMR 601 at §128-9); the negligence claims are novel (whether
companies in one group can be responsible for the actions of a third-party supplier and the police) and
questions of public policy are likely to arise; and the tort of intimidation is less well developed in Malaysia.
Further, there is extensive reliance on Malaysian statutory and constitutional law which does not apply in
England and is best considered by Malaysian courts.

(d) the relevant evidence is predominantly located in Malaysia, and obtaining evidence from ATA/J and the
Malaysian police would be time consuming and costly, and with respect to the Malaysian police the Letter
Rogatory process may not be successful due to issues of comity and/or state immunity;

(e) certain of the claims for contribution and/or indemnity against ATA/J and the Malaysian police can only
be brought in Malaysia, and there is a risk that an English judgment for contribution against ATA/J would
not be enforceable in Malaysia. As a result, the Dyson Defendants would have to re-establish liability to the
Claimants in Malaysia, thereby creating a significant risk of irreconcilable judgments and serious injustice
to the Dyson Defendants.

58. With respect to Spiliada Stage 2, the Dyson Defendants contended in their written submissions that
the Malaysia is a mature and sophisticated common law jurisdiction, operating in full comity and
cooperation with the English judiciary. The Malaysian Courts would take case management measures to
ensure efficient and proportionate access to justice for the Claimants. Malaysian lawyers are used to
funding actions in return for a success fee at the conclusion of the case, subject to the payment of a
modest 'basic fee', an arrangement which is lawful and has the support of the professional regulator for
lawyers, the judiciary and the Malaysian government. With respect to the payment of the 'basic fee', there
are NGOs supporting migrant workers in Malaysia who would most likely assist if the Claimants could not
afford to pay it, and the Dyson Defendants have committed to meet the reasonable costs of remote
attendance, translation and other fees, and have guaranteed that the Claimants will have the benefit of
Qualified One Way Costing Shifting protection from adverse costs (during the hearing before me, it was
explained by Mr. Charles Gibson KC that in a 'mixed claim' this protection might not protect the nonpersonal injury part of the claim, and so the Claimants could face a potential liability for some of the
adverse costs. This was the same situation as would arise if the claim proceeded in England). The Dyson
Defendants submit that there are sufficient Malaysian lawyers with the right experience, expertise, and
access to sufficient resources, whether alone or teaming up with other lawyers, to take a case of this
nature on a success fee basis. Lawyers in Malaysia handle heavy and complex matters, including in multiparty cases involving migrants, including against large multi-national corporations where pressure is
brought to bear on foreign parent companies.

59. Furthermore, the Dyson Defendants submitted that the avoidance of the serious risks of wasted costs,
duplicative proceedings, injustice, unfairness, irreconcilable judgments and infringements of comity are
avoided if the cases are all heard together in Malaysia: this goes to the question of “substantial justice” and
“all the circumstances” at Stage 2.

60. The Dyson Defendants elaborated on these points in oral argument. Emphasis was placed on the
need to avoid fragmentation; that the “centre of gravity” of the case was Malaysia: the primary wrongdoers
were ATA/J and the Malaysian police, and that the claims against the Dyson Defendants were contingent
on those claims. The mere fact that contracts with ATA/J had been terminated did not mean that the Dyson
Defendants would not be disputing the allegations (there was evidence that the contracts were terminated
when it became clear that ATA/J were not willing to remedy issues that had been identified through


-----

investigation). ATA/J would also be disputing the allegations, and had obtained a report from KPMG that
demonstrated that there was not a forced labour problem. The Dyson Defendants would be joining ATA/J if
the proceedings were in Malaysia, and Mr. Gibson KC's instructions (as conveyed to me at the hearing)
were that if there were findings that the Dyson Defendants were liable for acts of the Malaysian police, then
the police would be joined. The allegations involving the police were serious, and damages would not be
low as the Claimants were seeking aggravated and exemplary damages in respect of the alleged
mistreatment by the police.

61. Further, it was contended by the Dyson Defendants that there was a commitment in Malaysia to
migrant workers; forced labour was a high profile issue in the country (including by the government's
ratification of the International Labour Organisation's forced labour convention); the Federal Constitution of
Malaysia stipulated for the right of access to justice; and the Malaysian legal profession was active, skilled
and public-spirited, acting for migrants and the indigent. It was argued that lawyers would want to take the
case: the case would be high profile, they would want to give migrants access to justice, and would be
keen on exploring a novel point of liability.

62. The Dyson Defendants stressed that the Court should not approach the decision on the basis that a
_Rolls Royce (or as Counsel impressed on me in the current age of electric battery-operated cars, a Tesla)_
service was required for the Claimants. The Malaysian Courts would be likely to order remote hearings so
that the Claimants could participate in the hearing, and an application for a remote hearing would not be
opposed by them. The trial would be split between liability and quantum, and an undertaking was given to
the Court that the Dyson Defendants would not oppose an application for a split trial. It was submitted that
the Malaysian Court could make an interim costs order after the liability trial, and the costs awarded could
be used by the Claimant's lawyers to fund the quantum stage. It was only at the quantum stage that expert
evidence would be required (for personal injury claims) and, having succeeded at the liability stage, they
would have an incentive to obtain a success fee from the compensation award. Insofar as the unjust
enrichment claim was concerned, there would not be a need for a large amount of forensic accountancy
evidence to analyse that: it would be based on what the Claimants were paid in the factory and the profit
made by the Dyson Group from their work.

63. With respect to the use of success fees, the Dyson Defendants contended that there was no real risk
that a lawyer in Malaysia would face disciplinary action if they took on the present case on a partial
success fee basis. This was supported by all of the evidence available: decisions of the Courts and the
settled practice in Malaysia (18 years of settled practice using the partial success fee arrangement model),
the position of the Malaysian Bar Council and the Attorney General's chambers, and the absence of any
disciplinary proceedings against lawyers engaging in that practice.

64. With respect to the defamation claim, the Dyson Defendants submitted that it was pure speculation as
to what would happen in that case. There has been no defence to the defamation claim, so it cannot be
known what the real issues would be for the Court hearing that case to decide: the defence may simply go
to the broadcaster having reasonable ground to suspect the allegations against the Dyson Defendants and
not proving the truth of the allegations. The causes of action in the claims against the Dyson Defendants
were different from those in the defamation claim. If the claims against the Dyson Defendants were
retained by the English Courts, the two sets of claims would not be managed together: there was juridical
incompatibility between the two sets of claims.

65. During the course of the hearing before me, the Dyson Defendants handed up a “Case Management
Model” and a disbursements table. This stated that: (i) the Claimants could issue their claim on a single writ
and pay one fee; (ii) the claim would be issued in the High Court of Malaysia; (iii) the claim would be heard
by a single judge; (iv) the Malaysian courts, including the High Court, deal regularly with cases involving
multiple claimants; (v) cases are generally determined within 10-18 months of issue of the claim, and trial
could commence within a year; (vi) Malaysian procedure is governed by the 2012 Rules of Court; (vii) a
case management hearing takes place after close of pleadings and the Court makes case management
directions, there may be further such hearings; (viii) Malaysian judges have the power to make appropriate
case management directions to achieve just disposal of the claims; (ix) the Court can and would, if the
parties make an application order a split trail to determine liability before causation and quantum; (x) the


-----

Court can and would, if the parties agree, order a small number of test cases to be heard to determine
liability; (xi) if liability is proven, the Court can and would make an order that the Defendants make an
interim payment of costs to the Claimants; (xii) the Claimants would not be required to be or remain in
Malaysia to commence and pursue proceedings, and claims are not dismissed because a person leaves
Malaysia; (xiii) evidence for trial is adduced in witness statements, not affidavits; (xiv) affidavits in support
of applications are produced by Malaysian lawyers on instructions; (xv) the Claimants can give evidence by
video from abroad; (xvi) the Court has the power to allow the Claimants to give evidence remotely; (xvii)
the Court has a practice direction that sets out the guidelines for giving remote evidence from abroad;
(xviii) the Court would make such an order in these circumstances, including where the Claimants are
abroad and have a well-founded fear of travelling to Malaysia to give evidence; (xix) translators and
interpreters are frequently used in Malaysian Courts; (xx) interpreters are either court appointed or court
approved; (xxi) with respect to discovery: the starting point is the pleadings, the judge will give directions
for discovery and exchange at the case management hearing; the Malaysian High Court prefers that
parties make disclosure without making applications; the test for disclosure is whether the document is
relevant to the issues in dispute and is or has been in the “possession, custody or power” of the disclosing
party, and the test covers documents that adversely impact the disclosing party's case; the process for
discovery can be amended by the judge, applications can be made at any stage, documents include
electronic documents, and the Malaysian High Court is very familiar with cases involving large quantities of
electronic documents, including those involving large companies, where a party is located outside of
Malaysia discovery will include documents held by that party outside of Malaysia, the process for making
applications for specific discovery is well known and efficient; (xxii) the only expert evidence required here
is medical evidence for the causation and quantum stage; and (xxiii) the Malaysian Court can order a
single joint medical expert for the causation and quantum stage. The Claimants take issue with some of
these propositions.

66. With respect to disbursements, the Dyson Defendants provided the Court with the estimated cost of
the various disbursements and explained who would be expected to fund them: a mixture of NGOs, the
relevant lawyers, and/or the Dyson Defendants themselves. They estimate the 'Basic Fee' as being 1000
MYR, which equates to £167 (at an exchange rate of 1 MYR to 0.1673 pound sterling). The issue fee is
400 MYR, and the filing fee for a Statement of Claim is 16 MYR. The witness statement filing fee for three
test case witnesses is 48 MYR. The fee for three applications for Specific Discovery is 168 MYR. The fee
for three other interlocutory applications (including affidavit filing fees) is 168 MYR. The fee for filing a
Reply is 16 MYR, for filing a list of witnesses is 16 MYR, for filing the statement of agreed facts and list of
issues (when shared with the Dyson Defendants) is 16 MYR, and a fee for a Court Order is 300 MYR.

67. In total, the Dyson Defendants estimate the disbursements as costing 9,165 MYR (£1,534), of which
2,232 MYR (£374) are not covered by undertakings given by them. Only the initial issue fee and filing fee
for the Statement of Case is expected to be covered by an NGO (and not the Claimants' lawyer), along
with the basic fee: that is, a sum of 1,500 MYR. In total, the amounts that would not be covered by the
Dyson Defendants would come to the sum of 1,916 MYR (equivalent to £328). The Dyson Defendants did
not rely on the Claimants themselves making any contribution.

68. The Claimants did not take issue with the cost of the specific fees referred to, but did take issue with
the ability of NGOs to pay for them. The Dyson Defendants rejected the Claimants' description of the offer
to pay the disbursements as a cynical tactic. They contended that it reflected their legitimate objective of
avoiding injustice by facilitating a trial in the appropriate forum.

(b) The Claimants' Submissions

69. In essence, the Claimants submit that England is the more appropriate forum for the trial of their
claims against the Dyson Defendants, and in any event there is a real risk that they could not obtain
substantial justice in Malaysia.

70. In their written submissions, the Claimants contended that with respect to Spiliada Stage 1:

(i) There is a strong connection between the claims and England, which is where two of the Dyson
Defendants are based and where many of the key relevant acts and omissions occurred: particular focus


-----

being placed on the creation, promulgation and enforcement of various policies and standards concerning
working and living conditions in factory facilities and accommodation within the supply chain, which will
have been carried out by employees of D1 and/or D2, situated in their offices in England;

(ii) Much, if not most, of the key witnesses and documentary evidence will be in England;

(iii) There is a significant risk of duplication and inconsistent judgments if the Claimants are required to
pursue their claims in Malaysia given that it is likely that the same factual allegations will be investigated
and determined by the English courts in the defamation proceedings;

(iv) There are no material differences between Malaysian and English law;

(v) The Claimants will be unable to participate in a trial in Malaysia in person, or remotely;

(vi) The defence of the claims will be conducted and coordinated from England;

(vii) Dyson Malaysia is a necessary and proper party to the claims against D1 and D2, and this reinforces
that England is the appropriate forum;

(viii) None of the Dyson Defendants' arguments based on hypothetical future indemnity or contribution
claims against ATA/J and/or the Malaysian police have any merit. With respect to ATA/J, D1 and D2 are
not parties to any of the contracts with ATA/J; the most recent contract with ATA/J contains an exclusive
jurisdiction clause requiring all disputes to be determined through arbitration in Singapore and not through
the Malaysian courts; and a statutory contribution claim could be brought against ATA/J in England, and
even if ATA/J did not submit to English jurisdiction, a judgment could be enforced in Malaysia. With respect
to the Malaysian police, the evidence does not suggest that such a contribution claim is likely, and a
significant majority of the Claimants (20 out of 24) do not make any allegation of mistreatment against the
Malaysian police, and the allegations of mistreatment form a discrete part of the claims. Further, the
Claimants challenge the argument that the Dyson Defendants would have to re-establish their claims
against ATA/J and/or the Malaysian police and could not rely (whether in principle or practice) on the
findings of the English Court.

(ix) There are no real obstacles to obtaining documents from ATA/J or the Malaysian police if the claims
are pursued in England.

71. With respect to Stage 2, the Claimants contended in their written submissions that they have adduced
cogent evidence which establishes that there is at least a real risk that they would be unable to obtain
substantial justice in Malaysia. This arises from the combined effect of:

(i) The complexity of the Claimants' claims and the types of evidence, legal representation and
disbursements which will be required in order to litigate against well-resourced, aggressive and obdurate
defendants;

(ii) The Claimants' extreme poverty and their resulting inability to pay anything towards the cost of legal
representation or necessary disbursements;

(iii) The Claimants' inability to obtain suitably qualified legal representation and funding of necessary
disbursements in Malaysia:

(a) as legal aid is unavailable for these types of claim;

(b) as it is unlawful for a Malaysian lawyer to conduct the claim on a full contingency fee basis;

(c) a partial contingency fee basis is unlawful, and in any event is unavailable in practice because the
Claimants could not afford to pay the non-contingent aspect of such an arrangement, and suitably qualified
lawyers are unlikely to be prepared to expose themselves to the risks, both financial and professional, of
representing the Claimants on such a basis;

(d) they would not obtain funding from NGOs.

(iv) The fact that the Malaysian rules and procedure regarding disclosure are unlikely to facilitate the fair
determination of these claims, in which disclosure of documents held by the Defendants will be crucial;


-----

(v) The Claimants' inability to participate effectively in a trial in Malaysia either in person or remotely, due
to their fear of persecution, detention in inhumane conditions and deportation should they return to
Malaysia.

72. The evidence presented to the Court was that the Claimants are very poor. There was witness
evidence from one of the Claimants, Didar Hossain. He continues to live and work in Malaysia. He says
that he is in debt, has no savings, and spends all the money he earns (including by way of remittances to
family members in Bangladesh), and could not pay any money towards a lawyer. Another of the Claimants,
Mr. Limbu, who has returned to Nepal, says that he usually has no money left each month after paying for
his living expenses, and has no savings, but has debts. He also says that if he was needed to participate in
a trial remotely in Kathmandu, he would not be able to afford to attend. He also has no friends or relatives
in Kathmandu that he could stay with. He does not have a laptop or computer, he has a camera phone and
WIFI, but the signal is not strong and shuts down when the electricity goes out which happens about once
a week, and more often in the rainy season. A similar story was told by Mohammad Abu Taher who has
returned to Bangladesh, as well as by Sonu Tamang who has returned to Nepal. The latter has used up
the savings that she had accumulated while working in Malaysia. Her expenses are greater than her
earnings.

73. The Claimants contend that an important part of the context that would be relevant to the likelihood of
Malaysian lawyers taking their claim was the attitude and approach of the Dyson Defendants, who they say
have responded to the claims (the present claim, and the defamation claim) in a “disproportionate,
aggressive and obdurate manner”. This, they say, is evidenced by the way in which the Dyson Defendants
approached the issue of disclosure for the purposes of the jurisdiction hearing: they refer to the Dyson
Defendants' repeated refusals to permit inspection of documents relied upon and referred to by them in
their evidence in support of the jurisdiction challenge.

74. In their oral submissions, the Claimants developed these points in greater detail. The Claimants
emphasised that these were cases of real importance, involving breaches of fundamental human rights
and modern slavery: in those circumstances, the Court needed to be astute to ensure that the Claimants
have access to a fair trial. The claims were complicated, this was a very rare case in which the Court would
consider the question of civil liability of a non-employer for **_modern slavery because of their significant_**
control over supply chains. There was a material disparity in arms between the parties, and whilst the case
in this jurisdiction was well developed, and the Claimants had obtained representation from solicitors with
expertise to work under Conditional Funding Arrangements with significant disbursements, the Dyson
Defendants were asking the Court not only to prevent the Claimants from continuing their claims in this
jurisdiction but to seek out lawyers to litigate cases in Malaysia when they were not living there and did not
know anyone who knows a Malaysian lawyer.

75. The Claimants accepted that where the alleged mistreatment took place was obviously relevant, but it
was unlikely that, or at least questionable whether, the Dyson Defendants would challenge the alleged
mistreatment. Indeed, that is why they say the contract with ATA/J was terminated. In essence, the claim
was about D1 and D2's responsibility, and their liability was not dependent or contingent on D3. It is
alleged that D1 and D2 knew of the risk of mistreatment. Although the damage was sustained by the
Claimants in Malaysia, it is alleged to be ongoing elsewhere: in Nepal and Bangladesh.

76. The Claimants contended that the centre of gravity of the claim was outside of Malaysia. The issues
most likely to occupy the central focus of the litigation seen through the prism of both negligence and
unjust enrichment was whether the Dyson Defendants owed the Claimants a duty of care, what the
standard of care was and whether the Dyson Defendants breached that duty. The assessment of those
issues predominantly concern acts within England. This is where the relevant policies were made and
where the framework of oversight is based. In addition, it was contended that what went on in the ATA/J
factories or at the police station may not in reality be in dispute.

77. Furthermore, as a matter of convenience or practicability, Mr. Hermer KC argued that Malaysia had a
real disadvantage because participation in a trial in Malaysia will be effectively impossible for the
Claimants. Those who live outside of the country will not be able to enter; those who did enter would be at


-----

risk of arrest or imprisonment for overstaying in the past; those still living there were living under the radar.
In England, on the other hand, their legal representatives would be able to bring over the Claimants so that
they could participate in the proceedings. Where, as here, a breach of human rights was alleged, it was of
real value for the Claimants to be able to participate in the steps leading up to trial as well. There was no
guarantee that the Malaysian courts would agree to the receipt of video evidence. Even if they did, there
was a qualitative difference between attending a hearing remotely and attending in person.

78. Mr. Hermer KC also contended that there was practical convenience in holding the case in England
when considering the question of documentation, which was central to the question of liability: the
documents could be distilled by and for the Claimants in this country using disclosure software; in Malaysia
this would need to be done by hand. Documents from ATA/J can be obtained: either through joining them
to the English proceedings, or through voluntary request, or in any event the Dyson Defendants had a
contractual right of access to ATA/J's documents.

79. The Claimants acknowledged that the risks of irreconcilable judgments would be significant. However,
they argued that there would be no difficulties in bringing ATA/J into the claims in England, or of
enforcement of judgment in Malaysia. On the other hand, there would be irreconcilable judgments if the
claim was heard in Malaysia and the defamation proceedings were determined in England. It was highly
likely that the Court hearing the defamation claim would be expected to traverse very many of the same
issues as the Claimants' claim, and would look at the same documents, hear from the same witnesses and
address the same allegations, and this was not speculative. D1 and D2 had chosen to litigate the
defamation claim.

80. As for why the Claimants could not get justice in Malaysia, nine points were made in the oral
submissions before me: (i) there were real difficulties in obtaining access to justice for migrant workers,
given the absence of legal aid services and lack of trained lawyers for foreign workers; (ii) the claims were
complicated and needed suitably qualified advocates, and the lawyers who argued labour and migrant
cases did not have the expertise necessary to deal with this kind of case, and teaming up was unlikely; (iii)
it was not possible to case manage out complexity and, although personal injury cases could easily be
divided into liability and quantum, this was not possible for a claim of unjust enrichment where establishing
the extent of enrichment was part of the question of liability. A very substantial part of the case would
involve unjust enrichment, and an estimate of 6 months for the trial had been given; (iv) there would be
very significant disbursements, not least on expert fees; and there would be a need for forensic accounting
for the unjust enrichment claim; (v) the claims would involve considerable financial risk for the Claimants'
legal representatives. They would have to commit thousands of hours of work, and be at risk that they
would not recover anything for their efforts. Among other things, there would also be translation costs,
hundreds of hours for reviewing documents, and also the cost of setting up hearings in Bangladesh. The
fact that there was one witness who had said he would take the case (Mr Chandrasegaran) was not
sufficient; (vi) the prospect of a small band of practitioners being willing to take the risk was reduced when
considering that they would be opposed by Defendants without any effective limitation on resources,
represented by one of the largest law firms in the world, and where an aggressive and heavy-handed
approach is likely to be taken in the defence of the proceedings; (vii) it was inappropriate to rely on the
undertakings given by the Dyson Defendants. Paying for the disbursements does not touch the size of the
financial risk. There was also a conflict of interest here, as the Claimants' legal representatives would be
negotiating with the Defendants' legal representatives over the reasonableness of the costs incurred; and
(viii) there was no cogent evidence that the gaps could be filled by NGOs. In addition, (ix) the Claimants
contended that partial CFAs were unlawful in Malaysia; and even if they were lawful, they cannot be
nominal, and the fee that would have to be paid by the Claimants would be set at a level which was
unrealistic.

81. Further submissions were produced by the parties following the Court of Appeal's decision in the
defamation case, and following the Claimants' review of the contracts between Dyson Group companies
and ATA/J which took place after the hearing before me. With respect to the latter, the Claimants refer
among other things to the fact that one of the contracts with ATA (and Dyson Operations Pte Ltd, a
Singaporean company within the Dyson Group) obliges ATA to comply with various English law


-----

obligations; that the Dyson Group's United Kingdom-based lawyers may have been involved in drafting the
contract and played a part in its termination; and Dyson Group companies will already have access to
documentation relating to ATA's working practices.

Discussion

82. I have carefully considered all of the evidence presented to me, along with the written submissions and
the oral submissions forcefully made by counsel for the respective parties. I note, at the outset, that on a
number of points of significance there was opinion evidence pointing in different directions. Indeed, on
various points, there were competing opinions expressed by two former Chief Justices of Malaysia. It was
not appropriate for me to make findings of fact on these various points of difference on a balance of
probabilities basis, as I was not conducting a mini-trial. Nevertheless, I have scrutinised the different
positions to see if the opinions were properly supported by the evidence, and have sought to evaluate
whether the risks identified were realistic or not. It is not enough, in my judgment, for the evidence of an
expert to be accepted as identifying a real risk merely because of the eminence of that individual. That
evidence had to be cogent, which I take to mean being clear, logical and convincing or persuasive.

_Spiliada Stage 1_

83. With respect to Stage 1, the key factors are as follows.

84. (i) Neither England nor Malaysia are practically convenient for all of the parties and witnesses.
Wherever the claims are heard, there will be some parties and witnesses for whom that location will not be
convenient, and this factor is essentially neutral as between the different fora.

85. D1 and D2, and the likely relevant witnesses for those companies are located in England, and so
England is convenient for them. It is not convenient for any of the other parties, as they would have to fly to
England and be accommodated here if they wished to give evidence in person: D3, and the likely relevant
witnesses for those companies, are located in Malaysia; ATA/J witnesses (if they are joined to the English
proceedings) are located in Malaysia; the Claimants are not located in England.

86. Malaysia would be convenient for D3 and its witnesses, as well as those of ATA/J and the Malaysian
police (if the latter two parties are joined to the Malaysian proceedings). The witnesses for D1 and D2
would need to fly to, or be accommodated, in Malaysia. The majority of Claimants are located outside of
Malaysia (in Bangladesh and Nepal) and they will be unlikely to return to Malaysia to give evidence, and if
they were to participate in the hearing, they would have to attend proceedings remotely. A small number of
Claimants are located in Malaysia, although there is a serious risk that they would not feel sufficiently
comfortable to give evidence there in person.

87. I have no doubt that the English Court will direct that evidence can be given remotely if that is
requested by any party. This will reduce the practical inconvenience and cost of witnesses flying to, and
being accommodated, in England. Different views have been expressed as to whether the Malaysian
Courts would exercise their case management powers to allow for remote attendance at the hearing (this
would apply not only to the Claimants, but also to those witnesses for D1 and D2 who did not fly to
Malaysia).

88. Former Chief Justice Tun Arifin expressed the view that he was sure that the High Court in Malaysia
would order that the evidence of the Claimants could be given remotely. In his view, the Malaysian Court
would take into account and give significant weight to the fact that a witness based abroad has a wellfounded fear of coming to give evidence in person in Malaysia. The approach to remote hearings is wellestablished. They will not be used in exceptional circumstances only. The Malaysian Court would not
simply abandon the use of remote evidence if technical problems arose. The primary aim of the Court
would be to achieve the just disposal of the case.

89. Dato' Malik noted that the default position with respect to trials was that they were conducted in
person, but he recognised that this could be displaced if the parties agreed otherwise. Dato' Malik said that
the Court would have regard to a variety of factors set out in the Practice Direction, and said that when
remote hearings were granted the Courts imposed onerous conditions.


-----

90. Former Chief Justice Malanjum explained that the Malaysian Court's Practice Directions which
enabled remote hearings were issued during the Covid-19 pandemic and, now that the pandemic had
passed, it was his view that “it is more likely that hearings in person will be ordered, and remote evidence
will be permitted in exceptional circumstances only”. In his view, the chance of being refused an online
hearing application was “now real”. He stated that “the chance of persuading a Judge to exercise his or her
discretion to order remote evidence will be quite slim”. In his view, such a chance would “be further eroded
if there are technical and procedural obstacles, such as language/interpreter issues and internet
connectivity. It must also be appreciated that Judges in Malaysia are expected to clear their cases within a
certain time frame. Hence, delays due to such technical glitches would not be easily accepted, given that
the physical presence of witnesses and litigants would remove these difficulties.” In his view, although in
theory it is possible to ask for the Claimants to give evidence remotely, “considering their locations, it would
be quite a monumental task to effect this”. The Practice Directions allowed the Court to cancel the use of
remote video technology where there were technical interruptions. Where the Claimants had unreliable or
slow internet or low-quality video conferencing equipment, former Chief Justice Malanjum considered that
the Court might decide against making order in favour of giving remote evidence.

91. Surendra Ananth, a Malaysian lawyer who practices in the field of civil, commercial and administrative
law, and is acting pro bono in environmental and human rights litigation, expressed the view that although
Malaysian Courts allow for trials to be conducted online, they would not be feasible for the present claims.
In his experience, the Courts generally only allow civil trials to be conducted online where the matter is
substantially document-based. In exercising discretion to conduct a trial online, the Court must consider (a)
the complexity of the case, (b) the ability of the witnesses to testify online, (c) the availability and quality of
the technology that will be used, and (d) the right of parties to a fair hearing.

92. It seems to me that the risk that a Malaysian Court would not allow a remote hearing in this case (or,
more likely, a hybrid hearing in which the legal representatives and some witnesses attended in person
whilst some witnesses gave evidence remotely) is not a real one. Former Chief Justice Malanjum's opinion
did not take into account that funding for the remote hearing arrangements would be met by the Dyson
Defendants, thereby diminishing the prospect of technical difficulties which might otherwise be a concern
for the Malaysian Court. Furthermore, his view was that remote hearings only took place post-pandemic in
exceptional circumstances, a view which was not shared by the other witnesses.

93. All of the witnesses acknowledged that the Malaysian Court had the power to direct remote hearings.
The factors that the Court would need to consider when exercising its discretion strongly favoured the
giving of remote evidence, and it was difficult to imagine that the Malaysian Court would look at these
factors substantially differently to an English Court. The litigation involved an issue of real public
importance. Access to justice in Malaysia would be totally denied to the Claimants if a remote hearing
could not be permitted, given that they would not for good reason (whether fear of arrest on return, or lack
of funds) be able to attend in person. The parties were also in agreement that the hearing should be
remote, or at least involve remote evidence. The fact that the Dyson Defendants had committed to fund the
arrangements would mean that the risk of technical problems arising would be seriously diminished, and
the onerous conditions that the Court might impose would most likely be met.

94. I accept that the factor of “practical convenience” should also include consideration of the giving of
instructions to one's legal representatives, and also staying involved in or informed of the various case
management and procedural steps in advance of the substantive hearing. This element is essentially
neutral between the different fora, given the location of the various witnesses and parties. With respect to
the Claimants, it would be possible for the Claimants to give instructions and discuss the case with legal
representatives in Malaysia or England even though they live outside of either country: telephone and
email facilities are available in the places where they now live, even if WiFi connections are patchy from
time to time.

95. It did not seem to me that the question of practical convenience at Stage 1 involved the consideration
as to how easy it would be for documents to be distilled by and for the Claimants in the different
jurisdictions: the use of disclosure software in England as opposed to reviewing documents by hand in
Malaysia This is not one of the specific examples given by Lord Briggs in Vedanta at §66 and was not


-----

analogous to any of them. In essence, this would be an issue for the relevant legal representatives. In
some cases, that could impact on costs, but that was not of any real bearing in this case as the Claimants
would not bear these costs themselves. In any event, even if this matter was properly taken into account at
Stage 1, it could only have a very slight effect on the question and, in light of the more substantial matters
that I am addressing under Stage 1, makes no difference to the outcome of my assessment.

96. (ii) There is no completely common language for each of the witnesses, and so this factor is neutral.
Although English is likely to be spoken by most (if not all) the Dyson Defendants' witnesses, and English
will be the language of presentation in this country's Courts, it can also be the language for those giving
evidence in Malaysia according to Dato' Malik and former Chief Justice Tun Arifin. The need for
interpreters and the translation of the Claimants' evidence, with the associated cost and potential for
distortion, applies equally to both jurisdictions.

97. (iii) The system of law which will be applied is that of Malaysia, and this is a factor which clearly
favours hearing the case in Malaysia.

98. Malaysian law is not the same as English law and the claim against the Dyson Defendants contains
some novel points of law: whether joint liability can apply to those who are in a supply-chain relationship
and not merely within the same corporate structure; and whether the unjust benefit in a claim for unjust
enrichment has to flow directly from the plaintiff to the defendant. I consider that it is far more appropriate
for these legal issues to be decided by Malaysian judges than English judges ruling, based on an analysis
and evaluation of expert opinion, what Malaysian law would be. This is supported by a number of factors.

99. First, English judges could not assume that the novel points of law would be decided in Malaysian law
the same way as they would in English law. Whilst there are clearly substantial similarities between English
law and Malaysian law, and English Court decisions on common law matters are frequently referenced and
applied by Malaysian Courts, the evidence is that case law from other Commonwealth nations such as
India, Singapore, Australia, New Zealand, Canada and Hong Kong is also persuasive for the Malaysian
Courts. The evidence before me was that the Malaysian Courts would not necessarily follow English law
when considering the cause of action for unjust enrichment. In this regard, I note that the Malaysian lawyer,
Dato' Malik, described the cause of action for unjust enrichment as being “still in a formative stage”, and he
noted in particular the divergence from English law on the “unjust” ingredient. Former Chief Justice Tun
Arifin stated that under Malaysian law it is the party alleged to have been enriched who bears the burden of
establishing that there was a lawful basis for their enrichment, which is different from English law.

100. Second, English judges could not assume that there would be consistency between the experts. The
evidence adduced for this application indicates the possibility of there being differences of opinion on key
legal issues from eminent Malaysian jurists. In the reports before me, I note that there are differences
between two former Chief Justices of Malaysia on an analogous issue: whether “a Malaysian Court would
be likely to apply Caparo over Vedanta and Okpabi” when considering the question of liability of a parent
company for the direct acts and omissions of a subsidiary company.

101. Third, I also have regard to the fact that the underlying labour laws that the Claimants complain have
been breached by ATA/J are Malaysian statutes, where there is presumably a large corpus of law with
which the Malaysian Courts are familiar (and will certainly be more familiar than their English counterparts).

102. (iv) The issues in this case took place in both England and Malaysia, however, the place where the
harm occurred was in Malaysia (even if there are ongoing injuries for the Claimants who live outside of
Malaysia), and the underlying alleged mistreatment took place in Malaysia. In my judgment, the centre of
gravity of this case is plainly Malaysia, and this is a strong factor pointing towards Malaysia as being the
proper forum.

103. The claims against the Dyson Defendants are contingent on whether the underlying mistreatment by
ATA/J which is alleged to have taken place over a number of years (from 2011 to 2022) and/or by the
Malaysian police actually occurred. If that mistreatment did not occur, the claims against D1 and D2 fail,
irrespective of whether in principle they could be held liable for what took place within their supply chain. In
other words, even though D1 and D2 are situated in England, the policies which they promulgate (and


-----

which are alleged to have been contravened) applied to activities that took place in Malaysia, and would
have been based on information arising from Malaysia via D3 which had the direct contractual relationship
with ATA/J and primary responsibility for policing ATA/J's treatment of its employees. The Dyson
Defendants have not admitted that mistreatment and I cannot assume that they will.

104. The allegations as to the underlying mistreatment are fundamental to the Claimants' claim, and are
likely to take up a considerable proportion of the hearing on liability. In the circumstances, I cannot accept
Mr. Hermer KC's submission that the main focus of the trial will in reality be concerned with D1 and D2,
and the Dyson Defendants' policies, activities and arguments about their liability.

105. (v) The documents relevant to the case are held in both England and Malaysia. Wherever a trial is
held, it seems most likely that the relevant documents will be obtainable.

106. If the trial took place in Malaysia, the evidence of John Leadley, a partner at Baker & McKenzie LLP
(solicitors to the Dyson Defendants) was that relevant documentary records held by D1 and D2 would be
disclosable in Malaysian court proceedings in accordance with the local procedural rules. This was
supported by former Chief Justice Malanjum, who referred in his evidence to Order 66 of the Malaysian
Rules of Court 2012, which empowers the High Court of Malaysia to make orders for the examination of
witnesses and for production of documents in relation to a matter pending before a Court in a place outside
of the jurisdiction. The disclosure rules in Malaysia would plainly cover documents belonging to D3, as well
as ATA/J and the police.

107. If the trial took place in England, the Court would need to rely on the judicial mutual assistance of the
Malaysian Courts to secure the production of witnesses and documents from the police, and this has been
described as a cumbersome process. However, as Mr. Hermer KC quite rightly pointed out, the police are
unlikely to have many records detailing torture and mistreatment of the four Claimants. With respect to
ATA/J documents, many of these will be disclosable to the Dyson Defendants pursuant to contract (and
many of them will already be available to parties within the Dyson Group already), and any objection by
ATA/J to their disclosure would result in an application to the Malaysian Court.

108. Overall, I consider that these latter factors would make matters slightly more inconvenient if the case
was heard in England, and so slightly favours the Malaysian forum.

109. (vi) There is a real risk of a multiplicity of proceedings, and of irreconcilable judgments, wherever this
claim is heard.

110. All of the allegations made by the Claimants and any contribution claims made against ATA/J and the
Malaysian police could be heard in one hearing in the Malaysian Court. There is, therefore, no risk of
fragmentation of the issues in the present claim if the Claimants proceed in Malaysia. That is highly unlikely
to be the case if the claims were allowed to proceed in England, given that the Malaysian police have not
waived State Immunity, and I have no reason to consider that they would do in the future. It would not be
possible, therefore, for the Malaysian police to be joined to the proceedings in England.

111. Insofar as the English Courts made findings as to how four of the Claimants were treated by the
Malaysian police, these findings would not be binding on the Malaysian Court. It would be necessary,
therefore, for the Dyson Defendants to sue the Malaysian police separately in Malaysia if they wished to
recover any damages. This would require the Dyson Defendants to establish liability against the police
(without being able to rely on the English Court's judgment). It is not certain that this will happen, as the
Malaysian police have not yet been put on notice that proceedings will be issued against them, but there is
a real risk that they will, given that the damages claimed against the Dyson Defendants includes
aggravated and exemplary damages.

112. I note, however, that the claims involving the Malaysian police concern four Claimants only, and in
the overall scheme of things this is a relatively minor part of the claims. As a result, although this factor
favours hearing the case in Malaysia, it is only a relatively slight factor. I am conscious that the tail should
not wag the dog: per Coulson J. in Vedanta at §168.


-----

113. ATA/J has so far refused to submit to the jurisdiction of the English Courts, and it is uncertain as to
what their response will be if they were joined to the proceedings in England by the Dyson Defendants.
That joinder might be on the statutory basis only, as the contractual indemnity with D3 (contracts are dated
2009, 2011, 2013 and 2020) contain clauses granting Malaysia exclusive jurisdiction or call for arbitration
in Singapore, and there is no guarantee that ATA/J will waive those provisions, allowing the contractual
indemnity claim to be brought against them in England.

114. If ATA/J are properly served with notice of the proceedings, but do not take part in the English
proceedings, then the question arises as to whether there is a real risk that judgment could not be enforced
against them in Malaysia. That was the view of former Chief Justice Tun Arifin who stated that it was
difficult to predict how the Malaysian Court would rule if presented with an English judgment on ATA/J's
contribution given in default of appearance or otherwise. He said that the Malaysian Court would have to
be satisfied that the English Court had jurisdiction at the relevant time in circumstances where the
jurisdiction would not be based on traditional grounds such as presence within the jurisdiction. He was not
aware of any case where the English Court's Part 20 claim service out jurisdiction had been considered.
He considered that there was a real risk that a Malaysian court would decline to enforce a judgment
against ATA/J in circumstances where they had not participated in the English proceedings even if they
had been served. Furthermore, there was a risk that a Malaysian Court would decline to enforce a
contribution claim against ATA/J on public policy grounds on the basis that recognition and enforcement
would encourage forum shopping and would be contrary to natural justice to require ATA/J to submit to the
jurisdiction.

115. If the English judgment was not recognised, the effect of this would be that the Dyson Defendants, if
they lost the substantive claim in the English Court, would then have to establish that they were liable to
the Claimants in the Malaysian Courts before they were entitled to claim contribution from third parties in
Malaysia, in accordance with the judgment of Lord Goff in the Privy Council decision of Société Nationale
Industrielle Aerospatiale v Lee Kui Jak [1987] 1 AC 871(appeal from Brunei, which has the same statutory
contribution provision as in Malaysia). Even if the Dyson Defendants admitted liability for these matters –
based on the findings of the English Court – the other parties (ATA/J and/or the Malaysian police) may give
evidence to contradict those findings, thereby giving rise to the possibility of inconsistent conclusions on
the issue of liability.

116. A contrary view was expressed by former Chief Justice Malanjum, who emphasised the Malaysian
Reciprocal Enforcement of Judgments Act 1958 which permits enforcement of monetary judgments from
reciprocating countries, including the United Kingdom. That contrary view was shared by Dato' Malik, an
experienced litigator in the Malaysian Courts. This was also supported by the point made in submissions
by Richard Hermer KC that the rules for service out of the jurisdiction in Malaysia are strikingly similar to
those in this country, and so it would be rather surprising if the Malaysian Courts regarded it as against
public policy for ATA/J to have been joined to proceedings in England, when in a mirror image claim a third
party could be served out of the jurisdiction in Malaysia.

117. It seems to me that these latter points are far more compelling than the view of former Chief Justice
Tun Arifin. Former Chief Justice Tun Arifin's view was premised on the fact that this kind of situation had
not arisen previously, and there were various matters that could potentially persuade the Malaysian Court
not to enforce an English judgment against ATA/J. These points lacked cogency. Where the Malaysian
Court has substantially similar powers to the English Court when it comes to service out, and when it is
assumed that ATA/J will have been given proper notice of their joinder to the English proceedings, it seems
most unlikely that the Malaysian Court would treat the matter differently than would an English Court.
Accordingly, I consider that the risk of irreconcilable judgments with respect to ATA/J is fanciful, rather than
real.

118. The potential for a multiplicity of proceedings and the risk of irreconcilable judgments is also said to
arise from the defamation proceedings maintained by D1 and D2. Richard Hermer KC argued that the
ongoing defamation proceedings, which had been brought by D1 and D2 by choice, put the Stage 1 issue
beyond all doubt. I disagree.


-----

119. At this stage, there is an element of speculation as to what defence will actually be run by the
broadcaster at trial of the defamation proceedings. It is possible that the broadcaster will not run a defence
which requires the Court to determine whether mistreatment of the Claimants did, in fact, take place when
working for ATA/J. I have to say, however, that there is a substantial risk that the broadcaster will run such
a defence and that a Court will have to make findings as to what did, in fact, occur. There is, therefore, a
substantial risk that an English Court hearing the defamation proceedings will reach a judgment that will
not be binding on a Malaysian Court hearing the Claimants' claim, as the parties to the two sets of
proceedings will be different. This means that there is a substantial risk of irreconcilable judgments with
respect to many of the same factual matters in both sets of proceedings. If that was all, this factor would
point strongly in favour of England being the appropriate forum.

120. That is not all, however, as it seems to me that there is a real risk of irreconcilable judgments even if
the Claimants' claim is heard within this jurisdiction. It seems to me unlikely that the defamation case and
the Claimants' case will be case managed together, or even with a real eye on one another. The parties
are not the same in the two actions, and the broadcaster may have little interest aligning their defence to
the prosecution of the claim by the Claimants. I acknowledge that there is a possibility that the stars will be
aligned, so that the findings of fact would be the same in both claims in England, but that outcome is most
unlikely.

121. Overall, therefore, I consider that this factor – multiplicity of proceedings (or fragmentation) and
irreconcilable judgments – does favour hearing the Claimants' case in England and not Malaysia,
especially as the defamation proceedings have been brought in this jurisdiction by D1 and D2, and so they
had choice in the matter. However, given that a claim involving the Malaysian police must be heard in
Malaysia and not in England, and that there is a real risk that the defamation proceedings will result in
irreconcilable judgments in either jurisdiction, this is not a factor which puts matters beyond doubt. Rather, I
regard this as a significant factor favouring England as the proper place to hear the claim. It must be
weighed in the balance with all of the other factors, however, including those that favour hearing the case
in Malaysia.

_Spiliada Stage 1: conclusion_

122. Taking all of these factors into account, my conclusion at the end of Stage 1 is that England is not the
natural or appropriate forum and that Malaysia is another available forum which _is clearly and distinctly_
_more appropriate. The centre of gravity in this case is Malaysia: that is where the primary underlying_
treatment about which the Claimants complain took place, and is therefore the forum with “the most real
and substantial connection” per Lord Goff in Spiliada at 478A. Malaysian law is also the governing law, and
there are good policy reasons for letting Malaysian judges consider the novel points of law that are being
raised in this claim within the context of their jurisprudence, rather than letting an English Court second
guess what they might decide. In my judgment, these factors are not “dwarfed” by countervailing factors
(per Lord Mance in VTB). The risk of irreconcilable judgments resulting from the defamation proceedings is
an important factor, but it does not tilt the balance in favour of the English Court being the proper forum to
determine the Claimants' claim.

123.  Mr. Hermer KC submitted that the Court could sever the claims against D1 and D2 from that against
D3, and decide that the claim should proceed against D1 and D2 because England is the proper forum for
hearing that claim under Stage 1. In those circumstances, it would not be necessary to consider Stage 2
with respect to the claim against D1 and D2 or D3. I agree that severance would be permissible in
principle, but it would not make any difference to the outcome at Stage 1. The factors that have driven the
conclusion set out in the previous paragraph apply to the claim against D1 and D2. Whilst it is correct that
their alleged actions or omissions took place in England, any claim against them is contingent on making
out that harm was caused to the Claimants in Malaysia. Further, the governing law is that of Malaysia.

_Spiliada Stage 2_

124. As I have decided under Stage 1 that England is not the natural and appropriate forum, and that
Malaysia is clearly and distinctly more appropriate, I need to go on and consider Stage 2. In doing so, I
have looked at all the circumstances of the case (including those considered at Stage 1) and considered


-----

whether there are special circumstances such that justice requires the trial to take place in England. In
accordance with Lord Briggs' warning in _Vedanta, I am reminded that “a conclusion that a foreign_
jurisdiction would not provide substantial justice risks offending international comity”, and as a
consequence “Such a finding requires cogent evidence, which may properly be subjected to anxious
scrutiny.”

125. The Claimants have advanced a number of different arguments as to why they say that there is a real
risk that they will not obtain substantial justice in Malaysia. It is necessary for me to examine these
arguments with anxious scrutiny.

(i) Difficulties in obtaining justice for migrant workers

126. The Claimants contend that there are real difficulties in obtaining access to justice for migrant
workers, given the absence of legal aid services and the lack of trained lawyers for foreign workers. In
support of this argument, they cite the Malaysian Bar Council's report, Migrant Workers Access to Justice,
28 November 2019, which stated that finding lawyers to take migrant cases further than negotiation is very
difficult: “Few lawyers have the expertise, interest, and time to represent migrant workers.” Whilst this is no
doubt correct as a general rule, there is clear evidence that many migrant workers do obtain access to
justice and obtain representation by trained and experienced lawyers which goes beyond the negotiation
stage. The evidence from Chandrasegaran A/L Rajandran, an experienced lawyer who has represented
workers and trade unions in the statutory tribunals and civil courts, supports that conclusion. Furthermore,
there is evidence to suggest that forced labour is a high profile issue in the country (including the
ratification of the International Labour Organisation's forced labour convention); the Federal Constitution
stipulates for the right of access to justice; and the Malaysian legal profession is active, skilled and publicspirited, acting for migrants. In the circumstances, I do not consider that there is a real risk that the
Claimants will fail to obtain justice merely because they are migrant workers.

(ii) the claims were complicated and needed suitably qualified advocates, the lawyers who argued labour
_and migrant cases did not have the expertise necessary to deal with this kind of case, and teaming up was_
_unlikely_

127. Dato' Malik expressed doubts that there were qualified advocates in Malaysia who had necessary
expertise to take the Claimants' cases. He stated that no Malaysian advocate had represented a plaintiff in
making a claim for unjust enrichment or parent company/supply chain liability in circumstances similar to
that of the Claimants. Dato' Malik said that only a small number of Malaysian advocates have general
experience of a high level in both claims for unjust enrichment and for tort. The advocates that had been
suggested by Mr Chandrasegaran and Ms Chew were experienced in the field of employment and
industrial law, but their experience would be in statutory tribunals and in High Court claims arising
therefrom, and they would not have experience of tort and unjust enrichment.

128. Dato' Malik analysed the various cases that had been brought by migrant workers, and sought to
distinguish them from the present claims: none of them involved a claim for unjust enrichment or claims for
forced labour. Thus, the multi-claimant case of Goodyear was a claim brought by migrant workers in the
Industrial Court for underpayment. Other cases that had been referred to by Ms Chew in her witness
statement were cases for enforcement of terms under a contract of employment, claims arising from motor
accidents, physical abuse by an employer, wrongful termination, assault and negligence, breach of
statutory duty and negligence arising from a workplace accident.

129. Mr. Pereira expressed the view that for the Claimants to have a fair trial in Malaysia they would need
a prominent and senior civil court lawyer to represent them, given the complexity of the claims. These
lawyers were significantly different to lawyers operating in the statutory tribunals, whose claims are based
on simpler causes of action. The senior civil court lawyers charge significantly higher fees and he seriously
doubted that they would work for free on a complex claim involving forced labour and false imprisonment.
Ms. Glorene Amala Das from Tenaganita (an NGO that works on issues relating to human rights abuses,
migration, gender and human trafficking) expressed the view that High Court proceedings for complex
claims would require an experienced lawyer and they rarely take migrant worker cases. As a result, her
organisation only assisted cases that were being brought in the statutory tribunals


-----

130. On the other hand, Dato' Mah Weng Kwai (the former Judge of the Court of Appeal) expressed the
view that members of the Malaysian legal profession and judiciary are more than capable of handling a
claim of this nature if brought in the Malaysian Courts. Malaysian lawyers would have sufficient resources
in terms of skill, knowledge and manpower to deal with a claim of this nature including getting the case
ready for trial. There are many lawyers who are prepared to argue novel and difficult points of law.

131. This view was shared by Mr. Chandrasegaran, who stated that there was no shortage of lawyers in
Malaysia who were capable of taking a case involving the issues in the present claim to the highest levels
of the court system if necessary. Whilst he recognised that the claims were novel and ground-breaking, as
the Claimants were claiming against their employer's customer, and he recognised that the case would
require a significant amount of analysis of the Dyson Defendants' documents, policies and their witness
evidence, the underlying factual allegations were typical of many workplace disputes that he dealt with in
the Malaysian courts on a regular basis. This view was echoed by former Chief Justice Tun Arifin who
stated that the courts in Malaysia hear many complicated cases argued by Malaysian lawyers. He also
noted that lawyers who practice in the fields of industrial relations and employment law are generally
familiar with the practice and procedure of the higher courts, and would be suitable for this case given that
it involves issues of alleged forced labour, unpaid wages and poor working conditions.

132. In my judgment, there is no real risk that the Claimants could not find suitably qualified advocates to
deal with this kind of case. Substantial justice does not require the Claimants to receive a _Tesla_ service
(which they would doubtlessly receive if their claim proceeded in England), and this lesser standard does
not appear to have been sufficiently appreciated by those lawyers who have cast doubt on the ability of the
Claimants to find suitably qualified advocates. This undermines the cogency of their evidence. Whilst it was
correct that the lawyers who argued labour and migrant cases had never argued a similar kind of case
before, and lawyers who regularly appeared in complex civil claims may not be prepared to represent the
Claimants as their fee requirements could not be met, there was evidence that lawyers – such as Mr.
Chandrasegaran – had argued complex cases in the High Court (the _Goodyear_ case went to the High
Court and Court of Appeal), and I see no reason why a lawyer like him would not be suitably qualified to
argue the tort and unjust enrichment aspects of this case (whether supported by other lawyers, or a team
of lawyers, or not). There was plenty of evidence that lawyers teamed up to take on cases. Dato' Malik
agreed that it was not uncommon for multiple lawyers from different firms to come together and act on a
specific matter, particularly sole practitioners or small partnerships. Mr. Ananth agreed with this, as he had
worked with an external firm of solicitors when handling a complex tort claim.

(iii) it was not possible to case manage out complexity, and although personal injury cases could easily be
_divided into liability and quantum this was not possible for a claim of unjust enrichment, where establishing_
_the extent of enrichment was part of the question of liability. A very substantial part of the case would_
_involve unjust enrichment, and an estimate of 6 months for the trial had been given_

133. The Claimants accept that for the personal injury cases a split trial could be ordered, separating out
liability and quantum. This was the evidence of former Chief Justice Tun Arifin, who expressed the view
that the Court would be most likely, on the application of the parties, to order that liability be determined
before and separately to the question of quantum; and after determining liability, the Malaysian High Court
would ordinarily make an order for costs to be paid by the unsuccessful party, and for damages to be
assessed. The Court could also, if the parties agreed, permit test cases. Former Chief Justice Malanjum
appeared to accept that the Court could order a split trial if the parties agreed: the Dyson Defendants have
undertaken to agree to this. Whilst there is evidence, from former Chief Justice Malanjum, that a trial would
take 6 months, this appears to be the length of the hearing if quantum was not split from liability.

134. I acknowledge that it would not be straightforward to split the unjust enrichment claim, as establishing
the extent of the liability was part of the question of liability. Nevertheless, it did not seem to me correct to
say that a very substantial part of the overall trial would involve unjust enrichment. The unjust enrichment
claim would involve questions as to the relevant legal principles that apply (which could be argued out in a
matter of days). Measuring the extent of the liability would be likely to involve an evaluation of what the
Claimants earned, and what level of profit the Dyson Defendants made from their labour (the question of
“surplus value”) and then consideration of whether the “surplus value” earned by the Dyson Defendants at


-----

the end of the line was legally appropriate (which may involve consideration of a reasonable level of profit).
That would require some evidence and analysis, but it would be very surprising if the time devoted to this
was extensive given that the claim involves only 24 workers. There was no evidence presented to the
Court to suggest otherwise.

135. On their own, these matters did not give rise to a real risk that substantial justice could not be
achieved by the Claimants in Malaysia.

(iv) there would be very significant disbursements, not least on expert fees; and there would be a need for
_forensic accounting for the unjust enrichment claim;_

136. The Dyson Defendants have undertaken to pay for many of the disbursements, including joint expert
fees. If the Claimants wished to instruct their own expert on personal injury matters, it seems likely that the
relevant fee would only be required to be incurred after liability had been established and an interim award
of costs made in their favour. This was the view of former Judge Kwai. Furthermore, it is not uncommon for
the Malaysian Court to order a single joint expert, and the Dyson Defendants could be ordered to bear the
upfront cost of that.

137. With respect to the unjust enrichment claim, no evidence was put forward on this point by the
Claimants as to what would be required to advance this case. I accept, however, that there may be a
requirement for some limited forensic accounting evidence. Contrary to the Claimants' submission, it is
doubtful that this would need to be extensive, given that the claim only involves 24 workers, rather than
many hundreds or thousands of migrant workers, and that the issues need not be that complex: see
paragraph 134 above. I agree with the way that this was put by Mr. Gibson KC in his oral submissions: that
the Claimants' lawyers in Malaysia would be particularly astute to make sure that the unjust enrichment trial
took place without expensive expert evidence particularly when it was not necessary.

138. Accordingly, it seems to me that there is no real risk that significant, let alone very significant,
disbursements would need to be paid by the Claimants, or by those who were funding those
disbursements (NGO or their lawyers). I deal further with the question as to whether there was a real risk
that NGOs would not fill the gaps.

_(v)            the claims would involve considerable financial risk for the Claimants' legal_
_representatives. They would have to commit thousands of hours of work, and be at risk that they would not_
_recover them. Among other things, there would also be translation costs, hundreds of hours for reviewing_
_documents, setting up hearings in Bangladesh. The fact that there was one witness who had said he would_
_do the case was not sufficient._

139. I agree with the proposition that if the claims proceeded in Malaysia, this would involve considerable
financial risk for the Claimants' legal representatives, who would have to commit thousands of hours of
work, and be at risk that they would not recover them. Also, they might be required to incur translation
costs and, potentially, some forensic accounting costs to particularise the unjust enrichment claims. They
would not have to set up hearings in Bangladesh and Nepal, however, as arrangements for remote
hearings would be met by the Dyson Defendants. The question for this Court is whether given the hours of
work involved which might not be remunerated at all, and the translation costs that might be required to be
paid, there was a real risk that the Claimants would not be able to find suitably qualified lawyers to take on
their case.

140. Various witnesses expressed the view that this risk was real. Dato' Malik expressed the view that
whilst lawyers from different firms did team up to act on a specific matter, he did not think that the firms
which would be willing to represent the Claimants would have the necessary resources to do so. They
would only do so if the success fee was substantial enough for them to share in. Given the need for
revenue to operate as a firm, and the serious commitment of time and effort which this case would require,
it would therefore limit other work that could be done. Mr. Ananth who appears in human rights cases said
that he would not be able to represent the Claimants as (i) he did not have capacity to represent them pro
bono; (ii) he would not be prepared to represent them on full or partial contingency basis given the risk of


-----

disciplinary action against him if he did so (discussed further below), and (iii) he did not expect that the
Claimants would be able to afford the cost of disbursements required to see it through to trial.

141. Dato' Malik's view was countered by Mr. Chandrasegaran, who stated that his firm would be able to
manage the claims and would bring in other lawyers to assist if necessary or cooperate with other firms. He
named three other Malaysian law firms who he said might be able to assist with the claims. Mr.
Chandrasegaran explained the likely charging structure for the case. He said that, on the assumption that
the Claimants had good prospects of success in their claims, and would obtain substantial damages if
successful, and if there were test cases run on liability alone with a good prospect of a favourable interim
costs order (all of which are not unreasonable assumptions, given that the Dyson Defendants have not
sought to strike out the claims and have not sought summary judgment; it is accepted that test cases can
be run in Malaysia and that liability could be split from quantum; and that interim costs orders were
available), he would ask the Claimants for an upfront payment, which would include a per person share of
the single issue fee. He said that he would be open to considering a higher than usual success fee in an
effort to charge an upfront fee which was affordable to the Claimants. Mr. Chandrasegaran said that he
took a novel class action migrant worker case, Goodyear, on a modest deposit, and would strive to do the
same for these Claimants if they instructed him as would other Malaysian lawyers who were committed to
ensuring access to justice in Malaysia.

142. I consider that the evidence of Mr. Chandrasegaran was cogent. It acknowledged the nature of the
case, commenting that the Claimants were seeking to bring a novel and ground-breaking claim against, not
their employer, but their employer's customer. It recognised that the case would require a significant
amount of analysis of the Defendants' documents, policies and their witness evidence. His evidence was
supported by real-life examples of working on a substantial case for migrant workers. It was also based on
real-life experience of taking cases on a partial-contingency basis. He also specifically named a number of
Malaysian law firms who might be able to assist, and Dato' Malik did not dispute that these firms might be
able to assist. The key concern for Dato' Malik was whether the success fee would be substantial enough
for the various lawyers making up the overall legal team to share in. This was addressed by Mr.
Chandrasegaran's evidence that he would charge a higher than usual success fee to take on the
Claimants' case, and there was nothing to suggest that the Claimants would not agree to that.

143. I appreciate that this is evidence of one potential lawyer only, but that is sufficient in my judgment to
mean that proper representation for the Claimants can be achieved in Malaysia: c.f. the position in
_Connelly where Lord Goff concluded at p.874E that highly professional representation could not be_
achieved in Namibia.

144. Although I am not making findings of fact, I am required to evaluate risk based on the competing
evidence. Given what Mr. Chandrasegaran has said, and how he has addressed the fundamental concerns
of Dato' Malik, the latter's evidence does not provide cogent support for the proposition that there is a real
risk that representation cannot be found for the Claimants in Malaysia.

(vi) _the prospect of a small band of practitioners being willing to take the risk was reduced when_
_considering that they would be opposed by Defendants without any effective limitation on resources,_
_represented by one of the largest law firms in the world, and where aggressive and heavy-handed_
_approach is likely to be taken in the defence of the proceedings_

145. I have no doubt that the Dyson Defendants would prove to be a tough opponent if the claim does
proceed in Malaysia: that would be their right, so long as they (and their legal representatives) act within
the law and in accordance with the relevant ethical standards and codes of conduct. There is nothing that I
have seen or heard about the way in which the Dyson Defendants have conducted the present
proceedings, and from what I have been told about the defamation proceedings, to suggest that the Dyson
Defendants and their legal representatives have in this jurisdiction acted outside the law or contrary to
relevant ethical standards and codes of conduct.

146. The fact that the Dyson Defendants will prove to be a difficult opponent, and have no real limit to the
resources available to them, is unlikely to make any difference to the willingness of legal practitioners in


-----

Malaysia (such as Mr. Chandrasegaran on his own, or with the other law firms that he has referred to) to
take the risk of representing the Claimants.

(vii) _it was inappropriate to rely on the undertakings given by the Dyson Defendants. Paying for the_
_disbursements does not touch the size of the financial risk. There was also a conflict of interest here, as_
_the Claimants' legal representatives would be negotiating with the Defendants' legal representatives over_
_the reasonableness of the costs incurred;_

147. I do not consider that there is anything improper in this Court making its decision in reliance on the
undertakings given by the Dyson Defendants. The giving of such undertakings is not uncommon in
jurisdictional disputes. I also do not consider that there is any conflict of interest here with respect to the
question of costs. If an undertaking is given to this Court that reasonable costs will be paid, then that will
presumably be the benchmark by which the Malaysian Courts will address any dispute that may arise on
the question of such costs whether the undertakings were made only to this Court or, as Mr. Gibson KC
submitted could be the case, the same undertakings were made to the Malaysian Court as well.

(viii) there was no cogent evidence that the gaps could be filled by NGOs.

148. Based on the figures provided by the Dyson Defendants, and taking into account the various
undertakings that they have given to the Court as to the fees and disbursements that they will cover, as
well as the various fees that the lawyers representing the Claimants would be expected to fund out of their
own resources, a sum of 1,916 MYR (£328) would need to be found to fill the gaps: see paragraph 67
above. The question for this Court is whether that gap in funding would be met by NGOs (as it is not
suggested that the Claimants could, or would, pay this sum themselves), or whether there was a real risk
that NGOs would not fund that amount.

149. There was much evidence as to the role that NGOs played in supporting migrant workers who bring
legal claims in Malaysia. Mr. Chandrasegaran expressed the view that there were many NGOs and trade
unions in Malaysia working with various international organisations to enable access to justice for migrant
workers in Malaysia that may be able to provide assistance to the Claimants in bringing their claims.

150. Dato' Malik expressed the view that he was not aware of any Malaysian NGO that would be prepared
to fund the entire or even a substantial part of the Claimants' expenses in bringing a claim in Malaysia. Mr.
Ananth has experience of NGOs who carry out work on the relevant area of the litigation paying for
disbursements, but not for expert fees.

151. Mr. Pereira, from NSI, explained that when assisting migrant workers with proceedings before the
Department of Labour or the Department of Industrial Relations, NSI pays for the workers' disbursements,
which can include (i) any filing fees at a cost of below 1000 MYR; (ii) special Government-issued “special
pass” visas to allow court attendance upon the termination of their “working” visas: 100 MYR per month;
(iii) hostel accommodation (usually YMCA): at least 700 MYR per month; (iv) daily food expenses: 50 MYR;
and (v) the court filing fee: 100 MYR. Mr. Pereira said that in cases that he had worked on, more senior
and experienced lawyers including Civil Court lawyers have requested upfront fees of 120,000 MYR, and
some have requested up to 50 percent of the damages award. He said that NSI had never used such
lawyers as their fees were prohibitively expensive. He said that his organisation would not be able to pay
the disbursements involved in a forced labour case in the Malaysian High Court as it has limited financial
resources. However, Mr. Pereira's evidence was premised on NSI having to pay for all or the bulk of the
disbursements: that would not be the case here, given that the Dyson Defendants had undertaken to pay
for most of the disbursements.

152. Ms. Glorene Amala Das, the Executive Director of Tenaganita, also expressed the view that her NGO
has experience of supporting individuals in the Labour and Industrial Courts. She said that, as a small
NGO, they instructed lawyers on a pro-bono basis, and were only able to fund disbursements in limited
circumstances where funds were available. She explained that it can take a long time to raise funds
needed to pursue a claim. She pointed out that some of the cases that they wanted to pursue were likely to
be time-consuming, and she regarded it as unfair for the lawyers to receive nothing for the work they will
need to do on it. As a result, she said that that is why her NGO takes on and funds the disbursement of


-----

individual cases in the Labour and Industrial Court rather than larger group cases in the High Court where
the legal fees and disbursements (including the court filing fee) would be greater, and which she said
would likely preclude her NGO from being able to fund such claims. In conclusion, she expressed the view
that her NGO would not be able to support the Claimants in the current case, as they did not have the
financial resources to fund a case that would involve multiple Claimants amounting to significant and
ongoing disbursements. As with Mr. Pereira, Ms. Glorene Amala Das' evidence was premised on her
organisation having to fund all, or the bulk, of the fees and disbursements which would not be the case
here given that the Dyson Defendants have undertaken to pay for most of the disbursements.

153. Shakirual Islam is the Chairperson of Ovibashi Karmi Unnayan Program (“OKUP”), a grassroots
migrants' rights organisation based in Dhaka, Bangladesh whose primary objective is the promotion of
safe, legal migration and ethical recruitment of migrants leaving Bangladesh for work and the sustainable
reintegration and access to justice for migrant workers returning to Bangladesh from their destination
countries. He explained that his NGO would want to support a returnee migrant worker with giving remote
evidence to Malaysian courts, but they have no capacity or budget to do this. His NGO was not able to
assist migrant workers in bringing claims against their employers or anyone associated with the employers
in Malaysia, as they did not have the financial resources available or the ability to navigate the Malaysian
legal system. Mr. Islam was aware, however, of the Malaysian NGO, Tenaganita. OKUP had partnered
with Tenaganita in 2012-2014, through CARAM Asia (a network of 42 organisations working on migrants'
rights issues across Asia, based in Kuala Lumpur, Malaysia), and referred Bangladeshi migrant workers to
Tenaganita for assistance.

154. In my judgment, if the Claimants sought to bring their claims in Malaysia, in circumstances where
legal representatives were available to assist them on a partial contingency basis (as described by Mr.
Chandrasegaran), it is highly likely that one or more of the several NGOs that support migrant workers in
Malaysia, and fund some of the fees and disbursements of migrant workers' claims, would fill the relatively
small gap in funding required by the Claimants to prosecute their claims. The risk that the NGO community
would not fill the gap is unrealistic.

155. I reach this conclusion on the basis that (i) there are several NGOs that do support migrant workers
in Malaysia, and whose very purpose is to support such workers and raise the profile of the issues affecting
migrant workers; (ii) several NGOs provide some funding for legal cases brought by migrant workers – and
the funding provided by NSI on occasions is greater than that required in the instant case to fill the gap;
and (iii) the claim against the Dyson Defendants will be high profile, focusing on the circumstances of
migrant workers in Malaysia and raising questions as to their treatment (I express no view as to the merits
of the Claimants' specific allegations, but there is no doubt that their proceedings will draw attention to
those allegations). Whilst there is evidence from witnesses who work for two of the organisations – NSI
and Tenaganita – expressing the view that they would not be able to support financially the Claimants'
claims, the premise of their evidence is that they would have to provide much more financial support than
would actually be required. What would be required here would be assistance with the basic fee and the
filing fee. It seems to me reasonable to infer that they would be willing to support the Claimants' claims if
their financial contribution was far less than they had anticipated.

(ix) In addition, the Claimants contended that partial CFAs were unlawful; and even if they were lawful, the
_basic fee to be paid cannot be nominal, and the fee that would have to be paid by the Claimants would be_
_set at a level which was unrealistic._

156. It was common ground that a fee agreement that was entirely contingent on success was prohibited:
see section 112(1)(b) of the Malaysian Legal Profession Act 1976 (“the 1976 Act”), which provides that
“Except as expressly provided for in any written law, or by rules made under this Act, no advocate or
solicitor shall enter into any agreement by which he is retained or employed to prosecute any action or
other contentious proceeding which stipulates for payment only in the event of success in such suit, action
or proceeding”.

157. There was disagreement between the former Chief Justices as to whether part contingency
agreements were permitted. Former Chief Justice Malanjum expressed the view that they were not


-----

permitted under Malaysian law, as they offended against the general prohibition in section 112(1)(b) of the
1996 Act, and that express legislation was required to permit them. He also expressed the view that the
power for advocates and solicitors to enter agreements for the costing of contentious business, at section
116(1) of the 1996 Act, did not provide the necessary statutory permission. That section provides that:
“Subject to any written law, an advocate and solicitor may make an agreement in writing with his client
respecting the amount and manner of payment for the whole or any part of his costs in respect to
contentious business done or to be done by such advocate and solicitor, either by a gross sum, or
otherwise, and either at the same rate or at a greater or lesser rate than the rate at which he would
otherwise be entitled to be remunerated.”

158. Former Chief Justice Malanjum expressed the view that the case law which purported to approve of
part contingency fees was not sufficiently reasoned and would not withstand appellate scrutiny. In any
event, he stated that if it was permitted to pay a basic fee in addition to a success fee, the basic fee would
have to be set at a more than nominal level to avoid being struck down. He stated that the Court would be
likely to consider “the quantum of claim, the fee percentage, the complexity of the case and the anticipated
quantum of success fee”; and that the disbursement costs would also need to be considered. In his view, a
basic fee of 1,000 to 1,500 MYR would be entirely nominal and would give rise to a high risk of being
struck down. Former Chief Justice Malanjum expressed the view that the prohibition of conditional fee
agreements and the lack of funding options for the case would mean that the Claimants would not be able
to engage Counsel. This was a complex case requiring significant resources.

159.  Former Chief Justice Malanjum's view that part contingency fees were unlawful was shared by the
attorney, Dato' Malik. In support of his view, Dato' Malik noted that the Attorney General's Chambers had
stated that they consider it necessary to amend section 112 of the 1996 Act in order to introduce draft rules
for conditional fee arrangements. Dato' Malik also expressed the view that given that the legal position of
success fees was far from certain, he was unable to say that any advocate reasonably acquainted with the
issues surrounding such agreements would be prepared to enter into one. They would be risking a
challenge to their fee agreement or being subject to a disciplinary complaint. As noted above, Mr. Ananth
expressed the view that given the risk of disciplinary or disqualification proceedings, he would not be
prepared to enter into an agreement for each Claimant to pay a nominal sum together with a success fee:
that kind of arrangement would be, in effect, a wholly contingent arrangement, masked as a partial
contingency arrangement.

160. These risks did not appear to deter Mr. Chandrasegaran. The evidence was that Mr.
Chandrasegaran was paid 20% of the damages award in the Goodyear litigation. In another claim involving
migrant workers contending that a collective agreement was breached, Mr. Chandrasegaran agreed to act
on a contingency basis, with disbursements paid by NSI. In his witness statement, Mr. Chandrasegaran
explained that in Malaysia it was the practice of lawyers representing workers in dismissal cases, money
claims and/or trade unions to collect an interim payment towards fees and disbursements, and the balance
of the fee as a percentage of the compensation amount. In setting the upfront fee, he would normally
consider the prospects of success and that the Court would order the defendant to pay the claimant's legal
costs.

161. Former Judge Kwai expressed the view that whereas pure contingency fee arrangements were
prohibited, the Malaysian Courts have accepted a fee arrangement under section 116 of the 1996 Act
where there is a basic or fixed fee combined with a contingent or conditional or success fee. He expressed
the view that payment of a basic fee of around 1000-1,500 MYR (between the Claimants, and to include
the filing fee of around 500 MYR) would be permissible. In his view, this would not amount to a nominal
sum. This is supported, in his view, by the fact that the Bar Council have stipulated a basic fee of 500 MYR
for personal injury claims and 1000 MYR excluding disbursements and any taxable items for non-personal
injury claims. Former Judge Kwai also expressed the view that there was no prohibition on disbursements
being funded by law firms so long as there is a basic fee to be paid with a success fee along with the
disbursements.

162. In arriving at this view, former Judge Kwai referred to the case of Chai Chee Chin and Others v
Tetuan Zahari Ong & Co [2005] MLJU 623 in which the Defendant agreed to receive a lump sum payment


-----

based on a percentage of the amount of compensation received by the plaintiff, subject to a minimum
amount of 1,000 MYR. The plaintiffs sought to invalidate the arrangement under section 112 of the 1996
Act, as they did not want to pay the pre-agreed fee to the Defendant lawyers. The High Court upheld the
fee arrangement. This case was relied upon in another High Court action where legal fees of 64,474 MYR
were paid, and a percentage of quantum was also to be paid to the lawyers: see Raymond Mah Mun Kitt v
Bengjaya Sdn Bhd [2014] 1 LNS 82. Chai Chee Chin was also approved by the Court of Appeal in Lua &
Mansor v Tan Ah Kim [2017] 3 MLJ 371, a case in which a 'success fee' of 15% was agreed on top of a
basic fee of 5,000 MYR. A couple of more recent decisions upholding a basic fee plus success fee
arrangement were Jacob and Toralf Consulting Sdn Bhd & Ors v Siemens Industry Software Gmbh & Co
Kg (previously known as Comos Industry Solutions GmbH and previously known as Innotec GmbH) & Ors

[2018] MLJU 767; and Ling Peek Hoe & Anor v Ding Siew Ching & Ors [2022] MLJU 157.

163. Former Judge Kwai also stated that the position taken by the Malaysian Bar Council since at least
2011 was that contingency fee arrangements consisting of a basic fee plus success fee were not unlawful.
He referred to the Circular issued by the Malaysian Bar Council, following discussions with the Attorney
General's Chambers, with respect to the development and legalisation of conditional fees. Proposed rules
for personal injury and non-personal injury cases have been drafted by the Bar Council. The Attorney
General's Chambers have expressed concern that these rules can only be promulgated if there is an
amendment to section 77(1) of the 1996 Act, as the proposed rules referred to 'fees', and that section did
not currently give the Bar Council the power to make rules governing fees.

164. Against this background, former Judge Kwai expressed the view that it was highly unlikely that the
Bar Council would commence disciplinary proceedings against any advocate and solicitor for any breaches
of the conditional fees arrangements. This was supported by Tony Woon Yeow Thong, a lawyer who had
been active with the Malaysian Bar Council and had served as Chairperson of its Ad Hoc Committee on
Contingency Fee Rules and as Chairperson of the Legal Practices Committee. He stated that the Bar
Council had considered the basic fee and success fee model to be lawful, but had proposed to regulate the
practice. The retainer that was set in the draft rules was designed to ensure compliance with the case law.
He explained that the minimum fee was not set by reference to the value of the case or the work involved.
The remuneration of the lawyer would come, in the event of success, from the taxed costs as well as the
success fee and the full recovery of disbursements. He explained that it was often necessary for lawyers
acting on success fee arrangements to fund the disbursements for their clients. He was not aware that the
Attorney General's Chambers had expressed any concern about the lawfulness of success fee
arrangements. He was not even aware that there was any doubt or controversy within the legal profession
that these arrangements were other than lawful.

165. I do not consider that there is a real risk that partial contingency fees are unlawful. It is clear that
there is a frequent and regular practice of lawyers taking cases in Malaysia on the partial contingency fee
basis. This has received repeated judicial support, including from the Malaysian Court of Appeal in the
case of Lua & Mansour. It is also the view of the Malaysian Bar Council, which has repeatedly made
reference to the lawfulness of such fee arrangements. There has been no dissent from this view by the
Attorney General's Chambers: their concern has been with whether the Bar Council has power to
promulgate specific rules to regulate contingency fees, rather than with the principle itself. These views and
practices are also entirely consistent with the language of section 112 of the 1996 Act which prohibits
agreements “for payment only in the event of success” (emphasis added). I am fully aware that I am not a
Malaysian judge, but I am told that the principles of statutory construction applied by the Malaysian Courts
are substantially similar to those in this jurisdiction, and the interpretation of that section which has found
favour thus far with the Malaysian Courts does, at least on its face, appear to correspond with the wording
of the relevant statute.

166. Against this background, it does not seem to me that the view of former Chief Justice Malanjum (and
Dato' Malik) that part contingency fees were unlawful, withstands anxious scrutiny. In any event, even if
there was legal doubt about the matter, there is no evidence that this would deter legal representatives
such as Mr. Chandrasegaran from taking the Claimants' case. He has taken other cases on the part


-----

contingency basis on previous occasions. Furthermore, the Dyson Defendants have undertaken not to
challenge that fee arrangement.

167. As for the level at which the basic fee would need to be set, the evidence strongly supports a realistic
fee for the Claimants of around 1,000 MYR. This is the fee that found approval in the case of Chai Chee
Chin; it is also the fee level that has been proposed by the Malaysian Bar Council for non-personal injury
claims, with personal injury claims being set at half that amount. There is real logic behind this view. By
contrast, although former Chief Justice Malanjum has expressed the view that a fee set at this level would
run a high risk of being struck down as being entirely nominal, there is no case law to support that position,
and it is not consistent with what the Bar Council have proposed more generally.

168. Accordingly, I do not consider that the risk that suitably qualified lawyers would not take on the
Claimants' case in Malaysia on a part contingency basis, with a basic fee to be paid of 1,000 to 1,500
MYR, is a real one. That position appears to be settled law and practice in Malaysia.

_Spiliada Stage 2 conclusion_

169. Taking the various arguments made by the Claimants under Stage 2 individually, and then stepping
back and looking at them cumulatively along with the arguments made at Stage 1, and bearing in mind Mr.
Hermer KC's admonition that this Court needed to “get real”, it seems to me that there is no real risk that
the Claimants will not be able to obtain legal representation and necessary NGO funding to pursue their
claims in Malaysia. I appreciate that the level of service that they may receive in Malaysia may not equal
the Tesla type service that they would no doubt receive from the legal team that they have assembled in
this jurisdiction, but there is no real risk that they will be unable to source suitably qualified and expert legal
representatives to take on their case in Malaysia on a partial contingency basis, with the fees and
disbursements funded by a combination of the Dyson Defendants (through their undertakings), NGOs, and
the legal representatives themselves. The claim against the Dyson Defendants is an important one, and is
likely to attract the interest of a number of Malaysian lawyers who work on migrant worker cases, including
Mr. Chandrasegaran.

170. I appreciate that most of the Claimants are not currently in Malaysia, and I also appreciate that none
of the Claimants appears to know any lawyers in Malaysia. Nevertheless, the names of Malaysian lawyers
and of the relevant NGOs are available to them via these proceedings, and I have to assume that if they
wish to pursue their claims in Malaysia so as to vindicate their rights against the Dyson Defendants they
will, whether alone or with the assistance of other NGOs in their home countries such as OKUP in
Bangladesh, make contact with NGOs in Malaysia who can assist them. Mr. Islam explained that his NGO
had previously made contact with Tenaganita on behalf of other migrant workers. I have no reason to
believe that he, or his organisation, would not provide similar assistance in the instant case, even though
his NGO could not fund or otherwise support the bringing of the proceedings.

171. Accordingly, I do not consider that this is one of the “exceptional cases” in which “the absence of a
means of funding litigation in the foreign jurisdiction, where such means are available in England, will lead
to a real risk of the non-availability of substantial justice”, per Lord Briggs JSC in Vedanta at §93.

Conclusion

172.  In conclusion, therefore, I grant a stay of the proceedings against D1 and D2, and set aside the
Order granted without notice by Master Gidden on 3 October 2023, and set aside the service upon D3 of
these proceedings pursuant to that Order.

173. The conduct of the Dyson Defendants in responding to the Claimants' requests for the documents
that were referred to in their witness statements – namely, the various contracts between Dyson Group
companies and ATA – does not impact on this finding. My provisional view is that the documents ought to
have been provided rather sooner than they were, and in plenty of time for the Claimants legal
representatives to review them in advance of the hearing before me. It does not seem to me, however, that
the Dyson Defendants' conduct with respect to disclosure was so egregious that it would justify this Court
in taking a different approach to jurisdiction. The matter can, if appropriate, be addressed through an order


-----

for the costs of the application made by the Claimants for specific disclosure of these documents. I will
consider the parties' submissions on costs, including costs on the application for disclosure, after handdown of this judgment on jurisdiction.

**End of Document**


-----

