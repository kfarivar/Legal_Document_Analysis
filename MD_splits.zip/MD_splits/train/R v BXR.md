# R v BXR

_[[2022] EWCA Crim 1483, [2022] All ER (D) 52 (Nov)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66WM-60B3-GXF6-80W5-00000-00&context=1519360)_

**Court: Court of Appeal, Criminal Division**
**Judgment Date: 10/11/2022**

# Catchwords & Digest

**CRIMINAL LAW - POSSESSING FALSE IDENTITY DOCUMENT WITH IMPROPER INTENTION – WHETHER**
**CONVICTION UNSAFE WHERE FRESH EVIDENCE OF MODERN SLAVERY**

The Court of Appeal, Criminal Division, allowed the appeal of the defendant Nigerian overstayer, who had
been charged with offences, arising out of the use of the false passport to gain employment. The offences had been
[committed before the defence introduced by s 45 of the Modern Slavery](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C236-00000-00&context=1519360)
the court admitted 'undisputed' fresh evidence which showed that the defendant, who had cognitive difficulties and
suffered from post-traumatic stress disorder, had been trafficked, and it quashed the convictions of the offences on
the indictment (possession of a false identity document with an improper intention and fraud). The court ruled,
among other things, that: (i) the degree of compulsion felt by the defendant, as a result of his earlier trafficking
experiences, and the further trafficking in offering him exploitative accommodation and work, had been very high;
(ii) that trafficking had been responsible for his using the false passport to obtain the exploitative job; (iii) the nexus
between the trafficking and use of the passport to gain employment had been such as to reduce his culpability for
the offending to a very low level, if not wholly to extinguish it; and (iv) accordingly, it had not been in the public
interest that the defendant had been prosecuted and, had the Crown Prosecution Service known the trafficking
circumstances responsible for the offences and applied the relevant guidance, it would very likely not have
prosecuted. The court, in so ruling, held that the absence of fault on the part of defendant's then legal advisers (who
had not been aware of the trafficking) was no bar to a successful application to set aside convictions in a case of
the present kind. Further, the defendant's conviction of a related summary offence was also quashed and the court
directed that no further proceedings should be taken in respect of another related summary offence which had been
sent to the Crown Court by the magistrates.

# Cases referring to this case

R v AFU

_[[2023] EWCA Crim 23](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:67C3-3093-CGX8-01PV-00000-00&context=1519360)_
Considered


20/01/2023

CACrimD


-----

**End of Document**


-----

