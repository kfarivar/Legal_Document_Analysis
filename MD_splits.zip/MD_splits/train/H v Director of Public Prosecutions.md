# H v Director of Public Prosecutions

_[[2021] EWHC 147 (Admin), [2021] 1 WLR 2721, [2021] All ER (D) 45 (Feb)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:61YX-B233-GXFD-820N-00000-00&context=1519360)_

**Court: Divisional Court**
**Judgment Date: 29/01/2021**

# Catchwords & Digest

**MAGISTRATES - JURISDICTION – REOPENING CASE TO RECTIFY MISTAKE ETC.**

The appellant failed in his appeal, by way of case stated, against the district judge's decision to refuse the
[appellant's application for a direction that his case be heard again pursuant to s 142(2)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61S0-TWPY-Y156-00000-00&context=1519360)
Act 1980. The appellant had entered unequivocal guilty pleas and had been sentenced by the Crown Court. He
sought to set aside his guilty plea to enable him to adduce evidence and argue a defence under s 45 of the
**_[Slavery Act 2015. In dismissing the appeal, the Administrative Court held that R v Douglas[2019] EWCA Crim 1545](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)_**
had established that once the Crown Court had passed sentence, _[MCA 1980 s 142(2)](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-61S0-TWPY-Y156-00000-00&context=1519360)_
whole scheme of s 142 was to enable the magistrates' court to intervene when the impact of an order only affected
its own determinations.

# Cases considered by this case

R v Douglas

_[[2019] EWCA Crim 1545](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8WFG-YFK2-8T41-D1VB-00000-00&context=1519360)_
Applied

Houston v Director Of Public Prosecution (2015)

_[[2015] EWHC 4144 (Admin)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JGN-9471-F0JY-C1T2-00000-00&context=1519360)_
Considered

**End of Document**


06/09/2019

CACrimD

10/11/2015

DC


-----

