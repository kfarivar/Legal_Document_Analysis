# R (on the application of Saadawi) v Secretary of State for the Home
 Department [2017] All ER (D) 03 (Dec)

[2017] EWHC 3032 (Admin)

Queen's Bench Division, Administrative Court (London)

Judge Markus QC (sitting as a High Court Judge)

29 November 2017

**Immigration – Trafficking people for exploitation – Victim of trafficking**
Abstract

_Immigration – Trafficking people for exploitation. The defendant Secretary of State's decision letter showed that she_
_had properly directed herself as to the legal criteria and had considered the relevant factors in having decided that_
_there were not sufficient grounds to believe that the claimant had been a victim of trafficking. The Administrative_
_Court, in dismissing the claimant's application for judicial review of that decision, further held that her decision had_
_clearly been within the range of decisions open to a rational decision-maker._
Digest

The judgment is available at: [2017] EWHC 3032 (Admin)

**Background**

The claimant Egyptian national obtained employment with a businessman, A, in Qatar. In November 2013, he
followed A to the UK. The claimant gave his passport to A, so that he could sort out the paperwork and never saw it
again. He did not have a bedroom and slept on the floor. Each day the claimant worked from 6 am until the early
hours of the following morning, with no day off or holidays. He was paid £140 per month, but not until March or April
2014.

In November 2015, the defendant Secretary of State decided that there were reasonable grounds to believe that the
claimant was a potential victim of human trafficking. However, in May 2016, she reviewed the case and decided
that, on the balance of probabilities, there were not sufficient grounds to believe that the claimant had been a victim
of trafficking. The claimant sought judicial review of the Secretary of State's decision.

Application dismissed.

**Issues and decisions**

Whether, applying anxious scrutiny, it had been properly open to the Secretary of State to conclude, on the balance
of probabilities, that the claimant had not been trafficked on the basis that the work had not been exacted under
menace of penalty and had not been involuntary.

The decision letter showed that the Secretary of State had properly directed herself as to the legal criteria in the
light of the 'Victims of modern slavery – Competent Authority guidance', version 3.0 dated 21 March 2016 and had
considered the relevant factors. The claimant disagreed with the Secretary of State's interpretation of the facts.
However, her decision had clearly been within the range of decisions open to a rational decision-maker.


-----

In particular, there had been no indication that the claimant had co-operated with A's wishes because of his
concerns about his visa and his immigration status. There could be no proper criticism of the Secretary of State's
decision that the timing and circumstances of a beating and threats on the claimant's last day could not have been
part of any controlling measure to keep him in employment. The other factors relied on by the claimant, including
poor pay, living conditions and excessive work load, could not have amounted to menace of penalty.

Further, a finding of vulnerability should not have been carried through to that on exploitation. The Secretary of
State had found the claimant had been vulnerable because he could find no work in Egypt and had been desperate
to support his family. That vulnerability and the fact that the claimant had ended up working in poor conditions for
low wages did not, of itself, mean that he had been trafficked for the purpose of exploitation by way of forced labour
or domestic servitude (see [30], [31], [36] of the judgment).

_Van der Mussele v Belgium (Application 8919/80)_ _[[1983] ECHR 8919/80 considered; R (on the application of BG) v](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5R5C-F7W1-DYBP-X0D2-00000-00&context=1519360)_
_Secretary of State for the Home Department_ _[[2016] All ER (D) 74 (Apr) considered.](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5JHR-T581-DYBP-N21M-00000-00&context=1519360)_

Catherine Robinson (instructed by Lupins) for the claimant.

William Hansen (instructed by the Government Legal Department) for the Secretary of State.
Karina Weller - Solicitor (NSW) (non-practising).

**End of Document**


-----

