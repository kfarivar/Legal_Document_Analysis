# R v Orlu [2024] EWCA Crim 171

Court of Appeal, Criminal Division

Lady Justice Andrews, Mrs Justice Cheema-Grubb and Her Honour Judge Rosa Dean (The Recorder Of
Redbridge)

6 February 2024Judgment

**Ms C Mawer appeared on behalf of the Appellant.**

_________

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

**J U D G M E N T**

**LADY JUSTICE ANDREWS:**

**_Introduction_**

1. On 1 December 2021, in the Crown Court at Inner London, Emmanuel Orlu, then aged 18, pleaded
guilty to two counts of robbery and one count of having an offensive weapon. Those pleas were indicated
at the Magistrates' Court and attracted full credit. Sentencing was adjourned to the conclusion of another
matter, which resulted in his acquittal, following a retrial, on 10 March 2023.

2. Although the applicant was initially remanded in custody, he was released on bail following a bail
hearing in September 2022. On 31 May 2023, by which time he was 19 years old, the applicant was
sentenced by Her Honour Judge Rowley to a total custodial term of 3 years' detention in a young offender
institution. The sentence comprised 3 years' detention on the first count of robbery, 2 years' detention on
the second count of robbery and 6 months' detention on the offensive weapon count, all of which were
ordered to run concurrently. His application for an extension of 27 days in which to apply for leave to
appeal against sentence was referred to the Full Court by the single judge, who indicated that he
considered the grounds to have merit.

3. In the light of the explanation for the delay provided by counsel, we grant the extension requested. We
also grant leave to appeal, and in the rest of this judgment therefore we shall refer to the applicant as “the
appellant”.

**_The Facts of the offending_**


-----

4. The two robberies were committed on the same day, in the same location, a football pitch in South
London. On 13 October 2021, the appellant and a male companion approached a young man named
Esteban Salgado, who was playing football. The appellant asked Mr Salgado if he could borrow his
bicycle. When Mr Salgado said “No”, the appellant simply walked away with the bicycle. When Mr
Salgado followed him, the appellant turned around and revealed that he had a knife tucked into his trouser
waistband.

5. Mr Salgado's friends telephoned the police. While they were doing so, they witnessed the second
robbery. The appellant rode the bicycle that he had stolen towards the second victim, Bayo Badmass, and
demanded his jacket and bag, otherwise he would “soak him up”. As the appellant reached for something
in his jacket, indicating that he had a weapon, the victim handed over his bag and ran away.

6. Both victims were adversely affected by the robberies. Mr Salgado said that seeing the knife was
terrifying and the experience had been scary and distressing. It had left him feeling very cautious about
being in the area and he was more worried now about taking his possessions out with him. Mr Badmass
said that he had lived there his whole life and that this had changed his relationship with his home. Not only
did they steal his belongings but they stole his peace of mind. He also said that the incident had weighed

heavily on a pre‑existing illness.

7. The police apprehended the appellant and his companion, Nobel Adamu, in a communal hallway on the
top floor of a block of nearby flats. The appellant attempted to get away, but was detained and handcuffed.
Mr Salgado's bicycle was leaning against the wall and the appellant was wearing Mr Badmass's bag. He
still had the knife tucked into his trouser waistband. Mr Badmass's wallet had been emptied and his identity
cards had been thrown onto the floor of the stairwell. Mr Adamu remained with the officers. Although he
was also arrested and charged with robbery, in the event the Crown offered no evidence against him.

8. The appellant was in breach of a GPS monitored bail condition which prohibited him from going south of
the river Thames. Despite his youth, he already had five convictions for seven offences since January
2019. These included a 2019 conviction for threatening with a bladed article on school premises, two
convictions for possession of a bladed article in a public place in 2020/2021 and a 2019 conviction for
battery. He was on bail for the 2021 offence at the time of the robberies.

**_The sentencing hearing_**

9. The appellant offered a guilty plea on the basis that he was the victim of modern slavery. He stated
that for the past 3 years he had been subject to continuing threats of violence and coercive influences from

London‑based gangs, who had indebted him and forced him to commit criminal offences in order to make

money for them. In consequence, he and his family had to move from their previous address to East
London, but a gang had discovered their new address and attempted to break into the property. The
incident was reported to the police, but he and his family continued to receive death threats from the gang.
Since he had nowhere to hide, he had travelled to South London in an attempt to resolve the situation with
the gang by meeting with them; but that morning, they had told him to commit robberies to repay his debts,
and that any item of value he could bring to them would significantly reduce his financial obligations to
them.

10. So far as the knife was concerned, the appellant said he was in possession of it to protect himself in
case he was physically attacked by members of the gang when he went to meet them.

11. By the time of the sentencing hearing, the Single Competent Authority had made a decision, on 9
February 2023, that there were conclusive grounds to accept that the appellant was a victim of **_modern_**
**_slavery: specifically, that he was forced into drug dealing in London, Milton Keynes and Basingstoke, in a_**
period between approximately 2018 and 2020.

12. The prosecution and the defence each produced sentencing notes. The Crown submitted that under
the Definitive Sentencing Guidelines for Street Robbery, count 1 was a culpability A offence because of the
production of the bladed article to threaten violence, and count 2 was culpability B because no weapon
was produced to back the threat although the appellant did make a gesture which suggested he was going


-----

to produce one if Mr Badmass did not comply. Each offence fell within category 2 for harm. The starting
point on count 1 was therefore 5 years' custody with a range of between 4 and 8 years and on count 2, the
starting point was 4 years' custody with a range of between 3 and 6 years.

13. In the Crown's sentencing note, the prosecution referred to the conclusive grounds decision and to the
basis of plea. They said that the Court would need to consider whether the defendant was involved in the
commission of the robberies through coercion or intimidation or exploitation and, if so, whether this
reduced his culpability either within the range of category A or lowered it to within categories B or C.

14. The Crown submitted that the reason advanced for the appellant's alleged coercion, intimidation
and/or exploitation was monetary gain. The amount of the debt had not been disclosed. The appellant
had not explained his failure to report the threats to the police, nor why he did not attempt to raise the
money through honest means, or even through criminality that did not involve targeting individual members
of the public. They said that the use of the knife in the commission of the offences was a choice that the
appellant made, clearly with the expectation that it would speed up the process, scare the victims into
compliance and so reduce the effort required in stealing their property. They submitted that the conclusive
grounds decision did not alter the placement of counts 1 or 2 within the guidelines in terms of culpability
and, on that basis, it should not make a material difference to sentence.

15. Ms Mawer, on behalf of the defence, submitted in her sentencing note that there were a number of
lower culpability C factors, most pertinently the explanation of becoming involved in the offending through
the pressure that was brought to bear on the appellant by reason of his indebtedness to the gang. This was
supported by independent evidence concerning his exploitation, including evidence from Children's Social
Services and an expert report from Dr Grace Robinson, who stated that the appellant's account, if believed,
had a number of features of modern slavery.

16. Given his background, it was submitted that the idea of his paying off the gangs by earning the money
was fanciful. Ms Mawer also prayed in aid his cognitive difficulties, suggestibility and decision-making
difficulties, as attested to in the psychological report of Dr Rajinder Dyal. That report indicated that he was
functioning within the low average to mildly impaired range in most areas of cognition and that the most
notable component of his overall intellectual functioning was what the doctor described as “his meagre
abilities in the domains of reasoning and making proper judgments”. Last but not least, the defence
sentencing note relied upon the appellant's youth and immaturity.

17. The judge also had the benefit of a balanced and carefully structured pre‑sentence report. This

records that the appellant told the probation officer that he committed the offences as he was “backed into
a corner” and was being forced to pay back money to a gang. He also stated that the offences were “spur
of the moment” and not planned. It was heavily reported within his probation records that he was in a
bondage debt to a gang in the Southwark area. His mother had also corroborated that he was in debt to a
group.

18. The author said that the current offences were an escalation of the appellant's previous offending, but
that she would have assessed them as part of a pattern of his involvement with a gang lifestyle. She took
into account Dr Robinson's report, and that the appellant's personal history and experiences made him
more susceptible to grooming and exploitation, but she also noted that the appellant appeared to lean quite
heavily on this and took minimal responsibility for his offending. She considered that, as was the case with
previous YOS officers, the appellant went through the motions of saying what he thought you wanted to
hear and disclosing as little meaningful information as possible.

19. The probation officer's assessment was that the appellant knew the risk and was “fully culpable for his
actions” which reflected, she said, a lack in consequential thinking, a lack of maturity, and triggers around
employment, finances, lifestyle and associates. She said that although he had a significant history of being
exploited by males from the Rockingham Estate, his previous probation officer had spoken of her concerns

regarding his life‑style/associates and that he may still seek out a negative peer group. He had voluntarily

travelled from the family's new address to South London more than once.


-----

20. There was also reference in the report to the appellant's lack of enthusiasm for further education and
to his pretending that he had got a job in a restaurant working night shifts so that he could get his bail
varied. He had admitted his lack of motivation and, although he said that he was in the process of applying

for Universal Credit, the author of the pre‑sentence report was sceptical about this. She was concerned

about his absence of any source of income other than to be dependent on friends and family, and identified
financial issues as a major concern. She said he had made little progress since his release in September
2022 to try to find a legitimate source of income and that he could be susceptible to becoming involved
once more in financially motivated offending.

21. The Crown did not seek a Newton hearing for the reasons set out in the prosecution note for sentence.
In the course of Ms Mawer's plea in mitigation, the judge indicated, more than once, that she was not going
to accept the basis of plea. Counsel, properly, indicated that in those circumstances, she considered that
there should be a _Newton hearing. The judge demurred, referring in particular to the contents of the_

pre‑sentence report. Ms Mawer said that her client had accepted that he had put up a front to disguise the

extent to which he had been acting at the behest of others, but nevertheless it was accepted in the

pre‑sentence report that he had been exploited by others, and the extent to which that had happened was

referred to by the probation officer.

22. Ms Mawer also referred to evidence that the appellant had taken seriously the criticisms in the

pre‑sentence report about his lack of commitment to finding a legitimate source of finance. There was

evidence before the Court that he had indeed applied for Universal Credit and had an appointment at the

Job Centre. As to the suggestion in the pre‑sentence report that he was not motivated to undertake further

education, there was evidence that he had a place to begin a diploma at a university in Scotland, but he
had been unable to take it up because he was on remand at the time. He had not lied in relation to
employment, because he had been given a job offer, evidence of which was produced, but taking it up
would have meant applying for a variation of his bail, which he had fought hard to achieve and did not wish
to affect by making such a further application. Since his release on bail, he had not got into any further
trouble. It was submitted that in putting on a front to the professionals with whom he engaged, by being
economical with the truth, he was covering up a deep sense of shame.

23. At the start of her sentencing remarks, the judge told the appellant that he would be given full credit for
his guilty plea. She also said that she took account of his basis of plea and the medical evidence, but that
her assessment would have to be whether those factors were directly linked to the offence under the
sentencing guidelines. That is to an extent a reflection of the approach that the prosecution had urged the
judge to adopt to the assessment of culpability, which was in accordance with the applicable sentencing
guidelines.

24. However, we consider that there is force in Ms Mawer's criticism of the judge's reasoning when
seeking to follow that approach, which is not altogether easy to understand and at times appears
completely contradictory. Indeed, it is unclear whether the judge was accepting the basis of plea (as she
should have done if she did not hold a Newton hearing) or whether she was rejecting it and, if so, on what
basis she was rejecting it, which would have been unfair to the appellant were she not to follow the ordered

procedure of putting him in the witness box and having him cross‑examined.

25. So far as the cognitive impairment was concerned, the judge said that she had carefully considered
the Sentencing Guidelines for Sentencing Offenders with Mental Disorders but that she had concluded that
the appellant's impairment had little or no relevance to his culpability for the two robberies. She indicated
that because of his youth, other disorders and the modern slavery decision, she would give a 25 per cent
discount from what she erroneously described as “the appropriate starting point” after the full discount for
his guilty plea.

26. Having accepted the prosecution categorisation of the offences, she rightly identified that because it
was his fourth conviction for carrying such a weapon, the offence of possession of the knife attracted a
minimum sentence of 6 months' custody. However, because it was part and parcel of the robberies, she


-----

said she would make the sentence concurrent. The judge explained that she was not prepared to impose a
suspended sentence because the appellant was identified as a risk of danger to the public and had a
history of poor compliance with court orders. These offences were committed whilst on bail and there was
no evidence that imprisonment would have any harmful effect upon him. However, she then went on to say
that the appropriate sentence would have been above 2 years' detention in any event.

27. Four grounds of appeal are advanced, although there is a degree of overlap between at least the first
two of them. First, it is contended that the judge erred in not sentencing the appellant in line with his basis
of plea, resulting in a sentence that was manifestly excessive. Secondly, it is contended that the judge
failed to identify and sentence on the basis of features of lesser culpability which led to an incorrect
categorisation of count 1. Thirdly, the judge erred in failing to exercise a discretion to pass a suspended
sentence, and fourthly, the judge was not an impartial Tribunal.

**_Discussion_**

28. Although it appears from the transcript of the submissions in mitigation that the judge felt under
pressure of time because only 45 minutes had been allowed for the sentencing hearing, it was unwise of
her to have interrupted defence counsel quite so much, and to have displayed so much overt impatience
with her submissions. However, it does appear that Ms Mawer did manage to make all the submissions
that she wished and therefore, in the light of our conclusions on grounds 1 and 2, there is no need for us to
say any more about ground 4.

29. The real issue is as to whether the judge was entitled to treat count 1 as a culpability A case in the
light of the basis of plea, at least without giving the appellant the opportunity to go into the witness box and

be cross‑examined on his account. It may well be that, if she had done so, she would have disbelieved his

account of being forced by the gang to go out and commit robberies, but having failed to do so, she was, in
our judgment, obliged to follow the basis of plea. Therefore she was obliged to accept that what he was
saying about his meeting with the gang on that particular morning was true.

30. The probation officer's assessment in the pre‑sentence report was that the appellant was “fully

culpable for his actions” though she said they were the result of poor thinking and poor judgment. However,
the report provided no justification for refusing to accept the basis of plea without holding a _Newton_
hearing. Culpability was a matter for the judge to assess.

31. The factual background to this offending was not seriously in dispute and the evidence that the
appellant was in debt to a gang, and that he was vulnerable to exploitation on account of previous
involvement with a gang or gangs, appears to have been accepted. The dispute was as to whether those
factors lowered his culpability for this offending. His past exploitation appears to have led to his
involvement in county lines drug dealing, which is a different form of criminality. The continued threat of
violence to the appellant and his family and the need to pay off the debt as fast as possible may have been
the motivation for the offending, and the gang may have suggested that committing a robbery would be the
swiftest means of reducing the debt, but, as the appellant accepted when interviewed by the probation
officer, these were spur of the moment offences which were his idea. Significantly, he deliberately chose to
use the knife as a threat, although, on the other hand, he never removed it from his waistband.

32. We agree with counsel that a balanced assessment of the appellant's culpability would have justified a
move down from the starting point in category 2A of 5 years, even if it would otherwise have been
appropriate to place the offence into that category for culpability in the first place. Standing back and
looking at the matter in the round, we consider that there is force in Ms Mawer's submission that, given that
the judge did not hold a Newton hearing, she was bound to accept his account of events. She could then
have dealt with the matter in one of two ways: she could either have regarded his culpability as reduced to
an extent by the degree of exploitation to which he was subjected by the gang to whom he was in debt,
and treated that as a category C factor, which would be balanced against the category A factor of the knife,
thereby putting the offending into category B; or she could have kept the offence within Category A but
treated this matter as significantly reducing his culpability, placing the offending at the lowest end of that
sentencing category.


-----

33. Either way, we consider that the appropriate sentence before taking into account other aggravating or
mitigating features would have been one of 4 years' imprisonment. That is the starting point in B2
(reflecting the first of the two approaches outlined above). It is also the lowest end of the range in category
A2.

34. The Guidelines on Sentencing Offenders with Mental Impairments or Disorders indicate that the
sentencing judge should make an initial assessment of culpability in accordance with any relevant offence
specific guideline, and _then consider whether culpability was reduced by reason of the impairment or_
disorder. In this case, the appellant understood the nature and consequence of his actions and was able
to make rational choices. Whilst he exhibited poor judgment, he was not suffering from a learning disability.

35. Although this was not an easy exercise, the judge was entitled, on the basis of the evidence, to
conclude that the appellant's cognitive impairment was not sufficiently linked to the commission of the
offences to reduce his culpability for them though, like his age and immaturity, it provided him with
significant personal mitigation. That meant that in principle the judge was right to consider those matters at
the second stage of the sentencing process, after placing the offending in the correct category within the
guidelines for harm and culpability.

36. Taking all those matters into consideration, we consider, as we have said, that the judge should have
begun with a sentence of 4 years, either by placing the offence into category B2 by dint of balancing the
culpability A and culpability C factors or by bringing the offence right down to the bottom of category A2.
As to aggravating factors, there were two robberies, albeit committed on the same occasion, the offences
were committed on bail and he was in breach of the prohibition on going to South London. Despite his
youth, the appellant had an unattractive criminal record including for possession of bladed articles.
However, the strong mitigating features apart from the **_modern slavery aspects have already been_**
identified, and they warranted a significant downward adjustment.

37. The judge fell further into error in giving credit for the guilty pleas before discounting for those
mitigating factors. She should have determined the notional sentence after trial before giving credit for the
guilty pleas.

38. In our judgment, balancing all the aggravating and mitigating features, including the appellant's
troubled history and his apparent willingness to change, and his lack of further offending after being
released on bail, and applying a discount of 25 per cent to specifically reflect his age, immaturity and
cognitive impairment, would justify a notional sentence after trial on count 1 of 3 years' custody, which
would be reduced to 2 years to reflect full credit for the guilty plea.

39. So far as the possession of the knife is concerned, in accordance with section 315(3) of the
Sentencing Act 2020, the judge was obliged to impose an appropriate custodial sentence of 6 months. This
applied unless the court was of the opinion there were particular circumstances which related to the
offence or the offender that would make it unjust to do so in all the circumstances.

40. Turning to Ground 3, Ms Mawer, in her attractive submissions to the court, urged the court that there
were factors that would make it unjust to apply an immediate custodial sentence on the basis of the knife
alone, especially if a sentencing judge would have suspended the sentence in relation to the robberies and
would otherwise be prohibited from doing so because of the mandatory provisions relating to the knife. She
pointed to the fact that the earlier offending involving bladed articles occurred at a time when the appellant
was under 18, and she drew our attention again to his very disruptive background and the culture within
which he was carrying a bladed article.

41. Since the knife was used in the commission of the first robbery, albeit only by being shown to the
victim, and this was his fourth offence involving a bladed article in the course of 4 years, it is quite difficult

to see on what basis it could be said that a 9‑month notional sentence after trial, reduced to 6 months for

his guilty plea, was unjust in the circumstances, let alone that it was manifestly excessive. Totality was
properly taken into account in making all the sentences concurrent.


-----

42. On the question of suspension, the sentences that the judge pronounced were not within the range to
enable them to be suspended. She identified, however, that three of the factors in the guidelines indicating
that it would be inappropriate to suspend the sentence were present, namely, a history of poor compliance
with court orders; a risk to the public through his repeated carrying of knives; and that appropriate
punishment could only be achieved by immediate custody. The pre-sentence report had assessed the
appellant's risk of violence to a partner as high and his risk of violence towards others as medium.

43. On the other hand, as Ms Mawer pointed out, he had already served a great deal of time on remand,
even if one discounts the period on remand which overlapped with another custodial sentence. There was
strong personal mitigation, and whilst there had been poor compliance with court orders in the past, and
whilst he had committed minor breaches of his bail (which did not lead to its revocation) the appellant had
not reoffended since his release on bail. This represented a significant step towards getting away from the
clutches of the gang. He had also written a letter to the court expressing remorse and showing that he had
taken positive steps to seek job opportunities or benefits. That indicated that there was a real prospect of
rehabilitation.

44. The author of the pre‑sentence report had indicated that the risk factors she identified could be

reduced if the appellant ceased contact with all negative peers and formed new pro-social associations,
found constructive use of his time through education or paid employment, and avoided going back to South
London. Unfortunately, one of the breaches of his bail conditions was that he _had gone back to South_

London. The author of the pre‑sentence report also felt that he would benefit from undertaking

rehabilitative activity sessions and completing the Thinking Skills Programme.

45. Whilst there was perhaps much more to be said in favour of a suspended sentence than the judge
gave credence to, on balance, given the propensity of this young man to go back out in public armed with a
knife, Ms Mawer's submission that it was appropriate to suspend the sentence was ambitious. Even though
the judge did not properly weigh the factors for and against suspension, she did not need to in the light of
the sentence that she passed. Having carried out that exercise carefully ourselves, we do not consider that
this was a case in which it could be said to be wrong in principle to decide that appropriate punishment
could only be achieved by immediate custody. That said, we wish to acknowledge the significant progress
that this young man has made since he was released on bail and we note that, as a result of the proper
application of the rules relating to time spent in custody and allowance of period on remand and on
electronic curfew, he should be released in the not too distant future.

46. On that subject, the judge said nothing in her sentencing remarks. It was drawn to our attention by the
Registrar that, although the period spent by the appellant on remand would be administratively dealt with,
and therefore the fact that it is not expressly referred to on the face of the custody order should not pose a
problem, the judge failed to direct that half the time spent on bail subject to a qualifying curfew condition
and an electronic monitoring condition was to count as time served as part of the appellant's sentence, as
she should have done, under section 325 of the Sentencing Act 2020. That period of course is subject to
any deductions made due to breach of the curfew, but we know of no such deductions.

47. Ms Mawer was very helpful this morning in providing the Court with the relevant periods. The time
spent on remand, she told us, other than that which overlapped with his period in custody for other matters,
was one of 229 days. Obviously, if that figure is incorrect, it can be corrected administratively. So far as the
period on electronic curfew is concerned, we were told that the total period was one of 251 days, and so
half that period, which we will round up to 126 days, should also be credited towards the sentence that is
currently being served, and we so direct. The Court will order an amendment of the record for the correct
periods to be recorded.

48. We therefore allow this appeal, quash the sentence passed on Count 1 and reduce the custodial term
on Count 1 to one of 2 years' detention. The period of 229 days spent on remand and 126 days in respect
of qualifying curfew will count towards the time to be served. The concurrent sentences passed on Counts
2 and 3 are otherwise unaffected. We record again our thanks to Ms Mawer for her very helpful
submissions, both in writing and orally this morning.


-----

Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part
thereof.

Lower Ground, 46 Chancery Lane, London WC2A 1JE

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

