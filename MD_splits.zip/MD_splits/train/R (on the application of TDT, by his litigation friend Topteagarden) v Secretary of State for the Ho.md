Department (Equality and Human Rights Commission interven....

# R (on the application of TDT, by his litigation friend Topteagarden) v
 Secretary of State for the Home Department (Equality and Human Rights
 Commission intervening) [2018] EWCA Civ 1395

Court of Appeal, Civil Division

Underhill, Floyd and Gloster LJJ

19 June 2018Judgment

**Mr Christopher Buttler (instructed by Simpson Millar LLP) for the Appellant**

**Mr Gwion Lewis (instructed by the Treasury Solicitor) for the Respondent**

**Ms Helen Mountfield QC (instructed by Equality and Human Rights Commission) for the Intervener)**

Hearing date: 21st and 22nd February 2018

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Lord Justice Underhill:**

**INTRODUCTION**

1. This appeal concerns the treatment by the Home Office of a young Vietnamese man who is said to
have been a victim of trafficking. The outline facts are as follows:

(1) The Appellant's detention. The Appellant was found by police with fifteen other young men or boys in
the back of a lorry in Kent on 8 September 2015: six of them were also Vietnamese. The view was taken
by the immigration authorities that he was over 18, and he was detained initially at the Dover Immigration
Removal Centre and then at Brook House in Sussex, with a view to his being returned to Vietnam as soon
as emergency travel documents could be obtained.

(2) Instruction of Maxwell Gillott. After a short period during which he was represented by a different firm
of solicitors, on 23 October the Appellant was seen at Brook House by Ms Silvia Nicolaou Garcia of
Maxwell Gillott (“MG” – at that time a trading style of Simpson Millar): I should say at this stage that her
work on his behalf appears to have shown exceptional ability and commitment. He told Ms Nicolaou
Garcia that his date of birth was 5 December 1999, which accorded with her own impression that he was
significantly under 18. His account also indicated to her that he was a victim of trafficking. She passed
that information to the Home Office case-worker the same day, and also wrote a short letter intimating an
intention to bring proceedings for judicial review in respect of the failure to treat him as a child and his
continued detention.

(3) Referral as a potential victim of trafficking. Ms Nicolaou Garcia arranged for the Appellant to be seen
by Ms Tara Topteagarden, the Trafficked Boys' Adviser at the Refugee Council. She saw him on 28
October and referred his case that day to the Competent Authority under the National Referral Mechanism
(“NRM”) for potential victims of trafficking, of which I give more details below.


-----

Department (Equality and Human Rights Commission interven....

(4) _The letter of 28 October 2015._ On 28 October MG wrote a pre-action protocol letter to the Home
Office, though it does not appear to have been sent till the following day. The letter challenged various
aspects of the Appellant's treatment, including the failure to conduct an age assessment and to recognise
him as a potential victim of trafficking. It gave a full account of the facts relied on as showing that he had
been trafficked from Vietnam. The letter asked that he be released from detention, but it said that he was
at serious risk of falling back into the hands of his traffickers unless his release was accompanied by a
package of arrangements which minimised the risk of that occurring. In particular, MG said that he should
be released into safe and secure accommodation, to be provided by the local authority, West Sussex
County Council (“the Council”), for assessment and services under sections 17 and 20 of the Children Act
1989; that a multi-agency meeting should be arranged; and that his case should be referred to the Kent
police and the Human Trafficking Team of the Metropolitan Police. The letter was also sent to the Kent
Police and to the Council. I give more details of its contents at paras. 51-54 below.

(5) The Home Office's non-response. The Council replied promptly to MG's letter, agreeing in principle to
the proposed arrangements for the Appellant's release, and in particular saying that it would supply safe
accommodation for him. However, there was no response from the Home Office, despite a chasing letter
sent the following day.

(6) Commencement of proceedings. On 6 November judicial review proceedings were issued in the High
Court, with Ms Topteagarden acting as the Appellant's litigation friend on the basis that he was under 18.

(7) _The Appellant's release._ Later that same day the Appellant was granted temporary admission, on
condition that he reside at an address in south London, which it is now known was in fact the address of a
Buddhist temple: I will come back to the circumstances of this in due course. MG learnt from the Appellant
early in the afternoon that his release was proposed and wrote immediately to the Home Office protesting
that he should not be released without the package of arrangements sought in the pre-action protocol
letter; but his release proceeded nevertheless.

(8) _The Appellant's disappearance._ The Appellant has not been seen by anyone, and has not been in
contact with MG, from the moment of his release. The police have made enquiries as to his whereabouts
but without success. It is his solicitors' belief that he has been re-trafficked.

2. The Appellant's claim has been continued by MG, taking their instructions from Ms Topteagarden.
There was some interlocutory activity in the immediate aftermath of his release, of which I need not give
the details. On 14 January 2016 May J gave permission to apply for judicial review on a single ground,
namely that the decision to release the Appellant without putting in place any measures to protect him
against being re-trafficked was a breach of his rights under article 4 of the European Convention of Human
Rights (“the ECHR”). That issue was heard before McGowan J on 20 and 28 April 2016: the Equality and
Human Rights Commission (“the Commission”) was granted leave to intervene. By a judgment handed
down on 29 July she dismissed the claim.

3. The Appellant appeals against that decision with the permission of Burnett LJ dated 28 April 2017. He
observed that the appeal “raises new and important points in the context of human trafficking, something of
growing practical and legal significance”.

4. The Appellant is represented by Mr Christopher Buttler, and the Secretary of State by Mr Gwion Lewis,
both of whom appeared before McGowan J. The Commission has again been given permission to
intervene and is represented by Ms Helen Mountfield QC, who also appeared below.

5. It is an unusual feature of the case that the proceedings are being continued on the Appellant's behalf in
circumstances where he has had no contact with his solicitors since the day that they were commenced
and where, whatever his age in 2015, he is on his own account now over 18. The Secretary of State has
taken no point about this, but shortly before the hearing the Court asked his counsel and solicitors
questions whether they believed that they continued to be properly instructed and also whether the
proceedings had any continuing purpose in view of the Appellant's disappearance. As to the former
question, Mr Buttler submitted that the instructions given by the Appellant himself at the time the


-----

Department (Equality and Human Rights Commission interven....

proceedings were initiated constituted sufficient authority, even if he was a minor at the time: he referred us
to the old case of Helps v Clayton (1864) 17 CB (NS) 553 and also the provisions of CPR 21.9. As to the
practical value of the proceedings, he submitted that it remained possible that the Appellant might yet reemerge, in which case the declaration being sought could form the basis of a claim for damages. In
circumstances where the Secretary of State had raised no objection, and where Burnett LJ had
emphasised the wider importance of the issues raised, we did not think it necessary to pursue the point
further.

**THE LAW**

6. The law relating to the treatment of victims, and potential victims, of trafficking derives partly from
European instruments and partly from domestic sources, though the former are to a greater or lesser
extent ultimately the basis for the latter. It will be convenient to consider them separately.

THE EUROPEAN INSTRUMENTS

7. There are three relevant European sources of law for our purposes. Two – the Anti-Trafficking
Convention and article 4 of the ECHR – derive from treaties entered into by the member states of the
Council of Europe; the third takes the form of an EU Directive. We are principally concerned with the
former two, which, as will be seen, closely inter-relate; but I will also briefly summarise the relevant parts of
the Directive.

(1)         The Anti-Trafficking Convention

8. In December 2005 the member states of the Council of Europe agreed the Convention on Action
against Trafficking in Human Beings. It drew to a considerable extent on the earlier “Palermo Protocol” to
the UN Convention against Transnational Organised Crime. “Trafficking” is defined in article 4 of the
Convention as follows:

“For the purposes of this Convention:

(a) 'Trafficking in human beings' shall mean the recruitment, transportation, transfer, harbouring or receipt
of persons, by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of
deception, of the abuse of power or of a position of vulnerability or of the giving or receiving of payments or
benefits to achieve the consent of a person having control over another person, for the purpose of
exploitation. Exploitation shall include, at a minimum, the exploitation of the prostitution of others or other
forms of sexual exploitation, forced labour or services, slavery or practices similar to slavery, servitude or
the removal of organs;

(b) The consent of a victim of 'trafficking in human beings' to the intended exploitation set forth in
subparagraph (a) of this article shall be irrelevant where any of the means set forth in subparagraph (a)
have been used;

(c) The recruitment, transportation, transfer, harbouring or receipt of a child for the purpose of exploitation
shall be considered 'trafficking in human beings' even if this does not involve any of the means set forth in
subparagraph (a) of this article;

(d) 'Child' shall mean any person under eighteen years of age;

(e)  'Victim' shall mean any natural person who is subject to trafficking in human beings as defined in this
article.

For present purposes we are only concerned with Chapter III of the Convention, which is headed
“Measures to Protect and Promote the Rights of Victims …”. The relevant provisions under that chapter
are as follows.

9. Article 10 is concerned with the identification of victims of trafficking. It reads:


-----

Department (Equality and Human Rights Commission interven....

“1. Each Party shall provide its competent authorities with persons who are trained and qualified in
preventing and combating trafficking in human beings, in identifying and helping victims, including children,
and shall ensure that the different authorities collaborate with each other as well as with relevant support
organisations, so that victims can be identified in a procedure duly taking into account the special situation
of women and child victims ….

2. Each Party shall adopt such legislative or other measures as may be necessary to identify victims as
appropriate in collaboration with other Parties and relevant support organisations. Each Party shall ensure
that, _if the competent authorities have reasonable grounds to believe that a person has been victim of_
_trafficking in human beings [emphasis supplied], that person shall not be removed from its territory until the_
identification process as victim of an offence provided for in Article 18 of this Convention1 has been
completed by the competent authorities and shall likewise ensure that that person receives the assistance
provided for in Article 12, paragraphs 1 and 2.

3. When the age of the victim is uncertain and there are reasons to believe that the victim is a child, he or
she shall be presumed to be a child and shall be accorded special protection measures pending
verification of his/her age.

4. …”

I have emphasised the phrase “if the competent authorities have reasonable grounds to believe that a
person has been victim of trafficking in human beings” in paragraph 2 because it is adopted in the domestic
arrangements to which I refer below.

10. Article 12 is concerned with assistance to victims. It reads, so far as material:

“1. Each Party shall adopt such legislative or other measures as may be necessary to assist victims in their
physical, psychological and social recovery. Such assistance shall include at least:

(a)-(f) …

2. Each Party shall take due account of the victim's safety and protection needs.”

I have not set out the various forms of assistance specified under paragraph 1 since no issue in relation to
them arises in this case. For the same reason I need not refer to the extended discussion of the purpose
of article 12 and its detailed requirements to which Mr Buttler referred us in paras. 146-171 of the
Explanatory Report to the Convention, interesting and instructive though they are.

11. Article 13 provides that where there are “reasonable grounds to believe that the person concerned is a
victim [of trafficking]” they should be provided with a “recovery and reflection period” of at least 30 days
during which they may not be removed and are entitled to assistance under paragraphs 1 and 2 of article
12.

12. The Convention does not of course have the force of law domestically; but, as will appear, it is both the
source, in practice, of certain obligations arising under the ECHR and the basis of the domestic regime.

(2)         Article 4 of the ECHR

13. Article 4 of the ECHR provides (so far as material for present purposes):

“1. No one shall be held in slavery or servitude.

2. No one shall be required to perform forced or compulsory labour.

3. …”

14. Although that language is very general, the European Court of Human Rights has held that it imposes
on member states certain positive obligations as regards trafficking. The leading case is Rantsev v Cyprus
_and Russia (2010) 51 EHRR 1. In its judgment in that case the Court said, at para. 282:_


-----

Department (Equality and Human Rights Commission interven....

“There can be no doubt that trafficking threatens the human dignity and fundamental freedoms of its
victims and cannot be considered compatible with a democratic society and the values expounded in the
Convention. In view of its obligation to interpret the Convention in light of present-day conditions, the Court
considers it unnecessary to identify whether the treatment about which the applicant complains constitutes
'slavery', 'servitude' or 'forced and compulsory labour'. Instead, the Court concludes that trafficking itself,
within the meaning of Article 3(a) of the Palermo Protocol and Article 4(a) of the Anti-Trafficking
Convention, falls within the scope of Article 4 of the Convention.”

One consequence of that conclusion is of course that any obligations in relation to trafficking arising under
article 4 are binding on public authorities as a matter of domestic law under section 6 of the Human Rights
Act 1998.

15. At paras. 282-289 of its judgment the Court goes on to expound the obligations imposed by article 4 as
it relates to trafficking. It begins, at para. 283, by pointing out that article 4, together with articles 2 and 3,
“enshrines one of the basic values of the democratic societies making up the Council of Europe” and that,
unlike most of the other articles, it is unqualified. At paras. 284-285 it says that although article 4 imposes
an obligation to penalise those guilty of trafficking, that is only one aspect of member states' obligations,
and it goes on, at paras. 286-288, to consider the extent of their other positive obligations. These read (so
far as material):

“286. As with Articles 2 and 3 of the Convention, Article 4 may, in certain circumstances, require a State to
take operational measures to protect victims, or potential victims, of trafficking (see, _mutatis mutandis,_
_Osman, [(2000) 29 EHRR 245] § 115; and Mahmut Kaya v. Turkey, no. 22535/93, § 115, ECHR 2000-III)._
In order for a positive obligation to take operational measures to arise in the circumstances of a particular
case, it must be demonstrated that _the State authorities were aware, or ought to have been aware, of_
_circumstances giving rise to a credible suspicion that an identified individual had been, or was at real and_
_immediate risk of being, trafficked or exploited [emphasis supplied] within the meaning of Article 3(a) of the_
Palermo Protocol and Article 4(a) of the Anti-Trafficking Convention. In the case of an answer in the
affirmative, there will be a violation of Article 4 of the Convention where the authorities fail to take
appropriate measures within the scope of their powers to remove the individual from that situation or risk
(see, _mutatis mutandis,_ _Osman, cited above, §§116 to 117; and_ _Mahmut Kaya, cited above, §§ 115 to_
116).

287. Bearing in mind the difficulties involved in policing modern societies and the operational choices which
must be made in terms of priorities and resources, the obligation to take operational measures must,
however, be interpreted in a way which does not impose an impossible or disproportionate burden on the
authorities … . It is relevant to the consideration of the proportionality of any positive obligation arising in
the present case that the Palermo Protocol, signed by both Cyprus and the Russian Federation in 2000,
requires States to endeavour to provide for the physical safety of victims of trafficking while in their
territories and to establish comprehensive policies and programmes to prevent and combat trafficking … .
States are also required to provide relevant training for law enforcement and immigration officials … .

288. Like Articles 2 and 3, Article 4 also entails a procedural obligation to investigate situations of potential
trafficking. The requirement to investigate does not depend on a complaint from the victim or next-of-kin:
once the matter has come to the attention of the authorities they must act of their own motion (see, mutatis
_mutandis, Paul and Audrey Edwards v. the United Kingdom, no. 46477/99, § 69, ECHR 2002-II… .”_

I have italicised the words “credible suspicion that an identified individual had been, or was at real or
immediate risk of being trafficked” in para. 286 because their meaning and effect are central to the issue on
this appeal.

16. Those principles have been re-stated and applied in a number of subsequent Strasbourg cases. We
were referred in particular to J v Austria (58216/12) and Chowdhury v Greece (21884/15). In the latter the
Court re-emphasised the role of the Anti-Trafficking Convention in defining the scope of member states'
obligations under article 4. It said, at para. 104:


-----

Department (Equality and Human Rights Commission interven....

“… [T]he member States' positive obligations under Article 4 of the Convention must be construed in the
light of the Council of Europe's Anti-Trafficking Convention and be seen as requiring, in addition to
prevention, victim protection and investigation, together with the characterisation as a criminal offence and
effective prosecution of any act aimed at maintaining a person in such a situation (see Siliadin … § 112).
The Court is guided by that Convention and the manner in which it has been interpreted by [the Council of
Europe's Group of Experts on Action against Trafficking in Human Beings].”

It also re-stated, with a slightly different structure, what it had said in Rantsev about the positive obligations
imposed by article 4. At paras. 86-89 it said:

“86. The Court refers to its relevant case-law on the general principles governing the application of Article 4
in the specific context of human trafficking (see, in particular, Rantsev … §§ 283-89). Having regard to the
importance of Article 4 within the Convention, its scope cannot be confined merely to the direct actions of
the State authorities. It follows from this provision that States have positive obligations, in particular, to
prevent human trafficking and protect the victims thereof and to adopt criminal-law provisions which

penalise such practices (see Siliadin, [73316/01, ECHR 2005‑VII], § 89).

87. Firstly, in order to combat this phenomenon, member States are required to adopt a comprehensive
approach and to put in place, in addition to the measures aimed at punishing the traffickers, measures to
prevent trafficking and to protect the victims (see Rantsev … § 285). It transpires from this case-law that
States must, firstly, assume responsibility for putting in place a legislative and administrative framework
providing real and effective protection of the rights of victims of human trafficking. In addition, the States'
domestic immigration law must respond to concerns regarding the incitement or aiding and abetting of
human trafficking or tolerance towards it (see Rantsev … § 287).

88. Secondly, in certain circumstances, the State will be under an obligation to take operational measures
to protect actual or potential victims of treatment contrary to Article 4. As with Articles 2 and 3 of the
Convention, Article 4 may, in certain circumstances, require a State to take such measures (see _L.E. v._
_Greece, no. 71545/12, § 66, 21 January 2016). In order for a positive obligation to take operational_
measures to arise in the circumstances of a particular case, it must be demonstrated that the State
authorities were aware, or ought to have been aware, of circumstances giving rise to a credible suspicion
that an identified individual had been, or was at real and immediate risk of being, trafficked or exploited
within the meaning of Article 3 (a) of the Palermo Protocol and Article 4 (a) of the Anti-Trafficking
Convention. In the case of an answer in the affirmative, there will be a violation of Article 4 of the
Convention where the authorities fail to take appropriate measures within the scope of their powers to
remove the individual from that situation or risk (ibid.).

89. Thirdly, Article 4 imposes a procedural obligation to investigate potential trafficking situations. The
authorities must act of their own motion once the matter has come to their attention; the obligation to
investigate will not depend on a formal complaint by the victim or close relative … .”

17. As is most clearly stated in that passage, the duties which the Court has held to be imposed by article
4 as regards human trafficking can be classified under three headings:

(a) a general duty to implement measures to combat trafficking – “the systems duty”;

(b) a duty to take steps to protect individual victims of trafficking – “the protection duty” (sometimes called
“the operational duty”);

(c) a duty to investigate situations of potential trafficking – “the investigation duty” (sometimes called “the
procedural duty”).

18. The present case is concerned with the protection duty. That duty is triggered, as we have seen from
para. 286 of _Rantsev, where it is “demonstrated that the State authorities were aware, or ought to have_
been aware, of circumstances giving rise to a credible suspicion that an identified individual had been, or
was at real and immediate risk of being, trafficked”. I will refer to this as “the credible suspicion threshold”.


-----

Department (Equality and Human Rights Commission interven....

The EU Directive

19. On 5 April 2011 the European Parliament and Council promulgated Directive 2011/36/EU, “on
Preventing and Combating Trafficking in Human Beings and Protecting its Victims”. Member states were
required to transpose its provisions into national law by no later than 6 April 2013. Although it is formally
relied on by the Appellant in these proceedings, the focus of the submissions before us has been on article
4 of the ECHR. In those circumstances, I need to refer only to two of its articles.

20. Article 11 of the Directive is headed “Assistance and Support for Victims of Trafficking in Human
Beings” and reads, so far as material, as follows:

“1 …

2. Member States shall take the necessary measures to ensure that a person is provided with assistance
and support as soon as the competent authorities have a reasonable-grounds indication for believing that
the person might have been subjected to any of the offences referred to in Articles 2 and 3.

3-4 …

5. The assistance and support measures referred to in paragraphs 1 and 2 shall be provided on a
consensual and informed basis, and shall include at least standards of living capable of ensuring victims'
subsistence through measures such as the provision of appropriate and safe accommodation and material
assistance, as well as necessary medical treatment including psychological assistance, counselling and
information, and translation and interpretation services where appropriate.

6-7. …”

21. Article 13 is headed “General Provisions on Assistance, Support and Protection Measures for Child
Victims of Trafficking in Human Beings”. It reads:

“1. Child victims of trafficking in human beings shall be provided with assistance, support and protection. In
the application of this Directive the child's best interests shall be a primary consideration.

2. Member States shall ensure that, where the age of a person subject to trafficking in human beings is
uncertain and there are reasons to believe that the person is a child, that person is presumed to be a child
in order to receive immediate access to assistance, support and protection in accordance with Articles 14
and 15.”

22. Articles 14 and 15 go on to make various specific provisions about child victims, but I need not set
them out here.

THE DOMESTIC REGIME

The NRM

23. The Anti-Trafficking Convention was ratified by the UK in December 2008, with a view to its
implementation with effect from 1 April 2009. It was not at first sought to be implemented by legislation.
However, the Secretary of State did establish by administrative measures a National Referral Mechanism
(“NRM”) for identifying and supporting victims of trafficking. This involves three key steps:

(1) If a potential victim of trafficking is identified by a “first responder” the case must be referred to the UK
Human Trafficking Centre (“UKHTC”), which is a unit within the National Crime Agency. First responders
comprise a number of designated governmental and non-governmental organisations, including the Home
Office itself and the Refugee Council (for whom Ms Topteagarden worked).

(2) A designated “Competent Authority” – either the UKHTC itself or a unit within the Home Office – will, if
possible within five days, determine whether there are reasonable grounds to believe that the person
referred is a victim of trafficking. If such a determination is made they will be given a 45-day recovery and
reflection period (longer than required by the Convention), with associated support.


-----

Department (Equality and Human Rights Commission interven....

(3) After the expiry of the 45 days, the Competent Authority will make a final decision as to whether there
are, on the balance of probabilities, sufficient grounds to decide that he or she is a victim of trafficking – a
so-called “conclusive grounds decision”. There are various possible consequences of such a decision, but
I need not rehearse them here.

[The Modern Slavery Act 2015](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)

[24. Parts of the Modern Slavery Act 2015 came into force on 31 July 2015. The definition of “modern](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
**_slavery” refers to article 4 of the ECHR and thus embraces trafficking; but its substantive provisions are_**
not material for our purposes.

Guidance

25. The Home Office has published guidance on the operation of the NRM to its front-line staff and to
Competent Authorities. New versions were issued effective from 31 July 2015 pursuant to section 49 of
the 2015 Act and to coincide with its (partial) coming into force. Those – version 2 in both cases – are the
relevant versions in our case, though they have since been replaced. Although they do not constitute
legislation, any unjustified departure from their terms will be potentially challengeable by way of judicial
review in the usual way.

26. I take first the Frontline Staff Guidance. This is a very full and detailed document, whose detailed
provisions may well be of central importance in other cases; but I confine myself here only to those points
that are directly material for our purposes. Section 5 summarises “the key steps for frontline staff in the

[NRM] process”. Step 1 is “Identify a potential victim of **_modern slavery”; and section 9 states_**
unequivocally that “it is the responsibility of frontline staff in the Home Office to identify if a person is a
potential victim of modern slavery”. Step 2 concerns the provision of emergency medical treatment where
appropriate. Step 3 is “Refer a potential victim of **_modern slavery to NRM [that is, to the Competent_**
Authority]”. Both section 5 and section 9 cross-refer to section 7, which is headed “Indicators of Modern
**_Slavery – How to Spot a Potential Victim”. A number of indicators are listed, some of them being_**
developed in more detail in the following sections. I note in particular that section 7.3 identifies a number
of “psychological indicators”. Section 13 gives more detail about the NRM process generally.

27. I turn to the Competent Authority Guidance. For our purposes I need only be concerned with the
discussion of the “reasonable grounds decision” taken following a referral by a first responder. Section 5
summarises the effect of a “positive reasonable grounds decision” as being that the Authority

“suspects but cannot prove this person is a potential victim of human trafficking on any UK referral.”

28. That is elaborated in section 12. Sub-section 12.3.1 is headed “The Reasonable Grounds Test”. It
begins:

“This is designed to determine whether someone is a potential victim. When the Competent Authority
receives a referral, they must decide whether on the information available it is reasonable to believe that a
person is a victim of the crime of … modern slavery … .2 The test the Competent Authority must apply is:
whether the statement 'I suspect but cannot prove' the person is a victim of modern slavery …:

is true

whether a reasonable person having regard to the information in the mind of the decision maker, would
think there are reasonable grounds to believe the individual had been a victim of human trafficking or
**_modern slavery.”_**

That is oddly worded, in various ways, but we were not addressed on the detail. The only point that
matters for our purposes is that the test is characterised as one of suspicion falling short of proof. Later in
the same sub-section the Guidance uses the term “reasonable suspicion”.

29. Sub-sections 12.3-12.6 go on to discuss the circumstances in which the Competent Authority may
need to make further enquiries. It is recognised that the information provided by the first responder may be
sufficient to make a positive reasonable grounds decision; but there is also provision for it to make further


-----

Department (Equality and Human Rights Commission interven....

enquiries where that information does not appear to justify such a decision, notwithstanding “the limited 5
day timescale”. In that connection the Authority is enjoined to bear in mind “the relatively low threshold of
the reasonable grounds test” (sub-section 12.6).

OVERVIEW AND SUMMARY

30. The interplay of the various sources of law identified above is not entirely straightforward. It was to
some extent considered by this Court in Secretary of State for the Home Department v Hoang (Anh Minh)

_[[2016] EWCA Civ 565, [2017] INLR 267. In that case the Competent Authority had made a negative](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5K28-G3W1-F0JY-C53G-00000-00&context=1519360)_
reasonable grounds decision. The Judge at first instance (Ms Mountfield, as it happens) found that it had
failed to follow the Guidance in various respects and quashed the decision (see _[2015] EWHC 1725_
_(Admin)). It was common ground before the Judge that it followed from that decision that there had also_
been a breach of the investigation, or procedural, duty under article 4. This Court held that that was wrong.
As Burnett LJ, who delivered the only substantial judgment, put it at para. 35:

“The application of the Guidance is not the mechanism by which the United Kingdom satisfies the
procedural obligation under article 4.”

31. Although it was concerned with the investigation/procedural duty, rather than the protection duty with
which we are concerned in the present case, _Hoang is an important reminder that, despite their inter-_
relationship, the obligations under article 4, as elaborated in _Rantsev, and the obligations under the_
Guidance (reflecting the Anti-Trafficking Convention and the Directive) need to be analysed separately:
there is no automatic read-across. Burnett LJ also went on to make two more general points about the
NRM process which are directly in point in this case:

(1) At para. 36 he drew a distinction between the threshold for the requirement on frontline staff to make a
referral to the Competent Authority under the Guidance and the threshold that triggered the investigation
duty under article 4. The former he described as “very low … – in reality, any suspicion or any claim”,
whereas the latter required “'credible suspicion' that a person has been trafficked”3.

(2) He held that the threshold set by the requirements of “reasonable grounds” in the Convention and the
Guidance and “credible suspicion” were substantially the same. He said, at paras. 36-37:

“36. … [Counsel for the claimant] submits that 'credible suspicion' is not the same as 'reasonable grounds
to believe'. To my mind, in using the term 'credible suspicion', just as 'potential trafficking' or indeed
'arguable claim' in article 3 cases, the Strasbourg Court is drawing a distinction between mere allegations
and those with sufficient foundation to call for an investigation. The procedural obligation does not arise
simply on the making of an allegation …

37. The decision of the Competent Authority in this case was for all practical purposes applying a
threshold the same as 'credible suspicion' or 'arguable claim'. …”

32. Against that background, it is possible to summarise the obligations to which Home Office staff are
potentially subject, so far as concerns the protection of potential victims of trafficking, as follows.

33. I start with the obligations arising from the Guidance, which is intended to satisfy the UK's obligations
under the Anti-Trafficking Convention (and also the Directive). These arise at two stages:

(1) There is an obligation under the Guidance on front-line staff who encounter cases where there are
indicators of trafficking to refer such cases to the Competent Authority. The threshold for this obligation is
very low: see the observation by Burnett LJ in Hoang quoted at para. 31 (1) above. (This obligation does
not explicitly arise from the Convention. It might, however, be thought to be necessarily implicit, since the
UK has given the responsibility for making the necessary decisions to an authority which is not on the front
line and it must accordingly be under an obligation to ensure that all potential cases are brought to the
attention of that authority.)


-----

Department (Equality and Human Rights Commission interven....

(2) There is an obligation on the Competent Authority to make a positive reasonable grounds decision
where there is a reasonable suspicion that the person referred is a victim of trafficking. This threshold is
higher than that applicable at the first stage but, as the Guidance itself recognises, it is still “relatively low”.

34. I should at this stage note a point about the use of the phrase “potential victim of trafficking”. This can
be found being used (and I will use it) to refer not only to someone who satisfies the “relatively” low
threshold applicable at the stage of the reasonable grounds decision but also to someone at the earlier
stage who has satisfied the “very” low threshold for referral by a first responder (what might be called “a
potential potential victim of trafficking”). It is necessary to be alert to this possible ambiguity, but it should
not usually give rise to any problem.

35. I turn to the protection duty under article 4 of the ECHR, as articulated in Rantsev. As held by Burnett
LJ in _Hoang (see para. 31 (2) above), the “reasonable grounds” test to be applied by the Competent_
Authority is substantially equivalent to the “credible suspicion” threshold under article 4. But it does not
follow that that threshold may not, on the facts of a particular case, have been crossed before the case
comes before the Competent Authority – that is, at the earlier stage when a member of the Home Office
front-line staff decides to refer. Indeed that will be so in most cases where a positive reasonable grounds
decision is subsequently made: if the case crossed the credible suspicion threshold when considered by
the Competent Authority it will also have done so at the point when it was referred4. Accordingly the
Secretary of State will have come under the protection duty under article 4 some time before the
Competent Authority makes its decision. It should be noted that the designation of the Competent
Authority under the UK system – whether it be the UKHTC or part of the Home Office – is a purely
domestic construct: the Court in _Rantsev and_ _Chowdhury refers simply to “the State authorities”, which_
would embrace front-line staff as much as the authorities further up the chain of referral.

36. At first sight the point made in the last paragraph might be thought to create a mismatch between the
NRM process and the UK's obligations under article 4 which will give rise to difficulties in practice. But I do
not think that that is so. The obligations in question are purely protective. As long as reasonable steps are
taken to protect the individual pending the decision of the Competent Authority there is no need to take any
of the other steps required by the Convention, such as the provision of a period of recovery and reflection,
any sooner than the Guidance provides for.

THE CREDIBLE SUSPICION THRESHOLD

37. There was some discussion before us of the requirements of the credible suspicion threshold. Not all
the points raised were directly relevant to the issue in the present case, but in view of the basis on which
Burnett LJ gave leave I think it right to consider them.

“Credible Suspicion”

38. The Strasbourg phrase “credible suspicion” has a slightly odd ring, but the broad sense is clear
enough. It corresponds, as I have said, to the concept of “reasonable grounds for suspicion” found in the
Convention and the Guidance and represents a relatively low threshold. As Burnett LJ observed in para.
35 of his judgment in Hoang, quoted above, the Court “is drawing a distinction between mere allegations
and those with sufficient foundation to call for an investigation” – or, here, to call for the taking of protective
measures. Mr Buttler noted that in _CN v United Kingdom (2013) 56 EHRR 24 the Strasbourg court_
regarded the credible suspicion threshold as having been crossed in a case where the putative victim's
account of having been trafficked was “not inherently implausible” (see at para. 72 of the judgment).

Past History and Future Risk

39. If the formulation in Rantsev is read literally the protection duty arises where there is credible suspicion
of either of two separate things – (a) that an individual has been trafficked or (b) that he or she was at real
and immediate risk of being trafficked. There was an issue before us as to whether those two elements
are indeed true alternatives, so that the protection duty arises not only in the case of individuals for whom
there is a (real and immediate) risk of their being trafficked in the future but also in the case of individuals


-----

Department (Equality and Human Rights Commission interven....

who have been trafficked in the past. Mr Lewis contended that the Court's language should not be
construed too literally. The obligation in question is, necessarily, to protect potential victims against future
(re-)trafficking, and the Court can only have intended it to arise in respect of past victims to the extent that
their history indicates that they are at risk of being (re-)trafficked in future. It made no sense to treat the
obligation as arising even in cases where the victim had been trafficked in the distant past and there was
no reason to suppose any continuing risk. In response, Mr Buttler and Ms Mountfield submitted that the
Court will have adopted its formulation of an obligation of this kind with care and that it should be taken to
have meant precisely what it said. There are good reasons for treating the criteria as true alternatives. It is
prudent to regard any past victim of trafficking as a potential victim of re-trafficking, and it is important for
the duty to be engaged so that an assessment of that risk can be made: if on such an assessment a
reasonable view is taken that there is no longer any risk requiring protective measures, the duty would be
readily discharged, but that was not a reason for finding that it did not arise in the first place. Mr Buttler
noted that in J v Austria the Court proceeded on the basis that the duty arose in the context of a group of
victims who had escaped from their traffickers nine months previously (see paras. 110-111 of its
judgment).

40. I am not sure how important this issue really is in practice. In most cases encountered by the
authorities both criteria will be satisfied. Trafficking is a process and not a single event. A victim of
trafficking who is encountered in the back of a lorry or found working at a cannabis farm or a nail bar will
not only have been trafficked in the preceding period but will also be at real and immediate risk of the
trafficking continuing; even if a victim has escaped, or been removed, from the immediate control of their
traffickers, he or she will very commonly still be sufficiently under their influence to be at real and
immediate risk of re-trafficking if not afforded proper support and protection.

41. I accept, however, that the issue would in principle arise in a case, however untypical, where a person
has been trafficked in the past but there is no credible suspicion that they are any longer at real and
immediate risk of being re-trafficked: perhaps, for example, the traffickers are in custody and it is clear that
no-one else is involved. I understand the argument that in such a case there should still be an obligation at
least to consider whether any protective measures are needed: even if the risk is no longer “real and
immediate” a past victim of trafficking is inherently more likely to remain at some degree of risk. But I do
not think that it is likely that the Court in Rantsev was thinking along those lines. “Real and immediate risk”
is a well-established criterion in the Strasbourg jurisprudence, denoting the limit of the circumstances in
which a general right of this character might impose positive “operational” obligations on a state, and I
doubt if the Court intended to depart from it. I think it more likely that, as Mr Lewis submitted, it identified
the (suspected) fact that a person has been trafficked as a distinct element only because having such a
history is the paradigm case of someone who is likely to be at real and immediate risk and so require
protection: as I say above, the two elements will in practice generally coincide. It is important not to read
the words of a Strasbourg judgment with the same rigour as a statute. However, the distinction in practice
between this position and that espoused by Mr Buttler and Ms Mountfield may not be very great. In order
to decide whether a past victim is indeed no longer at real and immediate risk of being (re-)trafficked the
authorities will in any event have to conduct a careful assessment of the kind for which they contended.

42. In order to avoid any possible confusion, I should emphasise that I am dealing only with the protection
duty. Ms Mountfield correctly pointed out that there will be other obligations, whether arising under article 4
or otherwise, which are triggered by a past history of trafficking alone – i.e. in the absence of any real and
immediate future risk to the victims. For example, victims may require support and treatment for the
consequences of past ill-treatment; and the state is required where possible to bring criminal proceedings
against traffickers. But obligations of that kind are outside the scope of the issues raised in these
proceedings.

43. I should mention a couple of verbal points arising out of the twofold way that the Court formulates the
threshold:

(1) While it is entirely apt to speak of “suspecting” that a person has been trafficked, which is an existing
state of affairs it is arguably rather less apt to speak of “suspecting” a risk that something will happen in


-----

Department (Equality and Human Rights Commission interven....

the future. But there is no difficulty of substance. The language in both cases reflects the fact that what is
required is a judgement, on reasonable grounds, about something which is not at the stage in question
capable of being known.

(2) It is both convenient and common to use the phrase (potential) “victim of trafficking” to refer
compendiously to persons to whom the protection duty under article 4 is owed, even though strictly the
phrase connotes only people who are already victims of trafficking and not those who are at real and
immediate risk of being trafficked but have not been so far. But cases of the latter kind are likely to be very
rare in practice; and the shorthand is sufficiently accurate for working purposes.

“Real and Immediate Risk”

44. There has been no discussion in the Strasbourg or domestic case-law of what the term “real and
immediate risk” connotes in the context of article 4. However, the effect of the same phrase in the context
of article 2 was considered by the Supreme Court in Rabone v Pennine Care NHS Trust _[2012] UKSC 2,_

[2012] 2 AC 72. The Strasbourg case-law had in that context also elaborated out of the very general
language of the article an operational duty on the relevant authorities to take appropriate steps to protect
an individual whose life is at “real and immediate risk”: see para. 116 of the judgment of the Court in
_Osman v United Kingdom (1998) 29 EHRR 245. The issue in Rabone was whether that operational duty_
arose in the case of a psychiatric in-patient who had committed suicide while on a permitted home visit.
The leading judgment is that of Lord Dyson. He noted at para. 35 (p. 90 F-G) the finding of the trial judge,
based on the evidence of the Trust's expert witness (Dr Caplan), that the risk of the patient attempting
suicide was (at different times during his visit) between 5% and 20%. He then said, at paras. 37-39 (p. 91
B-F).

“37. I accept that it is more difficult to establish a breach of the operational duty than mere negligence. This
is not least because, in order to prove negligence, it is sufficient to show that the risk of damage was
reasonably foreseeable; it is not necessary to show that the risk was real and immediate. But to say that
the test is a high one or more stringent than the test for negligence does not shed light on the meaning of
'real and immediate' or on the question whether there was a real and immediate risk on the facts of any
particular case.

38. It seems to me that the courts below were clearly right to say that the risk of Melanie's suicide was 'real'
in this case. On the evidence of Dr Caplan, it was a substantial or significant risk and not a remote or
fanciful one. Dr Caplan and Dr Britto (the claimants' expert psychiatrist) agreed that all ordinarily competent
and responsible psychiatrists would have regarded Melanie as being in need of protection against the risk
of suicide. The risk was real enough for them to be of that opinion. I do not accept [counsel for the Trust's]
submission that there had to be a 'likelihood or fairly high degree of risk'. I have seen no support for this
test in the Strasbourg jurisprudence.

39. As for whether the risk was 'immediate', [counsel for the Trust] submits that the Court of Appeal failed
to take into account the fact that an 'immediate' risk must be imminent. She derives the word 'imminent'
from what Lord Hope said in Van Colle v Chief Constable of the Hertfordshire Police [2009] 1 AC 225, para
66. In the case of _In re Officer L_ [2007] 2007] 1 WLR 2135, para 20, Lord Carswell stated that an apt
summary of the meaning of an 'immediate' risk is one that is 'present and continuing'. In my view, one must
guard against the dangers of using other words to explain the meaning of an ordinary word like
'immediate'. But I think that the phrase 'present and continuing' captures the essence of its meaning. The
idea is to focus on a risk which is present at the time of the alleged breach of duty and not a risk that will
arise at some time in the future.”

45. Mr Buttler submitted that that approach was equally applicable to a case under article 4. I broadly
agree. In particular, I agree that in the context of article 4 also a “real” risk does not connote a likelihood,
or “fairly high degree” of probability; and that “immediate” does not necessarily mean “imminent”. The
former point is also clearly made by Sedley LJ in Batayav v Secretary of State for the Home Department

_[2003] EWCA Civ 1489: see paras. 37 and 38 of his judgment._


-----

Department (Equality and Human Rights Commission interven....

46. However, the precise application of the “real and immediate risk” test is inevitably sensitive to the
particular factual situation under consideration, and I do not think Rabone is useful beyond establishing the
points of principle referred to above. In particular, the kind of statistical quantification of risk that was
available on the evidence in that case will not be possible in many kinds of case and is in my view not
necessary. As appears from para. 38 of Lord Dyson's judgment, the essential question is simply whether
the material available shows a sufficient risk – in this case of re-trafficking – for protective measures to be
needed.

Generic or Specific Evidence

47. Mr Buttler submitted that membership of a class of person which is frequently trafficked is sufficient by
itself to give rise to a credible suspicion for the purpose of the protection duty under article 4. In response
Mr Lewis initially contended that there must in every case be evidence peculiar to the individual in
question, over and above membership of the vulnerable class. However, in the course of his oral
submissions he rowed back from that absolute position. In truth I do not believe that this is an issue on
which useful generalisation is possible. In principle the ultimate question in any given case must be
whether there are reasonable grounds for suspecting that the particular individual in question is a victim of
trafficking. However, one of those grounds may be – indeed is very likely to be – that he or she falls into a
class known to be peculiarly vulnerable to being trafficked. The weight to be given to generic evidence of
that kind in any particular case will depend both on the strength of the association alleged and the reliability
of the evidence supporting it. If there were clear statistical evidence that 95% of all young Ruritanians
entering the UK illegally were victims of trafficking, I cannot see why that by itself would not justify (at least)
a credible suspicion that any particular young Ruritanian illegal entrant had been trafficked. Conversely, if
there was indeed a known phenomenon of young Ruritanians being trafficked but they were only a small
proportion of the numbers of young Ruritanians entering the country such a suspicion would not be justified
without other circumstances being present. But in the real world most cases will fall between those two
extremes: the relevant evidence will be a mixture of generic and specific, and the question will be what its
overall effect is when viewed as a whole.

**THE APPELLANT'S CASE**

48. The essence of the case made on the Appellant's behalf is that as at the point of his release on 6
November 2015 the Secretary of State was, or should have been, aware of material which gave rise to a
credible suspicion that he had been trafficked, which in the circumstances of his case meant that he was
also at real and immediate risk of being (re-)trafficked if released; that she was thus, in accordance with
para. 286 of the judgment of the Court in _Rantsev, under a positive obligation under article 4 to take_
operational steps to protect him from falling back into the hands of his traffickers; that that duty could have
been discharged by her taking the steps proposed in the letter of 28 October; and that her decision to
release the Appellant without taking those steps was therefore a breach of that duty.

49. The crucial element in that case is the first; and indeed Mr Lewis accepted before us that if the
Secretary of State should indeed reasonably have suspected that the Appellant was a victim of trafficking
and at real and immediate risk of being re-trafficked if released, the operational duty in Rantsev arose and
she was in breach of it.

50. The material relied on by the Appellant in support of his case can be categorised under three heads
(though there is a degree of overlap) – (1) the representations made to the Home Office prior to his
release; (2) evidence adduced before the Judge as to the knowledge that the Secretary of State should
have had about the trafficking, and re-trafficking, of young Vietnamese males generally; and (3) evidence
about what was known about the other young Vietnamese detained at the same time as he was. I take
those elements in turn.

(1)         THE CONTEMPORARY REPRESENTATIONS


-----

Department (Equality and Human Rights Commission interven....

51. The main such representations are contained in MG's letter of 28 October 2015. That summarised for
the Secretary of State the circumstances which were said to show not only that she was already in breach
of the investigation duty under article 4 but also that the protection duty required her to take the specified
measures to protect him on release from detention.  The matters relied on are equally relevant to the case
as it is now put following his release.

52. In section 5 of the letter MG set out the Appellant's account of how he had come to the UK. Although it
was made clear that Ms Nicolaou Garcia had only had limited time to take instructions the account is fairly
full and circumstantial. I will not attempt a summary, since the essential points are sufficiently summarised
in the passage I quote in the next paragraph.

53. In section 6 (b) of the letter, which is the part alleging a breach of article 4 and of the Secretary of
State's own policy, reference is made to the passage in the Front-line Guidance describing indicators of
trafficking. The letter then continues:

“Plainly TDT's circumstances fit the description above. He was transported from Vietnam to the UK via
Russia for the purposes of labour exploitation. He was told to sign a contract where he was told he owed
his traffickers a 'debt', he was told he would receive 'higher wages abroad' and was then tricked, locked up
and mistreated in Russia and various other locations on his way to the UK. The exploitation of young
Vietnamese boys in cannabis farms or nail bars in the UK is well-known.”

(As I have said, that is a summary of facts more fully stated in the earlier section.) The letter says that the
Appellant's appearance, as “a 16-year old Vietnamese boy with an expression of fear or anxiety who feels
lonely in detention and does not engage or interact with the other detainees”, clearly corresponds to the
indicators of fear, anxiety and depression listed in section 7.3 of the Front-line Guidance (see para. 26
above).

54. Finally, in section 6 (c) MG emphasise the importance of taking steps to prevent the Appellant being
re-trafficked on release. The letter says:

“TDT may still be under the control of his traffickers and will be vulnerable to their threats and coercion
when he is released from immigration detention. The two other Vietnamese children referred in page 5 of
this letter went missing/were re-trafficked from their foster placements on 29 September 2015 and 23
October 2015. We understand Kent Police is currently investigating their disappearance. The June 2012
_Report from the Joint Inquiry into Children who go Missing from Care makes clear how common it is for_
Vietnamese children to be re-trafficked from their foster placements after being released from immigration
detention. Paragraph 38 of that report summarises the Office for the Children's Commissioner [“OCC”] for
England's evidence during the Inquiry:

_'Evidence to the Inquiry showed that certain profiles of trafficked children go missing immediately. For_
_these groups, it is particularly important that immediate interventions take place – preferably within 24_
_hours of being placed into care – to prevent these children going missing. Indeed, the OCC, in relation to_
_child trafficking in Kent, recommend that “Given that virtually all of the Vietnamese children who arrived in_
_Kent in 2010 went missing and the only ones recovered (to date) were those found working in cannabis_
_factories, OCC is of the view that all unaccompanied Vietnamese children should be regarded, prima facie,_
_as having been trafficked”. The OCC also suggested that for some potential victims, police surveillance_
_should be considered “with the aim of catching those responsible for trafficking … bringing them to justice.'_

[Emphases in original]”

The evidence that a high proportion of Vietnamese children go missing on release is particularly important
for our purposes.

55. As I have said, MG's letter of 28 October also attached Ms Topteagarden's NRM referral, made the
previous day. That gave a substantially similar account of the reasons to believe that the Appellant was a
victim of trafficking. The relevant parts read:


-----

Department (Equality and Human Rights Commission interven....

“[TDT] explained to me that he was brought to the UK earlier this year by an agent. He was working in
construction at the time in order to support himself. He was approached by the agent who had spoken to
his boss and who told him he could earn more money working abroad. [TDT] explained to me that he had
lost his parents, he was on his own and felt that he had nothing to lose by agreeing to this. [TDT]
understood that he would have to pay for the journey by working as he was given a 'contract' that stated
this. He did not know what work he would be doing or how long for or how much exactly he would owe.

[TDT] spoke about travelling by plane to Russia and then overland to the UK. He was detained on arrival
and was placed in Dover IRC before being transferred to Brook House.

The Refugee Council has been involved with a number of other young people who we believe may have
travelled with [TDT] and may have been trafficked by the same people. Three of these young people have
gone missing from care and two remain missing whilst the third was returned to his foster placement. It is
overwhelmingly likely that these children have been re-trafficked and are currently being exploited by the
people who brought them here. We are extremely concerned about [TDT's] safety and believe it is of the
utmost importance that he is recognised as a potential victim of trafficking to ensure he receives the
appropriate level of support and protection. We will continue to support him and to build a relationship of
trust in order to ascertain more information about his trafficking and ensure he is able to engage with
support services who will work to alleviate the pressure and control that traffickers exert over their victims.”

Ms Topteagarden also ticked a number of boxes on the appropriate form as indicators that the Appellant
may have been trafficked. These included that he “shows signs of emotional neglect” and was “socially
isolated” – also that he had a mobile phone, which is significant partly because it was a means by which he
could remain in touch with his traffickers while in detention.

56. Apart from the weight of that evidence in its own right, the Appellant also relies on the fact that by letter
dated 17 November 2015 the Home Office itself as Competent Authority accepted that Ms Topteagarden's
referral showed reasonable grounds to believe that he was a victim of trafficking. Of course by that time he
had been released and disappeared; but the decision is significant, to put it no higher, because it shows
that the evidence available on 6 November satisfied a different arm of the Home Office, applying
essentially the same test, that the Appellant was indeed a potential victim of trafficking.5

(2)          THE GENERIC EVIDENCE BEFORE THE JUDGE

57. The evidence adduced by the Appellant before the Judge, besides the contemporary representations
referred to above, comprised:

(a) an expert report (and an addendum) from Christine Beddoe, the former Director of ECPAT UK [End
Child Prostitution, Pornography and Trafficking] and adviser to the All-Party Parliamentary Group on
Trafficking;

(b) a witness statement from Andy Desmond, a former police officer who is now a freelance consultant on
trafficking issues;

(c) a witness statement from Chloe Setter, the Head of Advocacy, Policy and Campaigns at ECPAT UK
and Chair of the Home Office Child Trafficking Sub-Group;

(d) three witness statements from Ms Nicolaou Garcia;

(e) a witness statement from Ms Topteagarden.

Reliance was also placed on certain published reports and other materials most of which were referred to
in the witness evidence, including in particular a letter to MG from the OCC. Of course the reports and
witness statements were not before the Secretary of State at the time of the Appellant's release; but they
state facts and refer to materials which it is said were or should have been known to the Home Office and
express opinions about whether those facts and materials passed the credible suspicion threshold.

58. The evidence in question is careful and comprehensive, but the factual material in it (though not all the
expressions of opinion) is not essentially disputed by the Secretary of State, and some of it goes to matters


-----

Department (Equality and Human Rights Commission interven....

which are not now in issue. Accordingly it is not necessary to rehearse it in great detail. For present
purposes it can be sufficiently summarised as follows.

59. The central evidence is that of Ms Beddoe. Paras. 27-35 of her report are headed “Vietnamese
Children and Human Trafficking in the UK” and deal generally with the phenomenon of trafficking young
Vietnamese men into the UK. Para. 27 reads:

“When TDT arrived in the UK in September 2015 there was already a vast array of police and UK Border
Agency intelligence, and information published by the UK Human Trafficking Centre, the Child Exploitation
and OnLine Protection Centre and the National Crime Agency, for all authorities to be alert to the trafficking
profile of young Vietnamese males trafficked for exploitation in cannabis factories or other forms of criminal
activity and sexual exploitation. TDT fits this profile.”

In the following paragraphs she goes on to give particulars of the materials in question, which include
reports published in 2009 and 2010 by the Child Exploitation and Online Protection Command (“CEOP”),
part of the National Crime Agency; a report from the Children's Commissioner for England published in
2011 on “Landings in Kent”; and a “Strategic Threat Assessment” published by UKHTC in 2014 on the
nature and scale of human trafficking into the UK in 2013. These reports, of which copies were before us,
clearly make good her statement.

60. At paras. 36-43, under the heading “Going Missing”, Ms Beddoe explains that there is a known
problem of child victims of trafficking returning to the control of their traffickers if released into care. At
para. 39 she quotes figures from the 2010 CEOP report showing that this problem was most acute among
Vietnamese victims. Of 42 children going missing between March 2009 and February 2010, 28 were
Vietnamese: a number were subsequently re-discovered working in cannabis factories. Similar reports are
cited from a BBC investigation in 2013 and a joint report from CEOP and the British Embassy in Hanoi.

61. Among the materials referred to by Ms Beddoe was evidence given by the Children's Commissioner to
the All Party Parliamentary Group for Runaway and Missing Children and Adults in April 2012. The
Group's report recorded her evidence in the terms quoted at para. 54 above. On 23 November 2015 the
OCC stated:

“The position we took in relation to Vietnamese young people arriving unaccompanied remains the same
as it did when we reported to the inquiry. In particular, we consider that all unaccompanied Vietnamese
young people arriving in the UK should, by virtue of their nationality, be considered at immediate risk of
having been trafficked.”

(Strictly, that post-dates the Appellant's release by a couple of weeks, but of course it simply confirms what
the Commissioner had already said.)

62. Ms Beddoe's conclusion was that the materials in question clearly established that the Appellant was a
potential victim of trafficking and was at real and immediate risk of being re-trafficked if he were released.

63. Mr Desmond's evidence was to the effect that the profiles of the Appellant and two of the other young
Vietnamese males detained with him “meet the well-documented profiles of Vietnamese trafficked children
who are trafficked into the UK via Dover” and said that there were clear indicators from their histories which
were “consistent with the modus operandi of how the traffickers bring Vietnamese trafficked children to the
UK” and “which should have been clear to the Home Office as a frontline agency” from the moment of their
detention. He described in particular the use of the route via Russia. (It is convenient to mention at this
stage that we were referred by Mr Buttler to a passage in the Hoang decision at first instance summarising
a US State Department report on _Trafficking in Persons from June 2013, which identified Russia as a_
principal staging-post for trafficking from Vietnam to the West: see paras. 86-91. The report itself was not
put before us but Mr Buttler relied on the summary given in Hoang, which Mr Lewis did not suggest was
inaccurate.)

64. Ms Nicolaou Garcia's first witness statement contained a lengthy section in which she recounted her
discussions with other solicitors with expertise in this field about the risk of re-trafficking. The essential


-----

Department (Equality and Human Rights Commission interven....

point to emerge, stated at para. 27 of the statement, was that “there appears to be a very high risk of
young Vietnamese potential victims of trafficking going missing on their release from immigration
detention”, whereas that is generally rare for other young people who are so released. She relied in
particular, though by no means only, on what she was told by Ms Philippa Southwell of Birds Solicitors,
which was to the effect that between 30% and 50% (depending on the year) of her Vietnamese trafficked
clients “went missing/were re-trafficked after being released from immigration detention” and that all those
who eventually re-emerged (only about 15%) turned out to have been re-trafficked. (Only percentage
figures are given: there are no absolute numbers.) It was not Mr Buttler's case that the Secretary of State
should have been aware of those figures as such but rather that they were further evidence of a pattern of
which the Home Office should have been well aware from the published sources and its own experience
and expertise in the field.

65. Ms Nicolaou Garcia's witness statement also contained an account of information given to her by
Imogen Spencer Chapman, Children's Services Practitioner at the NSPCC Child Trafficking Advice Centre.
She said that, of the 250 Vietnamese children her team had dealt with, more than 50% had gone missing.

66. For completeness, I note that in his skeleton argument Mr Buttler relied on what he said were findings
by the Home Office itself in December 2015 to the effect that 72 of 158 potentially trafficked children have
gone missing at least once and that 85% of the missing children were Vietnamese. We were not referred
to the document said to evidence those findings, and since they post-dated the decision to release the
Appellant I would not take them into account for our purposes.

(3)         THE OTHER VIETNAMESE

67. It will be seen that in the letter of 28 October 2015 MG referred to the fact that two other Vietnamese
males detained at the same time as he was had been treated by immigration officials as children and put
into foster care but had since gone missing. Their case was that they were plainly (at least potential)
victims of trafficking, and that this reinforced the case that the Appellant was too.

68. Further details about the two children in question were given in Ms Nicolaou Garcia's witness
statement. However, as will appear, the Judge found that since it had never been definitively established
that they were indeed victims of trafficking, the evidence about them did not really advance the argument.
On a strict view there appears to be some force in that point; and since I do not believe that this element is
central to the Appellant's case, and Mr Buttler did not take us to the evidence in his oral submissions, I
need not say anything more about it.

**THE SECRETARY OF STATE'S CASE**

69. Remarkably, no witness statement was lodged on behalf of the Secretary of State, and, as I have said,
there was no reply to the pre-action protocol letter. There is accordingly no evidence of what contemporary
consideration, if any, was given to the points made by MG. Nor is there any evidence to counter or qualify
the other evidence relied on about what should have been known to the Secretary of State about the
possibility that young Vietnamese males encountered entering the UK illegally might be victims of
trafficking or the risk of them being re-trafficked if released, or about how the Appellant fitted that profile.
Mr Lewis's case was, straightforwardly, that the material on which the Appellant relied did not get over the
credible suspicion threshold.  His essential point before the Judge, as before us, was that while the
evidence showed that there was indeed a problem of young Vietnamese males being trafficked to the UK,
and of their being at being at risk of being re-trafficked on release, it was not sufficient to show that the
Appellant's case fell into that pattern. Not all young Vietnamese males entering the UK were victims of
trafficking: even on the figures suggested by Ms Nicolaou Garcia's inquiries it was less than 50%. Some
would be entering as ordinary economic migrants, without any element of trafficking; and there was no
sufficient basis to suspect that the Appellant was not such a migrant.

70. Since that is the issue, there is strictly speaking no need for us to consider how it came about that the
Appellant came to be released notwithstanding the correspondence from MG. Nevertheless it is possible
to reconstruct most of what happened from the case record sheet (“CRS”) disclosed by the Secretary of


-----

Department (Equality and Human Rights Commission interven....

State and from the evidence of Ms Nicolaou Garcia about her contacts with the Appellant, and I think the
exercise is worth doing.

71. So far as the period up to 6 November is concerned I can take it fairly shortly:

(1) The early CRS notes are essentially concerned with attempts to obtain emergency travel documents
and the justification for detaining the Appellant in the meantime. The principal decision-makers were not at
Brook House but were part of a Home Office “NRC” team in Birmingham.

(2) A note dated 23 October records that the Appellant's representatives say that he was born on 5
December 1999 and is a victim of trafficking. It is clear from Ms Nicolaou Garcia's witness statement that
that reflects a phone call from her to the Home Office following her visit to the Appellant that day.  The
same note also says that there has been a Merton-compliant assessment of the Appellant's age; that was
simply wrong.

(3) The receipt of the pre-action protocol letter sent on 28 October is recorded on 2 November (a weekend
had intervened) and various administrative consequences are noted; but there is no record of any
substantive consideration of its contents.

(4) On 3 November the notes record that emergency travel documents cannot be obtained. On the same
day a “detained case worker” addresses a note to his colleagues saying that he believes the Appellant to
be a “deemed PVoT” [potential victim of trafficking] and that “an application has been raised”. This must, I
think, be a reference to Ms Topteagarden's NRM referral on 28 October. The note goes on to point out
that the Appellant's age is disputed and that there has been no Merton assessment and asks whether the
team “wish to continue to treat this subject as a minor”; but there is no apparent response to that query.

(5) There are notes dated 5 and 6 November recording that the Appellant would have to be released from
detention, partly because there was now no prospect of obtaining emergency travel documents in the near
future but also because, as the note records, “the PVOT RG [potential victim of trafficking reasonable
grounds] decision remains outstanding and there is a real chance that a positive RG decision will be
made”. The note records that “a safe release address” will be needed and that Brook House had been
asked to provide one.

72. The exact sequence of events on 6 November is impossible to reconstruct, but the key elements are
as follows:

(1) The judicial review proceedings were served on the Secretary of State at 12.48 pm, together with an
application for urgent consideration. The application made it clear that the Appellant should not be
released without “a robust risk assessment, protective plan and specialist accommodation in place”: this of
course is what had already been sought in the pre-action protocol letter.  The CRS shows that the
proceedings were forwarded by e-mail to the NRC team in Birmingham forthwith.

(2) At about 1.30 pm the Appellant was interviewed by an immigration officer at Brook House. There was
no interpreter present but the Appellant told Ms Nicolaou Garcia in the conversation referred to below that
a fellow-detainee had tried to translate, and he appears to have understood that he was going to be
released and that he was being asked for a release address.

(3) At about 2.30 pm Ms Nicolaou Garcia (through an interpreter) spoke to the Appellant on the telephone
and he told her of that interview. She understood that he had not so far supplied a release address. She
wrote at once to the Government Legal Department reminding them of the issue of proceedings and
insisting that he should not be released except in accordance with the precautions sought in the pre-action
protocol letter and the application. The letter was sent at about 3.15 pm

(4) At some point in the afternoon – it is not clear when – the Appellant gave staff at Brook House a
release address in Upper Norwood in South London. There is no record of any consideration by the staff
of whose the address was or how the Appellant came to have it: plainly one possibility is that he was given
it by traffickers. Police enquiries have since established that, as I have said, it was in fact not a residential
address at all but that of a Buddhist temple.


-----

Department (Equality and Human Rights Commission interven....

(5) Later that day the Appellant was released. Police enquiries have since established that he was seen
with another man at Gatwick railway station. There is no record of him ever having gone to the temple.

(6) The CRS suggest that an attempt was made by the NRC team to contact the Appellant's
representatives after he had been released, by fax and phone; but no such message was received by MG,
and it was not until four days later that Ms Nicolaou Garcia learnt of his release from the Government Legal
Department.

73. That is a sorry story. The Brook House staff and the NRC team appear to have proceeded with their
plan to release the Appellant in total disregard of the terms of the pre-action protocol letter of 28 October
2015, even though they were certainly aware of it and, separately, of the fact that his age was disputed and
that there had been no Merton-compliant assessment. That is the more disturbing given that those points
had been explicitly recorded in the CRS notes referred to at para. 71 (4) and (5) above. The most obvious
explanation is a failure of internal communication; but in the absence of a witness statement from the
Secretary of State it is impossible to take it further. (The failures to respond to the interim application in the
claim form and MG's letter of 6 November are, by contrast, venial, since they were received at most a very
few hours before the Appellant's release.) Mr Lewis acknowledged that something had gone seriously
wrong as a matter of administration; but he emphasised – correctly, as I would accept – that the question
of whether there had been a breach of the protection duty under article 4 is distinct.

**THE JUDGMENT OF McGOWAN J**

74. McGowan J found that the circumstances relied on by the Appellant did not reach the credible risk
threshold. Her analysis appears at paras. 27-33 of her judgment, which read as follows:

“27. If there was a credible basis to suspect that [TDT] was trafficked into the UK then he has not been
offered reasonable protection against being re-trafficked. The questions at the core of the case are, first,
was he trafficked or was there enough material to give rise to a credible suspicion that he had been
trafficked? Second, if he was trafficked does that mean that he was at a real and immediate risk of being
re-trafficked?

28. Applying the test set out in _Rantsev to the issues, namely, 'In order for a positive obligation to take_
operational measures to arise in the circumstances of a particular case, it must be demonstrated that the
State authorities were aware, or ought to have been aware, of circumstances giving rise to a credible
suspicion that an identified individual had been, or was at real and immediate risk of being, trafficked or
exploited'. What are the circumstances said to give rise to the credible suspicion? It is accepted that simply
being a Vietnamese national of about 18 years of age is not enough. The incidence is high but not high
enough for that automatically to give rise to grounds for a credible suspicion. It is submitted on the
Claimant's behalf that there is more, there is the fact that he was travelling in a lorry with other Vietnamese
males, who were thought may be victims of trafficking and that one of them had disappeared from foster
care and two from detention. It is also submitted that those who represent him had put forward evidence of
their belief that he was under 18. There were 16 males in the same lorry, 9 of whom were not Vietnamese
nationals. There is no suggestion that the other nationals were victims of trafficking. It is difficult to see how
the Claimant's presence in the lorry with other Vietnamese, about whom the same concerns were
expressed, can without more, amount to grounds for credible suspicion. It is further submitted that three of
the other Vietnamese males had disappeared by 6 November. That is true but one returned in due course.
That such persons disappear frequently and for a variety of reasons is obvious.

29. On the age issue it is clear, given that the male who disappeared and returned was in foster care that
some consideration had been given to the age of the detainees and he had been assessed as young
enough for foster care rather than detention. The immigration officials who considered the age of the
detained Vietnamese nationals must, on the day of detention or later, have applied the guidelines and
determined that at least one of them was or may have been under 18. The determination of the Claimant's
age at that point is disputed but it is not demonstrably unreasonable. There was a conflict of opinion which
was not determined before his disappearance. The certainty on the part of the Claimant's witnesses that he


-----

Department (Equality and Human Rights Commission interven....

was under 18 and has since been trafficked does not prove that he has and does inform the decision taken
on 6 November 2015, which is the decision under challenge.

30. Although I do not find such grounds established I have gone on to consider the Rabone test, namely,
looking for a substantial or significant risk of re-trafficking which is present and continuing. On the premise
that there were grounds for the credible suspicion that the Claimant had been trafficked into the UK it is
argued that having been trafficked he was at a real and immediate risk of being re-trafficked. Even if there
were credible grounds for suspicion, what more is there to give rise to a real and immediate risk? It is
accepted that being Vietnamese and about 18 is not enough but that, actually, is the basis upon which the
submission is founded. It is said that in such cases it is common practice for contact between the traffickers
and the trafficked to be re-established after detention and for there to be a 'voluntary' or forced reunion.
Accepting that evidence, it is still based on the age and nationality of the Claimant without any or any
sufficient additional grounds to establish the basis of this challenge.

31. Accordingly, I do not find an operational breach of Article 4 in this case. …”

75. Although I have for completeness included the surrounding paragraphs, the core reasoning is at paras.
28-30. In summary:

(1)  At paras. 28-29 the Judge considers the first element in the _Rantsev formulation, namely whether_
there was a credible suspicion that the Appellant had been trafficked. She finds that the facts before the
Secretary of State amounted to no more than that he was Vietnamese and “about 18” and that that was not
enough to give rise to such a suspicion. She rejects the argument that the fact that he was arrested with
other Vietnamese young men, or that he was alleged to be under 18, constituted “something more”.

(2)  At para. 30 she considers the other element, namely whether the Appellant was at real and immediate
risk of being re-trafficked. But, as she points out, such a risk only in practice arose if the first criterion was
satisfied; and thus unsurprisingly she rejects his claim on this basis too.

**THE APPEAL**

76. The Appellant's primary ground of appeal is simply that the Judge was wrong to find that at the
moment of his release the credible suspicion threshold had not been crossed. But that is supported by the
criticism that she fails in the relevant paragraphs to make any reference to a number of the key points in
his case.

77. In my view that challenge is well-founded. I believe that the material before the Secretary of State
plainly justified a credible suspicion as at 6 November 2015 both that the Appellant was a victim of
trafficking and also that he was at risk of being (re-)trafficked if proper protective measures were not taken.
It is arguably enough to point, as the Appellant does, to the fact that that was the view of the Competent
Authority (itself a branch of the Home Office) when it belatedly considered the selfsame material, and
indeed that the CRS notes show that it was contemplated that that might be the outcome: see paras. 56
and 71 (4)-(5) above. But my conclusion would be the same even without that element. My reasons can
be summarised as follows.

78. There is abundant evidence, and it is undisputed, that there is a high incidence of young Vietnamese
males being trafficked to the UK. Despite his stance on the point discussed at para. 47 above, Mr Buttler
did not invite us to proceed on the basis of the OCC's proposition that any young Vietnamese male found
illegally entering the UK should prima facie be regarded as a victim of trafficking; and indeed it appears that
he had accepted before the Judge that “something more” was required. But in my view the available
material clearly went further than that. It was, in the first place, the explicit and uncontradicted evidence of
Ms Beddoe and Mr Desmond that the Appellant's account of how he had been brought to the UK fitted the
pattern of a victim of trafficking, and Ms Topteagarden's referral under the NRM was on the same basis: all
three had highly relevant expertise, and Ms Topteagarden had actually met him. Their evidence did not
rely on mere assertion. They identified particular features of the Appellant's account that were said to be
characteristic – particularly his having reached the UK via Russia, being subject to a contract under which
he would have to work in the UK to repay the cost of being brought here and having been mistreated en


-----

Department (Equality and Human Rights Commission interven....

route. There was also Ms Nicolaou Garcia's contention, based on both her own contacts with him and Ms
Topteagarden's, that the Appellant fitted the psychological indicators identified in the Front-line Guidance: I
accept that this is more difficult to judge objectively, but it cannot be discounted in circumstances where
there is no evidence that any Home Office staff responsible for his case even tried to form their own
assessment. None of those features are mentioned by the Judge. She seems to have focused her
consideration of whether there was “something more” on the fact that he was found in a lorry with a
number of other young Vietnamese males, some of whom had subsequently gone missing. As to that, as I
have said, I am inclined to agree that that in itself it would not have taken the question much further; but in
my view the other material referred to was fully sufficient to raise a credible suspicion that the Appellant
had been trafficked to the UK, and the Judge should have so found.

79. Mr Lewis drew attention to the fact that the Appellant's claim to have been a victim of trafficking was
not made straightaway but only following the involvement of MG. I accept that that is a point that can
properly be put in the balance, though there are obviously reasons why a genuine victim of trafficking
under the influence of his traffickers might not make such a claim straightaway. But it is important not to
lose sight of the fact that we are not concerned with a conclusive decision but simply with whether the
“relatively low” credible suspicion threshold has been crossed.

80. It follows from that conclusion, at least in the circumstances of this case, that there was also a credible
suspicion that the Appellant was at real and imminent risk of being re-trafficked if released. There was
plenty of material which was, or should have been, known to the Secretary of State that showed that young
Vietnamese males trafficked to this country are at high risk of falling back into the control of their traffickers
if released from detention. We heard some submissions about percentage risks, based partly on the
figures given to Ms Nicolaou Garcia by Ms Southwell and Ms Chapman. But the evidence does not lend
itself to useful statistical analysis. In my view the more general evidence of the OCC to the All-Party
Parliamentary Group – see para. 54 above – is sufficient to meet the relevant test; and that evidence was
explicitly quoted in MG's letter of 28 October 2015.

81. I need not specifically consider the Judge's reasoning on this aspect: as she pointed out, it was a
necessary premise for the existence of such a risk that the Appellant should have been trafficked in the first
place, and she had found that there were insufficient grounds to suspect that that was so.

82. Mr Lewis submitted that though there might be such a risk it was at too generic a level to cross the
credible suspicion threshold or to be categorised as “real and immediate”. There was no specific evidence
that the Appellant was till in contact with his traffickers and thus vulnerable to being re-trafficked by them.
Given that there were, as I have found, specific grounds for a reasonable suspicion that the Appellant was
a victim of trafficking, detained in the course of the trafficking process, I do not believe that further specific
evidence of the risk of re-trafficking was necessary. As I have already said, being a past victim of
trafficking and being at real and immediate risk of being (re-) trafficked are very closely inter-related. It is
inherently entirely plausible that a victim of trafficking who has been detained will remain under the
influence of his traffickers (particularly where he or she retains their mobile phone); and there is particular
evidence to this effect in the case of young Vietnamese males. Again, it is important to remember that the
test is one of credible suspicion.

83. Mr Lewis reminded us that it was recognised that the equivalent protection obligation in the article 2
cases should not be treated as imposing “an unduly burdensome obligation”, and in particular that member
states were not obliged to do more than take reasonable steps in the particular circumstances. He referred
us in particular to the speech of Lord Carswell in _Re Officer L_ _[2007] UKHL 36, [2007] 1 WLR 2135, at_
para. 21 (p. 2144 F-G); and to the observations of Lord Hughes at paras. 111-113 of his judgment in
_Commissioner of Metropolitan Police v DSD_ _[2018] UKSC 11, [2018] 2 WLR 895. He submitted that a_
conclusion that the protection duty under article 4 arose in a case of this kind would place a
disproportionate burden on the Home Office; and that it could not be right that the state was under more
onerous obligations in the context of article 4 than in the context of article 2, which was concerned with the
right to life itself. As general propositions all that is unobjectionable, but what specific obligation it is
proportionate to impose depends on the circumstances of the case Mr Lewis did not argue nor sensibly


-----

Department (Equality and Human Rights Commission interven....

could he have done, that the particular protective measures sought by MG in this case – essentially, that
the Appellant should only be released into safe accommodation provided by the Council (which it had
agreed to provide) – imposed any disproportionate burden. The argument is in truth an unattractive one in
circumstances where the Appellant's release was apparently not the result of any considered decisionmaking by the relevant Home Office team at all.

84. Although it was initially an important part of the Appellant's case, which the Judge rejected, that he
should have been treated as a minor, it will be apparent that I do not think that that aspect is central to the
issue. The essential criticism in this case, namely that if the Appellant was a potential victim of trafficking
he should not have been released without proper protection against the risk of being re-trafficked, is
equally valid even if he was 18. I accept that if he was in fact an adult the particular form of protective
measures argued for by MG, which, as I understand it, depended on the Council treating him as a child,
would not have been available. But it was not argued by Mr Lewis that no effective protective measures
could have been put in place if he were over 18.

85. Having said that, there are heightened duties for children who are victims, or potential victims, of
trafficking; and the case against the Secretary of State is certainly reinforced by the evidence of Ms
Nicolaou Garcia and Ms Topteagarden, unrebutted by any contrary evidence, that the Appellant appeared
to them to be clearly still a child. I regard it as reprehensible that once MG had put the Appellant's age
squarely in issue no attempt was made by the responsible Home Office staff to reach a considered view on
the question and to await a Merton assessment if necessary – all the more so when the question had been
raised in the CRS notes themselves (see para. 71 (4)-(5) above).

**DISPOSAL**

86. I would allow the appeal and make a declaration to the effect that the Secretary of State acted in
breach of her duty under article 4 of the ECHR and thus section 6 of the 1998 Act by releasing the
Appellant on 6 November 2015 without having put in place adequate measures to protect him from being
re-trafficked.

87. Mr Buttler asked us also to make orders prescribing what the Secretary of State should do, or not do, if
the Appellant were to be found by him in the future – specifically (a) that he should not remove the
Appellant until there has been a conclusive decision about whether he is a victim of trafficking and (b) that
he should notify Simpson Millar within 24 hours. As to (a), I do not believe that it is right in principle to
make a final order enjoining the Secretary of State from taking a step which there is no reason to believe
that he intends to take: as Mr Lewis pointed out, the Secretary of State will be fully aware of what this Court
has held and of its implications. As to (b), the circumstances in which the Appellant may be found – maybe
years hence – are unpredictable, and I do not think that a mandatory final order prescribing how the
Secretary of State should act (let alone within 24 hours) is appropriate: simply by way of example, the
Appellant might in the meantime have obtained other legal advisers. I would, however, hope and expect
that as a matter of good practice the Secretary of State would promptly so inform Simpson Millar, or in any
event ensure that the Appellant was enabled to do so, unless there were some good reason not to. Mr
Buttler told us that similar orders had been made interlocutorily in other cases; but this is a final order.

88. Ms Mountfield in her skeleton argument submitted that what went wrong in the present case was more
than simply a one-off error and that it reflected a much more general failure on the part of the Home Office
to understand how to handle potential victims of trafficking. I am not in a position to express any view
about that, but I would certainly hope that the Secretary of State will give careful consideration to whether
any general lessons can be learnt from this case.

**Lord Justice Floyd:**

89. I agree.

**Dame Elizabeth Gloster:**


-----

Department (Equality and Human Rights Commission interven....


90. I also agree.

**End of Document**


-----

