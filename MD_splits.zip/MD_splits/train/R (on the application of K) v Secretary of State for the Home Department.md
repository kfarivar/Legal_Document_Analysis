# R (on the application of K) v Secretary of State for the Home Department

 [2015] EWHC 3668 (Admin)

Queen's Bench Division, Administrative Court (London)

Picken J

21 December 2015Judgment

**Catherine Meredith (instructed by Wilson Solicitors LLP) for the Claimant**

**Kerry Bretherton (instructed by The Government Legal Department) for the Defendant**

Hearing dates: 1 and 2 December 2015

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**The Honourable Mr. Justice Picken:**

**Introduction**

1. The Claimant ('K') is a 35-year old man who was born in Ghana. He entered the United Kingdom on 4
September 2003. He has lived here ever since. It is common ground that he was a victim of trafficking. He
challenges the refusal by the Defendant, in a decision letter dated 16 January 2015 made under the
National Referral Mechanism for the identification of victims of trafficking (the 'NRM'), to grant him a
residence permit, and so discretionary leave to remain under Article 14 of the Council of Europe
Convention on Action against Trafficking in Human Beings 2005 (CETS No 197) (the 'Trafficking
Convention'), rather than under the Immigration Rules which are not concerned with the grant of leave to
remain to victims of trafficking.

2. As will appear, the decision made on 16 January 2015 was a 'fresh' decision made after permission to
bring these judicial review proceedings had been given by Lord Carlile of Berriew CBE QC (sitting as a
Deputy High Court Judge) on 1 April 2014 in relation to an earlier decision made by the Defendant on 10
October 2013. K's case, in summary and as set out in the Amended Grounds for Judicial Review prepared
by reference to the letter dated 16 January 2015, is that the Defendant's refusal to grant him a residence
permit is unlawful in that it: (i) failed to apply/misapplied her own published trafficking guidance without
good reason in the assessment of whether the Claimant qualified for a residence permit, failing in particular
to take into account material considerations (Ground (1)); (ii) applied an unlawful policy governing the
eligibility conditions for a residence permit (Ground (2)); (iii) was in breach of Article 4 of the European
Convention on Human Rights as a result of a failure to exercise 'anxious scrutiny' of K's eligibility for a
residence permit (Ground (3)); and (iv) failed to consider at all, or acknowledge, the principle that the
Defendant is required to correct an historic injustice to a victim of trafficking (Ground (4)). As will appear,
the nature of the Grounds has undergone, in places, something of a change from how they were presented
in the Amended Grounds for Judicial Review.

3. The Defendant disputes each of these grounds. She maintains that the decision made on 16 January
2015 was a decision which was lawful. Miss Kerry Bretherton, counsel for the Defendant, noted in her
skeleton arg ment in partic lar that Gro nds (3) and (4) ere not mentioned in the skeleton arg ment


-----

submitted by Miss Catherine Meredith, counsel for K. Miss Meredith subsequently, however, made it clear,
in a document submitted in reply to Miss Bretherton's skeleton argument, that Ground (3) is pursued. It was
confirmed by Miss Meredith, both in the reply document and in her oral submissions, that, consistent with
how the point was put in the Amended Grounds for Judicial Review, the challenge is as to the decision
made on 16 January 2015. However, despite the Amended Grounds stating very specifically in paragraph
141 (as to Ground (3)) that the alleged failure to exercise 'anxious scrutiny' by the decision-maker was a
failure as to matters set out in paragraph 125 (matters which did not include a Police investigation, which
was addressed in paragraph 126 and following), Miss Meredith explained that Ground (3) had as its
exclusive focus the issue of co-operation with the Police and how that issue was addressed by the
decision-maker when the decision was made. She confirmed also during her oral submissions that, despite
reference in her skeleton argument to “a failure to discharge the Defendant's positive obligations by way of
_a referral to and cooperation with the police” being one of the grounds asserted in these proceedings, no_
freestanding failure by the Defendant to make a referral to the Police had been asserted in the Amended
Grounds and, as such, this broader type of allegation was not pressed before me - at least, as I shall later
explain, as regards matters which have happened after the decision in K's case was made on 16 January
2015. As I shall explain shortly, this has an impact on the admissibility of certain material post-dating the
decision made on 16 January 2015 on which, at least in her skeleton argument, Miss Meredith sought to
rely.

4. As to Ground (4), Miss Meredith explained in her skeleton argument, in a footnote, that this aspect,
which is based on EK (Tanzania) _[[2013] UKUT 313, was not pursued as part of the present proceedings](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5929-8BS1-F0JY-C1RS-00000-00&context=1519360)_
since it is recognised by K and his legal team that leave to remain on the basis of correcting an historic
injustice is a separate issue to be determined most appropriately through an application under the
Immigration Rules rather than in the present context. However, somewhat surprisingly, during the course of
Miss Bretherton's submissions, Miss Meredith interjected to say that Ground (4) was pursued.
Subsequently, after this judgment was sent to the parties in draft, Miss Meredith explained that Ground (4)
was not, after all, intended to be resurrected and apologised for the confusion. In the circumstances, whilst
I had thought that I need say no more about Ground (4) and instead focus exclusively on Grounds (1), (2)
and (3), and indeed that would ultimately seem to be the case, nevertheless, if only for completeness, I
propose to address Ground (4) also.

**Background facts**

5. The background facts are largely uncontroversial. It was acknowledged by Miss Bretherton that, in the
circumstances, I could take them from Miss Meredith's helpful summary in her skeleton argument, and this
is what I do in what follows, albeit that I have made modifications to Miss Meredith's summary where
appropriate, my having myself read the underlying material (including K's most recent witness statement
dated 11 November 2015 and so not available to the Defendant when making the decision on 16 January
2015, a matter to which I shall return) in order to satisfy myself that what is contained in that summary is
accurate.

_Ghana_

6. K was born in Ghana on 3 February 1978. His mother died when he was aged 3. He was subsequently
sold by his father's family to a couple in the north of the country whom he called his 'aunty' and 'uncle'. He
attended school from the age of about five. He stopped going to school, however, when fees ceased to be
paid, instead working for his 'aunty' and 'uncle' on the streets, selling various things as well as working
without pay on cocoa plantations and fishing. He was regularly beaten using electrical cables, canes and
palm branches. He also suffered sexual abuse from his 'aunty'. He tried to run away on a number of
occasions, and in addition witnessed a fellow child labourer being beaten to death by tree branches.

7. K managed to escape, with somebody else who worked on the plantation, and went to live with
somebody called Afia for a few months. In this period K was subjected to threats and rituals known as “juju”
which instil extreme fear into victims to prevent them from speaking of their abuse and as a means of
maintaining control. It was in this period also that somebody else called Tony introduced K to a person
ll d M B t h d t d i f t l t thi t


-----

_Arrival in the United Kingdom_

**_8.           As I have mentioned, K entered the United Kingdom on 4 September 2003. On arrival he_**
was taken to a house in Luton, where he was subjected to forced labour and mental and verbal abuse.
This lasted for three years, during which he was unable to escape and his passport was kept from him. He
was locked in a house and taken to work in warehouses to sort through and clean products such as
clothing, shoes and electrical equipment. He received payment only occasionally, adding up to about £40 a
month. He worked from 4 am until about 8 or 9 pm, receiving only limited amounts of food.

**_9.           K eventually escaped with the aid of a Ghanaian truck driver called Ben, who collected_**
goods from one of the warehouses where K worked. Ben helped K to obtain his passport and took him to a
house in Milton Keynes. There he was made to work as a male escort, on one occasion being anally
raped. After about 6 months, he escaped and went to work in London as a cleaner, where he entered into
a relationship with a woman with whom he had a son. This was in 2007.

_Immigration applications_

**_10.           The same year, on 7 June 2007 to be precise, K applied for an EEA Registration_**
Certificate in conjunction with somebody whom he claimed was his uncle and two people said to be his
cousins. This was on the expiry of his leave to remain as a student on 31 May 2007, K's initial entry to this
country having been as a student. Further immigration applications were, however, refused. K was served
with papers stating that he had overstayed his visa and his subsequent challenges to this were
unsuccessful. In October 2010, having a year before been arrested as an overstayer and made the subject
of reporting restrictions, K was convicted of knowingly possessing an improperly obtained (and another's)
identification documents with intent. He was sentenced to 15 months' imprisonment.

**_11.           K then made several applications for judicial review, all of which were rejected. K was also_**
detained on two occasions: first, from 16 March 2011 to 7 November 2012; and then from 1 July 2013 until
10 December 2013. Bail was granted by an Immigration Judge on two occasions and K complied with
reporting restrictions. During both periods of detention, K was noted to be vulnerable and as suffering from
Post-Traumatic Stress Disorder, as well as a range of other medical and physical conditions as a result of
the various experiences to which I have referred.

_The 10 October 2013 decision letter_

**_12.           In July and August 2013, the Defendant sought to remove K from this country, and it was_**
at this time that the Non-Government Organisation, Detention Action, spotted indicators of trafficking and
made a referral to the Salvation Army, which, in turn, made a referral to the Defendant acting as the
Competent Authority under the NRM.

**_13.           This was followed, on 28 August 2013, by a letter from the Defendant, specifically from Mr_**
Phil Jardine Davies as the Competent Authority at Home Office Immigration Enforcement in Liverpool. In
his letter, Mr Davies stated that he had “concluded that there are reasonable grounds to believe” that K had
been trafficked. The letter went on to explain that, at the end of a period lasting 45 days, the Competent
Authority would make a conclusive decision as to whether K was a victim of trafficking.

14. On 10 October 2013 (received by fax on 11 October 2013), the 45 days having come to an end and
Wilsons Solicitors LLP ('Wilsons') having on 10 October 2013 written asking that K be released, Mr Davies
wrote again. He stated as follows:

_“As a result of further investigations into your case, the Competent Authority has concluded that you have_
_been trafficked.”_

However, the letter went on:

_“Although you were found to be trafficked because of the particular circumstances of your case, those_
_circumstances no longer exist and as you do not qualify for leave to remain in the UK you will be liable for_
_removal.”_


-----

15. This decision has subsequently been overtaken by the decision made on 16 January 2015. Miss
Meredith submits that this was inevitable in that the 10 October 2013 decision was unlawful because of its
reliance on historic trafficking and so on a previous policy of the defendant (not the policy which is current
to which I shall come on) which was held to be unlawful in R (Atamewan) v Secretary of State for the
**_Home Department_** _[2013] EWHC 2727 (Admin)._

16. Returning to the chronology, on 27 October 2013, the Defendant issued removal directions in respect
of K. This followed certain pre-action correspondence, in particular a letter from Mr Davies dated 24
October 2013 in which he made reference to K's passport having been used to travel in and out of the
United Kingdom since the time he first came to this country (something which K insists he did not,
suggesting that his traffickers must have used the passport when it was kept from him). The letter also
referred to K being willing to subvert immigration regulations and United Kingdom laws, as evidenced by
his conviction. On this basis, Mr Davies explained, it had been concluded that K would abscond from
custody if he were released.

17. This letter was followed by a further pre-action letter sent to the Defendant by Wilsons on 31 October
2013. Proceedings were then issued on 4 November 2013, and Mr Justice Kenneth Parker granted interim
relief the next day suspending K's removal.

18. K was subsequently released on bail on 10 December 2013 to the address of Mr Francis Akinseye. He
was referred for medical treatment in the community, and a medico-legal report dated 16 January 2014
was obtained from by Dr Hugh Grant-Peterkin. This report confirmed that K suffered from several physical
conditions, as follows: epilepsy, migraines, anal and rectal pain, haemorrhoids, intermittent testicular pain,
cysts on his head and buttock, depression and anxiety, history of thoughts of self-harm and suicide, and
Post-Traumatic Stress Disorder. It was concluded that there “are direct causative links between the abuse
_he experienced and his current mental state”. Detailed recommendations were given that K requires_
medication and highly-specialised psychotherapy and counselling by highly trained practitioners to treat his
complex needs.

19. In the meantime, Wilsons had requested that the Competent Authority, Mr Davies, refer the trafficking
claims to the Police. This led, on 12 February 2014, to Mr Davies telling Wilsons that a referral had been
made to Merseyside Police on the 'report a crime' website. On 26 February 2014, Wilsons wrote to Mr
Davies, stating that this referral, which had been made to Merseyside Police due to the fact that Mr Davies
is based in Liverpool, was irrelevant. Wilsons went on to make representations concerning K's personal
circumstances and his willingness to co-operate with a more appropriate Police force.

_Commencement of judicial review proceedings_

20. Permission to bring these proceedings having then been granted, on 1 April 2014, some months later,
on 27 September 2014, the Defendant requested current medical evidence concerning K. It is suggested
by Miss Bretherton in her skeleton argument that no such medical evidence was forthcoming and, indeed,
that it had not come forward by the time that the 'fresh' decision was made on 16 January 2015. Miss
Meredith pointed out, however, that further medical evidence had been included in a bundle prepared by
Wilsons for the substantive hearing which had been scheduled to take place in October 2014. Be that as it
may, the parties agreed that that hearing should not take place and that the Defendant would reconsider
K's application for leave to remain, the hearing being vacated as a result of a Consent Order which was
approved by Miss Clare Moulder (sitting as a Deputy Judge High Court Judge) on 8 October 2014.

21. That Consent Order contemplated that the Defendant would make a 'fresh' decision by 7 December
2014.

_The 16 January 2015 decision letter_

22. In the event, the decision was made on 16 January 2015, in the form of a letter from Mr Peter
Corcoran, acting as the Competent Authority having taken over from Mr Davies, when the Defendant
refused to grant K leave to remain, hence the fact that it is this decision (not the decision made on 10
October 2013) which is now the subject of these judicial review proceedings.


-----

23. The 16 January 2015 letter stated as follows at paragraph 2:

_“To clarify the position of the Home Office regarding grants of leave to victims of human trafficking, there_
_are three grounds on which [K] could be granted leave as a victim of human trafficking:-_

_a.          Assisting the Police in UK with their enquiries_

_Under the Council of Europe Convention on Action against Trafficking in Human Beings (the convention)_
_the Home Office may grant a period of 12 months Discretionary Leave where a victim has agreed to_
_cooperate with police enquiries. Where a person is conclusively found to be a victim of trafficking and has_
_agreed to assist with police enquiries from the UK, the police must make a formal request for them to be_
_granted leave to remain on this basis. This may be extended where necessary, for example, where a_
_criminal prosecution takes longer than expected and the police have confirmed or requested an extension._

_b.          Personal Circumstances_

_It may be appropriate to grant a victim of trafficking Discretionary Leave if their personal circumstances are_
_compelling. For example, to allow them to finish a course of medical treatment that would not be readily_
_available if they were to return home._

_c.          Victims who pursue compensation_

_Article 15 of the Council of Europe Convention on Action Against Trafficking in Human Beings deals with_
_the right of victims to compensation from traffickers. Discretionary Leave or a Residence Permit can be_
_granted in this circumstance.”_

24. The letter went on to say this in paragraphs 3 and 4:

_“3.          The Home Office have not had a formal request from the police in respect of your client_
_assisting them with their enquiries. Therefore [K] does not qualify for leave on this ground._

_4.          Consideration has been given to whether [K] qualifies for leave on medical grounds.”_

25. It continued at paragraphs 5, 6 and 7:

_“On 7 February 2014, a medico-legal report completed by Dr HD Grant-Peterkin dated 16 January 2014_
_was submitted in respect of your client. The conclusions contained in Dr Grant-Peterkin's report were that_
_your client had the following conditions:-_

_-            Epilepsy_

_-            Migraines_

_-            Anal / rectal pain / haemorrhoids / testicular pain_

_-            Post Traumatic Stress Disorder_

_-            Depression_

_-            Psychosis_

_6.            Dr Grant-Peterkin's report stated he was receiving the following treatment:-_

_-            Carbamazepine – Epilepsy medication_

_-            Risperidone – anti-psychotic medication_

_-            Citalopran – anti-depressant medication_

_-            Pizotifen and Sumatriptan – migraine medications_

_-            Ibruprofen – tesicular pain medication_

_-            Anusol – rectal / anal pain medication_

_7.          Dr Grant-Peterkin's report stated he needed the following further treatment:-_


-----

_-          Psychological intervention”._

26. In paragraph 8 Mr Corcoran stated as follows:

_“The Competent Authority accepts the medical evidence contained in the report of Dr Grant-Peterkin, that_

_[K's] conditions, treatment and prognosis were as stated at the date of the report on 16 January 2014.”_

27. Then, in paragraphs 9 to 11, Mr Corcoran considered whether K's various medical difficulties would be
treatable in Ghana. He did so by setting out various research material to which he had had regard. In
paragraph 10, in particular, he stated:

_“According to the most recent MedCOI reports (a European Refugee Fund financed project to obtain_
_medical country of origin information) dated between April 2013 and August 2014 confirm the following_
_treatment's in respect of [K's] conditions are available in Ghana:-_

_-            Carbamazepine to treat Epilepsy was available_

_-            Resperidone to treat anti-psychotic illness was available_

_-            Citalopram to treat depression, was not immediately available, but could be procured_
_privately within 2-3 weeks_

_-            Sumatriptan to treat migraine was not available but could be procured from the private_
_sector, such as a Chemist_

_-            There was no evidence Pizotifen to treat migraine was available, but Almotriptan which is_
_an alternative migraine medication was available and a further alternative Zolmitriptan, was not available_
_but could be procured through the private sector within 2-3 weeks_

_-            Ibrupofen to treat pain was available_

_-            Their [sic] was no evidence Anusol to treat rectal/anal pain was available, but as stated_
_above alternative pain relief medication is available_

_-            Outpatient treatment and follow-up by a psychiatrist was available, inpatient treatment by a_
_psychiatrist was available, and outpatient treatment and follow-up by a psychologist was available. It is_
_further noted the EMDR (Eye Movement Desensitization and Reprocessing) was available.”_

28. This was followed in paragraph 12 by the following:

_“On 27 September 2014, the Home Office Competent Authority requested current medical evidence of any_
_illnesses your client has, together with the treatment he currently receives and what the impact would be if_
_he could no longer receive that treatment.”_

In the next paragraph Mr Corcoran noted that “No response has been received to that request”.

29. Mr Corcoran then stated his conclusion as follows at paragraph 14:

_“If your client was returned to Ghana, based on the country information in the paragraphs above, it is_
_considered that medical treatment is available to treat his conditions. Although healthcare facilities in_
_Ghana may not be the same standard of healthcare as in the United Kingdom, your client would have been_
_able to seek treatment there.”_

30. The letter ended with Mr Corcoran making the point, which is not controversial, that K is not pursuing
compensation from his traffickers, and so this is not a reason why in his case leave to remain should be
granted.

_Additional material_

31. Subsequently, by a Consent Order dated 18 March 2015, the parties agreed, inter alia, that there may
be permission to rely on further evidence. K then filed his Amended Grounds the following month, on 15
April 2015, and three weeks after that, on 6 May 2015, the Defendant served her Detailed Grounds of
Defence.


-----

32. It is at this juncture that I need to address a dispute between Miss Meredith and Miss Bretherton as to
whether it is open to K to rely in these proceedings on additional material which was not before the
Competent Authority (Mr Corcoran) on 16 January 2015 when he made the decision which is under
challenge in these proceedings. The additional material consists of the following: the witness statement
from K dated 11 November 2015, to which I have previously referred; a statement from Mr Francis
Akinseye dated 9 November 2015; a witness statement from Ms Nina Rathbone Pullen, an assistant
solicitor at Wilsons, dated 11 November 2015; and an expert's report from Professor Benjamin Lawrance
dated 25 August 2015, in which a number of matters are addressed, including the availability of health care
in Ghana. Miss Bretherton submitted that this is evidence which all post-dates the decision made on 16
January 2015 and which as such is not material which could have been taken into account by Mr Corcoran
when he made that decision, so as to mean that it ought not to be taken into account when assessing the
lawfulness of the decision. Miss Bretherton also referred to the fact that K has introduced into the trial
bundle further published reports running to over a hundred pages of new material which was not provided
to Mr Corcoran at the time that he made his decision in January this year. She additionally pointed out that
there are also before the Court letters such as that from K's GP dated 16 July 2015 which post-date the
decision, and so are not strictly speaking relevant to the question of whether the decision was lawful.

33. Miss Meredith took issue with this. She submitted, first, that there _was medical evidence before Mr_
Corcoran when he made his decision; indeed, the decision letter dated 16 January 2015 specifically refers
to Dr Grant-Peterkin's report dated 16 January 2014. This is right but it is no answer to an objection which
concerns other medical evidence which was not before Mr Corcoran. As to this, Miss Meredith suggested
that there was additional medical evidence, although I am not clear what this was, in the bundle prepared
by Wilsons for the hearing in October 2014 which did not take place. However, it was acknowledged during
the hearing by Miss Meredith that this may not have found its way to Mr Corcoran, and that it was material
which had not otherwise been provided to him by K's solicitors.

34. Secondly, Miss Meredith observed that, as I have mentioned, the parties agreed by way of Consent
Order earlier this year that K could rely on additional evidence and set out a timetable for doing so (31 July
2015 as subsequently extended in correspondence to 28 August 2015). Thirdly, Miss Meredith made the
point that the Defendant made requests on four occasions between February and November this year in
which further evidence was sought. Lastly, Miss Meredith submitted that, as the Competent Authority, Mr
Corcoran is obliged to gather further evidence and reconsider further evidence where a 'conclusive
grounds' decision has been challenged (Competent Authority Guidance, paragraphs 12.7-8, 17.6 and
22.1), and in any event there is an ongoing duty under Article 4 to do these things.

35. I am not persuaded by these various points. In fairness, after the matter had been canvassed at the
hearing, Miss Meredith appeared to recognise that it was not appropriate that material which was not
before Mr Corcoran when he made his decision on 16 January 2015 should be taken into account, other
than possibly by way of updating of the position, in assessing the lawfulness of Mr Corcoran's decision. I
consider that it must be right that, in a case where a specific decision is being challenged, the review of the
lawfulness of that decision should focus on what was before the decision-maker when the decision was
made, and not on material which was not before the decision-maker. I consider that this is inherent in the
assessment of the legality of the decision and that to allow evidence which was not before the decisionmaker to enter into the evaluation of the lawfulness of the decision would not be appropriate.

36. Despite reference in her skeleton argument to _“a failure to discharge the Defendant's positive_
_obligations by way of a referral to and cooperation with the police”, as Miss Meredith ultimately_
acknowledged, this is not a case in which it has been alleged in the Amended Grounds for Judicial Review
that there was a freestanding failure by the Defendant to make a referral to the Police, at least in reliance
on matters which have happened since the decision was made on 16 January 2015. The focus is on the
lawfulness of the decision made on 16 January 2015. That is the position in relation to Ground (3) as much
as it is in relation to the other Grounds which are asserted, notwithstanding a suggestion in the document
submitted by Miss Meredith ahead of the hearing in reply to Miss Bretherton's skeleton argument that there
might be a freestanding claim advanced which extends beyond the 16 January 2015 decision. Ground (3),
as clarified by Miss Meredith at the hearing itself, consists of a challenge which entails the submission that,


-----

when making the decision on 16 January 2015, there was a breach of Article 4 in failing to exercise
anxious scrutiny having regard to the Defendant's previous failure to make a referral to the Police.
Similarly, although in relation to Ground (1) there was a broadening of the case which is put forward, as I
shall also come on to explain (see paragraph 104 below), the focus even in relation to this aspect is still on
the position as it stood in January this year when Mr Corcoran made the decision under challenge in these
proceedings. It follows that it is not relevant to have regard to material which was not before the decisionmaker, Mr Corcoran, in January this year.

37. In any event, dealing with the additional material which post-dates the January 2015 decision, it is not
clear to me that the further evidence from Dr Grant-Peterkin, in the form of a report dated 13 April 2015, in
which Dr Grant Peterkin confirms that K continues to need high level care and familial support in order to
recover from his experiences of trafficking and exploitation in Ghana and the UK, really adds much to what
was stated in his first report which was before Mr Corcoran and to which Miss Bretherton takes no
objection. In addition, in the present case it seems to me that much of what is contained in the various
witness statements, specifically that of K himself, is material which was before Mr Corcoran in January this
year because it was material which K told Dr Grant-Peterkin about and which was included in the report
prepared by him in January 2014 and specifically identified by Mr Corcoran in the 16 January 2015
decision letter. As to Mr Akinseye's witness statement, it does not seem to me that this greatly adds to the
task which I am presently engaged in. The same applies to the witness statement from K's solicitor and the
GP letter dated 16 July 2015.

38. Nor is this a case in which it has ever been contended on K's behalf that Mr Corcoran ought to have
had regard to published material, in the form of the reports which are before me but which were not before
him, and that because he did not have regard to such material his decision is unlawful (see Sufi & Elmi v
**_The United Kingdom (2012) 54 EHRR 9 at [230]-[231]). Again, this was ultimately acknowledged by Miss_**
Meredith, and correctly so given that, as she conceded, no such point was made in the Amended Grounds
for Judicial Review.

39. This leaves the expert evidence sought to be adduced in the form of the report from Professor
Lawrance. I do not consider it right to give weight to this report because it is not a report which was before
Mr Corcoran when he made the relevant decision and I do not regard it as appropriate to take the view that
it is a report which contains evidence sought by the Defendant in the various requests made since
February this year. It may be that, were a fresh decision to be made now by Mr Corcoran and were he not
to pay adequate regard to the report, the fresh decision would be vulnerable to attack (I should not be
taken as expressing any view about this), but that is not what the current proceedings are concerned with:
their focus is exclusively on the decision made by Mr Corcoran on 16 January 2015, a decision made when
the report was not before him. I might add that Miss Bretherton made the point also that the report appears
to have been based on the understanding that the 16 January 2015 decision involved reliance on the fact
that K had been trafficked historically and the stance that, as such, no protection was required (the reason
given in the 10 October 2013 decision letter) when that is not what was stated in the 16 January 2015
decision letter. It seems to me that there is force in this criticism but that it is not an answer to everything
stated in the report, the main focus of which is on the availability of health care in Ghana.

40. The position is different in relation to the question of K's co-operation with the Police, not because, in
my view, this impacts on the lawfulness of the decision made on 16 January 2015, since again events
which are subsequent to that decision can hardly be events which Mr Corcoran should have taken into
account when making the decision, but because it does seem that the Defendant has asked Wilsons
questions regarding K's co-operation. In the circumstances, although I am not persuaded that it is
appropriate that I take account of these matters when considering the lawfulness of the decision under
challenge in these proceedings, I go on nevertheless to set out what, in fact, has happened since the
decision was made. I do so, in the circumstances, only briefly.

41. Following correspondence with the National Crime Agency and the Bedfordshire Police on 15 April
2015, it was confirmed by the Police in Luton that there had been liaison with Mr Corcoran, as the
Competent Authority. In May 2015 K attended the Police station. Subsequently, after certain concerns
were raised by Wilsons about how K had been treated during that appointment K took part in two ABE


-----

interviews. Specifically, in a drive-around of the area following the first ABE interview in June 2015 he
identified the warehouse where he had been put to work. He was told that following the second ABE
interview he would be taken on another drive-around to find the house where he was held. The process
was, however, distressing for K.

42. Wilsons subsequently wrote to Mr Corcoran in June 2015, stating that his 16 January 2015 decision
did not properly consider leave on the basis of K's cooperation with the police. It was stated, in particular,
that K _“should not be expected to assist the UK police/Competent Authority without the security and the_
_access to rights and entitlements that a renewable residence permit provides. Indeed that is the purpose of_
_the residence permit”._ Subsequently, Wilsons asked Bedfordshire Police if they had requested the
Defendant to grant leave in accordance with their policy. On 5 August 2015, DC Knight replied saying that
he was “trying to get hold of [Mr Corcoran] so I can get it sorted”. K then had his second ABE interview on
30 September 2015, and on 23 October 2015 Bedfordshire Police stated that they had completed all
reasonable enquiries and were closing the investigation, explaining on 11 November 2015 that during this
second ABE interview it was:

_“with very obvious reason very difficult to get information … due to it being a very traumatic period… when_
_the subject of being sexually exploited was brought up, it was very difficult to get [K] to be more specific in_
_detail”._

**The law and the applicable policies**

43. Against this factual background and before coming on to consider the grounds relied upon by Miss
Meredith on behalf of K, I need first to explain the legal context within which this claim is brought. When
reading Miss Meredith's and Miss Bretherton's skeleton arguments, I had understood there to be a
considerable measure of agreement between the parties as to this, both Miss Meredith and Miss
Bretherton essentially setting out the same material in their respective skeleton arguments. However, it
emerged during the hearing that there were several matters in relation to which there was no agreement.
These include: first, the test which is to be applied by the Court when considering an application such as
this, specifically whether the Court is required to exercise 'anxious scrutiny'; secondly, the justiciability of
the Trafficking Convention; and thirdly, the point which directly arises in relation to Ground (2), the
lawfulness of the Defendant's applicable policies. Unfortunately, by the time that Miss Meredith came to
make her reply submissions the areas of dispute appeared to have widened still further, with Miss Meredith
making reference to various new authorities in what ought to have been relatively brief submissions but
which turned out to be somewhat longer than might have been expected.

44. It is convenient to deal with the first and second of these matters before addressing the various
Grounds relied on by Miss Meredith on behalf of K. However, before doing this, it is necessary in the first
place to set out the relevant legal context in which the two points arise.

_The Trafficking Convention and the 2011 Directive_

45. As Miss Meredith pointed out, the right to freedom from slavery was the first human right to be
protected by an international treaty followed by a number of other international instruments preventing
slavery and trafficking: the 1885 Berlin Treaty; the 1926 Slavery Convention; the 1930 ILO Convention No.
29 on Forced or Compulsory Labour; the 1948 Universal Declaration on Human Rights; the 1956
Supplementary Convention on the Abolition of Slavery, the Slave Trade, and Institutions and Practices
Similar to Slavery; the 1966 International Covenant on Civil and Political Rights; and the 2000 UN
Organised Crime Convention and UN Trafficking Protocol (the 'Palermo Protocol'). Lord Hughes
summarised the position in Hounga v Allen and another (Anti-Slavery International intervening) _[2014]_
_UKSC 47 at [60] and [61]:_

_“60.            Human trafficking is a very serious crime, recognised both internationally and nationally._
_Those who practise it can expect, and receive in England and Wales, severe penalties. The position of_
_those who have been transported is, however, more complex. First, the line between (on the one hand)_
_trafficking properly so called and (on the other) the often rapacious demands for money made by agents of_
_persons who are only too keen to be transported to a western country may sometimes be difficult to_


-----

_discern in a particular case. The latter situation is generally referred to as smuggling, to distinguish it from_
_trafficking. Second, assuming that the case is indeed one of trafficking, properly so called, the question_
_arises how offences committed by the trafficked person ought to be treated._

_61.            The UK is bound by a series of international instruments, all of which adopt the same_
_definition of trafficking, which originates in the Protocol to the UN Convention against Transnational_
_Organised Crime, 2000 ('the Palermo Protocol'), ratified by the UK on 9 February 2006. The accepted_
_definition is, as set out by Lord Wilson:_

_'For the purposes of this Protocol:_

_(a) 'Trafficking in persons' shall mean the recruitment, transportation, transfer, harbouring or receipt of_
_persons, by means of the threat or use of force or other forms of coercion, of abduction, of fraud, of_
_deception, of the abuse of power or of a position of vulnerability or of the giving or receiving of payments or_
_benefits to achieve the consent of a person having control over another person, for the purpose of_
_exploitation. Exploitation shall include, at a minimum, the exploitation of the prostitution of others or other_
_forms of sexual exploitation, forced labour or services, slavery or practices similar to slavery, servitude or_
_the removal of organs;_

_(b) The consent of a victim of trafficking in persons to the intended exploitation set forth in subparagraph_
_(a) of this article shall be irrelevant where any of the means set forth in subparagraph (a) have been used;_

_(c) The recruitment, transportation, transfer, harbouring or receipt of a child for the purpose of exploitation_
_shall be considered 'trafficking in persons' even if this does not involve any of the means set forth in_
_subparagraph (a) of this article.'”_

46. As Lord Hughes went on to say, the same definition appears in subsequent international instruments,
as well as the Trafficking Convention, which was ratified by the United Kingdom on 17 December 2008,
and the directly effective EU Directive 2011/36/EU on Preventing and Combating Trafficking in Human
Beings and Protecting its Victims ('the 2011 Directive'), which came into effect on 6 April 2013.

47. As to the 2011 Directive, Article 2.1 provides that Member States “shall take the necessary measures
_to ensure that the following intentional acts are punishable” and then lists those acts as follows:_

“The recruitment, transportation, transfer, harbouring or reception of persons, including the exchange or
_transfer of control over those persons, by means of the threat or use of force or other forms of coercion, of_
_abduction, of fraud, of deception, of the abuse of power or of a position of vulnerability or of the giving or_
_receiving of payments or benefits to achieve the consent of a person having control over another person,_
_for the purpose of exploitation.”_

Article 2.2 goes on to state that:

_“A position of vulnerability means a situation in which the person concerned has no real or acceptable_
_alternative but to submit to the abuse involved”._

48. As for the Trafficking Convention, Article 4 of the Trafficking Convention defines “Trafficking in human
_beings” as meaning:_

_“the recruitment, transportation, transfer, harbouring or receipt of persons, by means of the threat or use of_
_force or other forms of coercion, of abduction, of fraud, of deception, of the abuse of power or of a position_
_of vulnerability or of the giving or receiving of payments or benefits to achieve the consent of a person_
_having control over another person, for the purpose of exploitation. Exploitation shall include, at a_
_minimum, the exploitation of the prostitution of others or other forms of sexual exploitation, forced labour or_
_services, slavery or practices similar to slavery, servitude or the removal of organs”._

49. Article 10 (“Identification of the victims”) then goes on to provide as follows:

_“1 Each Party shall provide its competent authorities with persons who are trained and qualified in_
_preventing and combating trafficking in human beings, in identifying and helping victims, including children,_
_and shall ensure that the different authorities collaborate with each other as well as with relevant support_


-----

_organisations, so that victims can be identified in a procedure duly taking into account the special situation_
_of women and child victims and, in appropriate cases, issued with residence permits under the conditions_
_provided for in Article 14 of the present Convention._

_2 Each Party shall adopt such legislative or other measures as may be necessary to identify victims as_
_appropriate in collaboration with other Parties and relevant support organisations. Each Party shall ensure_
_that, if the competent authorities have reasonable grounds to believe that a person has been victim of_
_trafficking in human beings, that person shall not be removed from its territory until the identification_
_process as victim of an offence provided for in Article 18 of this Convention has been completed by the_
_competent authorities and shall likewise ensure that that person receives the assistance provided for in_
_Article 12, paragraphs 1 and 2.”_

50. Picking up on the reference in Article 10(1) to the obligation “in appropriate cases, to issue residence
_permits in the manner laid down in Article 14”, Article 14 (“Residence permit”) is then in the following terms:_

_“1 Each Party shall issue a renewable residence permit to victims, in one or other of the two following_
_situations or in both:_

_a the competent authority considers that their stay is necessary owing to their personal situation;_

_b the competent authority considers that their stay is necessary for the purpose of their co-operation with_
_the competent authorities in investigation or criminal proceedings._

_…_

_3 The non-renewal or withdrawal of a residence permit is subject to the conditions provided for by the_
_internal law of the Party._

_4 If a victim submits an application for another kind of residence permit, the Party concerned shall take_
_into account that he or she holds, or has held, a residence permit in conformity with paragraph 1._

_5 Having regard to the obligations of Parties to which Article 40 of this Convention refers, each Party shall_
_ensure that granting of a permit according to this provision shall be without prejudice to the right to seek_
_and enjoy asylum.”_

51. Earlier, Article 12 (“Assistance to victims”) states:

_“1 Each Party shall adopt such legislative or other measures as may be necessary to assist victims in their_
_physical, psychological and social recovery. Such assistance shall include at least:_

_a standards of living capable of ensuring their subsistence, through such measures as: appropriate and_
_secure accommodation, psychological and material assistance;_

_b access to emergency medical treatment;_

_c translation and interpretation services, when appropriate;_

_d counselling and information, in particular as regards their legal rights and the services available to them,_
_in a language that they can understand;_

_e assistance to enable their rights and interests to be presented and considered at appropriate stages of_
_criminal proceedings against offenders;_

_f access to education for children._

_2 Each Party shall take due account of the victim's safety and protection needs._

_3 In addition, each Party shall provide necessary medical or other assistance to victims lawfully resident_
_within its territory who do not have adequate resources and need such help._

_4 Each Party shall adopt the rules under which victims lawfully resident within its territory shall be_
_authorised to have access to the labour market, to vocational training and education._


-----

_5 Each Party shall take measures, where appropriate and under the conditions provided for by its internal_
_law, to co-operate with non-governmental organisations, other relevant organisations or other elements of_
_civil society engaged in assistance to victims._

_6 Each Party shall adopt such legislative or other measures as may be necessary to ensure that_
_assistance to a victim is not made conditional on his or her willingness to act as a witness._

_7 For the implementation of the provisions set out in this article, each Party shall ensure that services are_
_provided on a consensual and informed basis, taking due account of the special needs of persons in a_
_vulnerable position and the rights of children in terms of accommodation, education and appropriate health_
_care.”_

52. This is followed by Article 13 (“Recovery and reflection period”):

_“1 Each Party shall provide in its internal law a recovery and reflection period of at least 30 days, when_
_there are reasonable grounds to believe that the person concerned is a victim. Such a period shall be_
_sufficient for the person concerned to recover and escape the influence of traffickers and/or to take an_
_informed decision on cooperating with the competent authorities. During this period it shall not be possible_
_to enforce any expulsion order against him or her. This provision is without prejudice to the activities_
_carried out by the competent authorities in all phases of the relevant national proceedings, and in particular_
_when investigating and prosecuting the offences concerned. During this period, the Parties shall authorise_
_the persons concerned to stay in their territory._

_2 During this period, the persons referred to in paragraph 1 of this Article shall be entitled to the measures_
_contained in Article 12, paragraphs 1 and 2._

_3 The Parties are not bound to observe this period if grounds of public order prevent it or if it is found that_
_victim status is being claimed improperly.”_

53. In practical terms, Miss Meredith helpfully explained that the NRM was established in order to
implement the UK's trafficking obligations under Trafficking Convention and came into force in the UK on 1
April 2009. There is no governing legislation giving effect to those obligations. This is instead set out in
various policies of the Defendant, as I shall explain. However, in brief summary, the position is as follows.
First, a designated First-Responder (law enforcement agencies, the Salvation Army, and NGOs) makes a
referral to a Competent Authority, either the Home Office in immigration cases involving third country
nationals, or in other cases the UK Human Trafficking Centre. Secondly, an initial decision based on
reasonable grounds that the person has been trafficked (on a lower standard) is made within a target of 5
days from referral. Temporary admission is usually granted following a reasonable grounds decision and
victims should not be removed from the territory: Article 10(2). Victims are not detained absent very
exceptional circumstances (see Enforcement Instructions and Guidance _Identifying Victims of Trafficking_
(the 'EIG'), Chapters 9 and 55). The Competent Authority shall ensure that that person receives the
assistance provided for: the Trafficking Convention, Articles 12(1) and (2). Article 13(1) requires that
victims recognised on reasonable rounds be granted a recovery and reflection period _“sufficient for the_
_person concerned to recover and escape the influence of traffickers and/or to take an informed decision on_
_cooperating with the competent authorities. During this period it shall not be possible to enforce any_
_expulsion order against him or her.” Victims shall be provided with assistance and support pursuant to_
Article 12(2) during this period (Article 13(2)). Thirdly, at the end of a target of 45 days, the Competent
Authority makes a conclusive grounds decision that the person was trafficked (based on the balance of
probabilities). With conclusive status, there is no automatic grant of discretionary leave for one year and
one day, although this _may be granted if the individual is co-operating with the Police or owing to their_
personal circumstances (under Article 14 of the Trafficking Convention). Leave to remain as a victim is
without prejudice to any other entitlement to leave as a refugee (a category of immigration leave).

54. Miss Bretherton took no issue with this summary, which reflected the summary given by Aikens LJ in R
**_(on the application of Atamewan) v Secretary of State for the Home Department [2014] 1 WLR 1959,_**

_[2013] EWHC 2727 (Admin) at [72] to [74]:_


-----

_“72            … First, each Party has to undertake an investigation to see if there are 'Reasonable_
_Grounds' for believing that a person has been the victim of trafficking. The phraseology of the sentence_
_suggests that this exercise in itself does not involve any assessment of other needs of the victim._
_Secondly, if the conclusion is that there are 'Reasonable Grounds' for concluding that the person has been_
_a 'victim', then there is an obligation on the Party not to remove the person concerned from the territory of_
_the Party until the identification process has been completed. That obligation is clear and unqualified._
_Thirdly, if there are 'Reasonable Grounds' then there is an obligation to ensure that the person receives the_
_assistance set out in Article 12(1) and (2). It is at that stage, after the conclusion that there are 'Reasonable_
_Grounds' to believe that the person has been the victim of trafficking, that there is room for an assessment_
_of needs, because that is explicit in Article 12(2) itself. But, in my view, this third obligation is separate from_
_the second one in Article 10(2) second sentence that I have identified, viz. not to remove the person from_
_the territory until the identification process as victim of an offence provided for in Article 18 has been_
_completed._

_73            Article 12(1) sets out Parties' obligations as to the minimum level of assistance that is to_
_be provided to a person whom the Competent Authorities have concluded there is a 'Reasonable Ground'_
_for believing he or she is a 'victim'. But this obligation is qualified by Article 12(2), because that obliges_
_each Party to take account of the victim's 'safety and protection needs'. Therefore, if the needs are great,_
_the level of assistance must be greater; but, equally, if they are minimal or they become minimal, it seems_
_to me that the obligation to provide the assistance will be accordingly reduced or exhausted._

_74            This, in my view, is the answer to Mr Eadie's suggestion in his written submissions that_
_the logical conclusion of the claimant's submission on the meaning of Articles 4 and 10(2) is that 'victim_
_status' at the 'Reasonable Grounds' stage would lead to that person being entitled to assistance for life and_
_long after the traumas of being a victim of trafficking had passed. CAT plainly did not contemplate that and,_
_in my view, the proper interpretation of Articles 4 and 10(2) does not lead to that conclusion.”_

55. As to the assessment of needs to which Aikens LJ referred, he went on at [79] and [80] as follows:

“79  The scheme of Article 14 also fits in with my interpretation of Articles 4 and 10(2). The obligation to
_issue a renewable residence permit is not absolute, but will only arise if one of the two situations set out in_
_(a) and (b) arise. A permit can be withdrawn or not renewed in the circumstances set out in Article 14(3). In_
_other words, a conclusion that there are 'Reasonable Grounds' does not automatically mean that a Party_
_must grant a renewable residence permit._

_80            In argument Mr Eadie posed the rhetorical question: what is to happen in the case of_
_someone who was trafficked to the UK 30 years ago but has managed to create a new life for himself for_
_many years since then? My answer would be that, if that person then came forward and claimed he was_
_the victim of trafficking all those years ago, the Article 10(2) process of deciding whether there were_
_'Reasonable Grounds' for believing he was trafficked would have to be undertaken. On the assumption that_
_the test was satisfied, Article 13 is unlikely to apply as the person will probably have obtained a right to_
_reside in the UK in the meantime. The second obligation under the second sentence of Article 10(2) would_
_apply, but that would be subject to Article 14. Articles 14(1)(b) and (3) would be particularly relevant. Article_
_12 would be applicable, but the provision in Article 12(2) would be highly relevant in such a case. It may be_
_that, after 30 years, not much (if any) further assistance was needed apart from assistance regarding_
_investigation and possible prosecution of the offences to which he had been subject. Each case, would, of_
_course, depend on the particular facts involved.”_

56. Otherwise Article 16 of the Trafficking Convention should also be mentioned. This deals with
repatriation, Article 16(2) in particular stating as follows:

_“When a party returns a victim to another State, such return shall be with due regard for the rights, safety_
_and dignity of that person and for the status of any legal proceedings related to the fact that the person is a_
_victim, and shall preferably be voluntary.”_

57. Miss Meredith also highlighted the fact that Article 40(4) provides that the Trafficking Convention “shall
_not affect the rights, obligations and responsibilities of States and individuals under international law”,_


-----

including specifically the 1951 Refugee Convention. Similarly, she pointed out, Article 7(1) of the Palermo
Protocol calls on State Parties to consider adopting legislative or other appropriate measures that permit
trafficked persons to remain in the territory of the host country, temporarily or permanently, in appropriate
cases. In implementing such measures, Article 7(2) requires State Parties to give appropriate consideration
to humanitarian and compassionate factors. Moreover, Miss Meredith went on additionally to show that
there is a clear emphasis in the Trafficking Convention on victim protection and human rights. She
suggested that this is demonstrated in particular by the following Articles:

(1) Article 1(b) (“Purposes of the Convention”), stating that the purposes of the Trafficking Convention
include being “to protect the human rights of the victims of trafficking, design a comprehensive framework
_for the protection and assistance of victims and witnesses, while guaranteeing gender equality, as well as_
_to ensure effective investigation and prosecution”._

(2) Article 3 (“Non-discrimination principle”):

_“The implementation of the provisions of this Convention by Parties, in particular the enjoyment of_
_measures to protect and promote the rights of victims, shall be secured without discrimination on any_
_ground such as sex, race, colour, language, religion, political or other opinion, national or social origin,_
_association with a national minority, property, birth or other status.”_

(3) Article 5(3) (“Prevention of trafficking in human beings”):

_“Each Party shall promote a Human Rights-based approach and shall use gender mainstreaming and a_
_child-sensitive approach in the development, implementation and assessment of all the policies and_
_programmes referred to in paragraph 2.”_

(4) Article 10(2) (“Identification of the victims”):

_“Each party shall adopt such legislative or other measures as may be necessary to identify victims as_
_appropriate in collaboration with other Parties and relevant support organisations. Each Party shall ensure_
_that, if the competent authorities have reasonable grounds to believe that a person has been victim of_
_trafficking in human beings, that person shall not be removed from its territory until the identification_
_process as victim of an offence provided for in Article 18 of this Convention has been completed by the_
_competent authorities and shall likewise ensure that that person receives the assistance provided for in_
_Article 12, paragraphs 1 and 2.”_

The same can be seen, Miss Meredith suggested, from the fact that Chapter III is entitled _“Measures to_
_protect and promote the rights of victims, guaranteeing gender equality”, this being the chapter which_
contains Article 14.

58. Miss Meredith also highlighted that what might be termed 'the human rights approach' is consistent
with EU law, the EU Council Framework Decision on trafficking 2002/629/JHA having been replaced by the
2011 Directive so that, as stated in Recital (30), the substantial number of amendments made were in the
interests of clarity in one place. This is further borne out by the following recitals, all of which confirm 'the
human rights approach' contained in the 2011 Directive:

(1)   Recital (1):

_“Trafficking in human beings is a serious crime, often committed within the framework of organised crime, a_
_gross violation of fundamental rights and explicitly prohibited by the Charter of Fundamental Rights of the_
_European Union. Preventing and combating trafficking in human beings is a priority for the Union and the_
_Member States.”_

(2)   Recital (7):

_“This Directive adopts an integrated, holistic, and human rights approach to the fight against trafficking in_
_human beings and when implementing it, Council Directive 2004/81/EC of 29 April 2004 on the residence_
_permit issued to third-country nationals who are victims of trafficking in human beings or who have been_
_the subject of an action to facilitate illegal immigration, who cooperate with the competent authorities and_
_Directive 2009/52/EC of the European Parliament and of the Council of 18 June 2009 providing for_


-----

_minimum standards on sanctions and measures against employers of illegally staying third-country_
_nationals should be taken into consideration. More rigorous prevention, prosecution and protection of_
_victims' rights, are major objectives of this Directive. This Directive also adopts contextual understandings_
_of the different forms of trafficking and aims at ensuring that each form is tackled by means of the most_
_efficient measures.”_

(3)   Recital (33):

_“This Directive respects fundamental rights and observes the principles recognised in particular by the_
_Charter of Fundamental Rights of the European Union and notably human dignity, the prohibition of_
_slavery, forced labour and trafficking in human beings, the prohibition of torture and inhuman or degrading_
_treatment or punishment, the rights of the child, the right to liberty and security, freedom of expression and_
_information, the protection of personal data, the right to an effective remedy and to a fair trial and the_
_principles of the legality and proportionality of criminal offences and penalties. In particular, this Directive_
_seeks to ensure full respect for those rights and principles and must be implemented accordingly.”_

59. Lastly, before coming on to consider the Defendant's relevant policies, reference was also made by
Miss Meredith to the Explanatory Report to the Trafficking Convention. This states as follows at paragraphs
180 to 185 in the section dealing with Article 14:

_“180.            Article 14(1) provides that victims of trafficking in human beings shall issue with_
_renewable residence permits. Provision for a residence permit meets both victims' needs and the_
_requirements of combating the traffic._

_181.            Immediate return of the victims to their countries is unsatisfactory both for the victims_
_and for the law-enforcement authorities endeavouring to combat the traffic. For the victims this means_
_having to start again from scratch – a failure, that in most cases, they will keep quiet about, with the result_
_that nothing will be done to prevent other victims from falling into the same trap. A further factor is fear of_
_reprisals by the traffickers, either against the victims themselves or against family of friends in the country_
_of origin. For the law enforcement authorities, if the victims continue to live clandestinely in the country or_
_are removed immediately they cannot give information for effectively combating the traffic. The greater_
_victims' confidence that their rights and interests are protected, the better the information they will give._
_Availability of residence permits is a measure calculated to encourage them to cooperate._

_182.            The two requirements laid down in Article 14(1) for issue of a residence permit are that_
_either the victim's stay be 'necessary owing to their personal situation' or that it be necessary 'for the_
_purpose of their cooperation with the competent authorities in investigation or criminal proceedings'. The_
_aim of these requirements is to allow Parties to choose between granting a residence permit in exchange_
_for cooperation with the law-enforcement authorities and granting a residence permit on account of the_
_victim's needs, or indeed to adopt both simultaneously._

_183.            Thus, for the victim to be granted a residence permit, and depending on the approach_
_the Party adopts, either the victim's personal circumstances must be such that it would be unreasonable to_
_compel them to leave the national territory, or there has been an investigation or prosecution with the_
_victim cooperating with the authorities. Parties likewise have the responsibility of issuing residence permits_
_in both situations._

_184.            The personal situation requirement takes in a range of situations, depending on_
_whether it is the victim's safety, state of health, family situation or some other factor which has to be taken_
_into account._

_185.            The requirement of the cooperation with the competent authorities has been introduced_
_in order to take into account that victims are deterred from contacting the national authorities by fear of_
_being immediately sent back to their country of origin as illegal entrants to the country of exploitation …”._

_Relevant Home Office policies_

60. Turning, then, to the Defendant's policies, as Miss Bretherton went on to explain, the primary issue in
th **_At_** h th th H Offi li i f t th ti l f l Aik LJ


-----

explaining at [69] and [70] that the reference in the relevant 2010 Guidance to the approach to be adopted
as regards historic victims of trafficking was wrong in law, as indeed had been conceded on the Secretary
of State's behalf. Since judgment in the Atamewan case, however, the Guidance has been amended; it no
longer contains the deficiencies identified by Aikens LJ precisely because it was changed in the wake of
his decision and with effect from 30 October 2013.

61. There have been as many as five separate policies in force in the period from October 2013 to the
present, namely: (i) _Victims of human trafficking – Competent Authority Guidance (v.1.0 – 24 October_
2013) (the 'Competent Authority Guidance'); (ii) Victims of human trafficking: Guidance for frontline staff, (v.
5.0 - 21 January 2013) (the 'Frontline Staff Guidance v.5.0'); and (iii) Chapter 9 EIG (v.5.3 - 27 November
2013 ('Ch 9 EIG'); although in the period from 31 July 2015 to date (and so not relevant to the decision
made on 16 January 2015) two versions of the published policy were amended (largely to cover victims of
trafficking and **_modern slavery as a result of the_** **_Modern Slavery Act), namely (iv)_** _Victims of_ **_Modern_**
**_Slavery – Competent Authority Guidance_** (v.2.0 – 31 July 2015) (the 'Competent Authority **_Modern_**
**_Slavery Guidance'), and (v) Victims of Modern Slavery – Frontline Staff Guidance (v.2.0 – 31 July 2015)_**
(the 'Frontline Staff Modern Slavery Guidance'). In addition, there was also the Asylum Policy Instruction
on Discretionary Leave (v.6.0 – 24 June 2013) (the 'Asylum Policy Instruction'), guidance now replaced by
the Asylum Policy Instruction on Discretionary Leave (v.7.0 – 18 July 2015).

62. The Frontline Staff Guidance v.5.0 states at page 51:

_“Reasonable grounds decision_

_The competent authority will apply a 'reasonable grounds' test to consider if a reasonable person, having_
_regard to the information in the mind of the competent authority, would hold the opinion 'I suspect but_
_cannot prove' the claimant is a victim of human trafficking. They will consider the information provided by_
_the first responder along with any other evidence available._

_The competent authority works to a target of five working days from the date UKHTC receive the referral._
_During this period they may contact the first responder for further information. If a case needs to be fast_
_tracked, for example, when the person is detained or being prosecuted for a criminal offence, the_
_competent authority will prioritise the case to reach the reasonable grounds decision as soon as possible._

_If they find there are reasonable grounds to believe someone is a potential victim of trafficking, they will_
_grant them a minimum of 45 calendar days for recovery and reflection. No detention or removal action is_
_taken against the potential victim during this time unless it is justified on public protection or public order_
_grounds._

_…_

**_NRM - conclusive grounds decision_**

_If a competent authority makes a positive reasonable grounds decision, they then conclusively decide if the_
_individual is a victim of trafficking. The expectation is a decision will be made after 45 calendar days.”_

63. The Asylum Policy Instruction states at paragraph 2.4 (“Trafficking cases”):

_“A grant of DL should be considered where a UK Competent Authority has conclusively identified that_
_person as a victim of trafficking within the meaning of Article 4 of the Council of Europe Convention on_
_Action Against Trafficking in Human Beings and the individual's personal circumstances, although not_
_meeting the criteria of any of the other categories listed, are so compelling that it is considered appropriate_
_to grant some form of leave in line with the Duration of Grants of Leave below._

_A grant of DL should be considered where the victim has lodged a legitimate compensation claim against_
_the trafficker and a grant of leave would help secure justice for the trafficked person and assist in ensuring_
_the trafficker faces the consequences of their actions. The fact that someone is seeking compensation will_
_be relevant to the consideration but does not, in itself, merit a grant of leave. Leave must only be granted_
_where it would be unreasonable for them to pursue that claim from outside of the UK._


-----

_If an individual is cooperating with an ongoing police investigation in relation to their trafficking case and_
_their presence is required for this purpose it may be appropriate to grant leave.”_

It goes on to state this at paragraph 4.5:

_“4.5            Trafficking cases_

_-            Where the UK Competent Authority has conclusively identified the applicant as a victim of_
_trafficking and the personal circumstances of the case are so compelling that a grant of leave is considered_
_appropriate, DL should be granted. The period of leave will depend on the individual facts of the case but_
_must not be less that 12 months and 1 day and normally no more that 30 months (2.5 years). The minimum_
_period of leave ensures that a victim if trafficking who is refused asylum but granted DL has a right of_
_appeal against the rejection of their asylum claim by virtue of_ _[Section 83(1)(b) of the Nationality,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:8053-K4Y0-Y97X-70GW-00000-00&context=1519360)_
_Immigration and Asylum Act 2002._

_-            Where the UK Competent Authority has conclusively identified the applicant as a victim of_
_trafficking and the individual is cooperating with the police in an ongoing police investigation into their_
_trafficking case and their presence is required in the UK by the police for this purpose, they should be_
_granted 12 months and 1 day DL. A further period of leave may be granted where appropriate.”_

64. The Competent Authority Guidance states as follows at page 98:

_“Personal circumstances_

_When you make a conclusive decision and the person does not meet the criteria for any of the other leave_
_or protection categories, it may be appropriate to grant a victim of trafficking discretionary leave if their_
_personal circumstances are compelling. For example, to allow them to finish a course of medical treatment_
_that would not be readily available if they were to return home. This must be considered in line with the_
_discretionary leave policy (see related link). Unless further information has come to light, you do not need_
_to reconsider a grant of discretionary leave if it has already been considered together with a related asylum_
_claim.”_

It then states at page 101:

_“Victims who are assisting with police enquiries from the UK_

_Under the Council of Europe Convention on Action Against Trafficking in Human Beings (the convention)_
_the Home Office may grant a period of 12 months discretionary leave where a victim has agreed to_
_cooperate with police enquiries. Where a person is conclusively found to be a victim of trafficking and has_
_agreed to assist with police enquiries from the UK, the police must make a formal request for them to be_
_granted leave to remain on this basis. This may be extended where necessary, for example, where a_
_criminal prosecution takes longer than expected and the police have confirmed or requested an extension.”_

_The proper legal approach to NRM decisions_

65. Lastly, before coming on to consider the grounds raised by Miss Meredith on behalf of K, it is
convenient to set out some further authorities since both Miss Meredith and Miss Bretherton cited a
number of cases, Miss Bretherton mainly in relation to reliance on Article 4. Starting with the cases relied
upon by Miss Meredith, there was an issue between Miss Meredith and Miss Bretherton as to whether in
cases such as the present 'anxious scrutiny' is demanded in the decision-maker's assessment of whether
or not a person has been trafficked and in the Court's assessment of that decision (as Miss Meredith
contended) or whether the correct approach entails the application of Wednesbury principles only (as Miss
Bretherton contended).

66. This issue was recently considered by Mr Philip Mott QC (sitting as a Deputy High Court Judge) in R
(FM) v Secretary of State for the Home Department [2015] EWHC 844 (Admin):

_“30.            In relation to the standard of review, Mr Buttler submits that the test is one of 'anxious_
_scrutiny', which applies whenever fundamental human rights are in issue. He points to the fundamental and_
_non-derogable nature of Article 4 of the ECHR, and relies on the European Court decision in Rantsev._


-----

_Anxious scrutiny applies to the qualified Article 8 rights on a fresh claim for leave to remain, so even more_
_it should apply to the absolute right set out in Article 4 of the ECHR. The practical consequences of the_
_challenged decision are serious, involving a liability to detention and removal from the UK, and therefore_
_inability to participate in any police investigation or to access the counselling she has been assessed as_
_needing. He submits that the practical effect of the anxious scrutiny test is 'the need for decisions to show_
_by their reasoning that every factor which might tell in favour of an applicant has been properly taken into_
_[account' (R (YH) v SSHD [2010] 4 All ER 448, at paragraph 24). Whether a consideration is relevant to the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5196-W261-DYBP-M484-00000-00&context=1519360)_
_decision is a matter of law (R (Sainsbury's Supermarkets Ltd) v Wolverhampton CC [2011] 1 AC 437, at_
_paragraph 70)._

_31.            Mr Jowett does not accept that this is an 'anxious scrutiny' case, but even if it is the_
_Defendant has complied with it. He submits that the standard Wednesbury test applies, though bearing in_
_mind that 'The more substantial the interference with human rights, the more the court will require by way_
_of justification before it is satisfied that the decision is reasonable' (R (Q) v SSHD [2004] QB 36, at_
_paragraph 115). This is, he says, neither such a serious decision as was contemplated in R (Yogathas) v_
_SSHD [2003] 1 AC 920(paragraphs 9 and 58), nor is it 'final' because the Claimant can still make fresh_
_claim submissions under Part 12 of the Immigration Rules, when anxious scrutiny would apply._

_32.            If anxious scrutiny does apply, it is accepted on both sides that as a result the Defendant_
_would bear the burden of justifying the decision; the review is still one for error of law, not correctness; and_
_anxious scrutiny 'does not mean that the court should strive by tortuous mental gymnastics to find error in_
_the decision when in truth there has been none. The concern of the court ought to be substance not_
_[semantics' (R (Sarkisian) v IAT [2001] EWHC Admin 486, at paragraph 18).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VGC1-DYBP-P0CC-00000-00&context=1519360)_

_33.            Any decision by a public body which affects the rights of an individual now is expected to_
_include reasons. The extent of the reasons required will vary according to the circumstances. In some_
_cases, it may be enough simply to say that a possible basis of claim has been considered and rejected (an_
_example of this in a different context is the consideration of Article 8 claims outside the Immigration Rules,_
_see R (Nagre) v SSHD [2013] EWHC 720 (Admin), at paragraph 30). In others, very much more detailed_
_justification and explanation will be expected, especially where the effect of the decision is great._

_34.            The concept of 'burden of proof' in judicial review cases is not always apt, since_
_witnesses generally are not heard and challenged, issues of credibility of witnesses do not generally arise,_
_and the material is accepted at its highest in favour of the claimant. If a better term is 'burden of_
_justification' or 'burden of explanation', the public body will always bear some burden because some_
_reasons are always expected. The weight of that burden will be variable according to the circumstances, as_
_appears in the quotation from Q set out above. At its highest, the term 'anxious scrutiny' has become a_
_shorthand description for the much greater detail of reasoning described in YH._

_35.            In my judgment, for the reasons put forward by Mr Buttler, this is an anxious scrutiny_
_case, but the conclusions which I reach below would be the same on the approach submitted as correct by_
_Mr Jowett.”_

67. It will be apparent from what is stated by Mr Mott QC in these passages that he was addressing not
only the question of whether the decision-maker should exercise 'anxious scrutiny' but also the question of
whether the Court, in reviewing the decision made by the decision-maker, should exercise 'anxious
scrutiny'. The same approach was adopted, albeit without, it seems, there being any dispute about the
relevant test, by Miss Helen Mountfield QC (sitting as a Deputy High Court Judge) in R (Minh) v Secretary
**_of State for the Home Department_** _[2015] EWHC 1725 (Admin) at [4]. That was a case involving a_
Vietnamese man who was detained when entering this country in the back of a lorry. The decision-maker
reached a decision that there were 'no reasonable grounds' to conclude that he was a victim of trafficking.
In these circumstances, as Miss Mountfield QC explained at [2], the Court's role was: “not to determine for
_itself whether there were or not such reasonable grounds, but to decide whether the decision-maker_
_properly addressed himself to the right legal issue, and reached his decision on the basis of a rational_
_application of the Defendant's policy guidance as to how this issue should be approached”. Miss Mountfield_
QC then went on to say this, basing what she had to say in part on Mr Mott QC's decision in the FM case:


-----

_“3.            However, as well as an ordinary public law challenge, the Claimant says that the_
_Defendant's failure correctly to apply her own Guidance meant that there was a breach of Article 4 of the_
_European Convention on Human Rights (ECHR), which imposes positive obligations to take proportionate_
_steps to investigate where there are indications that a person might have been subjected to trafficking by a_
_third party._

_4.            In those circumstances, where fundamental human rights are in issue, I am required to_
_give anxious scrutiny to the decisions which the Defendant reached, and to be satisfied that the decisions:_
_'show by their reasoning that every factor which might tell in favour of an applicant has been properly taken_
_[into account.' (R(FM) v SSHD [2015] EWHC 844 (Admin) at [30], quoting R(YH) v SSHD [2010] 4 All ER](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5196-W261-DYBP-M484-00000-00&context=1519360)_
_[448 at 24).The greater the likely impact of a decision on the rights of the person affected, the greater the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5196-W261-DYBP-M484-00000-00&context=1519360)_
_detailed justification and explanation which will be expected._

_5.            Nonetheless, I remind myself that the Court's task is one of review for error of law, not_
_correctness, and that anxious scrutiny: 'does not mean that the court should strive by tortuous mental_
_gymnastics to find error in the decision when in truth there has been none. The concern of the court ought_
_[to be substance not semantics.' (FM at [32], quoting R(Sarkisian) v IAT [2001] EWHC Admin 486 at [18]).”](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:59MP-VGC1-DYBP-P0CC-00000-00&context=1519360)_

68. Miss Meredith also placed heavy reliance on a more recent decision still, R (SF) v Secretary of State
**_for the Home Department_** _[2015] EWHC 2705 (Admin). In that case Sir Stephen Silber began his_
judgment by explaining at [2] that a decision of the Competent Authority in relation to whether a person is a
victim of trafficking “is of critical importance as it not only affects the position of the victim of trafficking, but
_it also affects the ability of the State to mount effective prosecutions against traffickers”. The Competent_
Authority decided that SF was not a victim of trafficking, in contrast to the position in the present case
where Mr Corcoran decided that K is such a victim. The challenge before Sir Stephen was, therefore, in
relation to that decision, not a decision as to whether a victim should be permitted to remain in this country.
The judge explained at [5] that there was a dispute before him as to how the Court should approach the
challenge which had been made. He summarised the claimant's position at [6]:

_“Thus the case for the Claimant is that heightened or more rigorous scrutiny should be applied and that_
_there is in the words of Carnwath LJ in R(YH) v Secretary of State [2010] EWCA Civ 116 [24]:_

_'the need for decisions to show by their reasoning that every factor which tells in favour of the applicant has_
_been properly taken into account'.”_

He then went on at [7] to explain that the Secretary of State's position was that the appropriate approach
was the standard Wednesbury approach.

69. The judge then dealt with the matter at [84] to [104] of the judgment. He began by again setting out the
parties' rival contentions at [84] and [85]:

_“84.            It is common ground that this application is not an appeal on the merits, but there is a_
_dispute between the parties as to the appropriate level of scrutiny this Court should adopt in determining_
_the present dispute. The case for the Claimant is that heightened or more rigorous scrutiny should be_
_applied because of the nature of the issues, especially as they will have a decisive impact on whether the_
_Claimant will be able to enjoy the protection which the State accords to victims of trafficking which is a_
_fundamental right._

_85.            Ms Anderson disagrees and she contends that allegations about defective reasoning_
_must identify a related error of law or objective irrationality in order to found a jurisdiction for the court to_
_intervene so as to quash the decisions under challenge. She submits that it is appropriate to apply a_
_standard Wednesbury approach, and that the Court 'cannot be asked to form its own view of the merits of_
_the Claimant's allegations and credibility as a witness in her own cause'. She proceeds to submit that the_
_Court must identify an error of law or objective irrationality before it can quash the present decision. Ms_
_Anderson relies on the well-known statement that:_

_'It is essential that in exercising the very important jurisdiction to grant judicial review, the court should not_
_intervene just because the reasons given, if strictly construed, may disclose an error of law. The jurisdiction_


-----

_to quash a decision only exists when there has in fact been an error of law. Moreover, the court should not_
_approach decisions and reasons given by committees of laymen expecting the same accuracy in the use of_
_language which a lawyer might be expected to adopt.' per Lord Browne-Wilkinson (with emphasis added)_
_giving the only reasoned speech in Reg. v. Bishop Challoner School, Ex p. Choudhury [1992] 2 AC,_
_182,197E.”_

70. The judge then reviewed the recent authorities, including the FM and Minh cases as well as R (AB) v
**_Secretary of State for the Home Department [2015] EWHC 2014 (Admin) in which he concluded that_**
HHJ Heaton QC (sitting as a Deputy High Court Judge) essentially made no decision on the appropriate
test to be applied because, even applying a Wednesbury approach, the judge regarded the decision-maker
had acted unlawfully. He cited also a lecture given by Lord Sumption, the 2014 Annual Lecture of the
Administrative Law Bar Association given on 14 November 2014 and entitled “Anxious Scrutiny”, referring
in particular at [92] to Lord Sumption having made the following observation:

_“When the courts say, as they often do, that the intensity of review varies with the context, they are usually_
_saying no more than that the more significant the right interfered with, the more cogent will be the_
_justification required for the interference.”_

71. He then went on at [94] to [96] to refer to Kennedy v Information Commissioner [2015] AC 455, in
which a majority of the Supreme Court endorsed a flexible approach to principles of judicial review
especially where important rights are at stake. He cited, in particular, the following passage in the judgment
of Lord Mance at [51]:

_“The common law no longer insists on the uniform application of the rigid test of irrationality once thought_
_applicable under the so-called Wednesbury principle…The nature of judicial review in every case depends_
_on the context.”_

In that case, as the judge observed, Lord Mance, Lord Neuberger and Lord Clarke approved the approach
adopted by Lord Bridge in R v Secretary of State for the Home Department, ex p Bugdaycay [1987] AC
514at page 531 where he concluded that, subject to the weight to be given to a primary decision-maker's
findings of fact and exercise of a discretion:

_“The court must be entitled to subject an administrative decision to the more rigorous examination, to_
_ensure that it is in no way flawed, according to the gravity of the issue which the decision determines.”_

He pointed out that Lord Mance went on to state in the Kennedy case, at [54], that:

_“in the context of fundamental rights, it is a truism that the scrutiny is likely to be more intense than where_
_other interests are involved.”_

72. Sir Stephen then, at [97], referred to R (Pham) v Secretary of State for Home Department [2015]
1WLR 1591, specifically to Lord Reed's statement at [114] that:

_“The variable intensity of reasonableness review has been made particularly clear in authorities, such as R_
_v Secretary of State for the Home Department, Ex p Bugdaycay [1987] AC 514, R v Secretary of State for_
_the Home Department, Ex p Brind [1991] 1 AC 696, and R v Ministry of Defence, Ex p Smith [1996] QB_
_517, concerned with the exercise of discretion in contexts where fundamental rights are at stake. The_
_rigorous approach which is required in such contexts involves elements which have their counterparts in an_
_assessment of proportionality, such as that an interference with a fundamental right should be justified as_
_pursuing an important public interest, and that there should be a searching review of the primary decision-_
_maker's evaluation of the evidence.”_

Having cited this case, the judge then said this at [98]:

_“So pausing at this stage, rigorous scrutiny is required by the courts where fundamental rights are at stake_
_[and this degree of scrutiny is not limited to claims under the Human Rights Act 1998. So I cannot accept](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
_Ms Anderson's submission to the contrary. So it becomes necessary to analyse the nature of the_
_Claimant's rights, which were in issue in the process leading to the decision that she was not a victim of_


-----

_trafficking. These rights have to be considered against the background of the fundamental and non-_
_derogable nature of Article 4 of the ECHR. …”._

He continued by making the point that in Rantsev v Cyprus and Russia (2010) 51 EHRR 1, it was held
that _“article 4 enshrines one of the basic values of the democratic societies making up the Council of_
_Europe” and that_ _“no derogation from it is permissible under art 15(2) even in the event of a public_
_emergency threatening the life of the nation”._

73. The judge then referred to paragraph 127 of the Explanatory Report to the Trafficking Convention,
specifically its reference to a “Failure to identify a trafficking victim correctly will probably mean that victim's
_continuing to be denied his or her fundamental rights …”, before then saying this at [100]:_

_“If the failure to identify a trafficking victim correctly is a breach of his or her fundamental rights, then_
_another fundamental right is her or her right to have his or her claim properly investigated. In consequence,_
_a failure to consider fairly and properly whether a person has been trafficked must also be a breach of his_
_or her fundamental rights bearing in mind the significance of the rights granted to a person held to be_
_trafficked … .”_

He went on at [101] to contrast a case involving a decision as to whether a person has been trafficked with
a case, such as R (Westech College) v Secretary of State for Home Department _[2011] EWHC 1484_
_(Admin), the authority relied on by the Secretary of State's counsel in the case before him, where there was_
no question of fundamental rights being involved.

74. Sir Stephen's conclusion at [102] was that “the present application is in an area where the court should
_and can adopt a more rigorous approach to decisions refusing to hold that a person has been trafficked”,_
summarising the position as he saw it at [104]:

_“So pulling the threads together, the rationality of a gateway decision that a person is not the victim of_
_trafficking requires a heightened or a more rigorous level of scrutiny both because it relates to fundamental_
_rights and also because it arises in an area in which a court has the requisite knowledge. This means that_
_the approach of the courts should be in accordance with the approach of: Carnwath LJ (with whom Moore-_
_Bick and Etherton LJJ agreed) in R (YH) v Secretary of State [2010] EWCA Civ 116 [24], which was that:_

_'the need for decisions to show by their reasoning that every factor which tells in favour of the applicant has_
_been properly taken into account.'”_

75. Miss Meredith understandably submitted that, in the light of these authorities, including the cases so
helpfully reviewed in the **_SF case, the position is clear: 'anxious scrutiny' needs to be exercised by the_**
Court in reviewing the decision-maker's decision (here the decision contained in the 16 January 2015
letter), as well as by the decision-maker in making the decision under review. For her part, Miss Bretherton
did not agree with the analysis contained in the **_FM,_** **_Minh and_** **_SF cases, as she did not accept that a_**
decision as to whether a person has been trafficked entails a decision concerning a fundamental right. She
submitted, however, that even if that is wrong and a fundamental right is involved, nevertheless there is an
important contrast between the **_FM,_** **_Minh and_** **_SF cases and the present case, in that the present case_**
does not involve the Competent Authority having made the decision under challenge in each of those
cases, namely whether the particular claimants had been trafficked, but a different (and lesser) decision,
namely whether a residence permit should be issued to a person whom the Defendant accepts has been
trafficked. As such, she submitted, the rationale to which Sir Stephen Silber referred at [104] in the SF case
does not apply in K's case. Mr Corcoran's decision was not whether K is a victim of trafficking since it was
accepted by him (and so by the Defendant) that that is the case. The decision under challenge was instead
as to whether, in view of the fact that K is a victim of trafficking, it was appropriate that a residence permit
be granted to him. That decision, Miss Bretherton suggested, did not relate to a fundamental right, and so
the approach to be adopted in these proceedings is the standard _Wednesbury approach rather than the_
'anxious scrutiny' approach, and so also the decision-maker (here Mr Corcoran) was not obliged to
exercise 'anxious scrutiny'.

76. As I see it, in the light of the consistent approach adopted in the FM, Minh and SF cases, if and insofar
as the decision under challenge before the Court is as to a fundamental right the correct approach is one


-----

which entails the exercise of 'anxious scrutiny'. I reject Miss Bretherton's suggestion that in such cases the
_Wednesbury approach is to be preferred. In this respect, I agree with the analysis, in particular, set out in_
the **_SF case by Sir Stephen Silber. This still leaves, however, the real point which Miss Bretherton has_**
made, namely that the present case is concerned with a decision as to the grant of a residence permit, not
a decision as to whether K was trafficked since that is something which the Defendant accepts was the
case. I am more sympathetic to this submission; indeed, I consider it to be correct. It seems to me that
there is a very real distinction between what is to be regarded as the primary decision, namely whether a
person is a victim of trafficking, and what are essentially secondary or consequential decisions, including
whether a residence permit is to be granted to the trafficked person. The former decision concerns a
fundamental right precisely because it gives rise to something fundamental and has the consequences
described by Sir Stephen Silber in the SF case at [2]:

_“The decision of the [Competent Authority] is of critical importance as it not only affects the position of the_
_victim of trafficking, but it also affects the ability of the State to mount effective prosecutions against_
_traffickers. A person held to have been trafficked will thereby become entitled to a series of rights under_
_CAT and these include the right to assistance to aid recovery (Article 12); to a residence permit in the_
_circumstances laid down in Article 14; to information about and access to compensation procedures_
_(Article 15); for any return to her country to be carried out with 'due regard for the rights, safety and dignity_
_of that person' (Article 16); and of particular importance in the present case, a right not to be prosecuted for_
_offences directly connected with her experience of being trafficked (Article 28). As the Claimant has been_
_held not to be trafficked, she will not be entitled to any of the benefits and is now at great risk of being_
_prosecuted and then sent back to St Lucia.”_

It is to be noted that the judge in this passage made it clear that the decision on whether a person is a
trafficking victim is the decision on which other aspects hang. Those other aspects, including the decision
concerning a residence permit, are parasitic on the fundamental decision concerning whether a person is
trafficked; they are not themselves decisions which are concerned with fundamental rights. In addition,
although this is a matter to which I shall return when addressing Ground (3), I consider that Miss
Bretherton was right when she highlighted that Article 14 of the Trafficking Convention is not imperative in
its terms, so lending further support to the view which I have reached. That view, however, is one which I
have reached independently of this further point.

77. The distinction is illustrated by a point raised by Miss Bretherton in argument, which is that the grant of
a residence permit under Article 14 of the Trafficking Convention is not the same as a grant of permanent
leave to remain under the Immigration Rules since a residence permit can be taken away. Indeed, insofar
as a residence permit is granted in order to aid the investigation and prosecution of trafficking offences, it is
obviously the case that there will be a temporal element to the grant to take account of the fact that
investigations and prosecutions will inevitably reach some sort of conclusion, whether because convictions
are obtained or because prosecutions are not brought. As such, I find it difficult to see how the grant of a
residence permit, at least on this basis, can involve a decision as to a person's fundamental rights. In the
circumstances, I consider that the approach to be adopted in a case such as the present, where what is
under review by the Court is a decision whether to grant a residence permit rather than a decision whether
a person is a victim of trafficking, is the Wednesbury approach. Nevertheless, in case I am wrong on the
approach to be adopted, I propose when addressing the Grounds raised in the Amended Grounds for
Judicial Review to consider the matter not only on a _Wednesbury basis but also exercising 'anxious_
scrutiny'.

78. Secondly, Miss Meredith submitted that a departure from the Defendant's policy without explanation,
or a failure to adhere to published (and internal) policy is a vitiating public law error. In this regard, Miss
Meredith cited the recent decision of Elizabeth Laing J in R (Mutesi) v Secretary of State for the Home
**_Department_** _[2015] EWHC 2467 (Admin) at [45]:_

_“It is trite law that if a decision maker publishes a policy or guidance about how particular decisions will be_
_made or a particular power will be exercised, the decision maker will err in law if, without explanation, he_
_departs from that guidance. See Lumba v Secretary of State for the Home Department [2011] UKSC 12;_

_[2012] 1 AC 245 ”_


-----

Miss Bretherton took no issue with Miss Meredith about this. It is this principle which underpins Ground (1).

79. There was, however, a dispute as between Miss Meredith and Miss Bretherton concerning the
justiciability of the Trafficking Convention in this jurisdiction. This touches on Ground (2) which is
concerned with whether the Defendant has applied in K's case a policy which sets a higher threshold than
stipulated in Article 14 of the Trafficking Convention. As I understand it, Miss Bretherton did not quibble
with the proposition that, if and insofar as the Defendant's relevant policy guidance purported to give effect
to the terms of the Trafficking Convention yet failed to do so, that would be a justiciable error of law. This
was accepted by the Secretary of State in the **_Atamewan case (see [69] per Aikens LJ), the Divisional_**
Court going on to conclude that the then applicable policy guidance was unlawful because it entailed a
misinterpretation of the Trafficking Convention. However, Miss Bretherton did not accept that the
Trafficking Convention in and of itself is justiciable, as Miss Meredith contended, since the Trafficking
Convention does not have direct effect. This was the point made in the **_Minh case at [53] where Miss_**
Mountfield QC stated as follows:

_“Since the UK Government has announced that its policy is to give effect to its obligations under the_
_Trafficking Convention, that has consequences in domestic administrative law. Failure to apply the_
_provisions of the Convention may give rise to a successful claim for judicial review: not because the treaty_
_has any direct effect (because it does not), but because the Government has then failed to apply its own_
_published policy (see R(Y) v SSHD [2012] EWHC 1075 (Admin) at [40]). Thus, the Competent Authority_
_should be taken to have intended to protect the victim's rights, combat trafficking and promote international_
_co-operation (the objectives identified in the Convention) and to promote a human rights based approach.”_

_80. Miss Meredith nonetheless submitted that, although the Trafficking Convention is an unincorporated_
treaty, it has been applied by, and is justiciable in, domestic courts both as a guide to the interpretation of
the EU Trafficking Directive which is directly effective (see **_R v LC_** _[2013] EWCA Crim 991; [2013] 2 Cr._
App. R. 23 at [8] and [18], and Gudanaviciene & Ors, R (on the application of) v The Director of Legal
**_Aid Casework & Or_** _[2014] EWCA Civ 1622 at [105]), and through its implementation in Home Office_
Guidance to guide the process of the identification of victims. In this latter respect, Miss Meredith placed
significant reliance on the following passages in Mr Mott QC's judgment in the FM case:

“10. The Council of Europe Convention on Action against Trafficking in Human Beings ('CAT') was signed
_on 16 May 2005. It was ratified by the UK on 17 December 2008, but has never been directly incorporated_
_into domestic law. Instead, the UK's international obligations have been implemented by the adoption of_
_procedures and policies by government ministers responsible. The most important of these is the_
_Defendant, who has issued and updated a document now called 'Victims of human trafficking – competent_
_authority guidance' ('the Guidance')._

_11.            The relevance of the CAT in this sort of challenge, and that of the Explanatory Report_
_('CATER') which accompanied it, have been considered by the Divisional Court in R (Atamewan) v SSHD_

_[2014] 1 WLR 1959. The following principles are now established:_

_i)              Insofar as the Guidance purported to give effect to the terms of the CAT and failed to do_
_so, that would be a justiciable error of law. In general it is not disputed, as I found in the case of R (E) v_
_SSHD [2012] EWHC 1927, that the Defendant has adopted the CAT in her published Guidance. The_
_exception in Atamewan in respect of Article 27 of the CAT no longer applies because of changes in the_
_wording of the Guidance, as set out below, which clearly now purport to give effect to Article 27 of the CAT,_
_as the Defendant accepts._

_ii)              Because the Defendant, and the agencies acting on her behalf, are public authorities_
_for the purposes of the_ _[Human Rights Act 1998,](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_ _they must not do anything that would be contrary to a_
_person's rights under the European Convention on Human Rights ('ECHR'). One of those rights, under_
_Article 4 of the ECHR, is not to be subjected to slavery. That provision must be read in harmony with the_
_general principles of international law. Those principles include the CAT, which is a more detailed_
_approach to the prevention and relief of slavery by means of trafficking. Thus a failure to comply with the_
_obligation in the CAT is amenable to judicial review by this route._


-----

_iii)              As a result of these two principles it is not disputed on behalf of the Defendant in the_
_present case that I am entitled to look at both the CAT and the CATER when considering the Defendant's_
_duties under her published Guidance.”_

81. It can be seen that principle (i) entails the proposition with which, as I have explained, I do not
understand Miss Bretherton to take issue. Miss Meredith placed particular reliance, however, on principle
(ii) in support of her submission that the Trafficking Convention is justiciable in this jurisdiction
notwithstanding that it does not have direct effect. On analysis, however, I do not consider that Mr Mott QC
was going as far as Miss Meredith suggested when setting out principle (ii). It seems to me that he was
simply making the point which Miss Mountfield QC in the **_Minh case at [52], the paragraph before the_**
passage set out above in which she addressed the second of _“two bases upon which it is said that the_
_Trafficking Convention is potentially relevant to this claim”. Dealing with the first of the two bases at [52],_
Miss Mountfield QC said this:

_“The first was that failure to comply with the assistance provisions in the Convention was something which_
_it was said I could take into account in considering whether there was a breach of the positive obligations_
_under Article 4 ECHR. As both parties noted, in Rantsev v Cyprus & Russia [2010] 51 EHRR 1, the_
_European Court of Human Rights found that trafficking as defined in Article 4(a) of the Trafficking Protocol_
_falls within the scope of Article 4 ECHR and (at [288]) that Article 4 ECHR entails a procedural obligation to_
_investigate situations of potential trafficking. If the procedures undertaken by the Secretary of State did not_
_match up to the demands of the Trafficking Directive, that might be persuasive evidence that there had_
_been a breach of the positive investigative obligation under Article 4 ECHR.”_

82. Miss Mountfield QC was, therefore, describing the same _“route” as Mr Mott QC was describing in_
principle (ii). She was not suggesting that the Trafficking Convention is otherwise, or more generally,
justiciable in this jurisdiction. The same approach was followed in the Atamewan case, Aikens LJ stating
as follows at [89] and [90]:

_“89.            Two obligations on the UK authorities are involved. First, there is the obligation of the UK_
_in Article 27(1) of CAT. As already noted, in his written submissions Mr Eadie took the points that, first, an_
_unincorporated international treaty cannot be relied upon in domestic courts to fill an alleged lacuna in_
_Government policy and, secondly, that the Guidance does not purport to transpose any possible positive_
_duty under Article 27(1) of CAT to provide for the referral of a victim of trafficking's case to the police in_
_circumstances where the police have not already been alerted._

_90.            I accept those propositions. But that still leaves Ms Kaufmann's point that the UKBA is a_
_[public authority for the purposes of the Human Rights Act 1998 and it must not do anything that would be](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9DF0-TWPY-Y0K2-00000-00&context=1519360)_
_contrary to a person's Convention rights: in this case those of the claimant under Article 4 not to be_
_subjected to slavery, servitude or forced or compulsory labour. I would be prepared to accept, on the basis_
_of the analysis of the authorities by Wyn Williams J in OOO v Commissioner of Police for the Metropolis_
_that, in the present case, the UKBA was under a duty to initiate or trigger an effective investigation by the_
_police into offences that were committed against the claimant in respect of her trafficking to and in the UK._
_(I did not understand Mr Eadie to argue to the contrary). I would also accept that it appears on the face of_
_the NRM decision itself that the UKBA did nothing; indeed it relied upon the fact that the claimant had not_
_made a complaint to the police for the fact that there were no continuing police investigations.”_

83. It seems to me that this falls somewhat short of Miss Meredith's proposition that the Trafficking
Convention in and of itself is justiciable in this jurisdiction notwithstanding that it does not have direct effect.
In the circumstances, I reject that broader submission, not that, in any event, it really adds either to Ground
(2), which depends on Mr Mott QC's (uncontroversial) principle (i) in the FM case, or to Ground (3), which
entails an allegation of an Article 4 breach in failing to exercise 'anxious scrutiny' of K's eligibility for a
residence permit and so, by that “route”, a need to have regard to the Trafficking Convention.

84. Miss Bretherton also referred to certain authorities in her skeleton argument. She did so in the context
of Article 4 and the suggestion in Ground (3) that there was a breach in relation to investigations by the
Police. I shall deal with these cases later when considering Ground (3).


-----

85. Before coming on to consider the various Grounds, I should record the fact that, during the course of
her reply submissions, Miss Meredith produced an 8-page Note, along with certain documents not in the
hearing bundles which she explained had only recently been disclosed by the Defendant in response to a
request made by Wilsons. Subsequently I was provided with a further bundle of authorities which included
copies of various cases to which Miss Meredith made reference in her Note. Miss Meredith suggested that
the Note was prepared, at least in part, to deal with new points which had only emerged during the course
of Miss Bretherton's oral submissions. That is not the case. On the contrary, the matters canvassed in Miss
Meredith's Note arise from points made by Miss Bretherton not only in her oral submissions but also in her
skeleton argument. I will address the points, namely those which seem to me to matter, when dealing with
the various Grounds. I am less than clear, however, that some of the further points made by Miss Meredith
in the Note and the additional authorities on which she relied greatly assist me in resolving the present
dispute. I am conscious also that the points at issue, as raised in the Grounds, are points which ought to be
capable of relatively straightforward determination. It is regrettable, in my view, that, notwithstanding this,
so many arguments have been raised and that I have had to spend so long considering those arguments
before coming on to consider, and determine, the Grounds. Miss Meredith suggested at the outset of her
opening submissions that this case involves issues of _“real public importance”. Although I am doubtful_
about this, it might explain why, in my view, I have been somewhat over-burdened in this case with
submissions and with citation of authority.

86. I turn now, finally and regrettably somewhat belatedly, to address the various Grounds which have
been raised by Miss Meredith on K's behalf. I stress in doing so that I have taken into account all of the
points made by Miss Meredith and Miss Bretherton, including in Miss Meredith's 8-page Note. If I do not
address each and every such point, it should not be assumed that I have not taken it into account. It is
important, however, that I now focus on what really matters and this means that I do not propose dealing
with every point.

**Ground (1): alleged failure to apply or misapplication of the Defendant's policy guidance**

87. Ground (1) is the challenge which entails the submission that Mr Corcoran's decision on 16 January
2015 misapplied or failed to adhere to the Defendant's own policy guidance as set out in the Competent
Authority Guidance and the Asylum Policy Instruction to which the Competent Authority Guidance refers.
Miss Meredith contended that there was misapplication or failure to adhere by Mr Corcoran (and so the
Defendant) both in relation to what is stated at page 98 of the Competent Authority Guidance under the
heading “Personal circumstances” and as regards what is set out at page 101 concerning co-operation with
the Police.

_Personal circumstances_

88. Dealing, first, with the former, a number of specific objections are made in this regard by Miss
Meredith. First, it is suggested that, despite having cited at page 2 of the letter the test contained in the
Competent Authority Guidance at page 98 (that discretionary leave is to be granted to a person “if their
_personal circumstances are compelling”), Mr Corcoran then failed in what followed, throughout the 16_
January 2015 letter and specifically in the conclusion, to state that that test (a test which Miss Meredith
submitted was, in any event, too high a test: see Ground (2)) had not been met. Miss Meredith highlighted
in this respect how at paragraph 4 of the letter Mr Corcoran explained that “Consideration has been given
_to whether [K] qualifies for leave on medical grounds”, before going on at paragraph 14 to state his_
conclusion that “medical treatment is available to treat [K's] conditions” in Ghana. She suggested, however,
that since no mention was made in these contexts of the Competent Authority Guidance “compelling” test,
this made the decision unlawful. She pointed out also that Mr Corcoran made no mention in these parts of
the letter, what she described as the “substantive” parts of the letter, of the test contained in the Asylum
Policy Instruction at paragraph 4.5, namely that discretionary leave may be granted where “the individual's
_personal circumstances, although not meeting the criteria of any of the other categories listed, are so_
_compelling that it is considered appropriate to grant some form of leave”. This, in circumstances where_
page 98 of the Competent Authority Guidance gives a weblink to the Asylum Policy Instruction.


-----

89. Miss Meredith submitted that not only did these failures make the decision unlawful, but that, in
defending these proceedings by making the point that Mr Corcoran was entitled to reach the view that K's
personal circumstances were insufficiently compelling to justify the grant of a residence permit, the
Defendant is engaged in what Miss Meredith labelled “retrospective justification”. I cannot accept that this
is the case. Nor can I accept that it was incumbent upon Mr Corcoran to state in express terms in the
_“substantive” parts of the decision letter that he had decided that there were not sufficiently “compelling” or_
_“so compelling” reasons why a residence permit should be granted. It is obvious from the fact that Mr_
Corcoran stated the applicable test at the start of the letter that it was that test to which he was having
regard when considering K's personal circumstances. It is obvious, therefore, that, when he came on to
consider the factors to which he referred and when he stated his conclusion, having taken those factors
into account, he was applying that test and not some other test which he had not troubled himself to
identify. I regard the submission made by Miss Meredith to the contrary as being wholly unrealistic and, as
such, quite unsustainable. I agree with Miss Bretherton's description of the submission as involving a “nit_picking approach”. Accordingly, I reject this criticism._

**90. Miss Meredith went on to suggest that Mr Corcoran was wrong to have focused, “exclusively” as she**
put it, on the example of “compelling” circumstances which is given at page 98 of the Competent Authority
Guidance. She suggested that by so doing Mr Corcoran failed to have proper regard to the guidance itself.
She highlighted in this regard how “it may be appropriate to grant a victim of trafficking discretionary leave
_if their personal circumstances are compelling”, and that what follows is simply described as being an_
example, namely “to allow them to finish a course of medical treatment that would not be readily available if
_they were to return home”. Miss Meredith's submission was that Mr Corcoran, in effect, treated the_
example, as she put it in her oral submissions, as “the controlling rule”, so failing to take account of other
factors which should have been considered as part of Mr Corcoran's assessment of K's personal
circumstances and, specifically, his determination as to whether those personal circumstances were such
as to amount to compelling circumstances.

**91. I cannot accept this criticism either. First, it is not accurate for Miss Meredith to suggest that Mr**
Corcoran focused on the example which is given at page 98 of the Competent Authority Guidance. That
example is concerned with a person completing a course of medical treatment; it is not an example which,
therefore, refers to _any medical treatment but which very specifically identifies the completion of medical_
treatment. This is not an example which seems to me to cover K's circumstances. True it is that K has a
series of medical conditions, as set out in paragraph 5 of the 16 January 2015 letter. True it is also that K
was taking medication for those conditions, as set out in paragraph 6. This does not mean, however, that K
is to be regarded as a person who needs _“to finish a course of medical treatment”. At the risk of giving_
further examples and confusing matters, that example seems to me to be referring to cases where
somebody is undergoing a course of chemotherapy or a series of related surgical procedures. I struggle to
see how it would embrace a case, such as K's case, where somebody is receiving medication and doing so
on effectively a long-term basis. I note in this respect that in paragraph 8 of the letter Mr Corcoran went on
to refer to Dr Grant-Peterkin having stated in his January 2014 report that K needed psychological
intervention. This was a reference not to existing psychological intervention but to treatment which K had
not yet started. This is clear from Mr Corcoran's reference to Dr Grant-Peterkin saying in his report that K
needed such “further treatment”. Accordingly, this did not bring K's case into the example given at page 98.
In summary, then, Miss Meredith is wrong to suggest that Mr Corcoran focused on the example given. He
could not have done so because K's case did not fit into that example.

**92. Secondly and in any event, having read and re-read the decision letter several times, I am satisfied**
that Mr Corcoran properly considered the individual facts pertaining to K, indeed (if this is what was
required) that he gave 'anxious scrutiny' to those matters. I say this also having read Dr Grant-Peterkin's
January 2014 report in some detail, Miss Meredith having helpfully taken me through it at the hearing. Miss
Meredith suggested that in the decision letter Mr Corcoran ought to have made express reference to
particular parts of the report. She highlighted, for example, paragraph 10.4, in which Dr Grant-Peterkin
described K's mistrust of people owing to his experience as a victim of trafficking. She referred also to
paragraph 11.4, in which reference was made to K's “mental state and symptomatology” being “aggravated
_b_ _hi_ _t i_ _i_ _ti_ _t t_ _d_ _t d b_ _hi_ _d t_ _ti_ _”_ tt l dd d i


-----

paragraph 19.1. She then pointed to paragraph 20 and Dr Grant-Peterkin's concerns that K might commit
suicide if he were to be returned to Ghana. Miss Meredith submitted that these are all matters which see
no mention in the decision letter, so indicating that Mr Corcoran failed to consider K's personal
circumstances in an appropriate way. In my view, this is a criticism which is unwarranted. It seems to me
unrealistic to have expected that Mr Corcoran should have addressed, expressly in the decision letter,
every aspect of what was a substantial report. I am clear that this is not what somebody in his position
should have to do. What is necessary is that the decision-maker considers the position; what is not
necessary is that he or she rehearses every point contained in the material placed before him or her. To
require that that is done would, in my view, be to require too much. I am clear that in K's case Mr Corcoran
had regard to Dr Grant-Peterkin's report in an entirely appropriate way. He was entitled to take from that
report what he regarded as the most prominent points. He did that, as can be seen from the contents of
paragraphs 5, 6 and 8 of the decision letter. As to the particular matters covered by the paragraphs in the
report highlighted by Miss Meredith, there is no reason to suppose that they were not taken into account by
Mr Corcoran. To illustrate the point, it is only to be expected that somebody in K's position will feel anxiety
concerning his or her ability to remain in this country, in circumstances where they have been trafficked.
The notion that Mr Corcoran, somebody whose task was to make decisions under the NRM, would not
appreciate this, whether he was told it in a medical report or not, is somewhat fanciful.

93. It follows from this that I cannot accept Miss Meredith's third criticism, as well as the sixth criticism
which is very closely linked to the third criticism, as both set out in her skeleton argument, that the
Defendant has failed in this case, through what is said to be Mr Corcoran's exclusive focus on _“medical_
_grounds”, to comply with the guidance given in the Atamewan case at [80] and conduct an overall factual_
enquiry or assessment of _“a range of situations, depending on whether it is the victim's safety, state of_
_health, family situation or some other factor which has to be taken into account”, as paragraph 184 of the_
Explanatory Report to the Trafficking Convention explains is required for Article 14(1)(a) purposes. Clearly,
in the decision letter there was something of an emphasis on medical matters. That is hardly surprising,
however, in circumstances where what was put before Mr Corcoran by Wilsons on behalf of K was Dr
Grant-Peterkin's January 2014 report, a document which focused on medical matters whilst also
addressing other matters of the sort to which I have referred. It was telling that when I asked Miss
Meredith, during the course of submissions, what other factors it was being suggested that Mr Corcoran
ought to have taken into account, she confirmed that the matters were all set out in Dr Grant-Peterkin's
report. It was not suggested that there were other matters. It follows from the conclusion which I have
expressed in the previous paragraph, namely that Mr Corcoran did not need to deal expressly in the letter
with every point raised in the report, that, accordingly, I cannot this criticism on the part of Miss Meredith.

94. Nor can I accept the fourth and fifth criticisms made in Miss Meredith's skeleton argument. Dealing
with these points in turn and so focusing initially on the fourth point, Miss Meredith submitted that, in
compliance with the Competent Authority Guidance at pages 58 and 59, the Defendant ought to have
contacted other agencies responsible for providing high level support to K. These pages are entitled
_“Gathering more information” and start with the following explanation:_

_“This page gives information for competent authority staff about gathering more information to make a_
_reasonable grounds decision”._

As such, it is somewhat questionable whether this is applicable guidance since the Defendant had already
made a 'reasonable grounds' decision by the time that the decision on 16 January 2015 came to be made.
It seems to me that the (similar) guidance given at page 77 is potentially more apposite. This is also
entitled “gathering more information” but is directed towards the making of “a conclusive grounds decision”.
However, even that is open to some doubt in circumstances where the decision which was made on 16
January 2015 followed the decision letter dated 10 October 2013 which was, as far as I can see, the
relevant 'conclusive grounds' decision in K's case. In short, the aspect which was the subject of the 16
January 2015 decision was whether K should be granted a residence permit, not whether the Defendant
accepted that he was a victim of trafficking. If that is right, as I consider it is, then, it must follow that the
Defendant was under no obligation under the Competent Authority Guidance at pages 58 to 59 or at page
77 to gather more information from other agencies, and that is an answer to Miss Meredith's point. Even if


-----

this is too technical an answer and there was some obligation on the part of the Competent Authority to
make such contact, as a freestanding criticism I do not see where the point goes. Miss Meredith would
need to go somewhat further and make good her next point, the fifth criticism contained in her skeleton
argument, if the objection is to have any significance.

**95. As to that fifth criticism, Miss Meredith submitted that this case is akin to the FM case, in which Mr Mott**
QC asked himself, in line with the approach advocated in Secretary of State for Education and Science
**_v Tameside Metropolitan Borough Council[1977] AC 1014 at page 1065B, whether the Defendant had_**
asked herself _“the right question”_ and taken “reasonable steps to acquaint” herself “with the relevant
_information to enable”_ her “to answer it correctly”, concluding that she had not done so. The specific
questions which arose in that case were set out at [47]:

_“In this case medical treatment was recommended. That recommendation, coming from an expert, must_
_have been a material consideration, and begs a number of questions. Why has the treatment not started?_
_Is that connected with the Claimant's pregnancy? Will she agree to such treatment? When can it start? Is it_
_available in Ethiopia? Could it be conducted there with the same prospect of success?”_

Mr Mott QC went on to express his views at [49] and [50]:

_“49.            In this case the Defendant appears not to have considered Dr Battersby's_
_recommendation at all, and certainly made no further inquiries. This is despite the duty under Article 12(1)_
_of the CAT to provide appropriate psychological assistance to help the victim overcome the trauma that_
_she had been through._

_50.            On any basis it seems to me that the decision, and the supplementary reasons, both fail_
_dismally in considering a vital element of evidence about the Claimant's psychological condition. Whatever_
_might be the result of a proper consideration, there is no indication that even now it has been given to this_
_aspect of the Claimant's case. As a result, that part of the decision cannot be supported.”_

96. Miss Meredith suggested that the Defendant in the present case involving K, her client, similarly failed
to appraise herself of the relevant medical treatment required by K in order to answer the question of
whether it was readily available. She submitted, in particular, that the solitary reference in paragraph 8 of
the decision letter to Dr Grant-Peterkin stating that “psychological intervention” was required does not, as
Miss Meredith put it, “begin to address” the treatment which Dr Grant-Peterkin, in his January 2014 report,
stated was needed owing to K's complex psychological and physical needs where there _“are direct_
_causative links between the abuse he experienced and his current mental state” (paragraph 12.1 of the_
report), such treatment comprising “consistent, high-quality multi-disciplinary input' (paragraph 11.1) as well
as treatment already provided by CMHT, K's GP and the Refugee Therapy Centre.

97. I cannot agree with this submission essentially for the reasons which I have already given. I agree with
the point made by Miss Bretherton in her oral submissions, namely that in considering expert evidence, all
the more so a report of some length, it is easy to alight on a particular matter in the report and say that the
decision-maker did not mention it in support of a submission that this shows that the decision-maker must
have failed to take the matter into account. I am clear that the Court should be wary of this type of
submission since there is a danger that a view is formed which could only be avoided if the decision-maker
were to incorporate virtually the entire report for fear of it being suggested that its contents had not
adequately been taken into account. I am satisfied, indeed applying the 'anxious scrutiny' approach urged
upon me by Miss Meredith (albeit that I do not consider this to be the right test), that Mr Corcoran took all
relevant matters into account. The suggestion, in particular, that the present case is like the FM case in this
regard seems to me to be unsustainable. That was a case in which the questions posed at [47] had not
been considered at all. As made clear by Mr Mott QC at [19] the relevant medical report, that of a Dr
Battersby, was not mentioned in the decision letter. The decision letter in the present case expressly
referred to Dr Grant-Peterkin's report and went on to deal in some detail with the matters raised in it. The
contrast is striking.

98. Miss Meredith went on in her skeleton argument to point to certain of the various reports to which
reference was made in the 16 January 2015 letter. She referred specifically to comments attributed in one


-----

of the reports to Dr Akwasi Osie, director of the Accra Psychiatric hospital, as well as to a report of the UN
Torture Committee published on 15 June 2011 which, she noted, confirmed a lack of access to treatment
of those with psychiatric conditions even in the capital Accra. These are, however, just two aspects of the
material to which the letter referred. Other material cited by Mr Corcoran supported his conclusion that
there would be medical treatment available to K in Ghana, albeit that Mr Corcoran recognised that it was
not to the same standard as that in this country (see paragraph 14). I see no basis, in these circumstances,
for concluding that Mr Corcoran did not consider matters properly or (if this is what was required) that he
did not exercise 'anxious scrutiny' in relation to this issue. I certainly cannot conclude that he acted in a
manner which would warrant a conclusion of unlawfulness applying Wednesbury principles, and I arrive at
the same conclusion as to the lawfulness of the decision letter applying also the 'anxious scrutiny'
approach if that is the applicable approach to adopt.

99. I would add that I reject the suggestion that it is open to Miss Meredith on behalf of K to suggest that
Mr Corcoran was somehow at fault in not accessing other publicly available sources. Miss Meredith has
accepted that there is no challenge based on the approach described in the **_Sufi_** case. She rightly,
therefore, acknowledged, ultimately at least, that this further criticism contained in her skeleton argument
cannot be maintained. The same applies, for reasons which I have set out previously, in relation to the
suggestion made in her skeleton argument that the Court should have regard to the second report of Dr
Grant-Peterkin dated 13 April 2015 and evidence filed in July and August 2015, including Professor
Lawrance's expert report. These post-date the decision under challenge and, as such, it is not open to Miss
Meredith to rely upon them.

100. This leaves Miss Meredith's seventh and final criticism as regards the personal circumstances issue.
This is that Mr Corcoran's decision was reached in the absence of 'anxious scrutiny' of K's specific
individual circumstances, as demonstrated by his failure in the decision letter, as it was put by Carnwath LJ
(as he then was) in R (YH) v Secretary of State for the Home Department _[2010] EWCA Civ 116 at [24],_
_“to show by [its] reasoning that every factor which tell in favour of the applicant has been properly taken_
_into account”. Again, I cannot accept that this is a legitimate criticism, even if it is right that Mr Corcoran_
was under an obligation to exercise 'anxious scrutiny'. I am satisfied, applying indeed, as Miss Meredith
urged me to do, an 'anxious scrutiny' approach at this stage also (namely as the judge hearing the judicial
review), that Mr Corcoran's reasons were sufficient to enable me to see that he himself applied 'anxious
scrutiny' in K's case.

101. This is my conclusion in relation to each of the criticisms made as regards this aspect of the Ground
(1) challenge. I conclude that the Defendant acted in a manner which was lawful, whether applying
_Wednesbury principles or applying the 'anxious scrutiny' approach. In the circumstances, I conclude in_
relation to this aspect of Ground (1) that this is not a case in which there has been a departure from the
Defendant's policy without explanation, or a failure to adhere to published (and internal) policy such as to
give rise to a vitiating public law error (see the Mutesi case at [45]).

_Police co-operation_

**102. I come on to consider the second aspect of Ground (1). This is concerned with co-operation with the**
Police. The first point raised by Miss Meredith on K's behalf was that Mr Corcoran was wrong to approach
K's case on the basis that, as the Defendant had not “had a formal request from the police in respect of
_your client assisting them with their enquiries”, K “does not qualify for leave on this ground”. It will be_
recalled that this followed a passage in the letter under the heading “Assisting the Police in UK with their
_enquiries”, in which reference was made to the Trafficking Convention and to the situation where “a victim_
_has agreed to cooperate with police enquiries”_ and “has agreed to assist with police enquiries from the
_UK”, the point being made that “the Police must make a formal request for them to be granted leave to_
_remain on this basis”. This reference in the letter, in turn, reflects, again it will be recalled, the Competent_
Authority Guidance at page 101 (“Victims who are assisting with police enquiries from the UK”).

**103. Miss Meredith pointed out in this regard that in the** **_FM_** case at [29] it had been accepted by the
Secretary of State's counsel that the requirement at page 101 of the Competent Authority Guidance is not
a condition precedent to the grant of a residence permit In circumstances however where Ground (1) is


-----

concerned, and only concerned, with the question of whether the Defendant followed her own policy
guidance, I am not clear where this observation takes Miss Meredith in the context of Ground (1). I propose
to deal with this particular matter, in such circumstances, when addressing Ground (2), even though I
would note that in her skeleton argument the only matter specifically raised in support of Ground (2) is the
point concerning the applicable (“compelling”/“so compelling”) test in relation to personal circumstances,
and not also a point concerning co-operation with the Police, which was nevertheless part of Ground (2) in
the Amended Grounds for Judicial Review. In truth, it was the Ground (2) challenge which was at the
forefront of Miss Meredith's submissions. Indeed, she accepted during her oral submissions that Mr
Corcoran was _“entitled to refer to the absence of a formal request from the Police in refusing to grant a_
_residence permit because the Guidance says that”. She went on to say that that was the end of the matter_
but she did so by making the submission which arises in the context of Ground (2), a submission based on
what the Trafficking Convention requires, and not a submission which, therefore, matters for the purposes
of Ground (1).

**104. Miss Meredith nevertheless maintained a point made in paragraph 129 of the Amended Grounds for**
Judicial Review, namely that the Defendant failed to take into account “the impact of her previous failure to
_do anything in relation to a referral to the police for investigation, contrary to Atamewan and her policy, and_
_despite the repeated requests for a referral to be made”. It is appropriate that I deal with this point. This is_
despite the fact that in Miss Meredith's skeleton argument the case was not put in this way. No longer was
it suggested, or at least apparently maintained, that Mr Corcoran failed to take into account the matter
identified in the passage from which I have quoted. Instead, it was submitted, based on the FM case, that
the Defendant's decision to refuse a residence permit to K “should be quashed for the delay and/or failure
_to involve the police”. That is not the same case as was advanced in the Amended Grounds for Judicial_
Review: that case focused on the decision made on 16 January 2015 and whether delay ought to have
been taken into account, whereas the case in the skeleton argument entailed a freestanding case based
on “delay and/or failure to involve the police” leading up to the date of the decision in January this year,
albeit that the remedy for the latter (a quashing of the decision) would be the same in each case, which is
the relief sought in paragraph 145 of the Amended Grounds for Judicial Review. Although it is not helpful
that there should be this re-packaging of the case, it is nevertheless appropriate that I deal with the point
since, even though the matter was not put in this way previously, I recognise that, as cited by Mr Mott QC
in the FM case at [39], Aikens LJ in the Atamewan case explained as follows at [87] Aikens LJ:

_“… a decision which is based, in part, on a failure to fulfil the positive obligation not to remove someone_
_who has passed the 'reasonable grounds' test and which decision is also contrary to the negative_
_obligation set out in article 27(1) of the CAT cannot be regarded as lawful.”_

I bear in mind also that there is an overlap between the case as it (now) arises in the context of Ground (1)
and the case as it is put in relation to Ground (3), which (again now at least, albeit this is not how the case
was put in the Amended Grounds for Judicial Review) entails the submission that there was a breach of
Article 4 in failing to exercise anxious scrutiny when making the decision on 16 January 2015 having
regard to the Defendant's previous failure to make a referral to the Police.

**105. For reasons which I shall now briefly explain, it seems to me that, in any event, the original Ground**
(1) case (as contained in paragraph 129 of the Amended Grounds for Judicial Review) and the new
Ground (1) case (as described in Miss Meredith's skeleton argument), as well as the new Ground (3) case,
cannot succeed. Each of these cases depends on Miss Meredith being right in her contention that the
present case is akin to the FM case. However, on analysis, that is not the position: the two cases are not
comparable. There is a simple reason for this. This is that in the FM case, unlike in the present case, at the
stage when the decision under challenge concerning the grant of discretionary leave under the NRM was
made, there had still to be a referral to the Police at the time when the decision equivalent to the 16
January 2015 decision made by Mr Corcoran in K's case, a decision made in the FM case on 3 October
2014 and supplemented by a letter dated 12 November 2014. In K's case, by the time that Mr Corcoran
made the decision concerning the grant of a residence permit on 16 January 2015, there had been a
referral to the Police. That referral was made almost a year earlier when, as required by the Competent
Authority Guidance at page 37 (“Sharing information with the police”) the Competent Authority referred K's


-----

case to the “local police force” to the Competent Authority's office in Merseyside. As a result, and as further
confirmed by the subsequent correspondence between Wilsons and the Defendant which took place during
2014, correspondence to which Miss Meredith took me in some detail, there can be no doubt that,
whatever failings there may or may not have been as regards referral to the Police at an earlier stage, by
the time that the decision was made on 16 January 2015 those failings had been rectified. This is not,
therefore, a case such as the FM case in which the Competent Authority was relying on the absence of a
formal request from the Police in circumstances where the reason why there was no formal request was
that the Competent Authority had not made a referral. The Police in K's case had eleven months within
which to make a formal request. The fact that the Police made no formal request, in such circumstances,
puts the present case in a somewhat different category to the FM case. Applying the Competent Authority
Guidance at page 101, as for present purposes (subject to the Ground (2) challenge) the Defendant was
entitled to do, which Miss Meredith accepted, it must follow that this aspect of the Ground (1) challenge
also fails.

_106. I derive further support for the conclusion which I have reached from a case relied on by Miss_
Bretherton, R (Haile) v Secretary of State for the Home Department _[2015] EWHC 732 (Admin). In that_
case, Ms Alexandra Marks (sitting as a Deputy High Court Judge) was dealing with a claim for damages
alleging a breach of Article 4. She dismissed that claim, explaining as follows at [93]:

“To consider whether the Defendant failed in her duty to report the Claimant's case to the police once
_credible suspicions had arisen that the Claimant was a potential victim of trafficking, I shall first consider_
_the point at which the duty arose. Despite Ms Knorr's submission that a credible allegation was made in_
_2010, for the reasons I have given in paragraph 72 above, I do not accept that argument. The latest stage_
_at which the Defendant's duty arose was, in my judgement, in November 2013 when the Defendant made_
_her 'reasonable grounds' decision in respect of the Claimant as a victim of trafficking – and the earliest in_
_January 2013 when the NRM referred the Claimant's case to the Defendant. In January 2013, however, the_
_Defendant – acting under her then current guidance – found that the Claimant's allegations were historic._
_On the Claimant's own account, she had escaped from her employers/traffickers over three years earlier._
_The Defendant's guidance was, as a consequence of the Atamewan decision, found to be unlawful and_
_has since been revised. However, it seems to me that the Defendant's failure to report the matter to police_
_at that stage was consistent with her guidance and her NRG decision in January 2013 and – to adopt Mr_
_Banner's terminology – did not trigger any positive obligations under Article 4. Moreover, after making her_
_new 'reasonable grounds' decision in November 2013, the Defendant's later report, by her own motion, of_
_the Claimant's case to the police in January 2014 did not, in my view of the circumstances, constitute an_
_unreasonable or substantial delay. Nor is there any evidence that any alleged delay in reporting the matter_
_to the police rendered their investigation ineffective. Indeed, although the police only became involved_
_years after the events which might have given rise to criminal charges, it appears that after receiving the_
_first report in January 2014, the police were nevertheless able to identify – from the Claimant's entry visa_
_application – those who had employed and trafficked her. There is therefore no reason to believe that the_
_police investigation could not have been pursued further had the Claimant continued to cooperate with the_
_criminal enquiry. However, it clear from the Claimant's own witness statement that it was she who – for_
_perfectly understandable reasons – despite police encouragement to do so, decided not to take matters_
_further. Therefore the police investigation was closed.”_

Miss Bretherton submitted that these observations underline the fact that a failure to refer K's case to the
Police earlier than was done (the earliest date was a date in October 2013 whilst the referral was made in
February 2014), at a stage when the Defendant was following the pre-Atamewan policy guidance, is not
such as to trigger a breach of Article 4. I agree. Miss Bretherton also relied on the case as demonstrating
that, if it can be seen that any breach of Article 4 is of no causative relevance since by the time that the
decision as to whether to grant a residence permit is made a referral has been made and any prior delay
has made no difference, so there is no claim. I agree with this also.

**107. I would add that, consistent with the approach explained previously and as also accepted by Miss**
Meredith, in view of the way in which she ultimately couched both this aspect of the Ground (1) challenge
and the originally framed Ground (1) challenge as set out in paragraph 129 of the Amended Grounds for


-----

Judicial Review, as well as the Ground (3) challenge (which, now anyway, is concerned exclusively with
the Police co-operation issue), I take no account of events which have happened after the decision was
made on 16 January 2015. In particular, I take no account of certain exchanges between the Police and
the Defendant in August this year, which Miss Meredith handed up to me in her reply submissions,
accompanied by the explanation that the relevant documents had only recently been disclosed by the
Defendant, and which she suggested (inaccurately) involved the Defendant seeking to 'wrongfoot' the
Police concerning any investigation concerning K. This is not relevant to the issue which I have to
determine: the lawfulness of the decision made several months earlier, on 16 January 2015. Nor am I
assisted by various points made by Miss Meredith, as set out in her skeleton argument, concerning the
psychological effect on a victim of trafficking such as K and the consequential impact on a victim's
effectiveness when taking part in investigations. This was a point made by Miss Meredith when drawing
attention to an email from Bedfordshire Police sent on 11 November 2015, in which the point was made
that K had obvious difficulty dealing with the traumatic aspects of the investigation. I can understand that
this is likely to be the case. However, it can have no impact on my assessment of the lawfulness of the
decision under challenge in these proceedings.

108. All in all, I am satisfied, applying again the 'anxious scrutiny' approach (if applicable) and the
_Wednesbury test, that there is nothing in this aspect of the Ground (1) challenge. There was no departure_
from the Defendant's policy without explanation, or a failure to adhere to published (and internal) policy
such as to give rise to a vitiating public law error (see the Mutesi case at [45]).

**Ground (2): allegation that the Defendant's policy guidance is unlawful**

109. There are two aspects to the Ground (2) challenge, at least as described in the Amended Grounds
for Judicial Review. The first concerns personal circumstances and so Article 14(1)(a) of the Trafficking
Convention; the second concerns Article 14(1)(b) and the issue of co-operation with the Police. Only the
former was addressed in Miss Meredith's skeleton argument in the context of Ground (2); there was only
very fleeting reference to the latter in the skeleton argument, and then in relation to Ground (1), even
though the issue actually arises in relation to Ground (2) and I address the matter, therefore, in this
context.

_Personal circumstances_

110. Ground (2) was presented in Miss Meredith's skeleton argument as a relatively straightforward issue.
The submission was made that the _“compelling” and_ _“so compelling” tests contained in the Competent_
Authority Guidance (page 98) and the Asylum Policy Instruction (paragraphs 2.4 and 4.5) are unlawful
because they fail correctly to reflect Article 14(1)(a) of the Trafficking Convention. Miss Meredith made the
point that Article 14(1)(a) provides that a renewable residence permit may be _“appropriate”' if a person's_
_“stay is necessary owing to their personal situation”, whereas the Competent Authority Guidance (page 98)_
and the Asylum Policy Instruction (paragraphs 2.4 and 4.5) impose what Miss Meredith described as “an
_additional test” of compellability. This, she submitted, is at odds not only with the “appropriate” language of_
Article 10(1) allied with Article 14(1)(a), but also with paragraph 183 of the Explanatory Report to the
Trafficking Convention which refers to a person's personal circumstances being _“such that it would be_
_unreasonable to compel them to leave the national territory”. In these circumstances, applying the principle_
referred to in the Atamewan case at [69], in the Minh case at [53] and in the FM case at [11(i)], a principle
with which Miss Bretherton did not take issue, Miss Meredith submitted that if and insofar as the
Defendant's policy guidance purports to give effect to the terms of the Trafficking Convention yet fails to do
so, then there is a justiciable error of law, in the present case the Competent Authority Guidance (page 98)
and the Asylum Policy Instruction (paragraphs 2.4 and 4.5) are to be regarded as unlawful.

111. Miss Bretherton's response to this case was equally straightforward. She submitted that there is no
inconsistency between the Competent Authority Guidance (page 98) and the Asylum Policy Instruction
(paragraphs 2.4 and 4.5), and that as such these policies are lawful. Miss Bretherton submitted,
specifically, that it is important to read Article 14 of the Trafficking Convention, as she put it, “as a whole
_rather than to select individual elements of the obligation”. She amplified this, again in her skeleton_
t b ki th i t th t th t t f A ti l 14 i h t it “th t th _d t_ _i_ _l_ _if_


-----

_the competent authority” is “satisfied of the particular elements identified and then it considers that leave is_
_necessary”._

112. This was a reference to the fact that Article 14 provides that a party state “shall issue a renewable
_residence permit to victims, in one or other of the two following situations or in both”, before going on to_
make it clear in each of sub-paragraphs (a) and (b) that the situations both entail that _“the competent_
_authority considers” a certain thing: in the case of sub-paragraph (a), that the person's “stay is necessary_
_owing to their personal situation”; and in the case of sub-paragraph (b), that the person's “stay is necessary_
_for the purpose of their co-operation with the competent authorities in investigation or criminal_
_proceedings”. In each case, therefore, it is for the Competent Authority to consider whether either or both_
of the scenarios in sub-paragraphs (a) and (b) exist. Only if the Competent Authority considers that they
do, or one of them does, is there then an obligation (designated by the word “shall”) to issue a residence
permit. Miss Bretherton built upon this submission in her oral submissions, albeit that the submission
remained constant, by making the point that the wording used in Article 14(1) is in contrast to the language,
for example, used in Article 13(2) dealing with the “recovery and reflection period”, where what is stated, in
unqualified terms, is that “During this period, the persons referred to in paragraph 1 of this Article shall be
_entitled to the measures contained in Article 12, paragraphs 1 and 2”. She suggested that Article 14(1) is_
not as imperative in its terms, and that the reason for this is that it was recognised in Article 14(1)(a) and
(b) that the Competent Authority will need to carry out its own internal investigation of the particular
circumstances of a given case. That, Miss Meredith suggested, is obviously the reason why subparagraphs (a) and (b) state that the Competent Authority has to consider whether the scenarios described
exist.

113. Miss Bretherton also submitted that the words “so compelling”, as they appear in paragraphs 2.4 and
4.5 of the Asylum Policy Instruction, must be considered in context and not in isolation, highlighting how
paragraph 2.4 in particular states (with emphasis supplied) that in trafficking cases:

_“A grant of DL should be considered where a UK Competent Authority has conclusively identified that_
_person as a victim of trafficking within the meaning of Article 4 of the Council of Europe Convention on_
_Action Against Trafficking in Human Beings and the individual's personal circumstances,_ **_although not_**
**_meeting the criteria of any of the other categories listed, are so compelling that it is considered_**
_appropriate to grant some form of leave in line with the Duration of Grants of Leave below.”_

114. Miss Bretherton submitted, again in her skeleton argument, that this wording emphasises that, even
though the criteria of the other categories listed have not been met in a particular case, it can be
considered appropriate to grant leave in that case. Accordingly, this does not represent any _“additional_
_test”, but merely underlines “the additional rights afforded to victims of trafficking in Article 14 and the_
_policy”. This was a point which Miss Bretherton made in her oral submissions, when she observed that the_
grant of a residence permit under the NRM entails “a specialist ground in which someone can obtain leave
_to remain which presupposes that other grounds have failed”, those_ _“other grounds” being under the_
Immigration Rules. This was an observation made in the context of a submission that it is necessary _“to_
_look at the decision with an air of realism”._

115. It was this observation which provoked a response in the form of Miss Meredith's Note, on the basis,
she suggested (although I do not accept this is right), that Miss Bretherton's submission had not previously
been heralded. Miss Meredith, first, made the point that the reference in the Competent Authority Guidance
at page 98 under “Personal circumstances” to a person who “does not meet the criteria for any of the other
_leave or protection categories” represents an acknowledgment that, as Miss Meredith put it, “there might_
_be other categories under which the victim may qualify; and not that trafficking DL only applies if other_
_categories are not satisfied”. I do not see how this submission can be right. On the contrary, it seems to me_
that the words highlighted by Miss Meredith, far from supporting the submission which she made, provide
support for Miss Bretherton's observation. The words make it quite clear that the situation when
discretionary leave under the NRM may be appropriate is when the person fails to qualify for other
situations when leave is available. Indeed, as I see it, this reading is borne out by the last sentence of the
paragraph which starts with the wording relied on by Miss Meredith. That is the sentence which states:


-----

_“Unless further information has come to light, you do not need to reconsider a grant of discretionary leave if_
_it has already been considered together with a related asylum claim.”_

This relates to the case where discretionary leave has been refused, including under the Immigration
Rules, so indicating that, whilst the NRM does not require that other avenues have been exhausted before
it can operate, nevertheless that, at a minimum, might very well be the position.

116. Miss Meredith also relied on what is stated at page 99, suggesting that Miss Bretherton's submission
entails a misreading of what caseworkers are directed to do. The relevant wording states as follows under
_“Issuing the decision”:_

_“If you decide the person is a victim of trafficking and requires discretionary leave you must:_

_…_

_-            grant discretionary leave in line with Home Office discretionary leave policy_

_…”._

Then, under “Victims who are eligible for other types of leave”, the following is stated:

_“If a victim also qualifies for another form of leave, you must issue the more generous grant of leave.”_

Miss Meredith submitted that this demonstrates that a person might be able to obtain different types of
leave of different durations, for example under the Immigration Rules or discretionary leave as a victim of
trafficking. With that I agree. I did not myself understand Miss Bretherton really to have been suggesting
otherwise. What Miss Bretherton suggested, as I understand it, was not that the NRM is only available if
discretionary leave is unavailable under the Immigration Rules, but that, if discretionary leave under the
NRM is to be granted, it will generally be in circumstances where discretionary leave is not available under
the Immigration Rules. That seems to me to what the guidance at page 99 is itself saying: if a person
qualifies for discretionary leave under the Immigration Rules, that will be what should be granted.

117. Miss Meredith then pointed to the Competent Authority Guidance at page 103. This states as follows:

_“People who are conclusively found to be victims of trafficking, but who are not assisting with police_
_enquiries and are not eligible for a grant of leave, must still be issued with a positive conclusive grounds_
_decision._

_…_

_Normal immigration procedures will then apply as there will no longer be a barrier to removal on the_
_grounds of trafficking. …”._

This, Miss Meredith suggested, indicates that there is no specific order as to which comes first: an
application under the NRM or an application under the Immigration Rules. Again, whilst I consider that this
is probably right, it does not seem to me to represent an answer to Miss Bretherton's point, certainly
anyway in a situation where, as a matter of fact, as in K's case, a person has made immigration
applications which have failed, and then seeks to obtain discretionary leave under the NRM. It may well be
that the NRM does not require that it is only invoked when immigration applications have failed. This does
not mean, however, that where such applications have actually been made and have failed, and then an
application is made under the NRM, it is wrong to regard the NRM application as an application which, for
practical purposes, is an application of last resort.

118. However, this was not all that was addressed in Miss Meredith's Note. There was quite a bit more,
reflecting the fact that what had been a relatively straightforward matter on the face of the skeleton
arguments had by the end of the hearing, specifically during the course of Miss Meredith's reply
submissions, developed into an issue in relation to which a myriad of points were being raised. As I have
explained, I do not propose addressing each and every such point. I confirm again, however, that I have
taken everything into account. I consider that, in truth, the issue remains a simple one which is (or at least
ought to be) susceptible to a simple answer.


-----

119. A particular matter raised by Miss Meredith in the Note, however, is worth mentioning. This is Miss
Meredith's submission that, if it were the case that the NRM was a matter of last resort, then, this would
mean that there would be discrimination, in that, Miss Meredith explained, there would be an unjustified
distinction between victims in an irregular situation and those who are not in such a situation by requiring
the former “to cross a higher threshold”, something which the Trafficking Convention expressly prohibits in
Article 3, as follows:

_“The implementation of the provisions of this Convention by Parties, in particular the enjoyment of_
_measures to protect and promote the rights of victims, shall be secured without discrimination on any_
_ground such as sex, race, colour, language, religion, political or other opinion, national or social origin,_
_association with a national minority, property, birth or other status.”_

Miss Meredith also highlighted paragraph 69 of the Explanatory Report to the Trafficking Convention,
which deals with Article 3 and states as follows:

_“Thus Article 3 of the Convention might be contravened, even if there were no contravention of other_
_provisions of the Convention, if the measures provided for in those articles were implemented differently in_
_respect of particular categories of person (for example, depending on sex, age or nationality) and the_
_difference in treatment could not be reasonably justified.”_

Miss Meredith submitted that approaching the NRM on the basis that it were a matter of last resort would
involve discrimination as between different trafficked persons. She relied in this context on authorities
stating that victims of human trafficking are recognised as coming within the scope of a particular social
group within the context of claims for asylum: see **_AM and BM (Trafficked women) Albania v SSHD_**

_[2010] UKUT 80 (IAC),_ **_SB (PSG, Protection Regulations, Reg. 6) Moldova CG [2008] UKAIT and AZ_**
**_(Trafficked Women) Thailand CG_** _[2010] UKUT 118IAC. The difficulty with this submission, however, is_
that Article 14 of the Trafficking Convention only applies to people who have been trafficked. It follows that
suggesting that pointing to the fact that a person has been trafficked is capable of amounting to
discrimination for the purposes of Article 3 (or Article 14 of the ECHR) seems to me to make little sense.

120. In the circumstances, I do not propose now to take up more time dealing with Miss Meredith's various
other points in the Note produced during her reply submissions, but instead to address the submissions
which Miss Meredith made, both orally and in the final two pages of the Note, which directly concern the
lawfulness of the _“compelling” and_ _“so compelling” tests contained in the Competent Authority Guidance_
(page 98) and the Asylum Policy Instruction (paragraphs 2.4 and 4.5). I have previously addressed the
broader justiciability issue, rejecting Miss Meredith's submissions on this matter. There remains, however,
the question of whether the Defendant's policy guidance succeeds in giving effect to the terms of the
Trafficking Convention in circumstances where it purports to do so. As I have explained, if the policy
guidance does not do this, then, there is a justiciable error of law, and the Competent Authority Guidance
(page 98) and the Asylum Policy Instruction (paragraphs 2.4 and 4.5) are unlawful.

121. Responding to Miss Bretherton's central submission that, given the structure of Article 14(1) of the
Trafficking Convention, it is for the Competent Authority to consider whether either or both of the scenarios
in sub-paragraphs (a) and (b) exist, and only if the Competent Authority considers that they do, or one of
them does, is there then an obligation to issue a residence permit, Miss Meredith made a number of
submissions. First, she stressed that the introductory language of Article 14(1) states (with her emphasis)
that “Each Party shall issue a renewable residence permit to victims”. The wording is, therefore, imperative.
This, however, ignores Miss Bretherton's central reliance on what Article 14(1) goes on to refer to in subparagraphs (a) and (b) concerning the Competent Authority having to consider that either or both of the
scenarios there identified apply. I am not, accordingly, impressed by Miss Meredith's first point in this
regard.

122. As to Miss Meredith's second point, this was that any evaluation of the factual position by the
Competent Authority requires that the Competent Authority exercises its discretion in a manner which is
compatible with the Trafficking Convention, as well _“its object and purpose”. In relation to this, Miss_
Meredith emphasised the 'human rights approach' adopted in the Trafficking Convention, relying on the
matters to which I have referred in paragraphs 57 and 58 above along with various other references to the


-----

Explanatory Report to the Trafficking Convention set out in the Note provided during the course of her reply
submissions (specifically, paragraphs 11, 29, 30, 31, 32, 33, 36, 41, 46, 50 and 51). She submitted, in
effect, that the _“compelling” and_ _“so compelling” tests contained in the Competent Authority Guidance_
(page 98) and the Asylum Policy Instruction (paragraphs 2.4 and 4.5) represent an illegitimate fetter on the
'human rights approach' which renders the protection envisaged by the Trafficking Convention illusory. The
difficulty with this submission, however, as it seems to me, is that it is still necessary to have regard to what
Article 14(1) states. If the Defendant's policy guidance is not at odds with Article 14(1), the provision which
specifically deals with the grant of residence permits, then, in my view, the argument that the policy
guidance is unlawful must fail. I acknowledge that it is legitimate to read Article 14(1) against the backdrop
of the other provisions contained in the Trafficking Convention and in its Explanatory Report, including
therefore all the passages relied upon by Miss Meredith. I have done so. Nevertheless, it is still necessary
to look at what Article 14(1) actually has to say and Miss Meredith's wider submissions concerning the
'human rights approach' cannot act as a substitute for doing this.

123. Miss Meredith's third point was that it is not open to this country to “alter the conditions for a grant of
_a permit under 14(1)”, something which is to be contrasted with what is provided for in Article 14(3) which_
states that “The non-renewal or withdrawal of a residence permit is subject to the conditions provided for
_by the internal law of the Party”. Miss Meredith also highlighted how under Article 14(4), where a trafficking_
victim submits “an application for another kind of residence permit” (in other words, not a residence permit
under Article 14(1)), a state “shall take into account that he or she holds, or has held, a residence permit in
_conformity with paragraph 1”. Miss Meredith suggested that this amounts to a recognition that the grant of_
a residence permit under Article 14(1) is of a sui generis nature. Miss Meredith followed up these various
observations with a related submission that it is not open to the Defendant to suggest that the exercise of
its discretion under Article 14(1)(a) and (b) enables her (as the Competent Authority) to have regard to the
Trafficking Convention rather than being bound by its specific terms. Miss Meredith submitted that in this
respect the Defendant's (and Miss Bretherton's) approach is contrary to authority. Otherwise, she
submitted, the United Kingdom would find itself in breach of its international obligations as set out in the
Trafficking Convention (see the Hounga case at [50] per Lord Hughes) or guilty of “a justiciable Atamewan
_error”._

124. As to this last matter, I have already addressed the argument advanced by Miss Meredith concerning
the justiciability of the Trafficking Convention. I do not repeat my conclusions in this respect, other than to
make it clear (again) that the question which arises in relation to Ground (2) is whether there has been a
justiciable error of law arising from the fact that the Defendant's policy guidance purports to give effect to
the terms of the Trafficking Convention yet fails to do so (see the Atamewan case at [69], the Minh case at

[53] and the FM case at [11(i)]). More generally, however, Miss Meredith's submissions as set out in the
previous paragraphs are not submissions which I can accept. I agree with Miss Bretherton that, in
circumstances where the Trafficking Convention has not been directly incorporated into the law of England
and Wales, and where the Trafficking Convention is not directly enforceable in this country, it would be a
mistake to regard the Trafficking Convention as though it had been incorporated and has direct effect. As
the Competent Authority Guidance itself makes clear on each of its 115 pages, “The guidance is based on
_the Council of Europe Convention on Action against Trafficking in Human Beings”. It is_ _“based” on the_
Trafficking Convention; it is not the Trafficking Convention itself. Nevertheless, consistent with the principle
to which I have referred and which is not disputed by Miss Bretherton, if the Competent Authority Guidance
and the Asylum Policy Instruction are not consistent with Article 14(1), they will contain a justiciable error in
law as Miss Meredith has suggested. As I have made clear already, this, therefore, is the central question:
are the Competent Authority Guidance and the Asylum Policy Instruction consistent with Article 14(1)? In
my judgment, they are since I consider that, on analysis, there is nothing in Article 14(1) which, in
considering the matters identified in sub-paragraphs (a) and (b), prevents the Defendant (as the
Competent Authority) from applying the _“compelling” and_ _“so compelling” tests. I see nothing in Article_
10(1) (with its reference to there being _“appropriate cases” in which to issue residence permits_ _“in the_
_manner laid down in Article 14”) or in Article 14(1) itself or in paragraph 183 of the Explanatory Report to_
the Trafficking Convention (with its reference to a person's personal circumstances being _“such that it_
_would be unreasonable to compel them to leave the national territory”), including when viewed against the_


-----

backdrop of the 'human rights approach' which Miss Meredith has emphasised, which is inconsistent with
the Competent Authority Guidance and Asylum Policy Instruction tests. On the contrary, in my view, the
specific references in sub-paragraphs (a) and (b) to the Competent Authority being the party which gives
the consideration described demonstrate that, as Miss Bretherton submitted, it is for the Competent
Authority to consider whether either or both of the scenarios in sub-paragraphs (a) and (b) exist. If the
Competent Authority considers that this is the case, a residence permit must then be issued, hence the
word _“shall” appearing at the start of Article 14(1) before sub-paragraphs (a) and (b) are set out; if the_
Competent Authority considers that is not the case, then there is no obligation to issue a residence permit.
There is nothing in sub-paragraphs (a) and (b) to restrict the approach to be adopted by the Competent
Authority. I do not consider it right, in these circumstances, to approach the matter as though there were.
That said, it seems to me that the _“compelling”/“so compelling” tests contained in the Defendant's policy_
guidance amount to a recognition of the fact that paragraph 183 of the Explanatory Report to the
Trafficking Convention refers to a person's personal circumstances being _“such that it would be_
_unreasonable to compel them to leave the national territory”. As I see it, there is no inconsistency in a_
requirement that consideration is given as to what would be _“unreasonable” and a requirement that_
consideration be given as to whether a person's personal circumstances are _“compelling” or_ _“so_
_compelling” as to warrant the grant of a residence permit. The more so, although this is not critical to the_
conclusion which I have reached, when it is appreciated that, whilst the grant of a residence permit under
the NRM is not something which can only be done once a person has failed to obtain leave under the
Immigration Rules, in practice, if a person is able to obtain leave under the Immigration Rules, that leave
will be obtained and a residence permit will not be granted under the NRM. This is the point which I
addressed in paragraphs 113 to 117 above.

125. As to Miss Meredith's third point specifically, the fact that Article 14(3) is in mandatory terms is
explained by the fact that this is a provision which applies after a residence permit has been issued under
Article 14(1), and so at a stage when the trafficking victim has already had the benefit of the protection laid
down by Article 14(1). At that stage, a country's “internal law” is clearly all that matters. Similarly in relation
to Article 14(4), which is anyway concerned with an application for a residence permit different from that
available under Article 14(1), it makes sense that the individual country should have to make the relevant
decision without having to consider the matters set out in Article 14(1)(a) and (b). As such, it is obviously
right that that country should be able to make its own decision. It does not follow, however, given especially
the language used in Article 14(1)(a) and (b), that the country is under an obligation to issue a residence
permit under Article 14(1) and is unable to refuse to do so in circumstances which involve the operation of
a policy which prevents it from applying a “compelling”/“so compelling” test.

_Police co-operation_

126. The other aspect of the Ground (2) challenge concerns the issue of co-operation with the Police. As I
have observed, this is a matter which was barely addressed in Miss Meredith's skeleton argument, but it
was canvassed by her during her oral submissions and it was also dealt with in the Amended Grounds for
Judicial Review. It is appropriate, in these circumstances, that I myself address the issue.

**127. Miss Meredith's submission, in essence, is that Mr Corcoran's reliance, in the decision letter dated 16**
January 2015, on the absence of “a formal request from the police in respect of your client assisting them
_with their enquiries”, resulting in his decision not to grant K a residence permit, entailed the application of_
policy guidance, contained in the Competent Authority Guidance at page 101, which is at odds with Article
14(1)(b) of the Trafficking Convention, with the consequence that there is a justiciable error of law, again
having regard to the principle to which I have referred the principle (see again the Atamewan case at [69],
the **_Minh case at [53] and the_** **_FM case at [11(i)]) and which is not disputed by Miss Bretherton. Her_**
submission was that nowhere in the Trafficking Convention is there any mention of there needing to be a
request, formal or otherwise, for the trafficked person's _“co-operation with the competent authorities in_
_investigation or criminal proceedings”. Miss Meredith submitted that, in the circumstances, if the_
Competent Authority Guidance is to be regarded as involving a condition precedent that there be a formal
request from the Police, then, the Competent Authority Guidance contains, in this respect, a justiciable
error of law In this regard again as I have mentioned Miss Meredith made the point that in the FM case at


-----

[29] it was accepted by the Secretary of State's counsel that the requirement at page 101 of the Competent
Authority Guidance is not a condition precedent to the grant of a residence permit.

**128. Miss Bretherton was not prepared to make the same concession in the present case, although I**
understood her to accept that if, notwithstanding that there was no formal request from the _“competent_
_authorities”, it was nonetheless clear that those authorities (typically the authorities engaged in_
investigations or prosecutions, and so not the Competent Authority making the determination whether to
grant a residence permit) wished for a person to be permitted to remain in this country in order to assist
with investigations or a prosecution, then, in practice, a residence permit would likely be granted. It was
Miss Bretherton's central proposition, however, that Miss Meredith's submissions are premised on what
was described by Miss Bretherton as _“an artificial distinction between the language of Article 14 and the_
_policy which are akin to the Claimant arguing that any explanation beyond the language of Article 14 itself_
_gives rises to an unlawful policy”. I agree with Miss Bretherton about this. I agree, in particular, that there is_
no inconsistency between Article 14(1)(b) and page 101 of the Competent Authority Guidance, specifically
its requirement that the Police should have made a formal request. That requirement makes it known what
the Defendant (as the Competent Authority) will require if she is to consider that a stay is necessary for the
purposes of investigation or prosecution. There is nothing in Article 14(1)(b) which precludes her from
making this clear, nor from operating on the basis that a formal request is necessary. In the circumstances,
I see nothing objectionable about the requirement. It makes sense also from a practical perspective since
the obvious means by which the Defendant can make a decision as to whether a stay is necessary under
Article 14(1)(b) is if the “competent authorities” (the Police or other investigating authorities, or the Crown
Prosecution Service or other prosecuting authorities) let it be known that the trafficked person's cooperation is required by them. As Miss Bretherton rightly observed during the course of her oral
submissions, the Defendant does not make investigatory or prosecution decisions. For this reason, she
needs to be told that assistance is needed. In the circumstances, I am clear that there is nothing unlawful
about the policy guidance set out in the competent authority Guidance at page 101.

**129. For all these reasons, relating to both aspects raised by Miss Meredith on K's behalf, the Ground (2)**
challenge must fail.

**Ground (3): alleged breach of Article 4 as a result of a failure to exercise 'anxious scrutiny' of K's**
**eligibility for a residence permit**

130. Ground (3) is a matter which, in essence, I have already considered in the context of Ground (1)
when dealing with the Police co-operation aspects of that challenge.

131. As I have mentioned, Ground (3) in the Amended Grounds for Judicial Review was concerned not
with the Police co-operation issue at all since the relevant paragraph, paragraph 141, contains a crossreference back to paragraph 125, a paragraph which concerns matters which did _not include a Police_
investigation. It was only in response to Miss Bretherton's skeleton argument that Miss Meredith explained
that actually Ground (3) should be treated as having as its exclusive focus the issue of co-operation with
the Police. Miss Meredith subsequently confirmed at the hearing that, consistent with how the point was
put at paragraph 141, the focus of Ground (3) is on matters as they stood at the time of the decision on 16
January 2015, not subsequent matters. Specifically, the case which is advanced is that, when making the
decision on 16 January 2015, there was a breach of Article 4 in failing to exercise 'anxious scrutiny' having
regard to the Defendant's previous failure to make a referral to the Police.

132. As I have previously observed and as also confirmed by Miss Meredith, Ground (3), therefore, links in
with the Ground (1) case as contained in the Amended Grounds for Judicial Review (that the Defendant
failed to take into account “the impact of her previous failure to do anything in relation to a referral to the
_police for investigation, contrary to Atamewan and her policy, and despite the repeated requests for a_
_referral to be made”) and the additional Ground (1) case advanced by Miss Meredith in her skeleton_
argument (that the Defendant's decision to refuse a residence permit to K “should be quashed for the delay
_and/or failure to involve the police”). Each of the cases, including Ground (3), is concerned with the_
Defendant's previous failure (prior, that is, to January 2014, a year before the decision made on 16 January
2015) to make a referral to the Police


-----

**133. In the light of the conclusions which I have reached in relation to the submissions advanced by Miss**
Meredith under Ground (1), I conclude also that there was no breach of Article 4 on the part of the
Defendant in failing to exercise 'anxious scrutiny' (if that is what was required) when making the decision
on 16 January 2015 having regard to any previous failure to make a referral to the Police. It follows that the
Ground (3) challenge must also be rejected.

**Ground (4): alleged failure to take account of 'historic injustice'**

134. Lastly, I consider Ground (4), which arises separately from the Article 4 challenge contained in
Ground (3) as well as the related challenge which forms part of Ground (1). I have no hesitation in rejecting
the submission made by Miss Meredith, albeit not in her skeleton argument nor in the further skeleton
argument submitted in response to Miss Bretherton's skeleton argument ahead of the hearing nor in the
Note provided during the course of Miss Meredith's submissions, that Mr Corcoran acted unlawfully in
making his decision on 16 January 2015 because he failed to consider, or acknowledge, the principle that
the Defendant is required to correct an historic injustice to K as a victim of trafficking. This, it will be
recalled, is the argument which Miss Meredith explained in her skeleton argument was not pursued as part
of the present proceedings since, she explained, it was recognised by K and his legal team that leave to
remain on the basis of correcting an historic injustice is a separate issue to be determined most
appropriately through an application under the Immigration Rules rather than in the present context. It was
only during the course of Miss Bretherton's submissions that Miss Meredith stated that the argument was
still pursued within these proceedings, albeit that, after this judgment was sent to the parties in draft, Miss
Meredith then explained that Ground (4) was not, after all, intended to be resurrected.

135. In truth, the argument is hopeless. The case relied on, EK (Tanzania) _[[2013] UKUT 313, concerning](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5929-8BS1-F0JY-C1RS-00000-00&context=1519360)_
the 'historic injustice' principle is an immigration case rather than an NRM case, and so Ground (4) has no
application in the present proceedings. Miss Meredith advanced no submissions before me in support of a
case to the contrary. This, in circumstances where, as I say, in her own skeleton argument the point was
made that the 'historic injustice' principle applies to immigration decisions. Indeed, as I have explained, it
was confirmed in the note submitted in response to the draft judgment being sent to the parties that
Ground (4) was not, after all, pursued in the context of these (judicial review) proceedings. This, also, in
circumstances where I was shown no authority in the NRM context which indicates that the same approach
applies as it does in the immigration context. This, in addition, in circumstances where Article 14(1) makes
no reference to 'historic injustice' being a basis on which the Competent Authority can consider that a stay
is necessary. This, lastly, in circumstances where it is to be noted that it was never suggested prior to the
decision made on 16 January 2015 that Mr Corcoran should have regard to the 'historic injustice' principle.
This last point is especially telling given that it is stated in paragraph 143 of the Amended Grounds for
Judicial Review that the Defendant _“failed, without reason or justification, to consider this aspect”. If the_
'historic injustice' principle were applicable to an application under the NRM, it might have been expected
that that would have been stated by Wilsons to Mr Corcoran, yet this was not done. I struggle to see how,
in view of this, it can really be right to conclude that Mr Corcoran was in error in not taking the matter into
account. I am clear that in this regard he was not in error.

**Conclusion**

136. In the circumstances and for the reasons which I have given, I dismiss K's claim for judicial review. I
consider that the decision made on 16 January 2015 was a lawful decision which, as such, is not
susceptible to legitimate challenge.

**End of Document**


-----

