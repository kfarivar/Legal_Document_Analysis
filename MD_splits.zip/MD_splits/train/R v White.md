# R v White [2020] EWCA Crim 1825

CA, CRIMINAL DIVISION

202002269 A4

Andrews LJ, Cutts J, HHJ Lodder QC

Friday, 13 November 2020

13/11/2020

MRS JUSTICE CUTTS:

1 On 31 July 2020 in the Crown Court at Woolwich this appellant, then aged 17 years, pleaded guilty on Counts 2
to 4 of the indictment to three offences of burglary contrary to s.9(1)(b) of the Theft Act 1968 and one offence of
attempted burglary contrary to s.1(1) of the Criminal Attempts Act 1981 (Count 6). Count 1, an offence of
conspiracy to burgle, was left to the lie on the file on the usual terms.

2 On 1 September 2020 he was sentenced on each count to concurrent terms of 18-months Detention and
Training Order. He was erroneously ordered to pay the surcharge in the sum of £21 when it should have been in
the sum of £32. The appellant was charged together with four other young men. Two, Stephen Tripp and Conner
McKay, pleaded not guilty and await trial. A third, Bobby Turner, aged 18 years by the time of sentence, also
pleaded guilty to the three counts of burglary and one of attempted burglary. Given the likely delay in any trial, the
judge proceeded to sentence the appellant and Turner. Turner was sentenced to 18 months' detention in a Young
Offenders' Institution for the offences. He was also sentenced for separate offences upon a separate indictment,
that is burglary and aggravated vehicle taking, to 12 months' detention consecutive. His total sentence was,
therefore, one of 30 months' detention in a Young Offenders' Institution. In his case, the conspiracy allegation in
Count 1 was also ordered to lie on the file. Proceedings were later discontinued in relation to Arthur Greenslade,
who was found to be a victim of modern slavery. This appellant appeals his sentence with the leave of the single
judge.

3 We turn, firstly, to the facts of the offences in Counts 2 and 6. On 16 November 2019 at around 1.00 a.m. a
resident in Cadwallon Road, New Eltham was awoken by a security light and upon looking out of the window saw
four males walking around trying front door handles. The resident called the police as two of the males entered the
house at Number 34 whilst the other two waited outside. Police arrived a short time later, whereupon the four
males decamped. The appellant was caught nearby, as was Arthur Greenslade. The other two males escaped
from the scene, but were later apprehended. Items stolen from the property included clothing, car keys and house
keys. Greenslade was found to be in possession of a screwdriver and a room key for a Travelodge. The

Travelodge room was searched and the co‑accused, McKay and Tripp, were found therein.

4 CCTV showed the four burglars arriving at Cadwallon Road about half an hour before being disturbed. They split
up and tried various doors. Around ten door handles were tried unsuccessfully. Number 34 was found to be
insecure. The burglars appeared to be looking for car keys to enable them to steal cars from the driveways outside.
When the appellant was searched, he was found in possession of a mobile phone which was subsequently
interrogated. The phone contained video clips showing a group of young men driving expensive cars. One of the
cars was a Mercedes that had been stolen in a burglary in Kent in the early hours of 13 November 2019. Enquiries
revealed that there had been two burglaries in that vicinity that night A property in Broad Lane Dartford was


-----

broken into and car keys were taken to a Mercedes which was then stolen. Half an hour later in Church Road in
Greenhithe a similar burglary occurred and a Range Rover was stolen, the keys having been taken from inside the
address. That vehicle was recovered as it was fitted with a tracker, but the Mercedes was never recovered. The
appellant's phone had video clips showing both him and Turner in the vehicles and cell site evidence placed them in
the vicinity of the burglaries. These offences were reflected in Counts 3 and 4 of the indictment.

5 As we have already said, the appellant was aged 17 at sentence, having been born on 18 October 2002.
Despite his youth, he had appeared before the courts on three previous occasions for six offences between 2018
and 2019. In January 2018 he was sentenced to a referral order for handling stolen goods and driving offences. In

October of that year he received a Youth Rehabilitation Order for a non‑dwelling burglary. In 2019 he was ordered

to pay compensation for two offences of battery. He had breached two previous court orders by failing to appear. It

was noted in the pre‑sentence report that he struggled with engagement and compliance, although he had complied

well on the three occasions he had been subject to an electronically monitored curfew. Turner was aged 18 at
sentence, having been born on 6 June 2002. He had appeared before the courts on 18 previous occasions for 36
offences between 2015 and 2020. His offences included criminal damage, abusive behaviour, theft, possession of
a knife, battery, common assault, fraud and multiple breaches of court orders.

6 The judge had the benefit of a pre‑sentence report and an educational psychology report in relation to the

appellant. The pre‑sentence report observed that the appellant remained very closed regarding his version of

events, which may have been due to a fear of further incriminating himself and/or his co‑accused. The author

recorded however that he now wanted to take responsibility for what he had done and had shown maturity in his
acceptance. She noted that according to the educational psychology report he struggled with being able to feel
empathy for other people, due to the development of his emotional literacy. The appellant had been permanently
excluded from school at the age of 14. He had failed to engage with further attempts to educate him. He had not
been in education, employment or training since 2018.

7 The overall safety and well‑being concerns relating to the appellant were assessed as high. There were

concerns he could come to physical harm in the community through his behaviour or the behaviour of his peers.
There was the possibility he could be the target of retaliation as a result of something he had done or who he was
associated with. A car had been set on fire on the driveway of his home and it was thought this might have been a
retaliation for something, though this was not confirmed. This was indicative of a risk to the safety of the appellant
and his family and the risk remained relatively current. The author recommended that a community order be
passed. Although she recognised that it was a challenge to manage the appellant in the community, in her view he

required an intensive approach to help him form structure to his day‑to‑day life and with the transition to adult

probation services.

8 The educational report was written in 2017 when the appellant was aged 15 years in order to assess his special
educational needs. At that age, he was said in educational terms to be operating at between three and eight years
below his chronological age. An Educational Health and Care Plan written in 2019 stated that he was then delayed
in his emotional literacy development, particularly in motivation and empathy. In the view of the author he
presented as a young person who was emotionally younger than his peers.

9 In mitigation, the appellant relied upon the findings of the educational psychologists; his good compliance with
electronic tags; his disrupted childhood caused by his father leaving the family home when he was aged two years;
the fact that he continued to be a criminal grooming risk; the offer of employment from his uncle and the view of the

author of the pre‑sentence report that he was showing signs of positive change.

10 Sentencing the appellant and his co‑accused, the judge observed that these offences must have been horrible

and terrifying experiences for the home owners who had their homes broken into at night whilst they were asleep
upstairs. Having expensive cars stolen, would cause them some loss. He placed all offences to which they had
pleaded guilty into category 1 of the relevant Sentencing Council Guideline. They were offences of greater harm by


-----

reason of them occurring at night with the occupiers at home and because they were targeting property of high

value. They were offences of high culpability, because this was well‑organised group activity. This resulted in a

starting point for an adult after a trial of three years' imprisonment with a range of two to six years. The parties were
agreed that given the maximum sentence of 14 years for offences of burglary, in the appellant's case s.91 and the
Powers of the Criminal Court (Sentencing) Act 2000 could apply.

11 The judge expressly considered the Sentencing of Children and Young People Definitive Guideline. In so
doing, he recognised that in light of the appellant's age he needed to consider the possibility of rehabilitation and
every available sentencing option before custody. Having done so, he concluded that only an immediate custodial

sentence could be justified. This was because the offending was well‑organised and contrived to steal keys of

expensive cars. It comprised a series of incidents, including clear attempts on the night of 16 November to try as
many houses as possible in order to steal as many cars as they could.

12 In the view of the judge, had the appellant been an adult, the starting point for the totality of the offending would
have been one of six years' imprisonment. Taking account of his age he reduced that by half, the maximum
reduction suggested in the Sentencing Guideline for offenders aged 15 to 17, to three years. He accorded credit of
25 per cent for the appellant's guilty pleas, which further reduced the sentence to one of 27 months. The judge
drew back from passing such a sentence under s.91 of the Powers of Criminal Court (Sentencing) Act. Rather,
given the appellant's age and the fact that he had not been in custody before, he considered it appropriate to further
reduce the sentence to one of 18 months' Detention and Training Order on each count to run concurrently.

13 The judge then turned to the sentence of the co‑accused Turner. He recognised that although aged 18 at the

time of sentence Turner was aged only 17 at the time of the offences with which he was jointly charged with the
appellant. He had also to sentence him for further offending with which the appellant was not involved. Bearing in
mind the principle of totality, he approached the sentence on the joint indictment of Turner in the same way as that
of the appellant, passing sentences of 18 months' detention on each count concurrent. He passed sentences of 12
months' detention for each of the further offences concurrent inter se but consecutive to the 18 months, resulting in
an overall sentence ever 30 months' detention.

14 Following the sentencing of the co‑accused, Mr Crosbie, who represented the appellant in the court below as he

does before us today, raised the question of the appellant's curfew. The appellant had been on bail prior to
sentence, a condition of which was that he complied with a curfew. Mr Crosbie submitted that the appellant was
therefore entitled to 143 days' deduction from any sentence passed. The judge indicated that had he known of this
prior to sentence, the length of the sentence would have remained the same. He had reduced the sentence of 27
months to 18 months, which he considered to be generous in the circumstances. He did not consider any further
reduction would meet the justice of the case.

15 Turning to the appeal, Mr Crosbie submits that the sentence imposed upon this appellant was manifestly
excessive on the following grounds. First, he submits that the judge erred in failing to further reduce the sentence
for recognition of the time the appellant spent on a qualifying curfew. Second, he contends that the judge's starting
point of six years at the top of the category range was too high in the circumstances of the case and the judge erred
in failing to distinguish between burglaries and attempts. Third, the judge gave insufficient reduction for the
appellant's age and maturity. Mr Crosbie submitted in his written submissions that he should have received up to

the maximum of two‑thirds reduction allowed for in the Guideline relating to the sentencing of children and young

people. He submits the judge erred in failing to give adequate reasons as to why a Youth Rehabilitation Order
could not be justified. Fourth, he contends that the judge failed to pay sufficient regard to the appellant's welfare
and personal mitigation. Fifth, he submits the sentence was inconsistent with that imposed upon Turner, who
should by reason of his age and previous convictions have received a longer sentence than the appellant. Next, he
submits the judge paid insufficient regard to the harsher prison conditions by reason of the Pandemic, as this court
required in R v Manning _[2020] EWCA Crim 592. Finally, he submits that the judge erred in treating the counts to_

which the appellant had pleaded guilty as sample counts and in so doing inadvertently over‑sentenced him.


-----

16 We have reflected upon these submissions. We can find no fault in this case with the judge's approach to the
sentencing exercise, which in our view was a model of its kind. He had first to decide where the offending fell within
the relevant adult guideline. We agree with the judge that the appellant pleaded guilty to serious offences and find
no force in the submission that in all the circumstances of the case the judge adopted too high a starting point.
Very sensibly, there is no dispute that each offence fell within category 1. That specifies a starting point of three
years for a single offence. The judge in the instant case was sentencing the appellant for three substantive
offences of burglary and one attempt. In our judgment, that fact alone entitled him to move up the category range.
There were, additionally, multiple factors of greater harm and of higher culpability, which together with the
aggravating factors properly identified by the judge entitled him to conclude the totality of the offending to which the
appellant had pleaded guilty, that is the substantive offences and the attempt combined, fell at the highest end of
the category range. As to the final ground, we do not accept the contention that the judge treated all offences as
sample counts. The judge only treated the attempted burglary in Count 6 in this way. This in our view he was
entitled to do following the appellant's admission that he was part of an agreement to try as many houses as he
could in Cadwallon Road to try to find a weak spot to gain entry. As the judge rightly stated, Count 6 therefore
represented the wider attempts that night. This was the way in which the facts of Count 6 were opened by the
prosecution. We are told today that no objection was taken to this at the time nor sensibly could it have been given
the CCTV evidence in the case.

17 Having reached the starting point for an adult offender, the judge then correctly addressed the question of the
appellant's age at the time of the offending by reference to the relevant guideline. H e considered the question of
rehabilitation, but concluded that the seriousness of the totality of the offending was such that, notwithstanding the
appellant's youth, immediate custody was required. We cannot accept Mr Crosbie's contention that he failed to give

reasons for this conclusion. The judge could not have been clearer that the well‑organised nature of the offending,

the targeting of keys to expensive cars and the number of incidents led him to reject any sentence other than
custody. It is a conclusion with which we entirely agree. We observe in so saying that this appellant had also failed
to comply with community orders in the past. The judge recognised that a reduction to any custodial sentence was
necessary to reflect the appellant's age. Contrary to Mr Crosbie's submissions, we consider the reduction of the
sentence by half to be generous in all the circumstances. As Mr Crosbie conceded in the course of his

submissions, his contention that the relevant guideline applied a maximum of two‑thirds reduction of the appropriate

adult sentence was based on a misreading of it. The Guideline states there should be no mechanistic approach in
reduction in custodial sentences by reason of age. Para.6.46 says this:

"When considering the relevant adult guideline, the court may feel it appropriate to apply sentence broadly within
the region of a half to two-thirds of the adult sentence for those aged 15 to 17 and allow a greater reduction for
those aged under 15."

18 It is clear, as Mr Crosbie now accepts, that if applied this would result in a reduction of the adult sentence within

the region of one half to one‑third for those aged 15 to 17. So seen, the judge applied the greater suggested

reduction to this appellant. This can only have been in recognition of his emotional and developmental age and his
lack of maturity. The judge then applied appropriate credit of 25 per cent, reaching the sentence of 27 months'
detention. As he said, he could have passed such a sentence under s.91, but he did not do so, reducing the

sentence by a further nine months to reach the 18‑month Detention and Training Order imposed. We cannot

accept in those circumstances that the judge failed to pay sufficient regard either to the appellant's youth or his
personal mitigation.

19 We turn next to the contention that the appellant's sentence was inconsistent with that imposed upon Turner.
We cannot accept that it was. In sentencing Turner, the judge had to take account of both his age at the time of the
offences with which this appeal is concerned and with the totality of the sentences he imposed on all of the offences
to which Turner had pleaded guilty. In those circumstances, he was not only entitled but also in our judgment
correct to approach the sentence in the way that he did, notwithstanding that Turner had a worse criminal record
than the appellant. In any event, this court is concerned with the appellant's contention that his sentence is


-----

manifestly excessive. The fact that a co‑accused receives what may be perceived as a lenient sentence does not

impact on that question.

20 We turn finally to the question of the appellant's curfew. S.240A(1) of the Criminal Justice Act provides:

(1) This section applies where—

(a) a court sentences an offender to imprisonment for a term in respect of an offence...

(b) the offender was remanded on bail by a court in course of or in connection with proceedings for the offence, or
any related offence, after the coming into force of section 21 of the Criminal Justice and Immigration Act 2008, and

(c) the offender's bail was subject to a qualifying curfew condition and an electronic monitoring condition."

21 The credit period is defined by (3) in short as half the number of the days the offender spent on such a
qualifying curfew. When sentencing an adult offender, the judge has no discretion in this regard and by virtue of
this section must direct that this period is to count as time served. However, in this case the judge was not
sentencing the appellant to a term of imprisonment, but to a Detention and Training Order. The approach to a
qualifying curfew when passing such a sentences is governed by s.101(8)(b) of the Powers of Criminal Court
(Sentencing) Act 2000 which provides:

"(8) In determining the term of a detention and training order for an offence, the court shall take account of any
period for which the offender has been remanded

(a) in custody, or

(b) on bail subject to a qualifying curfew condition and an electronic monitoring condition (within the meaning of
section 240A of the Criminal Justice Act 2003) in connection with the offence, or any other offence the charge for
which was founded on the same facts or evidence."

22 It can be seen that unlike the mandatory requirement to direct that the credit period is to count as time served
by an adult offender contained within s.240A of the Criminal Justice Act, imposing a Detention and Training Order a
judge need only "take account" of any such period. This is no doubt by reason of the set periods for which a
Detention and Training Order can be made. In the instant case, the judge once appraised of the qualifying curfew
did just that, coming to the conclusion that the further reduction he had already made took the curfew into account.
We find no merit in the contention that the judge erred in this regard.

23 This court is concerned solely with the question of whether the sentence imposed upon this appellant was
manifestly excessive. Having considered his grounds of appeal individually, we stand back to consider the
sentence as a whole. In so doing, we cannot accept that it was. Even taking the effect of the Pandemic on the
conditions of those in custody into account, it was in our view comfortably within the range available and could
possibly be regarded as towards the lower end of that range and this appeal is accordingly dismissed.

24 As we have upheld the sentence imposed upon this appellant, it is not open to us to increase the amount of the
surcharge to be paid by him as such would be to increase his sentence overall. That is of course prohibited by
s.11(3) of the Criminal Appeal Act 1968.

_______________

**End of Document**


-----

