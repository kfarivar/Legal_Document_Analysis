# TD and AD (Trafficked women) [2016] UKUT 92 (IAC)

Upper Tribunal (Immigration and Asylum Chamber)

Judge Dawson and Judge Bruce

9 February 2016Judgment

**Representation:**

For the Appellants: Miss S Khan, instructed by Ison Harrison Solicitors

Miss R Frantzis, instructed by Bankfield Heath Solicitors

For the Respondent: Mr S Whitwell, Senior Presenting Officer

_Much of the guidance given in AM & BM (Trafficked women) Albania CG [2010] UKUT 00080 (IAC) is_
_maintained. Where that guidance has been amended or supplemented by this decision it has been highlighted in_
_bold:_

_“a)        It is not possible to set out a typical profile of trafficked women from Albania: trafficked_
_women come from all areas of the country and from varied social backgrounds._

_b)        Much of Albanian society is governed by a strict code of honour which not only means that_
_trafficked women would have very considerable difficulty in reintegrating into their home areas on return but also will_
_affect their ability to relocate internally. Those who have children outside marriage are particularly vulnerable. In_
_extreme cases the close relatives of the trafficked woman may refuse to have the trafficked woman's child return_
_with her and could force her to abandon the child._

_c)_ **_Some women are lured to leave Albania with false promises of relationships_**
**_or work. Others may seek out traffickers in order to facilitate their departure from Albania and their_**
**_establishment in prostitution abroad. Although such women cannot be said to have left Albania against_**
**_their will, where they have fallen under the control of traffickers for the purpose of exploitation there is_**
**_likely to be considerable violence within the relationships and a lack of freedom: such women are victims_**
**_of trafficking._**

_d)_ **_In the past few years the Albanian government has made significant efforts to_**
**_improve its response to trafficking. This includes widening the scope of legislation, publishing the_**
**_Standard Operating Procedures, implementing an effective National Referral Mechanism, appointing a new_**
**_Anti-trafficking Co-ordinator, and providing training to law enforcement officials. There is in general a_**
**_Horvath-standard sufficiency of protection, but it will not be effective in every case. When considering_**
**_whether or not there is a sufficiency of protection for a victim of trafficking her particular circumstances_**
**_must be considered._**

_e)_ **_There is now in place a reception and reintegration programme for victims of_**
**_trafficking. Returning victims of trafficking are able to stay in a shelter on arrival, and in 'heavy cases' may_**
**_be able to stay there for up to 2 years. During this initial period after return victims of trafficking are_**
**_supported and protected. Unless the individual has particular vulnerabilities such as physical or mental_**


-----

**_health issues, this option cannot generally be said to be unreasonable; whether it is must be determined on_**
**_a case by case basis._**

_f)_ **_Once asked to leave the shelter a victim of trafficking can live on her own. In_**
**_doing so she will face significant challenges including, but not limited to, stigma, isolation, financial_**
**_hardship and uncertainty, a sense of physical insecurity and the subjective fear of being found either by_**
**_their families or former traffickers. Some women will have the capacity to negotiate these challenges_**
**_without undue hardship. There will however be victims of trafficking with characteristics, such as mental_**
**_illness or psychological scarring, for whom living alone in these circumstances would not be reasonable._**
**_Whether a particular appellant falls into that category will call for a careful assessment of all the_**
**_circumstances._**

_g)_ **_Re-trafficking is a reality. Whether that risk exists for an individual claimant_**
**_will turn in part on the factors that led to the initial trafficking, and on her personal circumstances,_**
**_including her background, age, and her willingness and ability to seek help from the authorities. For a_**
**_proportion of victims of trafficking, their situations may mean that they are especially vulnerable to re-_**
**_trafficking, or being forced into other exploitative situations._**

_h)        Trafficked women from Albania may well be members of a particular social group on that_
_account alone. Whether they are at risk of persecution on account of such membership and whether they will be_
_able to access sufficiency of protection from the authorities will depend upon their individual circumstances_
_including but not limited to the following:_

_1)        The social status and economic standing of her family_

_2)        The level of education of the victim of trafficking or her family_

_3)        The victim of trafficking's state of health, particularly her mental health_

_4)        The presence of an illegitimate child_

_5)        The area of origin_

_6)        Age_

**_7)_** **_What support network will be available._**

**DECISION AND REASONS**

**INDEX**

_Section        Paragraph numbers_

Introduction     1-6

Evidence      7-75

Our Conclusions on the Evidence 76-112

Legal Framework    113-118

Country Guidance    119

The Individual Appellants   120-176

**ABBREVIATIONS**

The following abbreviations are used in this determination:


-----

ARA  Albanian Responsible Authority for Anti-Trafficking

CA  Competent Authority

CARE Coordinated Approach for the Reintegration of Victims of Trafficking

CIG  Country Information and Guidance

COIR Country of Origin Information Report

EEA  European Economic Area

FCO  Foreign and Commonwealth Office

IOM  International Organisation for Migration

NCATS National Coalition of Anti-Trafficking Shelters

NGO Non-governmental organisation

NCRVT National Reception Centre for Victims of Trafficking (“the Linza centre”)

NRM National Referral Mechanism

OGN Operational Guidance Note

OSCE Organisation for Security and Cooperation in Europe

PVOT Potential Victim of Trafficking

RAVT IOM project 'Reintegrating Victims of Trafficking'

SOP  Standard Operating Procedures for the Identification and referral of

victims of trafficking and potential victims of trafficking, applied by the Office of the National Co-ordinator on
Combating Trafficking in Persons in Albania

TIP Trafficking in Persons Report published annually by the United States' State Department

UKHTC United Kingdom Human Trafficking Centre (part of the National Crime Agency)

UN  United Nations

VOT  Victim of trafficking

WAVE Women Against Violence in Europe

**INTRODUCTION**

1. This decision to which we have both contributed is in two parts. The first considers the availability or otherwise
of a safe internal flight for women who have been trafficked for the purpose of sexual exploitation. This involves an
assessment of the re-integration services offered by the Albanian State, NGO and civil society organisations to
such an individual.

2. The second part is specific to the appellants who are two women from Albania who have been trafficked for
sexual exploitation. They have both been found to be at risk of persecution in their home areas. It is accepted by
the Secretary of State that they are unable to re-join their families or look to them for support if returned. The
dispute for them that arises is whether it would be unduly harsh for them to relocate in Albania and whether they


-----

would be vulnerable to re-exploitation taking account of our general conclusions and matters specific to the
appellants.

3. The Upper Tribunal last considered the issues relating to the return of trafficked women in AM & BM (Trafficked
_women) Albania CG_ _[2010] UKUT 00080 (IAC) following hearings in February and May 2009. Its findings were_
summarised in the following headnote:

_“a)        It is not possible to set out a typical profile of trafficked women from Albania: trafficked_
_women come from all areas of the country and from varied social backgrounds._

_b)        At its worst the psychological damage inflicted on a victim of trafficking can lead to difficulties_
_in reintegrating into Albanian society and has implications on whether or not it is possible for the victim of trafficking,_
_should she fear persecution in her own area, to relocate._

_c)        Much of Albanian society is governed by a strict code of honour which not only means that_
_trafficked women would have very considerable difficulty in reintegrating into their home areas on return but also will_
_affect their ability to relocate internally. Those who have children outside marriage are particularly vulnerable. In_
_extreme cases the close relatives of the trafficked woman may refuse to have the trafficked woman's child return_
_with her and could force her to abandon the child._

_d)        Those that see themselves outside society, for example, divorced or abandoned women, or_
_others who wish to live abroad, may seek out traffickers in order to facilitate their departure from Albania and their_
_establishment in prostitution abroad. Although such women are not “trafficked women” in the sense that they have_
_not been abducted against their will, there is likely to be considerable violence within the relationships and the_
_psychological affect of that violence may lead to a situation where the pressures which they are under and the lack_
_of freedom they are under means that such women should be treated as trafficked women._

_e)   The Albanian Government and authorities are taking steps to protect trafficked women who return_
_but such steps are not always effective. When considering whether or not there is a sufficiency of protection for a_
_trafficked woman who is to be returned her particular circumstances must be considered. Not all trafficked women_
_returning to Albania will be unable to access the arrangements and facilities available to enable successful re-_
_integration._

_f)   Trafficked women from Albania may well be members of a particular social group on that account_
_alone. Whether they are at risk of persecution on account of such membership and whether they will be able to_
_access sufficiency of protection from the authorities will depend upon their individual circumstances including but_
_not limited to the following:_

_1)        The social status and economic standing of the trafficked woman's family._

_2)        The level of education of the trafficked woman or her family._

_3)        The trafficked woman's state of health, particularly her mental health._

_4)        The presence of an illegitimate child._

_5)        The area of origin of the trafficked woman's family._

_6)        The trafficked woman's age.”_

4. The Secretary of State contends that since that case was heard there has been progress by the Albanian
government in the detection of trafficking and the support of its victims; it is further said that the support victims of
trafficking (“VOTs”) now receive from the IOM and NGOs provides safety and support to the extent that it would not
be unreasonable nor unduly harsh to expect the women to relocate away from their families. On this basis their
protection claims were refused. The First-tier Tribunal (First-tier Tribunal Judge Saffer) heard the appeals against
the Secretary of State's decisions on 8 August 2014. In separate decisions he dismissed the appeals on asylum


-----

grounds, grounds under Council Directive 2004/83/EC (the Qualification Directive) and human rights grounds.
Essentially he concluded that the appellants would be able to internally relocate within Albania. This would be
initially within the shelters available and the support framework provided by the IOM in their return and reintegration
package. They could thereafter seek protection if needed from the authorities in the light of the significant changes
the judge considered have recently occurred.

5. Error of law was found by the Upper Tribunal in these decisions. In summary this was on the basis that
inadequate reasons had been given for departure from country guidance. The 'error of law' decision of Upper
Tribunal Judges Dawson and Rintoul can be found at Appendix A. The matter was set down with directions with a
view to giving updated country guidance. A list of issues was formulated to provide a framework for our decision
making. In essence, the agreed issues included an evaluation of the effectiveness of the IOM return and
reintegration packages, and to what extent they might assist returning VOTs in the short and long term. Those
packages are time limited; we were not invited to consider how a VOT might fare on return absent such resources.
To that extent, the guidance we give is confined to those measures being in place on return.

6. During the course of the hearing the appellants were granted permission without objection to rely on additional
grounds under Article 4 of the Anti-Trafficking Convention. It had been initially conceded that neither appellant could
meet the requirements of the Immigration Rules, including paragraph 276ADE. Their altered position was that the
“very significant obstacles” test in paragraph 276ADE(v) would, in these cases, be founded on the same facts as
the “unduly harsh” test under the Refugee Convention: for that reason they could not logically eschew one and not
the other.

**THE EVIDENCE**

7. The appellants relied on the evidence of two country experts: Professor Edlira Haxhiymeri, Professor of Social
Work and Social Policy Department, Faculty of Social Sciences, University of Tirana, and Robert Chenciner, a
recognised expert on the former Soviet states and Eastern Europe. Their reports are based in part on questions
the parties had posed. Dr Haxhiymeri gave evidence by telephone from Albania, and due to time constraints, her
cross-examination was based partly on questions previously notified by Mr Whitwell. Robert Chenciner was not
called to give oral evidence.

8. In addition, we heard evidence from Miss Rachel Mullan-Feroze of Ashiana, a UK based NGO offering
assistance to VOTs and from Dr Roxane Agnew-Davies, a Consultant Clinical Psychologist, who gave evidence by
telephone from France. She too answered questions posed in advance by Mr Whitwell, as well as responding to
direct cross-examination. Dr Agnew-Davies offered her general observations about the psychological sequelae of
trafficking as well as providing her assessment of each individual appellant. The latter is considered in part two. In
respect of the former we note that the evidence is the same as that given by Dr Agnew-Davies to the Tribunal in AM
_& BM; we have not therefore reproduced it here._

9. We were also provided with extensive documentary material, a list of which is set out in the index at Appendix B.
Since much of this documentary evidence was not contested we have not summarised all that is before us. There
are however three documents that were particularly relied upon by the representatives – and the expert witnesses –
as providing up to date analysis and statistics on the position of VOT in Albania. The first is the January 2015
report published by IOM under the auspices of the United Nations Programme _Support to Social Inclusion in_
_Albania: Profile of the situation of trafficking victims and efforts for social inclusion (“the UNP report”). The second is_
the _Needs Assessment: Human Trafficking in the Western Balkans (“the Needs Assessment”) produced by the_
Research Communication Group on behalf of IOM. The third is the US State Department _Trafficking in Persons_
_Report for 2014 (“the TIP”), published by the Office to Monitor and Combat Trafficking in Persons._

10. Each report refers to procedures put in place by the Albanian government as set out in the Standard Operating
_Procedures for the Identification and Referral of Victims of Trafficking and Potential Victims of Trafficking ('the_
SOP') amended and approved in July 2011. We were also provided with some very recent information by IOM with
which we begin.

_IOM_


-----

11. The IOM is an inter-governmental organisation whose stated commitment is to the principal that humane and
orderly migration benefits both migrants and society. As the “leading global organisation for migration”, IOM works
with migrants, governments and its partners in the international community. Its work includes the facilitation of
reintegration and safe return for migrants, and supporting the efforts of the international community to combat
trafficking in persons. IOM offices include locations in Tirana and London, and we were provided with information
from both.

12. IOM has provided evidence about the nature of its resettlement package currently offered to Albanian VOTs.
Known as the _Reintegrating Albanian Victims of Trafficking programme (RAVT), its aims are set out in an IOM_
information leaflet thus:

“[to help VOTs]…resettle in a humane and sustainable way that mitigates the risk of re-trafficking. The programme
is stated to be entirely voluntary and is designed with the victim of trafficking at the centre of the process in order to
empower them through the decision-making procedure”.

13. VOTs who are interested in returning to Albania can be referred to RAVT by the Salvation Army and its subcontractors, UKHTC, Home Office or Poppy Project. The referred VOT is asked to complete a “Screening and
Assistance Interview Form”. We were provided with one of these forms. The interview process begins with detailed
assessment of the individual concerned, covering her level of education, work experience, family situation, health,
how she came to be trafficked and by whom, whether there are any risk factors in respect of re-trafficking and the
nature of the work she was forced to undertake. There is also an enquiry whether there are any special factors
relating to return, whether the applicant requires pre-departure assistance and the degree of transit and reception
assistance required. Finally the nature of the reintegration package is addressed.

14. Despite being time limited, the “tailored” package described in the IOM literature is at the heart of the appeals
before us, and we have been told that it has featured in a number of refusal letters served on Albanian VOTs. IOM
have sought to clarify the position in a Written Statement on: Reintegrating Albanian Victims of Human Trafficking
_Project issued on 26th March 2015 (“the Statement”) setting out the nature of the project in more detail. This_
document was sent to the First Appellant's solicitors under cover of an email from Jennifer Dew of the IOM in the
UK who wrote:

“IOM feels that this project should have no bearing on an asylum decision as it cannot address individual fears of
persecution, threats to life or freedom in Albania, and it cannot provide protection from potential danger.
Furthermore it is important to underline the fact that this is a voluntary return project which means that an individual
must be making an informed decision that return is right for them. If a victim of trafficking does not wish to sign the
voluntary declaration form they will not be eligible for the project and IOM would not be able to provide them with
any integration assistance”.

15. The Statement also gives the following additional details about RAVT. The programme is available to adult
Albanian VOTs who have been accepted into the UK NRM, having received either a 'Reasonable Grounds' or
'Conclusive Grounds' decision from the Competent Authority. If an individual does not wish to go through the NRM,
but there are still indicators of trafficking, she may be admitted; this would be decided on a case-by-case basis.
Again, the voluntary nature of the programme is underlined. The first step is that the VOT is asked to sign a
declaration of voluntary return: if she does not wish to sign this form she will not be eligible for the project and the
IOM are unable to provide her with any assistance.  The Statement notes:

“The decision to return home is very complex and usually involves a number of different factors, ranging from the
trafficking experience and associated psychological issues, to personal aspirations and family support networks. To
date, two Albanian victims of trafficking have received assistance through this project: the first had a positive
reasonable grounds decision and the second had a positive conclusive grounds decision. In both cases the victims
of trafficking had family support networks in Albania and felt that returning home was the right, and safe, choice for
them.”

16. Once the decision is made, and the form completed, the IOM's Standard Operating Procedures (SOPs)
stipulate that a risk assessment must be carried out This begins with a general risk assessment which will look at


-----

the current scale of trafficking in Albania and whether any attempt has made been made by traffickers to contact the
VOT or her family. If general risks are found, a specific risk assessment is conducted. If the level of risk is deemed
“unacceptable”, or if the individual herself considers that she is in danger, she will not be eligible for the project.

17. Once a VOT is accepted into the programme, arrangements are made for departure. The IOM UK co-ordinates
with Refugee Action who will make the travel arrangements. IOM Albania will inform the Albanian Responsible
Authority for Anti-trafficking (ARA) who will meet the VOT on arrival in Tirana. IOM Albania then work with the
returnee to develop and implement their reintegration plan, including accessing training, education, or developing a
business plan. They provide all assistance in kind; there is no cash provision. The maximum provided for is £2100
per case and it can be spent on:

- Temporary accommodation

- Education

- Vocational training

- Start-up business activity

- Employment subsidiary salary

- Medical support

- Childcare

18. Following the Statement there ensued correspondence between the IOM, the FCO and the Home Office. On
the 30th April 2015 Clarissa Azkoul, the IOM UK Chief of Mission wrote to Mr Glyn Williams, Director of Immigration
and Border Policy. Ms Azkoul cites paragraph 1.1.14 of the September 2014 CIG (which gives a summary of the
RAVT project) and states that it has come to her attention that this section of the CIG is still being relied upon in
refusal letters, and the project is being portrayed as a 'protection measure'. This is despite the IOM raising its
concerns about it during meetings on at least four occasions and in email correspondence dating back to
September 2014. The concerns expressed are that the project cannot, and was never intended to, offer any
protection. Second, RAVT assistance is only available to voluntary returnees: “the form is signed following an
information session with the individual victim of trafficking to ensure that the decision to receive assistance under
the project is indeed voluntary and made without undue coercion”. Third, IOM considers that paragraph 1.1.14 of
the CIG is inaccurate where it states that returnees are “normally transferred to the secure National Reception
Centre for Victims of Trafficking, guarded by special police 24/7”. Ms Azkoul points out that this is not what has
happened in any of the, now 3, individuals who have returned from the UK under the project.

19. Assistance is also offered by way of a £750 in-kind temporary accommodation grant. She asks that the Home
Office urgently review and amend the CIG paragraph in question and concludes by emphasising again, that there
must be a “clear desire” on the part of the VOT to receive reintegration support.

20. Mr Williams responded by email. He agreed that the package does not in itself provide protection, and clarifies
that the CIG was not intended to indicate otherwise.  The Home Office position is that the existence of the shelters,
and the IOM package, are amongst a number of factors relevant to the question of protection. The Home Office
recognise that the programme is voluntary, and that VOT cannot be compelled to use it: the CIG has been
amended to reflect this. That said, Mr Williams continued:

“However, as I am sure you can appreciate, the Home Office has a clear responsibility to ensure effective
immigration control. Making sure that the asylum route is reserved for people who have a “well-founded fear of
being persecuted” under the UN Refugee Convention is an important part of that responsibility. As part of that, we
must consider whether the individual will be at risk on return; that includes the availability of a supported return and
reintegration package in considering whether effective protection can be sought on return and so whether, if the
applicant is fearful, that fear is well-founded. This does not compel victims to use this or any other voluntary returns
package but the availability of support and protection whether assisted by the IOM or not is a factor that may be


-----

taken into account when considering an asylum application. It is also worth noting that the CIG makes clear that
asylum decision-makers must take account of the individual circumstances of each case, and so cannot justify a
blanket approach to refusals; the paragraph which refers to the IOM package is directly followed by one
emphasising this point and listing the various individual factors decision-makers must consider”

21. As to Ms Azkoul's concerns about the inaccuracy of the CIG, Mr Williams agrees that the term “normally”
should be deleted and indicates that the CIG can be amended so as to make it explicit that the shelter is state-run.

22. The email exchange between Ms Azkoul and Mr Williams also addresses when the RAVT project is due to end.
It was initially funded until the 30 April 2015, and in her letter of the same date Ms Azkoul had referred to this as
adding urgency to the IOM's concerns. Mr Williams for his part appears to have considered it settled that the
funding was to extend to the 30 September 2015; in a further letter of 29 May 2015 Ms Azkoul agrees this to be the
case, with an end-date of 30 June 2015 for new entrants, in order that there is sufficient time remaining to deliver
the assistance before the funding runs out. A letter dated 23rd April 2015 from Nick Miller of the Foreign and
Commonwealth Office 'Returns and Reintegration Fund' states that the FCO have agreed funding for RAVT until
the 30 September 2015. On the question of funding Mr Williams makes the following observations:

“We remain very concerned about the lack of take-up of this project, given the public funds we have invested in it.
As we have discussed with you at previous meetings, we accept that demand may always be limited given that
many victims may not wish to return. However, we strongly believe that there is more to be done in how this
package is communicated to victims. To date, the literature provided to victims and opportunities for discussion or
seeking further information appear to have been minimal. Information on the project has been provided to victims at
one remove from IOM, by support providers who are not party to our contract with you and do not necessarily have
a stake in explaining or promoting the project”.

23. That was the extent of the evidence we were given in respect of RAVT. During the first day of hearing Mr
Whitworth alerted us to the Respondent's proposal to make submissions about another IOM promoted package,
known as CARE: 'Coordinated Approach for the Reintegration of Victims of Trafficking'. This is a project similar to
RAVT, jointly funded by the IOM, the FCO, the French Ministry of Foreign Affairs and other partners. It was due to
run for 24 months from the 2nd September 2013.  Its aim is to provide a sustainable reintegration package for
returned VOTs from Austria, France, the UK, Cyprus, Portugal and Spain. This was the extent of the information
we were given about CARE, which appears to operate along the same lines as RAVT.

_Standard Operating Procedures [SOP] for the Identification and Referral of Victims of Trafficking_

24. The SOP is described by the Albanian Office of the National Coordinator on Combating Trafficking in Persons,
under the auspices of the Ministry of Interior, as having been 'updated and improved' in 2011, when the document
was published. The SOP comprises a detailed checklist for stakeholders dealing with VOTs identified in-country as
well as arriving at Albania's borders: it gives step-by-step guidance on what to do, whom to contact and inform, and
what steps to take next. It is advanced as a comprehensive document that forms an important part of the Albanian
government's efforts to improve its response to trafficking and expand the scope of the National Referral
Mechanism (NRM). It claims to set a gold standard for the treatment of potential VOTs (PVOTs).

25. The SOP states that on arrival the returnee is interviewed and advised about her rights and the assistance
available. Even if the returnee declines assistance the Responsible Authority is informed about her arrival. The
initial interview is conducted by a Border and Migration Police Officer and it takes about 30 minutes. Food and
drink should be provided, and if the returnee needs medical assistance, she should be taken to the nearest health
centre. If in that initial interview it appears to the officer that trafficking indicators are present the PVOT is to be
taken to “appropriate premises” for the interview to continue. This further interview takes no more than an hour. If
the conclusion is that the interviewee is a PVOT the Border and Migration police must immediately inform their
counterparts from the 'Sector of the Fight Against Illegal Trafficking' (SFAIF). An in-depth assessment is then made,
with the PVOT being informed of the assistance that might be available to her. This would include information being
gathered with a view to prosecuting her traffickers. The assessment of needs is conducted by the police officer and
a social worker, and a copy of their conclusions is passed to the shelter where the PVOT is placed. The shelter will


-----

then stay in touch with the social worker and advise them about any developments. If there is perceived to be any
risk to the PVOT in getting to the shelter she is to be accompanied by a police officer. If the PVOT refuses to go to
a shelter she must be given information about available services in the area that she is returning to; the social
services department in that area will be informed about her arrival.

26. In respect of Albanians voluntarily returning to the country having been identified abroad as PVOT, the SOP
states that efforts should be made to identify any health needs prior to arrival. The socio-economic assessment is
made in accordance with the on-arrival procedures set out above. If the PVOT wishes to return to her own
community/family a local social worker will co-ordinate this. The PVOT will be provided with an up to date list of
assistance available to her there, and her social worker will contact any relevant organisations to introduce the
PVOT. There will be an assessment of the family before the assisted return is facilitated. This will be conducted by
a social worker who will contact and interview the PVOT's family. If it appears that the PVOT or her family are at
risk from traffickers the police will be immediately notified and intervention requested.  After the PVOT returns
home the social worker continues to monitor her situation and will immediately notify the Responsible Authority if
there is any change in circumstance or risk assessment. There is no time limit on the support offered by the social
worker. If it is found that the well-being of the PVOT is being compromised in her home situation, immediate action
must be taken to find an appropriate solution.

_The UNP Report and the Needs Assessment_

27. The January 2015 report produced under the auspices of the UNP contains actual case-studies, produced very
recently, of VOTs attempting to reintegrate in Albania. It also contains direct quotes from other actors 'on the
ground' such as representatives of NGOs. Unfortunately the document suffers from poor translation into English;
nevertheless it is comprehensible.  The Needs Assessment was published in 2014. It is based on research
conducted between September 2013 and March 2014 into human trafficking in Albania, Bosnia and Herzegovina,
Kosovo, Macedonia, Montenegro and Serbia. As such its conclusions are more generic, although we note that
many more stakeholders were consulted in respect of Albania than any other country in the study, and that much of
the text does specifically refer to Albania. It reveals that the authors spoke directly to stakeholders including VOTs
themselves and those working to find reintegration solutions for them.

28. Both reports were produced in conjunction with the IOM. We deal with them together simply because
thematically they address many of the same issues. They cover a wide range of issues but for the purpose of this
determination, there are four areas of interest: how VOTs gain access to assistance through the NRM, what is
offered in the shelters, whether VOTs remain at risk of trafficking once they have entered the NRM, and how VOTs
manage once they have left the shelters.

29. The Albanian NRM is identified in the Needs Assessment as the only “highly operational” NRM in the Western
Balkans. Multiple informants to that research describe the NRM as “working well and a good example” with effective
communication between the social services, the authorities and the NGOs. The UNP report notes that VOT are
brought into the NRM through a variety of sources, including civil society organisations, social services, and
counselling services in Europe, but by far the largest source of referrals in Albania comes from the police.  Different
& Equal are cited as recording seven cases brought during 2013 in which it was the prosecutors who attached the
status “VOT” to the victims. Both reports do however note shortcomings in the identification and referral process.
Partly because there are key actors who are not yet involved, such as labour inspectors, and partly through the
reluctance of VOTs to be identified. The UNP cites a survey conducted by the IOM in 2013-2014 which found that
38% respondents reported that they would be deterred from coming forward because of the “type and quality” of
assistance on offer.

30. NCATS is the National Coalition of Anti-Trafficking Shelters, comprising the NCRVT government shelter in
Linza, Tirana, and the three NGO-funded shelters Tjeter Vizion ('Another Vision') in Elbasan, Different & Equal in
Tirana, and Vatra in Vlore. The UNP report states that the three NGO shelters apply a re-integration approach in
stages: first, crisis intervention and reception at a shelter; second, the reintegration stage supporting semiindependent living and third, reintegration and social inclusion. The range of services can include “safe
accommodation and good living conditions, safe transportation, individual assistance plans, food, clothes, medical


-----

examinations and treatments, as well as provision of care in case of hospitalisation, health information,
psychosocial counselling, employment counselling and facilitation, reintegration grants, support for the return to
school and studies, social and cultural activities, vocational training and care during pregnancy, as well as for the
child”. The Needs Assessment adds that VOTs are offered a choice of which shelter to enter, although those with
any safety concerns are encouraged to enter the NRCVT state-run facility. At the date of the UNP report there was
found to be sufficient capacity in the shelters to meet demand: NRCVT can accommodate up to 100 persons,
Different & Equal 15, Vatra 20, Tjeter Vision 34. The report goes on to note that “such capacity is not sustainable”
because of funding issues.

31. The UNP report examines the cases of ten VOT as they attempt to reintegrate into Albanian society. Eight are
women. Two had previously been trafficked, having already been in one of the “relevant shelters”. This accords
with the findings of the NCATS report which found “Previous trafficking remains a key vulnerability factor. Hence, 16
new cases of trafficking (18%) referred to NCATS during the reporting period have been identified previously and
accommodated in Coalition Shelters”. The National Anti-Trafficking Co-ordinator reports that in the year prior to the
UNP report being compiled there was an increased response to trafficking by law enforcement officials. In both
2012 and 2013 there were only 2 convictions but in 2014 there were 10; during the reporting period from September
2013 there were a further 60 referrals to the Serious Crimes Prosecutor, including 58 for the offence of “exploitation
for prostitution”. Both the UNP and the Needs Assessment indicate that service providers working in the field
express scepticism about official figures, suggesting that these do not accurately reflect the scale of the problem in
Albania. The Needs Assessment further notes that the majority of reports and key informants mention corruption –
in the form of complicity between local officials and police with traffickers – as a major barrier to combating
trafficking.

32. All eight of the female VOT featured in the UNP report had received some kind of education or training whilst in
a shelter. Three had trained as hairdressers, three had taken a culinary course and one had done tailoring. One, a
minor, had been supported to go back to school. This training had resulted in work for five of the women. Two had
been employed by an NGO, but their position was precarious due to funding issues; one was living with family
members and the other was living in shared accommodation, trying to pay the rent on an income of 10,000 Lek per
month1. One described herself as “highly skilful” in her work as a chef for a private organisation; she was able to
pay the rent on an apartment herself.  One was also living alone but expressed concern about how she would meet
the rent because she did not think her employment secure. The fifth was “very confident” and good at hairdressing;
she was living with her mother.

33. In respect of long-term support the gaps in provision “featured prominently” in the research conducted for the
Needs Assessment. Although one informant suggested that “protection and assistance services to people who have
experienced trafficking (foreign and domestic) upon exit from the shelters are zero”2 most people interviewed
highlighted the major problem as being the lack of employment support. This in turn leads to difficulties in living
independently. Of the eight women in the UNP case-studies four went to live with family members, three paid rent
independently and one wished to go back to the shelter. All reported that it is very difficult to pay rent alone. There
is no legal provision to give priority to VOT in the allocation of social housing. There is a social housing programme
which seeks, inter alia, to provide for single parent families, but at the time that the UNP research was undertaken
“no single person had benefitted” from such programmes. The experience of women who did find work after
leaving the shelters was varied: three were in unsecure, low paid employment (as a chef, a cleaner and a part-time
distributor) whilst two described themselves as “confident and skilful” in their respective employment as a chef and
in “aesthetics”. The report summarises the position in the following terms,

“The data received from the interviews are confirmed by the service providers. The high unemployment rate has
driven people to accept any kind of job, having no social insurance and very low wages. Some reports show that in
Elbasan, there have been tens of cases of women in need and victims of trafficking who have accepted all sorts of
jobs. Employment offices' offers are limited and are associated with problems relating to working hours, days off,
very low salaries which cannot substantiate a safe re-integration.

According to the interviews with the service providers, maximum efforts are made to create jobs within the
organisations, given that they are sensitive to the special needs of victims, but these possibilities are very limited


-----

and depend hugely on funds. What the service providers give as a recommendation based on their experience, is
establishment of social businesses”

34. The Needs Assessment conclusion is framed in similar terms, and highlights the risks carried with such low
levels of economic security:

“At the same time it was noted in Albania that even where cases were able to find employment, low income jobs
often meant that they could not afford to meet their basic living costs. This highlights a crucial point made in one
report (Balkan Act Now 2013) that most victims are returning to the same place facing the same problems that they
had before they were trafficked. In particular, lack of economic opportunities motivated many people who get caught
in trafficking networks to have migrated in the first place. Their situation has not generally altered upon their return,
and may even be exacerbated by costs incurred through their migration. Thus, long-term reintegration brings
challenges for which adequate solutions have generally not been identified and implemented”.

_The 2014 Trafficking in Persons (TIP) report_

35. The TIP report is a document produced annually by the United States State Department who describe it as “the
US Government's principal diplomatic tool to engage foreign governments on human trafficking. It is the world's
most comprehensive resource of governmental anti-human trafficking efforts and reflects the US Government's
commitment to global leadership on this key human rights and law enforcement issue”. The authors of the Albanian
chapter consulted with relevant ministries within the Albanian government and representatives of NGOs. They also
had regard to other human rights reports. The report contains statistics on matters such as prosecutions and
training.

36. Albania remains a source and destination country for trafficking in persons for the purpose of sexual
exploitation and forced labour. In each year since 2009 the United States government has classified it as a 'Tier 2'
country, placing it in a category with countries as diverse as Afghanistan and Portugal. 'Tier 2' status means that the
State Department has concluded that Albania is making significant efforts to comply with the minimum standards
set out in the relevant US legislation, the Trafficking Victims Protection Act. The exception was in 2013 when
Albania was placed on the 'Tier 2 Watch List' for the following reasons:

a) the absolute number of victims of severe forms of trafficking is very significant or is significantly increasing;

b) there is a failure to provide evidence of increasing efforts to combat severe forms of trafficking in persons from
the previous year, including increased investigations, prosecution, and convictions of trafficking crimes, increased
assistance to victims, and decreasing evidence of complicity in severe forms of trafficking by government officials;
or

c) the determination that a country is making significant efforts to bring itself into compliance with minimum
standards was based on commitments by the country to take additional steps over the next year.

37. In 2014 Albania returned to 'Tier 2':

The Government of Albania does not fully comply with the minimum standards for the elimination of trafficking;
however, it is making significant efforts to do so. In October 2013, the government appointed a new national antitrafficking coordinator, who in December initiated the development of a special taskforce to improve coordination
among police, prosecutors, and judges. Albanian law enforcement improved its understanding of a victim-centered
approach to human trafficking, though further training is still needed to improve their operating effectiveness in
identifying cases and leading them through prosecution. The government increased the number of victims
identified, but prosecuted and convicted a small number of trafficking offenders. The government did not fund the
NGO shelters that provided services to victims of trafficking. Victims received inadequate mental health services at
the state-run shelter, and medical care staff needed training.

38. The TIP states that in the reporting period 2013 to 2014 Albania increased its anti-trafficking law enforcement
efforts and improved its criminal law by increasing sentences and creating new offences. In 2013 there were 24


-----

cases investigated, compared to only 11 in 2012. One case was brought to trial, which had not concluded at the
date of the TIP report. In 2012 two defendants were successfully prosecuted and received sentences of 15 years'
imprisonment. During 2013, the government trained 57 judges, prosecutors, and police officers on investigation and
prosecution of traffickers, and on victim identification and protection. The government increased the number of
judicial police and special prosecutors assigned to trafficking cases from three to seven during the reporting period.
In December 2013, the national anti-trafficking coordinator initiated the development of a special taskforce to
improve coordination among police, prosecutors, and judges. NGOs reported that police, prosecutors, and judges
demonstrated improved understanding of a victim-centered approach to human trafficking, though further training is
still needed. Corruption and high rates of turnover continued to be an issue within the police force, which hampered
the efficacy of training. The government did not report any investigations or prosecutions of government officials
allegedly complicit in human trafficking offences during the year.

39. There was an increase in the identification of VOT and their referral to the appropriate services. In the reporting
period 95 VOT were identified, and 93 received assistance in either an NGO or government shelter. Although there
was some financial provision for VOTs (approximately $10,000), there was a failure to fund NGO shelters and
$50,000 that had been allocated to provide them with food failed to materialize. Bureaucratic hurdles prevented
victims from accessing free healthcare that had previously been approved by the government and VOTs had to pay
for their own medical expenses. During the reporting period the NGOs reported improved operation of the NRM
and there was a substantial increase in special mobile units formed to identify child VOTs. The problems in the
shelters is summarised as follows:

“Victim advocates and NGOs reported that the state-run shelter lacked human, physical, and financial resources for
longer-term care of victims of trafficking, including health, education, and employment services. Victim advocates
reported that psychological services offered at the state-run shelter were inadequate and medical staff required
further training. NGOs reported that victims were punished as a direct result of being in human trafficking situations.
In 2012, at least three victims of sex trafficking were convicted of prostitution. In one case, the court issued both a
conviction against the defendant for trafficking in persons, and simultaneously convicted the victim for prostitution.
Lack of training and the high rate of turnover among prosecutors was a challenge to progress on this problem”.

40. The TIP states that in October 2013, shortly after taking office, the new government appointed a National AntiTrafficking Coordinator with a budget of approximately $50,000. Further funds were made available to local
government and there is some evidence of regional committees being active in addressing trafficking. NGOs
assisted with capacity building and training, but more is needed.

_Professor Edlira Haxhiymeri_

41. Professor Edlira Haxhiymeri is a Professor of Social Work in the Social Policy Department, Faculty of Social
Sciences, in the University of Tirana. In addition she is the executive director of the “Shelter for Battered Women
and Girls” in that city, a post she has held since 1998. She has worked for almost 25 years in the field of gender
based abuse and is the author of numerous reports, papers, political documents and research on abuse against
women and children in Albania. She has contributed to training professionals including police officers, judges,
prosecutors, health workers, teachers, psychologists and social workers on dealing with all forms of gender based
abuse and has contributed to the drafting of national documents with regard to combating and minimising violence
against women and girls. She is the co-author of the National Standards for Social Services for Victims of Domestic
Violence.

42. Her report begins with an introduction followed by answers to 25 questions to which the Secretary of State
contributed and finishes with conclusions on the general situation as well as the specific circumstances of the
appellant. Professor Haxhiymeri gave her evidence by telephone amplified through a loudspeaker.

43. She was questioned in cross-examination on her past activities. Observing that she was, in parts of her report,
critical of the Albanian government's efforts to combat trafficking, Mr Whitwell drew the Tribunal's attention to the
fact that Professor Haxhiymeri had at one time been a member of the ruling Socialist Party and that during that


-----

period she had publicly called for the resignation of the current Prime Minister Edi Rama. Professor Haxhiymeri
accepted that she had called for Edi Rama to resign, but that was before he became Prime Minister, and the call
was in respect of his position as leader of the Party. She said that she is principally an academic with 33 years of
experience in teaching and research. She had only been involved in politics for two years; she withdrew after
finding it was “not for her”. She stated that she had been critical of all leaders in Albania because of their failure to
address social problems. She describes her stance towards Edi Rama as “critical but not hostile”.

44. The following key points emerge from Professor Haxhiymeri's evidence. Where appropriate we have quoted
her directly:

(a) When a woman returned by the UK authorities arrives in Albania the SOP indicates that she will be met at the
border point by a police officer (possibly female), a social worker and a representative from an NGO. The returnee
will be asked to fill in a questionnaire which could be followed by identification procedures and it remains to be
decided whether the returnee will be identified as a victim of trafficking or not.

(b) There is a distinction between the shelters run by the NGOs, and the NRCVT at Linza. The latter is on the
outskirts of Tirana and is protected by guards 24 hours a day. It has a capacity for 100 beds although she
understands the current occupation is 20. Many of these are women from other countries who have either been
trafficked to, or transited, Albania: there are for instance women from Ukraine and Moldova there. It is run by a staff
of a professional and “political” background.

(c) Being a public centre funded by public funds and under the Ministry of Welfare and Youth it is affected by any
political change. This was illustrated by events at the end of 2013 when following a new government coming into
office the staff were suspended. The director and other professionals were fired. It took some months for new staff
to be appointed. This means that the centre is not stable, since its staff are highly affected by political rotation. For
instance, today only two of the twenty or so staff there are the same as last year. Such changes do not happen in
the NGO shelters which have a professional profile.

(d) She has not recently visited Linza. There is concern over disturbing the residents. It is a long procedure to get
permission; she does however meet with the staff and director regularly. She accepted there was no real evidence
that any of the women there had fallen into the hands of traffickers but she knew VOT preferred not to go there as it
was far away on the outskirts. There was a need to walk for twenty minutes to get the bus in an isolated mountain
area and the bus journey to the centre of Tirana is another 20 to 30 minutes. The VOTs are always accompanied if
they make this journey, since walking alone in this undeveloped area is highly dangerous. There is a high risk of
being caught by traffickers.

(e) Through cooperation with her shelter and the Linza Centre she and her staff have come to know the staff there.
There are not enough social workers, psychologists or educators. Most of the current staff have an “economic
background”. The quality and professionalism of the staff remains a problem with all the public centres. With Linza
being located on the outskirts she observes it is impossible for any of the girls to continue their normal life from
there and have to be accompanied in order to reach the city and other services. Any girls with high risk will go there
and when they move out of the shelter they are still unprepared to face “the reality” The majority of victims who wish
to enter the NGO centres have a different profile. Despite the 24 hour guarding, it is hard to say that it was a safe
place as the building is very easily identified. It has for instance, appeared on Albanian television a number of
times.

(f) It is considered that a six month stay at Linza will normally be long enough for a VOT. It may be as short as
three months. The assessment is made case by case. Pregnant women, those with newly born babies, or those
who are at high risk of being hunted by traffickers would be permitted a longer stay but in no case would it be more
than two years. With reference to the second appellant, who has a 9 month-old baby, her case would be
considered a “heavy” case and the assessment would be ongoing.

(g) As to other shelters she refers to three NGO shelters which cooperate with the government's Linza Shelter
being “Another Vision in Elbasan with a capacity of eight to ten persons at a time, Different and Equal in Tirana with
a capacity of 20 to 25 persons and Vatra in Vlora Southern Albania with nearly the same capacity In addition


-----

ARSIS is a new centre for children that have experienced trafficking and it is in Tirana”. She has visited the centre
in Vlore once and Different & Equal several times, the last being in October 2014. She has not been to ARSIS but
members of her staff have.

45. In Professor Haxhiymeri's opinion the shelters have, during the past few years, tried to enrich the scope of
services but the effect of their intervention “does not seem to last long”. At the beginning of their activity they were
offering mainly psycho-social support, shelter, nutrition and medical treatment. Nowadays programmes for
vocational training, employment and housing are established. As to the training of staff, some are social workers but
are not specialised in dealing with mental health. There is one psychologist but he or she is not trained in dealing
with mental health problems. They are trained in counselling but not in therapy. Most mental health patients are
treated by doctors with “medical treatments”, that is to say, they prescribe medication. When asked about this, she
explained that there are no staff equipped to deliver “deep” psychological treatment. Some will provide basic
counselling but this is not always available. Generally speaking where reports refer to “mental health provision” in
the shelters they are talking about medication, in the form of anti-depressants.

46. In respect of women with children, children are permitted to enter the shelters and they will usually share a
room with their mothers. VOTs with babies find it “impossible” to attend courses. Thus she concludes that “the
facilities in all centres for treating victims of trafficking remain poor”. The women there are isolated and the
buildings are poorly furnished. There is no space for privacy. She illustrates her point by quoting from some of the
beneficiary interviews in the Needs Assessment. When questioned Professor Haxhiymeri acknowledged that in the
NGO shelters women can receive free childcare for 3-4 months.

47. Professor Haxhiymeri could find no official data regarding the number of VOT using shelters between 2010 and
to date. She reiterates that the situation of victims who cannot be reunited with their families is more difficult than
the other cases and states that “the process of integration becomes almost impossible” as family support is a key
factor. According to the regulations at the centres victims can stay six to twelve months. Exceptions are made for
more demanding cases, described as “heavy” but the time limit is no more than two years. The government has not
funded NGO shelters that provide services to victims to trafficking. These are wholly reliant on support by foreign
donors. No public funds have gone to the NGO sector offering services for victims so far.

48. The real problem with the shelters, as far as Professor Haxhiymeri is concerned, is that none have a
programme for long-term intervention. Housing is only supported for three to six months. After this, victims do not
have enough means to pay the rent themselves. The employment offered there is in her view, a short-term
intervention.

49. Turning to the prospects for the VOT once she leaves the shelter, Professor Haxhiymeri's evidence was as
follows:

(a) She considers that the six characteristics identified as significant by the Tribunal in AM & BM are still important.
Of great relevance is the degree of education of the VOT: most VOTs had an elementary level education or less
and as such they could hardly find decent paid jobs. Mothers of illegitimate children are not well received in social
groups and find it difficult to work long hours to make the money needed to cover living expenses. It is difficult for
them to leave children in institutions because they know they will not be well treated and supported. Professor
Haxhiymeri accepts that VOT can receive some support from authorities in the country but this in no way helps
them to start “a new and honest life”.

(b) The majority of uneducated people can expect to receive a wage of up to €150 per month whereas rents are on
average €200. Although there were no official statistics to support these estimates Professor Haxhiymeri bases
them on her own experience of trying to resettle victims of domestic violence. Workers at her shelter have found it
very difficult to find suitable housing in Tirana for less than €200 and she is aware from the feedback of those who
have been housed that they find it very difficult to pay the rent because their wages do not cover it. They also have
to pay for all their other expenses on top. Because of the lack of employment in Albania, many people try to get any
kind of work without asking about conditions and this raises the risk of abuse and exploitation. VOTs face a higher
risk as they have to deal with the situation by themselves. These references to rental costs relate to the private


-----

sector. There are no public housing services. When she was asked about the social housing referred to in the UNP
report she was incredulous: it has never functioned. There were two to three blocks built in 2007/08 and nobody
had entered them to this day. There is no financial support to pay for childcare. The support provided, is then,
superficial: it does not allow the VOT to make enough money to cover her needs.

(c) Upon exit from the shelters VOTs received “zero support” for their employment and housing problems. When
asked about this she referred to the statement to the same effect in the Needs Assessment. Although she agreed
with Mr Whitwell that that report did not specifically relate that assessment to Albania (the Needs Assessment
pertaining to a number of countries in the Western Balkans), she said that in her experience it was an accurate
assessment.

(d) VOTs from the North of Albania, the fact that they have no family to support or protect them in the city, and that
they are so easily identifiable by their accent, makes them especially vulnerable to criminal groups.

50. As to mental health care and treatment in Albania, Professor Haxhiymeri refers to the section of the UNP report
dealing with social inclusion which includes reference to the Health Insurance Fund. In an interview given for a
newspaper in June 2014 the Health Insurance Fund director said that there were about 200 women and girls who
would receive free medical service and get a health card without paying a penny. She believes this to cover health
treatment in general and that nothing is provided for mental health care and treatment. Whilst VOTs receive free
mental health treatment in the shelters the quality is very low; once the VOT leaves the shelter she will be given a
health care card but this does not cover all services. This creates a risk of suffering from mental health problems
without treatment.

51. A further problem lies in the isolation of the VOT once she leaves the shelter. The family remains of central
importance in Albanian society and women such as VOTs or victims of domestic violence who live alone stand out.
Being a single woman is always a factor that attracts unwanted attention. For instance harassment in the
workplace is something which occurs, but is less likely to happen to women who have the protection of a family
around them. Although there is no data or recent research on the situation for single women who return to Albania
and live alone, in Professor Haxhiymeri's experience they are “in most cases considered as abandoned from their
families because they are 'kurva' (whores). This label carries a lot of hate, discrimination and risk of exclusion.
They are not welcomed in social groups. Even when employed, people try to stay away from them.  Employers try
to exploit them by making them work long hours, harder and pay them less.” Professor Haxhyimeri observes that
such individuals do not make a lot of money but sometimes “it is enough to survive”.

52. Whilst these problems are faced by all single women the position for women from Northern Albania is
exacerbated by the very traditional culture there. In her view young women in Northern Albania face a high risk of
being trafficked because of their lack of proper education, social isolation, arranged marriages and limited living
resources. Girls in Northern Albania experience higher levels of abuse within their family which sometimes
influences their decision to run away with the first man they meet. This does not mean that those from the southern
part of the country do not face a risk of trafficking; risks arise in isolated areas because of a lack of resources or the
vulnerability of the family, for example the presence of no men or an unmarried mother.

53. As to the application of the _Kanun, Professor Haxhiymeri acknowledges that she can “hardy find written_
evidence to justify it” but explains that it is a silent phenomenon. She accepts that old _Kanun is not mentioned_
frequently but those norms and rules are still alive: it might be taboo to discuss it but it is simply “part of our lives”.
For instance girls might be forced into marriage with someone in a remote rural area, or to a “handicapped
husband”, or with someone living in rural and remote areas. Women who have been exploited through trafficking
are treated in the same way as women who have committed adultery: it means that they will have violated the
honour of the family and every male in the family reserves the right to punish them with death. During the last
twenty years Albania has experienced a high level of internal migration. People from rural regions to urban and
suburban areas brought with them their culture and norms.  Because of this the majority of the population remain
under the influence of traditional culture and consequently women having experienced prostitution or being
trafficked are treated as kurva (“whores”). They are rejected and stigmatised. The possibility for integration remains
very low to “zero”. The situation of a mother with a child born out of wedlock is even more difficult. The child would


-----

be “pushed, ignored, despised, discriminated, insulted, offended and excluded from and in every social group”. As
to the fear of VOTs that they will be found by their families, Professor Haxhiymeri underlined that Albania is a small
country characterised by extended kinship networks.

54. In respect of the efforts made by the Albanian authorities, Professor Haxhiymeri recognises that progress has
been made. She adopts the formulation of the TIP to state that in her opinion the government of Albania does not
fully comply with the minimum standards for the elimination of trafficking, but it is making significant efforts to do so.
Some of the main laws have been improved and the SOP implemented. The national coordinator of the Unity
Against Human Trafficking is active. The NRM is enriched with new partners and she agrees with the contributors to
the Needs Assessment that is in a “good example” for other countries in the region. The National Committee
against Human Trafficking and its units in different regions are also operational. That said, Professor Haxhiymeri
expresses deep reservations about the depth and strength of the changes being made.

55. She does not, for instance, believe that the government has backed its public statements of intent with actual
money. She believes that many of the politicians making positive statements are doing so only because of the
“pressure of the international community”:

“In previous years I have witnessed as a result of my personal experience of working with victims of abuse that
those previously asking for shelter and protection in Albania were supported with a small amount of money and
cash. This is not the case anymore because the new government cancelled the amendment and excluded this
group from accessing the support. Also, the governmental support for non public agencies that offer services to
victims of abuse became non-existent. Whilst in reality interventions are not happening, the propaganda is
increased”.

56. Whilst she acknowledges that legislation has been expanded and improved she is critical of the measures
taken to actually enforce it. The legal procedures for compensation of the VOT do not seem to function or be
implemented fairly. Although the lawyers and judges are reported to take a more victim-centred approach during
trials they still need training and legal support to function professionally.  There have been attempts by NGOs to
engage in capacity building and training of officials but these are gains that are at risk of being lost due to the new
administrative reform which brings about a new division of Albanian territory.

57. In her view, the biggest problem remains police corruption. Professor Haxhiymeri believes collaboration
between traffickers and the police to be an ongoing risk factor. She refers to cases of police offices collaborating
with traffickers for financial profit and helping to identify repatriated VOTs. There is no official data to prove this but
whilst working with victims of domestic violence she has become aware of several cases of collaboration between
police officers and offenders. For instance during the first months of 2015 two police officers were arrested for
having collaborated with traffickers. As to societal attitude, Professor Haxhiymeri acknowledges that no data or
research exists to assess the attitudes of Albanian police to VOTs and she relies again on personal experience.
Despite what might be said and written about the situation improving, Albania “stands out world wide” because of
corruption, bribery and organised crime. There is no official evidence to prove that police are complicit in trafficking,
but again relying on her personal and professional experience in everyday life she would say this is a fact.

58. From her experience in working with victims of domestic violence and attempts to relocate them to other cities,
Professor Haxhiymeri considers without doubt that they can be re-trafficked either by their former traffickers or by
new ones. She concludes in her opinion that “relocation of the victims of trafficking in other areas is impossible”
and the findings of the Tribunal in AM & BM remain “current”.

59. Professor Haxhyimeri was unable to give us any information about CARE as it was not a programme that she
is familiar with.

_Mr Robert Chenciner_

60. Mr Chenciner is a Member of the Senior Common Room of St Antony's College, Oxford and has been an
Honorary Member of the Russian Academy of Science, Daghestan Filial, since 1991. His principal area of study is
the Eastern Caucasus. His first report in these appeals is dated 15th April 2015.  In response to some written


-----

questions from Mr Whitwell he provided an addendum dated 26th May 2015. We did not hear live evidence from Mr
Chenciner. In October 2014 he visited Albania for a week. He travelled across the country and met with various
agencies and individuals concerned with human rights. These included representatives of the OSCE, IOM and
USAid who were working with VOTs. In addition to VOTs returned to Albania from abroad these agencies are
concerned with the protection of women trafficked for sexual exploitation and children subject to forced labour within
Albania itself.

61. In October 2014 he met with Genci Pjetri of the IOM in Tirana. Mr Pjetri said that the IOM has been working
with VOTs in Albania for over 20 years, their current project being funded by the UK FCO. Their aim is to assist
voluntary returnees. They publicise the project through contact with organisations in the UK such as the Poppy
Project and the Salvation Army. They are neither able nor willing to put pressure on VOTs. If a VOT expresses an
interest in returning to Albania, the IOM facilitates various relevant ministries there are six ministries involved – to
make discreet enquiries with the woman's family or other concerned people to find out if they can safely take her
back and how to avoid the risk of her being re-trafficked.

62. Mr Pjetri said that there had been “many” enquiries about the return package but only one specific referral. The
case was dealt with within 24 hours. The woman was interviewed by trained female workers and was then reunited
with her family. She is living outside of Tirana. With regard to asylum seeking VOTs in the UK the project would not
apply: that is because at that stage the VOT would not wish to return home and so would not be a voluntary
returnee. Mr Pjetri told Mr Chenciner that the Home Office had misinterpreted the scope of the project in that they
have been relying on it in asylum refusal letters. Mr Chenciner concludes that the project should continue because
it can provide a satisfactory outcome for the few voluntary returnees who represent part of the group of VOTs.

63. In respect of the capacity of shelters for VOTs Mr Chenciner states:

“There are about 90 places for women and children, both children of the women who are VOTs and children who
are VOT themselves, in secretly located shelters in Albania. A few stay for years but most are short and medium
term, there were no available figures on any limits on the length of stay. It was not apparent that there were any
criteria for how long a VOT could stay in the shelters. Acute VOTs have been rescued from active attack; and about
half of the total are potential victims. One shelter in Elbasan has funding problems and has less than 10 VOTs;
Vatra NGO in Flora has about 30 plus children; in Tirana another is about the same size as Vatra; lastly the state
run emergency shelter has funding difficulties and is virtually running down. In general there has been a shift of
emphasis among foreign donor groups over the past 4-5 years to concentrate on helping children as a relatively
more vulnerable group than women VOTs.

Day centres are mainly for children and call centres such as the '129' police line does not usually elicit a response
unless violence is taking place.

With regard to the treatment of women VOTs by police, while there are likely to have been instances of stigma and
unpleasantness, by and large it appears that the years of training have in some measure started to change
attitudes. However another problem for the aid agencies is that Albania has a coalition government where as many
people as possible must be rewarded by ministerial and ministerial team appointments. The result is frequent
changes in personnel so that it is difficult for a team to take possession of a project or complete training and
consolidation”

Mr Chenciner adds that the “state-sponsored shelter is underfunded” and that there is only limited accommodation
available in the four shelters available, what provision there is usually being taken up by women fleeing domestic
violence.

64. Mr Chenciner also met with a representative of USAid. He was told that they are funding, along with other
partners, a project to improve the identification, referral and protection of VOTs. Concerns about how VOTs are
referred for care persist, notwithstanding the efforts of civil society and the Albanian government. The project is
being delivered by Vatra, Different & Equal and Tjeter Vizion, which will co-ordinate it. To the same end USAid are
also the co-funders of the new 'app' which allows members of the public to quickly report suspected cases of
trafficking


-----

65. Mr Chenciner was asked to comment on the issues that women VOTs might face trying to integrate into
Albanian society without the support of their families.  He references anthropological studies3 to offer the following
opinion:

“With regard to government support, it is virtually non-existent. The family is the main economic unit in Albania, from
subsistence farming in rural areas to bribing the authorities for required documentation, to obtaining rare jobs
usually from the main employer the state. The family income is also often supplemented by one or two members
who remit earnings as migrant workers both legal and illegal in Italy Greece and other parts of Europe…”

66. This is in the context of Albania being one of the poorest places Mr Chenciner has seen in his travels in the
Balkans and Eastern Europe. A woman away from the relative security of her family might be able to get casual
work as a seamstress, waitress or cleaner but the situation is still “extremely difficult', as acknowledged in _AM &_
_BM. She would be vulnerable to sexual harassment, and according to the US State Department report would not_
be able to register for social services support without risking her family finding out where she is: “corrupt police who
would pass on the information to vengeful male family members who perceive that the trafficked victim has stained
family honour”.  The difficulties of managing in low paid, informal sector employment means that women are
vulnerable to being forced into prostitution. Overall Mr Chenciner agrees with the findings of the Tribunal in AM &
_BM._

67. As evidence of police corruption Mr Chenciner refers to a report published in January 2015 by the Institute for
Democracy and Mediation (IDM) and funded by the Dutch Foreign Office4, which he summarises as finding that
citizens are viewed as an “opportunity to extort bribes”. There is impunity at all levels, and that 36% of public
respondents in that study reported bribing the police “very often”. The conclusions of the IDM are that there
continues to be high levels of corruption in Albanian society in general. Dr Chenciner reports the anecdotal
evidence of his respondents during his trip in October 2014: “I also asked everyone if the police were trusted –
emphatic no – and/or corrupt – emphatic yes”. Women face the additional hurdle of the police acting in conformity
with traditional patriarchal norms. For instance, a common narrative concerning domestic violence is that police are
called by neighbours to a noisy and severe beating, whereupon the man is arrested and placed in the cells
overnight. He is then released the next day. He is unlikely to be charged since there are no witnesses, and the
victim herself needs him to be at home earning money. The police view such matters as private, family affairs. For
the same reason they are very unlikely to become involved in an issue where a family's honour is deemed to have
been violated.  There were no direct reports of police collusion with traffickers but Mr Chenciner notes that
prosecutions are rare, and that the IDM do refer to instances of police involvement with organised crime, which he
infers must include trafficking. The IDM report contains “much evidence” of corrupt border guards. Mr Chenciner
relays an incident he himself witnessed during his trip which he believed was a man bribing a border guard.

68. In his first report Mr Chenciner notes that the 2014 TIP report “promotes” Albania from “Tier 2 watch list” to
“Tier 2”. He states that this was because they had appointed an anti-trafficking co-ordinator with a budget of
$50,000. In his additional questions Mr Whitwell sought to clarify if this was the sole reason for the promotion. In
response Mr Chenciner acknowledged that it is more complicated than that, but that the appointment, and the
budget allocation, were indeed the main improvements identified in the TIP report.

_Ms Rachel Mullen-Feroze_

69. Rachel Mullan-Feroze is the Service Manager at Ashiana, Sheffield5. She has worked with women who have
experienced abuse or trauma for over 23 years.  She currently manages Ashiana's trafficking project, which in the
past 12 months has received a large increase in the number of referrals for Albanian PVOT.  At the time of her
report on the 13th April 2015 Ashiana was supporting 32 Albanian women.  One of them is the First Appellant.

70. In her oral and written evidence Ms Mullan-Feroze states that Ashiana support and promote the _voluntary_
return of VOTs who are in a position to make an informed choice.  Ashiana are 'sub-contracted' by the Salvation
Army who hold the national trafficking contract with the Home Office and it is part of their contractual obligation to
explain all of the options to their clients. In that capacity, and through her own extensive contact with the IOM on
this matter, she has developed an understanding of the two alternative routes to resettlement facilitated by the IOM.


-----

71. The first is through the Albanian NRM. The VOT must consent to entering the NRM and once she does, it is up
to the Albanian authorities whether they recognise her as a PVOT/VOT: they do not automatically accept the
decisions of the UK NRM, the Home Office, or the Tribunal. A Conclusive Grounds decision does not hold any
weight, and although the Albanian NRM would not seek to “revoke” recognition by the UK authorities as such, they
make up their own minds. She was told this during telephone contact with IOM representatives including Jennifer
Dew, during February 2015. The VOT would be met at the airport by the Albanian police and a social worker. She
would usually be escorted to the National Reception Centre for Victims of Trafficking whilst her claim was
investigated. This centre has 24 hour police protection. IOM confirmed that the goal of the centre would ultimately
be the VOT reintegration with her family. To date, no VOT had returned to Albania from the UK to take up this route.
She expresses some concern about the danger of individual police officers contacting women's family members
without consent, and cites evidence to this effect found in the May 2013 OGN, itself a reference to the 2011 COIR.

72. The second option is the “socio-economic assessment route”. This in essence amounts to supporting VOTs to
reintegrate with their family upon return, without recourse to the shelters. The VOT must consent to the IOM and/or
Albanian police contacting her family or she will not be eligible for this assistance. She would go straight home, and
be offered some in-kind assistance by the IOM, such as meeting medical expenses. She might not meet a
representative face to face but would be expected to maintain telephone contact after her arrival in Albania. The two
women who have returned to Albania voluntarily since the start of the project have taken this route and Ms MullenFeroze has been told that they were both keen to go home and be with their families. She said that their
reintegration does appear to have been successful. The first woman returned in September 2014, the second in
November 2014.

73. In setting out that evidence Ms Mullan-Feroze makes two further points. First, it is Ashiana's position, based on
their contact with the IOM, that the RAVT project is entirely voluntary. Secondly it is her belief, based on her
personal contact with representatives of the Albanian embassy in the UK, that the Albanian government are not so
concerned with assisting VOTs as they might claim.

74. In respect of the first, Ms Mullan-Feroze explained that Ashiana has real concerns about the way that the Home
Office appears to have been relying on the RAVT package as a reason to refuse women asylum. She has seen for
herself women being told about it at the beginning of asylum interviews.  Ashiana has raised this with the IOM, and
directly with the Home Office who have indicated that they are reviewing procedures. The IOM have repeatedly told
Ashiana that this is not a package intended to offer protection, and that it is entirely voluntary. Their view is that it
cannot logically be relied upon during the asylum process. That said she acknowledged that it is part of Ashiana's
contractual obligation with the Salvation Army (who currently hold the national trafficking contract from the Home
Office) to inform women about their choices, and this would include the RAVT package. Ashiana has leaflets about
it in their offices and they do explain to their clients that it is an option, should they wish to avail themselves of it. So
far none of Ashiana's client group has taken it up.

75. As for the willingness of the Albanian government to work with VOTs Ms Mullan-Feroze expressed scepticism.
On the 11th February 2015 she was one of about 16 stakeholders who attended a meeting at the Albanian
Embassy organised by the Human Trafficking Foundation. Also present were representatives of the IOM, the police,
solicitors, Albanian and UK NGOs and consular staff. It was her observation that the embassy staff were “very
clear” in their assertions about trafficking in Albania. They did not accept that there was a significant problem, stated
that the majority of asylum claims in the UK - concerning trafficking and blood feuds - are probably false and that
the system here is open to abuse. The principle concern appeared to be that such claims “create a bad impression
of Albanians”.  The Consul also said that if individual details about claimants could be disclosed the Albanian
government would take steps to check the facts. Others present at the meeting were moved to point out that there
would be confidentiality issues with such an approach.  Ms Mullan-Feroze was left with the impression that the
efforts of the Albanian authorities to address trafficking is hampered by a “culture of disbelief” and that their main
focus is protecting the reputation of Albania. In response to cross-examination she confirmed that she could not
say with any certainty that such views were widely held across the Albanian government, but since the staff at the
embassy could be assumed to be speaking on behalf of the government that was what she had inferred.

**OUR CONCLUSIONS ON THE EVIDENCE**


-----

76. We have considered all of the evidence in the round; what follows is our evaluation of the core evidence relied
upon by the parties. As will become clear, three reports assumed particular significance: the UNP, the Needs
Assessment and the TIP. In varying respects the evidence of the expert witnesses was consonant with these
reports.

_Professor Haxhiymeri_

77. Professor Haxhiymeri does not work with VOTs herself, but rather formed her view on the issues in this appeal
through the lens of her own involvement in dealing with victims of domestic violence. It is of course open to her as
an expert to rely on that long experience, and we accept that there may be many parallels between the two groups:
where such similarities exist her evidence was helpful, for instance in respect of the difficulties single women face in
finding and paying for secure accommodation. In light of the fact that she has actually visited some of the NGO
shelters and has regular contact with their staff we have attached weight to her analysis of the services they are
able to offer, for instance in respect of mental health. However it was also apparent that in other respects her
knowledge directly relating to the current circumstances of VOTs was limited. For instance, she had not visited the
Linza shelter for some years and she was not aware of provision such as that provided by the CARE programme.
In the absence of direct knowledge Professor Haxhiymeri relied on generalisations: her evidence that women in the
Linza shelter face a real risk of being caught by traffickers if they ventured outside was not supported by a single
example of this ever happening. Similarly her concerns about political appointments at Linza was not supported by
any illustration as to why this might be to the resident's detriment. Whilst we were not persuaded by the
Respondent's suggestion that Professor Haxhiymeri had a political axe to grind,  we were left with the impression
that her perspective lacks detachment and underpinning by suitable material; rather it was one formed after many
years of campaigning for the rights of abused women, and women generally, in Albania. This is perhaps why her
analysis of the prospects for women trying to live on their own was considerably bleaker than the other evidence
might suggest.  For instance, notwithstanding her recognition of the varied services provided by the shelters, there
is no analysis of the potential gain which the time spent in the shelter may bring about; her apparently blanket
condemnation of police corruption did not appear to take account of her own evidence of police co-operation with
her organisation in cases involving domestic violence. She relies on the evidence of recent prosecutions of the
police as supporting her view on corruption, yet no consideration is given to the possibility that such prosecutions
might indicate a willingness to address the problem. Professor Haxhiymeri's view of how matters are evolving in
Albania is bound up with her long campaign as women's rights activist and does not, without more, persuade us
that her thinking is a complete and reliable assessment of the current situation for VOTs.

_Mr Chenciner_

78. Mr Chenciner spent one week in Albania for the purpose of his report. We appreciate that he was only
instructed late in the day, but this very short trip unfortunately left him with very little time to conduct research; he
was not, for instance, able to meet with a representative of one of the shelters as hoped. That the report lacks
clarity in a number of respects may be attributed to these time constraints. We found it difficult, for instance, to work
out what commentary was that of Mr Chenciner, and what was a direct quote from Mr Pjetri. The information that Mr
Chenciner supplied in respect of capacity in the shelters did not tally with the figures we were shown anywhere
else; it was not evident from the report whether these were obtained in his meeting with Mr Pjetri or from other
sources. Nor were we assisted by the great volume of background information drawn from Mr Chenciner's
experience of other countries. Whilst there may be similarities between Albania and other Eastern European
countries, in particular those formerly in the Soviet bloc, we were concerned in these appeals with specifics. Where
we did find his report to be useful was in his analysis of recent academic research that we may not otherwise have
been referred to, for instance in respect of anthropological studies on the family in Albania, and on the extent of
police corruption.

_Ms Mullan-Feroze_

79. Ms Mullen-Feroze was not tendered as an expert, but rather as a witness of fact as to her meeting at the
Albanian embassy, and in her dealings with the IOM. We have no doubt that she gave an honest account of her
meeting at the embassy, but we are unable to accept her analysis of it, namely that the Albanian authorities as a


-----

whole intend only to pay 'lip service' to tackling the problem of trafficking. That conclusion does not sit well with
other, well-researched and documented evidence before us. Albania is a country emerging from a difficult past, with
divergent strands of tradition, culture and politics. It is in those circumstances unlikely that every Albanian in a
position of authority, be it ambassador or border guard, will hold the same views. We were however grateful to Ms
Mullen-Feroze for her insights into how the RAVT package has operated thus far, and the extent to which it is
promoted to potential returnees. It is part of her job to be able to communicate what the package entails directly to
VOTs in the UK; as such she was able to explain the details to us with clarity.

80. Having made those general observations about those witnesses, we set out our findings. We begin with those
matters that are the least controversial, that is to say that the evidence about them is largely consistent.

_The NRM_

81. We can say with certainty that there is a framework for the identification, referral and assistance of VOTs
returning to Albania. It is clear that the Albanian government has in place a functioning NRM into which all returning
VOTs will be considered for referral. The returnee will be met on arrival, interviewed by police and social workers,
offered medical assistance if necessary, and safely transported to her chosen residence. Where that residence is
depends upon her circumstances; if she has opted to go back to her family the Albanian authorities will undertake
checks to ensure that this is the safe and right choice for her. If she is taken to a shelter, on-going assistance can
be delivered there. In recent years the mechanism has been enriched and expanded by the inclusion of no fewer
than six government Ministries in its operation. That the Albanian NRM functions well is acknowledged by Professor
Haxhiymeri, Mr Chenciner and the “multiple respondents” from civil society who contributed towards the Needs
Assessment research. The Albanian NRM is identified in that report as “working well and a good example” to other
countries in the Western Balkans, and the efforts to train relevant staff delivering services under the NRM are
singled out for praise in the 2014 TIP Report. The existence and relative success of the NRM is one of the factors
that has led the US State Department to reinstate Albania into their 'Tier 2' classification.

_The Shelters_

82. In addition to the state shelter at Linza, Tirana there are three shelters working with adult, female VOTs in
Albania. These are Tjeter Vizion in Elbasan (Central Albania), Different and Equal in Tirana, and Vatra in Vlore.
These three NGO shelters suffer from precarious funding. The NCRVT is reported to suffer from difficulties in the
training and retention of staff. The overall quality of the services on offer may vary; we are told however, that these
shelters do provide VOT and PVOT with assistance and basic amenities, which can, but will not always, include
safe accommodation and transportation, individual assistance plans, food, childcare, medical examinations and
treatments (as well as fees in the case of hospitalisation) employment counselling, further education, vocational
training, psycho-social counselling, reintegration grants and micro-finance loans.  The IOM programmes are based
on the availability of these various shelters to returning VOTs and it is on that basis that we have considered their
suitability for the purposes of internal relocation.

_RAVT and Strategies for Reintegration_

83. At the date we heard these appeals the UK government was funding a reintegration programme implemented
by the IOM in Tirana, referred to herein as RAVT. This is a voluntary programme, designed to “empower” the VOT
and place her at the centre of the decision-making process. A VOT will only be eligible if the IOM are satisfied that
she is making an informed and consensual decision to return to Albania. The IOM do not consider it appropriate, in
that context, that the Home Office rely upon the existence of the package in order to refuse VOTs asylum. In his
closing submissions Mr Whitwell adopted the comments made by Mr Williams, Director of Immigration and Border
Policy, in his email to the IOM. Noting the UK government's responsibility to preserve the integrity of the asylum
system he said:

“As part of that, we must consider whether the individual will be at risk on return; that includes the availability of a
supported return and reintegration package in considering whether effective protection can be sought on return and
so whether, if the applicant is fearful, that fear is well-founded. This does not compel victims to use this or any other


-----

voluntary returns package but the availability of support and protection, whether assisted by the IOM or not, is a
factor that may be taken into account when considering an asylum application….”

84. The Respondent is correct in her submission that as a matter of law a claimant is not in need of international
protection if there is a part of her country of origin where there is not a real risk of persecution, and where she can
[reasonably be expected to stay: see AN & SS (Tamils – Colombo – risk?) Sri Lanka CG [2008] UKAIT 00063. IOM](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:4THK-KD30-TWYV-R1DM-00000-00&context=1519360)
consistently and unambiguously state that VOTs will only be considered eligible for RAVT (and as we understood it
parallel programmes such as CARE) if return to Albania is voluntary. It follows that analysis of whether an individual
can reasonably refuse to avail herself of such intervention will depend upon the facts and must be decided on a
case by case basis.

85. The decision must be made “without undue coercion”. For women who do choose to enter this process, there
is a careful and detailed assessment of their individual needs, concerns and circumstances; all of this will be
considered when the return package is formulated. For those women who do wish to take this option, there are two
alternative pathways to reintegration back into Albanian society. The first, described by Ms Mullan-Feroze as the
“socio-economic” pathway, is in essence, return to the natal family with some in-kind assistance for things such as
medical bills. We are told that the two women who have availed themselves of the assistance of the IOM since the
programme began both took this option. Ms Mullan-Feroze was told that both were keen to go home and that for
them, this has been a success. It is likely that these women will continue to face, in the long-term, the same socioeconomic challenges as many other Albanian women living in impoverished families. They will do so with the
burden of their past experiences weighing upon them, and they may face stigma and discrimination from certain
individuals in society. However if they have the financial and emotional support of their families this can be the
“right, and safe, choice for them”. As Mr Chenciner puts it, for those who have this option available to them, it can
result in a “satisfactory outcome”.

86. The socio-economic pathway may not however be available to all VOTs. There will be some women for whom
it is not possible to return to their families.  For persons in such categories the 'return options' are limited to whether
they wish to return to Albania and fend for themselves, or whether to apply to enter the Albanian NRM and receive
the assistance of the IOM and/or the relevant shelter. It has not been suggested before us that the first option
would, for the vast majority of female VOTs, be reasonable. The focus of the evidence before us has been the
second pathway to reintegration.

87. Women taking that option are, in accordance with the SOP, met on arrival and transported directly to one of the
four shelters. If it is considered that there is any risk posed to either her or a family member, it is likely that she will
be placed at the government shelter in Linza, which has a guard. She will be allowed to stay in that shelter for
anything between 3 months and 2 years.

88. Because of a lack of evidence, we are unable to make a finding on the quality or quantity of assistance
provided to returning VOTs by the CARE package. It is surprising that neither party had much idea about this
aspect bearing in mind the scope of this appeal. From what we can tell, it appears to be a very similar programme
to, and running in tandem with, RAVT.

89. The evidence on the above matters is broadly consistent. The areas of dispute between the parties arising in
respect of this initial period of resettlement within the shelters concerned (i) safety, including the risk of retrafficking, (ii) the capacity of the shelters (iii) the quality of the care on offer in the shelters, and (iv) how well the
support provided equips the VOT for life on leaving the shelter.

_Risk whilst living in a shelter_

90. In respect of safety, three discrete risks were identified by the representatives for the appellants.

91. The first concerns the fear, expressed in trenchant terms by Mr Chenciner, that individual police officers or local
officials will betray the confidence of the VOT and tell “vengeful” male family members her whereabouts. The
motivation for doing so might be conformity with societal norms, the belief that a single young woman should not be


-----

living separately from her family; alternatively it might simply be corruption.  The former was a matter canvassed in
AM & BM in the accepted evidence of Dr Schwandner-Sievers:

79. She gave information relating to procedures on return stating that when a single woman was returned the
border police would interview her to check whether or not she was a victim of trafficking. The border police had
made it clear to her that it would not be possible for a woman to hide her identity. The border police would be likely
to contact the families of a victim of trafficking, because belief in the family was so strong the families would be
contacted in any event despite the case that trafficking often was from families where abuse had occurred. The
border police would contact the home police who would contact the family and the border police had stated the
families could be at the airport within three hours. It would depend on the police whether or not they would accept a
woman's plea that they should not contact her family. If a woman objected to the border police returning her to her
family they would suspect she was a victim of trafficking and she would be offered a place in the Linza shelter or
possibly at Different and Equal which was also in Tirana…”

92. We have heard uncontested evidence that the family unit remains of great socio-economic importance in
Albania. As such it is the norm for young women to remain part of their father's household until such time that they
are married. This is a pattern reinforced by culture and religious tradition; Mr Chenciner gives the example of the
man who has beaten his wife being released without charge after a 'cooling off'. In that context it is understandable
that the first port of call for individual police officers, social workers or NGO staff would be the returning VOT's
family: that is where she is presumed to belong. However we also bear in mind that the professionals involved in
applying the SOP have received specialist training and have been given very specific procedures to follow, none of
which include contacting a woman's family against her will. Dr Schwandner-Sievers conducted her research in
2008. Whilst we do not discount the possibility that the risk she identified may still be true of individual officers, and
that many professionals working within the context of the NRM would prefer ultimately, to see the VOT resettled
with her family, this must be balanced against the improvements there have been in the approach to VOTs in
general, and in returning entrants to the NRM in particular. For instance it was clear from the UNP report that the
vast majority of referrals into the NRM were from police stations in Albania; these women were being taken to
shelters not sent home to their fathers. We were shown no recent evidence of that practice. It did not, for instance,
feature in the detailed evidence given to Mr Chenciner by Genci Pjetri about on-arrival procedure. NGOs consulted
for the TIP research reported that “police, prosecutors and judges demonstrated improved understanding of a
victim-centred approach to human trafficking”.

93. There is however consistent evidence in respect of corruption. The Needs Assessment records that the
majority of reports and respondents to that research cited corruption – in the form of complicity between local
police/officials and traffickers – as a “major barrier” to combating trafficking. Mr Chenciner refers to the report by
the Institute for Democracy and Mediation concerning the pervasive and persistent problem of “a high level” of
corruption in Albanian society. That 2015 report found that 36% of public respondents admitted to bribing the police
“very often”. Professor Haxhiymeri offered her anecdotal evidence that in her experience over the years she has
come across several cases of police officers collaborating with perpetrators of domestic violence. The only
prosecutions she was aware of took place in the early part of 2015 when two police officers were arrested for
working with traffickers. This accords with the findings in the – earlier – TIP report that although corruption
continues to be highlighted as an issue, there were no investigations of government officials complicit in trafficking
offenses between 2013 and 2014. The TIP also acknowledges that in 2014 the continuing problem of corruption
has “hampered the efficacy of training”.

94. Corruption is, by its very nature, hidden and not susceptible to audit. The fact that two officers have been
recently prosecuted is a positive sign that whilst corruption is apparently widespread it is not so endemic that
prosecutions cannot be successfully brought. It does however remain a serious problem, not least in the minds of
the Albanian public who after many decades of living with bribery as a way of life may find it difficult to see any
change. In this regard we accept the evidence that for many VOTs there is a fear that they will have to pay the
police off –with either money or sexual favours. That subjective fear, whether it is well founded in respect of an
individual officer or not, can impact upon personal decisions about whether to enter the NRM. We accept that there
may be a number of officers who remain susceptible to bribery. We accept that there may be some individual


-----

officers who hold “traditional” and misogynistic views about how women should behave. In the absence of any hard
data we are however unable to find that this is a general, objective real risk to all women entering the NRM.

95. The second aspect of safety relates to the risk of re-trafficking by the same individual or gang who exploited the
VOT originally.  This is clearly not a fanciful notion, since it remains part of the risk assessment carried out by the
Albanian police and social work departments within the framework of the NRM, and in that conducted by the IOM.
The Linza shelter is, we are told, “guarded 24/7”. We accept that these actors on the ground must have had in the
past some objective experience of this danger, otherwise it would not feature as it does, for instance, in the SOP.
We note the evidence given in AM & BM to the effect that many VOTs remain under the control of their traffickers
and that if returned to Albania contact may be re-established. Women who are condemned by society as kurva may
see little alternative to returning to their former “work”6. There is however a complete lack of data on the
phenomenon of women being abducted from or nearby shelters by waiting traffickers. We have no doubt that had
there been instances of women disappearing from shelters over the past few years this would feature in the
evidence. What evidence we have about re-trafficking would appear to be confined to the risk once the VOT leaves
the shelter, and we return to this matter below.

96. The third area of concern was that the VOTs are “marked” as women without protection who have already been
forced into prostitution, and as such are vulnerable to the attentions of new traffickers, or simply predatory men
looking to exploit and abuse them. Professor Haxhiymeri described the Linza shelter as “isolated” and a long way
from the centre of town. In response to questions she clarified that it is about 40 minutes (half walking, half by bus)
to Tirana town centre. We accept her evidence that the centre has featured on Albanian television and that the
local population know what the centre is. We accept that there may be some hostility towards, or prurient interest in
the women living there from local people; it may be for this reason that VOTs are always accompanied if they leave
the Linza shelter. This is unpleasant, and could no doubt be frightening and threatening, especially for a woman
who has experienced sexual violence. We note the accepted evidence of Dr Schwandner-Sievers in AM & BM that
men “haunt” the shelters7; there is however no evidence before us of “new” traffickers having targeted women in
Linza. As implied in AM & BM, the modus operandi of traffickers has always been to target the naïve or desperate.
Professor Haxhiymeri told us that the disturbing pattern emerging in that context is towards younger women. It
seems unlikely that women under the active protection of the shelters and the police would be the ones most at risk.
Again, if there is a real risk of re-trafficking it may be once the VOT has left the shelter, and we consider this below.

_Services Available Within the Shelters_

97. Whilst we have been given a lot of information 'on paper' about the assistance offered by the IOM, CARE and
the shelters, there was a lack of precise evidence about how these services are actually delivered. For instance we
are told by the Needs Assessment, the UNP and IOM that 'childcare' is on offer. Professor Haxhiymeri agreed that
some support was provided. We were however told little about the extent and quality of that childcare. Does it
mean that a VOT can leave her baby with another VOT whilst she goes to the bathroom? Does it mean that there is
a crèche where she can leave her child for a substantial period of the day whilst she attends vocational training or
counselling? These are not trivial considerations. Without reliable information about the extent and quality of the
services on offer it is not easy to draw any detailed conclusions about what gain the VOT might derive from her time
in a shelter.

98. We can say with certainty that accommodation is provided. Professor Haxhiymeri describes the conditions in
the Linza shelter, when she visited it some years ago, as “poor” and makes the point that the women then had little
privacy. We do note that other victim advocates and respondents from NGOs expressed similar concerns to the
authors of the TIP report; although this is to be contrasted with the conclusions in the UNP report in which the
accommodation is described as “good”. We heard various figures about capacity, and the uptake of places. The
consistent theme of that evidence was that there is room in the shelters, none of which appear, at any stage, to
have been full. We are therefore satisfied that for as long as there is funding, there will be capacity, and that there
will be basic, safe accommodation offered to any returning VOT who wishes to avail herself of it.

99. We can say with certainty that other basic amenities such as food, drink and heating are provided. A number of
the sources refer to the government's failure to make good on a promise to give the three NGO shelters a reported


-----

$50,000 in order to feed VOTs but in the absence of any evidence to the contrary we are satisfied that the shelters
managed to provide food from other sources: if women were starving in the shelters we consider that this would
have been given prominence in the evidence before us.

100. As to healthcare the UNP report states that women receive “medical examinations and treatment” and that the
costs of hospital visits are covered. Women are also provided with “psycho-social counselling”. In contrast the TIP
report – covering the same period - records that the mental health services in the Linza shelter are “inadequate”,
that medical staff need training and that the funds allocated to pay for VOTs medical expenses were never in fact
released, resulting in VOTs having to pay their own bills. It is not explained in what way the provision that does exist
is “inadequate”. When we asked Professor Haxhiymeri about this she drew a distinction between “psycho-social
counselling” and actual mental health therapy. She explained that the workers in the shelters are not medically
qualified and are only trained to deliver basic counselling. The treatment referred to in, for instance the UNP report,
is confined to the dispensing of medication. Her conclusion is that whilst free mental health care is available in the
shelters, the quality is very low. In giving this evidence Professor Haxhiymeri again drew on her own experience but
we note that she has actually visited at least two of these shelters herself and that her evidence accords with the
information provided in the TIP report.

101. Taking all of the evidence in the round we are satisfied that there is a basic level of healthcare provided in the
shelters, but that there must remain concerns about the quality and extent of it, particularly in relation to mental
health treatment.  On the evidence before us, such care is limited to the prescription of anti-depressants and where
available, counselling by shelter staff who have no formal training in psychiatry or psychology.

102. The shelters also aim to provide the VOTs with some foundation upon which to start their new life. Variously
referred to in the sources as “vocational training”, “education”, “individual assistance” and “employment counselling”
we consider this under the general umbrella of 'help'. Concerns about the quality of such help are expressed by
contributors – NGO staff, victim advocates and VOTs themselves - to the UNP report, the Needs Assessment and
the TIP. Professor Haxhiymeri acknowledges that VOTs do receive support in the shelters, and that over the past
few years the NGOs in particular have sought to “enrich” their services; she however expresses concern that the
measures taken are “superficial” and that the effects “do not seem to last long”.

103. The most detailed evidence about these services is to be found in the UNP report, which provides casestudies of ten VOTs, eight of whom are female. That reveals that all of these women (and girls) received some kind
of vocational training (cookery, tailoring, hairdressing) or further education in a shelter. Although there is little by
way of detail about the quality or duration of the courses offered we are satisfied that such courses are generally
available. It is unclear whether VOTs are given a choice about whether they take a course, or about its content, nor
to what extent that those with childcare responsibilities are able to benefit from these provisions.

104. In summary we are satisfied that the shelters aim to offer more than security, board and lodging. They attempt
to enable VOTs to deal with the effects of their trafficking and to help them face a future in society. As to the
efficacy of these efforts, there is limited direct evidence, but what we were shown, we consider below.

_Life Outside the Shelters_

105. It was the consistent evidence of the IOM, the UNP, the Needs Assessment, Mr Chenciner, Professor
Haxhiymeri and Ms Mullan-Feroze that once admitted to a shelter, a VOT will be aware that it is time limited. No
VOT entering a shelter is given an exit date, but her departure date is determined following an assessment. We are
not told to what the degree it will be influenced by her own wishes. There is a 'maximum spend' in each case of
£2100, which is to cover the stay in the shelter as well as reintegration 'on the outside': all VOTs are aware that they
cannot be accommodated and supported indefinitely.  At some point, the VOT must either return to her family, or
set out on her own if that option is not available, and it is in this latter endeavour, the parties agree, that she would
face her greatest challenge.

106. All of the evidence before us indicates that in this period women face numerous obstacles, that include, but
are not limited to: financial hardship, difficulty in finding secure employment and housing, poverty, discrimination
and stigma (pertaining to the VOT as well as any children she might have) isolation and no or severely restricted


-----

access to mental health services. As will be seen below it is argued on behalf of the appellants that the cumulative
effect of such factors renders internal flight as unreasonable for many VOTs; it is further argued that the
vulnerability of a VOT at this point places her at an unacceptably high risk of re-trafficking or other harm.

107. We do not accept that it is, in general, “impossible” for a woman to live on her own in Tirana, as asserted by
Professor Haxhiymeri. She refers in her evidence to her own organisation resettling survivors of domestic violence
in the city, living alone or with their children. The case studies in the UNP report reveal that five of the eight women
entered into employment after leaving the shelter, and of these three were living apart from family members, for
instance 'T' who is paying her own rent, working for a private employer as a chef and who describes herself as
“confident and highly skilful”.

108. Such women have been able to live alone in Tirana; women who have been able to put the skills they have
acquired in the shelters to good use, and even to flourish in their new vocations.  For these women, there will be a
meaningful net gain from packages such as that offered by the IOM: the skills they have developed, sometimes
with the support of a loan or grant, has given them economic security and the ability to survive away from their
families.

109. For less resilient or adaptable women however, the path to financial independence is not so straightforward.
Professor Haxhiymeri describes the assistance offered by the shelters, the Albanian government or the IOM as
“superficial” and stressed that such training packages rarely help women in the long run. The problem she identifies
is that women in Albania tend to find work in the low-skilled, informal sector where employment is not secure or
protected, and where wages rarely keep up with the costs of living: this is the “grey economy” discussed in AM &
_BM8. All of the evidence supports a finding that the financial constraints make survival in the cities difficult: we_
accept Professor Haxhiymeri's evidence of her personal experience of trying to find accommodation for survivors of
domestic violence. Workers at her NGO typically find that the cost of basic accommodation in Tirana, even in the
outskirts, is €200 per month whereas a woman working in those conditions will typically earn no more than €150.
The respondents to the research consistently reported that it is “very difficult” to live alone because of the financial
constraints women face, in particular in staying in employment and in paying rent. The UNP report confirms that
there is no provision for VOTs to have access to social housing, and that they are therefore forced to rent in the
private sector. The high unemployment rate means that people are forced to take “any kind of job”. The Needs
Assessment succinctly summarises this situation: “most victims are returning to the same place, facing the same
problems that they had before they were trafficked”. The difference now being that they must face such daily grind
whilst living with the physical, psychological and social consequences of that experience.

110. At paragraphs 147-151 of AM & BM, the Tribunal considered the evidence of Dr Agnew-Davies in respect of
the psychological effects of trafficking. We adopt and underline the view expressed in that case that in all claims it is
important to consider the circumstances of the individual, including her strength, age, and psychological make-up.
For VOTs who have been through extreme traumatic experiences it is not difficult to see how they are likely to
suffer psychological consequences such as complex PTSD.  The VOT may suffer lasting physical damage as a
result of her experiences. These are important factors which must be considered when assessing whether internal
flight is reasonable for any individual VOT. Whilst the evidence relating to psychological support services for VOTs
once they have left the shelters suggests some availability, that it is undoubtedly patchy and in many cases wholly
inadequate as we have observed above. An individual, because of her condition, may have difficulty in accessing or
engaging with such services that do exist. She may be required to pay for mental health care, increasing her
financial burden. These are all matters relevant to the consideration of whether internal flight is reasonably
available.

111. As to the social consequences of a past trafficking experience we note the findings in AM & BM about social
exclusion of women labelled as _kurva, in the context of the tenacity of Northern Albanian traditions.  It might be_
thought that the increased migration from the countryside to the cities might lead to a weakening in such belief
systems, as extended families leave the land and break down into smaller, more independent units. Surprisingly we
were shown no evidence to that effect, and in fact it was suggested by Professor Haxhiymeri that such migration –
primarily from North to South – has had the opposite effect, of transporting conservative Geg social mores into the
more liberal south. The importance of the family unit as a social and economic construct was emphasised in all the


-----

evidence before us. We accept her evidence that women living on their own are immediately identifiable as being
on the 'outside'; even if the details of their history are not known, work colleagues and neighbours may view them
with some suspicion. In some cases that suspicion will escalate to open prejudice and hostility. We therefore find
no reason to depart from the general conclusions on this matter drawn by the Tribunal in AM & BM. Women living
on their own are likely to be socially distinct. Whilst discrimination and stigma certainly exist they will not generally
constitute persecutory “serious harm” or breach Article 3, but this it nevertheless a factor to be considered
cumulatively when assessing whether internal flight is reasonable for any given appellant.

112. It is against this background that all of the witnesses, and the civil society respondents to the UNP Report and
the Needs Assessment, expressed concern about the risk of VOTs being re-trafficked during this critical phase of
their reintegration. We share this concern. Women who are socially isolated and suffering from the consequences
of their past experiences are already vulnerable; where they are placed under the additional strain of financial
hardship this can render them even more susceptible to the advances of those who would seek to exploit them.
The UNP report cites an NCATS audit in which it is acknowledged that 18% of the cases referred in the reporting
period – a total of 16 women – had previously been trafficked and had been through the shelters at least once
already. The same is said of two of the eight women who constituted the case-studies in the UNP report. It must
therefore be the case that for some women, the period after they leave the shelters can be risky. Whether an
individual appellant can demonstrate that she faces such a real risk must be determined on the facts, having regard
to her personal circumstances and her age.

**THE LEGAL FRAMEWORK**

_Sufficiency of Protection_

113. Article 7 of the Qualification Directive provides:

1. Protection can be provided by:

(a) the State; or

(b) parties or organisations, including international organisations, controlling the State or a substantial part of the
territory of the State.

2. Protection is generally provided when the actors mentioned in paragraph 1 take reasonable steps to prevent the
persecution or suffering of serious harm, _inter alia, by operating an effective legal system for the detection,_
prosecution and punishment of acts constituting persecution or serious harm, and the applicant has access to such
protection.

3. When assessing whether an international organisation controls a State or a substantial part of its territory and
provides protection as described in paragraph 2, Member States shall take into account any guidance which may
be provided in relevant Council acts.

_114. These minimum standards reflect the approach taken in our own domestic jurisprudence: see_
Horvath v Secretary of State for the Home Department [2000] UKHL 37, Noune v Secretary of State for the Home
[Department [2000] EWCA Civ 306 and Bagdanavicius v Secretary of State for the Home Department [2003] EWCA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JTX1-DYBP-N3FG-00000-00&context=1519360)
_[Civ 1605, Bagdanavicius v Secretary of State for the Home Department](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:55Y7-JTX1-DYBP-N3FG-00000-00&context=1519360)_ _[2005] UKHL 38, AW (sufficiency of_
protection) Pakistan [2011] UKUT 31(IAC). The principles set down in these cases are distilled by Auld LJ in the
Court of Appeal's decision in Bagdanavicius as follows. Sufficiency of state protection means a willingness and
ability on the part of the receiving state to provide through its legal system a reasonable level of protection from illtreatment. The effectiveness of the system provided is to be judged normally by its systemic ability to deter and/or
to prevent the form of persecution of which there is a risk, not just punishment of it after the event. Notwithstanding
systemic sufficiency of state protection in the receiving state, a claimant may still have a well-founded fear of
persecution if she can show that its authorities know or ought to know of circumstances particular to her case giving
rise to her fear, but are unlikely to provide the additional protection her particular circumstances reasonably require.


-----

_Internal Relocation_

115. Article 8 of the Qualification Directive reads:

1. As part of the assessment of the application for international protection, Member States may determine that an
applicant is not in need of international protection if in a part of the country of origin there is no well-founded fear of
being persecuted or no real risk of suffering serious harm and the applicant can reasonably be expected to stay in
that part of the country.

2. In examining whether a part of the country of origin is in accordance with paragraph 1, Member States shall at
the time of taking the decision on the application have regard to the general circumstances prevailing in that part of
the country and to the personal circumstances of the applicant.

3. Paragraph 1 may apply notwithstanding technical obstacles to return to the country of origin.

116. In Secretary of State for the Home Department v AH (Sudan) [2007] UKHL 49 the House of Lords make clear
that the question of whether internal flight is “reasonable” is not to be equated with the test under Article 3 ECHR.
Lord Bingham refers [at 5] to his own guidance in Januzi v Secretary of State for the Home Department _[2006]_
_UKHL 5:_

“In paragraph 21 of my opinion in Januzi I summarised the correct approach to the problem of internal relocation in
terms with which all my noble and learned friends agreed:

'The decision-maker, taking account of all relevant circumstances pertaining to the claimant and his country of
origin, must decide whether it is reasonable to expect the claimant to relocate or whether it would be unduly harsh
to expect him to do so….There is, as Simon Brown LJ aptly observed in Svazas v Secretary of State for the Home
Department, [2002] 1 WLR 1891, para 55, a spectrum of cases. The decision-maker must do his best to decide, on
such material as is available, where on the spectrum the particular case falls… All must depend on a fair
assessment of the relevant facts'.

Although specifically directed to a secondary issue in the case, these observations are plainly of general
application. It is not easy to see how the rule could be more simply or clearly expressed. It is, or should be,
evidence that the enquiry must be directed to the situation of the particular applicant, whose age, gender,
experience, health, skills and family ties may all be very relevant. There is no warrant for excluding, or giving
priority to, consideration of the applicant's way of life in the place of persecution. There is no warrant for excluding,
or giving priority to consideration of conditions generally prevailing in the home country. I do not underestimate the
difficulty of making decisions in some cases. But the difficulty lies in applying the test, not in expressing it. The
humanitarian object of the Refugee Convention is to secure a reasonable measure of protection for those with a
well-founded fear of persecution in their home country or some part of it; it is not to procure a general levelling-up of
living standards around the world, desirable though of course that is.”

117. At 20 Baroness Hale cites with approval the UNHCR view that the test is whether the individual will be able to
live a “relatively normal life without undue hardship”, itself a formulation approved by their Lordships in Januzi9:

“As the UNHCR put it in their very helpful intervention in this case:

'…the correct approach when considering the reasonableness of IRA [internal relocation alternative] is to assess all
the circumstances of the individual's case holistically and with specific reference to the individual's personal
circumstances (including past persecution or fear thereof, psychological and health condition, family and social
situation, and survival capacities). This assessment is to be made in the context of the conditions in the place of
relocation (including basic human rights, security conditions, socio-economic conditions, accommodation, access to
health care facilities), in order to determine the impact on that individual of settling in the proposed place of
relocation and whether the individual could live a relatively normal life without undue hardship'.


-----

I do not understand there to be any difference between this approach and that commended by Lord Bingham in
paragraph 5 of his opinion. Very little, apart from the conditions in the country to which the claimant has fled, is
ruled out.”

118. The assessment on the individual characteristics of the claimant must include her personal history, and its
relevance in the society in which she is relocating. See for instance VNM v Secretary of State for the Home
Department [2006] EWCA Civ 47 [per Wilson LJ at 25]:

“it is obvious that the reasonableness of her relocation in a different part of Kenya requires consideration of the
practicability of her settling elsewhere; consideration of her ability convincingly to present to those in her new milieu
a false history relating to herself and to her daughter, including the latter's paternity, and a false explanation for their
arrival there; and, in the light of her substantial psychological vulnerability, consideration of her ability to sustain
beyond the short term a reasonable life for them both on that false basis”.

**COUNTRY GUIDANCE**

119. The decision in AM & BM is now over six years old. The matter in issue in these appeals was to what extent
recent measures taken by the Albanian government and others might have improved the situation for female VOTs
seeking internal flight. Our remit was therefore narrower than that of the Tribunal in _AM & BM_ and we find that
much of the guidance in that decision should remain undisturbed. Where we have amended or supplemented that
guidance in respect of internal flight, our findings are highlighted in bold below. We add that the only other part of
the country guidance in _AM & BM_ which we have found necessary to amend was sub-paragraph (c) of the
headnote. The country guidance is as follows:

“a) It is not possible to set out a typical profile of trafficked women from Albania: trafficked women come from all
areas of the country and from varied social backgrounds.

b) Much of Albanian society is governed by a strict code of honour which not only means that trafficked women
would have very considerable difficulty in reintegrating into their home areas on return but also will affect their ability
to relocate internally. Those who have children outside marriage are particularly vulnerable. In extreme cases the
close relatives of the trafficked woman may refuse to have the trafficked woman's child return with her and could
force her to abandon the child.

c) Some women are lured to leave Albania with false promises of relationships or work. Others may seek
**out traffickers in order to facilitate their departure from Albania and their establishment in prostitution**
**abroad. Although such women cannot be said to have left Albania against their will, where they have fallen**
**under the control of traffickers for the purpose of exploitation there is likely to be considerable violence**
**within the relationships and a lack of freedom: such women are victims of trafficking.**

d) In the past few years the Albanian government has made significant efforts to improve its response to
**trafficking. This includes widening the scope of legislation, publishing the Standard Operating Procedures,**
**implementing an effective National Referral Mechanism, appointing a new Anti-trafficking Co-ordinator, and**
**providing training to law enforcement officials. There is in general a** **_Horvath-standard sufficiency of_**
**protection, but it will not be effective in every case. When considering whether or not there is a sufficiency**
**of protection for a victim of trafficking her particular circumstances must be considered.**

e) **There is now in place a reception and reintegration programme for victims of trafficking. Returning**
**victims of trafficking are able to stay in a shelter on arrival, and in 'heavy cases' may be able to stay there**
**for up to 2 years. During this initial period after return victims of trafficking are supported and protected.**
**Unless the individual has particular vulnerabilities such as physical or mental health issues, this option**
**cannot generally be said to be unreasonable; whether it is must be determined on a case by case basis.**

f) **Once asked to leave the shelter a victim of trafficking can live on her own. In doing so she will face**
**significant challenges including, but not limited to, stigma, isolation, financial hardship and uncertainty, a**
**sense of physical insecurity and the subjective fear of being found either by their families or former**


-----

**traffickers. Some women will have the capacity to negotiate these challenges without undue hardship.**
**There will however be victims of trafficking with characteristics, such as mental illness or psychological**
**scarring, for whom living alone in these circumstances would not be reasonable. Whether a particular**
**appellant falls into that category will call for a careful assessment of all the circumstances.**

g) **Re-trafficking is a reality. Whether that risk exists for an individual claimant will turn in part on the**
**factors that led to the initial trafficking, and on her personal circumstances, including her background, age,**
**and her willingness and ability to seek help from the authorities. For a proportion of victims of trafficking,**
**their situations may mean that they are especially vulnerable to re-trafficking, or being forced into other**
**exploitative situations.**

h) Trafficked women from Albania may well be members of a particular social group on that account alone.
Whether they are at risk of persecution on account of such membership and whether they will be able to access
sufficiency of protection from the authorities will depend upon their individual circumstances including but not limited
to the following:

1) The social status and economic standing of her family

2) The level of education of the victim of trafficking or her family

3) The victim of trafficking's state of health, particularly her mental health

4) The presence of an illegitimate child

5) The area of origin

6) Age

**7)        What support network will be available.**

**The Individual Appellants**

120. Both Appellants have been found to be VOTs. Each has disclosed a history of rape and exploitation,
compounded by rejection by their families. This evidence is accepted. It forms the basis of our decision in the
individual claims, set out below. We first address the issues that were common to both appeals.

_Dr Agnew-Davies_

121. Neither appellant presented the First-tier Tribunal with medical evidence. On the facts that he had found,
Judge Saffer nevertheless inferred that in each case it would be “inconceivable, given the appalling level and period
of ill treatment that she would not have suffered some form of psychological harm”.  That this is so has now been
evidenced in two detailed reports by Dr Roxane Agnew-Davies.

122. Dr Agnew-Davies is a Clinical Psychologist who specialises in the impact of violence on women's mental
health. She has been working with victims of physical and sexual abuse for over 25 years. She is presently the
Director of Domestic Violence Training Limited, her own limited company. She provides training to other health
professionals on how to work with victims of abuse. She is an honorary research fellow at the University of Bristol.
Recent research projects she has run have been funded by the university and the Department of Health. She has
in the past had NHS contracts; the last one was with St George's Hospital in London. She was formerly the Head
of Psychological Services for Women at Refuge, the national charity for women escaping domestic violence. She
has provided evidence to the Tribunal in numerous appeals including AM & BM, and she has been accepted as an
expert witness by the High Court and Court of Appeal.

123. Dr Agnew-Davies saw each appellant for a single consultation of a little over four hours. She conducted a
semi-structured interview and administered a number of psychological tests10 and where available had regard to
the relevant health records and documentation. She appends all the diagnostic criteria applied, the relevant tests,


-----

and the transcript of her interview to her report. She has applied the terms of the Istanbul Protocol. Further to her
lengthy report we were given the opportunity to hear live telephone evidence from Dr Agnew-Davies.

124. A matter arose during the hearing as to the weight that could be attached to Dr Agnew-Davies' conclusions.
Mr Whitwell questioned why she had been selective in her application of the Trauma Symptom Inventory, one of the
diagnostic tools used in her report. She did not ask the questions from the scales measuring Sexual Concerns and
Dysfunctional Sexual Behaviour, because “these items are often found offensive and distressing by victims of
sexual abuse without, in my experience, helping contribute to a formulation”11. Mr Whitwell wanted to know
whether it would be standard practice to omit these questions. Dr Agnew-Davies explained that between 2000 and
2004 she and a colleague conducted research for Refuge. Looking at a study group of 500 women they found that
these particular questions caused distress, and were in fact unnecessary. She has adopted the practice of omitting
them since then. This data has been published. She has spoken publicly about her findings and has delivered
training in conjunction with a Professor at the Institute of Psychiatry.  No-one has challenged their conclusions.
She acknowledged that other mental health professionals leaving these particular questions out were usually
people that she had trained, but explained that it is not at all unusual for clinicians to tailor the questions asked
depending on the patient.

125. We are grateful to Mr Whitwell for his thorough and thoughtful cross-examination of Dr Agnew Davies, and to
Dr Agnew-Davies herself for making herself available to give live evidence. We have taken into account that these
are reports written after a single consultation, but we are nevertheless satisfied that they are evidence that we can
attach significant weight to. That is because Dr Agnew-Davies is a professional applying objective tests, she is an
expert in her field, and because the conclusions she reaches are entirely consonant with the accepted facts.

_Private Life_

126. The appellants had, at the outset of these appeals, conceded that they could not meet the requirements of
paragraph 276ADE(1)(vi). This provides that leave to remain should be granted where the applicant can show that
she:

(vi) ..is aged 18 years or above, has lived continuously in the UK for less than 20 years (discounting any period of
imprisonment) but there would be very significant obstacles to the applicant's integration into the country to which
he would have to go if required to leave the UK

Upon reflection this concession was withdrawn. That was because the relevant test, contained at sub-paragraph (vi)
of the Rule, would in these cases be determined with reference to precisely the same facts relied upon to show
internal flight would be 'unduly harsh'. This was not, as we understood it, acceptance that as a matter of law the
test of 'very significant obstacles to integration' is to be equated with 'unduly harsh'; it is simply that in these
particular cases the outcome of both would be the same.

_Obligations to VOTs_

127. Ms Khan submitted that in both cases the Secretary of State has failed in her duty towards the appellants,
both now recognised as VOTs.

128. It is accepted that the United Kingdom has an international obligation to provide VOTs with assistance for their
physical, psychological and social recovery. This arises under the UN Protocol to Prevent, Suppress and Punish
Trafficking in Persons (the Palermo Protocol), the Council of Europe Convention on Action against Trafficking in
Human Beings (ECAT)12, more recently under Directive 2011/36/EU of the European Parliament.

129. Article 6 of the Palermo Protocol provides:

“2. Each State Party shall ensure that its domestic legal or administrative system contains measures that provide to
victims of trafficking in persons, in appropriate cases:

…


-----

3. Each State Party shall consider implementing measures to provide for the physical, psychological and social
recovery of victims of trafficking in persons ...”

130. ECAT provides, in similar terms:

Article 12 – Assistance to victims

1 Each Party shall adopt such legislative or other measures as may be necessary to assist victims in their physical,
psychological and social recovery. …

2 Each Party shall take due account of the victim's safety and protection needs”.

…

Article 14 – Residence permit

1 Each Party shall issue a renewable residence permit to victims, in one or other of the two following situations or
in both:

a the competent authority considers that their stay is necessary owing to their personal situation”;

131. These obligations have been recognized by the courts as binding: see for instance Hounga v Allen &
Anor _[2014] UKSC 47, EK (Article 4 ECHR: Anti-Trafficking Convention) Tanzania_ _[[2013] UKUT 00313. The](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5929-8BS1-F0JY-C1RS-00000-00&context=1519360)_
government discharges these obligations primarily through operation of the NRM. The Respondent's Discretionary
Leave to Remain Policy provides:

“4.5 Trafficking cases

Where the UK Competent Authority has conclusively identified the applicant as a victim of trafficking and the
personal circumstances of the case are so compelling that a grant of leave is considered appropriate, DL should be
granted. The period of leave will depend on the individual facts of the case but must not be less than 12 months and
1 day and normally no more than 30 months (2.5 years). The minimum period of leave ensures that a victim of
trafficking who is refused asylum but granted DL has a right of appeal against the rejection of their asylum claim by
virtue of Section 83(1)(b) of the Nationality, Immigration and Asylum Act 2002”.

132. That these obligations exist, and that they must be met, was not in dispute.  The question raised by Ms Khan
is the extent to which they impose an ongoing duty of review on the Secretary of State. She accepts that at the
date of decision the Secretary of State was not aware of the material that is before us today. There was at that time
no finding of fact that the women had been trafficked, no conclusive grounds decisions and no evidence from Dr
Agnew-Davies. Nonetheless Ms Khan submits that the decisions to refuse leave have now been shown to be 'not
in accordance with the law'. The obligations to provide for their physical, psychological and social recovery do not,
she submits, depend on the information being provided prior to the date of decision.

133. Mr Whitwell accepts that where such information is made available to the Respondent, a review should, and
will, take place. The second appellant has written to request such a review (on the 8th May 2015) and when the
respondent looks again at her case the new material, including the findings of Judge Saffer and the report of Dr
Agnew-Davies, will be taken into account. Mr Whitwell submits that this does not mean that the original decisions
to refuse can be said to be 'not in accordance with the law' for failure to meet any of the relevant obligations under
international anti-trafficking agreements, since none of that material was available to the respondent at the date of
that decision.

134. The UK government is obliged to comply with its international commitments. Where, as in the case of the
second appellant, new material is subsequently brought to the respondent's attention, we agree that a review
should take place. This does not however mean that the existence of new material is capable of retrospectively
rendering the original decision unlawful. In the present case it is accepted that the first appellant has not directly
submitted any new material to the Secretary of State for her consideration. The second appellant has, in the course


-----

of the proceedings before us, done so. Mr Whitwell indicated that should her appeal be dismissed on asylum
grounds, her case will be actively reviewed. We are satisfied that this approach complies with the UK's obligations,
and in the present circumstances, no benefit can be accrued to the appellants by any declaration or direction by the
Tribunal.

135. We would add that we heard some argument about who is to bring new information and evidence to the
Secretary of State's attention. We were referred to various policy statements suggesting that such referrals can only
be made by actors such as the 'first responder' or the 'support provider'.  There is a risk, where such policy
documents exist, of the parties adhering to them so literally so as to lose sight of all common sense. If a referral is
made by a 'first responder' or a 'support provider' that is all well and good. That does not prevent any other
professional, be it a legal representative, social worker or doctor, bringing any pertinent matters to the respondent's
attention; where such a referral is received, outwith the framework in the respondent's policy, the international
obligations are engaged.

_The first appellant_

_Agreed Facts_

136. The facts as found by First-tier Tribunal Saffer and agreed between the parties in respect of the first appellant
are as follows:

i) She is an Albanian national born in 1988.

ii) She was born in a village in Northern Albania. Before leaving Albania that is where she lived with her parents,
brother and five sisters. Her parents and siblings still live there.

iii) The first appellant's father is employed as a security guard and her siblings are unemployed. She is from a poor
economic background.

iv) Her family are “strict Muslims”.

v) The first appellant attended school for 8 years at primary level until the age of 14. She then remained at home.
Her movements were restricted by her family. The first appellant was not allowed to study or work thereafter.

vi) In October 2013 the first appellant met a man (the trafficker) who was visiting his cousin who lived locally to her.
The first appellant began a secret relationship with him. They communicated using a mobile phone provided by him.
The first appellant met the trafficker at his cousin's house every fortnight and she spoke to him on the phone every
day.

vii) The relationship was discovered by the first appellant's father and brother. She was beaten severely by her
father and brother. The first appellant managed to run away when her mother and sister intervened to assist her.
She believes her father and brother would have killed her had they not been restrained.

viii) The trafficker collected the first appellant took her to a flat in Tirana where she was kept confined. He told the
first appellant that her family were looking for her and wanted to kill her. She was kept in the flat for 1 month after
which she was forced to work as a prostitute in the flat. She was forced to have non-consensual sexual intercourse
with numerous men under the immediate and real threat of physical violence. During this period she was raped
between 2 and 5 times a day for 6 weeks (between 80 and 200 times).

ix) The first appellant planned to kill herself twice by jumping off the balcony but was stopped by the trafficker.

x) She was allowed to speak to her sister once on the telephone. Her sister told her that her family knew she was
working as a prostitute and that her brother would kill her if she returned home.

xi) The trafficker arranged to obtain an official passport for the first appellant and has kept it.


-----

xii) The trafficker, and another man, then drove the first appellant in a car for a week before being put in the back of
a lorry. He told her that there were two or three other girls in the back of the lorry. The trafficker told the first
appellant that he expected her to have sex with 'clients' in the UK too. The lorry arrived in the UK.

xiii) The first appellant will not return to Albania voluntarily.

xiv) She has no access to family support and cannot return to her home area.

_Medical Evidence_

137. Dr Agnew-Davies had one clinical consultation with the first appellant which lasted for four hours and ten
minutes. Her report is dated 14th April 2015.  The first appellant told Dr Agnew-Davies that before “all of this” she
weighed 68 kilos. She now weighs 57. She eats little and sometimes goes for three days before she eats again.
She suffers from “terrible” headaches and cannot sleep at night. She told Dr Agnew-Davies that she feels panic or
terror “most of the time”. During the course of their consultation the first appellant was variously observed to be
distressed, shaking and at times “barely able to breathe”. Dr Agnew-Davies noted that as they completed the Beck
Depression Inventory the first appellant presented unusually severe symptoms of motor retardation: “any movement
at all seemed to be an effort”.

138. In summary the report concludes that the first appellant exceeds the clinical threshold for at least eight of the
nine symptom clusters associated with Major Depressive Disorder; she also meets the diagnostic criteria for chronic
and complex PTSD.

139. The first appellant told Dr Agnew-Davies that she has twice attempted suicide in the past. She tried to jump
from a balcony whilst under control of her trafficker but he prevented her from doing so. Since her arrival in the UK
she has taken an overdose of paracetamol. At present she expresses a weak will to live and a moderate to strong
wish to die. That is because her reasons for wanting to die outweigh the reasons for staying alive.  She thinks
about it continually and has considered ways of doing it, but has not worked out the details. She repeatedly stated
that she is frightened and convinced that she will be killed by her father, brother or trafficker if she is returned to
Albania. Mr Whitwell asked Dr Agnew-Davies to clarify whether (as it appeared from the interview summary in the
report) the first appellant had not volunteered that she had taken an overdose, and had in fact only disclosed that
when prompted. Dr Agnew-Davies confirmed that she had asked the direct question, but stated that this is perfectly
standard. Persons contemplating suicide very rarely spontaneously reveal their intentions – it would almost always
emerge through direct questioning.

140. As to the diagnosis of Major Depressive Disorder13 two separate tests showed the first appellant's ratings to
fall into the severe range, to a degree not found in 99% of the population. At present she presents a moderate risk
of suicide. She has found numerous reasons to kill herself, but none if any to offset the risk, for instance attachment
to family or religious belief. Dr Agnew-Davies does not believe that this diagnosis adequately captures the “fear
and interpersonal problems” that the first appellant presented.  She therefore also considered the criteria for a
diagnosis of Post-Traumatic Stress Disorder. The first appellant exhibits all of the core symptoms of intrusion,
avoidance, negative cognition/mood and arousal (anxiety/fear). The high ratings found in respect of each of these
symptoms leads Dr Agnew-Davies to diagnose Complex PTSD: the first appellant also exhibits altered affect
regulation, altered levels of consciousness, altered perception of self, altered perceptions of the perpetrator(s),
altered world view and altered relationships with others. In respect of this latter criteria Dr Agnew-Davies expresses
“serious concerns” about the first appellant's “capacity to function socially or interpersonally”. She describes the first
appellant as “one of the most isolated people I have encountered in my work over the last 15 years”. The first
appellant is not fit to work or give evidence. Dr Agnew-Davies does not think that the first appellant should be living
alone without being monitored by statutory mental health services. All of this is highly consistent with Dr AgnewDavies' experience of other women who have survived sexual and physical abuse and with the account given by
the first appellant herself.

141. The first appellant was prescribed a two week course of Citalopram in August 2014 but has not sought any
further medication. Dr Agnew-Davies notes that she was shown correspondence from the first appellant's doctor's


-----

surgery indicating that a number of appointments were rearranged. Because of her concerns about the first
appellant's current condition she recommends and requests that her report is sent to the GP.

142. In respect of causation Dr Agnew-Davies notes the first appellant's evidence that she grew up in a strict and
controlling family where she experienced physical abuse (being beaten by her father and brother), neglect and
emotional abuse. She witnessed domestic violence against her mother. Research shows that when one type of
abuse is experienced and/or if the abuse involves terror and captivity, the risk of developing problematic complex
PTSD is increased, especially where the first abuse occurs before the age of 13.  The first appellant described a
restricted childhood in a controlling, violent home where she was resigned to the idea of growing up to forced
marriage. She describes her strict Muslim father and brother as “fanatics”. In her oral evidence Dr Agnew-Davies
confirmed that she has heard similar accounts of abuse in childhood from other Albanian VOTs. Dr Agnew-Davies
does not believe that these early experiences fully account for her condition, but they are likely to have contributed
to her own powerlessness, helplessness and lack of self-worth. They are secondary to the trauma caused by the
trafficking.  Dr Agnew-Davies further considers whether the serious assault by the first appellant's father and
brother (when they discovered her relationship with the trafficker) could itself have led to her current condition. Dr
Agnew-Davies believes it to be a factor, but not one that could in itself have caused these symptoms. For instance,
if the relationship had turned into a loving intimate partnership as the first appellant had hoped, her symptoms may
over time have ameliorated.  The severity and complexity of the first appellant's symptoms are highly consistent
with a history of repeated sexual abuse by different perpetrators over time14. Her lack of certainty over her
immigration status and her poverty in childhood could be aggravating, but not causal factors. It is not possible to
accurately weigh the relative impacts of any specific incident, but only to consider the cumulative impacts.

143. Dr Agnew-Davies states that traumatised victims often present with physical symptoms and this is most likely
where the victim is reluctant or unable to speak about her experience. The first appellant reports a number of
neurological and physiological problems all highly congruent with her history of sexual abuse. Dr Agnew-Davies
notes that she has only ever seen the heightened sensitivity to noise exhibited by the first appellant in other victims
of trafficking for sexual exploitation. Dr Agnew-Davies has considered the possibility that the first appellant is
exaggerating or feigning her symptoms, and discounted it. The symptoms of complex PTSD are difficult, if not
impossible, to fake. In Dr Agnew-Davies professional opinion her psychological presentation was typical of a history
of abuse (her emphasis).

144. Dr Agnew-Davies concludes her report by considering how each of the first appellant's symptoms clusters
might impact on her capacity to cope and keep herself from harm. She finds:

i) The first appellant experiences unusually severe levels of _intrusion_ in the form of memories, flashbacks and
nightmares. Her cognitive ability to make decisions to promote safety or manage a situation is grossly impaired.
Whilst experiencing intrusions to this degree the first appellant is ill-equipped to cope practically or emotionally with
situations of threat;

ii) The first appellant reacts against her intrusive thoughts by avoidance. She actively tries to defend herself against
these memories by avoiding them. This means that she is highly unlikely to seek help; these efforts to avoid being
overwhelmed by traumatic memories paradoxically increases her isolation and impede her recovery;

iii) The first appellant dissociates to a clinically significant extent. This is an unconscious reaction which is highly
likely to render her passive. She may appear apathetic or paralysed: this is part of a well-established pattern
amongst victims of repeated trauma and it can impede efforts to escape situations of danger;

iv) The first appellant is in a generally heightened state of fear. These arousal symptoms are very deleterious to her
already fragile mental health and aggravate her tendency to isolate herself, which in turn aggravates her symptoms;

v) As a function of her depression she lacks energy, motivation and initiative and is more prone to contemplating
suicide;

vi) Complex PTSD encompasses a range of severe interpersonal disturbances that render a trauma victim at a
greater risk of exploitation. She remains vulnerable to being led into, and then trapped within, abusive situations


-----

because she may well resort to a well-established pattern of fear and obedience. It is very difficult for the first
appellant to hide her symptoms and disturbed behaviours: unscrupulous others could identify and exploit this.

145. At present the first appellant is not receiving any treatment. About half of adults who suffer from PTSD can
recover within about three months. Others may suffer symptoms for as long as 50 years. In cases where there are
overlapping diagnoses of PTSD and Major Depressive Disorder relapse is far more likely; a complex presentation is
associated with a more complex and longer term recovery. Dr Agnew-Davies believes that the first appellant is
extremely unlikely to show a spontaneous improvement. The first appellant is in need of active intervention from
home-based statutory mental health services to manage her suicidal ideas and acute symptoms. Any substantive
recovery would only be possible in the long term:

“[The first appellant] really needs trauma-focused and specialist treatment. However, trauma focused therapy can
only _start_ when the sufferer feels safe in their environment, to a degree sufficient to withstand the emotional
intensity of re-exposure to trauma and cognitive re-processing…in effect, it is not possible to start rebuilding the
burning house until the fire has been put out”

146. In the UK the approved treatment would involve medication prescribed in conjunction with psychological
therapy. To be successful this process would need to occur in a non-threatening environment with clinicians that
the patient can trust. That would include social security: “it is well established that social security is a significant
predictor of recovery, while isolation is likely to cause a deterioration in mental health”. In this regard Dr AgnewDavies states:

“If the outcome of proceedings was that [the first appellant] was to return to Albania, I think her mental health would
significantly deteriorate and that her suicidal ideation would significantly increase. I cannot predict the speed or rate
that her suicidal impulses will increase but I anticipate that there is a high risk she will attempt suicide immediately if
notified that she was to be removed and would continue to present a high risk on return, making repeated attempts
if unsuccessful. My opinion is based on the assessment of current suicide risk, [the first appellant]s beliefs about
Albania, her fear for her life or of being re-trafficked, as well as of social rejection from the village”

_The first appellant: Our Findings_

147. Our decision in the re-making of the first appellant's appeal is as follows.

148. The first appellant does not wish to return to Albania. She is not therefore eligible for the assistance offered
by the IOM through the RAVT programme.  She would however still receive the assistance offered by the Albanian
government through the operation of the NRM, which could include referral to a shelter. We were shown no
evidence that entry into the NRM is only available to those making a voluntary return. The question is whether it is
reasonable, in all the circumstances, that she avail herself of this option.

149. We have accepted that the NRM functions well and that that border officers are now expected to implement
the SOP. This does not include an option to contact the returning VOTs family against her will. The evidence
before us does not disclose a general objective risk that officials will act outwith that framework.  We find that if
returned to Albania the likely outcome for the first appellant would be that she would be met on arrival, processed
and taken to one of the four shelters. She would there be provided with accommodation, food and at least basic
healthcare. She may have access to counselling provided by a non-medically qualified member of staff. She will be
offered some form of vocational training such as a hairdressing or cookery course. Having had regard to the
medical evidence we have serious doubts about the first appellant's ability to engage with, or benefit from, such a
course. We note Dr Agnew-Davies' opinion that she is not currently fit to work. There are no features of the first
appellant's case which would indicate that she would be treated as a “heavy case”. It is therefore likely that she will
be required to leave the shelter after 3-6 months.

150. The socio-economic challenges to the first appellant at this point are likely to be substantial. She has some
basic education, having left school at 14, but would be presenting to prospective employers at the age of 27 with no
experience at all of working in Albania bar her brief period of vocational training in the shelter.  The best-case
scenario would be that she would be employed by an NGO but as we have heard, these jobs are few and far


-----

between and share the same financial insecurity as the organisations themselves. The likelihood would be that she
would have to find non-skilled low paid employment in the 'grey economy'.

151. The assessment made by Dr Agnew-Davies indicates two risks to the first appellant at this juncture: internal
and external. The internal challenge is that the first appellant is suffering from such profound mental distress that
she is unable to function 'normally'. She suffers from such levels of fear and anxiety that her illness manifests itself
as physical symptoms such as shaking, pain, and difficulty breathing. She is not at present fit to work.  She has
expressed an intention to kill herself should she be returned to Albania, the risk of which is assessed to be “high”.
Dr Agnew-Davies observed that she was one of the most “isolated” people she has met in 15 years of working with
victims of abuse.  In these circumstances we are satisfied that the first appellant would face substantial difficulty in
finding or keeping employment, and in turn accommodation.  She would be living with the constant subjective fear
of discovery by her family – in such a small country not a fanciful threat. These internal challenges in turn give rise
to external risks. Dr Agnew-Davies has set out with clarity why the first appellant's condition would impair her ability
to function normally within society and to protect herself from potential danger. She suffers symptoms of intrusion,
and in turn avoidance, to such a profound degree that “her cognitive ability to make decisions to promote safety or
manage a situation is grossly impaired”. In short, she would appear to the world outside as someone with serious
mental health problems. Dr Agnew-Davies states that it would be “very difficult for the first appellant to hide her
symptoms and disturbed behaviours” and concludes from this that “unscrupulous others could identify and exploit
this”. We agree with that assessment. The nature and extent of the first appellant's illness would severely limit her
ability to function. Left to fend for herself she would suffer profound mental distress and her ability to protect herself
from danger would be severely compromised.

152. We bear in mind Mr Whitwell's point that the target age group for traffickers is late teens/early twenties, and
that this would reduce the risk presented to the first appellant. We have however also had regard to the figures in
the UNP Needs Assessment. Approximately 20% of the VOTs that featured in that study, and in the NCATS annual
report, had been re-trafficked having been through the shelters once before. We find that someone with the
particular vulnerabilities that Dr Agnew-Davies has identified in the first appellant would be reasonably likely to fall
within that group: we are satisfied that the least likely to be able to cope on their own will be the ones most likely to
fall prey to the traffickers.

153. Even if we are wrong about the risk of re-trafficking we are satisfied that for the reasons set out above the first
appellant would be unable to live a “reasonable” or “relatively normal” life without undue hardship should she live on
her own in Albania. For that reason there is no safe internal relocation option available to this appellant; her removal
would therefore be a breach of the Refugee Convention and Article 3 ECHR. She has shown that there would be
very significant obstacles to her integration into Albanian society and so also qualifies for leave to remain under
paragraph 276ADE of the Immigration Rules.

154. In the circumstances we have not considered it necessary to assess the risk of suicide should the first
appellant be forcibly removed from the United Kingdom.

**_The second appellant_**

_Agreed Facts_

155. The facts as found by First-tier Tribunal Judge Saffer and agreed between the parties in respect of the second
appellant are as follows:

i) The second appellant is an Albanian national born in 1991. She was born in North Albania.

ii) Her family originate from Dukagjin, an area in the middle of the Alps in Albania which was ruled by the famous
Kanuni i Leke Dukagjinit. Her father came down from the mountains to make a life working on the agricultural land.

iii) The second appellant comes from a poor economic background.


-----

iv) The second appellant's father has very strict traditional beliefs and did not believe that women and girls should
be educated. Hence she was prevented from attending school after completing the seven compulsory years of
primary education.

v) The second appellant met a man (her trafficker) in Albania and entered into a relationship with him. The trafficker
spent 7 months in jail in Albania during their 10 month courtship. The second appellant left Albania on 15th
September 2013 using her own passport and went to Italy and then Belgium.

vi) The day after they arrived in Belgium, the second appellant was forced by the trafficker to work as a sex slave.
She was forced to have non-consensual sexual intercourse with numerous men under the immediate and real
threat of physical violence. She was raped 4 or 5 times a day for 8 weeks.

vii) The second appellant escaped from a brothel in Belgium. She arrived in the UK on 21st January 2014 after
being hidden in a lorry.

viii) The second appellant has a son who was born in June 2014 in the United Kingdom. The father of her son is
not known.

ix) The second appellant has no access to family support. It is accepted that she faces a real risk of serious harm
should she be returned to her father's home. Additionally, return there would place her back in the area from where
she was trafficked and where traffickers may still operate.

x) The second appellant describes herself as having lived a sheltered life in Albania and she has been told by
others that she presents as younger than her years. She says that she speaks with a distinctive Northern dialect.

xi) The second appellant does not wish to return to Albania.

_Medical Evidence_

156. Dr Agnew-Davies saw the second appellant on one occasion for four hours and interviewed her with the
assistance of an interpreter. She records that the second appellant “pinched her arm and wrung her fingers” during
the interview; her eyes were sad and her expression was pained. She was frequently tearful and at points her voice
became uneven and her breathing ragged.

157. Her conclusions are that the second appellant presents with a highly complex and chronic form of PTSD. The
majority of her trauma-related symptoms are related to her trafficking experience, but she did have a number prior
to her trafficking experience as a function of oppression by her father: she attempted suicide in her teens. She also
suffers from chronic Major Depressive Disorder of moderate severity. The report notes that the diagnostic scales
show her to be in the 'severe' range – for instance the results of the Trauma Symptoms Inventory indicate more
severe distress than found in 97% of the population – but Dr Agnew-Davies has modified the results to 'moderate'
because of the second appellant's commitment to, and engagement with, her son. Similarly her risk of suicide is
currently deemed to be low, as a function of caring for her son in a secure and supported environment. Dr AgnewDavies however cautions that it could rapidly escalate if she anticipated that they would be returned to Albania:

“In my professional opinion, [the second appellant] is rendered especially vulnerable by her mental illness and by
her conviction that she and her son will be found and killed if they are returned to Albania. At this stage in her
recovery, she is ill-equipped to cope with any major change, especially one which removes her from her sense of
safety and support network in the UK. In my opinion, her conviction that she would much prefer to commit suicide is
convincing and on which I think it highly likely that she would act.”

158. The second appellant described to Dr Agnew-Davies suffering from symptoms including intrusive memories
and feeling constantly scared. When she tries to sleep at night she is startled by what she thinks is someone
knocking on her window: in fact there is no-one there. The only night she can recall sleeping soundly was when she
had called the police and they had reassured her that they were patrolling the area and that there was no-one
around. She finds it impossible to relax and is haunted by thoughts such as “them” finding her and killing her son in
front of her It is the thought of being captured which makes her contemplate suicide most often She feels


-----

shame, and is afraid of her family: “I am a spoiled woman now and I will be forever judged as a bad woman”. Her
physiological symptoms include insomnia, numbness, constant headaches and fatigue. Asked whether she stays
away from certain people or places she said

“…some day probably three months ago I saw someone who looked like [the man] and I froze. I couldn't do
anything. I couldn't go forwards or backwards. I just froze and then I felt bad after that. I just wanted somewhere to
sit. I didn't have any energy left in my body”.

159. Dr Agnew-Davies believes that the symptoms suffered by the second appellant are primarily a function of her
trafficking experience, but that they are complicated by her childhood attachments. The second appellant described
her father as “controlling and oppressive” and that she had frequently witnessed him beating her mother. Although
Dr Agnew-Davies has no current concerns about this history impacting on the second appellant's ability to parent
her son, she believes that her conditions, if left untreated, will have adverse implications for the long-term
psychological health and well-being of her son. In oral evidence Dr Agnew-Davies was asked to comment on a note
made on the second appellant's antenatal notes by a midwife to the effect that there had been no domestic violence
in her family home. Dr Agnew-Davies was unable to comment on that specific note but said that it did not surprise
her since she had in fact worked on a randomised trial in which deficiencies had been found in primary care notes,
in particular a failure to capture domestic violence. She has worked on a programme to redesign the questions that
are asked and it is now being rolled out across the country.

160. As with the first appellant, Dr Agnew-Davies finds evidence of all four symptom clusters associated with
PTSD. In respect of each she records:

i) The second appellant suffers intrusion more severely than 99% of the population. She describes being plagued
by inescapable memories and thoughts, including flashbacks and nightmares. These intrusions can trigger suicidal
thoughts.

ii) The second appellant's symptoms of _avoidance exceeded those found in 90% of the population, a result just_
below the clinical threshold. Dr Agnew-Davies believes that this is because her level of intrusion is so high she is
unable to defend against traumatic recollections.  She generally manages to avoid these thoughts whilst caring for
her son, but is overwhelmed by them when he sleeps.

iii) In addition to conscious avoidance many victims of complex trauma experience an involuntary response known
as _dissociation._ This is a sub-conscious detachment from the present situation in which a victim can become
trapped and immersed in isolated recall and/or flashbacks.  The second appellant exhibits a level of dissociation
not found in 99% of the population. The 'freeze' response she described when seeing someone who looked like her
trafficker is a “classic symptom of PTSD in the aftermath of trauma”

iv) Dr Agnew-Davies found evidence of entrenched negative cognitions. The second appellant experiences
persistent self-blame and shame.

v) The second appellant exhibited physical signs of arousal during the interview when she was in a high state of
agitation and there were marked changes in her rate and depth of breathing. She was seen to tremble and fidget.
She experiences hot flushes and sweating even where the room temperature has remained constant. Of these Dr
Agnew-Davies observed: “the physiological changes that I observed are beyond any kind of wilful control and are
responses of the sympathetic branch of the nervous system (i.e. responses geared towards fight/flight/freeze
responses in situations of danger)”.

161. Dr Agnew-Davies specifically considers whether it is possible that the second appellant is feigning her
symptoms. She does not believe this to be the case. Many of the physiological symptoms were witnessed, not just
described, and Dr Agnew-Davies has substantial experience in assessing such claims. For instance when she
managed the UK national domestic violence helpline she trained staff to detect women who were falsely claiming to
be abused in order to secure accommodation. The second appellant's responses were highly congruent over a
number of standardised tests. In conclusion Dr Agnew-Davies finds that she is suffering from severe symptoms of


-----

chronic complex PTSD, complicated by her depressive disorder. These conditions cause her significant distress
and impair her social functioning.

162. Of particular concern is the second appellant's high level of dissociation. This unconscious reaction can make
her appear “apathetic or paralysed in a psychological state long known as 'learned helplessness'. This state has
grave implications because it can impede efforts to escape situations of danger in future…she is likely to follow
orders in a disembodied, dissociated state irrespective of her conscious will”. Further “she remains vulnerable to
being led into and trapped within abusive relationships because she can easily lapse into a well-established pattern
of fear and obedience, with hopelessness about the possibility of escape:

“…it is extremely common that victims of childhood abuse and trafficking learn to comply with, not to resist,
perpetrators to reduce the risk of further violence”. Moreover she cannot easily hide her symptoms, which puts her
at greater psychosocial vulnerability because unscrupulous others could identify and exploit her fear and
compliance”

163. Dr Agnew-Davies identifies two positive factors in her assessment of the second appellant. The first is the
presence of her son: “her devotion to her son and her determination to protect him increase her resilience and
offset her symptomatology”. The second is that her condition has shown some improvement. During the course of
her pregnancy the second appellant accessed regular medical support. Her GP recorded her symptoms of
headaches, gynaecological and urinary tract infections, and observed that she appeared tearful, worried and slept
badly. This led her to refer the second appellant for counselling. This started in October 2014 and led to an
improvement in her self-care. She was provided with coping strategies to deal with some of her symptoms. The
counsellor's notes accord with Dr Agnew-Davies assessment in respect of her son: “caring for her son was not just
important in giving her life a purpose but served to distract [the second appellant] from intrusive, painful memories,
at least during the day”. Although the second appellant is still heavily dependent upon support Dr Agnew-Davies
finds that the medical, counselling and other interventions by authorities have had a positive impact upon her. She
is making stable and significant progress.  Against these positive findings Dr Agnew-Davies sounds two notes of
caution. These gains are dependent upon the second appellant feeling secure, and any interruption or threat to
that security will quickly lead to a deterioration in her mental health and her ability to care for her son. The second is
that the counselling is not in itself going to enable her to recover: she still suffers from a clinically significant comorbid psychiatric disorder and as such requires further, substantial and long-term treatment. Her symptoms,
including fear, self-neglect and suicidal ideation, are “barely under control”.

164. Dr Agnew-Davies is unequivocal in her assessment of the second appellant's prognosis should she be
returned to Albania. Her intrusive memories are much more likely to be triggered there, and her symptoms of
disassociation mean that it is highly likely that she will “freeze” rather than take adaptive action if confronted with
danger. Her psychological profile severely reduces her capacity to cope, and any deterioration thereof would
negatively impact on her capacity to parent her son. Dr Agnew-Davies does not believe that she is fit to work or live
independently without a long-term support package such as that available to her in the UK.

_Our Findings_

165. We re-make the decision in the second appellant's appeal as follows.

166. The second appellant does not wish to return to Albania. Like the first appellant she is not therefore eligible
for the IOM package, but we are satisfied that she would gain entry into the Albanian NRM and be referred to a
shelter.

167. She and her son would there be provided with accommodation, food and basic healthcare. She may have
access to counselling provided by a non-medically qualified member of staff. She will be offered some form of
vocational training such as a hairdressing or cookery course, and although we are unable to make confident
findings about the quality or quantity of it, she would be offered some childcare to enable her to attend these
classes. We are satisfied that the second appellant would be able to engage with these services. She has
demonstrated that ability in the UK where she has benefitted from medical care, ante-natal provision and
counselling Her son gives her the positive motivation to take part Because she has a young child it is likely that


-----

she will be treated as a “heavy” case. Her stay in the shelter could be as long as 2 years. She may therefore gain
substantially from her time there.  In that length of time she could make friends, gain contacts and learn a skill to a
relatively high standard.

168. The practical support offered by the shelter to a mother like the second appellant is a positive feature of the
efforts of the Albanian government. For some women in her position the net gain made in the shelter will be of
sufficient value to ensure that she can 'make it on her own' once she leaves.  However our assessment must focus
on her particular characteristics and circumstances of as set out in the accepted facts and the findings of Dr AgnewDavies.

169. The second appellant presents with a highly complex and chronic form of PTSD as well as chronic Major
Depressive Disorder. Her symptoms manifest in an external, physiological way, as well as causing her internal
pain. For instance in their consultation, in a safe, welcoming and secure environment in the UK, she was observed
to be tearful, shaking, sweating and experiencing changes in breathing.  She described to Dr Agnew-Davies how
she 'froze' and became paralysed when she saw someone who looked like her trafficker.  These are indications
that although she has made progress since her arrival in the UK, the second appellant remains a highly vulnerable
individual.  Dr Agnew-Davies believes that her conditions will stop improving should she be removed from the
security of the UK; in fact they are likely to deteriorate.

170. These symptoms seriously compromise the second appellant's ability to cope, and to parent her son without
long-term support. Even in the UK she continues to suffer from intrusive memories, particularly at night when her
son is asleep and the distraction he gives her during daylight hours is removed.  This leads to serious concerns
about the risk that the second appellant would attempt suicide should she be returned to Albania, or perceive a
threat that she and her son would be found:

“…in my opinion, her conviction that she would much prefer to commit suicide is convincing and on which I think it
highly likely that she would act.”

She credibly describes being haunted by thoughts that “they” will find her and kill her son in front of her.  We
accept that these fears are far more likely to overwhelm her in a flat in Tirana than they are likely to do in the UK.

171. Even with a relatively long stay in the shelter the second appellant will, at some point, be required to leave
and live on her own. As we have found, this is not impossible, even for a woman with a child. Professor Haxhiymeri
told us about survivors of domestic violence that her organisation has helped to relocate away from their families.
The second appellant is however likely to face significant social and practical obstacles. There will be the same
difficulties that the first appellant will face in finding and keeping employment well paid enough to secure
accommodation. In the second appellant's case she faces the additional hurdle of paying for childcare. She and
her son will face the social stigma of living without their wider family. We accept that even in the urban setting of
Tirana this small family unit will be likely to raise questions. This will feed into the subjective fear that the second
appellant already holds about being found by her family, or her former traffickers.  In this regard we recall the
thoughtful conclusions of Wilson LJ in VMN that when assessing the reasonableness of internal flight for a single
mother consideration must be given to:

“…her ability convincingly to present to those in her new milieu a false history relating to herself and to her
daughter, including the latter's paternity, and a false explanation for their arrival there; and, in the light of her
substantial psychological vulnerability, consideration of her ability to sustain beyond the short term a reasonable life
for them both on that false basis”.

172. Having taken all of those factors into account we conclude that internal flight is not a reasonable option for the
second appellant and her son. Although she has shown a degree of resilience, driven by her impulse to be there
for her child, we are far from satisfied that she will be able to cope upon return to Albania. Dr Agnew-Davies has
found her symptoms, including fear, self-neglect and suicidal ideation, to be “barely under control”. There is likely to
be a significant deterioration in her condition should she be returned to an environment where she believes she and
her son to be at risk. The distress that this will cause will be alleviated to some degree by the support offered by a


-----

shelter, but on the evidence before us she is unlikely to receive mental health treatment to the standard and efficacy
required in her particular circumstances.

173. We therefore allow the appeal of the second appellant on asylum grounds and Article 3 ECHR. In the
alternative she qualifies for leave to remain under paragraph 276ADE because there are very significant obstacles
to her integration in Albania. Again, we have not considered it necessary to address the discrete issue raised as to
a possible violation of Article 3 arising from the risk of suicide.

**DECISIONS**

174. The appeals of both appellants are allowed on asylum grounds.

175. Neither appellant is entitled to humanitarian protection because they are refugees.

176. The appeals of both appellants are allowed on human rights grounds.

Signed        Date

Upper Tribunal Judge Dawson

NOTICE OF DECISION

The appeals are allowed on asylum grounds.

**Direction Regarding Anonymity – Rule 14 of the Tribunal Procedure (Upper Tribunal) Rules 2008**

Unless and until a Tribunal or court directs otherwise, the appellants are granted anonymity. No report of these
proceedings shall directly or indirectly identify them or any member of their family. This direction applies both to the
appellants and to the respondent. Failure to comply with this direction could lead to contempt of court proceedings.

Signed        Date

Upper Tribunal Judge Dawson

**TO THE RESPONDENT**

**FEE AWARD**

No fee is paid or payable and therefore there can be no fee award.

Signed        Date

Upper Tribunal Judge Dawson

**Appendix A – Error of Law Decision**

**Upper Tribunal**

**(Immigration and Asylum Chamber)**

**THE IMMIGRATION ACTS**

**Heard at Field House** **Determination**
**Promulgated**

**On 16 December 2014**

…………………………………


-----

**Before**

**UPPER TRIBUNAL JUDGE DAWSON**

**UPPER TRIBUNAL JUDGE RINTOUL**

**Between**

**T D (1st appellant)**

**A D (2nd APPELLANT)**

Appellants

**and**

**THE SECRETARY OF STATE FOR THE HOME DEPARTMENT**

Respondent

**Representation:**

For the Appellants: Miss S Khan, Counsel (1st appellant)

Miss F Daley, Counsel (2nd appellant)

For the Respondent: Mr Whitwell, Home Office Presenting Officer

**DECISION ON ERROR OF LAW**

1. The first appellant is a citizen of Albania born on 15 March 1998. The second appellant is also a citizen of
Albania, born on 31 December 1991. Their appeals were heard by Judge Saffer on 8 August 2014 and in each
case he dismissed the appeals against the decisions in respect of each appellant to remove her from the United
Kingdom as an illegal entrant made on 23 June 2014 and 20 May 2014 respectively, those decisions being
consequent upon the decisions to refuse their claims for asylum.

2. It is not at this stage necessary to set out the appellants' case in detail; it is sufficient to note that in both cases
the appellants were trafficked from Albania, forced into prostitution, and subjected to a significant amount of sexual
violence. In both cases threats were made to them by their families and Judge Saffer found that they would be at
risk in their home areas in north Albania.

3. The respondent argues that in both cases there would be sufficient police protection and support in Albania; that
the appellants could relocate; and, that it would be reasonable to expect them so to do, the fact that the second
appellant has a young child notwithstanding.

4. Judge Saffer dismissed the appeals on asylum and on human rights grounds. Having set out paragraphs 1.1.9
to 1.1.14 of the respondent's Operational Guidance Note of July 2014 he concluded:
i. that the situation in Albania had changed significantly since the decision in **AM and BM (Trafficked women)**
**Albania CG [2010] UKUT 80 (IAC);**

ii. that the appellants would be able to internally relocate initially to the shelters available and within the support
framework provided; and, seek police protection;


-----

iii. that there was no risk that they would be tracked down in either case by those who had formerly tricked them
into prostitution or by their families; nor was he satisfied that they would be forced to work again as prostitutes or retrafficked given the package of support protection; that they would given such professional psychological support as
required.

5. Both appellants sought permission to appeal on the ground that Judge Saffer had erred in failing to give sufficient
reasons for departing from AM and BM; and, that he erred with regard to the evidence upon which he did rely, as
set out in the OGN; and, that he had not properly considered the specific circumstances of either appellant in
judging whether, on the basis of the new evidence, they would not be at risk on return to Albania.

6. Permission to appeal was granted in both cases by First-tier Tribunal Judge Andrew who stated:

“The grounds complain that the judge did not follow the country guidance case of AM and BM (Trafficked women)
**Albania CG [2010] UKUT 80. That he had not ..... because he took note of the OGN in July 2014. This is a policy**
document and not country information. I accept that there is any arguable material error of law in the
determination.”

7. We consider, having heard submissions from all three representatives, that while Judge Saffer was entitled to
take the Operational Guidance Note into account, there is insufficient indication that he took into account that this is
in part a policy document produced by the respondent setting out her view of the risks on return to Albania; in
addition the document seeks to give guidance to caseworkers.

8. The OGN is clearly addressed to decision makers within the Home Office and whilst we accept that as Mr
Whitwell submitted, it is open to the Secretary of State through guidance notes to give instructions to her
caseworkers as to how they should reach decisions, it does not necessarily follow that she can submit that this
guidance should be followed by the Tribunal, nor did Mr Whitwell make such a submission. Indeed, had Judge
Saffer actually read the document as a whole, he would have realised that the respondent accepts that AM & BM is
still good law and expressly requires at 1.1.15 a careful analysis of individual circumstances.

9. It cannot be discerned from the determination that Judge Saffer engaged with the evidence set out in section 2 to
7 of the OGN, much of which is critical of the facilities offered to those who have been trafficked rather than the
policy summary as set out in his determination. There is insufficient indication in his determination of any nuanced
fact-specific consideration as to how the changes, and indeed in the systems of protection put in place by the
Albanian government of for that matter funded by the British government would be suitable for either appellant. That
changes were afoot was a matter considered in **AM & BM but rather than engage with that decision and give**
sufficient reasons for departing from it, Judge Saffer simply chose not to follow it. That is an error of law. It is
unlawful for a First-tier Tribunal Judge to seek not to follow a Country Guidance case on the basis not of evidence
but of a gloss placed on background evidence by one party to adversarial proceedings.

10. Accordingly, for these reasons, we are satisfied that the decision of Judge Saffer involved the making of an
error of law. We therefore set them aside.

11. It is our view the guidance of these appeals are suitable for country guidance and accordingly, they will be listed
for Case Management Review on 15 January in Manchester before Upper Tribunal Judge Dawson when a decision
will be made as to the future conduct of these appeals and directions given.

Signed        Date: 31 December 2014

Upper Tribunal Judge Rintoul

**Appendix B – Documents and Reports before the Upper Tribunal**

**Expert Reports before the Upper Tribunal with Supplementary Country Documents**

**Dr Haxhiymeri Report:**


-----

|Date|S o u r c e|Description|
|---|---|---|
|17 April 2015|Dr Edlira Haxhiymeri|R e p ort for TD (Albania) and AD (Albania)|
|January 2015|International Organisation f o r M ig r a t io n (IOM)|United Nations Programme 'Support to Social Inclusion in Albania' - Profile of the Situation of trafficking victims and efforts for social inclusion|
|2014|Produced for the I n ternational Organisation for Migration by the Research Communication Group|Human Trafficking in the Western Balkans, Needs Assessment, IOM Development Fund|
|2009|Centre For Legal Civic I n itiatives|Report on "The development and implementation of the Albanian legislation to combat human trafficking in human beings, with a focus on the protection of rights of victims of trafficking"|
|2013|Different & Equal|A nnual Report|
|10 April 2015|Stop Corruption Website|L i n k : h t t p://www.stopkorrupsionit.al/|
|10 April 2015|Transparency International W e b s i t e|Link: www.transparancy.org/cpi2014/results|


**Dr Robert Chenciner Report:**


**Description**

Report for TD (Albania) and AD (Albania)

United Nations Programme 'Support to Social Inclusion
in Albania' - Profile of the Situation of trafficking victims
and efforts for social inclusion

Human Trafficking in the Western Balkans, Needs
Assessment, IOM Development Fund

Report on "The development and implementation of the
Albanian legislation to combat human trafficking in
human beings, with a focus on the protection of rights of
victims of trafficking"

Annual Report

Link: http://www.stopkorrupsionit.al/

Link: www.transparancy.org/cpi2014/results

**Description**

|Date|S o u r c e|Description|
|---|---|---|
|15 April 2015|Robert Chenciner|F i n a l Report|
|2014|Tjeter Vizion, AssistiMPACT (EU funded website)|Project title: Improvement of identification referral and p r o t e c tion of victims of trafficking through the activities of Mobile Unit,|
|24 June 2014|World Vision|New smartphone app, hotline make reporting human trafficking possible for more Albanians|
|27 March 2015|Qendra sociale " Vatra" / P s y cho-Social Centre “Vatra”|Netzkraft Movement: Topics – Women's policy / social policy / disabled persons / aid organisation|
|07 January 15|Institute for Democracy a n d Mediation (IDM)|Police Integrity and Corruption in Albania|
|30 April 2014|Immigration and R e fugee Board of Canada|Responses to Information Requests: Albania - Domestic violence, including legislation, state protection and support services available to victims|
|12 April 2015|Radio Free Europe R a dio Liberty|How Long Can You Keep A Secret? For Kosovo's Wartime Rape Victims, The Answer Is: Maybe Forever|
|2006|International Migration Outlook|PART III International Migrant Remittances and their Role in Development|
|10 October 13|Office for Democratic I n s titutions and Human Rights|Albania, Parliamentary Elections, 23 June 2013 Final R eport|
|11 June 2007|Council of the European U n ion|2807th Justice and Home affairs Council meeting: 12 and 13 June 2007 - International multi-criminal mafia activity: Council conclusions setting EU priorities for fight against organized crime based on the 2007 organised crime threat assessment|


-----

|7 September 1999|The Guardian - UK n e w s|Albanian mafia targets Britain|
|---|---|---|
|10 March 13|There Must be Justice|S H A P E O F THE ALBANIAN ORGANIZED CRIME: Albanian Mafia Clan Keljmendi List|
|16 October 2012|International Business T i m e s|Tip Of The Iceberg: French Police Arrest Albanian Heroin Traffickers, But Balkan Criminal Gangs Tighten Grip Across Europe|
|10 January 2013|Digital Journal|O rganised Albanian crime destabilising Greece|
|16 October 2013|Osservatorio Balcani e C a u c aso - Italian journal|The Albanian mafia under investigation|
|11 December 2013|Independent Balkan N e w s A gency|Clashes between government and opposition on the figures of criminality in Albania|
|23 June 2014|The World Post|P o lice Destroy Over 40 Tons Of Marijuana In Lawless Albanian Village|
|16 June 2014|Daily Mail Online|A l b anian drug dealers torched £3.bn of cannabis in Lazarat to destroy evidence|
|27 April 2011|Haaretz - leading Israeli n e wspaper, via Underground Serbian Cafe|Israeli sex trafficker linked to the Albanian mafia sentenced to 18 years in Russia|
|01 July 2009|South Wales Argus|J a i l f o r Newport sex traffickers who sold woman for £2000|
|11 April 2012|The Independent|A lb a nian murder suspect arrested|
|27 June 2011|Refworld|2011 Trafficking in Persons Report: Albania (Tier 2), Country narratives|
|04 June 2008|Refworld|Trafficking in Persons Report 2008 – Albania (Tier 2 Watch list)|
|19 June 2013|Refworld|2013 Trafficking in Persons (TIP) Report: Albania (Tier 2, Watch List), Country narratives|
|19 June 2014|US Department of State|T r a f f ic k i n g in Persons Report 2014 Albania|
|27 February 2014|US Department of State|2 0 1 3 H u m an Rights Reports: Albania|
|2004|International Centre for Minority Studies and Intercultural Relations (IMIR)|The Kanun in present day Albania, Kosovo, and Montenegro|
|29 April 2012|Violence is not our C u lture|Albania: Virginity pressures bring women to the operating table|
|18 September 2014|Balkan Insight|A lbanians See Police as Corrupt, Surveys Say|
|25 March 2015|Institute for Democracy a n d Mediation: OSCE Network|Representative Profile|
|19 April 2013|US Department of State|C o u n t r y R e ports on Human Rights Practices fir 2012: Albania|
|2 January 2012|Regional Anti-Corruption I n i t i a t ive: Southeast European Times|In Albania, an underfunded healthcare system leads t o b r i b e r y|
|4 December 2014|Albania by Europe-cities|H e a l t h c a r e in Albania (www.europe-cities.com)|
|2006|World Health Organisation (WHO) / Ministry of Health Albania|WHO-AIMS Report on Mental Health system in Albania|
|24 September 2013|Travel.state.gov / US - U S C o n s ular information for travellers|Medical facilities and health information|


-----

**Country Documents before the Upper Tribunal:**

**Description**

**Date** **_Source_**

**Undated**

_International_ Reintegrating Albanian Victims of Human Trafficking,

**Undated** _Organisation for Migration (IOM)_ Package Information

_International_ Information Sheet

**Undated** _Organisation for Migration (IOM)_

_International_ Victim of Trafficking: Interview Assessment Form

**Undated** _Organisation for Migration (IOM)_

**2011**

_Ministry of Inferior:_ Standard Operating Procedures for the Identification

**2011** _Office of the National Coordinator on_ and Referral of Victims of Trafficking and Potential

_Combating Trafficking Persons_ Victims of Trafficking

_WAVE Report_ Albania extract

**2011**

**2012**

**12** _SIT Graduate Institute /_ Unlocking the Roots of Stigma Towards Victims of
**February 2012** _SIT Study Abroad: SIT Digital_ Trafficking in Albania

_Collections_

**2013**

_European Scientific_ Trafficking in Human Beings: Paradigms of a

**February 2013** _Journal (Vol. 9, No. 4 ISSN: 1857-7881)_ Successful Reintegration into Society (Albanian Case)

**1** _UK Home Office_ Operational Guidance Note Albania
**May 2013**

**2014**

_OSCE Office for_ Guiding Principles on Human Rights in the Return of

**2014** _Democratic Institutions and Human_ Trafficked Persons

_Rights (ODIHR)_

**29** _Committee of the_ Report submitted by the Albanian authorities on
**January 2014** _Parties to the Council of Europe_ measures taken to comply Committee of the Parties

_Convention on Action against_ Recommendation CP (2012) 1 on the implementation
_Trafficking in Human Beings_ of the Council of Europe Convention on Action against

Trafficking in Human Beings

**21** _ABC News            Albanian Girls Trafficked For Sex, Albanian Girls_
**May 2014** Kidnapped, Devoured Into a World of Prostitution

**16** _Net Hope_ Helping Albanians Report Trafficking and Save Lives

|Date|S o u r c e|Description|
|---|---|---|
|Undated|International Reintegrating Albanian Victims of Human Trafficking, O rganisation for Migration (IOM) P a c kage Information||
|Undated|||
|Undated|International O rganisation for Migration (IOM)|Information Sheet|
|Undated|International O rganisation for Migration (IOM)|Victim of Trafficking: Interview Assessment Form|
|2011|Ministry of Inferior: Standard Operating Procedures for the Identification Office of the National Coordinator on and Referral of Victims of Trafficking and Potential Combating Trafficking Persons V i ctims of Trafficking||
|2011|||
|2011|WAVE Report|A lbania extract|
|2012|SIT Graduate Institute / Unlocking the Roots of Stigma Towards Victims of S I T S t u dy Abroad: SIT Digital Trafficking in Albania Collections||
|12 February 2012|||
|2013|European Scientific Trafficking in Human Beings: Paradigms of a J o u r n a l (Vol. 9, No. 4 ISSN: 1857-7881) S u c c e s s f u l Reintegration into Society (Albanian Case)||
|February 2013|||
|1 May 2013|UK Home Office|O p erational Guidance Note Albania|
|2014|OSCE Office for Guiding Principles on Human Rights in the Return of Democratic Institutions and Human Trafficked Persons Rights (ODIHR)||
|2014|||
|29 January 2014|Committee of the P a r t i e s to the Council of Europe Convention on Action against Trafficking in Human Beings|Report submitted by the Albanian authorities on measures taken to comply Committee of the Parties Recommendation CP (2012) 1 on the implementation of the Council of Europe Convention on Action against Trafficking in Human Beings|
|21 May 2014|ABC News|Albanian Girls Trafficked For Sex, Albanian Girls Kidnapped, Devoured Into a World of Prostitution|


-----

|June 2014|Col2|Col3|
|---|---|---|
|19 June 2014|US Department of State|T r a f f i c k i n g in Persons Report 2014 Albania|
|20 June 2014|Embassy of the United S t ates Tirana, Albania|Time to End the Shame of Modern Slavery in Albania|
|17 July 2014|UK Home Office|C o u ntry Information and Guidance Albania - Trafficking|
|19 September 14|Home Office|Country Information and Guidance - Albania: Trafficking|
|26 September 14|Mary Ward Loreto F o u n d ation|Albania Hope, United Religious Against Trafficking (URAT) - 3 month report (September 2013 – March 2014)|
|30 September 2014|National Crime Agency ( N C A )|Strategic Assessment: The Nature & Scale of Human Trafficking in 2013|
|October 2014|European Commission|A l b a n ia P r ogress Report, Enlargement Strategy|
|2015|British Embassy Tirana L e t t e r : A l b ania: Trafficking: National Reception Centre / IOM||
|19 February 2015|||
|25 February 2015|Amnesty International|A m n e s t y International Report 2014/15 Albania|
|March 2015|Foreign & C o m monwealth Office|Human Rights & Democracy: The 2014 Foreign & Commonwealth Office Report|
|March 2015|Women Against V i o l ence Europe (WAVE)|WAVE Report 2014: Specialized Women's Support Services and New Tools for Combating Gender-based Violence in Europe [Country Profile - Albania]|
|26 March 2015|International O r g anisation for Migration (IOM)|Email and Written Statement on Reintegrating A lb a nian Victims of Human Trafficking Project|
|22 April 2015|International O r g anisation for Migration (IOM)|Emails and Additional Evidence (including: R e i ntegrating Albanian Victims of Human Trafficking November 2013 – April 2015; European Commission/IOM, coordinated approach for the reintegration of Victims of Trafficking (CARE); IOM information on CARE; IOM, Counter Trafficking; and Gewaltfreileben on CARE.|


1At the time of the UNP report in January 2015 this equated to approximately €70

2page 158

3De Waal, C in Pichler, R ed. (2014) Legacy and Change: Albanian Transformation from Multidisciplinary
_Perspectives at 123_

4Institute for Democracy and Mediation (2015) Police Integrity and Corruption in Albania

5Paragraph 212 of AM & BM

6        ibid, paragraph 63

7See for instance paragraph 156

8See for instance Lord Hope of Craighead at 47.


-----

9Clinical Outcomes of Routine Evaluation (CORE), Beck Anxiety Inventory, Beck Depression Inventory
(II), Trauma Symptom Inventory and the Beck Suicide Scales

10See for instance paragraph 3.7.1 of the report related to the first appellant

11UK Signed this on the 23 March 2007, ratified it on the 17 December 2008 and it came into force in the
UK on the 1 April 2009

12As defined by the American Psychiatric Association (DSM-V)

13Dr Agnew-Davies cites research by Herman (1992), Van der Volk & Fisler (1995), Jones et al (2001)
and Mechanic (2004)

**End of Document**


-----

