# R v AFU [2023] EWCA Crim 23

Court of Appeal, Criminal Division

Carr LJ, McGowan and Goose JJ

20 January 2023Judgment

**Benjamin Douglas-Jones KC (instructed by Philippa Southwell of Birds Solicitors) for the Appellant**

**Andrew Johnson (instructed by the Crown Prosecution Service) for the Respondent**

Hearing date : 19 December 2022

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

This judgment was handed down remotely at 9.45am on Friday 20 January 2023 by circulation to the parties or their
representatives by e-mail and by release to the National Archives.

.............................

**Lady Justice Carr :**

**Anonymity**

1. We make an anonymity order in this case in order to protect the interests of the proper administration of
justice. We bear in mind that the normal rule is open justice, but an anonymity order on the facts of the
[present case is strictly necessary, pursuant to the principles identified in R v AAD and others [2022] EWCA](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)
_[Crim 106; [2022] 1 WLR 4042(“AAD”) at [3] and [4] and summarised in Human Trafficking and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64PD-GP13-CGX8-0098-00000-00&context=1519360)_ **_Modern_**
**_Slavery Law and Practice_** (2nd ed) (at 8.103-8.108). The risk to the applicant of being re-trafficked for
criminal exploitation in the United Kingdom (“UK”) is real. Such an order is also consistent with (and so
does not risk undermining) anonymity orders made in respect of the applicant in the First-Tier Tribunal
(Immigration and Asylum Chamber).

**Introduction**

2. We have before us an application for leave to appeal against conviction, together with an associated
application for an extension of time (of 1,872 days). Both applications have been referred to the full court
by the Registrar.

3. The applicant, who is Vietnamese, is now 28 years old. During the course of his trial in October 2016
before HHJ Burgess (“the Judge”) sitting in the Crown Court at Nottingham, he pleaded guilty on rearraignment to a single count of conspiracy to produce a controlled Class B drug (cannabis) contrary to s.
1(1) of the Criminal Law Act 1977.

4. It is said that the applicant committed the offence against a background of being trafficked (or
smuggled) into the UK. Once in the UK, he was further trafficked, and subjected to exploitation involving
forced labour. This trafficking and exploitation compelled him to commit the offence, having left him with no
realistic alternative but to act as he did.


-----

5. The application is brought on two grounds, in summary as follows:

i) First, it is submitted that the applicant was not advised adequately, or at all, as to the availability of his
defence under s. 45 of the Modern Slavery Act 2015 (“s. 45”) (“the Act”). It is said that the extreme nature
and full circumstances of the trafficking and compulsion operating on the applicant only emerged from a
conclusive grounds decision made by the Competent Authority on 5 March 2018 (“the CG decision”), as
confirmed by the findings of First-Tier Tribunal Judge Rastogi (sitting in the Asylum and Immigration
Chamber) (“the FTT Judge”) promulgated on 5 January 2021 (“the FTT decision”). A s. 45 defence would,
it is argued, quite probably have succeeded. The conviction is therefore unsafe;

ii) Further or alternatively, the prosecution would, or might well, not have maintained the prosecution.
There were multiple failures on the part of the authorities in identifying the applicant as a victim of
trafficking (“VOT”) and reviewing his prosecution. The prosecution is said to have been an abuse of
process such as to render the conviction unsafe.

6. The application arises in the context of multiple failings on the part of the police and prosecution
authorities in 2016 to discharge their obligations towards the applicant as an actual or potential VOT. It is to
be hoped that such failures are not prevalent nowadays, given the increased awareness of the challenges
and difficulties facing VOTs and the authorities' obligations towards them. However in this case we are
required, amongst other things, to consider whether or not, despite the applicant's guilty plea, his
conviction is unsafe for abuse of process and, in this context, the very recent guidance of the special court
constituted for the purpose of the decision in AAD.

**The facts**

7. At 10.55am on 26 April 2016 police attended 29 Irving Place, Blackburn and executed a warrant under
s. 23 of the Misuse of Drugs Act 1971. The applicant, then aged 21 years, was present when they arrived.
A substantial cannabis production farm was discovered: 280 plants in various stages of growth; lamps;
heaters; fans and a hydroponic growing infrastructure. The electricity meter had been bypassed and
electricity abstracted.

8. In his first police interview under caution on 25 August 2016, the applicant relied on a prepared
statement:

“I arranged to come over to England with a male in Vietnam. I was promised a job when I arrived and I
have been here for around four months. Upon my arrival, I was taken to an unknown house and provided
with food whilst I waited to be allocated to my job. I was unaware of what the job entailed and was keen to
start employment. I was then transported to the address where I was arrested today. When I arrived, I was
given instructions to water the plants. I was unaware of what the plants were and I did not know they were
illegal until I was arrested today. When I arrived at the property, it was set up as it is today and I had no
involvement. I am in fact the victim of this crime and I have been exploited, I have not made any income
from the cultivation of cannabis. This is all I have to say at this stage”.

9. The applicant then answered “no comment” to all further questions.

**The proceedings and sentence**

10. The applicant pleaded not guilty and the matter proceeded to trial, where the applicant appeared
alongside seven co-defendants. He was represented by Mr Robert Wyn-Jones (“Counsel”). On the sixth
day of trial he pleaded guilty on the following basis:

“I was brought to this country in December 2015. I was placed in a house until another house became
available for me to work in. Once placed in the second house I was told to water the plants. Before I came
to the UK I did not know that I would be told to grow cannabis. At first I did not think I had a choice but to
do what I was told. I now accept I could have done more to get away”.

11. He signed and dated the written basis of plea document, as well as the following endorsement:


-----

“1. I…have decided to plead guilty to the allegation of conspiracy to produce cannabis that I face at
Nottingham Crown Court.

2. I do this because I am guilty of this allegation.

3. I have not been promised what my sentence will be.”

12. In each case it was confirmed that the declarations (in English) had been translated for, and fully
understood by, the applicant.

13. At the sentencing hearing, the prosecution contended that the applicant was a gardener with a
significant level of involvement, relying on his degree of contact with others and assistance in the
operation. In relation to the applicant's basis of plea, prosecution counsel stated:

“…to the extent it may be submitted that he was under some form of almost duress -- to use that inelegant
phrase -- we would reject that, your Honour, on the basis that he is seen on a number of occasions on the
CCTV. On one occasion, walking around Wilkinson's store and then within the Lemongrass store. On no
occasion does he appear to be under any sort of duress or acting in any way that might be considered out
of the normal. He was a straightforward and willing participant in this conspiracy”.

14. By way of general overview the Judge said this:

“Between 2014 and 26 April 2016 a business was operating. The business was to produce cannabis on a
very large scale. It was highly profitable. Large sums of money were invested in premises, equipment and
manpower. This business operation was run from Chesterfield, though in the main the production was
taking place in Blackburn in Lancashire…Seizures of cropped cannabis either on 27 April or earlier were in
the region of twenty kilos. It was plain that tens of thousands of pounds worth of cannabis was being
moved around the country in suitcases and I'm quite satisfied that a significant proportion of that went to
Scotland…Once a gardener was installed in one of the farm houses, they had to be instructed in the best
way to grow the drug. Detailed written instructions in feeding and watering and plant maintenance were
provided. The farm workers had to be fed. They were all Vietnamese nationals and their preference was for
Vietnamese food…I'm quite satisfied that the general conspiracy was an operation that was not only
capable of producing industrial quantities of cannabis for commercial use, it did produce such quantities.”

15. When sentencing the applicant specifically, the Judge referred to his age and the circumstances of his
arrest when 280 cannabis plants were seized. His telephone records showed that he had been in contact
with other conspirators. He was seen in Chesterfield on 18 and 19 December 2015 loading supplies into a
taxi. He was telephoned by one of the conspirators to alert him to the deliveries. The Judge went on:

“The prosecution also claim that your role was significant and they say that you must have been aware of
the wider conspiracy. You say that you were trafficked to this country and told to fetch and carry. You
arrived in this country on 15 December. Therefore the time that you were involved in the conspiracy must
be limited by that. You accept you were working as a gardener.

Again it is argued on your part that because of your limited knowledge of the wider conspiracy I should look
at a lower category and a lesser role. I remind myself that you are still only twenty-one years old. There
may be some force in the submission that is made on your behalf by Mr Wyn-Jones. However, in the
context of the case as a whole, my starting point cannot be lower than thirty months' imprisonment.”

16. The Judge addressed the question of credit for the applicant's guilty plea as follows:

“I said I would come back to the question of the timing of your plea. We had quite a lot of discussion about
it and how much credit you should get.

It was entered at the conclusion of the prosecution opening. However, there was a real problem getting you
to see a legal adviser. Not only was there a change of representation which was not your fault, but you
were also moved repeatedly through the prison estate so it became impossible for your legal advisers to
visit you. I am told by Mr Wyn-Jones that the first opportunity he had properly to give you advice was right
at the beginning of the trial. I am prepared to accept that.


-----

Rather ambitiously, he asks for full credit. But given your denials to the police, I am not prepared to give
you that much. But in the very unusual circumstances of your case, I am prepared to give you 25%. So, I
reduce the sentence in your case to 22 months' imprisonment.”

**Fresh evidence and subsequent events**

17. The applicant seeks leave pursuant to s. 23 of the Criminal Appeal Act 1968 to introduce fresh
evidence as follows:

i) The Competent Authority's Reasonable Grounds decision dated 8 March 2017 and the CG decision;

ii) The Home Office Rule 35(3) Detention and Services Order 09/2016 (“Rule 35(3)”) report dated 17
October 2017;

iii) The report of Dr Utpaul Bose (“Dr Bose”), consultant psychiatrist, dated 26 October 2017;

iv) The Home Office Rule 35(3) report of 20 February 2020 and Home Office response dated 24 February
2020;

v) Report of Dr Nuwan Galappathie (“Dr Galappathie”), consultant psychiatrist, dated 8 June 2020;

vi) The applicant's witness statement dated 6 August 2020 prepared for the hearing before the FTT Judge;

vii) The FTT decision.

18. All of this evidence post-dates the applicant's conviction. We entertained the evidence for the purpose
of the appeal hearing de bene esse. It reveals the following broad chronology of events, set in the context
of the applicant's account which the FTT Judge went on to accept in the FTT decision.

_The applicant's account of events leading up to his arrival in the UK as presented to the FTT Judge_

19. The applicant grew up in a rural village in Ha Tinh province, central Vietnam. He lived with his mother.
His father was often absent because, according to the applicant's mother, he was a gambler. He accrued
significant debt as a result. The applicant's parents would argue about money. In August 2015, the
applicant's mother was kidnapped. The applicant was in the house at the time, but managed to escape.
Afraid that the traffickers would find him, the applicant moved to Nghean Province, approximately 50
kilometres from his village. He travelled to the City of Vinh. A month later, he was kidnapped from the
street by the traffickers who had taken his mother. The applicant was then reunited with his mother. She
told him that she was being forced into prostitution, that the traffickers were very dangerous and that he
should obey their instructions. The applicant was held captive by these traffickers for several weeks. He
was threatened, beaten and told that he had to work to pay off his father's debt. He was then flown to
Russia, held for another two to three weeks before being trafficked through several European countries. In
France, he was stowed in a lorry and transferred to the UK. The applicant claimed to have entered the UK
in December 2015.

_The applicant's account of events leading up to his arrest as presented to the FTT Judge_

20. On arrival, he said that he was taken by his traffickers and held captive for several months, and
threatened and beaten. He was then forced to work in a cannabis house, where he remained until his
arrest on 26 April 2016.

_Events following the applicant's arrest on 26 April 2016 up to the CG decision_

21. On 6 May 2016, the applicant was referred to the National Referral Mechanism (“NRM”) by Blackburn
and Darwen Children's Services. On 13 May 2016, the Home Office found that there were reasonable
grounds to believe the applicant was a VOT.

22. On his account, very shortly thereafter, the applicant was then re-trafficked. While living in a foster
home in Burnley, he was kidnapped off the street, beaten and taken to another cannabis house. The
applicant was then taken to a third cannabis house. He tried to run away but was caught. His traffickers
had a gun and threatened to kill him if he tried to escape again


-----

23. Following the applicant's second arrest on 22 July 2016 (arising out of his involvement in the second
cannabis farm), he was referred to the NRM for a conclusive grounds decision to be made. During this
process, he was age-assessed and found to be an adult.

24. On 25 August 2016, the applicant was interviewed under caution. As set out above, his trial
commenced in October 2016, during the course of which he pleaded guilty. He was sentenced in
December 2016.

25. On 18 January 2017, the applicant was served with a deportation decision by the Home Office (“the
deportation decision”).

26. On 8 March 2017, the Home Office concluded that there were reasonable grounds to believe that the
applicant had been the victim of human trafficking.

27. On 25 September 2017, the applicant was interviewed regarding his asylum claim and trafficking
experiences.

28. On 17 October 2017, the Home Office concluded that the applicant may have been a victim of torture,
having a “large scar consistent with the account of torture at the hands of human traffickers”.

29. On 18 and 19 October 2017, the applicant was assessed by Dr Bose who concluded in a report dated
26 October 2017 that the applicant had problems with depressed mood and seemed to be suffering from
post-traumatic stress disorder (“PTSD”). Dr Bose stated that his mental health condition “… has been
severely caused and aggravated by the human trafficking incident(s)”. Dr Bose added in his report that the
applicant “presents as a vulnerable person and this could easily be identified when he is deported to
Vietnam … . His returning to the place where he was originally abducted is likely to cause a re-ignition of
the traumatic experience of when he was first abducted in Vietnam. His concerns are that he is very likely
to be abducted again by the gang who have abducted him twice before, and these fears and anxieties are
likely to fuel an increase in his PTSD symptomatology”. According to Dr Bose, the applicant also reported
he was at risk of suicide if returned to Vietnam.

30. On 30 November 2017, the applicant was interviewed in relation to his asylum and trafficking-based
claims.

31. Between October 2017 and January 2018, the applicant sought permission to seek judicial review of
the decision to detain him. Amongst other things, he questioned the delay in processing his claim through
the NRM, as well as the Home Office's alleged failures to report his case to the police and/or the Crown
Prosecution Service (“CPS”).

32. On 4 January 2018, the applicant's solicitors emailed the Salvation Army with concerns that the
Applicant had been placed in accommodation in Bradford, close to the Blackburn location where he was
trafficked. He went missing and, according to the applicant, was kidnapped and taken to a cannabis
warehouse. When he refused to tend the plants, he was threatened with a knife. The traffickers then used
the knife to cut his neck. He has a scar from this incident.

33. The CG decision was made on 5 March 2018.

_Events between the CG decision and the FTT decision_

34. On 29 March 2018 the applicant's application for asylum was refused for non-compliance, due to
failures to report. The applicant was listed as an absconder.

35. On 8 November 2018, the applicant's claim for permission to apply for judicial review of the deportation
decision was refused. The reasons given were that the applicant had been missing for many months,
despite efforts to locate him and there did not appear to be any prospect of the claim being pursued further.

36. On 26 September 2019, the Home Office decided not to allow the applicant discretionary leave to
remain following the CG decision. The Home Office concluded “that there is no realistic risk” of the
applicant being re-trafficked or becoming a victim of modern slavery again if he were to return to Vietnam


-----

because, according to the Home Office, the “exploitation took place in the UK after he had departed from
Vietnam”.

37. On 24 October 2019, the Home Office wrote to the applicant, noting his failure to report since 17
January 2018 and asking him to make contact.

38. On 31 October 2019, the Home Office issued a Deportation Order (“the Deportation Order”).

39. According to the applicant, during this time he was being held captive by his traffickers. He was taken
to another cannabis house in Scotland. On 5 December 2019, police searched this property and arrested
the applicant. He was taken to a detention centre. There, he told a duty solicitor that he had been
trafficked.

40. On 6 February 2020, the applicant claimed asylum again. A NRM referral was sought to establish his
trafficking status. The applicant's solicitors stated that there was “considerable mitigation for his absence
from the reporting sessions”.

41. On 24 February 2020, the Home Office responded to another Rule 35(3) report from 20 February 2020
that concluded the applicant may have been a victim of torture. The Home Office referred to the medical
practitioner's statement, which noted that the applicant:

“…[c]laims to have been kidnapped off the streets by an unknown group of men. He states he was forced
to work in a cannabis farm which he didn't want to do as it was illegal.

He initially refused to do the work but they put a knife against him[;] stated he would be killed if he didn't
start working.

He was locked up, not allowed to go out and was forced to work long hours. Living conditions were poor
and he was given minimal to eat and drink. The perpetrators would punch him repeatedly and cut him with
knives. If the condition of the cannabis was not good enough, they would burn him with cigarettes. He
worked for nearly 2 years before he was arrested”.

42. In the Rule 35(3) report it was noted there were two scars on the applicant's body consistent with his
story: a scar to the neck (where he was cut with a knife) and a scar to his right forearm (where he was
burnt with a cigarette).

43. The Home Office acknowledged that the evidence of torture met the guidance set out in the Detention
Services Order 9/2016 and Level 2 of the Adults at Risk in Immigration Detention Policy. However, the
Home Office decided to maintain the applicant's detention. It was considered that the negative factors
outweighed the risks and indicators of vulnerability.

44. On 2 March 2020 the Home Office refused the applicant's human rights claim and refused to revoke
the Deportation Order. The Home Office concluded:

“…it may be accepted that you are a victim of trafficking and modern slavery[;] however, it is considered
that you are safe on return to Vietnam where your parents and connections reside”.

45. On 7 May 2020, the applicant was assessed by Dr Galappathie who found the applicant to be suffering
from recurrent depressive disorder with a range of anxiety symptoms. He presented as an individual with
ongoing severe depression. Dr Galappathie also found that the applicant was suffering from severe PTSD
and that his symptoms had worsened since his assessment by Dr Bose. Dr Galappathie concluded that the
applicant's symptoms were consistent with his biographical account and that he presented with a
significant number of risk factors for self-harm and suicide. In his opinion, if the applicant was to be
returned to Vietnam he would be at a high risk of self-harm and suicide.

46. On 12 May 2020, the Competent Authority decided that there were reasonable grounds to conclude
that the applicant was a victim of modern slavery.

47. On 17 June 2020, the applicant appealed the Home Office's decision of 2 March 2020. The grounds of
appeal claimed that the applicant was a refugee and would face a real risk of harm if returned to Vietnam.


-----

_The hearing before the FTT Judge_

48. The appeal came before the FTT Judge at a hearing in which the applicant gave oral evidence,
alongside his witness statement of 6 August 2020; his account was then tested in cross-examination. In his
written statement he said this of his time at the cannabis house where he was found in April 2016:

“64. When I arrived there I was told how to look after the plants. They taught me when to turn on the lights
and how to water the plants. My job was as a gardener and I did what I was told to do.

65. The door was always locked and there was no way to escape. I was very scared and intimidated. They
constantly threatened me so I did what I was told, they did not beat me on this occasion.

66. I was given limited amounts of food and drink and I was not paid for this work. The traffickers did not
tell me what had happened to my mum and dad and they did not tell me how long I was supposed to be
there for.

67. I was at the Cannabis House for approximately one month when I was arrested.”

49. Of his experience leading up to and at trial and sentence in October/December 2016 the applicant said
that his solicitor never advised him of his potential defence as a victim of trafficking. He never met a
solicitor face to face, nor even spoke to a solicitor on the telephone. He was very worried and anxious and
did not know what was going to happen. He went on:

“88. On the morning of my trial I was brought to Court and I met my barrister for the first time. I did not
receive any other legal advice before the hearing.

89. I only spoke to him briefly. I didn't have time to tell him everything that had happened to me. He just
said that he had prepared the file and I must plead guilty.

90. He did not advise me of a potential defence as a victim of trafficking.

91. I didn't know what to say. He didn't give me an opportunity to do anything else apart from what he told
me.

92. He didn't say I could plead not guilty and I was not able to defend myself. He told [me] that my
sentence would not be very long if I pleaded guilty.

93. It was a really frightening experience and I felt very intimidated. I had no guidance about what I was
supposed to say or do. I knew that I had committed the crime because I was forced to by the traffickers. I
was scared that if I escaped or did not do as I was told, they would kill me.

94. I was sentenced to 22 months in prison. I didn't really understand what was going on or how this
happened. This did not seem like a short sentence to me.

95. I did not speak to my solicitor or my barrister after the trial.

96. Everyone else had their lawyer with them and had proper legal advice but I didn't.

97. I knew that it was not fair and I was really upset by this.”

50. In his oral evidence to the FTT Judge, he continued to maintain that he was only involved in the
cannabis production as he was trafficked into it. He accepted that he had a mobile telephone, since the
traffickers gave him one so that he could receive instructions.

51. The FTT Judge allowed the applicant's appeal against the decision not to revoke deportation. She
found that the applicant was a VOT and a refugee. In the course of her analysis of the evidence, she
commented as follows:

“59. I also have regard to the appellant's guilty plea. In pleading guilty he accepted the prosecution case
against him…He has stated in his witness statement that he felt intimidated into pleading guilty and was
told he would receive a short sentence. He is now see[k]ing to challenge his conviction.

60. There is significant reference in the sentencing remarks to the problems the appellant had in accessing
legal advice He received advice on the day of the trial This is not ideal for offences of such severity


-----

especially for a young person with no previous experiences of the criminal justice system. It was clear he
raised at that stage the fact that he was trafficked in and told to fetch and carry. Nevertheless his guilty
plea was accepted”.

52. The FTT Judge concluded that:

“80. Standing back and looking at the evidence in the round, I find the totality of the evidence over a
prolonged period consistently points to the appellant being a [VOT] as he has claimed to be…The main
evidence pointing away from his account being true is the fact and circumstances of his conviction. That is
a significant indicator contradicting the appellant's case and in many other cases, may be decisive.
However, there is enough doubt in my mind that the situation here is more complex. The sentencing
remarks corroborate the appellant's account about the difficulties he had accessing lawyers. Although he
pleaded guilty, the nature of his role within the conspiracy as described in the sentencing remarks, is not
wholly inconsistent with his account that, at the time, he was under the control of traffickers….

81. Therefore for all those reasons, and reminding myself of the lower burden of proof in protection claims,
I find as fact that the appellant was trafficked out of Vietnam to Russia and then within and out of Russia
and through Europe until he arrived in the UK in 2015 and then within the UK until his arrest on 26 April
2016; between mid May 2016 when he went missing from foster care till his arrest on 25 July 2016 and
again in mid-January 2018 to his arrest on 5 December 2019. I find as fact that he was taken forcibly from
Vinh City in Vietnam by traffickers because of a gambling debt owed by his father and whilst en route to the
UK he did not work but he was deprived of his liberty and he sustained beatings. In the UK I find that he
was required to work as a gardener in various cannabis factories and he was beaten, deprived of sufficient
food and of his liberty. His beatings included being cut to the neck with a knife and being burnt with a
cigarette to the arm and being assaulted to the head with a wooden post whilst in Russia. As a result of his
experiences I am satisfied that the appellant bears some scars of his experiences…and has developed
mental health problems in the form of depressive episodes and PTSD which have progressively worsened
with each re-trafficking episode and compounded by his period in prison and in immigration detention.
They are now classified as both being severe conditions. Finally, I am satisfied that the appellant is
unaware of the whereabouts of his parents in Vietnam and therefore it is reasonably likely that if returned
to Vietnam he will be doing so as a fairly young man without family support, who is a former [VOT] and who
suffers with mental health conditions as outlined and for which he has not yet received the appropriate
treatment to assist him to recover from his experiences ...

88. …I find that the appellant's case has features of virtually all of the factors listed at [2.4.8] of the April
2020 CPIN as increasing the risk of suffering abuse or re-trafficking. In addition, I find that the fact that the
appellant has already been re-trafficked on more than one occasion and this has compounded his mental
health problems from which he has not yet recovered. This places him at a more enhanced risk than
someone whose experiences of being trafficked are more limited …”.

**The circumstances surrounding the applicant's guilty plea**

53. As set out above, the applicant's evidence before the FTT was to the effect that he had been told by
his barrister to plead guilty and had not been advised of a potential defence of trafficking.

54. In a witness statement dated 3 January 2022 prepared for the purpose of this application, the applicant
elaborates on his time at the (first) cannabis house, stating that he was the only person at the property,
which he was not allowed to leave. He was provided with frozen food and had to sleep in the living room
with just a mattress and a blanket.

55. He goes on to state:

“I think I told the barrister that I was forced to come to the UK. I do not recall what else I told the barrister
about my situation. The barrister advised me to plead guilty and I entered a guilty plea. I do not recall why
the barrister advised me to plead guilty, but he said that the other defendants on the case pleaded guilty,
therefore, I also pleaded guilty… . I had one week to consider the evidence and see whether I would like to
plead guilty. Because the judge said if we enter guilty plea at that stage, we could get 10% credit. My


-----

barrister said I if want to plead guilty, he can ask whether I could get full credit of 25%. He said in his
opinion everyone in the case was guilty of the offence.”

[56. Counsel, in line with the procedure identified in R v McCook [2014] EWCA Crim 734; [2015] Crim LR](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5C0P-34W1-F0JY-C187-00000-00&context=1519360)
350, responded to the applicant's suggestion that he was never advised as to the availability of a s. 45
defence and told to plead guilty (and simply told that others had pleaded guilty). In doing so, Counsel
produced his contemporaneous manuscript notes, together with the applicant's signed basis of plea and
signed endorsement. He explained that on Monday 17 October 2016 he had asked the Judge for time to
take instructions, having not met the applicant before. The reason for that was that the prison service had
not been able to locate him.

57. The jury was selected at 12.17pm on the Monday and sent away until the Wednesday. Thereafter
Counsel's note states “S. 45 Modern Slavery Act 19-464”. (19-464 was a reference to the relevant section
in the then current edition of Archbold addressing s. 45.)

58. Counsel states that he had a s. 45 defence well in mind. The next day, Tuesday 18 October 2016, he
reminded the applicant of his first account to the police and went through the telephone evidence. He noted
to himself “But – Slavery”. He then took a full account from the applicant. Counsel says that this account is
completely different to the one now advanced by the applicant. The account given to Counsel at the time
was as follows:

i) The applicant lived rough, begging, from the age of 16, until the end of 2015;

ii) He then met a man, “Hung”, who invited him to come and work for him abroad where the applicant
would be fed and clothed and have a better life;

iii) He had heard of others going abroad, including girls who were forced into prostitution. He was scared
and worried that he would be asked to do something he did not want to do. However, he thought that Hung
was a good man;

iv) Hung gave him somewhere to stay in Saigon for two months. Hung wanted him “to taste the good life”;

v) Hung organised travel documents for the applicant, and travelled with him by plane to France in about
October 2015;

vi) On arrival they were picked up in a car and taken to a forest where they stayed in tents housing lots of
different nationalities, all guarded by European men. He stayed there for two months. He was sexually
assaulted by the guards more than once. He had to do what they told him to. He refused in the beginning
and was beaten up for this refusal. As a result, he had scars on his head. Eventually he gave in;

vii) One night, men drove him to a lorry park and put him in the back of a lorry with lots of boxes. After a
few hours or so, he was let out by a Vietnamese male who told him to get into his car. He was taken to an
address where he stayed for three months. He was fed and clothed as normal. He was told he owed
£20,000 for the trip and had to work to pay off the debt;

viii) About a month before his arrest he was taken to 29 Irving Place. Everything was in place for growing
cannabis. He was told to work on the plants. He was told that there were guards outside the address and
he would be killed if he ran away.

59. Counsel's notes then state “To Answer” and set out the evidence that the applicant would have to
address, particularly his access to telephones and his appearance at various locations on CCTV travelling
about with others. He says that he considered the evidence against the applicant. He then made notes
about the Lemongrass store and the applicant's connection with it.

60. On the following day, Wednesday 19 October 2016, Counsel says that he saw the applicant in
conference and went through the CCTV evidence. The applicant confirmed his identity in the footage for
various dates.

61. On Friday 21 October 2016, Counsel's notes at lunchtime read:

“D is considering pleading guilty. He will make his final decision on Monday am.”


-----

62. At 4pm, the applicant asked to see the CCTV footage again.

63. On Monday 24 October 2016, Counsel noted:

“D wants me to ask the Judge how much credit he will give D should he plead guilty today.”

64. The Judge gave an indication at 10.45am, following which the trial opening continued. Counsel noted
at 12.30pm:

“D tells me he intends to plead guilty. He signs endorsement and basis of plea.”

65. The applicant was re-arraigned and pleaded guilty at 2.30pm. At 3pm, Counsel noted:

“D wants to give police info about who was in charge of the operation. I explain to him that I will mention
this to prosecution counsel today.”

66. Counsel goes on to state:

“Over the course of a week and a day I took the Defendant through the evidence against him. I did
consider and explain the defence of **_modern slavery. I took him to the evidence that I advised may be_**
inconsistent with that defence. I advised him on credit for guilty plea. He made his own decision to plead
guilty having been properly advised. The account that he gives now about this life and journey to the UK is
completely different to the one he gave me. Importantly there was no mention at all of threats to his
parents. Plainly if he had told me that I would have factored that into my advice on the evidence. He told
me he hadn't seen his parents since he was 16. The account he gives of how I dealt with him is untrue.”

67. In an email dated 25 October 2021, the applicant's solicitor, Mr Rode of ABR Solicitors, agreed with
Counsel's comments.

68. In the light of a relevant factual dispute between the applicant and Counsel, both gave oral evidence
before us, the applicant using the services of an interpreter. We make our findings in relation to the events
surrounding the applicant's guilty plea later in this judgment.

**Grounds of appeal**

69. For the applicant, Mr Douglas-Jones KC contends that in this area of law, investigators and
prosecutors played a very significant role in permitting a false understanding of the law to become
prevalent. None of the very obvious indicia of trafficking were identified by the police or the prosecutors.
The police failings caused them to be in breach of their duty under s. 52 of the Act. The failure of
investigators and prosecutors to identity “classic Vietnamese trafficking paradigm indicators” caused them
to breach their international law obligations. In those circumstances, there should be no requirement on the
applicant to demonstrate that a s. 45 defence would quite probably have succeeded, and the conviction is
unsafe.

70. Further or alternatively, tailored to s. 45, it is submitted that the appropriate questions to pose
[(adopting the checklist identified in R v Dastjerdi [2011] EWCA Crim 365 (“Dastjerdi”) at [9] (“the Dastjerdi](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:528Y-VRD1-F0JY-C17B-00000-00&context=1519360)
checklist”)) are:

i) Should the applicant have been advised about the possibility of availing himself of a s. 45 defence? If so,

ii) Was he so advised?

iii) Was it open to the applicant, had he been so advised, to advance the defence?

iv) Was it (at least) quite probable that the applicant would have been able successfully to advance such a
defence? That is to say, could the prosecution have disproved any of the following to the criminal standard,
namely that:

a) He did the act because he was compelled to do it?; and

b) The compulsion was, or was part of, conduct which constitutes relevant exploitation, or the compulsion
was a direct consequence of the applicant being, or having been, a victim of relevant exploitation (i.e.
exploitation that was attributable to the exploited person being or having been a VOT)?; and


-----

c) A reasonable person in the same situation as the applicant and having the applicant's relevant
characteristics (age, sex and any physical or mental illness or disability) would have no realistic alternative
to doing that act?; and

d) It is likely that the prosecution could not have disproved one of those limbs to the criminal standard?

71. The answer to each question would be as follows:

i) This was “classically and obviously” a case where the applicant should have been advised about the
possibility of availing himself of a s. 45 defence;

ii) He was advised. However, the police prima facie breached their statutory duty to notify the Secretary of
State about a suspected VOT. The NRM process only concluded after the applicant's conviction. Those
representing the applicant had no opportunity to advise him that he had a meritorious s. 45 defence. It was
not possible for those representing him properly to advise him. Further, they were constrained from
exploring his possible defence through the constraints on conference and interview time;

iii) It was open to him, had he been so advised, to advance the defence;

iv) The applicant could clearly satisfy the evidential burden in relation to the three limbs of the defence.

72. Beyond this it is submitted, relying on R v LM and others [2010] EWCA 2327; [2011] 1 Cr App R 12 (“R
_v LM”), that, had the prosecution known at the point of charge or prosecution what is now known, the_
prosecution “would” or “might well” not have maintained the prosecution, rendering the conviction unsafe.
The prosecution was an abuse of process.

73. It is said in particular that, where the prosecution has failed to apply the relevant CPS Guidance on
prosecuting suspects who might be victims of human trafficking, the prosecution breaches the protections
under the international and regional instruments enshrined with that guidance and, as AAD makes clear,
such a prosecution may be an abuse of process. Any conviction following such failures will be unsafe, and
advice as to the merits cannot remedy that. A finding otherwise would i) undermine the principle that,
where it is unfair to try a defendant on the second limb of the test identified in R v Horseferry Magistrates
_Court (ex p Bennett)_ [1994] 1 AC 42, a prosecution should not be maintained and any conviction will be
unsafe; ii) remove the non-prosecution protection which applies by virtue of the relevant guidance; and iii)
violate the protections in international and regional instruments and Article 4 of the Convention of Human
Rights (“Article 4”).

74. This was a case where indicators of trafficking were clearly present. There was a failure on the part of
the prosecution to note that all three components (prima facie evidence of the purpose of the trafficking,
recruitment and exploitation) were present. The applicant was committing a cannabis offence
“paradigmatic of Vietnamese O[rganised]C[riminal]G[ang]s”. There was thus a failure to identify the
applicant and to apply the relevant CPS Guidance, including a failure to comply with any of its duties under
the three-stage test there identified. The positive duty to take operational measures to protect the applicant
was violated. Given what is now known about the applicant, this is a case where the prosecution would or
might well have been discontinued in the public interest. It was therefore an abuse of process. The
principle of finality does not apply where trafficking considerations have been overlooked.

**The Respondent's position**

75. Mr Johnson for the Respondent accepts that, on the basis of the FTT Judge's findings, the applicant
had a sound s. 45 defence which would “quite probably” have succeeded. The concession in the
applicant's basis of plea that he “could have done more to get away” has to be viewed in light of the
repeated trafficking found to have occurred by the FTT Judge.

76. However, it is said that the fact that a defence would “quite probably” have succeeded is insufficient for
the appeal to succeed. If the failure to advance arose out of the applicant's own fault, then the appeal
should not be allowed. This principally turns on whether the applicant was properly advised. If the applicant
was advised as to the availability of a s. 45 defence, then his appeal should fail. The fact that the applicant


-----

should have been referred by the police upon his first arrest does not mean that the applicant's
representatives were thereby prevented from properly advising him.

77. In short, the applicant was not compelled to enter a plea, but rather chose to do so. The facts do not
fall within the limited category of situations where an appeal founded on a guilty plea can succeed.

78. As for abuse of process, it is said that no abuse is made out. The initial charging decision
demonstrates that the prosecution was alive to the need to consider whether the defendants in the
proceedings were VOTs. It is accepted that his account in interview should have triggered a referral
through the NRM to the Competent Authority. But a referral was made very shortly afterwards by the
Children's Services in any event.

79. The Respondent submits that the fact that a s. 45 defence had a probability of success does not
render it inappropriate for the issue to be determined at trial. Decisions on disputed facts or evaluations of
facts are for the jury (see _AAD_ at [142(3)]); there would have been no impropriety in the prosecution
proceeding on the basis that this was a case where it was proper for the jury to evaluate the case with oral
evidence, rather than to proceed on the basis of a paper-based evaluation by a prosecutor.

80. In any event, the fact that the applicant's decision to enter a guilty plea, after being fully advised as to
the availability of a s. 45 defence, is relevant. There are good policy reasons why the principle of finality
exists. This was not a “no-fault” case. The applicant was advised that he could defend himself on the basis
of his alleged status as a VOT and chose not to do so. If a convicted offender in the position of the
applicant could succeed in arguing that proceedings amounted to an abuse of process in such
circumstances, the effect would be significantly to undermine the Boal test in respect of VOTs, which would
be an unsatisfactory state of affairs.

**Overview of the relevant legal principles**

_The state's duty to identify victims of trafficking and the defence under s. 45_

81. As confirmed in Rantsev v Russia and Cyprus [2010] (25965/04); [2010] 51 EHRR 1 (at [288]), Article
4 entails a procedural obligation to investigate situations of potential trafficking. The requirement to
investigate does not depend on a complaint: once the matter has come to the attention of the authorities,
they must act of their own motion. In order for the prosecution of an actual or potential VOT to respect the
freedoms guaranteed by Article 4, their early identification is of paramount importance (see for example
_VCL v United Kingdom (77587/12); AN v United Kingdom (74603/12) [2021] 73 EHRR 9 [2021] Crim LR_
586 (at [160])).

82. Further, the UK is party to both the 2000 Palermo Protocol and the 2005 Council of Europe
Convention on Action against Trafficking in Human Beings (“ECAT”), as well as the Convention. An
essential part of achieving the purposes of ECAT is the effective identification of victims (see article 10). To
this end the UK has established the NRM. First responders, such as the police or social workers, who
suspect that a person may be a victim of trafficking, refer the case to the Home Office, as the competent
authority under ECAT, for investigation. Whether or not a person is identified as a VOT is decided by
reference to the offence of trafficking in international law. It includes slavery and forced or compulsory
labour.

83. Article 26 of ECAT (“article 26”) provides:

“Each Party shall, in accordance with the basic principles of its legal system, provide for the possibility of
not imposing penalties on victims for their involvement in unlawful activities, to the extent that they have
been compelled to do so.”

84. On 6 April 2013, Directive 2011/36 of the European Parliament and of the Council of 5 April 2011 on
preventing and combating trafficking in human beings and protecting its victims (“the Directive”) came into
force in the UK. Article 8 (“article 8”) of the Directive provides:

“Non-prosecution or non-application of penalties to the victim


-----

Member States shall, in accordance with the basic principles of their legal systems, take the necessary
measures to ensure that competent national authorities are entitled not to prosecute or impose penalties
on victims of trafficking in human beings for their involvement in criminal activities which they have been
compelled to commit as a direct consequence of being subjected to [trafficking]…”

85. The UK provides protection for VOTs through s. 45, which came into force on 31 July 2015 and
applies to all (relevant) offences committed after that date. S. 45 provides materially:

“(1) A person is not guilty of an offence if:

(a) the person is aged 18 over at the time of the act which constitutes the offence.

(b) the person does that act because he is compelled to do it.

(c) the compulsion is attributable to slavery or to relevant exploitation, and

(d) a reasonable person in the same situation as the person and having the person's relevant
characteristics would have no realistic alternative to doing that act.

(2) A person may be compelled to do something by another person or by the person's circumstances.

(3) Compulsion is attributable to slavery or to relevant exploitation only if
(a) it is, or is part of, conduct which constitutes an offence under section 1 or conduct which constitutes
relevant exploitation, or

(b) it is a direct consequence of a person being, or having been, a victim of slavery or a victim of relevant
exploitation….

(5) For the purposes of this section
“relevant characteristics” means age, sex and any physical or mental illness or disability;

“relevant exploitation” is exploitation…that is attributable to the exploited person being, or having been, a
victim of human trafficking.”

86. S. 45 does not apply to offences in Schedule 4 of the Act (see s. 45(7)). Schedule 4 includes common
law offences, including kidnapping, manslaughter and murder, as well as many offences under the
_[Offences against the Person Act 1861,the Firearms Act 1968 and the Theft Act 1978.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9230-TWPY-Y18R-00000-00&context=1519360)_

87. It is for the defendant to raise evidence of each of the elements in s. 45(1), and for the prosecution to
disprove one or more of them to the criminal standard: see _R v MK; R v Gega [2018] EWCA Crim 667;_

[2019] QB 86 at [45].

88. Decisions of the Competent Authority are not admissible at trial, but are admissible on appeal when it
is contended that a person's trafficking status has been overlooked or inadequately considered (see _R v_
_Brecani [2021] EWCA Crim 731; [2021] 1 WLR 5851 at [40] and [41] and AAD at [79] to [89]). Whilst not_
binding, the decisions will usually be respected, unless there is good reason not to do so. However, there
may be cases where it is necessary for an applicant's account to be tested independently for the purposes
of safe resolution of the issues on appeal; for example where a finding of trafficking is based on
unsatisfactory evidence (see AAD at [108]).

89. Equally, a decision of a tribunal or court, where a finding of fact is made based on evidence, may be
admissible to assess the prospects of a defence succeeding or in the context of abuse of process
proceedings for reviewing the decision of a prosecutor (see _R v Sadighpour [2012] EWCA Crim 2669;_

[2013] 1 Cr App R 20 at [35] to [36]; R v Mateta [2013] EWCA Crim 1372; [2013] 2 Cr App R 35 at [23]).

90. The extent to which expert evidence can be of assistance when assessing an account of trafficking will
likely depend on the extent to which it relies on the accuracy of an individual's untested account of events:
see for example R v N; R v L [2012] EWCA Crim 189; [2013] QB 379(“R v N/L”) at [86(c)]; and R v VSJ et
_al [2017] EWCA Crim 36; [2017] 1 WLR 3153(“R v VSJ”) at [67]._

_Appeal against conviction on a guilty plea_


-----

91. The Court of Appeal's power to overturn a conviction is found in s. 2 of the Criminal Appeal Act 1968,
which reads:

“(1) Subject to the provisions of this Act, the Court of Appeal –

(a) shall allow an appeal against conviction if they think that the conviction is unsafe; and

(b) shall dismiss such an appeal in any other case.

(2) In the case of an appeal against conviction the Court shall, if they allow the appeal, quash the
conviction.

(3) An order of the Court of Appeal quashing a conviction shall… operate as a direction to the court of trial
to enter, instead of the record of conviction, a judgment and verdict of acquittal.”

92. The “sole obligation” of the court, therefore, is to determine whether the conviction is “unsafe”: see R v
_Graham [1997] 1 Cr App R 302 (at 309). A guilty plea does not deprive the court of jurisdiction to hear the_
appeal: see R v Lee [1984] 1 WLR 579(at 583).

93. However, the court should be cautious when overturning convictions following guilty pleas. As Lord
Hughes made clear in R v Asiedu _[[2014] EWCA Crim 567; [2014] 2 Cr App R 7 (“Asiedu”) at [19] to [25],](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5BVD-N401-F0JY-C1S4-00000-00&context=1519360)_
and [32], it will ordinarily be difficult to overturn a voluntary confession. The defendant, having made a
formal admission in open court that they are guilty of the offence, will not normally be permitted to change
their mind. The trial process is not to be treated as a “tactical game”.

94. Broadly, there are three categories of case in which a guilty plea may be vitiated, as summarised in R
_v Tredget_ _[[2022] EWCA Crim 108; [2022] 4 WLR 62(“Tredget”) at [154] to [180] and Archbold (2023 ed) at](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:64R9-80J3-CGX8-00NM-00000-00&context=1519360)_
7-43 to 7-46:

i) Cases where the guilty plea is vitiated. This can occur in several circumstances, including the appellant
being under the influence of controlled drugs when they entered their plea (R v Swain (1986) Crim LR
480); a plea compelled by an adverse or incorrect ruling as to the law (Asiedu); improper pressure (R v
_Nightingale_ _[[2013] EWCA Crim 405; [2013] 2 Cr App R 7); or incorrect legal advice that deprived the](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:584X-GG21-F0JY-C0H4-00000-00&context=1519360)_
defendant of a defence which quite probably would have succeeded such that a clear injustice has been
done (R v Boal [1992] QB 591(“Boal”));

ii) Cases where there is a legal obstacle to the defendant being tried. That will be the case where the
prosecution would be stayed on the grounds that it was offensive to justice to bring the defendant to trial.
Such cases are generally described, “conveniently if not entirely accurately”, as cases of “abuse of
process” (see Asiedu at [21]). As stated in R v Togher [2000] EWCA Crim 111; [2001] 1 Cr App R 33 at

[33], if it would be right to stop a prosecution on the basis that it was an abuse of process, an appellate
court would be most unlikely to conclude that, if there was a conviction despite this fact, the conviction
should not be set aside. In such cases, “by parity of reasoning, if the trial process should never have taken
place because it is offensive to justices, a conviction upon a guilty plea is as unsafe as one following trial”
(see Asiedu (at [21]);

iii) A small residual category of cases, where the admission made by the plea is a false one, because it is
established the defendant did not commit the offence (see _R v Verney [1909] 2 Cr App R 107 and_ _R v_
_Foster [1985] 1 QB 115)._

95. In this case, we are concerned with the first and second categories: that is, i) whether the applicant's
guilty plea was vitiated by inadequate legal advice, and/or ii) whether the proceedings were an abuse of
process.

_Inadequate Legal Advice_

96. Guilty pleas will be vitiated if erroneous advice was given that was so strong as to go to the heart of
the plea, such that it was not a true acknowledgement of guilt: R v Saik _[2004] EWCA Crim 2936; [2005]_
CLY 883 at [57].


-----

97. An appeal can also succeed if the plea is vitiated by erroneous legal advice or a failure to advise as to
a possible defence, even where the advice may not have been so fundamental as to have rendered the
plea a nullity. In this case, the effect of the advice must be to deprive the defendant of a defence which
would probably have succeeded: _Tredget_ at [158]; _R v Kakaei (Fouad)_ _[2021] EWCA Crim 503; [2021]_
Crim LR 1079 (“Kakaei”) at [67].

98. This test derives from Boal, where the court emphasised that in such situations a conviction should be
overturned only “exceptionally”, where “a clear injustice has been done” (at 599-600). This passage was
cited with approval in R v PK _[[2017] EWCA Crim 486; [2017] Crim LR 716 (“PK”) at [12]. The exceptionality](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5NHG-R6Y1-F0JY-C538-00000-00&context=1519360)_
of the defence was further emphasised in Tredget at [158] and R v PBL [2020] EWCA Crim 1445 at [23].

99. The _Dastjerdi_ checklist, applicable when determining whether a conviction following a guilty plea
should be overturned, was subsequently applied in PK at [13]. On the facts in this case, as set out above, it
requires:

“(1) That the applicant should have been advised about the possibility of availing himself of the [s. 45]
defence;

(2) That the applicant was not so advised;

(3) That, had [the applicant] been so advised, it was open to him to advance the defence;

(4) That the prospect that [the applicant] would have been able to advance such a defence were good.”

100. In the present case, it is contended that, while the applicant was informed of the possibility of raising
a s. 45 defence, he was not advised that the defence was meritorious.

101. In this regard, it is useful to compare two cases: R v S _[2020] EWCA Crim 765; [2020] 4 WLR 125and_
_R v V [2020] EWCA Crim 1355._

[102. In R v S, a conviction under the Misuse of Drugs Act 1971 was found to be unsafe. S entered a guilty](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:4ST8-9XT0-TWPY-Y0K9-00000-00&context=1519360)
plea after being advised that a defence under s. 45 would be unlikely to succeed, following a negative CG
decision. The evidence suggested that counsel had proceeded on the erroneous basis that the CG
decision was decisive (see [40]). Furthermore, S needed an interpreter, and may also have misunderstood
the importance of the CG decision (see [39]). For these reasons, in the highly unusual circumstances, the
conviction was regarded as unsafe.

103. The court in R v V distinguished R v S on three bases (at [36] to [40]): (i) the solicitor's advice as to
the availability of the s. 45 defence did not arise out of any misconception as to the importance of the
conclusive grounds decision in that case; (ii) the conclusive grounds decision in that case was wholly
lacking in any analysis of the evidence; (iii) there was a strong evidential basis on which to rebut the s. 45
defence. Because the potential for a s. 45 defence had been raised at the outset, and V was advised
realistically as to its merits, there was no basis on which to rule the conviction unsafe (see [41]).

104. In _R v Bani [2021] EWCA Crim 1958, four defendants had been convicted of assisting unlawful_
immigration, Mr Bani upon his guilty plea. However, subsequent to their convictions, the decision in Kakaei
determined that, where a person remains in an “approved area”, they are deemed not to have entered the
UK for the purposes of s. 11 of the Immigration Act 1971. It was further agreed that this was not a
departure from earlier law, but rather affirming consistent previous jurisprudence. The appellant who had
pleaded guilty had done so on the basis of advice that had not properly identified the relevant elements of
the offence. The guilty plea had been entered not simply because counsel had given inaccurate advice, but
because a legal “heresy” had been adopted by the investigators and then passed on to and accepted by
prosecutors, defendants, and judges (see [109]). The investigators and prosecutors had a role in “causing
or permitting a false understanding of the law to become prevalent” (see [116]). In these circumstances,
the court held that it “may be unjust” to require Mr Bani to prove that he would probably have succeeded in
his defence (the fourth limb of the Dastjerdi checklist). The conviction was held to be unsafe (see [118] and

[119]).

_Abuse of process_


-----

105. The provisions of ECAT and the Directive demonstrated a very significant change in the approach to
victims of trafficking, reflected in a series of appellate decisions underlining the power to quash a conviction
as an abuse of process if identification of a person as a victim of trafficking did not occur until after
[conviction (see for example R v L(C) [2013] EWCA Crim 991; [2014] 1 All ER 113 (“R v L(C)”); R v LM and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5B34-2B41-DYBP-M369-00000-00&context=1519360)
_R v N/L). The law was developed so as to ensure that the UK complied with its international obligations_
where the common law defence of duress was not available, including under article 26 and Article 4, and
before the implementation of the Act.

106. However, there is no question of any blanket immunity from prosecution on VOTs, as was
emphasised in R v S(G) [2018] EWCA Crim 1824; [2018] 4 WLR 167(“GS”) at [76(i)]. Rather, the relevant
enquiry is whether, had the prosecution known the true facts, the prosecution would not have (or might well
not have) been maintained in the public interest.

107. The test was usefully formulated by Gross LJ in GS at [76(v)] as follows:

“As always, the question for this court goes to the safety of the conviction. However, in the present context,
that inquiry translates into a question of whether in the light of the law as it now is (this being a rare change
in law case) and the facts now known as to the applicant (having regard to the admission of fresh
evidence) the trial court should have stayed the proceedings as an abuse of process had an application
been made. This question can be formulated indistinguishably in one of two ways which emerge from the
authorities: was this a case where either: (1) the dominant force of compulsion, in the context of a very
serious offence, was sufficient to reduce the applicant's criminality or culpability to or below a point where it
was not in the public interest for her to be prosecuted? or (2) the applicant would or might well not have
been prosecuted in the public interest? If yes, then the proper course would be to quash the conviction …”.
(emphasis added)

This passage was cited subsequently with approval in R v BXR _[2022] EWCA Crim 1483 (“BXR”) (at [19])_
and R v AGM [2022] EWCA Crim 920 (“AGM”) (at [11]).

108. The court in _GS emphasised that it was putting the same test in two different ways. The first_
formulation emphasises that it is not enough, on its own, for the applicant to have been trafficked. Rather,
using the language of s. 45, the applicant must have been “compelled” to do the criminal act in question,
the compulsion being “attributable to slavery or to relevant exploitation”.

109. In BXR the necessary degree of “nexus” between the trafficking and the commission of the offence
was explained thus (at [17]):

“Where there is no reasonable nexus, generally the conviction should not be set aside. At the other end of
the scale, where the nexus is such that in reality culpability is extinguished, the conviction should normally
be set aside. In between these examples at either end of the scale are cases in which there is a degree of
causative connection between the trafficking and the offending. Whether it is sufficient to make it contrary
to the public interest to prosecute will depend upon the extent to which it reduces the defendant's
culpability for the offending.”

110. The degree of compulsion is “not necessarily decisive in every case”: see _AGM at [13]; it must be_
considered in its full context. Thus, in BXR (at [18]) a range of other factors was taken into account:

“Nexus is not however the only factor: other factors which engage the public interest are the gravity of the
offence, and alternatives reasonably open to the defendant… There may also be particular features of the
defendant in question, including his history, and of the particular crime and the seriousness of the
defendant's participation in it, which increase or decrease the public interest in prosecution.”

111. The obvious point, as confirmed in R v L(C) (at [13]), is that the question of whether a prosecution in
a trafficking case is or might well be contrary to the public interest must be approached “with the greatest
sensitivity”. It is not necessarily the case that, even if there is strong evidence against the defendant,
prosecution will always be in the public interest (see AGM at [8]).

112. The degree to which the prosecution complied with CPS guidance in identifying the applicant as a
VOT will be relevant in that it affects the standard of scrutiny which the court can apply Unless it is argued


-----

that the guidance is in some way inadequate, it should normally be assumed that the contemporaneous
guidance will have taken account of all the guidance offered by the relevant authorities with responsibilities
in the context of Convention obligations. Therefore, when assessing compliance with article 26, the
guidance can provide the starting point and, in the overwhelming majority of cases, the finishing point for
that assessment (see R v N/L at [86(b)]).

113. The authorities emphasise that the decision to prosecute is ultimately for the prosecution, and not the
court. Where the prosecution has applied its mind to the relevant questions in accordance with the
applicable CPS guidance, it will not generally be an abuse of process to prosecute unless the decision to
[do so is “clearly flawed” (see AGM at [12] and R v BYA [2022] EWCA Crim 1326 at [20]). The court does](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:66KY-GB03-CGX8-00J1-00000-00&context=1519360)
not intervene merely because it disagrees with the ultimate decision to prosecute: see _AAD at [119]._
However, if CPS guidance has been disregarded, such that the question of whether to prosecute has not
been properly considered (or considered at all), the court can intervene more readily: see AGM at [13] and

[56]. It will then be open to the court to consider the public interest question without trespassing on ground
which has been appropriately considered by the prosecution authorities.

114. All of the authorities referred to immediately above relate to cases where the offending pre-dated the
Act (“pre-Act cases”). In _AAD,_ the court considered, amongst others, the question of whether it was still
possible, following the arrival of the Act, to argue on appeal that prosecution of a VOT was an abuse of
process. At [142] to [143], the court held that the jurisdiction to stay for abuse of process on appeal had not
been curtailed by s. 45, as had been perhaps suggested by the earlier case of R v DS _[2020] EWCA Crim_
_285; [2021] 1 WLR 303(at [40]). The jurisdiction remains “an additional safeguard, given appropriately_
exceptional facts… Cases of abuse of process will be (as they always should have been) very rare in this
context and can arise in only very limited circumstances”.

115. It was submitted for the Respondent that the guidance in GS (and the other cases dealing with preAct cases as set out above) does not apply to the present case, being a case to which the Act applied (a
“post-Act case”). Post-Act cases, it is suggested, fall to be assessed under the guidance in AAD, which is
said to be very different.

116. In AAD, having concluded that the abuse of process jurisdiction remains available in principle in all
VOT cases following the Act, the court went on to state (at [142]):

“(4) If (in what will be likely to be a most exceptional case) there has been a failure to have due regard to
CPS guidance or if there has been a lack of rational basis for departure by the prosecution from a
conclusive grounds decision then a stay application may be available. It will then be assessed by the court,
by way of review on grounds corresponding to public law grounds.” (emphasis added)

117. The court in AAD was not saying that the review is to be carried out strictly on public law grounds.
Rather, it referred to assessment by way of review on grounds “corresponding to public law grounds”. This
echoes the statement in R v LM at [18] where the court stated that the test was “akin to that upon judicial
review”. Nor was _AAD breaking new ground in terms of the approach to be adopted when considering_
whether there has been an abuse of process. The point being made was that the exercise for the appellate
court is not to substitute its own view, but rather to review the decision to prosecute by reference to
considerations including those of rationality and procedural fairness. Thus, by way of example, the court
stated in [120] of AAD:

“But what if the CPS has failed unjustifiably to take into account the CPS Guidance…?...in principle such a
scenario would, on ordinary public law grounds, seem to operate to vitiate that prosecution decision:
whether by reason of a failure to take a material matter (viz the CPS prosecution guidance) into account or
by making a decision to prosecute which is properly to be stayed as irrational. Consequently, such a
prosecution may, in an appropriate case, be stayed. This aligns with the principle…that, generally
speaking, a decision to prosecute is not susceptible to judicial review in the Administrative Court because it
may be challenged during the trial process itself, most particularly by an application to stay the proceedings
on the grounds of abuse of process…”


-----

118. Specifically, the court in AAD did not disapprove of the earlier guidance in GS, nor did it suggest that
such guidance no longer applied to cases falling under the Act. The considerations identified in _GS,_
including for example the question of nexus and the seriousness of the offending, may still be relevant to
the question of whether a stay would have been appropriate and whether or not a conviction can properly
be said to be unsafe on abuse of process grounds. That can be seen, for example, in the discussion in
_AAD at [182] of the safety of AAD's conviction on the facts._

119. We do not therefore accept the submission that the court in _AAD_ was promoting a fundamentally
different approach to that adopted previously by the courts when determining whether or not there has
been an abuse of process.

**Findings and analysis**

_Fresh evidence_

120. The application is predicated on the fresh evidence identified in [17] above, culminating in the FTT
decision. It is in the interests of justice to admit this evidence, including the expert psychiatric evidence
(which is based essentially on the applicant's accounts of trafficking which have been held to be reliable),
and we do so. In particular, the evidence appears to be (broadly) capable of belief and may afford a ground
for allowing the appeal.

_Findings on the contested facts surrounding the applicant's guilty plea_

121. We start with our findings on the question of whether or not the applicant was advised (adequately or
at all) of the availability of a s. 45 defence.

122. On the basis of the written material available, together with the oral evidence of the applicant (in
which he largely maintained the position set out in his witness statements) and Counsel, we have no
hesitation in preferring the evidence of Counsel over that of the applicant on this issue.

123. The applicant's version of events is unsustainable in the face of Counsel's lengthy manuscript notes,
which the applicant accepted in the witness box were made contemporaneously. Counsel took instructions,
showed the applicant the evidence against him and gave advice. Counsel's notes make it clear, amongst
other things, that he was fully alive to the possibility of a s. 45 defence. Counsel explained in the witness
box that this was the first time that he, and indeed all the other counsel in the case, were having to grapple
with s. 45. There is no good reason to doubt that Counsel, an experienced criminal practitioner, did not
take the applicant through the essential elements of a s. 45 defence. Whilst Counsel could not remember
what he had said about burden and standard of proof (as to which the law at the time was not clear), he
was certain that he discussed in particular the applicant's freedom to leave and, for example, his use of the
Zello app, which allowed worldwide communication. That issue was, he said and we accept, why the
applicant was anxious to view the CCTV footage available. That this was understood as an issue is further
reflected in the applicant's signed acceptance in his basis of plea that he “could have done more to get
away”. Counsel confirmed that it was the applicant's independent choice to plead guilty.

124. Thus, the applicant did not only have a single brief conversation with Counsel; he was not told that he
“must” plead guilty, as he in fact readily conceded before us in the witness box; he was given a full
opportunity to give instructions and he was advised of the essential elements of a s. 45 defence; it was his
free decision to plead guilty which he did in the hope of a significant reduction in sentence as a result.
(That hope indeed came to fruition, given the credit for guilty plea of 25% afforded by the Judge.)

_Inadequate legal advice_

125. As a preliminary matter, we reject the submission that there would be an injustice in requiring the
applicant to meet the Boal test, by analogy with Bani. As set out above, Bani was a most unusual case,
where a “legal heresy” had been created by the prosecution and then adopted throughout the system as to
the legal requirements of an offence under s. 25 of the Immigration Act 1971. By contrast, the position here
is that, as set out in more detail below, there were operational failures in the identification of the applicant
as a VOT and the application of the relevant CPS guidance in force at the time. Although such failures


-----

were serious, even fundamental, there was no false understanding, shared or otherwise, as a result of
anything said or done by the authorities as to any matter of principle or law.

126. We turn therefore to the requirements of the Boal test. As set out above, an appeal can succeed i) if
the guilty plea is vitiated by erroneous legal advice or a failure to advise as to a possible defence, even
where the failures may not have been so fundamental as to have rendered the plea a nullity and ii) the
effect of the advice is such as to deprive the defendant of a defence which would probably have
succeeded. A clear injustice must have occurred.

127. As for the merits of a s. 45 defence, the Respondent has conceded throughout that, on the basis of
the findings in the FTT decision in relation to events preceding trial (by which time the applicant had been
forced to work at a second cannabis farm), a s. 45 defence would “quite probably” have succeeded. In
other words, that part of the Boal test is satisfied. This is a case where the question of trafficking has been
explored fully at a hearing before the FTT Judge at which the applicant gave oral evidence which was
challenged in cross-examination. [81] of the FTT decision, as set out above, is particularly pertinent. There
is in our judgment no proper basis on which to depart from the findings there that, in the UK, the applicant
was required to work as a gardener in various cannabis factories and was beaten, deprived of sufficient
food and of his liberty.

128. We are not however persuaded, in the light of our findings above, that there was any clear injustice.
This is not a situation where a potential defence was missed; specifically the applicant was advised as to
the availability of a s. 45 defence. Counsel also gave sufficient advice on the basis of the applicant's
instructions to him. Only the applicant could explain to Counsel what had happened to him, and Counsel
could only work on the basis of those instructions. The applicant had time to consider the advice given, and
to consider, with reference to the CCTV footage in particular, whether he wished to accept guilt. He
suggested in his second witness statement that he was inhibited when speaking to his solicitor at the police
station; but we note that when giving instructions to Counsel, he freely alleged that he had been in fear of
his life, and the subject of multiple sexual assaults by guards. Further, he indicated that he wished to
provide the police with information “about who was in charge of the operation”. He signed the basis of plea
and the endorsement, both of which were in clear and readily understandable terms.

129. In these circumstances, we do not consider that this is one of those exceptional cases where the
applicant's guilty plea is vitiated on the basis of erroneous or inadequate legal advice. For the sake of
completeness, we add that there is no proper basis for suggesting that the plea was a nullity, and the
written submission to this effect was not pressed orally before us at all.

_Abuse of process_

130. As set out above, the further or alternative basis for the challenge to the safety of the applicant's
conviction is the contention that the proceedings against the applicant below were an abuse of process.
This is, on the facts, a far more obvious platform for a successful appeal.

131. We consider first the extent to which, if at all, the prosecution complied with the relevant CPS
Guidance, namely that in force in November 2015 when the applicant was arrested, and as revised in July
2016 (together “the Guidance”).

132. The Guidance included that prosecutors should be alive to indicators of trafficking i) generally and ii)
expressly in the context of cannabis cultivation and immigration crime. It identified the three-stage
approach to the prosecution of possible credible VOTs, including their identification, the consideration of a
possible defence of duress and the consideration of the public interest in prosecution of a VOT. In relation
to the first stage, the duty of prosecutors was to make proper enquiries in criminal prosecutions involving
individuals who may be VOTs by a) advising the investigating agency that it must investigate the suspect's
trafficking situation; and b) advising that the suspect be referred via the NRM. All law enforcement officers
are able to make such a referral, and these are steps that “must be done” regardless of what had been
advised by the investigator or whether there was an indication of an early guilty plea. In relation to the
second stage, a case should be discontinued if there is clear evidence of a credible common law defence
of duress (or, by extension, a s. 45 defence). In relation to the third stage, prosecutors had to consider


-----

whether the offence was a direct consequence of, or committed in the course of, trafficking, whereby if the
suspect had been compelled to commit the offence but not to a degree where duress was made out, it
would generally not be in the public interest to prosecute unless the offence was “so serious” or there were
other aggravating features. It was incumbent on prosecutors to apply to adjourn a case where a defendant
proposed pleading guilty if a “full investigation” had not been carried out and there was a suspicion of
trafficking. There was also a continuing duty after plea and pre-sentence to refer a defendant via the NRM
where indicators of trafficking became apparent at that stage.

133. The Respondent has made the following disclosure:

“The Respondent has considered the review notes it holds. The only reference to 'trafficking' is a general
note that in an initiating charging decision that 'Age of Vietnamese nationals and risk of being victims of
human trafficking to be kept under review'".

134. There is no evidence that any review of the applicant's position as a potential VOT was carried out at
any stage.

135. It is clear that the police failed to discharge their duty as first responders and that the prosecution
failed to comply with the Guidance. We emphasise the following:

i) There were clear indicators of trafficking from the outset, given the circumstances of the applicant's
arrival as an unaccompanied Vietnamese child/very young adult, his involvement in the cultivation of
cannabis and the express reference in his first prepared statement to having been exploited;

ii) No proper enquiries were made upon his arrest, nor was there any referral to the NRM;

iii) There being good reason to believe that the applicant was a VOT, there was no review on evidential
grounds as to whether there was clear evidence of a credible s. 45 defence;

iv) There was no consideration in any event of whether or not the public interest lay in proceeding to
prosecute/continuing a prosecution or not.

136. Had there been compliance with the Guidance, in the light of the fresh evidence, it can be seen that
the following main pre-trial events would have been discovered by the prosecution authorities:

i) Based on the findings of the FTT Judge, the applicant was trafficked out of Vietnam to Russia and then
within and out of Russia and through Europe until he arrived in the UK in 2015 and then within the UK until
his arrest on 26 April 2016;

ii) He had been taken forcibly from Vinh City in Vietnam by traffickers because of a gambling debt owed by
his father and whilst en route to the UK he did not work but was deprived of his liberty and sustained
beatings;

iii) In the UK he was required to work as a gardener in two cannabis factories and was beaten, deprived of
sufficient food and of his liberty. His beatings included being cut to the neck with a knife, being burnt with a
cigarette to the arm and being assaulted to the head with a wooden post whilst in Russia;

iv) On 9 May 2016, the applicant was age-assessed as a minor and referred to the NRM as a potential
VOT. There were concerns over his vulnerability and he was placed into foster care;

v) On 13 May 2016, a positive reasonable grounds decision was made;

vi) On 14 May 2016, the applicant went missing from foster care;

vii) On 27 May 2016, he was arrested at another cannabis farm, having been re-trafficked. (At this point he
was age-assessed as an adult and held on remand.)

137. Thus, the unjustifiable failure on the part of the prosecution to take into account the Guidance led to
material factors being overlooked. Added to this is the Respondent's acknowledgement that a s. 45
defence would “quite probably” have succeeded. We are confident that the prosecution would have been
discontinued at the second evidential stage. Alternatively, the trial court would have stayed the
proceedings as an abuse of process, had an application been made.


-----

138. Armed with the fresh evidence it can be seen that the dominant force of compulsion was sufficient to
reduce the applicant's criminality or culpability to or below a point where it was not in the public interest for
him to be prosecuted and the applicant would or might well not have been prosecuted in the public interest.
Further the applicant's involvement in the cannabis cultivation operation was limited in time and he was
operating at the bottom of the chain. He was very young, damaged and vulnerable, with no previous record
of offending. That there would have been no impropriety in leaving the facts to be evaluated by a jury, the
submission relied upon by the Respondent, misses the point. The prosecution would not have been
pursued with full knowledge of the relevant facts after proper enquiry.

139. Taking all of the above into account and standing back, we conclude that, on the present combination
of very unfortunate facts, this is one of those exceptional cases where there was a clear abuse of process
such that the conviction is unsafe.

140. For the sake of completeness, we add that, whilst there was no suggestion by the Respondent that
there was no continuing abuse of process jurisdiction after the applicant's conviction on his guilty plea, it
was suggested that the fact that he had pleaded guilty, and the principle of finality, were material
considerations, militating against a finding of abuse. There should not be a licence to appeal by anyone
who discovers, following conviction, that some possible line of defence has been overlooked (see for
example Boal at 599).

141. The principle of finality is undoubtedly important. However, we do not consider that the fact that the
applicant pleaded guilty renders his conviction safe on the facts of this case. Amongst other things, as set
out above, had the prosecution complied with its duties under the Guidance, the prosecution would not
have proceeded in the first place and/or would not have been pursued and/or the applicant would have had
a proper opportunity to apply for a stay. And, as set out above, a conviction on a guilty plea in a case
involving an abuse of process is as unsafe as one following trial. It would in our judgment be inconsistent
with the due administration of justice to allow the applicant's plea of guilty to stand.

**Conclusion**

142. We grant leave to rely on the fresh evidence and leave to appeal. We also grant the necessary
extension of time. Although the delay is very significant, as is apparent from the chronology above, there is
an explanation for the delay and there would be a significant injustice if the appellant were to be prevented
from pursuing what is a strong appeal. It is in the interests of justice to proceed accordingly.

143. For the reasons set out above, we allow the appeal on the basis that the conviction is unsafe in
circumstances where, although the appellant pleaded guilty following adequate legal advice, the
proceedings amounted to an abuse of process. The conviction is quashed.

**End of Document**


-----

