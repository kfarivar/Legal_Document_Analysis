# R v L (OK) (2017) [2017] EWCA Crim 152

CA, CRIMINAL DIVISION

201603369 C2, 201603370 C2

Andrews J and Treacy LJ

22/02/2017

**[Neutral Citation Number: [2017] EWCA Crim 152](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5N22-K3R1-F0JY-C0B3-00000-00&context=1519360)**

No: 2016/3369/C2

**IN THE COURT OF APPEAL**

**CRIMINAL DIVISION**


Royal Courts of Justice

Strand

London, WC2A 2LL

Wednesday 22 February 2017

**B e f o r e:**

**LORD JUSTICE TREACY**

**MRS JUSTICE ANDREWS DBE**

**HER HONOUR JUDGE MUNRO QC**

(Sitting as a Judge of the CACD)

**R E G I N A**

**O K L**

Computer‑Aided Transcript of the Stenograph Notes of

WordWave International Limited trading as DTI

165 Fleet Street London EC4A 2DY

Tel No: 020 7404 1400 Fax No: 020 7404 1424

(Official Shorthand Writers to the Court)

**Mr J Talbot appeared on behalf of the Appellant**


-----

The Crown did not appear and was not represented

J U D G M E N T

(Approved)

Crown copyright©

1. MRS JUSTICE ANDREWS: On 8th April 2016 the appellant was convicted after trial of being concerned in the
production of cannabis. When she was arrested she was in the possession of the key to the front door of a flat in
Middlesbrough in which there was a relatively substantial cannabis factory. The police had forced entry to the
premises, which were then vacant, and discovered the cannabis (which had a value of between £15,400 and
£46,200) growing in the loft. There were about 55 cannabis plants reaching maturity, which were being well tended
and cared for. There was a reasonably sophisticated watering and ventilation system and the electricity had been
diverted, all of which, as the trial judge, the Recorder of Middlesbrough remarked when sentencing the appellant,
were hallmarks of a professional farm. Matters had also been arranged at the flat so as to give the impression to
anybody looking at it from the outside that it was lived in.

2. The day after the forced entry, the appellant approached the front door of the premises. On seeing the damage
to the door caused by the forced entry, she turned around and walked away. A police officer who was guarding the
property saw her and asked her to stop. She shouted, "No, no, no" and ran away. The officer chased after her and
she was detained a short distance away. Apart from a set of keys including the key to the premises, she was in
possession of two mobile telephones and £700 in Scottish bank notes.

3. In her interview the appellant told the police that although she was born in Vietnam she was from China and
lived in the mountains. The impression she gave was that she had lived in China all her life. Her parents had died,
and after that she had lived with some people in a house where one of them spoke Vietnamese, which is why she
spoke that language. She said that she had come to the UK on a flight from Beijing two to three months earlier. A
male agent had arranged the flight and travelled with her. She had since lost her passport. She said that since
arriving in the UK she had been looked after by a man called John who had sent her to different houses to deliver
food, water and other things. He had made her hand over money to a white male two or three times whilst she was
in an address, but she did not know which address it was. She denied having ever been to Scotland. She said that
John had dropped her off in Middlesbrough the day before but did not return to collect her. She denied having
anything to do with cannabis farms. She said that she had previously refused to look after cannabis plants and that
John had hit her.

4. John had given her the keys, the £700 in cash and one of the phones. She said she was unable to unlock the
phone that John had given her because John had changed the PIN number. She had no idea that one of the keys
related to the premises and she denied approaching the premises. The fact that she had a key to the front door in
her pocket was just a coincidence, as was the fact that she was outside the premises talking on her mobile phone
when the policeman spotted her. She said she ran away because she did not realise he was a police officer and
she thought she was going to be attacked.

5. She also told the police in interview that she believed that she was a victim of human trafficking. When asked
why she did not just leave or go to the police station, she said that she was scared that John would come and find
her and hit her.

6. The appellant claimed to be 16 years old and gave her birth date as 12th September 1999. In the light of this
and in the absence of any identifying documentation, the appropriate steps were taken to assess her age. An initial
age assessment interview was carried out at the police station with the assistance of a Vietnamese interpreter. The
assessors were two highly experienced social workers who had been trained in the application of the guidelines in
R(B) v Merton London Borough Council _[2003] EWHC 1689 (Admin). The age assessment document was_
completed on 15th January 2016.


-----

7. The appellant told the assessors that she had no documents because she had lost them somewhere in the UK.
She said that she had arrived from China approximately a month before but she did not recall which airport she had
flown into. She said that a male in China had approached her and explained that she could travel to the United
Kingdom for a better life. He would organise her passport and would find work and accommodation for her whilst
she also attended school. She said that she came over to the United Kingdom of her own free will and she did not
feel under threat and was not scared in any way. She advised the social workers that there were four other females
on her flight, and also some men, but when they arrived in the UK the men left and she was left alone. She was
met by a male known as John. She said that prior to her arrest she had been working as a maid and living in
hotels. She said that she was forced to work and that if she did, John would buy her clothes and provide her with
food.

8. She said she had no documentation to prove her identity or age. When asked about her parents and family, she
advised that both parents had died “a long time ago when she was aged about 10”. From that age, she did not
attend any form of education and lived between homes with different people. These people were not friends or
family and she did not have any information in relation to them. She was generally reluctant to divulge information
to the social workers and she did not provide them with the details that they would have expected. Names, places,
dates and times were all inconsistent or not shared. She maintained that she was 16 and that no one had told her
to say that she was 16. However, she presented to the social workers as a developed woman, not a developing

teenager, and as a well‑groomed adult wearing nail varnish and bright lipstick. She was calm and spoke with

confidence, despite sharing only small pieces of information.

9. Having regard to her physical appearance, demeanour and credibility, the assessors came to the conclusion that
the appellant was an adult posing as a child and they gave cogent reasons for that conclusion. She did not present
as a vulnerable young person in need of support from children's services. They assessed her age as 25 with a twoyear margin for error on either side, making her true age between 23 and 27. It was explained to the appellant that
she could challenge the age assessment through a solicitor but that another assessment would not be offered
unless further information or evidence was provided that would suggest that she was indeed a child.

10. The landlord of the premises subsequently identified the appellant as the person from whom he had received
the rent for a period of approximately 12 months by picking her out in an identification procedure. His evidence at
trial was that he had let the property to a Lan Zeng in 2013. Shortly after the tenancy was renewed in September
2014, the appellant had become responsible for handling over the monthly rental payments. She was accompanied
by another female. He described her physical appearance and said that she wore red lipstick. Although her
English was broken, he said: "She could communicate fine."

11. In the light of the age assessment, the appellant was treated as an adult, and tried in the Crown Court at
Teesside. No order was made under section 45 of the Youth Justice and Criminal Evidence Act 1999. The
appellant was represented at trial by solicitors and counsel. The question of her age was specifically raised as a
preliminary issue prior to the start of the trial. Defence counsel sought information from the prosecution to confirm
that the appropriate procedures had been gone through to assess his client's age. Counsel for the Crown
confirmed to the court that there had been a proper Merton compliant age assessment and that what he described
as “an authoritative report” had been produced. It appears from the appellant's skeleton argument that a copy of
the age assessment was also produced by the Crown at that stage. Counsel for the Crown told the judge that the
defence seemed to take no further issue with that aspect of the case. Defence counsel did not demur.

12. Nothing was said to the court at that stage to suggest that any efforts were being made to obtain the appellant's
birth certificate in Vietnam, as it would have been if there were. There is no evidence that the appellant's previous
solicitors and counsel at that stage had any knowledge of such efforts, as one might have expected had such
efforts been undertaken. The solicitors confirmed that they themselves had made no attempts to obtain their
client's birth certificate, and no criticism has been made of them in that regard. Indeed, Mr Talbot, who appeared
today on behalf of the appellant, has been scrupulous to make it clear that he makes no criticism of the previous
solicitors or counsel, or indeed of the trial judge. No point is taken regarding the fact that those inquiries were not
made at that time.


-----

13. Having initially accepted in her defence statement that she handed over the rent on the premises on three or
four occasions, when she came to give evidence the appellant departed from the defence statement in a number of
material respects, including denying that she had ever been to the premises in Middlesbrough, claiming that she
handed over the rent in respect of a wholly different property.

14. The Recorder sentenced the appellant on the basis that, by reason of its verdict, the jury had accepted the
landlord's evidence that she had been responsible for handing over the rent on the premises for approximately 12
months. He said that he did not know for certain when or how she came to this country, but there was no evidence
to suggest that she was not telling the truth about that. However, it was clear that she took part in the production of
the cannabis. She was not at the top of the tree, there were clearly others above her, and she was acting under the
instruction and direction of those others, but quite clearly equally she was trusted. She was well aware that
cannabis was growing in the premises even though she did not live there. He was also sure that part of her act was
to give the appearance that people were living in the house. The Recorder took the view that the appellant was
playing a significant role in a Category 2 offence under the relevant sentencing guidelines, and that the starting

point for someone of good character after trial would be four years' imprisonment, with a range of two‑and‑a‑half to

five years. He treated her as vulnerable because she was in the country illegally and therefore could be taken
advantage of by those who were more criminally experienced, but he said that he was satisfied that she willingly
went along with what was happening. On that basis the appropriate sentence was one of three years'
imprisonment. One could not quarrel with that sentence if the appellant were an adult, and Mr Talbot very sensibly
made that clear to us today as well.

15. Initially the appellant applied for leave to appeal against conviction, as well as against sentence. She was
refused leave to appeal against conviction by the single judge. Despite telling the police that she was the victim of
trafficking, the appellant had not sought to raise a defence under section 45 of the Modern Slavery Act 2015. As
this court said in R v Joseph and others [2017] EWCA Crim. 36 at paragraph 40:

16.

"It does not follow from the fact than an individual 'fits the profile' of a victim of trafficking that they are necessarily
the victim of trafficking. A careful analysis of the facts is required including close examination of the individual's
account and proper focus on the evidence on the nexus between the trafficking and the offence with which they are
charged."

There was no evidence of trafficking in this case, let alone that the others involved with the cannabis factory had
anything to do with trafficking. In any event, having heard the evidence at trial the Recorder was satisfied that the
appellant was a willing participant in the criminal enterprise. The section 45 defence would not have succeeded
even if she had deployed it. In recognition of that, it was confirmed today by Mr Talbot that although there was
some confusion about it previously, that the appellant did not seek to renew her application for leave to appeal
against conviction.

17. However, she does appeal against her sentence by leave of the single judge. Her sole complaint is that at all
material times she was indeed 16 years old and should have been dealt with accordingly. It is contended that
because of her true age of 16 the appellant should have been tried in the Youth Court. The maximum sentence
that could have been imposed in the Youth Court was a 24-month detention and training order. Mr Talbot
submitted that it is unlikely that the appellant would have received the maximum sentence for these offences and
that, having taken into account the guidelines for young offenders, the appropriate sentence would have been in the
region of an 18-month detention and training order. The sentence that was passed was therefore manifestly
excessive.

18. In support of her appeal, the appellant seeks to rely upon fresh evidence which she claims proves that she was
telling the truth about her age, and that the age assessment carried out in January 2016 was wrong. Section 23 of
the Criminal Appeal Act 1968 provides as follows:

19.


-----

"23 Evidence.

(1) For the purposes of an appeal under this Part of this Act the Court of Appeal may, if they think it necessary or
expedient in the interests of justice—

...

(c) receive any evidence which was not adduced in the proceedings from which the appeal lies.

...

(2) The Court of Appeal shall, in considering whether to receive any evidence, have regard in particular to—

(a) whether the evidence appears to the Court to be capable of belief;

(b) whether it appears to the Court that the evidence may afford any ground for allowing the appeal;

(c) whether the evidence would have been admissible in the proceedings from which the appeal lies on an issue
which is the subject of the appeal; and

(d) whether there is a reasonable explanation for the failure to adduce the evidence in those proceedings."

20. The fresh evidence in this case comprises:

(a) two witness statements dated 25th August 2016 of Ms Phuong Cuthbert, a Vietnamese interpreter;

(b) a witness statement dated 13th September 2016 from a solicitor named Annalisa Moscardini, exhibiting what is
said to be a certified copy of the appellant's Vietnamese birth certificate dated 29th May 2016, confirming her date
of birth as 12th September 1999; and

(c) an unsigned and undated witness statement from a lady named Thi Mai Tran who claims to be the “auntie” of
the appellant, which was obtained in the circumstances explained by Ms Moscardini in her statement and by Ms
Cuthbert in her second witness statement. We appreciate that "auntie" is a title of respect for an older female who
may not necessarily be a blood relative.

21. Since the matters to which the Court of Appeal must have regard include whether the evidence appears to be
capable of belief and whether it may afford a ground for allowing the appeal, we have looked at it to help us decide
whether to allow the application to admit it into evidence.

22. Ms Cuthbert says in her witness statement that in May 2016 she was contacted by a member of the
Vietnamese community in Middlesbrough and asked if she could help the appellant who wanted to appeal her
sentence. Ms Cuthbert was asked if she knew a solicitor who could help. She contacted Ms Moscardini who she
knew professionally, and subsequently accompanied her to a meeting with the appellant in prison where Ms
Cuthbert acted as translator. At the meeting Ms Moscardini told the appellant that if they were able to obtain
evidence of her age there might be grounds for appeal, but that she would need an official birth certificate.
According to Ms Cuthbert, the appellant said she was trying to obtain one. Ms Cuthbert gave the appellant her
contact details in case she or her family needed to contact Ms Cuthbert.

23. At some point in mid‑June 2016 Ms Cuthbert says she was contacted by a Vietnamese student named Hang

who said that she had copies of a birth certificate to bring over to her. They met in Newcastle on Tyne and the
documents were handed over. Ms Cuthbert did not ask for Hang's surname and she took no contact details for her.
She says that it is not unusual for documents to be passed amongst the Vietnamese community in this way. She
then passed the documents on to Ms Moscardini.

24. Ms Moscardini says in her statement that when she met the appellant in May 2016 she looked and behaved as
though she was very young. She advised her that if she could get hold of her birth certificate there might be


-----

grounds for appeal. Ms Moscardini does not say that the appellant said that she was already taking steps to get the
birth certificate. She says that at some point in June 2016 Ms Cuthbert called her to say that she had been passed
the birth certificate by a student who had brought it on behalf of an auntie in Vietnam. Ms Moscardini says that she
is aware that sometimes the Vietnamese community send things with students rather than by post, as a quicker and
more trustworthy way of getting to their destination. Ms Cuthbert told Ms Moscardini that she had no way of finding
the student again, as she had not kept any details from her. Ms Moscardini made a lot of efforts to obtain
assistance from the Vietnamese Embassy in establishing the authenticity of the documents but they did not respond
to her emails. Her attempts to get through to them on the telephone also proved futile. Mr Talbot told the court
today that until she left on maternity leave at the end of last September, Ms Moscardini had been phoning the
Embassy on a regular basis and she had been kept on hold for upwards of an hour each time that she telephoned
them. She has certainly done everything possible to try and help this appellant, and is to be commended for her
efforts in doing so.

25. Because she got nowhere with the Vietnamese Embassy, Ms Moscardini asked the appellant to provide details
for the auntie who provided the birth certificate. They were not provided immediately. Ms Moscardini says that in
due course the appellant rang Ms Cuthbert from prison and passed over a telephone number to her. Ms Cuthbert
then arranged to attend the solicitors' office to act as translator whilst Ms Moscardini made a telephone conference
call to the auntie. Ms Moscardini turned what she was told during the telephone call by the auntie, Ms Tran, into a
witness statement. Ms Cuthbert has made a further witness statement confirming that the witness statement of Ms
Tran as put together by Ms Moscardini is an accurate account of what she told them on the telephone. That
account is as follows:

26.

"I am the auntie of Oanh Le. Her mother died when she was very young and I adopted her, though not formally. In
Vietnam this just means I took over responsibility for her upbringing. She was with me until she was 10 years old.
Her date of birth is September 12th 1999. At 10 years old she was taken. I believe she was taken to China. I do
not know anything about what happened to her and I do not know who took her there or where she was. The next I
heard from her was when she was 15 or 16 and she contacted me saying she was in the UK. This was before her
arrest for criminal offences. We had regular contact whilst she was in the UK.

At some point this year, I don't remember when, she called me from prison to say she had been arrested for a
criminal offence and she needed her birth certificate as people do not believe her age. I started trying to get her
birth certificate but this is not an easy process. It took at least a month to get. First I had to go to the birth registry
office in our area to get a copy of her original birth certificate. I still have this and will try to have it scanned to one
solicitor but this is hard as I do not have an email address or electronic equipment. I believe our post office may
offer a service I can use. I will check this. Then I have to go to a different office to have the certificate copied and
translated and stamped to affirm the copy. This was formally finished and stamped on 29th May 2016 and I was
given two copies. I confirm these are true copies of her birth certificate."

Ms Tran then goes on to explain how she used a named contact who knew a lot of students through whom she
organised delivery of documents to find a student, Hang, who was coming to study in Newcastle and Hang agreed
to take this document across to the UK. She said that she, Ms Tran, had never spoken to Hang and did not know
her surname. She gave Ms Cuthbert's details to her contact to pass on to Hang with copied certificates and a few
weeks later she got a call from the appellant in prison to say that they had been received.

27. Ms Moscardini said in her statement that she posted a translated copy of Miss Tran's unsigned witness
statement in a letter to Miss Tran and hoped that she would respond, although she was led to believe that the
postal system in Vietnam is more difficult for smaller towns given the "vague address" Ms Tran was able to give.

28. Ms Moscardini's statement was made on 13th September 2016. Despite the passage of time since then, no
signed copy of Ms Tran's witness statement has been produced.


-----

29. Mr Talbot submitted that the test for fresh evidence was met, but that even if it was not satisfied of this, the
court had an overriding discretion to allow the evidence to be admitted in the interests of justice and that it should
exercise that discretion in favour of the appellant.

30. The first question to consider is whether the fresh evidence appears capable of belief. On its face the
translated certificate purports to be a copy "from the register book" of a birth certificate for someone bearing the
appellant's name (not a copy of an original certificate which has been taken to a different office to be copied and
authenticated, which is what Ms Tran says it is). The place of birth is said to be Hong Thuy Commune, Le Thuy
District, Quang Binh Province, and the date of birth is stated as 12th September 1999. That was the date of birth
that the appellant gave to the age assessors. The certificate has some type of official stamp and signature upon it.
Only the name of the child's mother appears on the certificate. That is consistent with Miss Tran saying that the
child's mother died when she was very young and making no mention of her father. However, beneath the place of
registration it states:

"No: 54, April 02nd, 2013."

The relevance of that date is unclear, although it appears to be the date on which the birth was registered. There is
no explanation for why someone born in September 1999 would only have their birth registered in April 2013,
especially if they were no longer in Vietnam at that time.

31. The evidence as to this document's provenance is also highly unsatisfactory, even after making due
allowances for the difficulties in obtaining documents from a rural part of Vietnam. Whether or not it is common
practice in the Vietnamese community to use students as couriers for documents, the account of how the
documents came to be couriered from Vietnam by an unidentifiable Vietnamese student at Newcastle University or
College, whose details neither Ms Tran (nor perhaps more tellingly Ms Cuthbert) bothered to obtain is implausible.
That apart, there is no clear evidence that the individual referred to in this certificate, even assuming it to be
authentic and even assuming that it reached this country in the manner described, is the same person as this
appellant.

32. It is telling in this regard that no mention of her auntie in Vietnam was made by the appellant to the police in
interview or to the age assessors or to her own legal representatives at or prior to trial, at a time when it was plainly
in the appellant's interests to do whatever she could to satisfy them that she was only 16 years old. Instead she
told the age assessors that she had no documents to prove her age or identity, that her parents had died when she
was 10 years old and that the people she stayed with after that were neither friends nor family. That suggested her
parents brought her up until she was 10, whereas Ms Tran says that she did so.

33. According to Ms Tran she was in regular contact with the applicant by telephone when the applicant was in the
United Kingdom and before she was arrested. If that was so, the applicant could have told the Vietnamese
interpreter that was used at the police station, and when she was communicating with her original legal team, about
the existence of her auntie, and given anybody who asked for it the telephone number to contact her. She would
have known at the latest by February 2016 that the assessors did not believe her to be 16 years old and that it was
vitally important to establish her age. On her own account, Ms Tran was able to get authenticated copies of a birth
certificate by the end of May 2016 and to pass them to the student to take to England by the middle of June. If, as
the evidence suggests, the idea of getting a certificate emanated from the appellant's conversation with Ms
Moscardini earlier in May, then it did not take her more than a few weeks. If Ms Tran had been asked to do the
same thing in February 2016 the birth certificate would have been available before the trial. We cannot accept that
the appellant asked Ms Tran to obtain the birth certificate after she was first arrested but failed to mention that
crucial piece of information to her own legal representatives at any time before her trial.

34. It is also odd that when Ms Moscardini asked the appellant to provide details of the auntie she did not do so
straight away but in due course rang up Ms Cuthbert with the telephone number. Ms Moscardini says that is
because of the appellant's lack of English. That makes no sense because if she understood enough English to
appreciate what it was that Ms Moscardini wanted, as she must have done in order to provide the information to Ms
Cuthbert, and she was in regular contact with Ms Tran, she would have been able to provide the telephone number


-----

straight away. In any event, the jury accepted the landlord's evidence which suggests that the appellant's
understanding of English is somewhat better than she has been making out.

35. The next problem facing the appellant is that the fresh evidence, even taken at face value, does not provide
any sufficient basis for impugning the age assessment that was carried out. Section 164(1) of the Powers of
Criminal Courts (Sentencing) Act 2000 and section 305(2) of the Criminal Justice Act 2003 each have the effect of
providing that for the purpose of sentence, a person's age shall be taken to be that which it appears to the
sentencing court to be after considering any available evidence. That position is unaltered by section 99 of the
Children and Young Persons Act 1999. This provides that if a person brought before the court, other than as a
witness, appears to be a child or young person "the court shall make due enquiries to the age of that person ... and
where it appears to the court that the person so brought before it has attained the age of 18 years, that person shall
for the purposes of this Act be deemed not to be a child or young person."

36. It is well established that if the court has determined the defendant's age on a proper basis, as it did in the
present case, the sentence will not invalidated even though it may later be established that the offender belongs to

a different age group for whom that sentence may not be available or appropriate ‑ see for example R v Brown

(1989) 11 Cr.App.R (S) 263 and R v JF [2008] EWCA Crim. 1838.

37. In the former case, the appellant was sentenced to five years' imprisonment for robbery on the basis of
evidence that he was 21, when in fact he was 20 and the sentence should have been one of detention in a young
offenders' institution. The Court of Appeal refused to interfere with the sentence. In the latter case, no age
assessment was carried out until after the appellant was sentenced. In the light of the assessment the prosecution
accepted that the appellant's true age was 16 and expressly invited the Court of Appeal to approach the appeal on
that basis. The court did not enquire into the sentence that the judge would have passed if he had known the
appellant's true age, but allowed her appeal and substituted the sentence that it considered to be appropriate in the
light of the information before it.

38. That is a very different scenario from the present case, where a proper Merton-compliant age assessment was
carried out at the time. This birth certificate cannot serve to undermine the correctness of that age assessment
when there is no credible evidence that it is genuine or that it even relates to the appellant. In any event, it would
not afford a sufficient ground for impugning the sentence that was passed in good faith in reliance on the evidence
that was available following the properly conducted enquiry into her age.

39. Finally, but importantly, there is no reasonable explanation given for the failure to adduce the evidence at trial.
We accept that if it had been clear that the certificate was genuine then it probably would have been capable of
being adduced in evidence at trial by one means or the other, and Mr Talbot very fairly told us that the Crown
agreed with that proposition. However, the fact is that in this particular case the appellant simply failed to give any
information to the police, the local authority or to her own legal team about the prospect of obtaining her birth
certificate from Vietnam. Her accounts of her personal history were constantly changing and lacking in detail. She
seemed reluctant to divulge any information that might have led to her identity being ascertained or confirmed. It
appears likely that it was only after Ms Moscardini suggested it that any effort was made to obtain the birth
certificate. Therefore this is not a case in which there is clear evidence that enquiries were put in train before the
trial but the evidence did not arrive in time. Although it took a number of weeks for the certificates to be stamped
and brought to the UK (if that is what really happened) there is no reason why this could not have been done in time
for the trial if the appellant had been more forthcoming at the time of her arrest.

40. For all these reasons we refuse to admit the fresh evidence. In those circumstances, there is no basis upon
which it can be contended that the sentence imposed upon the appellant was manifestly excessive. The appeal is
therefore dismissed.

**End of Document**


-----

