# R v Kovalkov [2023] EWCA Crim 1217

Court of Appeal, Criminal Division

Mr Justice Jacobs, Mr Justice Griffiths

22 September 2023Judgment

WARNING: reporting restrictions may apply to the contents transcribed in this document, particularly if the case
concerned a sexual offence or involved a child. Reporting restrictions prohibit the publication of the applicable
information to the public or any section of the public, in writing, in a broadcast or by means of the internet, including
social media. Anyone who receives a copy of this transcript is responsible in law for making sure that applicable
restrictions are not breached. A person who breaches a reporting restriction is liable to a fine and/or imprisonment.
For guidance on whether reporting restrictions apply, and to what information, ask at the court office or take legal
advice.

This Transcript is Crown Copyright. It may not be reproduced in whole or in part other than in accordance with
relevant licence or with the express consent of the Authority. All rights are reserved.

MR P SPARY appeared on behalf of the Appellant.

_________

**J U D G M E N T**

Approved

MR JUSTICE GRIFFITHS:

1. On 18 April 2023, His Honour Judge Levett DL sentenced eight defendants who were charged on six different
indictments for a total of 26 offences. Two of them, Kovalkov and Smith, have been given leave to appeal against
their sentences to this Court. The first of those cases, the case of Kovalkov, has just been called on and heard
before us. Because the issues in Kovalkov differ from the issues in Smith, we are dealing with Kovalkov separately.

2. Kovalkov was born on 6 August 2005, so he was [an age] years old at the date of sentence. He pleaded guilty
at the PTPH on 28 July 2022, when he was [an age]. He is [an age] years old now.

3. The judge, in a complex sentencing exercise, dealing with all six indictments and all eight defendants, passed a
custodial sentence upon Kovalkov in respect of four matters, to which he had pleaded guilty. On indictment
T20227143, being concerned in the supply of Class A drugs, namely cocaine, he was sentenced to 30 months'
detention. On the same indictment, being concerned in the supply of Class B drugs, namely cannabis, he was
sentenced to 12 months' detention concurrent. On indictment T20227139, on his plea of guilty to an affray on 2
June 2022, he received a consecutive sentence of 12 months' detention. On indictment T20220434, the other
affray, on 15 August 2022, he received a sentence of 8 months' detention concurrent with the other affray sentence.

4. He appeals, with leave from the single judge, who said that it is arguable that the judge failed to have sufficient
regard to his age and personal circumstances when considering the nature and duration of any custodial sentence,
[having regard also to the provisions of Part 10 of the Sentencing Act 2020.](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:616J-5X93-GXFD-850J-00000-00&context=1519360)


-----

5. Upon examination of the papers and from the argument before us this morning, it is notable that the decision of
this Court in R v ZA [2023] EWCA Crim 596 was handed down after the sentences were passed in this case, and
after the Advice and Grounds were lodged in support of the appeal.

6. It does appear to be the case that the sentencing judge did not focus on every part of the Youth Guideline as the
case of ZA recommends. This may have been because there was no prosecution note. A structured approach to
submissions on sentencing Kovalkov as a young person was not adopted at the hearing.

7. Paragraph 6.42 of the Sentencing Children and Young People Guidelines says:

“Under both domestic and international law, a custodial sentence must only be imposed as a **'measure of last**
**resort;' statute provides that such a sentence may be imposed only where an offence is “so serious that neither a**
fine alone nor a community sentence can be justified.” [s.230 Sentencing Code] If a custodial sentence is imposed,
a court must state its reasons for being satisfied that the offence is so serious that no other sanction would be
appropriate and, in particular, why a YRO with intensive supervision and surveillance or fostering could not be
justified.” (emphasis in the original)

8. That paragraph is strongly emphasised in the submissions in support of the appeal as pointing towards a Youth
Rehabilitation Order (YRO) with Intensive Supervision and Surveillance (ISS) as the first sentence to be considered
in the event of the custodial threshold being crossed for a child or young person.

9. That is a point also made in paragraph 82(7) of ZA, which says:

“If the court considers that the offence(s) is (are) so serious as to pass the custody threshold, the court must
consider whether a YRO with ISS can be imposed instead. If it cannot, then the court must explain why.”

10. The appellant is now [an age]. There was a pre‑sentence report before the judge. It recommended a YRO but

did not recommend a YRO with ISS or discuss that possibility at any length.

11. Should the appeal succeed and should it be decided that a non‑custodial option should be adopted, the Court

does not yet have sufficient information by way of reports to allow it to consider (if it thinks fit) a sentence for this [an
age] year old appellant which, although it cannot now be a YRO with ISS because of the age he has now reached,
might be something like the adult equivalent, such as a Community Order with specific conditions.

12. We are therefore directing that such a report should be prepared by way of addendum to the PSR. In saying
that we in no way fetter the Court which considers this appeal, either as to whether the appeal is allowed or as to
what should happen if it is allowed. We are making sure that the Court has all the material it needs in order to
dispose of the appeal in the way that it thinks fit, whatever that might be.

13. There is another matter, which is that the existing pre‑sentence report (paragraph 34) says:

“An NRM [National Referral Mechanism] referral was first submitted for [Kovalkov] in April 2020 where a finding of
reasonable grounds was made. A further application was made on 9[th] August 2022, where the additional
information was provided. A finding of Conclusive Grounds to accept that [Kovalkov] is a victim of modern-day
slavery was returned on 16[th] August 2022.”

14. It seems that at the sentencing hearing no further information about that aspect was available and the
submissions made on behalf of Kovalkov simply referred to that paragraph without explaining it or expanding upon
it.

15. The inclusion of this passage as the conclusion of paragraphs 28 – 34 of the Pre Sentence Report suggests
that the report writer considered it relevant to sentence. It may be particularly relevant to what is said at para 30:

“[Kovalkov's mother] said that in February 2020 [he] went missing for a week and was found in Colchester. On
returning she said he was visibly dirty and appeared frightened. [She] said [he] went to his room when he got home


-----

and did not leave it for a few days. From this point everything he does has been for his friends. [She] feels that if

[he] could move away from his group of friends, then he would be in a much better and safer position. [She] stated
that she has noticed that [he] has come home with money, but he doesn't keep it, it is gone by the next day (…)

[She] believes that [he] is being exploited by his friends”

16. However, it is not clear from the report what the facts behind the Conclusive Grounds finding of modern-day
slavery were, or what information was provided to the NRM about it, or, therefore, what if any relationship there is
between the offending for which Kovalkov was being sentenced and his position as a victim of modern-day slavery.
His solicitor, who represented him at the sentencing hearing, and who also represents him on this appeal, was not
able to enlighten us any further, save to say that his client made it clear he did not want those matters to be
explored on his behalf and he respected his client's instructions in that respect.

17. It seems to us that the modern slavery finding might be relevant to the offending which is the subject matter of
the appeal.

18. It is essential that details of the NRM findings and the factual basis of the findings should be made available to
the Court which next considers this matter and we have asked the probation service to research and provide that
information, which it has kindly agreed to do.

19. We are directing that an addendum to the Pre Sentence Report should be prepared, within 28 days, dealing
with the adult sentencing options that would approximate to the effect of a YRO with ISS for the appellant in this
case; for example, a Community Order with identified conditions attached.

20. The Appellant is to lodge 7 days after receiving the addendum pre-sentence report a new or updated skeleton
argument which is specifically directed to the appeal as it now stands, limited to the matters upon which leave has

been given, addressing also the ZA case and the Guideline and the addendum pre‑sentence report, and the

**_modern slavery aspect. Mr Spary has indicated that the appeal against the length of the Criminal Behaviour Order_**
is not pursued, so that will be omitted.

21. The Respondent is to file a Respondent's Notice, also 7 days after receiving the addendum to the pre-sentence
report. The Respondent may attend the next hearing if so advised.

22. The appeal will be re-listed to be heard by the Full Court thereafter on an expedited basis, bearing in mind that
the appellant is in custody. We do not reserve it to ourselves.

Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part
thereof.

Lower Ground, 18‑22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

