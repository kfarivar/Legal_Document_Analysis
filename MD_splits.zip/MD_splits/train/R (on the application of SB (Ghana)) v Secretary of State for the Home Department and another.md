# R (on the application of SB (Ghana)) v Secretary of State for the Home
 Department and another [2020] EWHC 668 (Admin)

Queen's Bench Division, Administrative Court (London)

John Kimbell QC (sitting as a deputy judge of the High Court)

20 March 2020Judgment

**ALTHEA RADFORD (instructed by Duncan Lewis Solicitors) for the Claimant**

**BENJAMIN SEIFERT (instructed by the Government Legal Department) for the First Defendant**

The Second Defendant did not appear and was not represented

Hearing date: 15 October 2019

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**John Kimbell QC, sitting as a Deputy High Court Judge:**

**Introduction**

1. The Claimant ('SB') is a 37 year-old man from Ghana. Following the service of a deportation order on
30 October 2018, he was detained by the First Defendant ('SSHD') under section 2(3) of Schedule 3 to the
Immigration Act 1971. The detention lasted from 2 November 2018 until 17 June 2019, a period of 7
months and 15 days.

2. SB says that his detention was unlawful because the SSHD breached the principles first set out in R v
_Governor of Durham Prison, ex parte Hardial Singh [1984] 1 WLR 704and developed in subsequent case_
law. He also alleges that the SSHD failed to comply with her own policy on detention in relation to adults at
risk. A further pleaded allegation that her conduct breached SB's rights under Article 5 of the European
Convention on Human Rights was not pursued.

3. The SSHD denies that the detention of SB was unlawful at any stage and denies any breach of public
law or human rights law.

**Permission**

4. SB was granted permission to bring this claim by John Bowers QC, sitting as a Deputy High Court
Judge, on 16 July 2019. The claim for damages against the Second Defendant was transferred to the
County Court and stayed pending the outcome of the challenge to the legality of SB's detention made in
this claim.

**Representation and evidence**

5. SB was represented by Althea Radford of counsel. The SSHD was represented by Benjamin Seifert of
counsel. Neither party relied on any witness evidence.


-----

6. A witness statement by SB, dated 18 September 2019, was originally included in the bundle. However,
the SSHD disputed the Claimant's right to rely on this evidence because an agreed deadline to make an
application to rely on witness evidence had not been met by SB. Ms Radford did not pursue an application
for permission to rely on the witness statement.

7. No attempt was made by the SSHD to adduce witness evidence at any stage. Both parties therefore
sought to rely on a mosaic of reports, assessments, interviews and other documentation about SB from a
number of sources.

**Factual Background**

8. SB was born in Ghana in January 1983. He was brought up by his grandmother. In a Home Office
interview in 2017 he said that he had lost both his parents in a car crash when he was very young. In an
interview a year later with an employee of the National Offender Management Service ('NOMS') he stated
that his parents had separated and his mother had died when he was five.

9. SB worked as an electrician in Ghana and had lived there independently until he came to the UK in
2011. He entered the UK legally on a visitor's visa in March 2011. The visa was valid for six months from
18 March 2011 to 18 September 2011. SB did not leave when his visa expired or apply to renew it. He
therefore remained in the country illegally after 18 September 2011.

10. In his interview with the Home Office in November 2017, SB said that he had submitted an application
in 2012 to stay in the UK but “I never heard anything back before my arrest in 2014”. Home Office records
showed that SB had indeed submitted an application for an EEA residence card in November 2012.
However, far from not hearing about the result of that application, Home Office records showed that SB
had been notified that the application had been refused. Following a request to resend the decision letter in
November 2013, SB lodged an appeal against the refusal. This appeal was later withdrawn.

11. In the same Home Office interview in 2017 that I have already referred to, SB stated that he married
TT, a Ghanian national living in England, in July 2013. However, in a subsequent interview in 2018, SB
referred to her as his girlfriend. When NOMS telephoned TT she told them that she and SB had been “in a
relationship for a few months” but that they had not resided together. TT lived in Colchester. SB appears to
have lived in Milton Keynes where he worked casually for cash as a car valet and in a warehouse.

12. TT gave birth to a daughter on 27 October 2014. TT and SB both state that SB is the child's father.

**Conviction**

13. In April 2015, SB was convicted on two counts of rape in the Aylesbury Crown Court. The offence was
committed on 3 August 2014 in Milton Keynes.

14. In an Offender Assessment System ('OASYS') report dated 28 September 2018, SB's offence is
described as follows:

“Victim, who was a stranger to [SB], was raped while walking home alone at 1 a.m. after a night out. She
was intoxicated. [SB] who was walking in the opposite direction after leaving a party, attempted to engage
her in conversation. [SB] suggested they could have sex. When the victim refused, he followed her and
touched her inappropriately “all over”. When she told him to “fuck off” [SB] bent her over a car bonnet,
pulled down her tights and knickers and raped her first anally then vaginally. He did not use a condom”

15. The offence was described in similar terms by the trial judge in his sentencing remarks:

“On Saturday 2nd of August last year [XX] who was eighteen years old, went out with her friends in Milton
Keynes…At about one o'clock on the Sunday morning, you met [XX] as she walked home from her night
out and you were making your way to a club in Milton Keynes with other males from the party. The rest of
the group were polite and exchanged greetings with that young woman and they walked on. You did not. At
first you appeared to help her by picking up items that she had dropped. However, it quickly became
apparent that you were not going to leave her until you got what you wanted. A sound recording, retrieved
from nearby closed-circuit television camera, capture at first her pleading with you to be left alone, but then
her pleas became increasingly desperate


-----

Ultimately, your victim was raped by you, first anally and then vaginally as you pinned her down over a car
and you held your hand over her mouth to stifle her screams. You continued to rape her until you were
challenged by two passers-by who bravely intervened and disturbed you. You ran away and you were
chased by those two men, but when they stopped you, you talked your way of the situation and they
allowed you to go”

16. The judge went to describe how SB had put forward a defence that the victim had consented to sex.
This led to the victim having to relive the whole experience again in court.

17. The Judge noted that SB had suggested to the Probation Service that the victim had had consensual
sex with him before being raped by another man and noted that the Probation Service had concluded that
SB posed a high risk of harm to adult females and a high risk of sexual offending.

18. TT was six months pregnant at the time of the offence.

**Sentence**

19. SB was sentenced to 8 years' imprisonment in June 2015.

**Correspondence on deportation**

20. On 15 September 2016, SB wrote to the SSHD about the threat of deportation. He claimed in that
letter that there were people in Ghana who threatened his life. He repeated this in another letter sent on 23
December 2016.

21. No response from the SSHD to either of the above letters appeared in the hearing bundle.

22. On 30 January 2017, the SSHD sent SB a decision letter informing him that she intended to deport
him. The letter gave him 20 days to respond.

23. On 3 February 2017, SB signed a disclaimer form stating that “I am aware that I have an opportunity to
lodge representations against my deportation but I wish nevertheless to leave the United Kingdom without
doing so”. SB's signature was witnessed by a prison officer.

24. SB followed up the disclaimer form with a handwritten letter dated 6 February. In this letter he wrote: “I
have receive my deportation order which say I should sign and go back to Ghana. I have sign it and now I
want to know when I am going”. He continued: “I want to know my date because I was set up with a drug
gang before I came here and now there are a lot of people who want to kill me because of this rape
allegation”.

25. SB obtained legal advice at this time. Solicitors acting for SB sent a letter to the SSHD dated 9
February 2017 which said: “We are instructed by our client to notify you that he has considered his position
in the UK and, due to a change in his family circumstances, he has agreed to cooperate with the
deportation process and return to Ghana. He therefore does not intend to challenge deportation.”

26. In a letter sent just under two weeks later, SB again referred to being set up by a criminal gang to
come to the UK. However, the letter ends by referring to the fact that SB has signed deportation papers
and is “getting deported”.

**A change of position on deportation**

27. In a letter dated 11 March 2017, SB changed his position. In this letter he says in terms that he doesn't
want to be deported and asks for a second chance. Further letters followed in a similar vein.

**Formal notice of an asylum claim**

28. On 7 July 2017, the same solicitors who had previously written to the SSHD sought an interview for SB
in order that he might set out all the facts relied upon in support of his asylum claim. Their letter refers to
two threats. First, a threat arising from the fact that SB's rape conviction may become known in Ghana and,
secondly, from the alleged drug gang who it was alleged had set up SB to come the UK.


-----

29. The SSHD's internal records show that by 14 November 2017, it was clear to the Home Office that SB
was making an asylum claim. That, of course, ought to have been clear since the letter of 7 July 2017 from
SB's solicitors.

**Interview**

30. The SSHD arranged for SB to be interviewed at HMP Stafford on 21 November 2017. I have already
referred to some of the things said by SB in that interview. In the health section, there is a reference to SB
taking medication for depression. This is corroborated by the prison medical notes which were included in
the hearing bundle.

31. Following the interview, SB was informed on 18 December 2017 that his asylum claim was being
considered.

32. In the same month, SB was assessed by NOMS as posing a low risk of re-offending but a high risk of
serious harm to the public. He was assessed as having a high likelihood of sexual re-offending.

33. In June 2018 following a transfer to HMP Huntercombe, SB's depression was assessed as being in the
moderate range. His anxiety was assessed as mild.

**Response to the asylum claim**

34. SB's asylum claim was rejected by the SSHD on 31 July 2018 pursuant to s. 72(2) of the Nationality
Immigration and Asylum Act 2002.

35. Notwithstanding the rejection of his asylum claim the preceding month, in August 2018 the medical
notes state that SB's mood is improving following a change in medication and that he was receiving
relaxation therapy.

**Referral to the NRM**

36. In October 2018, the SSHD began processing the documents necessary for transfer from prison to
immigration detention. At around the same time an SSHD case handler noted that SB had made a human
trafficking allegation. His claim was referred to the National Referral Mechanism ('NRM').

**Immigration detention begins**

37. 2 November 2018 marked the halfway point of SB's prison sentence. However, SB was prevented
from being released by service of an IS.91R form dated 30 October 2018.

**Reasons for detention**

38. The IS.91R form informed SB that he was being detained because: (a) he was likely to abscond if
granted immigration bail and (b) his release was not considered conducive to the public good.

39. Four factors were identified to justify his detention:

i) Failure to comply with conditions of stay, admission or release.

ii) No evidence of lawful basis for being in the UK.

iii) Unacceptable character, conduct or associations.

iv) Likelihood of failing to comply with bail conditions.

40. The assessment underlying the decision set out in the IS.91R letter is contained in a detention & case
progression review document dated 29 October 2018. The document is signed by both a reviewing
executive officer and authorising higher executive officer. Detention was authorised for 28 days. The
reason for detention was stated as being that: “The presumption of liberty is outweighed at present by the
high risk of absconding and harm posed by [SB].”

41. A further detention review document signed by the same authorising officer only four days later on 1
November 2018 contained an identical assessment as the previous DRD but added this comment: “We


-----

need to monitor the [potential victim of trafficking] claim and to this end we need to consider his release via
a release referral, which has been drafted”.

42. On 6 November 2018 SB was transferred to IRC Campsfield.

**The Rule 35(3) Report**

43. On 17 November 2018, SB was examined by a Home Office doctor. The doctor reported that SB's
history, scars and presentation were consistent with SB having been a victim of torture.

44. On 26 November 2018, the SSHD accepted that SB met the criteria for a Level 2 Adult at Risk as
defined in the SSHD's Adults at Risk in Immigration Detention Policy of July 2018 ('the AAR Policy').
However, the SSHD nevertheless maintained detention was justified because the risk of harm to SB was
outweighed by immigration control considerations.

45. On 1 December 2018, SB was sent a report. This noted that he had made a modern slavery claim
and that he claimed to be a victim of torture. SB was notified that notwithstanding that it was accepted that
he met the criteria for a Level 2 Adult at Risk, his detention was being maintained.

**First Monthly Detention Review**

46. On 7 December 2018, the SSHD conducted her first monthly detention review ('DR1'). In it the
following was said:

i) The risk of SB absconding, if released, was assessed at medium.

ii) The risk of harm was assessed as high (based on the remarks of the sentencing judge).

iii) The risk of re-offending was assessed as medium.

47. On 13 December 2018, SB was transferred to IRC Heathrow.

**First application for bail**

48. On 21 December SB made an application for bail to a judge of the First-Tier Tribunal (Immigration and
Asylum Chamber). The application was refused. The reasons for the decision were as follows:

“1. The applicant has a bad immigration history. He entered as a visitor in 2011 and overstayed. He made
an EEA application more than a year later and lodged an appeal against the refusal, only to withdraw that
appeal thereafter. He then remained unlawfully in the UK until he was arrested for rape in October 2014.
The aspects of his history suggest a lack of regard for immigration control.

2. I am also required to consider – as a result of schedule 10 of the Immigration Act 2016 – the likelihood of
the applicant committing offences whilst on immigration bail. The view of the applicant's Probation Officer is
absolutely clear in that regard. Despite the rehabilitative work he has undertaken in prison, including work
around his alcohol consumption, he is said to be a high risk of harm to lone females. The facts of the
offence which underpin that conclusion are shocking and led the officer to conclude, inter alia, that the
applicant has 'degrading attitudes towards women, possibly linked to cultural views of white women' (page
20 of the OASys report refers).

3. I bear in mind that the applicant has been in detention since early November; that he is said to enjoy a
relationship with his four year old daughter (despite the fact that his relationship with her mother has
ended); and that he has outstanding claims for asylum and a referral to the Competent Authority as a
PVOT. Nevertheless, I consider there to be a very high risk of absconding and a high risk of further
offending, even if he were bailed on strict conditions to an approved address. In the circumstances bail is
refused.”

**Second Monthly Detention Review**

49. In the second monthly detention review dated 28 December 2018 ('DR2'), the assessments of the risk
of absconding, harm and reoffending remained unchanged. The refusal of bail was noted. Under action for


-----

the next review period, the following was said: “awaiting response for the competent authority before we
can decide to release or maintain detention.” The reviewing officer said:

“Please ascertain a timeframe for the PVOT claim along with monitoring the asylum decision. We must
ensure this progresses. I agree to maintain detention for a further 28 days at this stage”.

50. On 16 January 2019, SB was found by his cell mate with a ligature. SB's stated intention was selfstrangulation. On being interviewed SB was assessed as:

“struggling with personal problems being exacerbated by continued detention, combination of issues is
triggering low mood, however, no clinical features evident of psychotic illness or impaired thought
processes”.

**Third Monthly Detention Review**

51. A third detention review took place on 29 January 2019 ('DR3'). The key assessments remained the
same and no change of circumstances was noted.

**Second Bail application**

52. On 30 January 2019 two things happened:

i) A second application for bail was refused by a different First-Tier Tribunal Judge for the same reasons
as the first application. However, the judge added the following comment: “I am very concerned about the
risk he poses if released and for that reason I think he should remain in custody”.

ii) The SSHD decided that there were no reasonable grounds for suspecting that SB had been the victim
of trafficking. This was based on alleged inconsistencies in his account.

**Fourth Monthly Detention Review**

53. On 26 February 2019, a fourth Monthly Detention Review ('DR4') was undertaken. The authorising
officer recorded that SB's mental state was “stable and managed”. SB's removal was said to be expected
“within a realistic timeframe” but without any periods of time actually being given in which the various
obstacles to deportation identified by the SSHD were expected to be overcome.

**Third bail application**

54. On 13 March 2019, SB made a third bail application. The judge of the First-Tier Tribunal refused it. His
reasons were:

“Detention remains a proportionate response to the risk of absconding and further offending presented by
the applicant. He has been assessed as presenting a high risk of harm by the probation service, having
been convicted of two counts of rape, with a total sentence of imprisonment of 8 years. I am not satisfied
that the applicant's assurances that he no longer presents a risk are capable of overruling the formal
OASys assessment. He does not have an address approved by the probation service, and I am not willing
to grant so-called “bail in principle” on the speculative basis that the Home Office may, at some point in the
future, provide such accommodation to him”

**Fifth Monthly Detention Review**

55. On 26 March 2019 a fifth Monthly Detention Review ('DR5') recorded no significant change since the
DR4. It was, however, recorded that a decision had been made in relation to SB's asylum and human
rights claims which would be served on him “once approved”.

**SSHD decision on protection and human rights claim**

56. On 3 April 2019, the SSHD issued her notice of decision on SB's asylum and human rights claim. The
claims were rejected. The SSHD certified that the presumptions in section 72(2) of Nationality, Immigration
and Asylum Act 2002 ('the 2002 Act') apply to SB. The SSHD did not, however, issue a certificate under
section 94(1) of the 2002 Act that SB's claims were manifestly unfounded The absence of the latter


-----

certificate meant that SB had the right to an in-country appeal to the First-Tier Tribunal (Immigration and
Asylum Chamber) under section 82(1) of the 2002.

**SB's appeal**

57. On 16 April 2019, SB exercised his right of appeal. Two days later, SB was moved from IRC Heathrow
to IRC Morton Hall.

**Application to reconsider NRM decision**

58. On 25 April 2019, solicitors acting for SB submitted an expert report under cover of a letter asking the
SSHD to reconsider the NRM decision of 30 January 2019.

**Sixth Monthly Detention Review**

59. On 23 April 2019, the sixth monthly detention review ('DR6') took place. The authorising officer
recommended that “progress should be made” with emergency travel documentation and that the SSHD
should “closely monitor any appeal”. The reviewing officer was clearly unaware that an appeal had already
been lodged by SB.

**Issue of Judicial review proceedings**

60. On 17 May 2019, this claim for judicial review was issued.

**Seventh Monthly Detention Review**

61. On 22 May 2019, the seventh and final detention review took place ('DR7'). The authorising officer
now appreciated that SB had lodged an appeal against the dismissal of his asylum claim. No likely
timescale for the disposal of the appeal was provided. The action proposed for the next period of detention
was simply to “monitor the appeal outcome and initiate removal when appeal rights exhausted”.

**Reasonable grounds decision**

62. On 27 May 2019, the SSHD withdrew her previous negative reasonable grounds decision of 31
January 2019 and replaced it with a decision that there were reasonable grounds to conclude that SB had
been a victim of modern slavery. The letter notifying SB of the decision informed him that no conclusive
grounds decision would be made for at least 45 days. Just before the handing down of this judgment the
SSHD stated that she hoped to reach a decision within another 3 months.

**Dismissal of asylum appeal**

63. On 30 May 2019, SB's asylum appeal was dismissed in the First-Tier Tribunal. SB was subsequently
granted permission to appeal to the Upper Tribunal but the appeal itself was dismissed on 21 November
2019.

**Release from detention**

64. On 17 June 2019, SB was released on bail to Home Office approved accommodation.

**Legal principles**

65. In R. v Durham Prison Governor ex p Hardial Singh [1984] 1 WLR 704, Woolf J. heard an application
for a writ of habeas corpus. The applicant was a 26 year-old man, who had entered the UK from India
legally six years earlier and who had indefinite leave to remain in the UK. While living in the UK he was
convicted of two offences of burglary for which he was given a sentence of two years' imprisonment. He
would have been released on 20 July 1983 but the Home Secretary made a deportation order. Mr Singh
was then detained under paragraph 2(3) of Schedule 3 of the Immigration Act 1971.


-----

66. By the time the application was heard on 13 December 1983, Mr Singh had been detained for a week
short of six months. Having reviewed the available evidence about the circumstances of Mr Singh's
detention, Woolf J concluded:

“If the matter ended there, for my part, I would regard this as a case where the applicant was now entitled
to a writ of habeas corpus or an order for his release. I would take the view that the implicit limitations
imposed on the power of detention contained in the Act had not been complied with”

67. The following passage from Woolf J.'s _ex tempore judgment has been cited in many subsequent_
cases. It describes (at p.706D-F) the implicit limitations on the power to detain people under paragraph
2(3) of Schedule 3 of the Immigration Act 1971 as follows:

“Although the power which is given to the Secretary of State in paragraph 2 to detain individuals is not
subject to an express limitation of time, I am quite satisfied that it is subject to limitations. First of all, it can
only authorise detention if the individual is being detained in one case pending the making of a deportation
order and, in the other, pending his removal. It cannot be used for any other purpose. Secondly, as the
power is given in order to enable the machinery of deportation to be carried out, I regard the power of
detention as being impliedly limited to a period which is reasonably necessary for that purpose. The period
which is reasonable will depend upon the circumstances of the particular case. What is more, if there is a
situation where it is apparent to the Secretary of State that he is not going to be able to operate the
machinery provided in the Act for removing persons who are intended to be deported within a reasonable
time, it seem to me that it would be wrong for the Secretary of State to seek to exercise his power of
detention.

In addition, I would regard it as implicit that the Secretary of State should exercise all reasonable
expedition to ensure that the steps are taken which will be necessary to ensure the removal of the
individual within a reasonable time”

68. Woolf J's analysis of whether Mr Singh's detention had gone on for an unreasonably long time in light
of the principles he had enunciated occupied less than one and half pages of the judgment. Because the
application before the court was for a writ of habeas corpus, the court faced a binary choice. Either the
detention had gone on too long and the writ should be issued or it had not and the writ to the prison
governor ordering Mr Singh's release should not be issued. In fact, Woolf J. was persuaded to allow the
Secretary of State an adjournment for three days to put in more evidence.

69. In _Hardial Singh itself Woolf J was not concerned with ascertaining the precise day on which the_
detention had ceased to be lawful for the purposes of a claim of damages for unlawful detention. However,
since 1983 the _Hardial Singh principles have been frequently applied in that manner. It has become_
common for the court to engage in detailed analysis of detention and case review documents, offender
assessment records and other documents in an attempt to ascertain the day on which one or more of the
Hardial Singh principles are “breached” so as to give rise to a claim for damages for unlawful detention.

70. That the court is required to consider whether the _Hardial Singh principles have been “breached”_
rather than merely “engaged” is clear from see R. (AC) Algeria v SSHD _[2020] EWCA Civ 36 [28] – [29]._

71. The way in which the Hardial Singh principles have come to be applied is a radical departure from the
usual approach of public law review. Judicial review is usually a supervisory jurisdiction, as described by
Lord Clyde in Reid v Secretary of State for Scotland [1999] 2 AC 512 at 541F:

“Judicial review involves a challenge to the legal validity of the decision. It does not allow the court of
review to examine the evidence with a view to forming its own view about the substantial merits of the
case.”

72. In Hardial Singh judicial review claims, however, a different approach is taken. Rather than ask in the
conventional way whether in detaining a person the Secretary of State has taken account of irrelevant
considerations or reached a conclusion that no rational decision maker could have reached, the court in a
_Hardial Singh case is required to substitute its own view for that of the Secretary of State on the basis of_


-----

the same primary material as was available in real time to the Secretary of State - see _R(Muqutaar) v_
_Home Secretary [2013] 1 WLR 649 at [48]:_

“It is well established that in applying the Hardial Singh principles the court must form its own judgment (for
example, as to whether a reasonable period has been exceeded) rather than reviewing on Wednesbury
grounds a judgment made by the executive”

73. This unusual feature of the Hardial Singh jurisdiction has been commented upon by Elisabeth Laing J.,
writing extra-judicially:

“The most striking aspect of the decision in Hardial Singh as it has been subsequently explained is that it is
the court is the primary decision maker. It decides what period of detention is reasonable, rather than
reviewing that period on Wednesbury grounds. Woolf J did not explain why he took the approach which he
did, other than to say that the apparently unfettered power of detention must be subject to some implied
limit. A possible justification for making the court, rather than Secretary of State, the primary decision
maker is that if the power (however it is circumscribed) is exceeded, the finding that the detention is
unlawful means that a tort is has been committed, as well as a public law wrong.”1

74. The Hardial Singh principles themselves were recast by Lord Dyson JSC in R.(Lumba)v Secretary of
_State for the Home Department [2012] 1 AC 245 at 264H in the following form:_

[1] The Secretary of State must intend to deport the person and can only use the power to detain for that
purpose

[2] The deportee may only be detained for a period that is reasonable in all the circumstances

[3] If, before the expiry of the reasonable period, it becomes apparent that the Secretary of State will not be
able to effect the deportation within a reasonable period, he should not seek to exercise the power of
detention

[4] The Secretary of State should act with reasonable diligence and expedition to effect removal.

75. The principles are often referred to by advocates and judges by the shorthand “HS1- 4” – see e.g. R.
_(AC) Algeria v SSHD_ _[[2019] EWHC 188 (Admin).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TSC-5TY2-8T41-D1TX-00000-00&context=1519360)_

76. In the course of their written and oral submissions I was referred by counsel to a large number of
authorities including: R(I) v SSHD _[2002] EWCA Civ 888,_ _R(Khadir) v SSHD [2006] 1 AC 207,_ _R(S) v_
_SSHD_ _[2007] EWCA Civ 546, R(A) v SSHD_ _[2007] EWCA Civ 804, R(MH) v SSHD [2010] EWCA 1112, R._
_(Krasniqi) v SSHD_ _[2011] EWCA Civ 1549,_ _R (Sino) v SSHD [2011] EWHC 2249,_ _R (Lumba) v SSHD_

[2012] 1 AC 245, R(Muqtaar) v SSHD [2013] 1 WLR 649, Saleh v SSHD _[2013] EWCA Civ 1378, R(O) v_
_SSHD [2016] 1 WLR 1717,_ _R(H) v SSHD EWCA Civ 565,_ _BJ (Gambia) v SSHD [2016] 1035,_ _R(AXD) v_
_Home Office [2016] EWHC 1133,_ _R(Qarani) v SSHD [2017] EWHC 507 and_ _R(TDT) Vietnam v SSHD_

[2018] 1 WLR 4922.

77. In addition, I invited counsel to address me on R(AC) Algeria v SSHD _[[2019] EWHC 188 (Admin) and](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8TSC-5TY2-8T41-D1TX-00000-00&context=1519360)_

_[2020] EWCA Civ 36, R (Gasztony) v SSHD_ _[2019] EWHC 2879 (Admin) and R(Jonas Lauzakas) v SSHD_

_[2019] EWCA Civ 1168._

78. The main principles which I draw from these cases may be summarised as follows:

i) The starting point for any challenge to detention is that, as Lord Atkin said in his dissent in Liversidge v
_Anderson [1942] AC 206, at 245, “every imprisonment is prima facie unlawful and that it is for the person_
directing imprisonment to justify his act”: cited in Lumba, at [44] (Lord Dyson).

ii) When applying HS1-4, the court must form its own judgment (for example, as to whether a reasonable
period has been exceeded) rather than reviewing on normal judicial review grounds the legality of the
detention decision made by the SSHD - R(Muqutaar) v Home Secretary [2013] 1 WLR 649 at [48].

iii) Even though they have been approved by the Supreme Court, HS1-4 are not statutory rules and must
not be rigidly or mechanically applied – see Carnwath LJ in R (Krasniqi) v SSHD _[2011] EWCA Civ 1549_

[12] and Lumba [115].


-----

iv) What amounts to “a sufficient prospect” and what is a “reasonable period” for the purposes of HS2 and
HS3 in any particular case is a heavily fact sensitive enquiry.

v) The risk of absconding and the risk of reoffending are always of “paramount importance” - see Lumba at

[121].

vi) There must come a time when, however grave the risk of absconding and however grave the risk of
serious offending, it ceases to be lawful to detain a person pending deportation - see Lumba at [144].

vii) The court is ultimately required to perform a balancing exercise of all the relevant risk factors weighed
against each other. No one factor is a trump card - _see R(AS) Somalia v SSHD_ _[[2019] EWHC 1831](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8VYD-N7M2-8T41-D1T2-00000-00&context=1519360)_
_[(Admin) citing R (MH) v SSHD](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:8VYD-N7M2-8T41-D1T2-00000-00&context=1519360)_ _[2010] EWCA Civ 1112) and R(Shafiq-ur-Rehman) v SSHD_ _[2013] EWHC_
_1280 (Admin) at [27]._

viii) The balance may shift over time: “As the period of detention gets longer, the greater the degree of
certainty and proximity of removal I would expect to be required in order to justify continued detention.” see R(MH) v SSHD [2010] EWCA 1112 at [68] per Richards LJ.

ix) For the purposes of HS3, mere uncertainty is insufficient: release from detention is only required if and
when it is apparent that there is no real prospect of removal within a reasonable time – _R (Muqtaar) v_
_SSHD [2012] EWCA Civ 1270; [2013] 1 WLR 649 at [36]-[38]). See also to the same effect Supperstone J_
in MR (Pakistan) & Anor, R (On the Application Of) v Secretary of State for Justice & Ors _[2019] EWHC_
_3567 (Admin) (20 December 2019) at [125]._

x) In considering whether there has been a breach of HS4, it is not enough that some part of the process
is shown to take longer than it should have done. The dividing line between mere administrative failing and
illegality will be crossed only where, as a result of the failure, the claimant has been detained longer than
he would otherwise have been - see R (Krasniqi) v SSHD _[2011] EWCA Civ 1549 at [12]._

xi) Although the court cannot be expected to carry out a time and motion study in relation to each day or
week of detention long periods of unexplained inactivity are likely to cross the line into unreasonable delay
– see R (Saleh) v Secretary of State for the Home Department _[2013] EWCA Civ 1378 at [60] (8 months of_
a total of 12 months in detention declared unlawful).

xii) The principles must be applied upon the basis of what was known to the officers of the Secretary of
State at the relevant time (i.e. hindsight must be avoided) but the court can take into account any facts
known to the SSHD even if they did not feature in the reasons for detention: see _R(MS) v SSHD [2011]_
EWCA 938.

xiii) The views on the risk of reoffending and absconding expressed by judges who have refused
applications for bail are relevant but not determinative – see R(Abdollahi) v SSHD _[2013] EWCA Civ 366 at_

[50].

**Application of law to the facts**

79. Ms Radford's first submission was that the entire period of detention was unlawful because of (i) the
significant delay in 2017 in scheduling a screening interview in relation to SB's asylum claim and (ii) the
delay in referring SB's modern slavery claim to the NRM. This submission seemed to me to come very
close to saying that the SSHD was in breach of HS4 even before the period of immigration detention
began. I reject it. In my judgment, it is inappropriate to engage in a process of looking for a breach of HS4
before immigration detention has even begun. Of course, any delays before immigration detention in
dealing with claims which are themselves obstacles to removal will form part of the overall circumstances
against which the justification for detention has to be assessed but, in my judgment, it can go no further
than that. The delays will in other words form part of the background against which the balancing of factors
takes place.

80. For the purposes of analysis, I propose to divide the detention into three periods.

**Period 1: 2 November 2018 – 30 January 2019 (DR1 -3)**


-----

81. During this period, the factors weighing in favour of justified detention were as follows:

i) The seriousness of the offence: it involved anal and vaginal rape of a randomly encountered young
vulnerable woman in a public place. The offence was very clearly at the very serious end of the spectrum
of offences.

ii) **The risk of absconding: I have no evidence which could cause me to doubt the accuracy of the**
assessment of the risk of absconding as medium, as recorded in DR1 – 3. This was entirely justified given
SB's poor immigration record which involved a conscious overstaying. I was not impressed by SB's
misguided attempt to suggest that he had made an application to regularise his immigration status but had
'heard nothing' from the Home Office, whereas in fact his application for an EEA residence card had been
rejected, he had appealed that decision and then withdrawn his appeal. Whilst I take on board Ms
Radford's point that SB's ongoing relationship with his daughter (albeit confined to telephone contact) is a
mitigating factor, I do not accept that this is significant enough to displace the overall assessment of risk,
not least because it was perfectly possible for SB to have absconded and still kept in contact with his
daughter by telephone.

iii) **The risk of re-offending: I also have no reason or evidence which casts any doubt on the overall**
assessment of the risk of reoffending as medium. The risk of serious harm to adult females (not known to
SB) was assessed as high and SB was assessed as having a high risk of further sexual offending. Whilst it
was to SB's credit that following sentencing he came to accept his offending behaviour and was motivated
to attend a sex offender treatment programme, nevertheless, as the OASYS Assessment of 28.09.18
noted, the assessor had concerns about SB having degrading cultural attitudes towards young white
females. The same report concludes that “his description of his sexual relationships suggests that a
position of male privilege/entitlement in relation to partnerships, with women being the property of men”.
The report concludes that there is in SB's case “a clear link between relationships with women and the risk
of harm/offending”.

iv) **The two negative decisions on bail: within the period I am considering two specialist First-tier**
Tribunal judges separately considered SB's immigration history, the rehabilitative work undertaken by him
in prison, his outstanding asylum claim and referral to the competent authority but concluded that the risks
of absconding and further offending meant that SB ought not to be granted bail even on strict conditions at
an approved address.

v) The SSHD's decision on 30 January 2019 that there were no reasonable grounds to suspect that C was
a victim of trafficking.

82. The factors favouring release are:

i) **SB's mental health: SB was assessed early in this period as suffering from moderately severe**
depression, erratic sleep patterns and having suicidal thoughts on which he appeared to have partially
acted when he was found with a ligature intending to self-harm on 16 January 2019. However, on the
evidence I have seen, his mental health was being properly monitored and treated throughout the period I
am considering. He was assessed to be not suffering from any psychotic illness or impaired thought
processes. He was prescribed anti-depressants and ibuprofen.

ii) SB's status as a level 2 Adult at Risk: The SSHD accepted that SB was a level 2 Adult at Risk on the
basis of the Rule 35 Report described above. As a result, the AAR Policy was engaged. Ms Radford relied
on these features of the AAR Policy, in particular:

a) There is a clear presumption that detention will not be appropriate if a person is considered to be at risk
– para 3.

b) Detention ought to be for the shortest period necessary – para 6.

c) Continuing detention will only be appropriate if there are overriding immigration considerations – para 6.

d) In any given case it should be possible to estimate the likely duration required to give effect to removal
– para 14.


-----

iii) The outstanding asylum claim and referral to the NRM.

83. Weighing all the factors above against each other and taking an overall view as required by principle
(vii), as set out in paragraph 78 above, I am not persuaded that there was a breach of the HS2 or 3 in this
first period. Given the seriousness of the offence and the risk of harm arising from re-offending, in
particular, a reasonable period for overall detention had, in my judgement, not yet elapsed within the
meaning of HS2 and that at no point in this first period was it apparent to the SSHD that detention would
continue for an unreasonably long period into the future.

84. In relation to the AAR Policy, whilst I accept the thrust of Ms Radford's submission that the fact that a
detainee is categorised as a Level 2 Adult at Risk is a very significant factor favouring release, I was
persuaded that Mr Seifert was correct to submit as follows:

i) The AAR Policy must be read as a whole. Its purpose is to strike a balance between protecting the
vulnerable and ensuring the maintenance of legitimate immigration control.

ii) Whilst there is a clear presumption in favour of liberty for an adult at risk that does not mean that no
adult at risk will ever be detained.

iii) Paragraph 14 of the AAR Policy does not mandate the SSHD to estimate the precise likely timeframe to
effect removal in every case of an adult at risk. The words “it should be possible to” in my judgment are not
consistent with the existence of a mandatory requirement in every case. In my view what the policy does is
to recommend this approach in particular as a means of determining the risk of harm to the detained
individual.

iv) In any event, paragraphs 14 and 15 need to be read together. Paragraph 15 enjoins the SSHD to
perform a balancing exercise:

“An individual should be detained only if the immigration factors outweigh the risk factors such as to
displace the presumption that individuals at risk should not be detained. This will be a highly case specific
consideration”

85. To the extent that it was submitted that SSHD acted contrary to the AAR Policy as a free-standing
public law ground of challenge, I reject it. The letter dated 26 November 2018, written in response to the
Rule 35 Report, correctly sets out all the relevant factors in a clear and logical fashion. The letter comes to
a reasoned conclusion as to why in SB's case the balance of risk comes out in favour of detention. It was a
decision which in ordinary judicial review terms the SSHD arrived at lawfully.

86. The AAR Policy was in my judgment properly followed throughout this first period in both the monthly
progress reports sent to SB and also in the internal detention and case progression reviews. In the review
completed at the end of January 2019, the authorising officer appropriately asked for a timeframe for the
potential victim of trafficking claim and the asylum decision. The officer considered the presumption to
release under the AAR Policy and balanced it against the immigrational control factors.

87. It is regrettable that it took the SSHD until 30 January 2019 to make a decision on the victim of
trafficking claim and until 3 April 2019 to make a decision in relation to SB's asylum and human rights
claim. Nevertheless, in neither case was it apparent within the period that I am considering that the
decisions could not be made within a reasonable time so as to put the SSHD in breach of HS3. Nor am I
persuaded that weighing all the factors together that the time which elapsed before either decision was
reached was sufficient to give rise to a breach of HS2.

88. The delay in dealing with the two claims was also in my judgment not of such a scale as to constitute a
breach of HS4. The delays seem to me to fall on the administrative failing side of the line rather than on the
illegality side of the line as described in Krasniqi. I am also not persuaded that SB was detained any longer
than he otherwise would have been because of the delays. The detention did not become illegal by reason
of a breach of HS4 during this period.

**Period 2: 1 February 2019 – 2 April 2019 (DR4 – 5)**


-----

89. In my judgment, the factors in play during this period are not significantly different in kind to those in
Period 1. Of course, with the passing of each day the question of whether the balance has now shifted
becomes more acute. However, I am not persuaded that during this period the threshold of unreasonable
detention under HS2 is crossed for the following reasons:

i) The factors weighing heavily in favour of detention as set out above for Period 1 remained unchanged,
in particular, the paramount considerations of the risk of absconding and re-offending.

ii) SB's detention is properly reviewed and the AAR Policy properly taken into account in DR4 – 5.

iii) The SSHD confirmed in writing that a decision on the asylum claim would be reached within three
months.

iv) Whilst SB remained a level 2 adult at risk, his mental condition was noted as being “stable and
managed”.

v) On 13 March 2019, SB again applied to a First-Tier Tribunal judge for bail and it was again refused
based on the key factors of the seriousness of the offence, the risk of harm, the risk of further offending
and of absconding.

vi) In DR5 the authorising officer noted that a deportation decision had been drafted and would be
communicated to SB imminently.

90. Standing back and reweighing all the factors set out above, I am not persuaded that there was a
breach of the HS2 or 3 during Period 2. Although by the end of this second period, SB had spent nearly
six months in detention, a reasonable period for overall detention had in my judgment not yet elapsed
within the meaning of HS2. At no point in this second period was it apparent that detention would continue
for an unreasonably long period into the future. However, given that the six month point was rapidly
approaching, it was entirely appropriate that the SSHD was giving active consideration to terms of release,
as noted in DR5.

**Period 3: 3 April 2019 – 17 June 2019 (DR6 – DR7)**

91. In the third period of detention four key developments occurred:

i) On 3 April 2019, the SSHD refused SB's asylum and human rights claims but chose not to certify the
claims as 'clearly unfounded'.

ii) On 16 April 2019, SB exercised his right of appeal to the First-Tier Tribunal.

iii) On 25 April 2019 an expert report was submitted on SB's behalf by Duncan Lewis Solicitors together
with a request seeking reconsideration of the NRM decision of 30 January 2019.

iv) On 27 May 2019 the SSHD acting in her capacity as the Competent Authority reversed the decision of
30 January 2019. The SSHD now accepted that there were reasonable grounds to suspect that SB had
been a victim of human trafficking.

92. In my judgment, as a result of these events the balance shifted in this period decisively against further
detention and in favour of release to secure accommodation. I have already cited Richards LJ's comment
in MH at [68] that: “As the period of detention gets longer, the greater the degree of certainty and proximity
of removal I would expect to be required in order to justify continued detention.”. In this case the opposite
occurred after the six month mark of detention approached.

93. I accept Ms Radford's submission that when SB lodged his appeal against the dismissal of his asylum
claim to the First-Tier Tribunal on 16 April 2019, it ought to have been apparent to the SSHD that there was
no longer any real prospect of removal within a reasonable period of time.

94. A combination of the time already elapsed in detention (nearly six months) plus the time it would take
for the hearing and judgment of the First Tier Tribunal to be obtained (as well as any application for appeal
to the Upper Tribunal), which I consider to be not less than a further six months, meant that the prospect of
deportation within a reasonable time had vanished at this point.


-----

95. I have not been provided with any evidence of the precise state of the lead times for hearings in the
First-Tier Tribunal and applications for appeal to the Upper Tribunal in April 2019 but no-one with
experience of the immigration and asylum tribunal system would have suggested a time scale of anything
significantly less than a further six months. I note that the absence of statistical data did not prevent the
Court of Appeal reaching a similar conclusion in Lauzikas at [41] on the effect of lodging of an application
for judicial review.

96. In fact, the First Tier Tribunal handed down its decision on 30 May 2019, permission to appeal to the
Upper Tribunal was granted on 22 July 2019 and the decision of the Upper Tribunal was handed down on
22 November 2019. However, as per principle (xii) set out in paragraph 78 above, the question of whether
there was a reasonable prospect of deportation must be posed prospectively from the perspective of how
matters appeared on 16 April 2019 and not with the benefit of hindsight.

97. In my view, looking at matters in April 2019, it ought to have been apparent to the SSHD that a time
frame of no less than a further six months for resolution of the appeal was on the cards. In my judgment,
detention of that length of time following on from the five and a half months that had already elapsed would
no longer be detention pending deportation but rather some form of general preventative detention, which
is not authorised by the statutory power being exercised by the SSHD. It would thus be a breach of HS1, 2
and 3.

98. Furthermore, in my judgment, the SSHD's response to the lodging of the appeal by SB was not in
accordance with the AAR Policy. Given that SB remained categorised as and Level 2 Adult at Risk, the
question which ought to have been asked was of whether in light of the likely timescale for his appeal the
firm presumption in favour of release was still rebutted. However, neither DR6 nor DR7 contains any
assessment of a likely timescale. DR6 merely states that “any appeal needs to be closely monitored” and
DR7 refers to the need to “monitor the appeal outcome”. There is no evidence that the SSHD at any stage
estimated how long the appeal process might take or that she considered the risk of harm that SB might
suffer in that period in the manner described in the AAR Policy.

99. In my judgment, therefore detention after 16 April 2019 ceased to be justified pursuant to HS3, subject
only to a period of grace for arranging secure accommodation, discussed below.

100. I would add that, in my judgment, the SSHD's position became completely untenable on 27 May 2019
when she decided to reverse the previous decision on SB's human trafficking claim. It is well known that
conclusive grounds decisions can take many months to complete. The conclusive grounds decision in SB's
case is still awaited today, nearly a year later. It was therefore obvious that once the SSHD had reversed
her own decision on SB's human trafficking claim that deportation was not going to be possible within a
reasonable time within the meaning of HS3.

101. Detention after 27 May 2019 was therefore a clear breach of HS3, in particular for a detainee
categorised as a level 2 Adult at Risk. Had I not reached the conclusion I have that the prospect of removal
within a reasonable time had already receded by 16 April 2019, I would have held that there was by plain
and obvious breach of HS3 by 27 May 2019 in any event.

102. In light of my findings on HS3, it is not necessary for me to reach a concluded view on whether, and if
so at what point, HS2 was breached prior to his release on 17 June 2019.

**A grace period**

103. On 14 February 2020, I received further submissions from counsel on what, if any, grace period
ought to be allowed to the SSHD once it became clear that continued detention would be in breach of HS3
in light of the decision of the Court of Appeal in R (AC) Algeria v SSHD _[2020] EWCA Civ 36._

104. In R (AC) Algeria v SSHD Court of Appeal held, in summary, that:

i) Once any of the _Hardial Singh principles are breached, any further detention can be lawful for a_
reasonable period to put in place appropriate conditions of release.


-----

ii) The duration of a “grace period” is fact specific. The risk to the public is a “highly important factor” but
any risk posed cannot justify preventative detention: that would be out-with the statutory power to detain.

iii) In future cases, an increased energy and focus should be required of the SSHD in relation to such final
periods of detention: when the question of a grace period arises or might arise the SSHD will be expected
to advance some evidence and to make considered submissions as to what period would be appropriate
and why.

105. The Court considered that given the history of the case, a grace period of around two further weeks
from the date of judgment given below (6 February 2019) was ample. Detention beyond that time was
unlawful.

106. Ms Radford referred to the fact that when SB was due to be released from prison at the end of his
custodial sentence, an application for approved premises was made by National Probation Service on 25th
October 2018 and a place was secured for him in time for his planned released on 2nd November 2018,
i.e. within 8 days. This place was cancelled when the Claimant entered immigration detention.

107. Mr Seifert for the SSHD drew my attention to the fact that following the order of Spencer J. requiring
the Second Defendant to use best endeavours to secure approve premises, it still took nearly a month,
until 17 June 2019, to secure appropriate accommodation. He therefore submits that I should allow the
SSHD a grace period of four weeks.

108. Ms Radford realistically accepted that securing suitable accommodation for SB was not
straightforward. The Claimant required accommodation approved by the probation service, he is a sexual
offender with a medium risk of reoffending but high risk of causing serious harm. She accepted that there
had been a long delay in sourcing him an address after Spencer J.'s order.

109. Having considered all the relevant factors, I consider that in the circumstances of this case two weeks
is the maximum reasonable “grace period” which it is appropriate to allow. It follows that if a grace period of
14 days is allowed following the date on which I have held that it was apparent that removal within a
reasonable time was no longer be possible (16 April 2019), the detention of SB ceased to be lawful when
the grace period expired on 30 April 2019.

**CONCLUSION**

110. It follows that, for the reasons given above, SB is entitled in principle to substantial damages for
unlawful detention from 1 May 2019 until his release on 17 June 2019.

111. The assessment of damages will be carried out in the County Court pursuant to the order of John
Bowers QC, sitting as a Deputy High Court Judge, made on 16 July 2019.

**End of Document**


-----

