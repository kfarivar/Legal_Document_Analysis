# R v Iyamu (Josephine) [2018] EWCA Crim 2166

CA, CRIMINAL DIVISION

Case No: 201803156/A3

LORD JUSTICE DAVIS

Date: Thursday, 20 September 2018

20/09/2018

**J U D G M E N T (As Approved by the Court)WARNING: Reporting restrictions may apply to the contents**
transcribed in this document, particularly if the case concerned a sexual offence or involved a child. Reporting
restrictions prohibit the publication of the applicable information to the public or any section of the public, in writing,
in a broadcast or by means of the internet, including social media. Anyone who receives a copy of this transcript is
responsible in law for making sure that applicable restrictions are not breached. A person who breaches a reporting
restriction is liable to a fine and/or imprisonment. For guidance on whether reporting restrictions apply, and to what
information, ask at the court office or take legal advice.

LORD JUSTICE DAVIS:

Introduction

1. This is an application by the Solicitor General seeking leave to challenge a sentence on the ground that it is
[unduly lenient. The offences in question primarily arise under the provisions of the Modern Slavery Act 2015. The](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
facts of this case, which we will come on to summarise, wholly explain the need for such a piece of legislation;
legislation which by the uncompromising words of its very title connotes the stark criminality of the offending
concerned, where proved. We grant leave in this case.

Background facts

2. The background facts are these.

3. The offender Josephine Iyamu is 51 years old, having been born in 1966. After a trial lasting many weeks at the
Crown Court at Birmingham, before His Honour Judge Bond and a jury, the offender was on 28 June 2018
convicted of five offences of arranging or facilitating the travel of another person with a view to exploitation, contrary
to section 2 of the Modern Slavery Act 2015. In addition, she was also convicted of one offence of perverting the
course of justice.

4. On 4 July 2018 she was sentenced to a total sentence of 14 years' imprisonment. In respect of counts 1 to 5 on
the indictment there were concurrent sentences of 13 years' imprisonment on each count; in respect of count 6
there was a consecutive sentence of one year's imprisonment.

5. The position is this. The offender had been born in Monrovia, Liberia. She subsequently acquired citizenship of
Nigeria and in 2009 she also acquired British citizenship. She was a nurse and qualified to act as a midwife. She
and her husband owned a property in Bermondsey in London and she also had another property in Benin City in
Nigeria.


-----

6. So far as counts 1 to 5 are concerned, the offences took place between 1 May 2016 and 25 August 2017 and
concerned five victims. Those five victims were all identified and traced by the authorities. Victim 1 may be styled
as "S"; victim 2 may be styled as "A"; victim 3 may be styled as "K"; victim 4 may be styled as "F"; and victim 5 may
be styled as "O". In addition, another woman, who may be styled victim six for present purposes, was referred to by
the other victims but was never traced.

7. The victims were all from the Benin City region in the Edo State of Nigeria. They were all aged in their twenties.
They were from poor and in some cases rural backgrounds. They were all from large families. Each of them saw
the prospect of travelling to Europe as offering the means of financial salvation for themselves and their families. In
his sentencing remarks the judge was to describe the victims as "young, naive, trusting and desperate women who
only wanted to make their own lives and the lives of their immediate families better."

8. As had been the Crown case, the offender was known to arrange travel to Europe. The victims were either
introduced to her or met her by chance. They spoke to her about travelling to Europe and the prospect of working
there. With the exception of the first victim, S, all of the victims were made aware that they were going to be
working as prostitutes in Europe. As the judge found, S only found out about the work she was going to undertake
when she finally arrived in Germany. None of the victims, it should be added, had worked as prostitutes in Nigeria.

9. The victims travelled in groups of three on two separate occasions. The first group of three (that is to say victims
1, 2 and the victim styled as victim 6) began their journey before June 2016. The second group (victims 3, 4 and 5)
began their journey after September 2016.

10. A notable and particular feature of this particular case is that before they started on their travels the offender
had made the women attend the address of a priest who practised the art of juju. The victims were to give evidence
to the effect that they were in awe of such practices and felt wholly bound by the ceremonies, oaths and curses
which were placed upon them.

11. Evidence in fact was given during the trial by an expert witness, Dr Hermione Harris, a research associate at
the School of Oriental and African Studies in London. Dr Harris specialises in the field of witchcraft and juju, both of

which are intrinsic to the Nigerian world‑view, as it was said.

12. In summary, Dr Harris gave evidence to the effect that first the victims and their traffickers came from Edo

State in Nigeria, an area well‑known for trafficking. Second, the family situation of the victims, together with their

naivety, lack of education and absence of opportunity, made them susceptible to promises made by traffickers.

Third, Edo State and its capital Benin City were renowned for pre‑trafficking juju rituals. Fourth, the victims

underwent such rituals and were bound to secrecy and obedience on pain of misfortune and death. Fifth, juju does

not consist of isolated magical practices; it is part of a Nigerian world‑view and part of Nigerian culture. Sixth, each

element in the ritual carried a specific meaning which was relevant to the control of the victims. Seventh, the
victims felt bound by the oath which they had taken and would fear the curse which would follow if they broke their
oath. This therefore provided a significant tie to the traffickers. Eighth, the victims were regularly reminded of the
oath which they had taken, which operated as an effective form of remote control over them. Ninth, fear of the oath
and consequent curse could render a victim unable to provide information to persons in authority.

13. As we gather, Dr Harris also gave evidence about the means of travel of those trafficked from Nigeria to
Europe: this frequently following the route that was in fact undertaken by the victims in this case.

14. So far as the victims in the present case were concerned, they stayed at the address of a juju priest for
upwards of one week. Cuts were administered to their backs, chest, shoulders, legs and wrists with a razor blade
which caused permanent scarring. Their wounds were then filled with black powder made up ingredients such as
alligator powder. The insertion of ingredients to their bodies further increased the degree of control that the
offender would have had over them. Further, at the end of their stay with the priest, the victims were made to
participate in a ceremony which amongst other things required them to eat the heart of a cockerel. The ceremony
took place whilst they were naked and vulnerable. After the ceremony, the offender demanded photographs of the


-----

victims, together with samples of their head hair and pubic hair. This was all part of the juju oath and reinforced the
control that the offender exercised over them. In his sentencing remarks, the trial judge was to say this:

"By doing this, you ensured their compliance and silence because they were all terrified of the consequences of
breaking the voodoo or juju oath. They were told and believed that they might even die."

15. At or around this time, as was the evidence, the offender told the women how much they had to pay for the
trafficking service to Europe. She demanded between €30,000 and €38,000 from each woman. Due to their social
backgrounds and naivety, the victims had little or no appreciation of the size of the debt or what would be required
to repay it. By the time they had sworn the oath during the ceremony, it was too late to go back. Each promised on
oath that they would repay the offender for the cost of travel. They promised that they would not inform the police
of the identity of their trafficker and promised that they would not send money home to their families before repaying
the offender. The victims were told that breach of the oath would result in the juju impregnating them and water
flowing from their vaginas.

16. The judge was to find that the taking of the oath by the victims was an important feature of the trafficking for a
number of reasons. By taking the oath the offender ensured that they would remain loyal to her, she knew that the
victims would undergo the journey she had organised, the victims were promising to pay the offender money once
they were in Europe and the victims would not report her to the authorities.

17. Thereafter, the victims began their journey over land from Benin City, Nigeria across the African continent to
Tripoli in Libya. They were driven for approximately four weeks across the Sahara Desert. According to the
victims, the offender had put in place all the necessary arrangements for this to happen. This involved a network of
people who met and directed them from one place to the next. The offender, on the prosecution evidence,
organised these journeys and did so also by arranging for a man to accompany the women. The victims were, on
the evidence, in telephone contact with the offender during the course of their journey. In Libya one of them told the
offender that Arab men had tried to rape them. The offender's reply was that this was 'normal' and that this was
what was going to happen. The offender told that particular victim that if men tried to rape her then she (and, as the
occasion arose, the other girls) should say that they were menstruating.

18. The victims were on the journey exposed to risks as to their safety. In fact, whilst in Tripoli victim 4, F, was
raped as a result of which she became pregnant. The other victims also experienced a significant ordeal. They
endured lengthy periods waiting in overcrowded and dangerous transit houses before being moved on to the next
period of their journey.

19. Ultimately, and after money appeared to have changed hands, the victims were directed to a beach in Tripoli.
Once there they were made to embark upon a large rubber inflatable boat with over 100 other people, destined for
Southern Italy. For both sets of victims their journey across the Mediterranean Sea was a perilous one. There was,
as the judge found, a real and significant risk of death. Their boats broke down and they had to wait for rescue
vessels to pick them up before landing in Italy. Once there, they were housed in immigration camps. Victim 6
remained in Italy. Victims 1 and 2 were removed from the camp by someone working for the offender's network of
traffickers before being moved into Germany. Thereafter, the offender was in telephone contact with victim 6.
Before victims 1 and 2 travelled to Germany, the offender met victim 1 in Naples and the offender ensured that
victim 6 was set up with work in Italy.

20. Similar arrangements were put in place with regards to the second group of victims when they arrived in Italy a
few months later. Victim 4 stayed behind in Italy, whilst the offender's network of assistants arranged for her to
have an abortion, she having become pregnant following being raped. The offender then made victim 4 work as a
prostitute, even though she was still bleeding following her abortion. She was in fact required to repay the €500
cost of the abortion in addition to the other debts which she owed to the offender.

21. The victims destined to travel on to Germany were provided with false identification documents. However,
once in Germany those documents were taken from them, it seems so that they could then be used by others.
Together with their unlawful immigration status, the loss of their identification documents heightened their


-----

vulnerability. The offender had provided three of the victims with French passports in order to enable them to travel
from Italy into Germany in the first place.

22. When victims 1 and 2 arrived in Germany they were met at a railway station and taken to an address before
being moved on to brothels. Germany was then and still is a country which licenses prostitution. The victims
handed their false identification papers to the brothel staff and they rented a room at around €100 per day.
Thereafter, they worked as prostitutes in order to pay their rent, purchase food and repay the "debt" they owed the
offender. As was found, victim 1 (S) had known nothing of her prospective employment as a prostitute until she
arrived in Germany. All of the victims spoke of their distaste about the nature of their employment. As has been
mentioned, none of them had worked as prostitutes before. They spoke of the difficulties they faced and of the
emotional and physical effects upon them and upon the volume of custom they had to achieve in order to pay the
daily rent and repay the offender.

23. The money was paid to the offender by various means. Sometimes the offender would travel to Germany in
person to pick up the cash. Alternatively, cash would be handed over to a third party in Germany or money would
be sent by money transfer.

24. The German authorities, however, had obtained evidence from telephone intercepts in Germany. In particular,
this aspect of their investigation involved the interception of calls between a telephone number ending 6979 which
was identified as being under the control of the offender and various numbers attributed to the victims. These calls
evidenced the nature of the relationship between the offender and the victims. These calls in short demonstrated
that despite the nature of their employment, scant regard was paid to the victims' health. There was, for example, a
complete disregard for the wellbeing of victim 4, who had experienced the bleeding effects after her abortion. The
victims were also subject to regular demands for money enforced by the threat of having the juju curse unleashed
upon them. The demands for money were also enforced by threats directed towards the victims' families, usually
involving a shrine integral to juju worship. Methods of payment to the offender were discussed via third party
assistants or face to face contact.

25. In January 2017, victim 3 was arrested by the German authorities. On the day of her further arrest in August
2017 the offender was in repeated contact with victim 3's telephone. In due course the victims were variously
arrested either before or after the offender's own arrest in the United Kingdom. Their demeanour in custody was
noted by the authorities as appearing to "cower" and as being afraid of contact with the authorities.

26. On 24 August 2017 the offender was arrested at Heathrow. When interviewed she made no comment. In her
luggage police found mobile telephone handsets which contained or had contained SIM cards which had been in
contact with telephone numbers belonging to the victims. One handset contained the SIM card for telephone
number 6979, calls from which had been intercepted by the German authorities. The offender's husband was also
arrested. One of his mobile telephones contained the 6979 number under a particular contact.

27. Following her arrest, the offender's address in Nigeria was searched. There the police found photographs of a
number of young women, a mobile telephone belonging to victim 5 taken from her when she had met the offender
in Germany and lists of women who had apparently been trafficked.

28. The evidence from the victims demonstrated that a significant amount of money had been paid to the offender.
Victim 1 had paid her upwards of €15,000, victim 5 had paid her about €1,500. Victim 3 had been arrested shortly
after arrival in Germany and had paid scarcely anything to the offender. Following victim 3's arrest the offender had
contacted her by telephone to impress upon her that she had to continue to strive to pay the money that was
"owed".

29. Turning to count 6, the count of perverting the course of justice, this offence took place between 26 September
2017 and 10 February 2018. It concerned efforts made by the offender to trace and intimidate family members of
witnesses in the criminal proceedings. Whilst in custody, the offender had been afforded the use of a PIN phone
which had enabled her to make telephone calls from prison to numbers which she provided to the Prison Service.
One of those numbers was her husband's. The telephone calls were recorded. Those calls had often involved the
offender contacting her husband who in turn made conference calls enabling the offender to speak with third


-----

parties. In those calls they spoke about making payments to certain highly placed individuals in Edo State. In
addition, they spoke about obtaining the assistance of those in influence to get the case against her stopped. They
also spoke about the tracing and arrest of family members of the victims who had made witness statements.

30. On 19 December 2017 the sister of victim 5 was in fact arrested in Benin City. When the prosecutor involved
on behalf of the National Association for the Prevention of Trafficking Persons became involved and travelled to the
police station, it was assessed that the arrest of the sister had been unlawful. Nevertheless, the sister had been in
custody for one day, being arrested in front of her own children. When she had been taken to the police station she
had been told to withdraw the comments she had made in a witness statement which concerned victim 5 and
events in Germany.

31. At trial, the offender gave evidence to the effect that she was not a trafficker. She did not dispute that the
victims had been trafficked. Her essential case was that she had not been concerned in any such activity. She said
that another woman had been responsible. As for her visits to Germany, she said that was in order to deliver
parcels to the victims on behalf of their parents or relatives and any contact she had with them was for the purpose
of delivering parcels. She also said that she had lent money to the parents of some of the victims and that her
contact with the victims had concerned repayment of that money. In relation to the 6979 number, she said that
while she had been in possession of the SIM card and associated handset, she had not made calls from this
number. She was to say that she had allowed her driver to borrow the telephone.

32. No victim impact statements were obtained at the conclusion of the trial, albeit the victims had spoken of their
experiences when giving evidence. That evidence had included the fact, as they said, that they had been in
considerable fear of the juju ceremony and of the oath which they had given. They felt relieved when they heard
that the prosecution had approached the juju priest in at least one case and that the curse had been reversed.
They found it very difficult to describe their experiences of travelling to Europe. They also spoke of the risks that
they had incurred and the difficulties they had experienced in getting to Germany and further spoke about the
exposure of themselves and their families to threats.

The Judge's sentencing remarks

33. After the jury had given their verdicts, the matter was adjourned for sentence. Detailed and helpful sentencing
notes were prepared in writing by counsel then appearing for the prosecution and by Mr Benson QC appearing,
then as now, for the appellant. The judge had had the benefit of reading those sentencing notes before the hearing
and he also had the benefit of extensive oral submissions.

34. We have already identified some aspects of the judge's sentencing remarks. It is entirely evident that the judge

had approached sentence in a conspicuously careful, well‑structured and thoughtful way. He set out the facts in

great detail and duly recorded his own assessment of the evidence in so far as it bore on sentence. We would pay
tribute, as did Mr Buckland QC (Solicitor General), to the care which the judge had evidently bestowed on this very
difficult sentencing exercise.

35. Amongst other things, the judge made the following findings for the purposes of sentencing. First,
sophisticated planning had been involved. Second, the offender well understood the potential dangers to the
victims in travelling to Italy. She "simply did not care" for their welfare, as the judge found. Third, the offender had
regularly contacted the victims on the phone and pressured them into giving her money. Fourth, all the victims
were "psychologically scarred" by the juju ceremonies they had been forced to take part in, as well as being
physically scarred by the rituals. Fifth, the effect of the juju ceremony had not only been such as to leave
psychological scars, but also "meant that they were psychologically kept under lock and key" in Germany, even if
not physically so kept. The offender also had frequently threatened them with reporting them to the juju priest, a
grave matter for them and by threats to members of their families. Sixth, the judge in terms found that the offender
was the directing and organising mind who had arranged everything and controlled the various individuals who had
assisted in the travel arrangements. She had "a leading and organisational role", as the judge found.


-----

36. The judge's overall assessment can in part be encapsulated by certain of the remarks which he had made
during the course of the sentence hearing. It may be noted that in the course of discussion with counsel the judge
had indicated that had this been a case of the victims being, as it were, kept locked up in a room and then let out to
perform the sexual services required, the judge said that "I would be really looking at sentences of 20 years
upwards."

37. In the course of his detailed sentencing remarks the judge had amongst other things said this:

"Having seen and heard each of your victims give evidence, I am satisfied they were all young, naive, trusting and
desperate women, who only wanted to make their own lives and the lives of their immediate families better. You
preyed upon them and persuaded four of them to work as prostitutes in a foreign land far away from their families.
One of your victims, SA, did not know that the purpose of the journey to Europe was for her to work as a prostitute.
This is a serious aggravating feature to your offending.

Trafficking human beings is an ugly offence. It must always be dealt with severely by the courts in order to deter
others from taking part in this vile trade. In my judgment even the four women who knew what awaited them in
Germany were highly vulnerable victims. Your offending is aggravated by many different features, and I shall deal
with them as I describe the way you trafficked these women.

This is not a case of moving people over a border into a nearby country and putting them to work in a factory or
on fields. Your victims were sent on a long, arduous and very dangerous journey across two continents and a sea
where there was a real risk that they could all have drowned.  Then they were made to work as prostitutes, an
utterly demeaning job."

The judge then went on to refer to the juju ceremony and said this:

"By taking the oath, you ensured that your victims would remain loyal to you... In my judgment they indicate an
element of sophisticated planning that went into your offending."

The judge at a later stage referred to what had happened when the victims had stated their fears about being raped
and the explanation they should give about menstruation and said this:

"This is but one example that demonstrates your complete disregard for the welfare of these women. You saw
them not as living, breathing human beings, but as commodities who were there to earn you large sums of money."

Guidelines

[38. There is, as yet, no published definitive guideline relating to the Modern Slavery Act 2015. Nevertheless, the](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
judge was, rightly, fully addressed and at length on the issue of harm and culpability and himself rightly and fully
addressed those issues in his sentencing remarks: as indeed he was required to do under section 143 of the
Criminal Justice Act 2003. For these purposes the judge had also been referred to the guideline issued by the
Sentencing Council relating to section 59A of the Sexual Offences Act 2003 which currently is treated as a form of
interim guidance for the purposes of the 2015 Act. It is however to be emphasised that section 59A was replaced
and repealed by the 2015 Act with effect from 31 July 2015. It is further important to emphasise that the maximum
sentence available has been increased from 14 years' imprisonment to life imprisonment, that reflecting the gravity
which Parliament has adjudged should be accorded to such cases.

39. By reference to that particular guideline, it is quite clear, and as was not disputed before the judge below, that
this would have been a case of the highest culpability. This would have been so not just for one reason but for a
number of reasons. First, the offender was the directing and organising mind. Second, there was expectation of
significant financial gain. Third, there was significant influence over others in the organisation.

40. However, it was, on behalf of the offender, queried before the judge by Mr Benson as to whether this was a
case of the highest level of harm: a point further raised by Mr Benson on this appeal. We are in no doubt that the
judge was entitled to conclude, as he did, that it was. There were clear threats of violence backed by the juju rituals


-----

and there was psychological impact as the judge found. Further, whilst none of these victims had been physically
abducted as such, and S had not known she was even going to work as a prostitute in Europe, the fact is that it is
absurd to say that they freely consented to the travel arrangements and other arrangements they were to endure.
The reality is that they were coerced into accepting these travel arrangements and into working as prostitutes as a
price for fulfilling their desperate desire to get to Europe. Indeed, they would prospectively have had to work for a
long time as prostitutes in order to pay off the "debts" incurred in favour of the offender, with all the risks of
degradation and sexually transmitted disease potentially involved.

41. It may be said, as Mr Benson says, that the offender would have intended no harm should accrue to them in
their travels, indeed it was in her interest that they should arrive safe and sound. The fact remains, as the judge
found, she simply did not care.

42. Consequently, by reference to the guideline issued under section 59A, we are in no doubt that this was
properly assessed at the top level of harm and accordingly for the purposes of that particular guideline each offence
here was Category 1A offending.

43. We were also referred, as had been the judge, to a number of authorities. The case of Zielinski [2017] EWCA
Crim. 758 was the only sentencing authority cited to us which has been decided by reference to the 2015 Act. That
particular case came before this court as an Attorney General's Reference. A sentence of four years' imprisonment

after a trial on a 21‑year‑old defendant was increased by this court to seven years. The circumstances of that case,

briefly put, were that six individuals had been lured from Poland to the United Kingdom on promises of paid work
and of accommodation. On arrival they were appallingly treated and housed and their wages were mostly
deducted. Attempts by some to escape were met with physical retribution. That was certainly a bad case on its
facts: but as the judge himself rightly found, it was nothing like as bad as the present case. The present case, by
way of example, involved the appalling and dangerous travel to Europe, the enforcement of the conduct of the
victims by the juju rituals and oaths with a view to requiring the victims to make payment to the offender and with a
requirement of them having to prostitute themselves; and moreover, conspicuously unlike Zielinski, the offender
here had the leading and organisation role. Overall, the present case does not simply have the hallmarks simply of
forced labour, it has the hallmarks of servitude. Indeed, the judge, as we have said, described the offender as
treating the victims as "commodities". Treating a human being as an owned chattel is of course one hallmark of
slavery.

44. We also should bear in mind the apt comments of Lord Judge, Lord Chief Justice, in the case of Attorney
General's Reference Nos 2, 3, 4 and 5 of 2013 (Connors) [2013] EWCA Crim. 324, [2013] 2 Cr.App.R (S) 71, a
case which was in fact decided by reference to section 71 of the Coroners and Justice Act 2009. In the course of
the judgment, this was said:

"10. Sentences in this class of case must make clear ... that every vulnerable victim of exploitation will be protected
by the criminal law, and they must also emphasise that there is no victim, so vulnerable to exploitation, that he or
she somehow becomes invisible or unknown to or somehow beyond the protection of the law. Exploitation of fellow
human beings in any of the ways criminalised by the legislation represents deliberate degrading of a fellow human
being or human beings. It is far from straight forward for them even to complain about the way they are being
treated, let alone to report their plight to the authorities so that the offenders might be brought to justice. Therefore
when they are, substantial sentences are required, reflective, of course, of the distinctions between enslavement,
serfdom, and forced labour, but realistically addressing the criminality of the defendants."

In an earlier case decided in 2010 by a constitution of this court by reference to section 4 of the Asylum and
Immigration (Treatment of Claimants, etc) Act 2004, that case being Attorney General's Reference Nos 37, 38 and
65 of 2010 (Khan and others) [2010] EWCA Crim. 2880, [2011] 2 Cr.App.R (S) 31, the court had identified a
number of factors (not expressed as an exclusive or exhaustive list of relevant factors) which required consideration
when assessing the seriousness of an offence under the Act. Those included the following: first, the nature and
degree of deception or coercion exercised upon the victim; second, the nature and degree of exploitation exercised
upon the victim on arrival; third, the level and methods of control exercised over the victim with a view to ensuring
that the victim remained economically trapped; fourth, the level of vulnerability of the victim, usually economic but


-----

also physical and psychological; fifth, the degree of harm suffered by the victim (physical, psychological and
financial); sixth, the level of organisation and planning behind the scheme, the gain sought or achieved and the
offender's status and role within the organisation; seventh, the number of those exploited; and eighth, where
relevant, previous convictions for similar offences. Those observations were approved in Connors and in Zielinski.

Disposal

45. The recital of the facts which we have given shows that this was very, very grave offending. The role of the
offender, notwithstanding her protestations at trial, was found to be a leading one. There was considerable financial
gain at stake. There was a high level of planning and organisation. There was not just one but five victims whose
vulnerability was exploited from the outset. The offending itself spanned some 15 months. The trafficking further
involved sexual exploitation of these young women who were coerced by threats and juju rituals, and who were
"psychologically detained" (in the judge's words) as well as being psychologically and physically scarred. The
victims further had been exposed to appalling suffering whilst travelling to Europe and exposed to a real risk of
danger in making in particular the perilous crossing across the Mediterranean. Further, threats were also made not
only to them but to family members. Yet further, they were exposed to risk by having their identification documents
removed whilst in Europe and to the risk of detention as illegal entrants. On top of all this, there was the significant
attempt to pervert the course of justice.

46. It has to be said that the mitigation available was relatively sparse. There could be no credit for any plea, as
the trial was fought; and as we gather there is no remorse, indeed the offender's position is still one of denial of any
responsibility for what occurred. It is however right to say that the offender was of previous good character and
indeed, as we have indicated, had herself worked as a nurse in the United Kingdom. Further, she has a

16‑year‑old son with problems and she herself has some health issues. We were also told by Mr Benson this

morning that she is concerned that she has a number of nephews and nieces in Benin City whom formally she had
been supporting both financially and emotionally but is no longer able to do so.

47. Mr Buckland has not sought to say that there was any error of principle of approach on the part of the judge.
His central point is that the judge's ultimate evaluation of the evidence as to the appropriate sentence that was to be
passed was simply wrong and the judge in the result inadvertently arrived at a sentence on counts 1 to 5 which is
properly to be described as unduly lenient.

48. Mr Benson on the other hand, whilst accepting that it could be said that this sentence was on the lenient side,
disputes that it is properly to be categorised as an unduly lenient sentence. He understandably stresses the
advantages which the judge had as having conducted the trial and also stresses the thoroughness of his whole
sentencing approach.

49. However, as we see it, the crystal clear exposition of the evidence by the judge in his sentencing remarks and
his findings made by reference to that evidence of itself demonstrate the sheer gravity of this particular offending
which related to five separate victims. As we have said, there are numerous elements showing that this was a case
of the highest culpability, and furthermore, there were the elements showing that this was the case of the highest
harm.

50. We accept of course that this was a very difficult sentencing exercise. We accept that the judge had no
definitive guideline available to him under the 2015 Act and relatively little guidance from such authorities as there
are as to the appropriate sentencing range for offending under this statute. But with all respect to the judge, we do
think that he did reach a wrong conclusion. Indeed, it may be noted that the judge himself had said in the course of
his sentencing remarks that if he had taken the case of S on its own (he regarding that as the worst of the cases),
he would have imposed a sentence of eight years' imprisonment. That, it may be noted, is the starting point for an
offence under section 59A as identified in the guideline relating to that section and when the maximum sentence
was one of 14 years and does not even go to the top of the range or towards the top of the range which is available
under that particular guideline. Furthermore, and whilst of course we accept that these things are not done in any
kind of arithmetical way, if the judge's notional sentence in respect of S was indeed one of eight years, then it would
appear that the judge had ascribed to the other four offenders taken together an uplift in the ultimate sentence on


-----

these counts of five years' imprisonment. However, we do not think that 13 years' imprisonment on counts 1 to 5
sufficiently reflects the appalling gravity of this offending relating as it did to five separate victims. Moreover, there
was the offending involving perverting the course of justice: appropriately dealt with, as the judge did, by adding on
a consecutive sentence. There can be no criticism of the consecutive sentence of one year for that offence; indeed,
we apprehend that it might have been longer taken on its own but was reduced to take account of principles of
totality.

Conclusion

51. Overall, therefore, the facts and circumstances of this case compel the conclusion that this sentence, in our
judgment, ought to be increased. Offending of this gravity requires condign sentencing. It also requires that
persons be deterred from engaging in offending of this kind. Mr Benson suggested that those in Nigeria or
elsewhere will not be deterred by severe sentences imposed by the courts in England and Wales. We are
unmoved by that. Those who are within the reach of the jurisdiction of the courts of England and Wales should
expect severe sentencing in this context. Those who engage in vicious, ruthless and heartless human trafficking of
this particular kind are playing for high stakes. They need to know that the courts will show no mercy when their
criminality is exposed.

52. In the result, we increase all the sentences on counts 1 to 5 to concurrent terms of 17 years' imprisonment:
which we consider to be the least sentence appropriate to these particular cases. The consecutive sentence of one
year's imprisonment on count 6 will stand. The total sentence therefore becomes one of 18 years' imprisonment.
The appeal is allowed accordingly.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part**
thereof.

**End of Document**


-----

# R v Iyamu (Josephine)

_[[2018] EWCA Crim 2166, [2019] 1 Cr App Rep (S) 132, [2018] All ER (D) 74 (Sep)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5TRG-7RB1-DYBP-N0H5-00000-00&context=1519360)_

**Court: Court of Appeal, Criminal Division**
**Judgment Date: 20/09/2018**

# Catchwords & Digest

**CRIMINAL LAW - TRAFFICKING PEOPLE FOR EXPLOITATION – SENTENCING**

Criminal Law – Trafficking people for exploitation. The Solicitor General's appeal to increase the offender's
[sentence for offences contrary to section 2 of the Modern Slavery Act 2015 was successful. The Court of Appeal](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FRN-P761-DYCN-C254-00000-00&context=1519360)
held that the offences committed by the offender had been grave and her role in the offences had been a leading
one. Her five victims had been left psychologically and physically scarred and the offender had shown no remorse
for her actions, therefore the sentence of 14 years imprisonment did not accurately reflect the appalling gravity of
the offences. The offender's sentence was accordingly increased to 18 years' imprisonment.

# Cases referring to this case

Director of Public Prosecutions v Edosa and Enoghaghase

_[[2023] IECA 38](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:6833-XYX3-RT9C-G4G2-00000-00&context=1519360)_
Considered

# Cases considered by this case

R v Zielinski (David) (2017)

[2017] EWCA Crim 758
Considered

R v Connors

_[[2013] EWCA Crim 324, [2013] All ER (D) 314 (Mar)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:582M-9241-DYBP-N3KK-00000-00&context=1519360)_
Applied


20/02/2023

IrCA

17/05/2017

CACrimD

26/03/2013

CACrimD


-----

A-G's Reference (Nos 37, 38 and 65 of 2010)

_[[2010] EWCA Crim 2880, (2011) Times, 24 February, [2010] All ER (D) 147 (Dec)](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:51PH-2V31-DYBP-N3P0-00000-00&context=1519360)_
Applied

**End of Document**


09/12/2010

CACrimD


-----

