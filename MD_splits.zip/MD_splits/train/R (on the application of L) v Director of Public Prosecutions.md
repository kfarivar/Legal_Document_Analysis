# R (on the application of L) v Director of Public Prosecutions [2020] EWHC
 1815 (Admin)

Queen's Bench Division (Divisional Court)

Hickinbottom LJ and Sweeney J

9 July 2020Judgment

**Benjamin Douglas-Jones QC and Chris Buttler (instructed by Deighton Pierce Glynn)**

for the Claimant

**John McGuinness QC and Andrew Johnson (instructed by CPS Appeals and Review Unit)**

for the Defendant

Hearing date: 1 July 2020

- - - - - - - - - - - - - - - - - - - - 
**Approved Judgment**

**Lord Justice Hickinbottom:**

**Introduction**

1. Subject to further order, the court directs that nothing shall be published in respect of this claim that
might identify the Claimant, directly or indirectly.

2. The Claimant challenges the decision of the Crown Prosecution Service (“the CPS”) on behalf of the
Defendant authority (“the DPP”) not to bring charges against her former employers (to whom I shall refer
as “Mr & Mrs Aljaberi”) for arranging her entry into the United Kingdom in circumstances in which they
intended to exploit her, contrary to section 4 of the Asylum and Immigration (Treatment of Claimants, etc.)
Act 2004 (“the 2004 Act”).

3. Before us, Benjamin Douglas-Jones QC and Chris Buttler of Counsel appeared for the Claimant, and
John McGuinness QC and Andrew Johnson for the DPP. At the outset, I thank them all for their respective
contributions.

**Background**

4. The Claimant is a national of the Philippines. In March 2012, through an agency, she obtained
employment for Mr & Mrs Aljaberi in Abu Dhabi, undertaking domestic and childcare work, from 7am to
10pm each day. Under the terms on which she was employed she was to earn US$400 per month,
although she was actually paid about US$200 per month.

5. In 2013, Mr Aljaberi obtained a diplomatic position at the United Arab Emirates Embassy in London. He
wanted the Claimant to accompany his family; and it is the Claimant's case that he promised her that, in
London, she would be required to work a 40 hour week for £1,000 per month, to which she agreed.
Certainly, a Tier 5 visa was obtained for the Claimant as an overseas domestic worker, on the basis of a


-----

Certificate of Sponsorship (“CoS”) from the Embassy which stipulated a salary of £1,000 per month.
Without that promise as to hours and pay, she says that she would not have come to the United Kingdom.
The visa was tied to her employment with Mr & Mrs Aljaberi in the sense that, if she left that employment,
she would have no right to stay in the UK.

6. In due course, Mr Aljaberi moved to London; and later, on 1 February 2013, his wife, children and the
Claimant followed. However, contrary to the promise she had been made and the stipulation in the CoS,
the Claimant was required to work 14-15 hours every day and was remunerated only £100 to £200 per
month.

7. Whilst in their employment in London, the Claimant alleges that she was mistreated by Mr & Mrs
Aljaberi. For example, in addition to the hours of work (many more than she had been promised) and
salary paid (much less than had been promised), she was not allowed to keep her own passport, she was
only allowed restricted movement and was sometimes locked in the home when Mrs & Mrs Aljaberi left it
and at other times locked in a room with the children, she was not allowed to leave the home without
permission and (save in limited circumstances) unless accompanied and, although Mr Aljaberi told her that
she was covered by medical insurance, she did not have access to medical care when sick.

8. The Claimant left her employers on 1 May 2013. Shortly after that date, she was referred by Kalayaan
(an organisation that assists migrant domestic workers) through the Metropolitan Police Service (“the
MPS”) to the competent authority (i.e. the Home Office) via the National Referral Mechanism (“the NRM”)
which is designed to satisfy the UK's obligations under the Trafficking Convention signed at Warsaw on 16
May 2005. Under the NRM, following a referral, the competent authority makes an initial decision as to
whether there are reasonable grounds for believing that the individual is a victim of trafficking, within a
target time of five days. If that decision is positive then the person receives assistance as required by the
Convention. At the end of a target period of 45 days, the competent authority makes a conclusive decision
as to whether the person was trafficked which, although a positive decision does not give an automatic
right to remain in the UK, may result in discretionary leave being granted. A positive reasonable grounds
decision was made by the Home Office as competent authority on 20 September 2013; and, on 19
November 2014, the Home Office concluded that, on the balance of probabilities, the Claimant had been
the victim of trafficking. In coming to that decision, it was found that the Claimant had been (i) recruited for
the purpose of domestic servitude, and (ii) deceived as to the salary she would receive in the UK and hours
she would be required to work.

9. In parallel with this referral, in January 2014, the Claimant made a report to the MPS, which
commenced an investigation into whether Mr & Mrs Aljaberi may have committed any offence in relation to
the Claimant. An Achieving Best Evidence (“ABE”) interview was conducted with the Claimant on 30
January 2014. However, on 2 July 2014, the police said that no further action would be taken to
investigate Mrs & Mrs Aljaberi because they had diplomatic immunity and therefore could not be
prosecuted. Following the threat of judicial review proceedings, on 1 October 2014, the police set aside
that decision and agreed to reopen the investigation. A further ABE interview was held with the Claimant
on 25 March 2015. However, on 8 July 2015, the police again decided to discontinue the investigation
without submitting the matter to the CPS for a charging decision, on the basis that the evidence was of
insufficient weight to meet the threshold test for exploitation. That decision was challenged in judicial
review proceedings, which were compromised on 9 June 2016 with the police agreeing to set aside and
retake the decision.

10. As a result, the police did refer the case to the CPS for a charging decision on 27 March 2017. Such
decisions are made in accordance with the Code for Crown Prosecutors, paragraph 3.4 of which provides
that a prosecution of a charge should only start or continue if that charge passes a two-stage test, namely
(i) on an objective assessment, the prosecutor is satisfied that there is sufficient evidence to provide a
realistic prospect of conviction, and (ii) a prosecution is in the public interest. Each stage is discrete, and
so, unless there is a sufficiency of evidence, the relevant decision maker does not proceed to consider the
public interest. It is well-established and uncontroversial that, in exercising its judgment in relation to each
stage of this test, an independent prosecuting authority has a very wide margin of discretion and a court


-----

will only interfere with its assessment in highly exceptional cases (see, e.g., R (Corner House Research) v
Serious Fraud Office [2008] UKHL 60; [2009] 1 AC 756 at [30] per Lord Bingham of Cornhill).

11. Mr Douglas-Jones accepted that, in making such decisions, the prosecuting authority has a wide
margin of discretion; but no margin of discretion in making an assessment requiring judgment can save a
decision when the approach of the decision maker was wrong. He submitted that a prosecutor could only
properly assess whether the first stage of the test was satisfied if he or she had considered the sufficiency
of the available evidence having identified the essential elements of the offence(s) which had to be proved
and assessed the evidence against that backdrop.

[12. In respect of this case, the Modern Slavery Act 2015,not being retrospective, did not apply: and it was](https://advance.lexis.com/api/document?collection=legislation-uk&id=urn:contentItem:5FP0-CDM1-DYCN-C0GV-00000-00&context=1519360)
considered that any offence would have been committed under section 71 of the Coroners and Justice Act
2009 and/or section 4 of the 2004 Act, each repealed by the 2015 Act but continuing to apply in respect of
pre-2015 conduct. Mr Douglas-Jones has no quarrel with the identification of those as the potential
offences.

13. Under the former, it is an offence knowingly to hold another person in slavery or servitude or knowingly
to require another person to perform forced or compulsory labour; but that provision plays no part in this
claim, and I need say nothing further about it.

14. Under section 4(1) of the 2004 Act, a person commits an offence if he arranges or facilitates the arrival
in, or entry into, the United Kingdom of a person in circumstances in which he intends to exploit, or he
believes that someone else is likely to exploit, that person. Section 4(4) provides that for these purposes a
person is exploited if, and only if (so far as relevant to this claim):

(a) he is the victim of behaviour that contravenes article 4 of the Human Rights Convention [“the ECHR”]…

…

(c) he is subjected to force, threats or deception designed to induce him—

(i) to provide services of any kind…”.

Article 4 of the ECHR prohibits slavery and servitude, and proscribes forced or compulsory labour.

15. On 21 February 2018, the CPS decided not to charge Mr & Mrs Aljaberi, because diplomatic immunity
applied and had not been waived. The Claimant's solicitors pressed for a fully reasoned decision, and that
was sent to her in a letter dated 17 October 2018 which confirmed that it had been decided not to
prosecute because it was considered that there was no realistic prospect of a conviction because of
diplomatic immunity. That decision was upheld on 4 December 2018 on a first, local resolution stage
review, requested by the Claimant under the Victims' Right to Review Scheme (“the VRR Scheme”). There
had, up to that stage, been no consideration of the evidential position by the prosecutor – the refusal to
charge resulted from the diplomatic immunity enjoyed by Mr & Mrs Aljaberi – and the DPP does not seek to
rely on any element of those decisions now.

16. However, the Claimant requested a second, independent review under the VRR Scheme, which was
conducted by Samuel Main, a Specialist Prosecutor with the CPS Special Crime and Counter Terrorism
Division (“the decision maker”). That review was sent to the Claimant on 20 June 2019 (“the June decision
letter”). It accepted that the residual immunity enjoyed by Mr & Mrs Aljaberi (who by now had left the UK)
did not shield them from prosecution; but the decision maker said, of the Claimant's various interviews:

“Assessed as a whole, I have concluded that they do not disclose misconduct that would amount to
slavery, servitude, forced labour or compulsory labour or an intention to traffic you into this country for any
of those purposes.

I have also concluded that the available evidence is not sufficient to sustain charges that you were forced,
threatened or misled in order to induce you to come to the United Kingdom to provide services.”

17. Having set out some of the evidence about the conditions in which the Claimant lived whilst employed
by Mr & Mrs Aljaberi, the letter continued:


-----

“Two important factors are at the heart of your case: your low pay and the long hours that you were
required to work. However, there have been other cases in the appeal courts that indicate that these
factors will not normally be enough to amount to criminal exploitation. Moreover, your case cannot be
strengthened by further evidence. I have therefore concluded that there is not a realistic prospect of
conviction and the decision not to bring charges was the correct one.”

18. In other words, the decision maker concluded that, although the earlier decision makers had erred in
relying in concluding that diplomatic immunity rendered a prosecution impossible in practice, such errors
were not material because there was in any event insufficient evidence to provide a realistic prospect of
securing a conviction against either Mr or Mrs Aljaberi. He therefore confirmed the earlier decisions not to
charge.

19. A letter before action dated 9 July 2019 was sent to the CPS by the Claimant's solicitors, the focus of
which was the June decision letter's conclusion that there was an insufficient evidential basis upon which
charges could be brought against Mr and Mrs Aljaberi on the basis that they had, by their conduct,
subjected the Claimant to domestic servitude and/or forced or compulsory labour. The CPS responded
with a further decision, dated 13 August 2019 and again made by Mr Main (“the August decision letter”). In
addition to the earlier evidence, this considered evidence not previously taken into account notably an
unsigned statement of the Claimant dated January 2014 and its exhibits which included the conclusive
decision of the Home Office as competent authority that the Claimant had been the victim of trafficking.

20. In the August decision letter, although he noted inconsistencies in the Claimant's account which led
him to be cautious about her credibility, the decision maker said – fairly and, in my view, properly – that “to
ensure that [the Claimant] was not disadvantaged by the lack of supporting exhibits, I assumed that her
account was true unless it was such that an objective, reasonable and fair-minded person could not accept

[it]”. Furthermore, he referred to the recent judgment of this court (Nicola Davies LJ and Farbey J) in R
(Torpey) v Director of Public Prosecutions _[2019] EWHC 1804 (Admin) in which (as the decision maker_
himself said in his letter) “criticism was made of the CPS for failing to give adequate reasons for an
adverse decision”. Therefore, in addition to dealing with the new submissions and evidence, the decision
maker made clear that:

“The purpose of this note is therefore to provide further detail as to the material taken into consideration
when each review was conducted, the law and policy considerations and the chief reasons for my
conclusions.”

It was thus clearly the intention of the August decision letter, in addition to taking into account new material,
to give clearer and better reasons for the decision than were set out in the June letter.

21. In relation to section 4 of the 2004 Act, the decision maker said:

“… Exploitation is narrowly defined. In this case, the relevant parts were slavery and forced labour (as
construed under article 4 of the [ECHR]) and the use or threat of force designed to induce a person to
provide services, provide another person with benefits or enable another person to acquire benefits….

After noting that [the Claimant] accepted agreeing to work for [Mr & Mrs Aljaberi] but on terms other than
those that transpired, I noted her complaints: her hours of employment were extremely long; she was paid
significantly below what was due; information provided to the Home Office in support of her application for
a visa was deliberately falsified; she was locked in the house when the interested parties were present; she
was provided with minimal resources; she was refused medical treatment when she felt it was necessary;
and she was prevented from socialising with third parties.”

22. The letter then continued that those matters could not, however, be considered in isolation and had to
be assessed against the entirety of the Claimant's interview accounts, including (for example) the fact that
she had control over her own affairs; she had a mobile phone which allowed access to Skype and
Facebook; and, although the Claimant's passport was taken from her, it was kept in a place unlocked and
known to her.

23. The decision maker then turned to section 4:


-----

“Dealing specifically with the section 4 offence, I considered that whilst [Mr & Mrs Aljaberi] had facilitated

[the Claimant's] entry into the UK, they had not been done so with a view to her exploitation. I considered
each potential route through which the offence could be made out”.

He then considered, in turn (and in separate, inset paragraphs), (i) slavery, (ii) servitude and (iii) forced and
compulsory labour, concluding that he did not consider any was shown on the evidence – which, he said,
was indicative of a lack of intention to exploit. He consequently concluded:

“Accordingly, the evidential stage of the Code for Crown Prosecutors was not met in relation to the section
4 offence.

…

As the evidential test was not met…, the decision that no further action should be taken was correct, albeit
for different reasons to those given by the original reviewing lawyer.”

24. Thus, having considered the new material, the decision maker confirmed his June decision not to
charge.

**The Claim**

25. The Claimant challenges the decision of 13 August 2018 not to bring charges against Mr and/or Mrs
Aljaberi. There is a single ground. Even if the decision maker had properly determined that there was no
realistic prospect of a conviction on the basis that Mr & Mrs Aljaberi had arranged the Claimant's entry into
the United Kingdom in circumstances in which they intended her exploitation as described in section
4(4)(a) of the 2004 Act (i.e. slavery, servitude, forced labour or compulsory labour), he had failed to
consider whether there was such a prospect of conviction on the basis of exploitation as described in
section 4(4)(c) (i.e. that they deceived her as to her working hours and pay to induce her – and, in the
event, in fact inducing her – to provide services to Mr & Mrs Aljaberi in the UK).

26. In paragraph 8 of his Detailed Grounds of Resistance, the DPP accepts that “the decision letters (i.e.
the June and August decision letters) ought to have addressed the question of evidential sufficiency in
respect of a prosecution in reliance on the definition of 'exploited' in section 4(4)(c) in specific terms (even if
relatively briefly) – and this they failed to do”, a concession repeated in paragraph 3 of Mr McGuinness's
skeleton argument in which it is also conceded that the decision letters failed properly to explain the
decision reached.

27. Nevertheless, Mr McGuinness seeks to uphold the decision of 13 August 2018 on two grounds. First,
he submits that, although they did not do so expressly or as clearly as they might have done, if the June
and August decision letters are read together as a whole in a broad and common sense way (as they must
be: R (Monica) v Director of Public Prosecutions [2019] QB 1019 at [46(3)] per Lord Burnett of Maldon CJ
and Jay J), it is clear that the decision maker _did consider whether, on the available evidence, a_
prosecution on the basis of exploitation as described in section 4(4)(c) stood a realistic prospect of
conviction – and concluded it did not. Second, if the decision maker did not consider that basis of
prosecution, then in any event, had he done so, Mr McGuinness submits that it is highly likely that the
outcome would have not have been substantially different; and so, applying section 31(2A) of the Senior
Courts Act 1981, the court “must refuse relief” and leave the decision to take no further action in place.

28. As to the first ground of defence, Mr McGuinness essentially relied upon the June decision letter,
which was effectively incorporated by reference into the later letter. He particularly relied upon the
passage from the early part of the June decision letter quoted above (see paragraph 16) in which the
decision maker states that “the available evidence is not sufficient to sustain charges that you were forced,
threatened or _misled in order to induce you to come to the United Kingdom_ _to provide services”, the_
emphasised words (he submitted, with some force) clearly deriving from section 4(4)(c). On the basis of
that sentence, Mr McGuinness submitted that the decision maker not only had a route for prosecution
through section 4(4)(c) well in mind, but he also clearly and unambiguously stated that the available
evidence was insufficient to give rise to a realistic prospect of conviction on that basis.


-----

29. Mr Douglas-Jones sought to persuade us that the quoted words did not refer to section 4(4)(c) at all,
but were rather merely part of the decision maker's consideration of section 4(4)(a); but I am unable to
accept that. Other than “misled” being used instead of “deception” – those words, in this context, having a
similar meaning – that sentence directly reflects the criteria and the terminology of section 4(4)(c). On its
face, I accept that that sentence is in the form of an assertion as to the prospects of conviction on the basis
of exploitation as described in section 4(4)(c). That clearly shows that the decision maker understood that
one potential route to a conviction was through the description of exploitation in section 4(4)(c). However,
it leaves open the question as to whether the June and/or August decision letters evidence on the part of
the decision maker an appreciation of the essential elements of the offence and an assessment by him of
the sufficiency of the available evidence to give a realistic prospect of conviction by that route.

30. Although Mr McGuinness did not press the point in his oral submissions, in paragraph 5 of the Detailed
Grounds of Resistance (reiterated in paragraph 3 of his skeleton argument), he relied upon the fact that the
June decision letter went on to say (as quoted in paragraph 17 above) that “two important factors” were “at
the heart of the [Claimant's] case”, namely “your low pay and the long hours that you were required to
work”. However, from its context in the letter, the decision maker was there clearly concerned with the
section 4(4)(a) case, as confirmed by his reference to “other cases in the appeal courts that indicate that
these factors will not normally be enough to amount to criminal exploitation”. As Mr Douglas-Jones pointed
out, these cases are listed in paragraph (h) of the August decision letter, and (with the exception of the
sentencing case of Attorney General's Reference Nos 37, 38 and 65 of 2010 (Shahnawaz Khan, Raza Ali
Khan and Perveen Khan) [2010] EWCA Crim 2880, in which no analysis of section 4(4)(c) is given) all are
exclusively concerned with offences involving the section 4(4)(a) route. In my view – as Mr McGuinness all
but accepted at the hearing – in the June decision letter, there is no analysis (or even consideration) of the
available evidence that might support a prosecution via the section 4(4)(c) route.

31. Nevertheless, Mr McGuinness submitted that, having referred to the relevant elements of section
4(4)(c) and to the Claimant's low pay and the hours she was required to work being at “the heart of [her]
case”, it can be taken that the decision maker had indeed properly analysed and assessed the sufficiency
of the evidence in support of a prosecution on the basis of section 4(4)(c) exploitation as a result of
deception in relation to her hours and pay; and the statement that there was insufficient evidence was not a
mere assertion but a conclusion. However, even construing the decision letters in a broad way, I do not
consider that to be so. As I have indicated, the references to pay and hours in the June decision letter are
clearly in the context of the section 4(4)(a) route – to which they were, of course, relevant – so there is no
evidence in the letter that any such consideration was given or analysis performed. In the June decision
letter, the assertion stands alone.

32. As I have described, the August decision letter was written in response to further submissions and
evidence from the Claimant which did not focus on section 4(4)(c), but rather section 4(4)(a); and, as Mr
McGuinness frankly and properly accepted, the August letter focuses exclusively on (a). Insofar as it
presented a post-Torpey opportunity to remedy any defects in the reasoning of the June decision letter in
respect of a prosecution relying on the section 4(4)(c) description of exploitation, it was an opportunity
spurned.

33. As quoted above (at paragraph 21), the decision maker said in this letter that “exploitation is narrowly
defined” – itself a moot point (see, e.g., R v Karemera [2018] EWCA Crim 1432; [2019] 2 Cr App R 14 at

[44] per Hallett LJ) – and he continued that the relevant parts of the definition were slavery and forced
labour (as defined in section 4(4)(a)); and, “the use of force designed to induce a person to provide
services, provide another person with benefits or enable another person to acquire benefits”. These
words, Mr McGuinness submitted, although not referring to “threats” or “deception”, were clearly a
reference to section 4(4)(c). However, if they were, “deception” is a most notable absentee. The decision
maker noted the Claimant's complaints of “her hours of employment were extremely long; she was paid
significantly below what was due”; but, he said, there had been “no deception as to the nature of the work
that would be undertaken” and the Claimant had been “remunerated for her services, albeit in sums
alleged to be significantly less than agreed”. The references here to hours and pay, and to “deception”,
however, were clearly made in the context of section 4(4)(a).


-----

34. As indicated above (paragraph 23), in the August decision letter, the decision maker said that he had
“considered each potential route through which the offence could be made out”, which would on its face
include the section 4(4)(c) route – but then went on to consider _seriatim those potential routes, not_
mentioning any section 4(4)(c) route, before concluding that the evidential test was not met. This is a clear
indication that, in the August decision letter at least, the section 4(4)(c) route was not in his mind at all.

35. Therefore, although the June decision letter asserts that there is an insufficiency of evidence to sustain
charges against Mr & Mrs Aljaberi on the basis that they deceived the Claimant to induce her to come to
provide services in the UK, there is simply no indication in the June or August decision letter that the
decision maker considered at all the relevant available evidence. There is no indication in either letter that
the decision maker considered the available evidence as to (i) deception (notably the terms as to pay and
hours settled prior to the Claimant's departure for the UK compared with the actual hours required and
payments made in respect of the Claimant's work in London, including whether this amounted to deception
on the part of Mr and/or Mrs Aljaberi), and (ii) if it were deception, whether the Claimant was induced by it
to come and work in the UK; or that he considered the extent to which that evidence might support such a
charge. As to (i), the Claimant's evidence was clear and (with the exception of one occasion when she
referred to 48 – rather than 40 – hours per week) consistent; and, at least as to required hours, confirmed
in the CoS. As to (ii), the Claimant said in her interview that the proposed terms as to pay and hours were
“the reason I came here” (ABE Interview Transcript, page 20); and, in her January 2014 statement, she
said that she had only accepted the job in London “because it seemed that my working conditions in the
UK would be better” (paragraph 20). Whilst I accept that, even though the decision maker's starting point
was to accept the Claimant's evidence as credible (and, despite his concerns about inconsistencies etc, he
drew no conclusion that her version of events was generally not credible), the decision maker might have
considered that the evidence was still not sufficient to give a realistic prospect of conviction; but that is an
issue with which the decision maker appears not to have wrestled.

36. In my view, although we were referred to authorities on the adequacy of reasons in public law decision
making, this is not a reasons case: as Mr Douglas-Jones submitted, there is simply no evidence that the
decision maker grappled with the assessment of the sufficiency of the available evidence against the
elements of the offence by way of section 4(4)(c). In the absence of evidence, there is no basis for finding
that he did. The decision maker's approach was thus fundamentally flawed.

37. For those reasons, I find this part of the claim made good.

38. Turning to the alternative ground of resistance, section 31(2A) of the Senior Courts Act 1981 provides
that this court must refuse relief on an application for judicial review “if it appears to the court to be highly
likely that the outcome for the applicant would not be substantially different if the conduct complained of
had not occurred”. This is a significant change from the previous position at common law, established
since Simplex GE (Holdings) Limited v Secretary of State for the Environment [1988] PLR 25, that the court
could exercise its discretion to refuse relief but only where satisfied that the outcome would inevitably have
been the same even if the identified public law had not occurred. Nevertheless, “the threshold remains a
high one” (R (Public and Commercial Services Union) v Minister of the Cabinet Office [2017] EWHC 1787
_[(Admin); [2018] 1 All ER 142 at [89] per Sales J as he then was).](https://advance.lexis.com/api/document?collection=cases-uk&id=urn:contentItem:5RBG-6DN1-DYBP-M20P-00000-00&context=1519360)_

39. In considering whether a substantially different outcome would have been “highly likely”, it is
particularly important to have in mind the different constitutional roles of the executive and the courts. As
recently observed by the Court of Appeal (Lindblom, Singh and Haddon-Cave LJJ) in R (Plan B Earth) v
Secretary of State for Transport [2020] EWCA Civ 214 at [273], of the provisions of which section 31(2A)
forms part:

“It would not be appropriate to give any exhaustive guidance on how these provisions should be applied.
Much will depend on the particular facts of the case before the court. Nevertheless, it seems to us that the
court should still bear in mind that Parliament has not altered the fundamental relationship between the
courts and the executive. In particular, courts should still be cautious about straying, even subconsciously,
into the forbidden territory of assessing the merits of a public decision under challenge by way of judicial
review. If there has been an error of law, for example in the approach the executive has taken to its


-----

decision-making process, it will often be difficult or impossible for a court to conclude that it is 'highly likely'
that the outcome would not have been 'substantially different' if the executive had gone about the decisionmaking process in accordance with the law. Courts should also not lose sight of their fundamental
function, which is to maintain the rule of law…”.

With that, I respectfully agree.

40. As I have described, proper decision making in a charging context requires the prosecutor to assess
the available evidence against the elements of the potential offence. In this case, for the reasons I have
given, the decision maker's approach was fundamentally flawed. Nothing I have said in this judgment
should be taken as any indication of what the charging decision should or might be – that is a matter for the
DPP – but, in all of the circumstances, it seems to me that is it quite impossible to say that it is highly likely
that the decision would be in substance the same had the decision maker's approach been different and
lawful.

41. For those reasons, in my view, section 31(2A) does not apply in this case. Although of course not
determinative nor even relevant to the decision this court has to take under that provision, it comes as
some comfort (and as no surprise) that, on giving permission to proceed, Spencer J concluded that the
same test was not satisfied for the purposes of section 31(3D) of the 1981 Act, under which this court must
refuse permission to proceed with a judicial review claim if it is satisfied that it is highly likely that the
outcome for the applicant would not have been substantially different.

**Conclusion**

42. For those reasons, subject to my Lord, Sweeney J, I would allow the claim, and quash the decision of
13 August 2019. That will require the DPP to reconsider and remake the decision as to whether to charge
Mr and/or Mrs Aljaberi.

**Mr Justice Sweeney :**

43. I agree that, for the reasons given by my Lord, Hickinbottom LJ, the claim must be allowed, and the
decision of 13 August 2019 quashed.

**End of Document**


-----

