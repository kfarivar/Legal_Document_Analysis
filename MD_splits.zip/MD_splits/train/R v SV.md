# R v SV [2020] EWCA Crim 742

CA, CRIMINAL DIVISION

2019/03694/B4

Leggatt LJ, Lavender J, HHJ Stockdale QC

18 February 2020

18/02/2020

Tuesday 18[th] February 2020

**LORD JUSTICE LEGGATT: I shall ask His Honour Judge Stockdale QC, the Recorder of Manchester, to give the**
judgment of the court.

THE RECORDER OF MANCHESTER:

1. This is a renewed application for leave to appeal against sentence following refusal by the single judge.

2. On 26[th] June 2019, the applicant was convicted by a jury in the Crown Court at Snaresbrook of an offence of
wounding with intent, contrary to section 18 of the Offences against the Person Act 1861, the offence having been
committed on 7[th] May 2018. He was acquitted on a count of attempted murder.

3. On 13[th] September 2019, the applicant was sentenced by His Honour Judge Lafferty (the trial judge) to a term of
eight years' detention under section 91 of the Powers of Criminal Courts (Sentencing) Act 2000.

4. The facts may be summarised briefly. On the afternoon of 7[th] May 2018, Shermar Dawes was walking on a
street in Leytonstone Road, London when a moped approached him carrying two people. The pillion passenger
was armed with a pistol, which was then fired at him. Shermar Dawes fled the scene unharmed, but a short time
later a black car pulled up near to him. The occupants of the car got out and attacked him. One stabbed him with a
kitchen knife. The others joined in. He was repeatedly stabbed before the group made good its escape.

5. The victim sustained nine stab wounds to the right shoulder, neck, chest, armpit, buttock, right leg and right
flank. He suffered a collapsed lung and a fractured spine.

5. The applicant was born on 23[rd] October 2001. He was aged 16 at the time of the offence and 17 at the time of
conviction and at the time of sentence. He is now aged 18.

6. The sentencing judge concluded that the applicant and three other gang members had gone out looking for
Shermar Dawes. They had come upon him and attacked him with knives in a concerted and persistent attack in
which he sustained serious injuries. It was, as he found, a pre-planned and premeditated, armed attack. The judge
placed the offending within category 1 of the guideline for section 18 offences. That category takes a sentencing
court to a starting point for an adult with no previous convictions of twelve years' custody, and a category range of
nine to sixteen years.

7. This was gang activity. The judge accepted that, in gang culture, there was commonly an element of grooming
of young gang members such as the applicant. Young members were attracted by a sense of perceived glamour


-----

and by inducements offered by gang leaders. But by May 2018, as the judge was to find, the applicant was a
willing and rising member of the gang known as the "Anyone Can Go Gang". The applicant had taken part in socalled "drill videos" in which he and other gang members gloried in violence and in showing their disdain for other
gangs.

8. The judge had been assisted by a detailed and careful pre-sentence report prepared by Chris Glover of the local
Youth Offending Team. There had been a provisional finding that the applicant may have been a victim of modern
**_slavery; yet he had persisted in associating with the gang after his arrest for the present offence and in taking part_**
in the "drill videos".

9. On 26[th] October 2018, whilst on bail, the applicant had taken part in a serious robbery in which four gang
members robbed an unaccompanied female in a car. The applicant had been fortunate, in the judge's view, to
receive on 27[th] March 2019 a Youth Rehabilitation Order for that offence and an associated offence of having a
bladed article. That offence was a factor which the judge took into account when assessing whether the applicant
was a dangerous offender. It was also a factor to be considered, in our judgment, when approaching the
applicant's general mindset as to gang activity and his avowed level of remorse.

10. But for his conviction for the robbery in October 2018, the applicant had no previous convictions. He had none
at the time when he committed the present offence of wounding with intent.

11. The author of the pre-sentence report had investigated the possibility of criminal exploitation of the applicant
and had considered whether his offending fell within the National Referral Mechanism criteria. A National Referral
Mechanism referral had resulted in a provisional response that there were reasonable grounds to believe that the
applicant might be a victim of modern slavery. He had attracted the attention of local Children's Services and he
had been assessed as a child in need at the time of the present offence in May 2018. He had been referred to the
Safer London Gangs Exit Programme, but, following his arrest, he had remained affiliated with the Anyone Can Go
Gang and had committed the offences of October 2018. Despite this history, the author of the pre-sentence report
was able to offer a comprehensive Youth Rehabilitation Programme with intensive supervision and surveillance in
the event that the court was able to consider an alternative to custody.

12. Relying significantly on the pre-sentence report, which recounted the applicant's family's move away from
London and away from the gang's home ground, and on the applicant's efforts to disengage from his previous
associates, the judge drew back from a finding of dangerousness. He, nevertheless, found twelve years to be the
appropriate starting point for sentence, from which one-third was deducted to reflect the applicant's youth,
producing a sentence of eight years' detention (less 129 days for time spent on a qualifying curfew).

13. The grounds of appeal, lodged in writing and amplified before us today by Mr Lloyd in his helpful oral
submissions, are that the judge erred in not allowing an adjournment for a National Referral Mechanism Conclusive
Grounds Report, in concluding on insufficient evidence that the attack on Shemar Dawes was premeditated, and in
concluding, without sufficient regard to the evidence of grooming within gangs, that the applicant was a rising
member of the Anyone Can Go Gang. It was said that the starting point was set too high at twelve years, and that
the judge had failed to give sufficient weight to the applicant's previous good character or his recent progress in
rehabilitating himself.

14. As the single judge observed, this was a case of serious gang-related, tit-for-tat violence in which a
defenceless young man, attacked by a group armed with knives, might well have lost his life. It fell squarely within
category 1 of the adult guideline for cases of wounding with intent. It is clear from the sentencing remarks that the
judge took account of the provisional National Referral Mechanism finding that the applicant may have been a
victim of modern slavery, and he accepted that with every gang there is an element of grooming at the start. He
found, however, that in the present case the applicant had become a willing and rising member of the gang by May
2018. That was a finding he was fully entitled to make in the light of the events of 7[th] May 2018, the applicant's later
engagement in "drill videos", and his participation whilst on bail in the events of 26[th] October 2018. The judge's
findings as to pre-planning and premeditation are supported by the use of weapons and the circumstances in which
the victim was pursued.


-----

15. After allowance is made for all aggravating and mitigating factors, save for the applicant's youth, the judge's
adoption of a starting point of twelve years' custody cannot be faulted. The reduction by a factor of one-third, to
reflect the applicant's young age, is likewise unimpeachable. We note that in the written grounds of appeal the
correctness of that level of discount is openly conceded. In any event, it accords with paragraph 6.46 of the
guideline for sentencing children and young people.

16. The sentence in this case was not manifestly excessive. For the reasons stated by the single judge, we
consider the grounds of the application to be wholly unsustainable. Accordingly, the renewed application is refused.

**Epiq Europe Ltd hereby certify that the above is an accurate and complete record of the proceedings or part**
thereof.

Lower Ground, 18-22 Furnival Street, London EC4A 1JS

Tel No: 020 7404 1400

Email: rcj@epiqglobal.co.uk

**End of Document**


-----

